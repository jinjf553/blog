# Components

Components in this dir will be auto-registered and on-demand, powered by [`vite-plugin-components`](https://github.com/antfu/vite-plugin-components).

## Icons

You can uses icons from almost any icon sets by the power of [Iconify](https://iconify.design/).

It will only bundles the icons you use, check out [vite-plugin-icons](https://github.com/antfu/vite-plugin-icons) for more details.
