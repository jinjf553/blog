<template>
  <div
    class="absolute top-0 left-0 bottom-0 right-0 opacity-60"
    style="z-index: 99999; background: rgba(0, 0, 0, 0.8"
  />
  <div class="absolute top-0 left-0 bottom-0 right-0" style="z-index: 999999">
    <div class="flex w-full h-full items-center justify-center">
      <div class="w-128 h-64">
        <div class="h-32 mr-6">
          <Spinner color="#FFFFFF" />
        </div>
        <h1 class="text-white">{{ LoadingTitle }}</h1>
      </div>
    </div>
  </div>
</template>

<script setup lang="ts">
import { LoadingTitle } from '~/logics/store'
</script>
