<template>
  <productIcon
    v-if="![`工作量汇总`, `码表库更新`, `年金`].includes(props.heading || ``)"
    v-show="
      props.show == `true` || userProfile?.permissions?.includes(props.heading || '')
    "
    :heading="props.heading"
    :icon="props.icon"
    @execute="execute"
  />
  <el-popover v-else placement="top" trigger="click" popper-class="autowidth">
    <div class="flex flex-row w-auto">
      <div class="flex flex-row">
        <div v-if="props.heading == `码表库更新`" class="flex flex-row">
          <Dashboard-IUpdateDIMS />
        </div>
        <div v-if="props.heading == `工作量汇总`" class="flex flex-row">
          <Dashboard-IWorkAmount />
        </div>
        <div v-if="props.heading == `年金`" class="flex flex-row">
          <Dashboard-IAnnuity />
        </div>
      </div>
      <div class="flex w-full pt-3 pl-3">
        <!-- <span>工作量统计信息</span> -->
      </div>
    </div>
    <template #reference>
      <div>
        <productIcon
          v-show="
            props.show == `true` ||
            userProfile?.permissions?.includes(props.heading)
          "
          :heading="props.heading"
          :icon="props.icon"
          @execute="execute"
        />
      </div>
    </template>
  </el-popover>
</template>

<script setup lang="ts">
import { defineProps } from 'vue'
import { ElPopover } from 'element-plus'
import {
  userProfile,
  isBackgroundTaskRunning,
  rpaRunningMode,
  fileInfo,
  isLoading,
  LoadingTitle,
} from '~/logics/store'
import { rpcRpa } from '~/rpc'

const props = defineProps({ heading: String, icon: String, show: String })

async function execute(_: HTMLElement, subticket_type: string) {
  if (subticket_type === '快捷登录SAP') {
    if (isBackgroundTaskRunning.value && rpaRunningMode.value === '本机执行') {
      await window?.pywebview?.api?.win32_message_box_ok('本机正在执行RPA任务，暂时无法登录SAP', 'RPA启动器')
      return
    }
    isLoading.value = true
    LoadingTitle.value = '正在获取SAP登录信息，请稍等'
    try {
      await window?.pywebview?.api?.launch_sap_gui()
    }
    catch (err) {
      await window?.pywebview?.api?.win32_message_box_ok(err.message, 'RPA启动器')
    }
    finally {
      isLoading.value = false
    }
    return
  }
  if (isBackgroundTaskRunning.value) {
    await window?.pywebview?.api?.win32_message_box_ok('RPA任务执行中，请勿重复执行', 'RPA启动器')
    return
  }
  if (subticket_type === '快捷登录FTP') {
    try {
      await window?.pywebview?.api?.launch_ftp()
    }
    catch (err) {
      await window?.pywebview?.api?.win32_message_box_ok(err.message, 'RPA启动器')
    }
  }
  else if (subticket_type === '工作量汇总') {

  }
  else if (subticket_type === '码表库更新') {

  }
  else if (subticket_type === 'MDM机构编码申请') {
    rpcRpa.value.call('/sap/mdm').catch(async (err) => {
      await window?.pywebview?.api?.win32_message_box_ok(err.message, 'RPA启动器')
    })
  }
  else if (subticket_type === '年金') {

  }
  else {
    let filename = ''
    if (subticket_type !== '自动拆单') {
      filename = await window?.pywebview?.api?.win32_open_file()
      if (filename === '')
        return
    }
    let file_info: any = null
    isLoading.value = true
    try {
      file_info = await rpcRpa.value.call('/sap/parse_file_info', [filename, subticket_type])
    }
    catch (err) {
      await window?.pywebview?.api?.win32_message_box_ok(err.message, 'RPA启动器')
      return
    }
    finally {
      isLoading.value = false
    }

    try {
      if (file_info?.subticket_type !== '自动拆单' && !file_info?.filename) {
        const result: boolean = await window?.pywebview?.api?.message_box_okcancel(
          `文件：【${file_info?.filename}】事件类型为【${file_info?.subticket_type}】，请确认是否执行`,
          '人事RPA平台',
        ) as boolean
        if (result) {
          fileInfo.value = file_info
          await rpcRpa.value.call('/sap/execute', [subticket_type, fileInfo.value?.filename])
          isBackgroundTaskRunning.value = true
        }
      }
      else {
        const result: boolean = await window?.pywebview?.api?.message_box_okcancel(
          `事件类型【${file_info?.subticket_type}】，请确认是否执行`,
          '人事RPA平台',
        ) as boolean
        if (result) {
          fileInfo.value = file_info
          await rpcRpa.value.call('/sap/execute', [subticket_type, file_info?.filename])
          isBackgroundTaskRunning.value = true
        }
      }
    }
    catch (err) {
      await window?.pywebview?.api?.win32_message_box_ok(err.message, 'RPA启动器')
    }
    finally {
      isBackgroundTaskRunning.value = false
    }
  }
}
</script>

<style lang="postcss">
.autowidth {
  width: auto !important;
}
</style>
