<template>
  <div
    ref="el"
    class="flex flex-col items-center justify-center w-48 h-32 cursor-pointer hover:bg-gray-100"
    @click="click"
  >
    <div class="w-8 h-8 m-4 text-2xl text-blue-600 pointer-events-none" v-html="innerSvg" />
    <span class="text-base pointer-events-none">{{ props.heading }}</span>
  </div>
</template>

<script setup lang="ts">
import { defineEmit, onMounted, defineProps, ref } from 'vue'

import { ui5Icons } from '~/funcs/ui5Icons'

const innerSvg = ref('')

const emit = defineEmit(['execute'])
const props = defineProps({ heading: String, icon: String })
const el = ref(null)

function click() {
  emit('execute', el.value, props.heading)
}

onMounted(() => {
  if (typeof props.icon === 'string')
    innerSvg.value = ui5Icons[props.icon]
})
</script>
