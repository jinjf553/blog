<template>
  <el-tabs tab-position="right" style="width:850px; height:360px">
    <el-tab-pane label="年金">
      <div class="flex flex-col mx-4">
        <section class="mt-6">
          <label class="text-base font-bold">事件类型</label>
          <div class="flex flex-row">
            <el-radio-group v-model="eventType">
              <el-radio-button label="首次参加年金计划">首次参加年金计划</el-radio-button>
              <el-radio-button label="退休支付确认">退休支付确认</el-radio-button>
              <el-radio-button label="集团内转移个人信息">集团内转移个人信息</el-radio-button>
              <el-radio-button label="集团外变动信息">集团外变动信息</el-radio-button>
              <el-radio-button label="账管系统核查">账管系统核查</el-radio-button>
            </el-radio-group>
          </div>
        </section>
        <section class="mt-6">
          <div v-if="eventType == `账管系统核查`">
            <label class="text-base font-bold mr-4">执行目录</label>
            <div>
              <label v-if="dirname !== ``" class="mr-6">{{ dirname }}</label>
              <el-button type="primary" plain @click="selectDir">{{ dirname ? '重新选择' : '选择目录' }}</el-button>
            </div>
          </div>
          <div v-else class="flex flex-col">
            <div class="flex flex-col">
              <label class="text-base font-bold mr-4">处理类型</label>
              <div class="flex flex-row items-center">
                <el-radio v-model="inputType" label="机构" border>机构</el-radio>
                <div v-show="inputType == `机构`">
                  <el-dropdown @command="selectOrg">
                    <span class="el-dropdown-link">
                      {{ org ? org : '选择机构编码' }}
                      <i class="el-icon-arrow-down el-icon--right"></i>
                    </span>
                    <template #dropdown>
                      <el-dropdown-menu>
                        <el-dropdown-item command="10010023 扬子石化">10010023 扬子石化</el-dropdown-item>
                        <el-dropdown-item command="10010067 湖南石油">10010067 湖南石油</el-dropdown-item>
                        <el-dropdown-item command="13350042 上海赛诺佩克">13350042 上海赛诺佩克</el-dropdown-item>
                        <el-dropdown-item command="30250052 四川石油">30250052 四川石油</el-dropdown-item>
                        <el-dropdown-item command="30250090 重庆石油">30250090 重庆石油</el-dropdown-item>
                        <el-dropdown-item command="33300000 广西石油">33300000 广西石油</el-dropdown-item>
                        <el-dropdown-item command="33400000 贵州石油">33400000 贵州石油</el-dropdown-item>
                        <el-dropdown-item command="33450000 云南石油">33450000 云南石油</el-dropdown-item>
                        <el-dropdown-item command="35100000 海南炼化">35100000 海南炼化</el-dropdown-item>
                        <el-dropdown-item command="35450003 勘探分公司">35450003 勘探分公司</el-dropdown-item>
                        <el-dropdown-item command="36400000 项目管理公司">36400000 项目管理公司</el-dropdown-item>
                      </el-dropdown-menu>
                    </template>
                  </el-dropdown>
                </div>
              </div>
              <div class="flex flex-row items-center mt-1">
                <el-radio v-model="inputType" label="文件" border>文件</el-radio>
                <div v-show="inputType == `文件`">
                  <label v-if="filename !== ``" class="mr-6">{{ filename }}</label>
                  <el-button
                    type="primary"
                    plain
                    @click="selectFile"
                  >{{ filename ? '重新选择' : '选择文件' }}</el-button>
                </div>
              </div>
            </div>
            <div class="flex items-center mt-6">
              <label class="text-base font-bold mr-4">日期范围</label>
              <el-date-picker
                v-model="dateRange"
                type="daterange"
                unlink-panels
                format="YYYYMMDD"
                range-separator="至"
                start-placeholder="开始日期"
                end-placeholder="结束日期"
                :shortcuts="dateShortcuts"
              ></el-date-picker>
            </div>
          </div>
        </section>
        <section class="relative mt-6">
          <el-button v-if="executeEnabled" type="primary" @click="exectue">执行</el-button>
          <el-button v-else type="primary" disabled @click="exectue">执行</el-button>
        </section>
      </div>
    </el-tab-pane>
    <!-- <el-tab-pane label="执行历史"></el-tab-pane> -->
  </el-tabs>
</template>

<script setup lang="ts">
import { ref, onMounted, watch, computed } from 'vue'
import dayjs from 'dayjs'
import { ElDatePicker, ElRadioGroup, ElRadioButton, ElRadio, ElTabs, ElTabPane, ElButton } from 'element-plus'
import { rpcRpa } from '~/rpc'
import { isBackgroundTaskRunning, rpaRunningMode } from '~/logics/store'

const eventType = ref('首次参加年金计划')
const dateRange = ref([]) as any
const dateShortcuts = ref([{
  text: '本月',
  value: [dayjs(), dayjs()],
}]) as any
const org = ref('')
const dayBegin = ref('')
const dayEnd = ref('')
watch(dateRange, (newValue, _) => {
  if (newValue?.length === 2) {
    dayBegin.value = dayjs(newValue[0]).format('YYYYMMDD')
    dayEnd.value = dayjs(newValue[1]).format('YYYYMMDD')
  }
})
const inputType = ref('机构')
const filename = ref('')
const dirname = ref('')

const executeEnabled = computed(() => {
  if (eventType.value === '账管系统核查' && dirname.value !== '') return true
  else if (inputType.value === '文件' && filename.value !== '' && dayBegin.value !== '' && dayEnd.value !== '') return true
  else if (inputType.value === '机构' && org.value !== '' && dayBegin.value !== '' && dayEnd.value !== '') return true
  else return false
})

async function selectOrg(command: string) {
  org.value = command
}

async function selectFile() {
  filename.value = await window?.pywebview?.api?.win32_open_file()
}

async function selectDir() {
  dirname.value = await window?.pywebview?.api?.win32_open_dir()
}

async function exectue() {
  if (isBackgroundTaskRunning.value === true) {
    await window?.pywebview?.api?.win32_message_box_ok('RPA任务执行中，请勿重复执行', 'RPA启动器')
    return
  }
  if (rpaRunningMode.value !== '本机执行') {
    window?.pywebview?.api?.win32_message_box_ok('请选择【本机执行】，再执行年金任务', 'RPA启动器')
    return
  }
  const arg1: string = eventType.value
  let arg2 = ''
  if (eventType.value === '账管系统核查') arg2 = dirname.value
  else if (inputType.value === '机构') arg2 = org.value
  else arg2 = filename.value
  const arg3: string = eventType.value === '账管系统核查' ? '' : dayBegin.value
  const arg4: string = eventType.value === '账管系统核查' ? '' : dayEnd.value
  isBackgroundTaskRunning.value = true
  try {
    await rpcRpa.value.call('/annuity/execute', [arg1, arg2, arg3, arg4])
  }
  catch (err) {
    await window?.pywebview?.api?.win32_message_box_ok(err.message, 'RPA启动器')
  }
  finally {
    isBackgroundTaskRunning.value = false
  }
}

onMounted(() => {
  dateShortcuts.value[0].value = [dayjs().startOf('month'), dayjs().endOf('month')]
  dateRange.value = [dayjs().startOf('month'), dayjs().endOf('month')]
})
</script>
