<template>
  <div class="flex flex-row items-center justify-between w-full px-10 text-white h-11 titleblue">
    <div class="flex flex-row items-center">
      <div
        class="flex items-center justify-center w-8 h-8 px-6 rounded-md hover:bg-gray-600"
        @click="router.push(`/dashboard`)"
      >
        <i class="el-icon-s-home" />
      </div>
      <div class="pl-4 font-mono text-xs font-bold">
        <!-- <span class="mr-1">人事RPA平台</span> -->
        <code>
          <span>销售建岗可用岗位数：{{ bucketDstJobCount }}</span>
        </code>
      </div>
    </div>
    <div class="absolute m-auto right-0 left-0 w-64">
      <el-radio-group
        v-model="rpaRunningMode"
        size="small"
        :disabled="isLoading || isBackgroundTaskRunning"
        @change="switchRpaRunningModel"
      >
        <el-radio-button label="本机执行"></el-radio-button>
        <el-radio-button label="后台执行" :disabled="!isWinLoginInfoRight"></el-radio-button>
        <el-radio-button label="云上执行" disabled></el-radio-button>
      </el-radio-group>
    </div>
    <div class="flex flex-row items-center">
      <div class="flex items-center justify-center w-8 h-8 px-6 rounded-md hover:bg-gray-600">
        <i class="el-icon-position" />
      </div>
      <div class="flex items-center justify-center w-8 h-8 px-6 rounded-md hover:bg-gray-600">
        <i class="el-icon-bell" />
      </div>
      <el-popover placement="bottom" trigger="click" popper-class="autowidth">
        <div class="flex items-center justify-center">
          <ul>
            <li
              v-if="userProfile?.staff_roles?.includes('管理员')"
              class="h-6 text-blue-500 cursor-pointer hover:underline"
            >
              <a @click="router.push(`/dashboard/permission`)">权限管理</a>
            </li>
            <li class="h-6 text-blue-500 cursor-pointer hover:underline">
              <a @click="switchAccount">切换账号</a>
            </li>
          </ul>
        </div>
        <template #reference>
          <div class="flex items-center justify-center w-8 h-8 px-6 rounded-md hover:bg-gray-600">
            <i class="el-icon-s-custom" />
          </div>
        </template>
      </el-popover>
    </div>
  </div>
  <Loading v-if="isLoading" />
</template>

<script setup lang="ts">
import { onMounted, watch } from 'vue'
import { useRouter } from 'vue-router'
import { ElPopover, ElRadioButton, ElRadioGroup } from 'element-plus'
import { LoadingTitle, isLoading, isBackgroundTaskRunning, isWinLoginInfoRight, rpaRunningMode, rpaRunningModePrev, rpaServerVersion, bucketDstJobCount, userProfile, isWebsocketConnected, rpaHost } from '~/logics/store'
import { rpcRpa } from '~/rpc'

const router = useRouter()

async function switchAccount() {
  if (isLoading.value === false && isBackgroundTaskRunning.value === false) {
    rpaRunningMode.value = '本机执行'
    await switchRpaRunningModel('本机执行')
    router.push('/')
  }
  else {
    await window?.pywebview?.api?.win32_message_box_ok('后台任务正在执行，无法切换账号', 'RPA启动器')
  }
}

async function fallbackRpaRunningMode() {
  rpaRunningMode.value = rpaRunningModePrev.value
}

async function switchRpaRunningModel(value: any) {
  if (isLoading.value || isBackgroundTaskRunning.value) {
    await window?.pywebview?.api?.win32_message_box_ok('RPA任务执行中，暂时无法切换执行方式', 'RPA启动器')
    await fallbackRpaRunningMode()
    return
  }
  let webapi_port: number = await window?.pywebview?.api?.get_webapi_port()
  if (value === '后台执行') {
    isLoading.value = true
    LoadingTitle.value = '首次登录切换花费时间较长，杀毒软件可能告警，请同意。'
    try {
      await window?.pywebview?.api?.launch_ws_on_other_user()
      webapi_port = await window?.pywebview?.api?.get_rpa_webapi_port()
    }
    catch (err) {
      await window?.pywebview?.api?.win32_message_box_ok(err.message, 'RPA启动器')
      await fallbackRpaRunningMode()
      return
    }
    finally {
      isLoading.value = false
    }
  }
  if (typeof webapi_port === 'number') {
    const [fsoUserName, fsoPassWord] = await window?.pywebview?.api?.get_fso()
    rpaHost.value = `ws://localhost:${webapi_port}`
    let unwatch: any = null
    unwatch = watch(isWebsocketConnected, (newValue: boolean, _: boolean) => {
      if (newValue === true && unwatch !== null) {
        unwatch()
        rpcRpa.value.call('/auth/login', [fsoUserName, fsoPassWord])
      }
    })
  }
  else {
    await fallbackRpaRunningMode()
    console.error(webapi_port)
  }
}

async function chkWinLoginInfoRight() {
  isWinLoginInfoRight.value = await window?.pywebview?.api?.is_win_login_info_right() || false
}

async function getRpaServerVersion() {
  rpaServerVersion.value = await rpcRpa.value.call('/rpa_config/get_rpa_server_version', []) as string
}

async function getBucketDstJobCount() {
  bucketDstJobCount.value = await window?.pywebview?.api?.get_bucket_dst_job_count() || 0
}

onMounted(() => {
  getRpaServerVersion()
  chkWinLoginInfoRight()
  getBucketDstJobCount()
  setInterval(getBucketDstJobCount, 10000)
})

</script>

<style lang="postcss" >
.titleblue {
  background-color: #004dae;
}

.autowidth {
  width: auto !important;
}
</style>
