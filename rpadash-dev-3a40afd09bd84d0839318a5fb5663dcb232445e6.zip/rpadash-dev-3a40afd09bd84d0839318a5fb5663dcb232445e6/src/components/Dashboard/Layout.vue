<template inherit-attrs="false">
  <div class="flex flex-col h-screen max-h-screen bggradient">
    <Dashboard-Header />
    <div class="flex content" style="height: calc(100vh - 44px)">
      <div class="flex flex-1 w-full px-8 py-6">
        <slot />
      </div>
    </div>
  </div>
</template>
