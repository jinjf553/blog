<template>
  <el-tabs tab-position="right" style="width:1500px; height:340px" @tab-click="handleTabSwitch">
    <el-tab-pane label="工作量汇总">
      <div class="flex flex-col items-center justify-center w-full">
        <div class="flex items-center justify-center w-full">
          <div class="mx-2">工作量周期</div>
          <el-date-picker
            v-model="dateRange"
            type="daterange"
            unlink-panels
            format="YYYYMMDD"
            range-separator="至"
            start-placeholder="开始日期"
            end-placeholder="结束日期"
            :shortcuts="dateShortcuts"
          ></el-date-picker>
        </div>
        <div class="flex flex-row">
          <div class="flex flex-row">
            <productIcon heading="模板下载" icon="business-by-design" @click="downloadTemplate" />
          </div>
          <div
            v-if="
              userProfile?.staff_roles?.includes(`管理员`) ||
              userProfile?.staff_roles?.includes(`正经理`) ||
              userProfile?.staff_roles?.includes(`副经理`) ||
              userProfile?.staff_roles?.includes(`书记`)
            "
            class="flex flex-row"
          >
            <productIcon heading="模板上传" icon="excel-attachment" @click="uploadTemplate" />
            <productIcon
              heading="业务部工作量下载"
              icon="excel-attachment"
              @click="downloadWorkAmount(`业务部工作量`)"
            />
          </div>
          <div v-if="userProfile?.staff_roles?.includes(`组长`)" class="flex flex-row">
            <productIcon
              heading="组内工作量下载"
              icon="business-by-design"
              @click="downloadWorkAmount(`组内工作量`)"
            />
            <productIcon heading="组内工作量确认" icon="business-by-design" @click="confirmWorkAmount" />
          </div>
          <div v-if="userProfile?.staff_roles?.includes(`业务人员`)" class="flex flex-row">
            <productIcon heading="个人工作量上传" icon="business-by-design" @click="uploadWorkAmount" />
            <productIcon
              heading="个人工作量下载"
              icon="business-by-design"
              @click="downloadWorkAmount(`个人工作量`)"
            />
          </div>
        </div>
        <div class="flex items-center justify-center w-full">
          <pre class="break-words whitespace-pre-wrap font-sans text-base">
        <span class="font-bold">功能须知：</span>
        <span
  class="ml-4"
>1. “个人工作量上传”：上传时需在“工作量周期”选定日期范围，默认为“上周四”至“本周三”，可以手动更改为“上上周四”至“上周三”，开始日期为其他日期时将报错。</span>
        <span
  class="ml-4"
>2. “个人工作量下载”：下载时需在“工作量周期”选定日期范围，默认为“上周四”至“本周三”，可以手动更改日期范围，可以选择任意的开始日期和结束日期，没有限制。</span>
        <span class="ml-4">3. “组内工作量下载”和“业务部工作量下载”操作方法同上。</span>
        <span class="ml-4">4. 一周内多次上传工作量，后传的工作量会替换先传的工作量，不会叠加。</span>
        <span class="ml-4">5. 上传的“工作量统计表”请保持版本最新，非最新版本将会报错。本次“工作量模板”更新时间：20210524-09点44分。</span>
       </pre>
        </div>
      </div>
    </el-tab-pane>
    <el-tab-pane label="历史记录">
      <pre class="flex flex-col mt-3 mb-2 ml-4 mr-2 overflow-scroll text-left" style="height:320px">
        <span
  v-for="(logtext, index) in workAmountUpdateHistory"
  :key="index.toString()"
  class="text-sm break-words whitespace-pre-wrap"
>{{ logtext }}</span>
    </pre>
    </el-tab-pane>
  </el-tabs>
</template>

<script setup lang="ts">
import { ref, watch, onMounted } from 'vue'
import { ElDatePicker, ElTabs, ElTabPane } from 'element-plus'
import dayjs from 'dayjs'
import { rpcRpa } from '~/rpc'
import {
  userProfile,
  isLoading,
  isBackgroundTaskRunning,
  rpaRunningMode,
  isWebsocketConnected,
  LoadingTitle,
} from '~/logics/store'

const workAmountUpdateHistory = ref([]) as any
const dateShortcuts = ref([{
  text: '本周',
  value: [dayjs(), dayjs()],
}, {
  text: '上周',
  value: [dayjs(), dayjs()],
}]) as any
const dateRange = ref([]) as any
const dayBegin = ref('')
const dayEnd = ref('')

watch(dateRange, (newValue, _) => {
  if (newValue?.length === 2) {
    dayBegin.value = dayjs(newValue[0]).format('YYYYMMDD')
    dayEnd.value = dayjs(newValue[1]).format('YYYYMMDD')
  }
})

async function downloadTemplate() {
  // 模板下载
  await window?.pywebview?.api?.win32_message_box_ok('执行前请先关闭Excel，确保程序正常运行', 'RPA启动器')
  const default_filename = '工作量汇总_模板.xlsx'
  const filename: string = await window?.pywebview?.api?.win32_save_as(default_filename)
  if (filename) {
    isLoading.value = true
    LoadingTitle.value = '正在下载工作量汇总模板，请稍等'
    try {
      await rpcRpa.value.call('/work_amount/download_template', [filename])
      await window?.pywebview?.api?.win32_message_box_ok('工作量汇总模板下载成功!', 'RPA启动器')
    }
    catch (err) {
      await window?.pywebview?.api?.win32_message_box_ok(err.message, 'RPA启动器')
    }
    finally {
      isLoading.value = false
    }
  }
}

async function uploadTemplate() {
  // 模板上传
  const filename: string = await window?.pywebview?.api?.win32_open_file()
  if (filename) {
    isLoading.value = true
    LoadingTitle.value = '正在上传工作量汇总模板，请稍等'
    try {
      await rpcRpa.value
        .call('/work_amount/upload_template', [filename])
      await await window?.pywebview?.api?.win32_message_box_ok('工作量汇总模板上传成功!', 'RPA启动器')
    }
    catch (err) {
      await window?.pywebview?.api?.win32_message_box_ok(err.message, 'RPA启动器')
    }
    finally {
      isLoading.value = false
    }
  }
}

async function uploadWorkAmount() {
  // 工作量上传
  if (isBackgroundTaskRunning.value) {
    window?.pywebview?.api?.win32_message_box_ok('RPA任务执行中，请勿重复执行', 'RPA启动器')
    return
  }
  const filename: string = await window?.pywebview?.api?.win32_open_file()
  if (filename) {
    isLoading.value = true
    LoadingTitle.value = '正在上传工作量，请稍等'
    try {
      const result = await rpcRpa.value.call('/work_amount/before_check', [filename, dayBegin.value, dayEnd.value])
      if (result) {
        await rpcRpa.value.call('/work_amount/upload_data', [filename, dayBegin.value, dayEnd.value])
        await window?.pywebview?.api?.win32_message_box_ok('工作量上传成功!', 'RPA启动器')
      }
      else {
        await window?.pywebview?.api?.win32_message_box_ok('工作量前置校验未通过，请检查文件批注信息', 'RPA启动器')
      }
    }
    catch (err) {
      await window?.pywebview?.api?.win32_message_box_ok(err.message, 'RPA启动器')
    }
    finally {
      isLoading.value = false
    }
  }
}

async function downloadWorkAmount(data_type: string) {
  // 工作量下载
  if (isBackgroundTaskRunning.value) {
    window?.pywebview?.api?.win32_message_box_ok('RPA任务执行中，请勿重复执行', 'RPA启动器')
    return
  }
  if (rpaRunningMode.value !== '本机执行') {
    window?.pywebview?.api?.win32_message_box_ok('请选择【本机执行】，再下载工作量', 'RPA启动器')
    return
  }
  await window?.pywebview?.api?.win32_message_box_ok('执行前请先关闭Excel，确保程序正常运行', 'RPA启动器')
  const default_filename = `${data_type}_${dayBegin.value}-${dayEnd.value}.xlsx`
  const filename: string = await window?.pywebview?.api?.win32_save_as(default_filename)
  if (filename) {
    isLoading.value = true
    LoadingTitle.value = '正在下载工作量，请稍等'
    try {
      await rpcRpa.value.call('/work_amount/download_data', [filename, data_type, dayBegin.value, dayEnd.value])
      isLoading.value = false
      if (data_type === '业务部工作量')
        await rpcRpa.value.call('/work_amount/calc_data', [filename, dayBegin.value, dayEnd.value, true])

      else if (data_type === '组内工作量')
        rpcRpa.value.call('/work_amount/calc_data', [filename, dayBegin.value, dayEnd.value, false])

      else
        await window?.pywebview?.api?.win32_message_box_ok('工作量下载成功！', 'RPA启动器')
    }
    catch (err) {
      await window?.pywebview?.api?.win32_message_box_ok(err.message, 'RPA启动器')
    }
    finally {
      isLoading.value = false
    }
  }
}

async function confirmWorkAmount() {
  // 工作量确认
  try {
    const result: boolean = await window?.pywebview?.api?.message_box_okcancel(
      '点击[确认]提交本组工作量至经理处汇总，点击[取消]终止本次提交',
      '人事RPA平台',
    ) as boolean
    if (result) {
      isLoading.value = true
      LoadingTitle.value = '正在确认组内工作量，请稍等'
      await rpcRpa.value.call('/work_amount/comfirm_data', [])
      await window?.pywebview?.api?.win32_message_box_ok('已确认工作量', 'RPA启动器')
    }
  }
  catch (err) {
    await window?.pywebview?.api?.win32_message_box_ok(err.message, 'RPA启动器')
  }
  finally {
    isLoading.value = false
  }
}

async function getUpdateHistory() {
  if (isWebsocketConnected.value) {
    workAmountUpdateHistory.value = await rpcRpa.value.call('/work_amount/get_history', [])

    const current_week_range: any = await rpcRpa.value.call('/work_amount/get_week_range', [])
    const before_week_range: any = await rpcRpa.value.call('/work_amount/get_before_week_range', [])
    dateRange.value = [dayjs(current_week_range[0]), dayjs(current_week_range[1])]
    dateShortcuts.value[0].value = [dayjs(current_week_range[0]), dayjs(current_week_range[1])]
    dateShortcuts.value[1].value = [dayjs(before_week_range[0]), dayjs(before_week_range[1])]
  }
}

async function handleTabSwitch(_: any, __: any) {
  await getUpdateHistory()
}

onMounted(async () => {
  if (isWebsocketConnected.value) {
    await getUpdateHistory()
  }
  else {
    watch(isWebsocketConnected, (newValue, _) => {
      if (newValue)
        getUpdateHistory()
    })
  }
})
</script>
