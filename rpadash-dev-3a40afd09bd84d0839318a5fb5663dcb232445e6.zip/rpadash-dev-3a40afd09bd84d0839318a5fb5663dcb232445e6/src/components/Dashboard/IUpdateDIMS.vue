<template>
  <div class="flex flex-col">
    <el-tabs tab-position="right" style="width: 950px;height:200px" @tab-click="handleTabSwitch">
      <el-tab-pane label="码表更新">
        <div
          v-if="userProfile?.staff_roles?.includes(`管理员`)"
          class="flex flex-col items-center justify-center"
        >
          <div>
            <el-radio-group v-model="group_name">
              <el-radio-button label="人事一组" />
              <el-radio-button label="人事二组" />
              <el-radio-button label="人事三组" />
              <el-radio-button label="人事四组" />
              <el-radio-button label="人事五组" />
              <el-radio-button label="人事六组" />
              <el-radio-button label="RPA团队" />
              <el-radio-button label="公用" />
              <el-radio-button label="全部" />
              <br />
              <el-radio-button label="薪酬一组" />
              <el-radio-button label="薪酬二组" />
              <el-radio-button label="薪酬三组" />
              <el-radio-button label="薪酬四组" />
              <el-radio-button label="薪酬五组" />
              <el-radio-button label="薪酬六组" />
            </el-radio-group>
          </div>
          <div class="flex flex-row">
            <productIcon
              heading="下载调配码表"
              icon="business-by-design"
              @click="downloadDIMS(`调配码表库`, group_name)"
            />
            <productIcon
              heading="更新调配码表"
              icon="business-by-design"
              @click="updateDIMS(`调配码表库`, group_name)"
            />
            <productIcon
              heading="下载离退码表"
              icon="business-by-design"
              @click="downloadDIMS(`离退码表库`, group_name)"
            />
            <productIcon
              heading="更新离退码表"
              icon="business-by-design"
              @click="updateDIMS(`离退码表库`, group_name)"
            />
          </div>
        </div>
        <div v-else class="flex flex-row">
          <productIcon
            heading="下载调配码表（本组）"
            icon="business-by-design"
            @click="downloadDIMS(`调配码表库`, userProfile?.staff_group)"
          />
          <productIcon
            heading="更新调配码表（本组）"
            icon="business-by-design"
            @click="updateDIMS(`调配码表库`, userProfile?.staff_group)"
          />
          <productIcon
            heading="下载离退码表（本组）"
            icon="business-by-design"
            @click="downloadDIMS(`离退码表库`, userProfile?.staff_group)"
          />
          <productIcon
            heading="更新离退码表（本组）"
            icon="business-by-design"
            @click="updateDIMS(`离退码表库`, userProfile?.staff_group)"
          />
        </div>
      </el-tab-pane>
      <el-tab-pane label="历史记录">
        <pre
          class="flex flex-col mt-3 mb-2 ml-4 mr-2 overflow-scroll text-left"
          style="height:150px"
        >
          <span
  v-for="(logtext, index) in dimsUpdateHistory"
  :key="index.toString()"
  class="text-sm break-words whitespace-pre-wrap"
>{{ logtext }}</span>
        </pre>
      </el-tab-pane>
    </el-tabs>
  </div>
</template>

<script setup lang="ts">
import { ref, watch, onMounted } from 'vue'
import { ElTabs, ElTabPane } from 'element-plus'
import { rpcRpa } from '~/rpc'
import {
  userProfile,
  isLoading,
  isBackgroundTaskRunning,
  isWebsocketConnected,
  LoadingTitle,
} from '~/logics/store'

const dimsUpdateHistory = ref([]) as any

const staffGROUPS = [
  '薪酬一组',
  '薪酬二组',
  '薪酬三组',
  '薪酬四组',
  '薪酬五组',
  '薪酬六组',
  '人事一组',
  '人事二组',
  '人事三组',
  '人事四组',
  '人事五组',
  '人事六组',
  'RPA团队',
]

const group_name = ref(userProfile.value?.staff_group)

if (!staffGROUPS.includes(group_name.value))
  group_name.value = '公用'

async function downloadDIMS(dims_name: string, group_name: string) {
  const default_filename = `${dims_name}_${group_name}.xlsx`
  const filename: string = await window?.pywebview?.api?.win32_save_as(default_filename)
  if (filename) {
    isLoading.value = true
    LoadingTitle.value = '正在下载码表库，请稍等'
    try {
      await rpcRpa.value.call('/dims/download_dims', [dims_name, group_name, filename])
      await window?.pywebview?.api?.win32_message_box_ok('码表库下载完成', 'RPA启动器')
    }
    catch (err) {
      await window?.pywebview?.api?.win32_message_box_ok(err.message, 'RPA启动器')
    }
    finally {
      isLoading.value = false
    }
  }
}

async function updateDIMS(dims_name: string, group_name: string) {
  if (isBackgroundTaskRunning.value) {
    window?.pywebview?.api?.win32_message_box_ok('RPA任务执行中，请勿重复执行', 'RPA启动器')
    return
  }
  if (group_name === '全部') {
    await window?.pywebview?.api?.win32_message_box_ok('仅支持公用、按组别更新码表', 'RPA启动器')
    return
  }
  await window?.pywebview?.api?.win32_message_box_ok('执行前请先关闭Excel，确保程序正常运行', 'RPA启动器')
  const filename: string = await window?.pywebview?.api?.win32_open_file()
  if (filename) {
    try {
      await rpcRpa.value.call('/dims/update_group_dims', [dims_name, group_name, filename])
      isBackgroundTaskRunning.value = true
    }
    catch (err) {
      await window?.pywebview?.api?.win32_message_box_ok(err.message, 'RPA启动器')
    }
  }
}

async function getUpdateHistory() {
  if (isWebsocketConnected.value)
    dimsUpdateHistory.value = await rpcRpa.value.call('/dims/get_dims_update_history', [])
}

async function handleTabSwitch(_: any, __: any) {
  await getUpdateHistory()
}

onMounted(async() => {
  if (isWebsocketConnected.value) {
    await getUpdateHistory()
  }
  else {
    watch(isWebsocketConnected, (newValue, _) => {
      if (newValue)
        getUpdateHistory()
    })
  }
})
</script>
