<template>
  <div class="absolute cursor-pointer" style="right: 8em; bottom: 6em" @click="openDialog">
    <div v-if="isBackgroundTaskRunning" class="w-16 h-8 mt-8 ml-8">
      <Spinner color="#3B82F6" />
    </div>
    <div v-else class="flex flex-row transform rotate-45" style="height: 41px">
      <div class="mx-px">
        <div class="w-6 h-6 my-px bg-blue-500" />
        <div class="w-6 h-6 my-px bg-blue-500" />
      </div>
      <div>
        <div class="w-6 h-6 my-px bg-blue-500" />
        <div class="w-6 h-6 my-px bg-blue-500" />
      </div>
    </div>
  </div>
  <div
    v-show="show"
    class="absolute top-0 left-0 w-screen h-screen opacity-60"
    style="z-index: 999; background: rgba(0, 0, 0, 0.8"
  />
  <div
    v-show="show"
    class="absolute"
    style="
      height: 800px;
      width: 1240px;
      z-index: 9999;
      top: calc((100vh - 800px) / 2);
      left: calc((100vw - 1240px) / 2);
    "
  >
    <el-card>
      <template #header>
        <span>当前任务</span>
      </template>
      <div class="flex flex-col w-full text-left">
        <div class="flex flex-col justify-between">
          <span>文件路径：{{ fileInfo?.filename }}</span>
          <span>SR号：{{ fileInfo?.sr_no }}</span>
          <span>事件类型：{{ fileInfo?.subticket_type }}</span>
          <span>
            记录数：{{
              fileInfo?.filename !== '' ? fileInfo?.row_count : ''
            }}
          </span>
          <span>执行开始时间：{{ backgroundTask?.begin_time || '' }}</span>
          <span>执行结束时间：{{ backgroundTask?.end_time || '' }}</span>
          <span>执行日志：</span>
        </div>
      </div>
      <pre
        class="flex flex-col mt-3 mb-2 mr-2 overflow-scroll text-left bg-gray-200"
        style="height: 500px"
        @mousemove="refreshScrollTimer"
      >
    <span
  v-if="isBackgroundTaskRunning || logText.length > 0"
  class="text-sm break-words whitespace-pre-wrap"
>
{{ backgroundTask?.begin_time ? '[' + backgroundTask?.begin_time + ']' : '                     ' }}                                    开始执行任务</span>
<span
  v-for="(logtext, index) in logText"
  :key="index"
  class="text-sm break-words whitespace-pre-wrap"
>{{ logtext }}</span>
    <span
  v-if="!isBackgroundTaskRunning && logText.length > 0"
  class="text-sm break-words whitespace-pre-wrap"
>{{ backgroundTask?.end_time ? '[' + backgroundTask?.end_time + ']' : '                     ' }}                                     任务执行结束</span>
    <span ref="elEnd" />
    </pre>
      <div class="mt-4">
        <div style="flex: 1" />
        <el-button type="primary" @click="closeDialog">
          {{
            isBackgroundTaskRunning ? '隐藏日志' : '关闭'
          }}
        </el-button>
      </div>
    </el-card>
  </div>

  <div
    class="absolute cursor-pointer"
    style="right: 8em; bottom: 6em"
    on:click="{handleBackgroundTaskIconClick}"
  />
</template>

<script setup lang="ts">
import { ref, onMounted, watch } from 'vue'
import { ElButton, ElCard } from 'element-plus'
import {
  backgroundTask,
  isBackgroundTaskRunning,
  fileInfo,
  logText,
} from '~/logics/store'
import { rpcLog } from '~/rpc'

const show = ref(false)
const elEnd = ref(null)
const timeoutToScroll = ref(10)

rpcLog.value.on('/log/log_text/clear', (_: any) => {
  logText.value = []
})

function openDialog() {
  show.value = true
}

function closeDialog() {
  show.value = false
}

function refreshScrollTimer() {
  timeoutToScroll.value = 10
}

onMounted(() => {
  watch(isBackgroundTaskRunning, (newValue, oldValue) => {
    if (newValue !== oldValue) {
      openDialog()
      if (oldValue === true && newValue === false) {
        setTimeout(async () => {
          await window?.pywebview?.api?.win32_message_box_ok('RPA执行结束', 'RPA启动器')
        }, 100)
      }
    }
  })
  setInterval(() => {
    if (timeoutToScroll.value > 0) {
      timeoutToScroll.value = timeoutToScroll.value - 1
    }
    else {
      const el: any = elEnd.value
      if (el !== null)
        el.scrollIntoView()
    }
  }, 1000)
})
</script>
