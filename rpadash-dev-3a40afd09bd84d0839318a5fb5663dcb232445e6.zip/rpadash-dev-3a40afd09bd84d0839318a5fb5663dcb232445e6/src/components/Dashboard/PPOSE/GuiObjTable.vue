<template>
  <div class="h-full">
    <el-table
      empty-text="暂无数据"
      :data="orgTable"
      row-key="obj_id"
      lazy
      :load="load"
      :height="400"
      :tree-props="{ children: 'children', hasChildren: 'has_children' }"
    >
      <el-table-column prop="obj_id" label="对象类型" width="200" fixed="left"></el-table-column>
      <el-table-column prop="obj_type" label="对象类型" width="80"></el-table-column>
      <el-table-column prop="obj_name" label="人员分配（结构）" width="180"></el-table-column>
      <el-table-column prop="obj_stext" label="名称" width="360"></el-table-column>
      <el-table-column prop="obj_begda" label="有效日从" width="100"></el-table-column>
      <el-table-column prop="obj_endda" label="有效期至" width="100"></el-table-column>
      <el-table-column prop="obj_vbegda" label="分配起始日期" width="110"></el-table-column>
      <el-table-column prop="obj_vendda" label="分配截至日期" width="110"></el-table-column>
      <el-table-column prop="obj_manager" label="主管" fixed="right"></el-table-column>
    </el-table>
  </div>
</template>

<script setup lang="ts">
import { ref, onMounted, watch } from 'vue'
import { ElTable, ElTableColumn } from 'element-plus'
import { ppose, isWebsocketConnected } from '~/logics/store'
import { rpcRpa } from '~/rpc'

const orgTable = ref([]) as any

async function load(tree: any, _: any, resolve: any) {
  if (ppose.value.is_ready) {
    const parentOrgId: string = tree?.obj_id || ''
    resolve(await rpcRpa.value.call('/ppose/get_gui_view', [parentOrgId]))
  }
}

async function initData() {
  orgTable.value = await rpcRpa.value.call('/ppose/get_gui_view', [''])
}

onMounted(async () => {
  if (isWebsocketConnected.value) { await initData() }
  else {
    watch(isWebsocketConnected, (newValue, _) => {
      if (newValue)
        initData()
    })
  }
})
</script>
