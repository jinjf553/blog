<template>
  <div class="bg-gray-500"></div>
</template>

<script setup lang="ts">
import { watch } from 'vue'
import { ppose } from '~/logics/store'
import { rpcRpa } from '~/rpc'

watch(ppose, (newValue, _) => {
  if (newValue.is_ready)
    rpcRpa.value.call('')
})
</script>
