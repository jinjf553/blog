<template>
  <el-dialog v-model="dialogVisible" title="提示" width="30%">
    <div class="flex flex-col">
      <span>建岗需要先连接SAP预读机构、岗位、人员信息，过程中不能执行其他操作。</span>
      <span>预计将花费2-5分钟，是否继续？</span>
    </div>
    <template #footer>
      <span class="dialog-footer">
        <el-button @click="router.push(`/dashboard`)">取 消</el-button>
        <el-button type="primary" @click="initPPOSE">确 定</el-button>
      </span>
    </template>
  </el-dialog>
</template>

<script setup lang="ts">
import { onMounted, ref } from 'vue'
import { useRouter } from 'vue-router'
import { ElDialog, ElButton } from 'element-plus'
import { ppose, isLoading, LoadingTitle } from '~/logics/store'
import { rpcRpa } from '~/rpc'
const router = useRouter()
const dialogVisible = ref(false)

async function initPPOSE() {
  dialogVisible.value = false
  isLoading.value = true
  LoadingTitle.value = '正在预读PPOSE数据，请稍等'
  try {
    const org_ids: any[] = await rpcRpa.value.call('/ppose/open_ppose', []) as any[]
    const is_ppose_ready = await rpcRpa.value.call('/ppose/is_ppose_ready', [])
    if (is_ppose_ready) {
      ppose.value.is_ready = true
      if (org_ids.length > 0) {
        ppose.value.current_org_id = org_ids[0]
        ppose.value.current_obj_id = org_ids[0]
      }
      const begin_date: string = await rpcRpa.value.call('/ppose/get_begin_date', []) as string
      ppose.value.begin_date = begin_date
    }
  }
  catch (err) {
    await window?.pywebview?.api?.win32_message_box_ok(err.message, 'RPA启动器')
  }
  finally {
    isLoading.value = false
  }
}

onMounted(() => {
  if (!ppose.value.is_ready)
    dialogVisible.value = true
})
</script>
