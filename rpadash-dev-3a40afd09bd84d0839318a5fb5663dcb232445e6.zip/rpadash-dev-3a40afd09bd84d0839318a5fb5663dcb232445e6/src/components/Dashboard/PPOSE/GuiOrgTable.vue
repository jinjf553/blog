<template>
  <div class="h-full">
    <el-table
      empty-text="暂无数据"
      :data="orgTable"
      row-key="org_id"
      lazy
      :height="800"
      :load="load"
      :tree-props="{ children: 'children', hasChildren: 'has_children' }"
    >
      <el-table-column prop="org_id" label="ID" width="180"></el-table-column>
      <el-table-column prop="org_name" label="代码" width="180"></el-table-column>
    </el-table>
  </div>
</template>

<script setup lang="ts">
import { ref, onMounted, watch } from 'vue'
import { ElTable, ElTableColumn } from 'element-plus'
import { ppose, isWebsocketConnected } from '~/logics/store'
import { rpcRpa } from '~/rpc'

const orgTable = ref([]) as any

async function load(tree: any, _: any, resolve: any) {
  if (ppose.value.is_ready) {
    const parentOrgId: string = tree?.org_id || '10010000'
    resolve(await rpcRpa.value.call('/ppose/get_gui_nav', [parentOrgId]))
  }
}

async function initData() {
  orgTable.value = await rpcRpa.value.call('/ppose/get_gui_nav', ['10010000'])
}

onMounted(async () => {
  if (isWebsocketConnected.value) { await initData() }
  else {
    watch(isWebsocketConnected, (newValue, _) => {
      if (newValue)
        initData()
    })
  }
})
</script>
