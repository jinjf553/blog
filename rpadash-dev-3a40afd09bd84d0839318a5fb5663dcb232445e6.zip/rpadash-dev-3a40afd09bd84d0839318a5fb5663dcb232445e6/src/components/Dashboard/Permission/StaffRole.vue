<template>
  <el-table
    :data="staffs"
    tooltip-effect="dark"
    height="90vh"
    class="w-auto"
    highlight-current-row
    stripe
    empty-text="暂无数据"
  >
    <el-table-column prop="staff_group" label="组别" width="120" />
    <el-table-column prop="staff_name" label="姓名" width="120" />
    <el-table-column v-for="(role, index) in roles" :key="role?.id" :label="role?.role_name">
      <template #default="scope">
        <el-checkbox
          v-model="staffRoles[scope.$index][index]"
          @change="(value) => { toggleStaffRole(scope.$index, index, value) }"
        />
      </template>
    </el-table-column>
  </el-table>
</template>
<script setup lang="ts">
import { onMounted, ref, watch } from 'vue'
import {
  ElTable,
  ElTableColumn,
  ElCheckbox,
} from 'element-plus'
import { isWebsocketConnected } from '~/logics/store'
import { rpcRpa } from '~/rpc'

const staffs = ref([]) as any
const roles = ref([]) as any
const staffRoles: any = ref([])

async function toggleStaffRole(row: any, col: any, isChecked: any) {
  try {
    await rpcRpa.value.call('/permission/toggle_staff_role', [staffs.value[row]?.staff_id, roles.value[col]?.role_id, isChecked])
  }
  catch (err) {
    await window?.pywebview?.api?.win32_message_box_ok(err.message, 'RPA启动器')
  }
}

async function refreshData() {
  async function refreshStaffRoles(roles: any, staffs: any, _data: any) {
    const result: boolean[][] = []
    for (let i = 0; i < staffs.length; i++)
      result.push(new Array(roles.length).fill(false))

    const role_ids: number[] = roles.map((role: any) => role.role_id)
    const staff_ids: number[] = staffs.map((staff: any) => staff.staff_id)
    _data.forEach((d: any) => {
      if (staff_ids.includes(d.staff_id) && role_ids.includes(d.role_id))
        result[staff_ids.indexOf(d.staff_id)][role_ids.indexOf(d.role_id)] = true
    })
    return result
  }

  const _roles: any = await rpcRpa.value.call('/permission/get_roles')
  const _staffs: any = await rpcRpa.value.call('/permission/get_staffs')
  const _data: any = await rpcRpa.value.call('/permission/get_all_staff_roles')
  const _staffRoles = await refreshStaffRoles(_roles, _staffs, _data)
  staffRoles.value = _staffRoles
  staffs.value = _staffs
  roles.value = _roles
}

onMounted(() => {
  if (isWebsocketConnected.value) {
    refreshData()
  }
  else {
    watch(isWebsocketConnected, (newValue, _) => {
      if (newValue) refreshData()
    })
  }
})
</script>
