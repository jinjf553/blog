<template>
  <el-table
    :data="permissions"
    tooltip-effect="dark"
    height="90vh"
    class="w-auto"
    highlight-current-row
    stripe
    empty-text="暂无数据"
  >
    <el-table-column prop="permission_name" label="权限名称" width="120" />
    <el-table-column v-for="(role, index) in roles" :key="role?.id" :label="role?.role_name">
      <template #default="scope">
        <el-checkbox
          v-model="rolePermissions[scope.$index][index]"
          @change="(value) => { toggleRolePermission(scope.$index, index, value) }"
        />
      </template>
    </el-table-column>
  </el-table>
</template>
<script setup lang="ts">
import { onMounted, ref, watch } from 'vue'
import {
  ElTable,
  ElTableColumn,
  ElCheckbox,
} from 'element-plus'
import { isWebsocketConnected } from '~/logics/store'
import { rpcRpa } from '~/rpc'

const permissions = ref([]) as any
const roles = ref([]) as any
const rolePermissions: any = ref([])

async function toggleRolePermission(row: any, col: any, isChecked: any) {
  try {
    await rpcRpa.value.call('/permission/toggle_role_permission', [roles.value[col]?.role_id, permissions.value[row]?.permission_id, isChecked])
  }
  catch (err) {
    await window?.pywebview?.api?.win32_message_box_ok(err.message, 'RPA启动器')
  }
}

async function refreshData() {
  async function refreshRolePermissions(roles: any, permissions: any, _data: any) {
    const result: boolean[][] = []
    for (let i = 0; i < permissions.length; i++)
      result.push(new Array(roles.length).fill(false))

    const role_ids: number[] = roles.map((role: any) => role.role_id)
    const permission_ids: number[] = permissions.map((p: any) => p.permission_id)
    _data.forEach((d: any) => {
      if (permission_ids.includes(d.permission_id) && role_ids.includes(d.role_id))
        result[permission_ids.indexOf(d.permission_id)][role_ids.indexOf(d.role_id)] = true
    })
    return result
  }

  const _roles: any = await rpcRpa.value.call('/permission/get_roles')
  const _permissions: any = await rpcRpa.value.call('/permission/get_permissions')
  const _data: any = await rpcRpa.value.call('/permission/get_all_role_permissions')
  const _rolePermissions = await refreshRolePermissions(_roles, _permissions, _data)
  rolePermissions.value = _rolePermissions
  permissions.value = _permissions
  roles.value = _roles
}

onMounted(() => {
  if (isWebsocketConnected.value) {
    refreshData()
  }
  else {
    watch(isWebsocketConnected, (newValue, _) => {
      if (newValue) refreshData()
    })
  }
})
</script>
