import ElementPlus from 'element-plus'
import locale from 'element-plus/lib/locale/lang/zh-cn'
import 'element-plus/lib/theme-chalk/index.css'
import { UserModule } from '~/types'

export const install: UserModule = ({ app }) => {
  app.use(ElementPlus, { locale })
}
