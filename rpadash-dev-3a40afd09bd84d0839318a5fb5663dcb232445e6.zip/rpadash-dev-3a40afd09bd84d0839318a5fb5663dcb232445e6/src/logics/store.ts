import { useSessionStorage } from '@vueuse/core'
import { Ref, ref, watch } from 'vue'
import { getCurrentDatetime } from '~/funcs/datetime'

export const backgroundTask = useSessionStorage('global-file-info', { begin_time: '', end_time: '' })
export const bucketDstJobCount = useSessionStorage('global-bucket-dst-job-count', 0) as Ref<number>
export const colorSchema = useSessionStorage('global-color-schema', 'auto') as Ref<'auto' | 'dark' | 'light'>
export const fileInfo = useSessionStorage('global-file-info', {}) as Ref<any>
export const isBackgroundTaskRunning = ref(false) as Ref<boolean>
export const isLoading = ref(false) as Ref<boolean>
export const isPposeReady = ref(false) as Ref<boolean>
export const isStaffLogin = useSessionStorage('global-is-staff-login', false) as Ref<boolean>
export const isWebsocketConnected = ref(false) as Ref<boolean>
export const isWebsocketError = ref(false) as Ref<boolean>
export const isWinLoginInfoRight = ref(false) as Ref<boolean>
export const LoadingTitle = ref('') as Ref<String>
export const logText = useSessionStorage('global-log-text', []) as Ref<String[]>
export const ppose = useSessionStorage('global-ppose', { is_ready: false, current_org_id: '', current_obj_id: '', obj_tab: '', begin_date: '' })
export const pposeNavActivateId = useSessionStorage('global-ppose-nav-activate-id', '') as Ref<string>
export const pposeViewActivateId = useSessionStorage('global-ppose-view-activate-id', '') as Ref<string>
export const rpaHost = useSessionStorage('global-rpa-host', `ws://localhost:${window?.pywebview?.webapi_port || 19527}`) as Ref<string>
export const rpaRunningMode = useSessionStorage('global-rpa-running-mode', '本机执行') as Ref<'本机执行' | '后台执行' | '远程执行'>
export const rpaRunningModePrev = useSessionStorage('global-rpa-running-mode-prev', '本机执行') as Ref<'本机执行' | '后台执行' | '远程执行'>
export const rpaServerVersion = useSessionStorage('global-rpa-server-version', '') as Ref<string>
export const userProfile = useSessionStorage('global-user-profile', {}) as Ref<any>

watch(isBackgroundTaskRunning, (newValue, oldValue) => {
  const currentTime: string = getCurrentDatetime()
  if (oldValue === false && newValue === true)
    backgroundTask.value = Object.assign(backgroundTask.value, { begin_time: currentTime })
  else if (oldValue === true && newValue === false)
    backgroundTask.value = Object.assign(backgroundTask.value, { end_time: currentTime })
})

watch(isLoading, (newValue, oldValue) => {
  if (oldValue === true && newValue === false) LoadingTitle.value = ''
})

watch(rpaRunningMode, (newValue, oldValue) => {
  rpaRunningModePrev.value = oldValue
})
