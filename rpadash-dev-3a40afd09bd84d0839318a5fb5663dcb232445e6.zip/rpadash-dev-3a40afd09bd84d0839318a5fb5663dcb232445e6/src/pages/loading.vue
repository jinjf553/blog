<template>
  <div class="flex flex-col items-center justify-center w-screen h-screen bgblue">
    <div v-if="isWaitingTimeout">
      <span class="font-sans text-2xl text-white">无法连接至服务器，请联系RPA管理员解决</span>
    </div>
    <div v-else>
      <Spinner />
    </div>
  </div>
</template>

<script setup lang="ts">
import { ref, onMounted, watch } from 'vue'
import { useRouter } from 'vue-router'
import { isWebsocketConnected } from '~/logics/store'
const router = useRouter()
const isWaitingTimeout = ref(false)

onMounted(async () => {
  if (isWebsocketConnected.value === true) {
    await window?.pywebview?.api?.win32_app_hwnd()
    router.push('/login')
  }
  else {
    watch(isWebsocketConnected, (isConnected, _) => {
      if (isConnected) {
        window?.pywebview?.api?.win32_app_hwnd().then(() => {
          router.push('/login')
        })
      }
    })
    setTimeout(() => {
      isWaitingTimeout.value = true
    }, 20000)
  }
})
</script>

<style lang="postcss" scoped>
.bgblue {
  background-color: #2b6cb0;
}
</style>
