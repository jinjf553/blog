<template>
  <div class="flex items-center justify-center w-screen h-screen bgblue">
    <el-card class="box-card" style="width:500px">
      <template #header>
        <div class="clearfix">
          <span>登录</span>
        </div>
      </template>
      <div v-if="!isWinLoginInfoRight" class="flex flex-col items-end pr-16">
        <div class="m-3">
          <label class="mr-2 font-mono">
            WIN账号:
            <span class="text-red-600">*</span>
          </label>
          <el-input v-model="winUsername" placeholder="请输入账号" style="width:200px" disabled />
        </div>
        <div class="m-3">
          <label class="mr-2 font-mono">
            WIN密码:
            <span class="text-red-600">*</span>
          </label>
          <el-input
            ref="elPassword"
            v-model="winPassword"
            placeholder="请输入密码"
            show-password
            style="width:200px"
          />
        </div>
      </div>
      <div class="flex flex-col items-end pr-16">
        <div class="m-3">
          <label class="mr-2 font-mono">
            FSO账号:
            <span class="text-red-600">*</span>
          </label>
          <el-input v-model="fsoUserName" placeholder="请输入账号" style="width:200px" />
        </div>
        <div class="m-3">
          <label class="mr-2 font-mono">
            FSO密码:
            <span class="text-red-600">*</span>
          </label>
          <el-input
            ref="elPassword"
            v-model="fsoPassWord"
            placeholder="请输入密码"
            show-password
            style="width:200px"
          />
        </div>
      </div>
      <div class="mt-2">
        <el-button type="primary" class="mx-2" @click="login">确认</el-button>
        <el-button class="mx-2" @click="router.push(`/register`)">注册</el-button>
      </div>
      <div v-if="!isWinLoginInfoRight" class="flex items-center justify-center">
        <span class="flex mt-4 text-sm text-red-500">
          请输入登录信息，如Windows用户无密码，请为账号
          <a
            class="cursor-pointer underline font-bold"
            @click="open_user_accounts"
          >设置密码</a>。
        </span>
      </div>
    </el-card>
  </div>
</template>

<script setup lang="ts">
import { ElButton, ElInput, ElCard } from 'element-plus'
import { ref, onMounted } from 'vue'
import { useRouter } from 'vue-router'
import { isWebsocketConnected, isStaffLogin, isWinLoginInfoRight, userProfile } from '~/logics/store'
import { rpcRpa } from '~/rpc'

const router = useRouter()
const fsoUserName = ref('')
const fsoPassWord = ref('')
const winUsername = ref('')
const winPassword = ref('')
const elPassword = ref(null) as any
const isRepeatLogin = ref(false)

async function open_user_accounts() {
  await window?.pywebview?.api?.open_control_user_accounts()
}

async function login() {
  if (!isWinLoginInfoRight.value) {
    if ([winUsername.value, winPassword.value, fsoUserName.value, fsoPassWord.value].includes('')) {
      await window?.pywebview?.api?.win32_message_box_ok('必填字段不能为空', 'RPA启动器')
      return
    }
    try {
      await window?.pywebview?.api?.chk_win_login_locked(winUsername.value, winPassword.value)
      isWinLoginInfoRight.value = await window?.pywebview?.api?.win32_check_win_login(winUsername.value, winPassword.value)
    }
    catch (err) {
      await window?.pywebview?.api?.win32_message_box_ok(err.message, 'RPA启动器')
      return
    }
    console.log(isWinLoginInfoRight.value)
    if (!isWinLoginInfoRight.value) {
      await window?.pywebview?.api?.win32_message_box_ok('Windows登录信息错误，请检查密码是否正确', 'RPA启动器')
      return
    }
    else {
      await window?.pywebview?.api?.update_win(winUsername.value, winPassword.value)
    }
  }
  if (fsoUserName.value === '' || fsoPassWord.value === '') {
    await window?.pywebview?.api?.win32_message_box_ok('请输入FSO用户名和密码', 'RPA启动器')
    return
  }
  if (isWebsocketConnected.value) {
    if (isRepeatLogin.value === true) return
    else isRepeatLogin.value = true
    try {
      const isLoginSucc = await rpcRpa.value.call('/auth/login', [fsoUserName.value, fsoPassWord.value])
      isRepeatLogin.value = false
      if (isLoginSucc) {
        isStaffLogin.value = true
        userProfile.value = await rpcRpa.value.call('/user/me', [])
        await window?.pywebview?.api?.update_fso(fsoUserName.value, fsoPassWord.value)
        router.push('/dashboard')
      }
      else {
        await window?.pywebview?.api?.win32_message_box_ok('登录信息错误，请检查账号、密码是否正确', 'RPA启动器')
      }
    }
    catch (err) {
      await window?.pywebview?.api?.win32_message_box_ok(err.message, 'RPA启动器')
    }
    finally {
      isRepeatLogin.value = false
    }
  }
}

onMounted(async () => {
  isWinLoginInfoRight.value = await window?.pywebview?.api?.is_win_login_info_right() || false
  winUsername.value = await window?.pywebview?.api?.get_win_username()
  if (elPassword.value?.input) {
    elPassword.value?.input?.addEventListener('keyup', (e: any) => {
      if (e.keyCode === 13 && isRepeatLogin.value === false && fsoPassWord.value !== '')
        login()
    })
  }
})
</script>

<style lang="postcss" scoped>
.bgblue {
  background-color: #3182ce;
}
</style>
