<template>
  <div class="flex items-center justify-center w-screen h-screen bgblue">
    <el-card class="box-card" style="width: 540px">
      <template #header>
        <div class="clearfix">
          <span>注册</span>
        </div>
      </template>
      <div class="flex flex-col items-end pr-24">
        <div class="m-3">
          <label class="mr-2">
            姓名:
            <span class="text-red-600">*</span>
          </label>
          <el-input v-model="staffName" style="width: 200px" />
        </div>
        <div class="m-3">
          <label class="mr-2">
            手机:
            <span class="text-red-600">*</span>
          </label>
          <el-input v-model="phoneNum" style="width: 200px" />
        </div>
        <div class="m-3">
          <label class="mr-2">
            邮箱:
            <span class="text-red-600">*</span>
          </label>
          <el-input v-model="email" style="width: 200px" />
        </div>
        <div class="m-3">
          <label class="mr-2">
            座机号码:
            <span class="text-red-600">*</span>
          </label>
          <el-input v-model="telNum" style="width: 200px" />
        </div>
        <div class="m-3">
          <label class="mr-2">
            FSO账号:
            <span class="text-red-600">*</span>
          </label>
          <el-input v-model="fsoUserName" style="width: 200px" />
        </div>
        <div class="m-3">
          <label class="mr-2">
            FSO密码:
            <span class="text-red-600">*</span>
          </label>
          <el-input v-model="fsoPassWord" show-password style="width: 200px" />
        </div>
        <div class="m-3">
          <label class="mr-2">
            FUNJ账号:
            <span class="text-red-600">*</span>
          </label>
          <el-input v-model="funj" style="width: 200px" />
        </div>
      </div>
      <div class="mt-2">
        <el-button class="mx-2" @click="router.push(`/login`)">返回</el-button>
        <el-button type="primary" class="mx-2" @click="register">注册</el-button>
      </div>
    </el-card>
  </div>
</template>

<script setup lang="ts">
import { ElButton, ElInput, ElCard } from 'element-plus'
import { ref } from 'vue'
import { useRouter } from 'vue-router'
import { useSessionStorage } from '@vueuse/core'
import { rpcRpa } from '~/rpc'

const router = useRouter()
const phoneNum = useSessionStorage('register-phone-num', '')
const staffName = useSessionStorage('register-staff-name', '')
const email = useSessionStorage('register-email', '')
const telNum = useSessionStorage('register-tel-num', '')
const funj = ref('')
const fsoUserName = useSessionStorage('register-fso-username', '')
const fsoPassWord = ref('')

async function register() {
  const args: string[] = [
    staffName.value.trim(),
    phoneNum.value.trim(),
    email.value.trim(),
    telNum.value.trim(),
    fsoUserName.value.trim(),
    fsoPassWord.value.trim(),
    funj.value.trim(),
  ]
  if (args.includes('')) {
    await window?.pywebview?.api?.win32_message_box_ok('必填字段不能为空', 'RPA启动器')
    return
  }

  try {
    await rpcRpa.value
      .call('/user/register', [
        staffName.value.trim(),
        phoneNum.value.trim(),
        email.value.trim(),
        telNum.value.trim(),
        fsoUserName.value.trim(),
        fsoPassWord.value.trim(),
        funj.value.trim(),
      ])
    await window?.pywebview?.api?.win32_message_box_ok('注册成功，跳转至登录页面', 'RPA启动器')
    router.push('/login')
  }
  catch (err) {
    await window?.pywebview?.api?.win32_message_box_ok(err.message, 'RPA启动器')
  }
}
</script>

<style lang="postcss" scoped>
.bgblue {
  background-color: #3182ce;
}
</style>
