<template>
  <Dashboard-Layout>
    <el-tabs v-model="activeName" tab-position="right" class="w-full">
      <el-tab-pane label="用户角色管理" name="staffRole">
        <Dashboard-Permission-StaffRole />
      </el-tab-pane>
      <el-tab-pane
        v-if="userProfile?.staff_roles?.includes(`管理员`)"
        label="角色权限管理"
        name="rolePermission"
      >
        <Dashboard-Permission-RolePermission />
      </el-tab-pane>
    </el-tabs>
  </Dashboard-Layout>
</template>

<script setup lang="ts">
import { ref } from 'vue'
import {
  ElTabs,
  ElTabPane,
} from 'element-plus'
import { userProfile } from '~/logics/store'

const activeName = ref('staffRole')

</script>
