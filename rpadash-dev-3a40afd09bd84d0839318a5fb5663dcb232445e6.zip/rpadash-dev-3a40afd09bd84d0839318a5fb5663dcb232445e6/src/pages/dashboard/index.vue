<template>
  <Dashboard-Layout>
    <div class="flex flex-row w-full">
      <div
        class="flex flex-col items-center py-12 overflow-hidden bg-white shadow-2xl"
        style="width: 400px"
      >
        <section class="flex flex-row">
          <img alt="logo" src="/images/logos/1200px-SINOPEC_Group.png" class="w-16 h-16 ml-4" />
          <div class="flex flex-col ml-6 text-left">
            <span class="text-xl">{{ userProfile?.staff_name }}</span>
            <span>{{ userProfile?.email }}</span>
          </div>
        </section>
        <section class="flex flex-col w-full mt-8 ml-16 text-lg text-left">
          <div class="flex flex-row mt-4">
            <div class="w-1/3 text-right">组别：</div>
            <div>{{ userProfile?.staff_group }}</div>
          </div>
          <div class="flex flex-row mt-4">
            <div class="w-1/3 text-right">账号：</div>
            <div>{{ userProfile?.funj }}</div>
          </div>
          <div class="flex flex-row mt-4">
            <div class="w-1/3 text-right">手机：</div>
            <div>{{ userProfile?.phone_num }}</div>
          </div>
        </section>
        <section class="flex content-center w-full mt-6">
          <div class="w-9/12 mx-auto border-t border-blue-400" />
        </section>
        <section class="flex flex-col pl-8 mt-8 ml-6 mr-16 text-xl">
          <div class="flex flex-col justify-between ml-4 text-base text-left">
            <span class="mb-4 text-base text-gray-800">快捷入口</span>
            <div class="m-2">
              <a
                class="text-gray-800 no-underline cursor-pointer hover:underline"
                @click="openUrl(`http://sssc.sinopec.com/AppNav/departmentChannel/NanJingCompany`)"
              >共享服务有限公司</a>
            </div>
            <div class="m-2">
              <a
                class="text-gray-800 no-underline cursor-pointer hover:underline"
                @click="openUrl(`https://mail.sinopec.com/owa/auth/logon.aspx?replaceCurrent=1&url=https%3a%2f%2fmail.sinopec.com%2fowa%2f`)"
              >中石化邮箱</a>
            </div>
            <div class="m-2">
              <a
                class="text-gray-800 no-underline cursor-pointer hover:underline"
                @click="openUrl(`https://uid.sinopec.com/ss/`)"
              >统一身份自助服务</a>
            </div>
            <div class="m-2">
              <a
                class="text-gray-800 no-underline cursor-pointer hover:underline"
                @click="openUrl(`http://172.16.11.2:8080/accounts/login/?next=/iclock/staff/`)"
              >时间管理平台</a>
            </div>
            <div class="m-2">
              <a
                class="text-gray-800 no-underline cursor-pointer hover:underline"
                @click="openUrl(`http://fso.sinopec.com/sap/bc/bsp/sap/crm_ui_start/default.htm?sap-client=800&sap-sessioncmd=open`)"
              >共享服务运行系统 FSO</a>
            </div>
            <div class="m-2">
              <a
                class="text-gray-800 no-underline cursor-pointer hover:underline"
                @click="openUrl(`http://10.246.138.110:8080/hrs-ssp/session/login.action`)"
              >企业平台</a>
            </div>
            <div class="m-2">
              <a
                class="text-gray-800 no-underline cursor-pointer hover:underline"
                @click="openUrl(`https://hrzhyy.sinopec.com/irj/portal`)"
              >综合应用平台</a>
            </div>
            <div class="m-2">
              <a
                class="text-gray-800 no-underline cursor-pointer hover:underline"
                @click="openUrl(`https://sia.sinopec.com/learn/index.html`)"
              >中国石化网络学院</a>
            </div>
            <div class="m-2">
              <a
                class="text-gray-800 no-underline cursor-pointer hover:underline"
                @click="openUrl(`https://ss.sinopec.com/`)"
              >服务评价</a>
            </div>
          </div>
        </section>
      </div>
      <div
        class="w-full pl-4 ml-8 overflow-y-auto text-xl bg-white shadow-2xl overscroll-x-none"
        style="min-width: 810px"
      >
        <section class="mt-4 mb-3">
          <div class="w-64 pb-4 ml-4 text-2xl text-left border-b border-blue-400">业务处理</div>
          <div class="flex flex-row flex-wrap">
            <ProductItem heading="组织机构维护" icon="edit" />
            <ProductItem heading="销售建岗" icon="create-form" />
            <ProductItem heading="员工入职" icon="add-employee" />
            <ProductItem heading="大学生入职" icon="add-employee" />
            <ProductItem heading="岗位变动" icon="user-settings" />
            <ProductItem heading="二级单位间调动" icon="kpi-managing-my-area" />
            <ProductItem heading="直属单位间调动" icon="leads" />
            <ProductItem heading="内退" icon="customer-history" />
            <ProductItem heading="离退休" icon="person-placeholder" />
            <ProductItem heading="离退休减册" icon="customer-briefing" />
            <ProductItem heading="不在岗变动" icon="customer-briefing" />
            <ProductItem heading="离职" icon="role" />
            <ProductItem heading="离岗" icon="supplier" />
            <ProductItem heading="劳务工退回" icon="visits" />
          </div>
        </section>
        <section class="mb-3">
          <div class="w-64 pb-4 ml-4 text-2xl text-left border-b border-blue-400">实用工具</div>
          <div class="flex flex-row flex-wrap">
            <ProductItem heading="快捷登录SAP" icon="sap-logo-shape" />
            <ProductItem heading="快捷登录FTP" icon="sap-box" />
            <ProductItem heading="手动拆单" icon="supplier" />
            <ProductItem heading="自动拆单" icon="product" />
            <ProductItem heading="机构岗位查询分析" icon="inspection" />
            <ProductItem heading="组合逻辑查询导出" icon="sys-next-page" />
            <ProductItem heading="员工信息表导出" icon="employee-lookup" />
            <ProductItem
              v-if="!userProfile?.staff_group?.includes(`薪酬`)"
              heading="工作量汇总"
              icon="kpi-corporate-performance"
            />
            <ProductItem heading="码表库更新" icon="upload-to-cloud" />
            <ProductItem heading="组织分配屏修改" icon="edit" />
            <ProductItem heading="成本中心定位" icon="activity-2" />
            <ProductItem heading="成本中心信息导出" icon="sys-last-page" />
            <ProductItem heading="MDM机构编码申请" icon="add-document" />
            <ProductItem heading="单位简化全称修改" icon="write-new-document" />
            <ProductItem heading="年金" icon="write-new-document" />
          </div>
        </section>
      </div>
    </div>
  </Dashboard-Layout>
  <Dashboard-BackgroundTask />
</template>

<script setup lang="ts">
import { userProfile } from '~/logics/store'

async function openUrl(url: string) {
  await window?.pywebview?.api?.win32_open_url(url)
}
</script>
