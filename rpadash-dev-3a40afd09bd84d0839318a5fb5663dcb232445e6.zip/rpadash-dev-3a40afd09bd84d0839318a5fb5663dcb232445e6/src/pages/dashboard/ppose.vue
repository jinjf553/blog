<template>
  <Dashboard-Layout>
    <el-container>
      <div class="border-r-8">
        <el-aside width="400px">
          <Dashboard-PPOSE-GuiOrgTable></Dashboard-PPOSE-GuiOrgTable>
        </el-aside>
      </div>
      <el-main>
        <div class="flex flex-col h-full">
          <div class="border-b-8 border-gray-300 h-1/2">
            <Dashboard-PPOSE-GuiObjTable></Dashboard-PPOSE-GuiObjTable>
          </div>
          <div class="h-1/2">
            <Dashboard-PPOSE-GuiObjData></Dashboard-PPOSE-GuiObjData>
          </div>
          <div></div>
        </div>
      </el-main>
    </el-container>
  </Dashboard-Layout>
  <Dashboard-PPOSE-GuiDialogInitPPOSE></Dashboard-PPOSE-GuiDialogInitPPOSE>
</template>

<script setup lang="ts">
import { ElContainer, ElAside, ElMain } from 'element-plus'
// import { ppose } from '~/logics/store'
</script>
