<template>
  <main class="text-center text-gray-700 dark:text-gray-200">
    <router-view />
  </main>
</template>

<script setup lang="ts">
import { onMounted } from 'vue'
import { useHead } from '@vueuse/head'
import hotkeys from 'hotkeys-js'
import '~/rpc'

// https://github.com/vueuse/head
// you can use this to manipulate the document head in any components,
// they will be renedered correctly in the html results with vite-ssg
useHead({
  title: 'Vitesse',
  meta: [
    { name: 'description', content: 'Opinionated Vite Starter Template' },
  ],
})

function avoidHotkey(event: any, _: any) {
  event.preventDefault()
}

onMounted(() => {
  if (process.env.NODE_ENV === 'production') {
    document.oncontextmenu = () => {
      return false
    }
    hotkeys('alt+left', avoidHotkey)
    hotkeys('alt+right', avoidHotkey)
    hotkeys('ctrl+d', avoidHotkey)
    hotkeys('ctrl+f4', avoidHotkey)
    hotkeys('ctrl+h', avoidHotkey)
    hotkeys('ctrl+j', avoidHotkey)
    hotkeys('ctrl+n', avoidHotkey)
    hotkeys('ctrl+o', avoidHotkey)
    hotkeys('ctrl+p', avoidHotkey)
    hotkeys('ctrl+r', avoidHotkey)
    hotkeys('ctrl+s', avoidHotkey)
    hotkeys('ctrl+shift+c', avoidHotkey)
    hotkeys('ctrl+shift+del', avoidHotkey)
    hotkeys('ctrl+shift+i', avoidHotkey)
    hotkeys('ctrl+shift+n', avoidHotkey)
    hotkeys('ctrl+shift+o', avoidHotkey)
    hotkeys('ctrl+shift+p', avoidHotkey)
    hotkeys('ctrl+shift+r', avoidHotkey)
    hotkeys('ctrl+shift+u', avoidHotkey)
    hotkeys('ctrl+shift+w', avoidHotkey)
    hotkeys('ctrl+t', avoidHotkey)
    hotkeys('ctrl+u', avoidHotkey)
    hotkeys('ctrl+w', avoidHotkey)
    hotkeys('f1', avoidHotkey)
    hotkeys('f10', avoidHotkey)
    hotkeys('f12', avoidHotkey)
    hotkeys('f2', avoidHotkey)
    hotkeys('f4', avoidHotkey)
    hotkeys('f5', avoidHotkey)
    hotkeys('f6', avoidHotkey)
    hotkeys('f7', avoidHotkey)
    hotkeys('f8', avoidHotkey)
    hotkeys('f9', avoidHotkey)
    hotkeys('shift+f10', avoidHotkey)
    hotkeys('shift+f5', avoidHotkey)
  }
})
</script>
