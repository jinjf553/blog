import dayjs from 'dayjs'

export function getCurrentDatetime(): string {
  return dayjs(new Date()).format('YYYY-MM-DD HH:mm:ss')
}
