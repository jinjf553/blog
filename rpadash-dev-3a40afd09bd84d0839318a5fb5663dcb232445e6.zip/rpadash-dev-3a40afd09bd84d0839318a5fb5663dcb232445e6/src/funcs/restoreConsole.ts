function restoreConsole() {
  const i: any = document.createElement('iframe')
  i.style.display = 'none'
  document.body.appendChild(i)
  window.console = i?.contentWindow?.console || console
}
