import { Client as Websocket } from 'rpc-websockets/build-ts/index.browser'
import { ref, Ref, watch } from 'vue'
import { fileInfo, isBackgroundTaskRunning, isPposeReady, isWebsocketConnected, isWebsocketError, logText, rpaHost } from '~/logics/store'

function websocket_rpc(uri: string) {
  const rpc = new Websocket(uri, { autoconnect: true, reconnect: true, reconnect_interval: 1000, max_reconnects: 20 })
  rpc.on('open', async () => {
    isWebsocketConnected.value = true
  })
  rpc.on('close', async () => {
    isWebsocketConnected.value = false
  })
  rpc.on('error', async (_: any) => {
    isWebsocketConnected.value = false
    isWebsocketError.value = true
  })
  rpc.on('/sap/is_background_task_running', ([is_running]: boolean[]) => {
    isBackgroundTaskRunning.value = is_running
  })
  rpc.on('/ppose/is_ppose_ready', ([isReady]: boolean[]) => {
    isPposeReady.value = isReady
  })
  rpc.on('update_file_info', ([newFileInfo]: any[]) => {
    fileInfo.value = Object.assign(fileInfo.value, newFileInfo)
  })
  return rpc
}

function websocket_rpc_log_text(uri: string) {
  const rpc = new Websocket(uri, { autoconnect: true, reconnect: true, reconnect_interval: 1000, max_reconnects: 20 })
  rpc.on('/log/log_text/clear', (_: any) => {
    logText.value = []
  })
  rpc.on('/log/log_text/update', (msg: string[]) => {
    logText.value = [...logText.value, ...msg]
  })
  return rpc
}

export const rpcRpa = ref(null) as unknown as Ref<Websocket>
export const rpcLog = ref(null) as unknown as Ref<Websocket>

function connect_ws(host: string) {
  rpcRpa.value?.close()
  rpcLog.value?.close()
  rpcRpa.value = websocket_rpc(`${host}/ws/rpc`)
  rpcLog.value = websocket_rpc_log_text(`${host}/ws/rpc_log_text`)
}

watch(rpaHost, (newValue: string, _: string) => {
  connect_ws(newValue)
})

connect_ws(rpaHost.value)
