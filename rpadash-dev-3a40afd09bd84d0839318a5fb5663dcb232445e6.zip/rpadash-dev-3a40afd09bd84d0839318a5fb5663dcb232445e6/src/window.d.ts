declare interface Window {
  // extend the window
  pywebview: any
}
