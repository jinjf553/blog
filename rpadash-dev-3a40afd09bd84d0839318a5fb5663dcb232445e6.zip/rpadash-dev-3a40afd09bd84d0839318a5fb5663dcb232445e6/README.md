# RPADASH

## 已知问题

- sirv-cli 在 windows 上偶尔会卡住，停止响应，servor 版本在 155 报错，local-web-server 无法打印请求日志，实现观察中
- 需要禁用 npm 插件，否则 package.json 报类型错错误
- 需要禁用 Vue 3 Snippets Highlight Formatters And Generator 插件，否则 .vue 文件报语法错误
- 需要禁用 eslint 插件
- vite-ssg 与 ui5-webcomponents、websockets 不兼容，无法 build
- ant-design-vue、vue、vue-i18n、vue-router 要用 next 的版本
- vite-plugin-vue-layouts 新版有问题，暂时只能用 0.2.2 版本
- vite版本变更依赖组件变更时，Header组件图标不能正常显示（更新至2.4.0-beta.2版本问题解决）

## 移除包

dependencies

- @ui5/webcomponents
- @ui5/webcomponents-fiori
- @ui5/webcomponents-icons
- @vaadin/vaadin
- ant-design-vue
- x-data-spreadsheet
- xlsx

devDependencies

- @iconify/json
- vite-plugin-icons
