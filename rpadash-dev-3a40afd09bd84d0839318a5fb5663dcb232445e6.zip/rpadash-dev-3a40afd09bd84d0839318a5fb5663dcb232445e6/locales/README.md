# i18n

This directory is to serve your locale translation files. Modify them to the locales you want, you might need to update `src/messages.ts` as well.

For more details, check out [`vue-i18n`](https://github.com/intlify/vue-i18n-next).

If you are using VS Code, [`i18n Ally`](https://github.com/antfu/i18n-ally) is recommended to make the better i18n experience.
