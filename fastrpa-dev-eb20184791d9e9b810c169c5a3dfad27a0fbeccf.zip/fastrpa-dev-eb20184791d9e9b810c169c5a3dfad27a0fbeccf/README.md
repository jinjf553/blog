# FastRPA

## RPA 启动器

| BUSI | PATH                          | DESC        | AUTHOR | REMARK                         |
| ---- | ----------------------------- | ----------- | ------ | ------------------------------ |
| HR   | rpa_launcher/frontend/main.py | webview界面 | Mr.He  | RPA 启动器                     |
| HR   | rpa_launcher/backend/main.py  | 后端服务    | Mr.He  | 端口19527                      |
| HR   | rpadash(独立项目)             | web服务     | Mr.He  | 155主机，端口19526，e:/rpadash |
| HR   | HTTP(独立项目)                | HTTP服务    | Mr.He  | 155主机，端口19530，e:/HTTP    |

## RPA 列表

| BUSI | PATH                                  | DESC                            | AUTHOR  | REMARK          |
| ---- | ------------------------------------- | ------------------------------- | ------- | --------------- |
| HR   | rpa/ssc_rpa/hr/rpa_bu_zai_gang        | 不在岗变动                      |         |                 |
| HR   | rpa/ssc_rpa/hr/rpa_chong_xin_lu_yong  | 重新录用                        |         |                 |
| HR   | rpa/ssc_rpa/hr/rpa_er_diao_zhi_diao   | 二级单位间调动 & 直属单位间调动 | Mr.He   |                 |
| HR   | rpa/ssc_rpa/hr/rpa_gang_bian          | 岗位变动                        | Mr.Jin  |                 |
| HR   | rpa/ssc_rpa/hr/rpa_ji_gou_wei_hu      | 非中层组织机构                  | Mr.Yang | 交接 Mr.He 维护 |
| HR   | rpa/ssc_rpa/hr/rpa_jian_gang          | 建岗[新]                        | Mr.He   |                 |
| HR   | rpa/ssc_rpa/hr/rpa_lao_wu_gong        | 劳务工退回                      | Mr.Jin  |                 |
| HR   | rpa/ssc_rpa/hr/rpa_li_gang            | 离岗                            |         |                 |
| HR   | rpa/ssc_rpa/hr/rpa_li_tui_xiu_jian_ce | 离退休减册                      | Mr.Jin  |                 |
| HR   | rpa/ssc_rpa/hr/rpa_li_zhi             | 离职                            | Mr.Jin  |                 |
| HR   | rpa/ssc_rpa/hr/rpa_nei_tui            | 内退                            |         |                 |
| HR   | rpa/ssc_rpa/hr/rpa_ru_zhi             | 入职 & 大学生入职               | Mr.Jin  |                 |

## 实用工具列表

| BUSI | PATH                                             | DESC                                 | AUTHOR   | REMARK                            |
| ---- | ------------------------------------------------ | ------------------------------------ | -------- | --------------------------------- |
| HR   | rpa/ssc_kit/hr/kit_chai_dan                      | 手动拆单 & 自动拆单                  | Mr.Jin   |                                   |
| HR   | rpa/ssc_kit/hr/kit_copy_pa20_to_pa30             | 国家管网复制高管 PA20 信息到 PA30 屏 | Mr.He    |                                   |
| HR   | rpa/ssc_kit/hr/kit_cost_center                   | 成本中心定位                         | Mr.He    |                                   |
| HR   | rpa/ssc_kit/hr/kit_export_103_107                | 组合逻辑查询结果自动导出             | Mr.He    |                                   |
| HR   | rpa/ssc_kit/hr/kit_export_103_t10                | 循环备份103到FTP                     | Mr.He    | 常驻任务 export_103_t10_all()     |
| HR   | rpa/ssc_kit/hr/kit_export_cost_center            | 成本中心信息导出                     | Mr.He    |                                   |
| HR   | rpa/ssc_kit/hr/kit_export_job_info_full          | 机构岗位查询分析全量导出工具         | Mr.He    | 全量导出                          |
| HR   | rpa/ssc_kit/hr/kit_export_job_info_v1            | 机构岗位查询分析\_V1                 | Mr.He    |                                   |
| HR   | rpa/ssc_kit/hr/kit_export_job_info_v2            | 机构岗位查询分析\_V2                 | Mr.He    | 可设置显示深度，v2 是独立版本     |
| HR   | rpa/ssc_kit/hr/kit_export_staff_info             | 员工信息表导出                       | Mr.Jin   | 由 Mr.Yang 开发初版，Mr.Jin 重写  |
| HR   | rpa/ssc_kit/hr/kit_gang_wei_chi                  | 建岗[新]补充维护岗位池               | Mr.He    | 常驻任务 main_4_1_01()            |
| HR   | rpa/ssc_kit/hr/kit_gong_zuo_liang                | 工作量汇总                           | Mr.He    |                                   |
| HR   | rpa/ssc_kit/hr/kit_guo_jia_guan_wang             | 国家管网模板生成(main_20200918.py)   | Mr.He    |                                   |
| HR   | rpa/ssc_kit/hr/kit_nian_jin                      | 年金                                 | Mr.Huang |                                   |
| HR   | rpa/ssc_kit/hr/kit_organization_code_application | MDM机构编码申请                      | Mr.Jin   |                                   |
| HR   | rpa/ssc_kit/hr/kit_pa30                          | 组织分配屏修改                       | Mr.He    | 将全局变量 IGNORE_FLAG 设为 False |
| HR   | rpa/ssc_kit/hr/kit_pa30                          | 组织分配屏修改（忽略原屏修改标识）   | Mr.He    | 将全局变量 IGNORE_FLAG 设为 True  |
| HR   | rpa/ssc_kit/hr/kit_sap_to_dims                   | 自动更新码表库码值                   | Mr.He    |                                   |
| HR   | rpa/ssc_kit/hr/kit_split_file                    | 根据文件 AB 列拆分（保留批注内容）   | Mr.He    |                                   |
| HR   | rpa/ssc_kit/hr/kit_update_dims                   | 码表库更新                           | Mr.He    |                                   |
| HR   | rpa/ssc_kit/hr/kit_update_org_name               | 单位简化全称修改                     | Mr.He    |                                   |
| HR   | rpa/ssc_kit/hr/kit_upload_files_to_ftp           | 上传模板到 ftp                       | Mr.Jin   |                                   |
| HR   | rpa/ssc_kit/hr/kit_whole_process_tracking        | 全流程跟踪                           | Mr.Jin   |                                   |
| HR   | rpa/ssc_kit/hr/kit_xlsx_cell_rstrip              | 清除 Excel 活动页所有单元格末尾空白  | Mr.He    |                                   |

## 常驻任务

在`VSCode`中打开`PATH`路径下的`main.py`，执行启动常驻任务

| BUSI | PATH                              | DESC                            | AUTHOR | REMARK                        |
| ---- | --------------------------------- | ------------------------------- | ------ | ----------------------------- |
| HR   | rpa/ssc_kit/hr/kit_export_103_t10 | (249主机)循环备份103到FTP       | Mr.He  | 常驻任务 export_103_t10_all() |
| HR   | rpa/ssc_kit/hr/kit_gang_wei_chi   | (159主机)建岗[新]补充维护岗位池 | Mr.He  | 常驻任务 main_4_1_01()        |

## 运行环境

`FastRPA`采用`Python3`自带的`venv`虚拟环境，你可以使用`cmd`或`Powershell`创建虚拟环境，其中`Powershell`默认需要额外配置操作。

### 下载地址

- [Python 3.8.9 (x64)](https://npm.taobao.org/mirrors/python/3.8.9/python-3.8.9-amd64.exe)
- [Git 2.31.1 (x64)](https://npm.taobao.org/mirrors/git-for-windows/v2.31.1.windows.1/Git-2.31.1-64-bit.exe)

### Git初次使用请先配置用户名和密码，推荐英文名和真实邮箱

```powershell
git config --global user.name "your name"
git config --global user.email "your email"
```

### 解决`Powershell`执行策略问题

在`windows`上，如果是 powershell，会遇到执行策略问题，可以用管理员权限打开配置，解决`vscode`的`因为在此系统上禁止运行脚本`问题。

```powershell
set-ExecutionPolicy RemoteSigned
Set-ExecutionPolicy -ExecutionPolicy RemoteSigned
```

### 创建虚拟环境，并安装依赖模块

```powershell
mkdir -p d:/rpa/venv
cd d:/rpa/venv
python -m venv fastrpa
.\fastrpa\Scripts\Activate.ps1
python -m pip config set global.index-url https://mirrors.aliyun.com/pypi/simple/ # 配置阿里源
python -m pip install --upgrade pip # 更新pip
python -m pip install -i http://mirrors.aliyun.com/pypi/simple/ --trusted-host mirrors.aliyun.com -r requirements.txt
```

注意：`pyinstaller`不支持下载离线安装包，从本地进行安装，已从`requirements_dev.txt`中移除，如有必要，请手工安装。

### 部署时可以先下载离线安装包，再进行静默安装

下载`pip`包

```powershell
python -m pip download -i http://mirrors.aliyun.com/pypi/simple/ --trusted-host mirrors.aliyun.com -r requirements.txt -d d:/rpa/安装包/pip
```

从本地安装`pip`包

```powershell
python -m pip install -r requirements.txt --no-index --find-links file:///d:/rpa/安装包/pip
```

## 更新`requirements_dev.txt`

```powershell
python -m pip install pur
pur -r .\requirements_dev.txt
```

## freeze `requirements_dev.txt`

```powershell
d:/rpa/venv/fastrpa/Scripts/activate.ps1
d:/rpa/venv/fastrpa/Scripts/python.exe -m pip freeze > requirements_utf16.txt # 需要转为UTF8编码并写入requirements.txt
```

## requirements.txt 已知问题

- py7zr依赖pycryptodome，但是pycryptodome最新版本有问题，需要安装3.9.9版本
- freeze时，不会生成pip的版本信息，需要手工加到requirements.txt中

## VSCode Notebook 无法导入项目虚拟环境安装的Python包时

```powershell
pip uninstall ipykernel
pip install ipykernel ipython --user
ipython kernel install --user --name=fastrpa  # 新建名为fastrpa的kernel（注意要在激活的虚拟环境中执行）
```

通常是由于`Notebook`没有从虚拟环境启动，在`Notebook`中按下`Ctrl+Shift+P`

输入`Jupyter: Select Interpreter to start Jupyter Server`，回车后选择`fastrpa`即可

## 打包发布流程

打包脚本：fastrpa根目录build.py (可以按Ctrl+E，输入build.py)
1、执行build.py
2、输入打包密钥：jS3E3VmeLeN55Eic
3、打包完成，在powershell中执行 $env:PYZ_FILE="d:/rpa/venv/fastrpa/rpa.pyz";$env:KEY="b'alMzRTNWbWVMZU41NUVpYw==\n'";python -m sitecustomize 测试程序是否可以启动
4、如正常启动，复制 D:\rpa\venv\fastrpa\rpa.pyz、D:\rpa\venv\fastrpa\rpa.pyz.version 到 155 服务器 E:\HTTP\fastrpa 目录下（覆盖前必须先备份155两个文件，如有问题，可再恢复回来）
5、重新打开RPA启动器，测试155服务器更新后，RPA是否正常
