"""虚拟环境: cd rpa_shell
            python -m venv x:/rpa/venv/rpa_shell
            x:/rpa/venv/rpa_shell/Scripts/Activate.ps1
   安装依赖: python -m pip config set global.index-url https://mirrors.aliyun.com/pypi/simple/
            python -m pip install pywin32==300 requests==2.25.1
            python -m pip install wheel pyinstaller[encryption] -U
   打包语句: pyinstaller ./main.py --uac-admin --clean --key=PBmmQGUYL3xF4kbD --noupx -F -w -i ./images/icons/256.ico -n rpa_shell --add-binary='./third_party;./third_party' --add-binary='./images;./images'
   -----------------------
   如果打包后程序启动错误，用以下命令重新打包，并在控制台执行打包后程序，查看异常原因
            pyinstaller ./main.py --uac-admin --clean --key=PBmmQGUYL3xF4kbD --noupx -F -c -i ./images/icons/256.ico -n rpa_shell --add-binary='./third_party;./third_party' --add-binary='./images;./images'
   如果显示win32gui导入错误，尝试重新安装pyinstaller
   -----------------------
   参考文档:
            Git安装器命令行参数: https://jrsoftware.org/ishelp/index.php?topic=setupcmdline
            Python安装器命令行参数: https://docs.python.org/3/using/windows.html
   离线安装:
            .NET 4.8     : https://dotnet.microsoft.com/download/dotnet-framework/net48                           (Webview2依赖)
            Git          : https://npm.taobao.org/mirrors/git-for-windows/v2.31.1.windows.1/Git-2.31.1-64-bit.exe (不通过Git分发代码，已弃用)
            MS Edge      : https://www.microsoft.com/zh-cn/edge                                                   (不通过Edge Chromium作为界面，已弃用)
            Python 3.8.9 : https://npm.taobao.org/mirrors/python/3.8.9/python-3.8.9-amd64.exe                     ()
            Webview 2    : https://developer.microsoft.com/zh-cn/microsoft-edge/webview2/#download-section        (pywebview chromium依赖)
"""
import datetime
import getpass
import logging
import os
import re
import shutil
import stat
import subprocess  # nosec
import sys
import traceback
import urllib.request
import winreg
from pathlib import Path
from threading import Thread
from time import sleep
from tkinter import messagebox
from typing import Dict, List, Optional, Union

import chardet  # type: ignore
import requests
import win32api
import win32con
import win32file
import win32gui

from ui import dialog, tree  # type: ignore

RPA_SHELL_VERSION = '2021-07-05 17:00:00'  # 【每次重新打包需更新此版本】
RPA_SHELL_TITLE = f'RPA启动（{RPA_SHELL_VERSION}）'  # 【每次重新打包需更新此版本】

URL_BASE = 'http://10.133.10.155:19530'
URL_REQUIREMENTS_TXT = f'{URL_BASE}/fastrpa/requirements.txt'
URL_RESOURCES_PYZ = f'{URL_BASE}/fastrpa/resources.pyz'
URL_RESOURCES_PYZ_VERSION = f'{URL_BASE}/fastrpa/resources.pyz.version'
URL_RPA_SEHLL_EXE = f'{URL_BASE}/fastrpa/rpa_shell.exe'
URL_RPA_SEHLL_EXE_VERSION = f'{URL_BASE}/fastrpa/rpa_shell.exe.version'
URL_SITECUSTOMIZE_PY = f'{URL_BASE}/fastrpa/sitecustomize.py'
URL_RPA_PYZ = f'{URL_BASE}/fastrpa/rpa.pyz'
URL_RPA_PYZ_VERSION = f'{URL_BASE}/fastrpa/rpa.pyz.version'

D_RPA = 'd:/rpa'
for i in range(100, 123):  # d-z
    if win32file.GetDriveType(f'{chr(i)}:') == 3:  # 本地磁盘或闪存
        D_RPA = f'{chr(i)}:/rpa'
        break
else:
    D_RPA = 'c:/rpa'
KEY = str(b'alMzRTNWbWVMZU41NUVpYw==\n')
FASTRPA_DIR = f'{D_RPA}/fastrpa'
LOG_DIR = f'{D_RPA}/logs'
PIP_DIR = f'{D_RPA}/安装包/pip'
PYTHON_INSTALL_DIR = f'{D_RPA}/Python/Python38'
RPA_TEMP_DIR = f'{D_RPA}/temp'
SETUP_DIR = f'{D_RPA}/安装包'
VIRTUAL_ENV_DIR = f'{D_RPA}/venv/fastrpa'
PIP_URL = Path(PIP_DIR).as_uri()  # f'file:///{PIP_DIR}'
SITECUSTOMIZE_PY = f'{VIRTUAL_ENV_DIR}/sitecustomize.py'
RPA_SHELL_DIR = getattr(sys, '_MEIPASS') if hasattr(sys, '_MEIPASS') is True else Path(__file__).parent.as_posix()  # pylint: disable=fixme, no-member  # 代码根目录
IS_PYINSTALLER_EXE = hasattr(sys, '_MEIPASS')  # 是否是EXE打包后程序


def config(filename: Optional[str] = None) -> None:
    logging.getLogger().handlers = []
    if float(sys.version[:3]) >= 3.8:
        logging.basicConfig(level=logging.INFO,
                            format=r'[%(asctime)s]%(threadName)s  %(lineno)4d %(filename)-13s %(levelname)-5s %(message)s',
                            datefmt=r'%Y-%m-%d %H:%M:%S',
                            force=True)
    else:
        logging.basicConfig(level=logging.INFO,
                            format=r'[%(asctime)s]%(threadName)s  %(lineno)4d %(filename)-13s %(levelname)-5s %(message)s',
                            datefmt=r'%Y-%m-%d %H:%M:%S')
    if filename is not None:
        if Path(filename).is_absolute() is True and str(filename).lower().endswith('.log') is False:
            raise Exception('日志文件必须以.log为扩展名')
        if Path(filename).is_absolute() is False:
            yyyymm = datetime.datetime.now().strftime(r'%Y%m')
            yyyymmdd = datetime.datetime.now().strftime(r'%Y%m%d')
            hhmmss = datetime.datetime.now().strftime(r'%H%M%S')
            if filename[-5:].lower() == '.xlsx':
                filename = filename[:-5] + '.log'
            elif filename[-4:].lower() != '.log':
                filename = filename + '.log'
            filename = Path(f'{D_RPA}/logs/{yyyymm}/{yyyymmdd}').joinpath(hhmmss + '_' + filename).as_posix()
        Path(filename).parent.mkdir(parents=True, exist_ok=True)
        file_handler = logging.FileHandler(filename=filename, encoding='utf-8')
        file_handler.setLevel(logging.INFO)
        formatter = logging.Formatter(r'[%(asctime)s] %(threadName)s %(lineno)4d %(filename)-13s %(levelname)-5s %(message)s', r'%Y-%m-%d %H:%M:%S')
        file_handler.setFormatter(formatter)
        logging.getLogger().addHandler(file_handler)


def logargs(*args):
    """遍历入参并打印"""
    for i, arg in enumerate(args):
        s = str(arg)[:100]
        if len(s) == 100:
            logging.info(f"==>参数{1+i}: {s+'...'}")
        else:
            logging.info(f"==>参数{1+i}: {s}")


def logfn2(fn):
    """为函数添加日志，正常执行时，打印执行时长，错误时打印传参及异常原因。"""
    def foo(*args):
        try:
            logging.info(f'函数{fn.__name__}开始执行')
            begintime = datetime.datetime.now()
            logargs(*args)
            result = fn(*args)
            endtime = datetime.datetime.now()
            dur = endtime - begintime
            logging.info(
                f'函数{fn.__name__}正常退出，执行时长: {dur.seconds}秒')
            return result
        except Exception as e:
            logging.error('===============================================')
            logging.error(f"函数{fn.__name__}执行异常")
            logargs(*args)
            logging.error(f"功能描述: {fn.__doc__}")
            logging.error(f'{e}')
            logging.error(f"异常原因: {traceback.format_exc()}")
            logging.error('===============================================')
        return False
    return foo


@logfn2
def gentempdir() -> str:
    yyyymm = datetime.datetime.now().strftime(r'%Y%m')
    yyyymmdd = datetime.datetime.now().strftime(r'%Y%m%d')
    hhmmss = datetime.datetime.now().strftime(r'%H%M%S')
    p = Path(RPA_TEMP_DIR).joinpath(yyyymm).joinpath(yyyymmdd).joinpath(hhmmss)
    p.mkdir(parents=True, exist_ok=True)
    return p.as_posix()


@logfn2
def peek_bytes_encoding(_bytes: bytes) -> str:
    """检测字节编码"""
    info: Dict[str, str] = chardet.detect(_bytes)
    if 'encoding' in info.keys():
        for encoding in [info['encoding'], 'ansi', 'gbk', 'gb2312', 'utf-8']:
            try:
                _bytes.decode(encoding)
                return encoding
            except Exception:  # nosec
                continue
    return 'ansi'


@logfn2
def peek_file_encoding(filename: str) -> str:
    """检测文本文件字符编码"""
    return peek_bytes_encoding(Path(filename).read_bytes())


@logfn2
def quit_360():  # 需要admin权限
    while True:
        try:
            hwnd_list: Dict[int, str] = {}
            win32gui.EnumWindows(lambda _hwnd, param: param.update({_hwnd: win32gui.GetWindowText(_hwnd)}), hwnd_list)
            for hwnd, all_title in hwnd_list.items():
                if "360天擎" in all_title or "Q360NetmonWnd" in all_title:
                    win32gui.PostMessage(hwnd, win32con.WM_QUIT, 0, 0)
        except Exception:  # nosec
            pass
        sleep(1)


@logfn2
def force_rm(filename: str) -> bool:
    """删除文件或目录
      （shutil.rmtree删除非只读文件报错，不能删除文件，os.remove只能删除文件，这里抽象下，能删除各种类型的文件）
    """
    is_delete_succ = True

    def _readonly_handler(func, path, execinfo) -> bool:
        try:
            os.chmod(path, stat.S_IWRITE)
            os.remove(path)
        except Exception:
            logging.error(path)
            is_delete_succ = False
            return is_delete_succ
        return True
    _f = Path(filename)
    try:
        if _f.exists():
            if _f.is_absolute():
                if _f.is_dir():
                    shutil.rmtree(Path(filename), onerror=_readonly_handler)
                    return is_delete_succ
                else:
                    os.chmod(filename, stat.S_IWRITE)
                    os.remove(filename)
            else:
                return False
        return True
    except Exception as e:
        logging.error(f'{e}: {traceback.format_exc()}')
        return False


@logfn2
def download_file(uri: str, local: str):
    urllib.request.urlretrieve(uri, local)  # nosec


def create_env(env: Dict[str, str] = {}):
    """创建新的虚拟环境"""
    new_env = os.environ.copy()
    new_env.update(env)
    return new_env


def run_cmd(cmd_line: str, cwd: Optional[str] = None, collect_output=True, wait_for_end=True, env: Dict[str, str] = {}, islog=False) -> Union[int, str, subprocess.Popen]:
    """执行cmd命令

    Args:
        cmd_line (str): 命令行参数
        cwd (Optional[str], optional): 执行目录，默认为x:/rpa/temp
        collect_output (bool, optional): 是否收集控制台输出结果
        wait_for_end (bool, optional): 是否等待结束

    Raises:
        Exception: cwd路径不存在时，报错

    Returns:
        Union[int, str, subprocess.Popen]: collect_output=True wait_for_end=True时返回str类型
                                           collect_output=False wait_for_end=True时返回int类型
                                           collect_output=False wait_for_end=False时返回subprocess.Popen类型
    """
    if cwd is None:
        cwd = f'{D_RPA}/temp'
        Path(cwd).mkdir(parents=True, exist_ok=True)
    elif Path(cwd).exists() is False:
        raise Exception(f'{cwd}不存在')
    merged_env = create_env(env)
    if collect_output is True:
        p = subprocess.Popen(cmd_line, cwd=cwd, env=merged_env, shell=True, start_new_session=True, stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=subprocess.PIPE)  # nosec
        if p.stdout is not None:
            _bytes = p.stdout.read()
            _encoding = peek_bytes_encoding(_bytes)
            stdout_str = _bytes.decode(_encoding)
        else:
            stdout_str = ''
        if islog:
            logging.info(stdout_str)
        return stdout_str
    elif wait_for_end is True:
        p = subprocess.Popen(cmd_line, cwd=cwd, env=merged_env)  # nosec
        p.communicate()
        if islog:
            logging.info(p.returncode)
        return p.returncode
    else:
        p = subprocess.Popen(cmd_line, cwd=cwd, env=merged_env, shell=True, start_new_session=True, stdout=None, stderr=None)  # nosec
        return p


@logfn2
def disable_uac():
    """关闭UAC账户控制"""
    run_cmd(r'reg.exe add HKLM\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\System /v EnableLUA /t REG_DWORD /d 0 /f')


@logfn2
def write_rpa_shell_exe_path_to_reg():
    winreg.CreateKey(winreg.HKEY_LOCAL_MACHINE, r'SOFTWARE\FASTRPA\RPA_SHELL')  # 为避免key不存在打开时报错，要先创建
    with winreg.OpenKey(winreg.HKEY_LOCAL_MACHINE, r'SOFTWARE\FASTRPA\RPA_SHELL', 0, winreg.KEY_SET_VALUE) as key:
        if hasattr(sys, '_MEIPASS') is True:
            winreg.SetValueEx(key, 'RPA_SHELL_PATH', 1, winreg.REG_SZ, sys.executable)
            winreg.SetValueEx(key, 'RPA_SHELL_VERSION', 1, winreg.REG_SZ, RPA_SHELL_VERSION)
            winreg.SetValueEx(key, 'DefaultUserName', 1, winreg.REG_SZ, getpass.getuser())  # 默认用户名


@logfn2
def get_rpa_shell_version() -> str:
    try:
        res = requests.get(URL_RPA_SEHLL_EXE_VERSION)
        if res.status_code == 200:
            rpa_shell_version = res.content.decode('utf-8')
        else:
            logging.error('未检测到RPA_SHELL版本文件，无法更新')
            rpa_shell_version = RPA_SHELL_VERSION
        return rpa_shell_version
    except Exception as e:
        logging.error(f'{e}: {traceback.format_exc()}')
        return RPA_SHELL_VERSION


@logfn2
def download_rpa_shell() -> str:
    temp_dir = gentempdir()
    try:
        res = requests.get(URL_RPA_SEHLL_EXE)
        if res.status_code == 200:
            Path(temp_dir).joinpath('rpa_shell.exe').write_bytes(res.content)
        else:
            raise Exception(res.status_code)
    except Exception as e:
        messagebox.showerror(f'错误信息: {e}', traceback.format_exc() + '\n下载最新RPA启动器失败')
        raise e
    return Path(temp_dir).joinpath('rpa_shell.exe').as_posix()


@logfn2
def chk_rpa_shell_update():
    logging.info('检测RPA_SHELL更新')
    if IS_PYINSTALLER_EXE is False or sys.executable.lower().endswith('python.exe'):  # 如果不处于开发模式下
        logging.info('非PYINSTALLER打包方式执行，不需要更新')
        return
    elif len(sys.argv) >= 2 and Path(sys.argv[-1]).exists() and Path(sys.argv[-1]).name.lower().endswith('.exe'):
        logging.info(f'已下载更新后RPA_SHELL，使用新版{sys.executable}覆盖旧版{ sys.argv[-1]}')
        sleep(3)
        shutil.copyfile(sys.executable, sys.argv[-1])
        return
    elif RPA_SHELL_VERSION == get_rpa_shell_version():  # 无更新
        logging.info('已是最新版本，不需要更新')
        write_rpa_shell_exe_path_to_reg()
        return
    else:
        logging.info('下载RPA_SHELL更新')
        rpa_shell_exe = download_rpa_shell()  # 下载并运行更新，当前程序退出
        logging.info(f'下载后文件名: {rpa_shell_exe}')
        win32api.ShellExecute(0, 'open', rpa_shell_exe, f' "{sys.executable}"', '', 1)
        dialog.quit()


@logfn2
def chk_volume_d_exists():
    tree.selection_set('chk_volume_d_exists')
    if Path(Path(D_RPA).drive).exists() is True:
        tree.set('chk_volume_d_exists', 'info', '存在')
        try:
            for path in [SETUP_DIR, PIP_DIR, LOG_DIR]:
                Path(path).mkdir(parents=True, exist_ok=True)
        except Exception as e:
            messagebox.showerror(f'错误信息: {e}', traceback.format_exc() + '\n创建RPA运行目录失败，请检查D盘是否写保护')
            tree.insert('chk_volume_d_exists', 'end', 'create_rpa_dir', text='创建RPA运行目录', values=('创建RPA运行目录失败，请检查D盘是否写保护', '未通过'))
            tree.set('chk_volume_d_exists', 'result', '未通过')
            raise e
        tree.insert('chk_volume_d_exists', 'end', 'create_rpa_dir', text='创建RPA运行目录', values=('创建完毕', '通过'))
        tree.selection_set('create_rpa_dir')
        tree.set('chk_volume_d_exists', 'result', '通过')
    else:
        messagebox.showerror('错误信息', 'D盘不存在，请检查驱动器盘符是否正确！')
        raise FileNotFoundError('D盘不存在，请检查驱动器盘符是否正确！')


@logfn2
def is_webview2_installed() -> bool:
    reg_key = None
    try:
        # runtime
        reg_key = winreg.OpenKey(winreg.HKEY_LOCAL_MACHINE,
                                 r'SOFTWARE\WOW6432Node\Microsoft\EdgeUpdate\Clients\{F3017226-FE2A-4295-8BDF-00C3A9A7E4C5}')
        build, _ = winreg.QueryValueEx(reg_key, 'pv')
        build = int(build.replace('.', '')[:6])
        return build >= 860622  # Webview2 86.0.622.0
    except Exception:  # nosec
        return False
    finally:
        if reg_key:
            winreg.CloseKey(reg_key)


@logfn2
def install_msedge_webview2():
    logging.info('正在安装Edge Webview2')
    edge_webview2_installer = Path(RPA_SHELL_DIR).joinpath('third_party/MicrosoftEdgeWebview2Setup.exe').as_posix()
    run_cmd(edge_webview2_installer, collect_output=False)


@logfn2
def chk_msedge_webview2_installed():
    tree.selection_set('chk_msedge_webview2_installed')
    if is_webview2_installed() is False:
        tree.insert('chk_msedge_webview2_installed', 'end', 'install_msedge_webview2', text='安装Edge Webview2', values=('安装中，请稍等……'))
        tree.selection_set('install_msedge_webview2')
        install_msedge_webview2()
        if is_webview2_installed() is False:
            tree.set('install_msedge_webview2', 'info', '安装不成功')
            tree.set('install_msedge_webview2', 'result', '未通过')
            tree.set('chk_msedge_webview2_installed', 'info', 'Edge Webview2安装不成功')
            tree.set('chk_msedge_webview2_installed', 'result', '未通过')
            return
        tree.set('install_msedge_webview2', 'info', '安装完毕')
        tree.set('install_msedge_webview2', 'result', '通过')
    tree.set('chk_msedge_webview2_installed', 'info', 'Edge Webview2已安装')
    tree.set('chk_msedge_webview2_installed', 'result', '通过')


@logfn2
def is_dot_net_framework_48_installed() -> bool:
    """检查.net framework 4.8 及以上版本是否安装"""
    reg_key = None
    try:
        reg_key = winreg.OpenKey(winreg.HKEY_LOCAL_MACHINE, r'SOFTWARE\Microsoft\NET Framework Setup\NDP\v4\Full')
        version, _ = winreg.QueryValueEx(reg_key, 'Version')
        return version >= '4.6'   # .NET Framework 4.8
    except Exception as e:
        logging.error(e)
        logging.error(traceback.format_exc())
        return False
    finally:
        if reg_key:
            winreg.CloseKey(reg_key)


@logfn2
def install_dot_net_framework_48():
    dot_net_framework_installer = Path(RPA_SHELL_DIR).joinpath('third_party/ndp48-web.exe').as_posix()
    run_cmd(dot_net_framework_installer, collect_output=False)


@logfn2
def chk_dot_net_framework_ready():
    tree.selection_set('chk_dot_net_framework_ready')
    if is_dot_net_framework_48_installed() is False:
        tree.set('chk_dot_net_framework_ready', 'info', '.NET Framework 4.8 安装中……')
        install_dot_net_framework_48()
        if is_dot_net_framework_48_installed() is False:  # 安装不成功
            tree.set('chk_dot_net_framework_ready', 'info', '.NET Framework 4.8 安装失败')
            tree.set('chk_dot_net_framework_ready', 'result', '未通过')
            return
    tree.set('chk_dot_net_framework_ready', 'info', '.NET Framework已安装')
    tree.set('chk_dot_net_framework_ready', 'result', '通过')


@logfn2
def chk_python_389_installer_exists():
    tree.selection_set('chk_python_389_installer_exists')
    if Path(f'{SETUP_DIR}/python-3.8.9-amd64.exe').exists() is True and Path(f'{SETUP_DIR}/python-3.8.9-amd64.exe').stat().st_size != 28242504:
        logging.info(f'{SETUP_DIR}/python-3.8.9-amd64.exe文件不完整，重新下载')
        tree.set('chk_python_389_installer_exists', 'info', f'{SETUP_DIR}/python-3.8.9-amd64.exe文件不完整，重新下载')
        os.remove(Path(f'{SETUP_DIR}/python-3.8.9-amd64.exe').as_posix())
    if Path(f'{SETUP_DIR}/python-3.8.9-amd64.exe').exists() is False:
        logging.info(f'{SETUP_DIR}/python-3.8.9-amd64.exe不存在，正在重新下载')
        tree.set('chk_python_389_installer_exists', 'info', f'{SETUP_DIR}/python-3.8.9-amd64.exe不存在，正在重新下载')
        tree.insert('chk_python_389_installer_exists', 'end', 'download_python_389_installer', text='下载Python3.8.9安装包', values=('下载中，请稍等……'))
        tree.selection_set('download_python_389_installer')
        try:
            download_file(r'http://npm.taobao.org/mirrors/python/3.8.9/python-3.8.9-amd64.exe', f'{SETUP_DIR}/python-3.8.9-amd64.exe')
        except Exception as e:
            logging.error('下载Python3.8.9安装包失败，请检查网络连接')
            messagebox.showerror(f'错误信息: {e}', traceback.format_exc() + '\n下载Python3.8.9安装包失败，请检查网络连接')
            tree.set('download_python_389_installer', 'info', '下载失败')
            tree.set('download_python_389_installer', 'result', '未通过')
            tree.set('chk_python_389_installer_exists', 'result', '未通过')
            raise e
        tree.set('download_python_389_installer', 'info', '下载成功')
        tree.set('download_python_389_installer', 'result', '通过')
    tree.set('chk_python_389_installer_exists', 'info', f'{SETUP_DIR}/python-3.8.9-amd64.exe存在')
    tree.set('chk_python_389_installer_exists', 'result', '通过')


@logfn2
def install_python():
    logging.info('安装Python')
    force_rm(PYTHON_INSTALL_DIR)
    python_install_dir = os.path.realpath(PYTHON_INSTALL_DIR)  # TargetDir 只支持 Windows 路径格式
    run_cmd(f'{SETUP_DIR}/python-3.8.9-amd64.exe /passive Include_launcher=0 InstallAllUsers=1 TargetDir="{python_install_dir}" PrependPath=1', collect_output=False)
    if Path(f'{PYTHON_INSTALL_DIR}/python.exe').exists() and Path(f'{PYTHON_INSTALL_DIR}/pythonw.exe').exists():
        logging.info('Python安装成功')
    else:
        logging.error('Python安装失败')


@logfn2
def uninstall_python():
    logging.info('卸载Python')
    run_cmd(f'{SETUP_DIR}/python-3.8.9-amd64.exe /passive /uninstall', collect_output=False)


@logfn2
def chk_python_installed():
    tree.selection_set('chk_python_installed')
    if shutil.which('python') is not None and shutil.which('pythonw') is not None:
        if Path(f'{PYTHON_INSTALL_DIR}/python.exe').exists() is False:
            logging.info('Python未安装到指定位置，卸载后重新安装')
            uninstall_python()
            install_python()
        elif 'Python 3.8.9' not in run_cmd(f'{PYTHON_INSTALL_DIR}/python.exe --version', PYTHON_INSTALL_DIR):
            logging.info('Python不是指定版本，卸载后重新安装')
            uninstall_python()
            install_python()
        tree.set('chk_python_installed', 'info', 'Python已安装')
    elif Path(f'{PYTHON_INSTALL_DIR}/python.exe').exists() is False or Path(f'{PYTHON_INSTALL_DIR}/pythonw.exe').exists() is False:
        logging.info('系统中未检测到Python，正在安装')
        uninstall_python()
        install_python()
    if Path(f'{PYTHON_INSTALL_DIR}/python.exe').exists() is True:
        if 'Python 3.8.9' in run_cmd(f'{PYTHON_INSTALL_DIR}/python.exe --version', PYTHON_INSTALL_DIR):
            tree.set('chk_python_installed', 'result', '通过')
            return
    tree.set('chk_python_installed', 'result', '未通过')


@logfn2
def create_python_venv():
    logging.info('正在创建虚拟环境')
    if Path(f'{PYTHON_INSTALL_DIR}/python.exe').exists():
        run_cmd(f'{PYTHON_INSTALL_DIR}/python.exe -m venv {VIRTUAL_ENV_DIR}', collect_output=False)
    else:
        logging.error(f'{PYTHON_INSTALL_DIR}/python.exe不存在，请确认Python是否正确安装')


@logfn2
def chk_venv_exists():
    tree.selection_set('chk_venv_exists')
    if Path(VIRTUAL_ENV_DIR).exists() is False:
        tree.set('chk_venv_exists', 'info', '正在创建虚拟环境……')
        create_python_venv()
    is_venv_broken = False
    if Path(VIRTUAL_ENV_DIR).joinpath('Scripts/python.exe').exists() is False or Path(VIRTUAL_ENV_DIR).joinpath('Scripts/pythonw.exe').exists() is False:
        is_venv_broken = True
    if Path(VIRTUAL_ENV_DIR).joinpath('pyvenv.cfg').exists() is False:
        is_venv_broken = True
    else:
        try:
            pyvenv_cfg = Path(VIRTUAL_ENV_DIR).joinpath('pyvenv.cfg')
            pyvenv_cfg_encoding = peek_file_encoding(pyvenv_cfg.as_posix())
            pyvenv_cfg_str = pyvenv_cfg.read_text(encoding=pyvenv_cfg_encoding)
            match = re.findall(r'(?:version\s*=\s*)(.*)', pyvenv_cfg_str)
            if len(match) > 0:
                python_version = match[0]
                if python_version != '3.8.9':
                    logging.error('虚拟环境Python不是指定版本')
                    is_venv_broken = True
            match = re.findall(r'(?:home\s*=\s*)(.*)', pyvenv_cfg_str)
            if len(match) > 0:
                pyvenv_cfg_str = pyvenv_cfg_str.replace(match[0], os.path.realpath(PYTHON_INSTALL_DIR))
                pyvenv_cfg.write_text(pyvenv_cfg_str, encoding='utf-8')  # 系统重装用户目录改变，需更新python路径
            else:
                logging.error('虚拟环境pyvenv.cfg指向的python不存在')
                is_venv_broken = True
        except Exception:
            is_venv_broken = True
    if is_venv_broken is True:
        logging.info('虚拟环境存在问题，删除虚拟环境')
        try:
            if force_rm(VIRTUAL_ENV_DIR) is True:
                create_python_venv()
                tree.set('chk_venv_exists', 'info', '虚拟环境已创建')
                tree.set('chk_venv_exists', 'result', '通过')
            else:
                tree.set('chk_venv_exists', 'info', '虚拟环境创建失败')
                tree.set('chk_venv_exists', 'result', '未通过')
                raise Exception(f'虚拟环境{VIRTUAL_ENV_DIR}删除失败')
        except Exception as e:
            logging.error(e)
            logging.error(traceback.format_exc())
    else:
        if Path(VIRTUAL_ENV_DIR).joinpath('Scripts/python.exe').exists():
            tree.set('chk_venv_exists', 'info', '虚拟环境已创建')
            tree.set('chk_venv_exists', 'result', '通过')
        else:
            tree.set('chk_venv_exists', 'info', '虚拟环境创建失败')
            tree.set('chk_venv_exists', 'result', '未通过')


@logfn2
def chk_windows_firewall():
    tree.selection_set('chk_windows_firewall')
    # 需要以管理员权限执行
    try:
        run_cmd('powershell -command "Set-ExecutionPolicy RemoteSigned -Force"')  # 启用powershell脚本
        run_cmd('powershell -command "Set-ExecutionPolicy -ExecutionPolicy RemoteSigned -Force"')  # 回退 set-executionpolicy Undefined
        rules_str = run_cmd('netsh advfirewall firewall show rule name=all | findstr /i "python"')
        rules = [rule.split(':') for rule in rules_str.splitlines()]
        rule_names = set([rule[1].strip() for rule in rules if len(rule) == 2])
        for rule_name in rule_names:  # 遍历所有名称中包含python的防火墙规则，全部启用，并允许通过
            logging.info(f'启用防火墙规则{rule_name}，设置允许使用公用网络')
            run_cmd(f'netsh advfirewall firewall set rule name={rule_name} new action=allow')
            run_cmd(f'netsh advfirewall firewall set rule name={rule_name} new enable=yes')
    except Exception as e:
        logging.error(e)
        logging.error(traceback.format_exc())
        messagebox.showerror('错误信息: 系统安全设置禁止执行powershell命令', '\n请以管理员身份打开PowerShell，并执行以下命令（已复制到剪切板）: ' +
                             '\nSet-ExecutionPolicy RemoteSigned' +
                             '\nSet-ExecutionPolicy -ExecutionPolicy RemoteSigned')
        tree.set('chk_windows_firewall', 'info', '入站规则屏蔽Python，RPA无法访问网络')
        tree.set('chk_windows_firewall', 'result', '未通过')
        raise Exception('Windows防火墙屏蔽Python，RPA无法访网络')
    tree.set('chk_windows_firewall', 'info', '入站规则未屏蔽Python')
    tree.set('chk_windows_firewall', 'result', '通过')


@logfn2
def is_deps_match():
    tree.set('chk_deps_installed', 'info', '检测虚拟环境已安装包')
    pip_installed_list: List[str] = []  # 虚拟环境PIP安装哪些包 [package-name: package-version]
    pip_list_str = run_cmd(f'{VIRTUAL_ENV_DIR}/Scripts/python.exe -m pip list --disable-pip-version-check', VIRTUAL_ENV_DIR)
    for line in pip_list_str.splitlines():
        match = re.match(r'([\]\[\w-]+)\s*([0-9.]+)\s*', line)
        if match is not None:
            package_name = match.group(1).lower().replace('-', '_')
            package_version = match.group(2)
            pip_installed_list.append(package_name + '==' + package_version)
    tree.set('chk_deps_installed', 'info', '检测requirements.txt包名称')
    requirements_txt = Path(VIRTUAL_ENV_DIR).joinpath('requirements.txt').as_posix()
    requirements_txt_str = Path(requirements_txt).read_text(encoding='utf-8')
    requirements_list: List[str] = []  # requirements.txt中的包 [package-name==package-version]
    for line in requirements_txt_str.splitlines():
        match = re.match(r'([\w-]+)[\]\[\w-]*\s*==\s*([0-9.]+)', line)
        if match is not None:
            package_name = match.group(1).lower().replace('-', '_')
            package_version = match.group(2)
            requirements_list.append(package_name + '==' + package_version)
    pip_download_list: List[str] = []  # 虚拟环境PIP安装哪些包 [package-name: package-version]
    tree.set('chk_deps_installed', 'info', '检测本地pip安装包完整性')
    for file in Path(PIP_DIR).rglob('*'):
        if file.is_dir() is False:
            match = re.match(r'([\]\[\w-]+)-([0-9.]+)', file.name)
            if match is not None:
                package_name = match.group(1).lower().replace('-', '_')
                package_version = match.group(2).strip('.')
                pip_download_list.append(package_name + '==' + package_version)
    # requirements.txt中的包是否都在x:/rpa/安装包/pip中下载
    is_package_downloaded = all([package in pip_download_list for package in requirements_list]) is True
    # requirements.txt中的包是否都在虚拟环境中已安装且版本匹配
    is_package_installed = all([package in pip_installed_list for package in requirements_list]) is True
    return is_package_downloaded, is_package_installed


@logfn2
def download_pip_packages():
    run_cmd('python -m pip config set global.index-url https://mirrors.aliyun.com/pypi/simple/')
    run_cmd(f'{VIRTUAL_ENV_DIR}/Scripts/python -m pip download' +
            f' --disable-pip-version-check --cache-dir {SETUP_DIR}/pip_cache' +
            f' -r {VIRTUAL_ENV_DIR}/requirements.txt -d {SETUP_DIR}/pip', collect_output=False)


@logfn2
def install_pip_packages():
    logging.info('正在安装pip包')
    run_cmd(f'{VIRTUAL_ENV_DIR}/Scripts/python -m pip install -r {VIRTUAL_ENV_DIR}/requirements.txt --no-index --find-links {PIP_URL}', collect_output=False)


@logfn2
def chk_deps_installed():
    tree.selection_set('chk_deps_installed')
    is_package_downloaded, is_package_installed = is_deps_match()
    if is_package_downloaded is False:
        tree.insert('chk_deps_installed', 'end', 'download_deps', text='检测到依赖更新', values=('正在下载最新模块，请稍等……'))
        tree.selection_set('download_deps')
        download_pip_packages()
        tree.set('download_deps', 'info', '模块下载完毕')
        tree.set('download_deps', 'result', '通过')
    if is_package_installed is False:
        tree.insert('chk_deps_installed', 'end', 'install_deps', text='安装最新依赖', values=('正在安装最新依赖，请稍等……'))
        tree.selection_set('install_deps')
        install_pip_packages()
        tree.set('install_deps', 'info', '依赖安装完毕')
        tree.set('install_deps', 'result', '通过')
    tree.set('chk_deps_installed', 'info', '依赖模块已安装')
    tree.set('chk_deps_installed', 'result', '通过')


@logfn2
def chk_requirements_txt_update():
    try:
        Path(VIRTUAL_ENV_DIR).mkdir(parents=True, exist_ok=True)
        res = requests.get(URL_REQUIREMENTS_TXT)
        if res.status_code == 200:
            Path(VIRTUAL_ENV_DIR).joinpath('requirements.txt').write_bytes(res.content)
        else:
            raise Exception(res.status_code)
    except Exception as e:
        logging.error(f'{e}: {traceback.format_exc()}')


@logfn2
def chk_sitecustomize_py_update():
    try:
        Path(VIRTUAL_ENV_DIR).mkdir(parents=True, exist_ok=True)
        res = requests.get(URL_SITECUSTOMIZE_PY)
        if res.status_code == 200:
            Path(VIRTUAL_ENV_DIR).joinpath('sitecustomize.py').write_bytes(res.content)
        else:
            raise Exception(res.status_code)
    except Exception as e:
        logging.error(f'{e}: {traceback.format_exc()}')


@logfn2
def chk_fastrpa_update():
    Path(VIRTUAL_ENV_DIR).mkdir(parents=True, exist_ok=True)
    p_pyz = Path(VIRTUAL_ENV_DIR).joinpath('rpa.pyz')
    p_pyz_version = Path(VIRTUAL_ENV_DIR).joinpath('rpa.pyz.version')
    version_str = ''
    try:
        res = requests.get(URL_RPA_PYZ_VERSION)
        if res.status_code == 200:
            version_str = res.content.decode('utf-8')
        else:
            raise Exception(res.status_code)
    except Exception as e:
        logging.error(f'{e}: {traceback.format_exc()}')
    if p_pyz_version.exists() and p_pyz.exists():
        if p_pyz_version.read_text(encoding='utf-8') == version_str:
            return
    try:
        res = requests.get(URL_RPA_PYZ)
        if res.status_code == 200:
            p_pyz.write_bytes(res.content)
            p_pyz_version.write_text(version_str)
        else:
            raise Exception(res.status_code)
    except Exception as e:
        logging.error(f'{e}: {traceback.format_exc()}')


@logfn2
def chk_resources_update():  # 只下载，解压工作由sitecustomize.py执行
    p_pyz = Path(VIRTUAL_ENV_DIR).joinpath('resources.pyz')
    p_pyz_version = Path(VIRTUAL_ENV_DIR).joinpath('resources.pyz.version')
    version_str = ''
    try:
        res = requests.get(URL_RESOURCES_PYZ_VERSION)
        if res.status_code == 200:
            version_str = res.content.decode('utf-8')
        else:
            raise Exception(res.status_code)
    except Exception as e:
        logging.error(f'{e}: {traceback.format_exc()}')
    if p_pyz_version.exists() and p_pyz.exists():
        if p_pyz_version.read_text(encoding='utf-8') == version_str:
            return
    try:
        res = requests.get(URL_RESOURCES_PYZ)
        if res.status_code == 200:
            p_pyz.write_bytes(res.content)
            p_pyz_version.write_text(version_str)
        else:
            raise Exception(res.status_code)
    except Exception as e:
        logging.error(f'{e}: {traceback.format_exc()}')


@logfn2
def before_check():
    chk_rpa_shell_update()
    # chk_volume_d_exists()  # D盘是否存在
    dialog.attributes('-topmost', True)  # 窗口置顶（恢复置顶）
    dialog.attributes('-topmost', False)  # 窗口置顶（取消置顶，避免遮挡安装过程）
    chk_msedge_webview2_installed()  # 安装Edge Webview2
    chk_dot_net_framework_ready()  # 检查.net framework版本是否低于4.6.2
    chk_python_389_installer_exists()  # Python3.8.9安装包
    chk_python_installed()  # Python是否安装
    chk_venv_exists()  # 虚拟环境是否创建
    chk_windows_firewall()  # Windows防火墙策略入站规则是否屏蔽Python
    # =======================================================
    chk_requirements_txt_update()  # RPA是否为最新版本
    chk_sitecustomize_py_update()
    chk_fastrpa_update()
    chk_resources_update()  # 只下载，解压工作由sitecustomize.py执行
    # =======================================================
    chk_deps_installed()  # 依赖模块是否完整
    dialog.attributes('-topmost', True)  # 窗口置顶（恢复置顶）
    tree.set('before_check', 'result', '通过')


@logfn2
def launch_rpa():
    tree.selection_set('rpa_launcher')
    tree.insert('rpa_launcher', 'end', 'rap_window', text='启动RPA窗口', values=('', ''))
    tree.selection_set('rap_window')
    tree.set('rap_window', 'info', '启动中……')
    force_rm(RPA_TEMP_DIR)
    pyz_file = Path(VIRTUAL_ENV_DIR).joinpath('rpa.pyz').as_posix()
    cmd = f'{VIRTUAL_ENV_DIR}/Scripts/python -X utf8 -m sitecustomize'
    _p = run_cmd(cmd, cwd=FASTRPA_DIR, collect_output=False, wait_for_end=False, env={'PYZ_FILE': pyz_file, "KEY": KEY})
    flag = False
    err_msg = ''
    for _ in range(60):
        if _p.poll() is not None:  # 程序已终止
            tree.set('rap_window', 'info', 'RPA进程启动失败，请检查日志')
            tree.set('rap_window', 'result', '未通过')
            raise Exception(f'RPA未启动，{_p.returncode}')
        if win32gui.FindWindow(None, '人事RPA平台') != 0:
            flag = True
            break
        else:
            sleep(1)
    if flag is True:
        tree.set('rap_window', 'info', '已启动')
        tree.set('rap_window', 'result', '通过')
        dialog.quit()
    else:
        tree.set('rap_window', 'info', '启动失败，请检查日志')
        tree.set('rap_window', 'result', '未通过')
        if err_msg == '':
            raise Exception('RPA未启动')
        else:
            raise Exception(f'RPA未启动，{err_msg}')


@logfn2
def main():
    try:
        before_check()  # 前置校验
    except Exception as e:
        tree.set('before_check', 'result', '未通过')
        messagebox.showerror(f'错误信息: {e}', traceback.format_exc())
        return
    launch_rpa()  # 启动RPA


def lock_screen():
    """电脑锁屏"""
    run_cmd('tsdiscon')


@logfn2
def setup_auto_login(win_username: str, win_password: str = ''):  # nosec
    winreg.CreateKey(winreg.HKEY_LOCAL_MACHINE, r'SOFTWARE\Microsoft\Windows NT\CurrentVersion\Winlogon')  # 为避免key不存在打开时报错，要先创建
    with winreg.OpenKey(winreg.HKEY_LOCAL_MACHINE, r'SOFTWARE\Microsoft\Windows NT\CurrentVersion\Winlogon', 0, winreg.KEY_SET_VALUE) as key:
        winreg.SetValueEx(key, 'LastUsedUsername', 1, winreg.REG_SZ, win_username)
        winreg.SetValueEx(key, 'AutoAdminLogon', 1, winreg.REG_SZ, "1")
        winreg.SetValueEx(key, 'DefaultUserName', 1, winreg.REG_SZ, win_username)
        winreg.SetValueEx(key, 'DefaultPassword', 1, winreg.REG_SZ, win_password)
        winreg.SetValueEx(key, 'ForceAutoLogon', 1, winreg.REG_SZ, "1")
        winreg.SetValueEx(key, 'IgnoreShiftOverride', 1, winreg.REG_SZ, "1")


@logfn2
def rollback_login_info():
    winreg.CreateKey(winreg.HKEY_LOCAL_MACHINE, r'SOFTWARE\FASTRPA\RPA_SHELL')  # 为避免key不存在打开时报错，要先创建
    with winreg.OpenKey(winreg.HKEY_LOCAL_MACHINE, r'SOFTWARE\FASTRPA\RPA_SHELL', 0, winreg.KEY_QUERY_VALUE) as key:
        win_username = ''
        win_password = ''  # nosec
        try:
            win_username = winreg.QueryValueEx(key, 'DefaultUserName')[0]
            win_password = winreg.QueryValueEx(key, 'DefaultPassword')[0]
        except Exception as e:
            logging.error(e)
        if win_username:
            setup_auto_login(win_username, win_password)


@logfn2
def launch_rpa_server():
    """启动rpa服务器端"""
    pyz_file = Path(VIRTUAL_ENV_DIR).joinpath('rpa.pyz').as_posix()
    cmd = f'{VIRTUAL_ENV_DIR}/Scripts/python -m sitecustomize'
    run_cmd(cmd, cwd=FASTRPA_DIR, collect_output=False, wait_for_end=False, env={'PYZ_FILE': pyz_file, "KEY": KEY, "ONLY_RPA_SERVER": "TRUE"})


if __name__ == '__main__':
    disable_uac()
    win_username = getpass.getuser()
    if Path(sys.executable).name in ['rpa_server.exe']:
        config(f'rpa_server_{win_username}')
        if win_username == 'fastrpa':
            launch_rpa_server()  # 仅启动server服务
            rollback_login_info()  # 设置原用户自动登录
            lock_screen()  # 锁屏
        else:
            logging.error(f'非fastrpa用户，直接退出{win_username}')
    elif Path(sys.executable).name in ['退出登录.exe']:
        config(f'退出登录_{win_username}')
        rollback_login_info()  # 设置原用户自动登录
        lock_screen()  # 锁屏
    else:
        config('rpa_shell')
        try:
            for d in [FASTRPA_DIR, LOG_DIR, PIP_DIR, PYTHON_INSTALL_DIR, RPA_TEMP_DIR, SETUP_DIR, VIRTUAL_ENV_DIR]:
                Path(d).mkdir(parents=True, exist_ok=True)
        except Exception as e:  # D盘有可能不存在，或不可写，在第一步检测，这里的错误先忽略
            logging.error(e)
            logging.error(traceback.format_exc())
        logging.info(RPA_SHELL_VERSION)
        logging.info(f'sys.argv: {sys.argv}')
        logging.info(f'sys.executable: {sys.executable}')
        dialog.iconbitmap(Path(RPA_SHELL_DIR).joinpath('images/icons/256.ico').as_posix())  # 必须使用绝对路径
        dialog.title(RPA_SHELL_TITLE)  # 窗口标题
        t1 = Thread(target=quit_360)
        t1.setDaemon(True)
        t1.start()
        t2 = Thread(target=main)
        t2.setDaemon(True)
        t2.start()
        dialog.mainloop()
