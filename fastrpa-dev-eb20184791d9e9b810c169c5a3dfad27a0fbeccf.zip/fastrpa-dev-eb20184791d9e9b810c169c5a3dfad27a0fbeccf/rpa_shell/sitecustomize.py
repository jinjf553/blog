import base64
import datetime
import importlib
import logging
import os
import shutil
import stat
import sys
import traceback
import types
from functools import wraps
from pathlib import Path
from types import ModuleType
from typing import Any, Dict, List, Optional, Tuple, Union

import win32file

if True:
    import _locale
    _locale._getdefaultlocale = lambda *args: ('zh_CN', 'utf-8')  # type: ignore


if __name__ == '__main__':
    D_RPA = 'd:/rpa'
    for i in range(100, 123):  # d-z
        if win32file.GetDriveType(f'{chr(i)}:') == 3:  # 本地磁盘或闪存
            D_RPA = f'{chr(i)}:/rpa'
            break
    else:
        D_RPA = 'c:/rpa'
    FASTRPA_DIR = f'{D_RPA}/runtime/fastrpa'
    RPA_RESOURCES_DIR = Path(FASTRPA_DIR).joinpath('resources').as_posix()
    Path(RPA_RESOURCES_DIR).mkdir(parents=True, exist_ok=True)

    def config(filename: Optional[str] = None) -> None:
        logging.getLogger().handlers = []
        if float(sys.version[:3]) >= 3.8:
            logging.basicConfig(level=logging.INFO,
                                format=r'[%(asctime)s]%(threadName)s  %(lineno)4d %(filename)-13s %(levelname)-5s %(message)s',
                                datefmt=r'%Y-%m-%d %H:%M:%S',
                                force=True)
        else:
            logging.basicConfig(level=logging.INFO,
                                format=r'[%(asctime)s]%(threadName)s  %(lineno)4d %(filename)-13s %(levelname)-5s %(message)s',
                                datefmt=r'%Y-%m-%d %H:%M:%S')
        if filename is not None:
            if Path(filename).is_absolute() is True and str(filename).lower().endswith('.log') is False:
                raise Exception('日志文件必须以.log为扩展名')
            if Path(filename).is_absolute() is False:
                yyyymm = datetime.datetime.now().strftime(r'%Y%m')
                yyyymmdd = datetime.datetime.now().strftime(r'%Y%m%d')
                hhmmss = datetime.datetime.now().strftime(r'%H%M%S')
                if filename[-5:].lower() == '.xlsx':
                    filename = filename[:-5] + '.log'
                elif filename[-4:].lower() != '.log':
                    filename = filename + '.log'
                filename = Path(f'{D_RPA}/logs/{yyyymm}/{yyyymmdd}').joinpath(hhmmss + '_' + filename).as_posix()
            Path(filename).parent.mkdir(parents=True, exist_ok=True)
            file_handler = logging.FileHandler(filename=filename, encoding='utf-8')
            file_handler.setLevel(logging.INFO)
            formatter = logging.Formatter(r'[%(asctime)s] %(threadName)s %(lineno)4d %(filename)-13s %(levelname)-5s %(message)s', r'%Y-%m-%d %H:%M:%S')
            file_handler.setFormatter(formatter)
            logging.getLogger().addHandler(file_handler)

    def logargs(*args):
        """遍历入参并打印"""
        for i, arg in enumerate(args):
            s = str(arg)[:100]
            if len(s) == 100:
                logging.info(f"==>参数{1+i}: {s+'...'}")
            else:
                logging.info(f"==>参数{1+i}: {s}")

    def logfn2(fn):
        """为函数添加日志，正常执行时，打印执行时长，错误时打印传参及异常原因。"""
        @wraps(fn)
        def foo(*args):
            try:
                logging.info(f'函数{fn.__name__}开始执行')
                begintime = datetime.datetime.now()
                logargs(*args)
                result = fn(*args)
                endtime = datetime.datetime.now()
                dur = endtime - begintime
                logging.info(
                    f'函数{fn.__name__}正常退出，执行时长: {dur.seconds}秒')
                return result
            except Exception as e:
                logging.error('===============================================')
                logging.error(f"函数{fn.__name__}执行异常")
                logargs(*args)
                logging.error(f"功能描述: {fn.__doc__}")
                logging.error(f'{e}')
                logging.error(f"异常原因: {traceback.format_exc()}")
                logging.error('===============================================')
            return False
        return foo

    def force_rm(filename: str) -> bool:
        """删除文件或目录
        （shutil.rmtree删除非只读文件报错，不能删除文件，os.remove只能删除文件，这里抽象下，能删除各种类型的文件）
        """
        is_delete_succ = True

        def _readonly_handler(func, path, execinfo) -> bool:
            try:
                os.chmod(path, stat.S_IWRITE)
                os.remove(path)
            except Exception:
                logging.error(path)
                is_delete_succ = False
                return is_delete_succ
            return True
        _f = Path(filename)
        try:
            if _f.exists():
                if _f.is_absolute():
                    if _f.is_dir():
                        shutil.rmtree(Path(filename), onerror=_readonly_handler)
                        return is_delete_succ
                    else:
                        os.chmod(filename, stat.S_IWRITE)
                        os.remove(filename)
                else:
                    return False
            return True
        except Exception as e:
            logging.error(f'{e}: {traceback.format_exc()}')
            return False

    class MetaPathLoader(importlib.abc.SourceLoader):
        z7_filename: str
        passowrd: Optional[str] = None
        _cache: Dict[str, Tuple[str, List[str]]] = {}
        static_dir: str = FASTRPA_DIR  # 静态文件目录（非.py文件被解压至此路径）

        def __init__(self, z7_filename: str, password: Optional[str] = None, static_dir: Optional[str] = None) -> None:
            self.z7_filename = z7_filename
            self.password = password
            MetaPathLoader.static_dir = static_dir or MetaPathLoader.static_dir
            if MetaPathLoader._cache == {}:
                MetaPathLoader._cache = self.cache_7z(self.z7_filename, self.password)

        @staticmethod
        def cache_7z(z7_filename: str, password: Optional[str] = None) -> Dict[str, Tuple[str, List[str]]]:
            from py7zr import SevenZipFile
            _cache: Dict[str, Tuple[str, List[str]]] = {}
            with SevenZipFile(z7_filename, password=password, mode='r') as zip:
                for fname, bio in zip.readall().items():
                    p = Path(fname)
                    fullname: str = ''
                    if p.name.endswith('__init__.py'):
                        fullname = p.parent.as_posix().replace('/', '.')
                    elif fname.endswith('.py'):
                        fullname = p.as_posix().replace('/', '.')[:-3]  # 去除末尾的.py
                    elif fname.endswith('.ipynb'):  # 跳过.ipynb文件
                        continue
                    else:
                        try:
                            _p = Path(MetaPathLoader.static_dir).joinpath(fname)
                            if _p.exists() is False:
                                _p.parent.mkdir(parents=True, exist_ok=True)
                            elif _p.is_dir() is True:  # 被同名的文件夹占用了
                                shutil.rmtree(_p.as_posix())
                            _p.write_bytes(bio.read())  # 解压至指定目录
                        except Exception as e:
                            logging.error(e)  # 一般报错是360把文件查杀了
                        continue
                    _cache[fullname] = (p.as_posix(), [line.decode('utf-8').strip('\r\n') for line in bio.readlines()])
            return _cache

        def module_repr(self, module):
            return '<urlmodule %r from %r>' % (module.__name__, module.__file__)

        def get_source(self, fullname: str) -> str:
            if fullname in MetaPathLoader._cache.keys():
                return '\n'.join(MetaPathLoader._cache[fullname][1])
            return ''

        def get_code(self, fullname: str) -> Any:
            srouce_code: str = self.get_source(fullname)
            return compile(srouce_code, self.get_filename(fullname), 'exec')

        def load_module(self, fullname: str) -> Optional[ModuleType]:  # type: ignore
            logging.info(f'load_module: {fullname}')
            try:
                code = self.get_code(fullname)
                mod = sys.modules.setdefault(fullname, types.ModuleType(fullname))
                mod.__file__ = self.get_filename(fullname)
                mod.__loader__ = self  # type: ignore
                mod.__package__ = fullname.rpartition('.')[0]
                exec(code, mod.__dict__)  # nosec
                return mod
            except Exception as e:
                logging.error(f'{e}:  {traceback.format_exc()}')
                raise e

        def get_data(self, path: Union[bytes, str]) -> Any:
            pass

        def get_filename(self, fullname: str) -> str:
            """包名转为文件路径"""
            if fullname in MetaPathLoader._cache.keys():
                return Path(MetaPathLoader.static_dir).joinpath(MetaPathLoader._cache[fullname][0]).as_posix()
            return fullname

        def is_package(self, fullname: str) -> bool:
            # 判断fullname是否是包，当fullname是目录时，返回True，是.py文件时，返回False
            if fullname in MetaPathLoader._cache.keys():
                if MetaPathLoader._cache[fullname][0].endswith('__init__.py'):
                    return True
                else:
                    return False
            return True

    class MetaPathFinder(importlib.abc.MetaPathFinder):
        z7_filename: str
        passowrd: Optional[str] = None

        def __init__(self, z7_filename: str, password: Optional[bytes] = None):
            self.z7_filename = z7_filename
            self.password = None if password is None else base64.decodebytes(password).decode("utf-8")

        @staticmethod
        def _get_links(url: str):
            pass

        def find_module(self, fullname: str, path=None) -> Optional[MetaPathLoader]:
            if fullname in ['rpa', 'rpa_launcher'] or fullname.startswith('rpa.') or fullname.startswith('rpa_launcher.'):
                return MetaPathLoader(self.z7_filename, self.password)
            else:
                return None

    @logfn2
    def clean_fastrpa():
        """清空用户目录下的fastrpa文件夹（.git包含只读文件，需要修改为可写，再删除）"""
        roaming_dir = Path(str(os.environ.get('APPDATA')))
        fastrpa_dir = roaming_dir.joinpath('fastrpa')
        if fastrpa_dir.exists() is True:
            force_rm(fastrpa_dir.as_posix())
        fastrpa_dir.mkdir(parents=True, exist_ok=True)

    @logfn2
    def extra_templates(templates_pyz: str):
        from py7zr import SevenZipFile
        if Path(RPA_RESOURCES_DIR).exists():
            force_rm(RPA_RESOURCES_DIR)
        Path(RPA_RESOURCES_DIR).mkdir(parents=True, exist_ok=True)
        if Path(templates_pyz).exists():
            logging.info(f'解压资源目录: {templates_pyz} => {RPA_RESOURCES_DIR}')
            logging.info('如日志执行至此无下文，一般为安全软件误报')
            logging.info('360企业版服务器版本会直接拦截，请安装办公终端版本')
            with SevenZipFile(Path(templates_pyz).as_posix(), mode='r') as zip:
                try:
                    zip.extractall(RPA_RESOURCES_DIR)
                except Exception as e:
                    logging.error(e)
                    raise e
            logging.info('资源解压成功')

    @logfn2
    def is_py7zr_ready():
        from py7zr import SevenZipFile
        SevenZipFile

    @logfn2
    def launch_rpa():
        import rpa.config
        rpa.config.LASTEST_GIT_COMMIT_HEAD = ''
        if 'ONLY_RPA_SERVER' in os.environ.keys():
            logging.info('RPA_SERVER')
            from rpa_launcher.backend.main import main as backend_main
            backend_main()
        else:
            extra_templates(Path(os.environ['PYZ_FILE']).parent.joinpath('resources.pyz'))
            from rpa_launcher.frontend.main import main as frontend_main
            frontend_main()

    def main():
        is_py7zr_ready()
        clean_fastrpa()
        if 'PYZ_FILE' in os.environ.keys() and Path(os.environ['PYZ_FILE']).exists():
            if 'KEY' in os.environ.keys():
                sys.meta_path.insert(0, MetaPathFinder(os.environ['PYZ_FILE'], eval(os.environ['KEY'])))  # nosec
            else:
                sys.meta_path.insert(0, MetaPathFinder(os.environ['PYZ_FILE']))
        else:
            raise Exception('无法加载rpa模块')
        launch_rpa()

    # python -m sitecustomize
    sys.path.append(FASTRPA_DIR)
    if 'ONLY_RPA_SERVER' in os.environ.keys():
        config('rpa_launcher_server')
    else:
        config('rpa_launcher_frontend')
    try:
        main()
    except Exception as e:
        logging.error(f'{e}:  {traceback.format_exc()}')
        raise e
