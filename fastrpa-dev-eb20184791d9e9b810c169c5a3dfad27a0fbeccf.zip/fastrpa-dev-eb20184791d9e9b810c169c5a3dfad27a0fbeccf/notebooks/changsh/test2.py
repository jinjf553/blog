

def remove_first_one(num_str):
    for i in range(len(num_str)):
        .0
        0.........................................................0.__annotations__

        . num_str[0:3] == "壹十零":
            num_str = '十' + num_str[3:]
        else:
            num_str
    return num_str


print(remove_first_one('壹十零亿零零壹十零万零零零壹点零'))
