# print (1+1)

# print("py")
# print("\npy")
# print("\tpy")


# name="asdfeIJKFJWvbrfd4532"

# print(name.lower().title())
# print(len(name))
# %%
a = [2, 4, 5, 6, 7]
# x = input("???")
# print(x)

# x= input('s')
# x=int(x)
# if x>=25:
#     print(3)
# elif x<25:
#     print(6)
# session = attach_sap()
#     wb = load_workbook(r"x:\Users\jinjf\Desktop\人资-附录1111111111.xlsx", data_only=True)
#     ws = wb.active
#     for i in range(5, len(ws["A"])+1):
#         template_name = ws[f"B{i}"].value
#         session.findById("wnd[0]/tbar[0]/okcd").text = "/n zhrbi0013"
#         session.findById("wnd[0]").sendVKey(0)
#         session.findById("wnd[0]/tbar[1]/btn[8]").press()
#         session.findById("wnd[0]/usr/ctxtP_SRTFD").text = template_name
#         session.findById("wnd[0]/usr/radRB_DOWN").select()
#         template_path = rf"{rpa.config.D_RPA}\HR人事\模板\{template_name.replace('->', '_')}.XLS"
#         if not os.path.exists(os.path.dirname(template_path)):
#             os.makedirs(os.path.dirname(template_path))
#         if os.path.exists(template_path):
#             os.remove(template_path)
#         pass_upload_window(rf"x:\r
#                            pa\HR人事\模板\{template_name.replace('->', '_')}.XLS", "另存为")
#         session.findById("wnd[0]/tbar[1]/btn[8]").press()
#         taskkill('Excel.exe')


# %%
def hello(name: str) -> str:
    return f'hello {name}'


# %%
print(hello('123'))

# %%
a = {'a': 10,
     'b': 100}
# %%


def divide(num):
    integer = int(num)
    fraction = round((num - integer) * 100)
    return(str(integer), str(fraction))


han_list = ["零", "壹", "贰", "叁", "肆", "伍", "陆", "柒", "捌", "玖"]
unit_list = ["十", "百", "千"]


def four_to_hanstr(num_str):
    result = ""
    num_len = len(num_str)
    for i in range(num_len):
        num = int(num_str[i])
        if i != num_len - 1 and num != 0:
            result += han_list[num] + unit_list[num_len - 2 - i]
        else:
            result += han_list[num]
    return result


def integer_to_str(num_str):
    str_len = len(num_str)
    if str_len > 12:
        print('to big to wrong')
        return
    elif str_len > 8:
        return four_to_hanstr(num_str[:-8]) + "亿" + four_to_hanstr(num_str[-8:-4]) + "万" + four_to_hanstr(num_str[-4:])
    elif str_len > 4:
        return four_to_hanstr(num_str[:-4]) + "万" + four_to_hanstr(num_str[-4:])
    else:
        return four_to_hanstr(num_str[-4:])


def remove_first_one(num_str):
    for i in range(len(num_str)):
        if num_str.find("壹十"):
            num_str = num_str.replace("壹十", "十")
        else:
            num_str
    return num_str


def remove_double_zero(num_str):
    for i in range(len(num_str)):
        if num_str.find("零零"):
            num_str = num_str.replace("零零", "零")
        else:
            num_str
    return num_str


def fraction_num(fraction):
    result = ""
    for i in range(len(fraction)):
        num = int(fraction[i])
        result += han_list[num]
    return result


# num = float(input("请输入一个浮点数："))
num = 1000100001.32005
integer, fraction = divide(num)
print(remove_double_zero(remove_first_one(integer_to_str(integer))) + "点" + fraction_num(fraction))
# print((remove_first_one(integer_to_str(integer)))+"点"+fraction_num(fraction))
# print(integer_to_str(integer)+"点"+fraction_num(fraction))


# %%
help(sort)
