import logging
from threading import Thread
from time import sleep

from rpa.fastrpa.log import config
from rpa.fastrpa.sap.session import attach_sap

config()


def new_thread():
    session = attach_sap('reopen')
    logging.info('sap opened')


t = Thread(target=new_thread)
t.start()


sleep(10)
