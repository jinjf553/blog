import asyncio
import json
import os
import random

import requests
import websockets
from logger import logger
from requests_toolbelt.multipart.encoder import MultipartEncoder


def sendDingMsg(nick: str = '', msg: str = '', msg_type: str = 'text', cookie: str = ''):
    """nick: 好友备注or群备注， msg:消息内容， msg_type: 消息类型（文本：text，文件：file）"""
    if msg_type in ['text', 'manage']:
        msg = msg
    elif msg_type == 'file' and not cookie:
        res = sendDingMsg(nick=nick, msg=msg, msg_type='cookie')
        sendDingMsg(nick=nick, msg=msg, msg_type='file', cookie=str(res))
        return
    elif msg_type == 'file' and cookie:
        if os.path.exists(msg):
            filepath = msg
            lis = list(range(48, 58)) + list(range(65, 91)) + list(range(97, 123))
            multipart_encoder = MultipartEncoder(
                fields={os.path.basename(filepath): ('blob', open(filepath, 'rb'), 'application/octet-stream')},
                boundary='----WebKitFormBoundary' + ''.join([chr(x) for x in random.sample(lis, 16)]))
            lenght, lenght1 = os.path.getsize(filepath), multipart_encoder.len
            headers = {
                'cookie': cookie,
                'content-type': 'application/x-www-form-urlencoded'
            }
            try:
                res = requests.get(f'https://im.dingtalk.com/attachment/mcreatefile?size={lenght}', headers=headers, timeout=10)
                headers.update({'content-type': multipart_encoder.content_type})
                headers.update({'content-length': str(lenght1), 'sec-fetch-mode': 'cors', 'ndpartition': f'bytes=0-{lenght-1}', 'sec-fetch-site': 'same-origin'})
                res2 = requests.post(f'https://im.dingtalk.com/attachment/mupload?uploadid={json.loads(res.text)["uploadid"]}', headers=headers, data=multipart_encoder, timeout=10)
                if 'filepath' not in json.loads(res2.text).keys():
                    raise Exception('网络可能异常，上传文件文件到服务器')
                msg = {'path': f"/{os.path.basename(filepath)}", "tempUrl": json.loads(res2.text)['filepath']}
            except Exception:
                msg = json.dumps({os.path.basename(msg): [open(msg, 'rb').read().decode('utf-8'), os.path.getsize(msg)]})
        else:
            logger.info(f'文件路径{msg}不存在')
            return 'error'
    elif msg_type == 'cookie':
        pass
    else:
        logger.info(f'{msg_type} 参数错误，只接收text, file, manage参数')
        return 'error'

    async def main_logic():
        async with websockets.connect('ws://10.133.10.155:9522') as websocket:
            await websocket.send(json.dumps({"jsonrpc": "2.0", "method": f"/{msg_type}", "params": [nick, msg], "id": 1}))
            res = await websocket.recv()
            return res
    res = asyncio.get_event_loop().run_until_complete(main_logic())
    logger.info(json.loads(res))
    if 'result' in json.loads(res):
        return json.loads(res)['result']
    else:
        return json.loads(res)
    # asyncio.get_event_loop().run_forever()


if __name__ == "__main__":
    res = sendDingMsg('金建峰', r"x:\Users\jinjf\Desktop\测试.txt", msg_type='text')
    print(res)
