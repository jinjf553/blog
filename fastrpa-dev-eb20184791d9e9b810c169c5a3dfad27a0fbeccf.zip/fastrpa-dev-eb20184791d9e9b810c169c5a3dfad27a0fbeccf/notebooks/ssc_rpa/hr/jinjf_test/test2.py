# def CreateGUID():
#     """     创建一个全局唯一标识符     类似：E06093E2-699A-4BF2-A325-4F1EADB50E18     NewVersion     """
#     try:
#         strDllPath = sys.path[0] + str(os.sep) + "createguid.dll"
#         dll = CDLL(strDllPath)
#         b = dll.newGUID()
#     except Exception:
#         pass
import os
import sys
from ctypes import CDLL, c_char_p

import win32api


def createguid():
    try:
        dllpath = sys.path[0] + str(os.sep) + "createguid.dll"
        dll = CDLL(dllpath)
        b = dll.newGUID()
        a = c_char_p(b)
        print(a.value)
    except Exception as e:
        raise e
        pass


def getFileVersion(file_name):

    info = win32api.GetFileVersionInfo(file_name, os.sep)

    ms = info['FileVersionMS']

    ls = info['FileVersionLS']

    version = '%d.%d.%d.%04d' % (win32api.HIWORD(ms), win32api.LOWORD(ms), win32api.HIWORD(ls), win32api.LOWORD(ls))

    print(version)
    return version


def read_exe(file_name):
    content = open(file_name, "rb").read()
    print(os.path.dirname(file_name) + "/test.exe")
    if os.path.exists(os.path.dirname(file_name) + "/test.exe"):
        print("cunzai")
        return
    open(os.path.dirname(file_name) + r"\test1.exe", 'wb').write(content)
    # print(content)


if __name__ == "__main__":
    # getFileVersion(r"x:\install\RDPWrap-v1.6.4\termsrv.dll")
    read_exe(r"x:\install\RDPWrap-v1.6.4\rdpconf.exe")
