import base64
import datetime
import logging
import os
import shutil
import time
from pathlib import Path
from threading import Thread
from typing import Optional

import requests
import rpa.config
import win32con
import win32gui
from py7zr import SevenZipFile
from rpa.fastrpa.log import config
from rpa.fastrpa.utils.git import get_lastest_git_commit_head
from rpa.fastrpa.utils.peek_encoding import peek_file_encoding


def build_rpa(zip7_filename: str, password: Optional[str] = None):
    """打包rpa.pyz"""
    Path(zip7_filename).parent.mkdir(parents=True, exist_ok=True)
    if Path(zip7_filename).exists():
        os.remove(zip7_filename)
    with SevenZipFile(zip7_filename, mode='w', password=password, header_encryption=False if password is None else True) as zip:
        for sub_dir in ['rpa', 'rpa_launcher']:
            for f in Path(rpa.config.WORKING_DIR).joinpath(sub_dir).rglob('*'):
                if f.is_dir():  # 跳过文件夹
                    continue
                elif f.name.endswith('.pyc'):  # 跳过pyc文件
                    continue
                elif f.name.endswith('.ipynb'):
                    continue
                elif f.name.endswith('.xlsx'):
                    continue
                elif f.name.endswith('.xls'):
                    continue
                elif f.name.endswith('.py'):
                    f_encoding = peek_file_encoding(f.as_posix())
                    f.write_text(f.read_text(encoding=f_encoding), 'utf-8')  # 强制所有.py转换为utf-8编码
                arcname = f.relative_to(rpa.config.WORKING_DIR).as_posix()  # 压缩包内路径
                zip.write(f, arcname=arcname)


def build_resources(zip7_filename: str):
    """打包resources.pyz"""
    Path(zip7_filename).parent.mkdir(parents=True, exist_ok=True)
    if Path(zip7_filename).exists():
        os.remove(zip7_filename)
    with SevenZipFile(zip7_filename, mode='w') as zip:
        for f in Path(rpa.config.WORKING_DIR).joinpath('resources').rglob('*'):
            arcname = f.relative_to(Path(rpa.config.WORKING_DIR).joinpath('resources')).as_posix()  # 压缩包内路径
            zip.write(f, arcname=arcname)


def encode_sitecustomize_py(sitecustomize_py: str):
    """混淆sitecustomize.py"""
    sitecustomize_py_str = Path(sitecustomize_py).read_text(encoding='utf-8')
    git_commit_str = get_lastest_git_commit_head()
    sitecustomize_py_str = sitecustomize_py_str.replace('LASTEST_GIT_COMMIT_HEAD = \'\'', f'LASTEST_GIT_COMMIT_HEAD = \'{git_commit_str}\'')
    Path(sitecustomize_py).write_text(sitecustomize_py_str, encoding='utf-8')
    pyminifier_cmd = f"pyminifier -o {sitecustomize_py} --obfuscate-classes --lzma --gzip --bzip2 {sitecustomize_py}"
    os.system(pyminifier_cmd)
    sitecustomize_py_str = Path(sitecustomize_py).read_text('utf-8')
    sitecustomize_py_str = sitecustomize_py_str.replace('# Created by pyminifier (https://github.com/liftoff/pyminifier)', '')
    Path(sitecustomize_py).write_text(sitecustomize_py_str, encoding='utf-8')


def main(dist=f'{rpa.config.D_RPA}/venv/fastrpa', password: Optional[str] = None):
    """构建程序，在虚拟环境目录（默认为x:/rpa/venv/fastrpa）生成以下文件：
       -----------------
       rpa.pyz （7z格式，加密）
       rpa.pyz.version （纯文本，内容为打包日期 YYYY-MM-DD HH:mm:ss 格式）
       resources.pyz （7z格式，未加密，内容为RPA资源文件，如模板）
       resources.pyz.version （纯文本，内容为打包日期 YYYY-MM-DD HH:mm:ss 格式）
       requirements.txt （纯文本，RPA依赖的第三方包列表）
       sitecustomize.py （混淆后的Python脚本，RPA的入口文件）
    """
    logging.info('正在构建...')
    build_time = datetime.datetime.now().strftime(r'%Y-%m-%d %H:%M:%S')
    Path(dist).mkdir(parents=True, exist_ok=True)
    build_rpa(Path(dist).joinpath('rpa.pyz').as_posix(), password)
    Path(dist).joinpath('rpa.pyz.version').write_text(build_time)
    build_resources(Path(dist).joinpath('resources.pyz').as_posix())
    Path(dist).joinpath('resources.pyz.version').write_text(build_time)
    shutil.copyfile(Path(rpa.config.WORKING_DIR).joinpath('requirements.txt'), Path(dist).joinpath('requirements.txt'))
    shutil.copyfile(Path(rpa.config.WORKING_DIR).joinpath('rpa_shell/sitecustomize.py'), Path(dist).joinpath('sitecustomize.py'))
    encode_sitecustomize_py(Path(dist).joinpath('sitecustomize.py').as_posix())
    logging.info(f'请上传结果文件到HTTP服务器: {dist}')
    _key = base64.encodebytes(bytes(password, encoding='utf-8')) if password else ''
    logging.info(f'构建结束，请执行测试指令：')
    logging.info(f'$env:PYZ_FILE="{dist}/rpa.pyz";$env:KEY="{_key}";python -m sitecustomize')
    # logging.info(f'python -m sitecustomize {dist}/rpa.pyz "{_key}"')
    logging.info(f'无问题后上传{dist}到HTTP服务器')


def main_1(dist=f'{rpa.config.D_RPA}/venv/fastrpa', password: Optional[str] = None):
    """构建程序，在虚拟环境目录（默认为x:/rpa/venv/fastrpa）生成以下文件：
       -----------------
       rpa.pyz （7z格式，加密）
       rpa.pyz.version （纯文本，内容为打包日期 YYYY-MM-DD HH:mm:ss 格式）
       resources.pyz （7z格式，未加密，内容为RPA资源文件，如模板）
       resources.pyz.version （纯文本，内容为打包日期 YYYY-MM-DD HH:mm:ss 格式）
       requirements.txt （纯文本，RPA依赖的第三方包列表）
       sitecustomize.py （混淆后的Python脚本，RPA的入口文件）
    """
    logging.info('正在构建...')
    build_time = datetime.datetime.now().strftime(r'%Y-%m-%d %H:%M:%S')
    Path(dist).mkdir(parents=True, exist_ok=True)
    build_rpa(Path(dist).joinpath('rpa.pyz').as_posix(), password)
    Path(dist).joinpath('rpa.pyz.version').write_text(build_time)
    build_resources(Path(dist).joinpath('resources.pyz').as_posix())
    Path(dist).joinpath('resources.pyz.version').write_text(build_time)
    shutil.copyfile(Path(rpa.config.WORKING_DIR).joinpath('requirements.txt'), Path(dist).joinpath('requirements.txt'))
    shutil.copyfile(Path(rpa.config.WORKING_DIR).joinpath('rpa_shell/sitecustomize.py'), Path(dist).joinpath('sitecustomize.py'))
    encode_sitecustomize_py(Path(dist).joinpath('sitecustomize.py').as_posix())
    logging.info(f'请上传结果文件到HTTP服务器: {dist}')
    _key = base64.encodebytes(bytes(password, encoding='utf-8')) if password else ''
    logging.info('构建结束，请执行测试指令：')
    logging.info(f'$env:PYZ_FILE="{dist}/rpa.pyz";$env:KEY="{_key}";python -m sitecustomize')
    # logging.info(f'python -m sitecustomize {dist}/rpa.pyz "{_key}"')
    logging.info(f'无问题后上传{dist}到HTTP服务器')
    key = "''".join(str(_key).split("'"))
    rpath = f"{rpa.config.D_RPA}/venv/fastrpa"
    fast, pyz_file = f'\'"{os.path.dirname(__file__)}\'"', f'\'"{rpath}/rpa.pyz\'"'
    py_cmd = rf'{rpath}\Scripts\python.exe -m sitecustomize'
    cmd = f'powershell.exe $env:PYTHONPATH="{fast}";$env:PYZ_FILE="{pyz_file}";$env:KEY="\'"{key}\'"";{py_cmd}'
    Thread(target=lambda: os.system(cmd), args=(), daemon=True).start()
    for _ in range(120):
        dialog = win32gui.FindWindow(None, '人事RPA平台')  # 对话框
        if dialog:
            win32gui.PostMessage(dialog, win32con.WM_QUIT, 0, 0)
            break
        time.sleep(0.5)
    else:
        raise Exception('build失败')
    files = {"rpa.pyz": open(rf"{rpath}\rpa.pyz", "rb").read(), "rpa.pyz.version": open(rf"{rpath}\rpa.pyz.version", "rb").read()}
    requests.post(url="http://10.133.10.155:2616", files=files)


if __name__ == '__main__':
    config('build.py')
    main_1(dist='x:/rpa/venv/fastrpa', password='jS3E3VmeLeN55Eic' or None)
