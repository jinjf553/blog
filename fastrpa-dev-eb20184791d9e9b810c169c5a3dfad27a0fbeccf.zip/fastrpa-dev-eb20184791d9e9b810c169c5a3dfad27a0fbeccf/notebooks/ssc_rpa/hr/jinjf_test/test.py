#!/usr/bin/env python
# -*- coding: utf-8 -*-
# @File    : test.py
# @Author  : jinjianfeng
# @Contact : 553041800@qq.com
# @Link    : https://github.com/jinjf553
# @software: PyCharm
# @Date    : 2019/4/14 21:29
# @Version : ??
import logging
import time
import traceback

from rpa.fastrpa.log import config
from rpa.robotB.run_B import run_robotB
from rpa.ssc_kit.hr.kit_chai_dan import check_ftp
from rpa.ssc_kit.hr.kit_chai_dan.run_A import (run_kit_shou_dong_chai_dan,
                                               upload_file)

file_A = r"x:\Users\jinjf\Desktop\3月新入职表单（第四批）\01V5 新员工入职（系统外调入）信息表-广东石油20210303.xlsx"
file_str = r""
file_B = r"x:\Users\jinjf\Desktop\1000264222-X420-岗位变动-郭运.xlsx"
file_C = r"x:\Users\lenovo\Desktop\1000199904-X600-离职-陆慧\1000199904-X600-离职-陆慧.xlsx"
config()


def function1():
    try:
        # 抓单
        file_list = check_ftp("拆单")
        # 机器人A
        for file in file_list:
            run_kit_shou_dong_chai_dan(filename=file)
        # 上载、转寄
        upload_file(file_list[0] if file_list else "", "")
        logging.info(file_list)
        if not file_list:
            file = check_ftp("岗位变动")
            run_robotB(file)
            if not file:
                file = check_ftp("员工入职")
                run_robotB(file)
    except Exception:
        with open("error.log", "a+", encoding="utf-8") as f:
            f.write(time.strftime("%Y%m%d %H:%M:%S\n", time.localtime(time.time())))
            f.write(traceback.format_exc() + "\n\n")
        time.sleep(10)
        function1()


if __name__ == '__main__':
    # 整体流程
    # function(1, 1)
    # function1()
    # 机器人A
    run_kit_shou_dong_chai_dan(filename=file_A, file_str=file_str)
    # 机器人B
    # file = check_ftp("员工入职")
    # run_robotB(filename=file_B)
    # run_li_zhi(filename=file_C)
    # run_chai_dan()

    # origin_desktop = win32service.OpenInputDesktop(0, True, win32con.MAXIMUM_ALLOWED)
    # origin_desktop = win32service.GetThreadDesktop(win32api.GetCurrentThreadId())
    # # new = create_desktop("test")
    # new = win32service.CreateDesktop("ABCD", 0, win32con.MAXIMUM_ALLOWED, None)
    # new.SetThreadDesktop()
    # new.SwitchDesktop()
    # attach_sap("reopen")
    # win32api.ShellExecute(0, 'open', r"sapshcut.exe",
    #                       f'-maxgui -user=funj0016 -pw=lenovo@7 -sysname=PH3 -client=800', '', 0)
    # time.sleep(20)
    # origin_desktop.SwitchDesktop()
    # win32gui.ShowWindow(win32gui.FindWindow("SAP_FRONTEND_SESSION", None), win32con.SW_HIDE)  # SW_SHOW  SW_HIDE
    # win32gui.ShowWindow(win32gui.FindWindow(None, "SAP Logon 740"), win32con.SW_HIDE)  # SW_SHOW  SW_HIDE
    # sap_gui_auto = win32com.client.GetObject("SAPGUI")
    # application = sap_gui_auto.GetScriptingEngine
    # print(len(application.Children))
    # for connection in application.Children:
    #     for session in connection.children:
    #         session_id: str = session.id
    #         print(session_id)
