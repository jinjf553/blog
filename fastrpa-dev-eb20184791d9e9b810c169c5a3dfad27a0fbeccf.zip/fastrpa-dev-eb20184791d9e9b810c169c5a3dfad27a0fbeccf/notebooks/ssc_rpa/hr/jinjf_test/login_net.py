import time

import requests


def crypt(p):
    b = ''
    for i in range(len(p)):
        a = ord(p[i])
        a = (((a & 1) << 7) | ((a & 2) << 5) | ((a & 4) << 3) | ((a & 8) << 1) | ((a & 16) >> 1) | ((a & 32) >> 3) | ((a & 64) >> 5) | ((a & 128) >> 7))
        a = a ^ (53 ^ (i & 255))
        if a == 32:
            b += '+'
        elif (a < 48 and a != 45 and a != 46) or (a < 65 and a > 57) or (a > 90 and a < 97 and a != 95) or (a > 122):
            b += f"%{'0123456789ABCDEF'[a >> 4]}{'0123456789ABCDEF'[a & 15]}"
        else:
            b += chr(a)
    return b


def loginAuthentication(u, p):
    headers = {
        # 'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9',
        # 'Accept-Encoding': 'gzip, deflate',
        # 'Accept-Language': 'zh-CN,zh;q=0.9,en;q=0.8,en-GB;q=0.7,en-US;q=0.6',
        # 'Cache-Control': 'max-age=0',
        # 'Connection': 'keep-alive',
        # 'Content-Length': '230',
        # 'Content-Type': 'application/x-www-form-urlencoded',
        # 'Cookie': f'username=jinjj.ssc; save_user=true; save_pass=true; password2={crypt("jINjianfeng1")}; uriback=1611552712125',
        # 'Host': '10.230.194.10:90',
        # 'Origin': 'http://10.230.194.10:90',
        # 'Referer': 'http://10.230.194.10:90/p/cc40b2589b21b16f0bdca3200db44f71/index.html?MTAuMjMwLjE5NC4xMDo5MC9sb2dpbg==',
        # 'Upgrade-Insecure-Requests': '1',
        # 'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/88.0.4324.96 Safari/537.36 Edg/88.0.705.50',
    }
    data = {
        # 'flags': '4',
        # 'forcedownlevel': '0',
        # 'uri': 'MTAuMjMwLjE5NC4xMDo5MC9sb2dpbg==',
        # 'terminal': 'pc',
        'login_type': 'login',
        'username': u,
        # 'password1': '',
        'password': crypt(p),
        # 'passwordText': '',
        # 'save_user': '1',
        # 'save_pass': '1'
    }
    res = requests.post("http://10.230.194.10:90/login", data=data, headers=headers)
    print(res.status_code, '认证登录成功')


def main(u: str = "", p: str = "") -> None:
    """
    params:
    u: 互联网认证账号
    p：互联网认证密码
    """
    if not u or not p:
        raise Exception('账号或密码不能为空')
    while True:
        res = requests.get("http://10.230.194.10:90/login?has_ori_uri")
        if "注销互联网" not in res.text:
            loginAuthentication(u, p)
        time.sleep(5)


if __name__ == "__main__":
    main('jinjj.ssc', 'jINjianfeng1')
