import os
import re
import shutil
import subprocess
import time
import winreg
from datetime import datetime

import chardet
import win32con
import win32gui
from rpa.fastrpa.sap.session_old import attach_sap


def rewrite_bat(curr_path, string, text):
    with open(fr'{curr_path}\tasks.bat', "rb") as f:
        content = f.read().decode("utf-8")
        pos, l = content.find(string), len(string)
    if pos == -1:
        return
    with open(fr'{curr_path}/task.bat', "wb") as f:
        data = f"{content[:pos+l]}{text}{content[pos+l:]}".encode('utf-8', errors="ignore")
        f.write(data)


def update_regedit(username, password, value):
    winreg.CreateKey(winreg.HKEY_LOCAL_MACHINE, r'SOFTWARE\Microsoft\Windows NT\CurrentVersion\Winlogon')  # 为避免key不存在打开时报错，要先创建
    with winreg.OpenKey(winreg.HKEY_LOCAL_MACHINE, r'SOFTWARE\Microsoft\Windows NT\CurrentVersion\Winlogon', 0, winreg.KEY_SET_VALUE) as key:
        winreg.SetValueEx(key, 'AutoAdminLogon', 1, winreg.REG_SZ, str(value))
        winreg.SetValueEx(key, 'DefaultUserName', 1, winreg.REG_SZ, username)
        winreg.SetValueEx(key, 'DefaultPassword', 1, winreg.REG_SZ, password)
        winreg.SetValueEx(key, 'ForceAutoLogon', 1, winreg.REG_SZ, "1")
        winreg.SetValueEx(key, 'IgnoreShiftOverride', 1, winreg.REG_SZ, "1")
    winreg.CreateKey(winreg.HKEY_LOCAL_MACHINE, r'SOFTWARE\Policies\Microsoft\Windows\OOBE')  # 为避免key不存在打开时报错，要先创建
    with winreg.OpenKey(winreg.HKEY_LOCAL_MACHINE, r'SOFTWARE\Policies\Microsoft\Windows\OOBE', 0, winreg.KEY_SET_VALUE) as key:
        winreg.SetValueEx(key, 'DisablePrivacyExperience', 1, winreg.REG_DWORD, 1)


def add_user(uname, passwd):
    # result = subprocess.run(f'net user {uname} /delete')
    result = subprocess.run(f'net user {uname}')
    if result.returncode == 0:
        print('该用户已经存在')
    else:
        try:
            subprocess.run(f'net user {uname} {passwd} /add /expires:never')
        except Exception as e:
            print(e)
            subprocess.run(f'net user {uname} {passwd} /add /expires:never')

        subprocess.run(f'net localgroup Users {uname} /delete')
        subprocess.run(f'wmic UserAccount where "Name=\'{uname}\'" set PasswordExpires=False')
    online_users = subprocess.run(f'query user', stdin=subprocess.PIPE, stdout=subprocess.PIPE)
    user_ids = re.findall(f'{uname}.*? (\d+) ', str(online_users))
    print(f"user_ids: {user_ids}, {online_users}")
    hwnd = win32gui.FindWindow(None, "Default4 - 127.0.0.2 - 远程桌面连接")
    win32gui.ShowWindow(hwnd, win32con.SW_HIDE)
    time.sleep(1)
    win32gui.ShowWindow(hwnd, win32con.SW_SHOW)
    time.sleep(1)
    win32gui.PostMessage(hwnd, win32con.WM_CLOSE, 0, 1)
    time.sleep(2)
    for user_id in user_ids:
        subprocess.run(f"logoff {user_id}")
        for _ in range(20):
            user_process_list = subprocess.run(f'tasklist /FI "USERNAME eq {uname}"  ', stdin=subprocess.PIPE, stdout=subprocess.PIPE)
            process_bytes = user_process_list.stdout  # .read()
            process_str = str(process_bytes.decode(chardet.detect(process_bytes)['encoding']))
            if "No tasks are running" in process_str or "没有运行的任务" in process_str:
                break
            time.sleep(0.5)
        time.sleep(0.5)
    a = subprocess.run(r'cmd.exe /c mstsc "x:\Users\jinjf\Desktop\Default4.rdp" /w:1 /h:1 /admin  ', stdout=subprocess.PIPE)
    print(a)
    # update_regedit(uname, passwd, 1)
    # subprocess.run(r"rundll32.exe user32.dll LockWorkStation")
    # time.sleep(2)
    # for _ in range(480):
    #     sap_path = rf"x:\Users\{uname}\AppData\Roaming\SAP\Common"
    #     startup_path = rf"x:\Users\{uname}\AppData\Roaming\Microsoft\Windows\Start Menu\Programs\Startup"
    #     if os.path.exists(startup_path):
    #         if not os.path.exists(sap_path):
    #             os.makedirs(sap_path)
    #         shutil.copyfile(rf"{rpa.config.D_RPA}\安装包\saplogon.ini", f"{sap_path}/saplogon.ini")
    #         shutil.copyfile(r"{rpa.config.D_RPA}\安装包\SapLogonTree.xml", f"{sap_path}/SapLogonTree.xml")
    #         shutil.copyfile(r"{rpa.config.D_RPA}\start_rpa.bat", f"{startup_path}/start_rpa.bat")
    #         break
    #     time.sleep(0.5)
    # update_regedit('jinjf', 'jIN15538135475', 1)
    # for _ in range(600):
    #     try:
    #         port_list = subprocess.run(f'netstat -aon | findstr "19527"', stdout=subprocess.PIPE, shell=True)
    #         port_str = re.findall(f"0.0.0.0:0.*?(\d+)", str(port_list.stdout))
    #         user_process_list = subprocess.run(f'tasklist /FI "USERNAME eq {uname}"  ', stdin=subprocess.PIPE, stdout=subprocess.PIPE)
    #         process_bytes = user_process_list.stdout
    #         process_str = str(process_bytes.decode(chardet.detect(process_bytes)['encoding']))
    #         if port_str and port_str[0] in process_str:
    #             print(process_str, port_str)
    #             break
    #     except Exception as e:
    #         print(e)
    #     time.sleep(0.5)


if __name__ == '__main__':
    user = "RPA1"
    passwd = "jinjf"
    # add_user(user.lower(), passwd)
    # attach_sap()
    print(datetime.now().strftime(r'%H%M%S'))
