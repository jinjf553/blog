from rpa.ssc.sap.query import parse_query_string

with open('x:/query_string_partten1.txt', encoding='utf-8') as f:
    query_string = f.read()
    parse_query_string(query_string)


with open('x:/query_string_partten2.txt', encoding='utf-8') as f:
    query_string = f.read()
    parse_query_string(query_string)
