
import logging
from time import sleep


class TestWithExitStmt(object):
    def __enter__(self):
        logging.info('enter')

    def __exit__(self, type, value, traceback):
        logging.info('exit')


with TestWithExitStmt():
    sleep(10)
    raise Exception('ddd')
