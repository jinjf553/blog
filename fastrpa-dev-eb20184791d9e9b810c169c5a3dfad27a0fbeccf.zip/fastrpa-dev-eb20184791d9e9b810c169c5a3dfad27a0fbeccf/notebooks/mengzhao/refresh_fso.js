(function () {
    let progress = document.querySelector("#fso_refresh_progress");
    if (progress == null) {
        progress = document.createElement('progress');
        progress.id = "fso_refresh_progress"
    }
    progress.value = "10"
    progress.max = "100"
    progress.style.cssText = "position:absolute;left:17em;top:8.8em;width:70%;height:20px;backgroud-color:#e6e6e6;backgroud:#e6e6e6;color:#0064B4"
    document.body.appendChild(progress);


    setInterval(function () {
        let value = progress.getAttribute("value")
        if (Number(value) >= 100) {
            window.onbeforeunload = null;
            let iframe1 = document.querySelector("#CRMApplicationFrame");
            let iframe2 = iframe1.contentWindow.document.querySelector("#WorkAreaFrame1");
            let todo_list_menu_item = iframe2.contentWindow.document.querySelector("#C4_W17_V18_IC-MGRHOME")
            if (todo_list_menu_item != null) {
                todo_list_menu_item.click()
            } else {
                console.error('没有找到待办事项菜单栏');
                return
            }
            progress.setAttribute("value", "0")
        } else {
            progress.setAttribute("value", Number(value) + 10)
        }
    }, 1000);
})();


javascript: !function () { let e = document.querySelector("#fso_refresh_progress"); null == e && ((e = document.createElement("progress")).id = "fso_refresh_progress"), e.value = "10", e.max = "100", e.style.cssText = "position:absolute;left:17em;top:8.8em;width:70%;height:20px;backgroud-color:#e6e6e6;backgroud:#e6e6e6;color:#0064B4", document.body.appendChild(e), setInterval(function () { let t = e.getAttribute("value"); if (Number(t) >= 100) { window.onbeforeunload = null; let t = document.querySelector("#CRMApplicationFrame").contentWindow.document.querySelector("#WorkAreaFrame1").contentWindow.document.querySelector("#C4_W17_V18_IC-MGRHOME"); if (null == t) return void console.error("没有找到待办事项菜单栏"); t.click(), e.setAttribute("value", "0") } else e.setAttribute("value", Number(t) + 10) }, 1e3) }();
