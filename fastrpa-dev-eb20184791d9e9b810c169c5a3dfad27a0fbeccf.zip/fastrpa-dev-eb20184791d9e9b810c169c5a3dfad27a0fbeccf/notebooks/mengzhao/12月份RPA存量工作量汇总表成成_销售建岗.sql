SELECT
	*
FROM
	(
		SELECT
			CASE
		WHEN file_id = '2020-12-07-11-30-58-932058' THEN
			'9dbad6de-383c-11eb-bd3f-a08cfdeb9030'
		WHEN file_id = '2020-12-08-10-00-21-935755' THEN
			'1f7556fb-38f9-11eb-91d6-a08cfdeb9030'
		WHEN file_id = '2020-12-08-14-31-29-125427' THEN
			'ffb20c4e-391e-11eb-827b-a08cfdeb9030'
		WHEN file_id = '2020-12-08-16-10-17-490799' THEN
			'cd4d23fe-392c-11eb-a737-a08cfdeb9030'
		WHEN file_id = '2020-12-10-08-15-35-004917' THEN
			'd16e4564-3a7c-11eb-904e-a08cfdeb9030'
		WHEN file_id = '2020-12-10-15-46-59-675512' THEN
			'e0b43915-3abb-11eb-96c8-a08cfdeb9030'
		WHEN file_id = '2020-12-11-15-08-07-287950' THEN
			'9e5a51fc-3b7f-11eb-bd85-a08cfdeb9030'
		WHEN file_id = '2020-12-11-15-16-07-470285' THEN
			'bc941660-3b80-11eb-b239-a08cfdeb9030'
		WHEN file_id = '2020-12-14-14-42-52-972392' THEN
			'96bf406e-3dd7-11eb-b854-a08cfdeb9030'
		WHEN file_id = '2020-12-14-14-51-46-729612' THEN
			'd4aac636-3dd8-11eb-803c-a08cfdeb9030'
		WHEN file_id = '2020-12-14-14-58-32-313058' THEN
			'c6a9d459-3dd9-11eb-af71-a08cfdeb9030'
		WHEN file_id = '2020-12-15-08-26-41-017548' THEN
			'3379d5e1-3e6c-11eb-be64-a08cfdeb9030'
		WHEN file_id = '2020-12-16-09-04-16-293117' THEN
			'9dde4e18-3f3a-11eb-ab7e-a08cfdeb9030'
		WHEN file_id = '2020-12-16-09-48-05-603184' THEN
			'bd540a55-3f40-11eb-82c3-a08cfdeb9030'
		WHEN file_id = '2020-12-16-09-53-15-571198' THEN
			'760f5836-3f41-11eb-9356-a08cfdeb9030'
		WHEN file_id = '2020-12-17-11-32-32-781184' THEN
			'7eeb360c-4018-11eb-83ae-a08cfdeb9030'
		WHEN file_id = '2020-12-17-13-37-17-971968' THEN
			'ec86a004-4029-11eb-93b5-a08cfdeb9030'
		WHEN file_id = '2020-12-17-13-43-19-201152' THEN
			'c3de45ce-402a-11eb-b5f0-a08cfdeb9030'
		WHEN file_id = '2020-12-17-13-47-05-119776' THEN
			'4a829b97-402b-11eb-9d61-a08cfdeb9030'
		WHEN file_id = '2020-12-17-14-56-29-824310' THEN
			'fca927cd-4034-11eb-94fd-a08cfdeb9030'
		WHEN file_id = '2020-12-17-14-59-07-049378' THEN
			'5a914589-4035-11eb-a71a-a08cfdeb9030'
		WHEN file_id = '2020-12-17-15-30-20-608306' THEN
			'b74f1a34-4039-11eb-8b3a-a08cfdeb9030'
		WHEN file_id = '2020-12-17-16-14-55-121113' THEN
			'f1a83377-403f-11eb-88c3-a08cfdeb9030'
		WHEN file_id = '2020-12-17-16-21-55-396504' THEN
			'ec20a437-4040-11eb-8f63-a08cfdeb9030'
		WHEN file_id = '2020-12-21-09-31-14-455614' THEN
			'36695de0-432c-11eb-ae69-a08cfdeb9030'
		WHEN file_id = '2020-12-21-09-40-40-932486' THEN
			'881eeec9-432d-11eb-9bce-a08cfdeb9030'
		WHEN file_id = '2020-12-21-10-24-17-474319' THEN
			'9fad85b2-4333-11eb-be67-a08cfdeb9030'
		WHEN file_id = '2020-12-23-07-44-00-377516' THEN
			'90b9670b-44af-11eb-bf3c-309c234bea87'
		WHEN file_id = '2020-12-23-07-56-11-500329' THEN
			'4483908d-44b1-11eb-8a76-309c234bea87'
		WHEN file_id = '2020-12-23-08-08-42-700082' THEN
			'044365ea-44b3-11eb-8fb7-309c234bea87'
		WHEN file_id = '2020-12-23-08-18-26-496904' THEN
			'60286585-44b4-11eb-9ef2-309c234bea87'
		WHEN file_id = '2020-12-23-08-23-23-786847' THEN
			'1170da0b-44b5-11eb-8ffd-309c234bea87'
		END subticket_id,
		post AS obj_id
	FROM
		hr.tb_hr_post_info
	) a
INNER JOIN hr.tb_ods_hr_subticket b ON a.subticket_id = b.subticket_id
LEFT JOIN hr.tb_ods_rpa_login c ON b.rpa_id = c.rpa_id
