from rpa.ssc.hr.orm.session import DbSession
from rpa.ssc.hr.orm.tb_hr_post_pool import PostPool

with DbSession() as s:
    p = PostPool(post_id='hellox')
    s.add(p)
    s.commit()
    print(p.id)
