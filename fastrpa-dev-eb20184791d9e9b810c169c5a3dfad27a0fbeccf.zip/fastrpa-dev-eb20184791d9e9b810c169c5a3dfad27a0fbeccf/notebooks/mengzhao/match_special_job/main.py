import logging
from typing import List

from fuzzywuzzy import process
from pandas import DataFrame
from rpa.fastrpa.adtable import load_from_xlsx_file


def load_dims() -> DataFrame:
    logging.info('加载特殊工种码表')
    lt_dims = load_from_xlsx_file(r"E:\特殊工种\特殊工种.xlsx")
    lt_dims.apply(lambda v: v.strip())
    df_dims = lt_dims.to_dataframe()
    df_dims['K'] = df_dims['H'] + ' ' + df_dims['I'] + ' ' + df_dims['J']
    # df_dims.columns = ['序号', '工种名称', '工种性质', '劳动条件', '文件依据', '工种序号', '页码', '厂', '车间', '岗位（工种）']
    return df_dims


def load_data() -> DataFrame:
    logging.info('加载南化公司简历')
    lt_data = load_from_xlsx_file(r"E:\特殊工种\南化公司简历.xlsx")
    lt_data.apply(lambda v: v.strip())
    df_data = lt_data.to_dataframe()
    df_data['G'] = df_data['E'] + ' ' + df_data['F']
    # df_data.columns = ['人员编号', '人员姓名', '开始日期', '结束日期', '简历描述', '简历描述2', '简历类型']
    return df_data


def choices(df_dims: DataFrame, contain_words: List[str] = []) -> List[str]:
    """根据关键词过滤特殊工种目录"""
    choices: List[str] = df_dims['K'].values.tolist()
    result: List[str] = []
    for c in choices:
        for w in contain_words:
            if w not in c:
                break
        result.append(c)
    return result


def match_job_name(job_name: str, choices: List[str], contain_words: List[str]):
    process.extract(job_name, choices, limit=50)


def main():
    logging.info('员工简历匹配特殊工种')
    df_dims = load_dims()
    df_data = load_data()
    # TODO


if __name__ == '__main__':
    from rpa.fastrpa.log import config
    config()
    main()
