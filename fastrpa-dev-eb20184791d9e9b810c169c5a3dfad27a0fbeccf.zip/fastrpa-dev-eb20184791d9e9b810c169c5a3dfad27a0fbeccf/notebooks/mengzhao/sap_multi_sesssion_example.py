"""同时打开3个SAP连接窗口，遍历人员PA20概览页面"""
import logging
from concurrent.futures import ProcessPoolExecutor
from time import sleep

from rpa.fastrpa.log import config
from rpa.fastrpa.sap.gui_tab_strip import GuiTabStrip
from rpa.fastrpa.sap.gui_table_control import GuiTableControl
from rpa.fastrpa.sap.session import SAP, SapSession, close_sap


def enter_pa20(session: SapSession, staff_id: str):
    session.findById("wnd[0]").maximize()
    session.findById("wnd[0]/tbar[0]/okcd").text = "/n pa20"
    session.findById("wnd[0]").sendVKey(0)
    session.findById("wnd[0]/usr/ctxtRP50G-PERNR").text = staff_id  # 人员编号
    session.findById("wnd[0]/usr/ctxtRP50G-PERNR").caretPosition = 8
    session.findById("wnd[0]").sendVKey(0)
    sap_status = session.findById("wnd[0]/sbar/pane[0]").text
    if sap_status != '':
        logging.error(sap_status)  # 人员编号有误
        raise Exception(sap_status)


def enter_sap_keycode(argu):
    staff_id, screen_idx = argu
    with SAP('new_connection', 'nothing_to_do', screen_idx) as pa20_session:
        enter_pa20(pa20_session, staff_id)
        pa20_gui_table_strip = GuiTabStrip(pa20_session, "wnd[0]/usr/tabsMENU_TABSTRIP")
        for pa20_gui_tab in pa20_gui_table_strip.gui_tabs:
            pa20_gui_tab.select()
            pa20_gui_table_control_id = pa20_gui_tab.findById('ssubSUBSCR_MENU:SAPMP50A:0400/subSUBSCR_ITMENU:SAPMP50A:0310/tblSAPMP50ATC_MENU').id
            gui_table_control_id = pa20_gui_table_control_id.replace(pa20_session.id + '/', '')
            pa20_gui_table_control = GuiTableControl(pa20_session, gui_table_control_id)
            for pa20_gui_table_control_row in pa20_gui_table_control.rows:
                if pa20_gui_table_control_row['状态'].ToolTip == '存在':  # 状态为存在时，说明有数据
                    pa20_gui_table_control_row['信息类型文本'].select_row()
                    pa20_session.findById("wnd[0]/tbar[1]/btn[20]").press()  # PA20 点击[概览]按钮
                    sleep(2)  # 延迟2秒
                    pa20_session.findById("wnd[0]/tbar[0]/btn[12]").press()  # PA20 点击[取消]按钮


if __name__ == '__main__':
    config()
    close_sap()
    with ProcessPoolExecutor(max_workers=3) as process_pool:
        process_pool.map(enter_sap_keycode, [('01533537', 0), ('01533537', 1), ('01533537', 2)])
