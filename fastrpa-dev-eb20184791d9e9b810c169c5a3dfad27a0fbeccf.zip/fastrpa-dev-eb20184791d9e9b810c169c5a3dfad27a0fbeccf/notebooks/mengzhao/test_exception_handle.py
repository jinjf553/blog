

def C():
    c = 'c'
    raise Exception('some error')


def B():
    b = 'b'
    C()


def A():
    a = 10
    B()


if __name__ == '__main__':
    A()
