from rpa.fastrpa.sap.session import SapWithoutClose

org_no = ['10010060', '10010060', '10010060']

with SapWithoutClose() as session:
    session.findById("wnd[0]/tbar[0]/okcd").text = "/n OOHQ"
    session.findById("wnd[0]/tbar[0]/btn[0]").press()
    if len(org_no) > 0:
        session.findById("wnd[0]/usr/btnPNPS$ORG").press()  # 点击组织机构按钮
        session.findById("wnd[1]/tbar[0]/btn[71]").press()  # 点击查找
        # 输入第一个组织机构编码作为占位符
        session.findById("wnd[2]/usr/tabsG_SELONETABSTRIP/tabpTAB001/ssubSUBSCR_PRESEL:SAPLSDH4:0220/sub:SAPLSDH4:0220/txtG_SELFLD_TAB-LOW[0,24]").text = org_no[0]
        session.findById("wnd[2]/usr/tabsG_SELONETABSTRIP/tabpTAB001/ssubSUBSCR_PRESEL:SAPLSDH4:0220/sub:SAPLSDH4:0220/txtG_SELFLD_TAB-LOW[0,24]").caretPosition = 8
        session.findById("wnd[2]/tbar[0]/btn[0]").press()  # 点击对勾
        session.findById("wnd[2]/usr/chk[1,3]").selected = -1
        session.findById("wnd[2]/usr/chk[1,3]").setFocus()
        session.findById("wnd[2]/tbar[0]/btn[0]").press()
        table = session.findById('wnd[1]/usr/subSUB_SEARCH:SAPLRHWH:0300/cntlSEARCH_TREE/shellcont/shell')  # 勾选表
        rows = list(table.GetAllNodeKeys())
        cols = list(table.GetColumnNames())
        for i in range(len(org_no)):
            for k in range(len(rows)):  # 遍历表格所有行
                value = session.findById('wnd[1]/usr/subSUB_SEARCH:SAPLRHWH:0300/cntlSEARCH_TREE/shellcont/shell').GetItemText(rows[k], cols[1])
                if org_no[i] in value:
                    session.findById("wnd[1]/usr/subSUB_SEARCH:SAPLRHWH:0300/cntlSEARCH_TREE/shellcont/shell").changeCheckbox(f"{rows[k]}", "SEAR_CHECKBX", -1)  # 勾选
                    break
        session.findById("wnd[1]/tbar[0]/btn[0]").press()
