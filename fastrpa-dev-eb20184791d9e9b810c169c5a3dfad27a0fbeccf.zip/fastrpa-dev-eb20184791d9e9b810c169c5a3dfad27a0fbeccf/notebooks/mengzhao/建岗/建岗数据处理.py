import logging

import pandas as pd
from rpa.fastrpa.log import config

config()

df = pd.read_csv('x:/jiangang.csv', dtype=str)
df = df.fillna('')
df['id'] = ''
df['obj_path'] = ''
df['parent_id'] = ''
df['has_children'] = ''
rn_path = []
parent_id = 'OFFFFFFFF'
parent_id_path = []
max_rn = max(df.index)
for rn in df.index:
    df['id'][rn] = df['obj_type'][rn] + df['obj_id'][rn]
    if df['obj_level'][rn] == '0':
        rn_path = [rn]
        parent_id = 'OFFFFFFFF'
        parent_id_path = [parent_id]
    elif df['obj_level'][rn] > df['obj_level'][rn_path[-1]]:
        parent_id = df['id'][rn_path[-1]]
        rn_path.append(rn)
        parent_id_path.append(parent_id)
    else:
        pop_count = int(df['obj_level'][rn_path[-1]]) - int(df['obj_level'][rn])
        for _ in range(pop_count):
            rn_path.pop()
            parent_id_path.pop()
        rn_path.pop()
        rn_path.append(rn)
        parent_id = parent_id_path[-1]
    if rn < max_rn and df['obj_level'][rn] < df['obj_level'][rn + 1]:
        has_children = '1'
    else:
        has_children = '0'
    df.loc[rn, 'obj_path'] = '>'.join(parent_id_path)
    df.loc[rn, 'parent_id'] = parent_id
    df.loc[rn, 'has_children'] = has_children
    if rn % 1000 == 0:
        logging.info(f'{rn},{df["obj_level"][rn]},{len(parent_id_path)}')
df.to_csv('x:/jiangang_.csv', index=False, encoding='utf-8')

df = df.drop_duplicates(['id'])  # 三个事务码之间数据存在重复，需要先补充列，合并后再执行删除重复行动作
df.to_csv('x:/jiangang_uniq.csv', index=False, encoding='utf-8')
