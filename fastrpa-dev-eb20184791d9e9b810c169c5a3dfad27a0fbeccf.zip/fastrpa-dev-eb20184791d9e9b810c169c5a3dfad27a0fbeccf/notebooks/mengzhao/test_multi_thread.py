import logging
from threading import Thread
from time import sleep

from rpa.fastrpa.log import config

WORKING = True

config()


def thread_a():
    while WORKING:
        sleep(1)
        logging.info('thread waiting')
    logging.info('thread exit')


t = Thread(target=thread_a)
t.setDaemon(True)
t.start()

for _ in range(5):
    sleep(1)
WORKING = False


input()
