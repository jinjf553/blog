import getpass
import logging
import shutil
import socket

import chardet  # type: ignore
import requests
# import onetimepass as otp
from getmac import get_mac_address

# def get_token():
#     return otp.get_totp('Zgi9x56htZ6HKeXQ')


def dns_lookup(host: str) -> bool:
    """查询DNS"""  # DNS查询FSO网站不稳定，一般用此函数先检验是否能够查询到
    try:
        socket.getaddrinfo(host, 80)
    except socket.gaierror:
        return False
    return True


def get_ip():
    s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    s.connect(('8.8.8.8', 80))
    ip = s.getsockname()[0]
    s.close()
    return ip


def get_hostname():
    return socket.gethostname()


def get_username():
    win_username = getpass.getuser()
    if win_username == 'mengzhao':
        win_username = 'tshemeng' + '@' + 'live' + '.' + 'com'
    return win_username


def get_macaddr():
    return get_mac_address()


def get_metainfo():
    ip = get_ip()
    hostname = get_hostname()
    user = get_username()
    mac_addr = get_macaddr()
    return {"ip": ip, "hostname": hostname, "user": user, "macAddr": mac_addr}


def get_encoding(file):
    # 二进制方式读取，获取字节数据，检测类型
    with open(file, 'rb') as f:
        data = f.read()
        return chardet.detect(data)['encoding']


def slurp(file: str, encoding='utf-8') -> str:
    with open(file, 'r', encoding=encoding) as f:
        return f.read()


def download_file(url, local_filename):
    try:
        with requests.get(url, stream=True) as r:
            with open(local_filename, 'wb') as f:
                shutil.copyfileobj(r.raw, f)
        return local_filename
    except Exception as e:
        logging.error(e)


def is_port_in_use(port: int) -> bool:
    import socket
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
        s.settimeout(1)
        return s.connect_ex(('localhost', port)) == 0


def get_unused_port(base_port: int = 10000) -> int:
    for port in range(base_port, 49151):
        if port in []:  # 跳过特定端口
            continue
        if is_port_in_use(port) is False:
            return port
    raise ValueError('没有可用的端口')


if __name__ == '__main__':
    print(dns_lookup('auth.siam.sinopec.com'))
