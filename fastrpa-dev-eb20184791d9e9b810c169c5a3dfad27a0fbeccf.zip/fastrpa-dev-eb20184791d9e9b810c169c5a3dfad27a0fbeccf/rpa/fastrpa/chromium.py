import logging
from pathlib import Path

import rpa.config
from rpa.config import CHROME_DRIVER_EXE_PATH
from rpa.fastrpa.ftp import MYFTP
from rpa.fastrpa.third_party.zip7 import unzip

FTP_PATH = '/安装包/谷歌浏览器'
LOCAL_PATH = f'{rpa.config.D_RPA}/安装包/谷歌浏览器'
CHROMIUM_PATH = Path(LOCAL_PATH).joinpath('Chromium').as_posix()
CHROMIUM_7Z = Path(LOCAL_PATH).joinpath('Chromium.7z').as_posix()
CHROME_EXE = Path(CHROMIUM_PATH).joinpath('chrome.exe').as_posix()


def checksum_chromium_7z() -> bool:
    """校验Chromium.7z完整性"""
    if Path(CHROMIUM_7Z).exists():
        return Path(CHROMIUM_7Z).stat().st_size == 80836125
    return False


def download_chromium_7z() -> bool:
    """从FTP下载Chromium.7z压缩包"""
    logging.info('从FTP下载Chromium.7z压缩包')
    with MYFTP() as ftp:
        ftp.download_file(CHROMIUM_7Z, Path(FTP_PATH).joinpath('Chromium.7z').as_posix())
        ftp.download_file(CHROME_DRIVER_EXE_PATH, Path(FTP_PATH).joinpath('chromedriver.exe').as_posix())
    return checksum_chromium_7z()


def extract_chromium_7z() -> bool:
    logging.info('解压Chromium.7z压缩包')
    if Path(CHROMIUM_7Z).exists() is False:
        return False
    try:
        unzip(CHROMIUM_7Z, LOCAL_PATH)
    except Exception as e:
        logging.error(e)
    return Path(CHROMIUM_PATH).joinpath('chrome.exe').exists()


def init_chromium():
    """下载并安装chromium"""
    if Path(CHROMIUM_PATH).joinpath('chrome.exe').exists() is False or checksum_chromium_7z() is False:
        if checksum_chromium_7z() is False:
            download_chromium_7z()
        extract_chromium_7z()
    if Path(CHROMIUM_PATH).joinpath('chrome.exe').exists() is False:
        raise Exception('Chromium安装失败')
