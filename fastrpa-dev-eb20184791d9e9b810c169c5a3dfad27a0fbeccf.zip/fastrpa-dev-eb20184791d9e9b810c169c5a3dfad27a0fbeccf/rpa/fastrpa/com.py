import pythoncom


class NEW_THREAD_USE_COM(object):
    """在子线程操作COM对象时，需要在线程开始先初始化，结束时释放资源
       -------------
       使用样例：
       from rpa.fastrpa.com import NEW_THREAD_USE_COM
       with NEW_THREAD_USE_COM():
           # 新线程操作COM组件
    """

    def __enter__(self):
        pythoncom.CoInitialize()

    def __exit__(self, exc_type, exc_val, exc_tb):
        pythoncom.CoUninitialize()
