import logging
from pathlib import Path
from time import sleep

import pywintypes
import rpa.config
import win32api
import win32event

WAIT_ABANDONED = 0x00000080
WAIT_OBJECT_0 = 0x00000000
WAIT_TIMEOUT = 0x00000102
WAIT_FAILED = 0xFFFFFFFF
ERROR_WAIT_NO_CHILDREN = 0x80
ERROR_SUCCESS = 0x0
ERROR_NOT_OWNER = 0x120
ERROR_ALREADY_EXISTS = 0xB7


class NamedFileLock(object):
    def __init__(self, name: str, timeout=60):
        if isinstance(name, str) is False:
            raise NameError('NamedFileLock锁名称必须是字符串')
        if name.isidentifier() is False:
            raise NameError('NamedFileLock锁名称必须以下划线或字母开头，其余部分为下划线、字母、数字的字符串')
        self.name = name
        self.timeout = timeout
        Path(f'{rpa.config.D_RPA}/lock/').mkdir(parents=True, exist_ok=True)

    def __enter__(self):
        wait_time = 0
        while True:
            try:
                Path(f'{rpa.config.D_RPA}/lock/').joinpath(self.name).mkdir(parents=True, exist_ok=False)
                break
            except FileExistsError:
                sleep(3)
                wait_time += 3
                # logging.info(f'NamedLock:{self.name}等待{wait_time}秒')
                if wait_time >= self.timeout:
                    raise TimeoutError(f'NamedFileLock:{self.name}等待超时{wait_time}秒')

    def __exit__(self, exc_type, exc_val, exc_tb):
        Path(f'{rpa.config.D_RPA}/lock/').joinpath(self.name).rmdir()


class NamedLock(object):
    """命名锁"""
    name: str
    timeout: int
    h_mutex: int
    is_already_exists: bool
    recur_error: bool

    def __init__(self, name: str, timeout=60, recur_error: bool = False):
        """命名锁

        Args:
            name (str): 锁名称，为与操作系统Mutex避免重名，自动增加_RPA_前缀
            timeout (int, optional): 等待锁时长，默认60秒
            recur_error (bool): 递归调用时报错，默认为False

        Raises:
            TimeoutError: 等待超时
            Exception: 未知错误

        注意：同一线程嵌套调用，同名锁不会报错
        """
        if isinstance(name, str) is False:
            raise NameError('NamedLock锁名称必须是字符串')
        self.name = f'_RPA_{name}'
        self.timeout = timeout
        self.h_mutex = win32event.CreateMutex(None, False, self.name)
        ret_code = win32api.GetLastError()
        if ret_code == ERROR_ALREADY_EXISTS:  # 锁已存在
            self.is_already_exists = True
        else:
            self.is_already_exists = False
        self.recur_error = recur_error

    def __enter__(self):
        wait_result = win32event.WaitForSingleObject(self.h_mutex, self.timeout * 1000)  # 等待互斥锁被释放
        if wait_result == WAIT_TIMEOUT:
            raise TimeoutError(f'互斥锁{self.name}等待超时')
        elif wait_result == WAIT_FAILED:
            raise OSError('未知错误：{ret_code}')
        elif wait_result == WAIT_ABANDONED:
            logging.warning(f'互斥锁{self.name}所有者未正常释放资源就退出')
        elif wait_result in (ERROR_SUCCESS, ERROR_WAIT_NO_CHILDREN):
            pass
        if self.is_already_exists is True and wait_result in (ERROR_SUCCESS, ERROR_WAIT_NO_CHILDREN, WAIT_ABANDONED):
            if self.recur_error is True:
                raise RecursionError('同一线程递归调用')

    def __release_lock__(self):
        try:
            win32event.ReleaseMutex(self.h_mutex)
        except pywintypes.error as e:  # pylint: disable=fixme, no-member
            if e.winerror == ERROR_NOT_OWNER:
                logging.error('尝试释放不属于当前所有者的Mutex')

    def __exit__(self, exc_type, exc_val, exc_tb):
        self.__release_lock__()


class ClipboardLock(NamedLock):
    """剪切板锁"""

    def __init__(self, timeout=60):
        super().__init__('CLIPBOARD', timeout)


if __name__ == '__main__':
    from rpa.fastrpa.log import config
    config()
    # with CLIPBOARD_LOCK():
    #     sleep(10)
    with NamedLock('/app/con[0]/ses[0]', 0):
        with NamedLock('/app/con[0]/ses[0]', 0):
            pass
