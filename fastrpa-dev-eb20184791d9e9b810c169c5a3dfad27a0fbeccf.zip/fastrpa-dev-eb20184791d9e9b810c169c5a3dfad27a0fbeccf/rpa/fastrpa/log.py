import asyncio
import datetime
import json
import logging
import logging.handlers
import sys
import traceback
from functools import wraps
from pathlib import Path
from typing import Optional

import rpa.config
from websockets.server import WebSocketServerProtocol


def create_websocket_handler(websocket: WebSocketServerProtocol):
    class WebsocketHandler(logging.Handler):
        websocket: WebSocketServerProtocol

        def __init__(self, websocket: WebSocketServerProtocol):
            logging.Handler.__init__(self)
            self.websocket = websocket
            if self.websocket:
                try:
                    # asyncio.run 在python 3.7以上版本有效
                    # 参见: https://stackoverflow.com/questions/51762227/how-to-call-a-async-function-from-a-synchronized-code-python
                    asyncio.run(self.websocket.send(json.dumps({'jsonrpc': '2.0',
                                                                'method': '/log/log_text/clear',
                                                                'params': []})))
                except Exception as e:
                    print(e)

        def emit(self, record):
            msg = self.format(record)
            rpa.config.LOG_TEXT.append(msg)
            if self.websocket:
                try:
                    # asyncio.run 在python 3.7以上版本有效
                    # 参见: https://stackoverflow.com/questions/51762227/how-to-call-a-async-function-from-a-synchronized-code-python
                    asyncio.run(self.websocket.send(json.dumps({'jsonrpc': '2.0',
                                                                'method': '/log/log_text/update',
                                                                'params': [msg]})))
                except Exception as e:
                    print(e)
    websocket_handler = WebsocketHandler(websocket)
    formatter = logging.Formatter(r'[%(asctime)s]%(threadName)s  %(lineno)4d %(filename)-13s %(levelname)-5s %(message)s', r'%Y-%m-%d %H:%M:%S')
    websocket_handler.setFormatter(formatter)
    websocket_handler.setLevel(logging.INFO)
    return websocket_handler


def config(filename=None, websocket=None) -> Optional[str]:
    """配置logging打印格式，当logfile不为空时，将日志写入logfile。"""
    rpa.config.LOG_FILENAME = ''
    rpa.config.LOG_TEXT = []
    logging.getLogger().handlers = []
    if float(sys.version[:3]) >= 3.8:
        logging.basicConfig(level=logging.INFO,
                            format=r'[%(asctime)s]%(threadName)s  %(lineno)4d %(filename)-13s %(levelname)-5s %(message)s',
                            datefmt=r'%Y-%m-%d %H:%M:%S',
                            force=True)
    else:
        logging.basicConfig(level=logging.INFO,
                            format=r'[%(asctime)s]%(threadName)s  %(lineno)4d %(filename)-13s %(levelname)-5s %(message)s',
                            datefmt=r'%Y-%m-%d %H:%M:%S')
    if websocket is not None:
        text_handler = create_websocket_handler(websocket)
        logging.getLogger().addHandler(text_handler)
    if filename is not None:
        if Path(filename).is_absolute() is True and str(filename).lower().endswith('.log') is False:
            p = Path(filename)
            filename = p.parent.joinpath(p.stem + '.log').as_posix()  # 将扩展名转换为.log
        if Path(filename).is_absolute() is False:
            yyyymm = datetime.datetime.now().strftime(r'%Y%m')
            yyyymmdd = datetime.datetime.now().strftime(r'%Y%m%d')
            hhmmss = datetime.datetime.now().strftime(r'%H%M%S')
            if filename[-5:].lower() == '.xlsx':
                filename = filename[:-5] + '.log'
            elif filename[-4:].lower() != '.log':
                filename = filename + '.log'
            filename = Path(f'{rpa.config.D_RPA}/logs/{yyyymm}/{yyyymmdd}').joinpath(hhmmss + '_' + filename).as_posix()
        Path(filename).parent.mkdir(parents=True, exist_ok=True)
        file_handler = logging.FileHandler(filename=filename, encoding='utf-8')
        file_handler.setLevel(logging.INFO)
        formatter = logging.Formatter(r'[%(asctime)s] %(threadName)s %(lineno)4d %(filename)-13s %(levelname)-5s %(message)s', r'%Y-%m-%d %H:%M:%S')
        file_handler.setFormatter(formatter)
        logging.getLogger().addHandler(file_handler)
        rpa.config.LOG_FILENAME = filename
        logging.info(f'日志文件路径: {filename}')
        return rpa.config.LOG_FILENAME
    else:
        rpa.config.LOG_FILENAME = ''
    return None


def logargs(*args):
    """遍历入参并打印"""
    for i, arg in enumerate(args):
        s = str(arg)[:100]
        if len(s) == 100:
            logging.info(f"==>参数{1+i}: {s+'...'}")
        else:
            logging.info(f"==>参数{1+i}: {s}")


def logfn(fn):
    """为函数添加日志，正常执行时，打印执行时长，错误时打印传参及异常原因。"""
    @wraps(fn)
    def foo(*args):
        try:
            return fn(*args)
        except Exception as e:
            logging.error('===============================================')
            logging.error(f"函数{fn.__name__}执行异常")
            logargs(*args)
            logging.error(f"功能描述: {fn.__doc__}")
            logging.error(f'{e}')
            logging.error(f"异常原因: {traceback.format_exc()}")
            logging.error('===============================================')
        return False
    return foo


def logfn2(fn):
    """为函数添加日志，正常执行时，打印执行时长，错误时打印传参及异常原因。"""
    @wraps(fn)
    def foo(*args):
        try:
            logging.info(f'函数{fn.__name__}开始执行')
            begintime = datetime.datetime.now()
            logargs(*args)
            result = fn(*args)
            endtime = datetime.datetime.now()
            dur = endtime - begintime
            logging.info(
                f'函数{fn.__name__}正常退出，执行时长: {dur.seconds}秒')
            return result
        except Exception as e:
            logging.error('===============================================')
            logging.error(f"函数{fn.__name__}执行异常")
            logargs(*args)
            logging.error(f"功能描述: {fn.__doc__}")
            logging.error(f'{e}')
            logging.error(f"异常原因: {traceback.format_exc()}")
            logging.error('===============================================')
        return False
    return foo


def logfn3(fn):
    """为函数添加日志，正常执行时，打印执行时长，错误时打印传参及异常原因。"""
    @wraps(fn)
    def foo(*args):
        try:
            logging.info(f"执行校验: {fn.__doc__}")
            return fn(*args)
        except Exception as e:
            logging.error('===============================================')
            logging.error(f"函数{fn.__name__}执行异常")
            logargs(*args)
            logging.error(f"功能描述: {fn.__doc__}")
            logging.error(f'{e}')
            logging.error(f"异常原因: {traceback.format_exc()}")
            logging.error('===============================================')
        return False
    return foo


def timeit(fn):
    """记录函数开始执行时间，结束执行时间"""
    @wraps(fn)
    def foo(*args):
        try:
            logging.info(f"执行操作: {fn.__doc__}")
            begintime = datetime.datetime.now()
            result = fn(*args)
            endtime = datetime.datetime.now()
            dur = endtime - begintime
            logging.info(f"执行结束: {fn.__doc__}，耗时: {dur.seconds}秒")
            return result
        except Exception as e:
            logging.error('===============================================')
            logging.error(f"函数{fn.__name__}执行异常")
            logargs(*args)
            logging.error(f"功能描述: {fn.__doc__}")
            logging.error(f'{e}')
            logging.error(f"异常原因: {traceback.format_exc()}")
            logging.error('===============================================')
        return False
    return foo


if __name__ == '__main__':
    config()
    logging.info("打印日志")
