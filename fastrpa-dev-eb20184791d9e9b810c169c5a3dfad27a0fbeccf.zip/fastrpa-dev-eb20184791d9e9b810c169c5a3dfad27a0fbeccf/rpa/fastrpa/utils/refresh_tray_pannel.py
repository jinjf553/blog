import win32api
import win32con
import win32gui


def refresh_tray_pannel() -> bool:
    """刷新系统托盘区，清除残留图标"""
    system_tray_container_handle = win32gui.FindWindowEx(0, 0, 'Shell_TrayWnd', '')
    if system_tray_container_handle == 0:
        return False
    system_tray_handle = win32gui.FindWindowEx(system_tray_container_handle, 0, 'TrayNotifyWnd', '')
    if system_tray_handle == 0:
        return False
    sys_pager_handle = win32gui.FindWindowEx(system_tray_handle, 0, 'SysPager', '')
    if sys_pager_handle == 0:
        return False
    notification_area_handle = win32gui.FindWindowEx(sys_pager_handle, 0, 'ToolbarWindow32', '用户提示通知区域')  # Win10 中文版
    if notification_area_handle == 0:
        notification_area_handle = win32gui.FindWindowEx(sys_pager_handle, 0, 'ToolbarWindow32', '用户显示的通知区域')  # Win7 中文版
    if notification_area_handle == 0:
        notification_area_handle = win32gui.FindWindowEx(sys_pager_handle, 0, 'ToolbarWindow32', 'Notification Area')  # 英文版
    if notification_area_handle != 0:
        left, top, right, bottom = win32gui.GetClientRect(notification_area_handle)
        for pixel_x in range(left, right, 5):
            for pixel_y in range(top, bottom, 5):
                win32gui.SendMessage(notification_area_handle, win32con.WM_MOUSEMOVE, 0, win32api.MAKELONG(pixel_x, pixel_y))
        return True
    return False
