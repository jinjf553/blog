from pathlib import Path
from typing import Dict

import chardet


def peek_bytes_encoding(_bytes: bytes) -> str:
    """检测字节编码"""
    info: Dict[str, str] = chardet.detect(_bytes)
    if 'encoding' in info.keys():
        for encoding in [info['encoding'], 'ansi', 'gbk', 'gb2312', 'utf-8']:
            if isinstance(encoding, str) and encoding != '':
                try:
                    _bytes.decode(encoding)
                    return encoding
                except Exception:
                    pass
    return 'ansi'


def peek_file_encoding(filename: str) -> str:
    """检测文本文件字符编码"""
    return peek_bytes_encoding(Path(filename).read_bytes())


def bytes_to_utf8(_bytes: bytes) -> str:
    """字节转化为utf-8字符串"""
    return _bytes.decode(peek_bytes_encoding(_bytes))


if __name__ == '__main__':
    _bytes = b'\r\n\xd3\xb3\xcf\xf1\xc3\xfb\xb3\xc6'
    bytes_to_utf8(_bytes)
