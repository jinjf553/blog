"""Windows平台用户账号类工具函数(需要管理员权限)"""
import logging
import os
import platform
import re
import shutil
import winreg
from contextlib import contextmanager
from pathlib import Path
from time import sleep

import requests
import rpa.config
import win32con
import win32profile
import win32security
from rpa.fastrpa.net import get_username
from rpa.fastrpa.third_party.sap import (FILE_SAPLOGON_INI,
                                         FILE_SAPLOGONTREE_XML)
from rpa.fastrpa.third_party.sysinternals_suite import PSEXEC_EXE, PSGETSID_EXE
from rpa.fastrpa.utils.run_cmd import run_cmd

# 账号默认登录方式
SIGNIN_PIN = '{D6886603-9D2F-4EB2-B667-1971041FA96B}'  # PIN登录
SIGNIN_PICTURE = '{2135F72A-90B5-4ED3-A7F1-8BB705AC276A}'  # 图片登录
SIGNIN_PASSWORD = '{60B78E88-EAD8-445C-9CFD-0B87F74EA6CD}'  # nosec 密码登录
SIGNIN_MS_ACCOUNT = '{F8A0B131-5F68-486C-8040-7E8FC3C85BB6}'  # 微软账号登录
SIGNIN_FINGERPRINT = '{BEC09223-B018-416D-A0AC-523971B639F5}'  # 指纹登录


def skip_new_user_privacy_setup():
    """修改Windows注册表，新用户登陆时跳过隐私设置界面"""
    winreg.CreateKey(winreg.HKEY_LOCAL_MACHINE, r'SOFTWARE\Policies\Microsoft\Windows\OOBE')
    with winreg.OpenKey(winreg.HKEY_LOCAL_MACHINE, r'SOFTWARE\Policies\Microsoft\Windows\OOBE', 0, winreg.KEY_SET_VALUE) as key:
        winreg.SetValueEx(key, 'DisablePrivacyExperience', 1, winreg.REG_DWORD, 1)  # 跳过隐私设置（第一次登录用户时，Windows会询问隐私设置）


def disable_switch_user():
    """禁用切换用户功能"""
    winreg.CreateKey(winreg.HKEY_LOCAL_MACHINE, r'SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\System')
    with winreg.OpenKey(winreg.HKEY_LOCAL_MACHINE, r'SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\System', 0, winreg.KEY_SET_VALUE) as key:
        winreg.SetValueEx(key, 'HideFastUserSwitching', 1, winreg.REG_DWORD, 1)  # 切换用户功能: 1禁用 0允许
        winreg.SetValueEx(key, 'dontdisplaylastusername', 1, winreg.REG_DWORD, 0)  # 上个登录用户: 1不显示 0显示（不显示时可以输入用户名，切换至任意用户）


def enable_switch_user():
    """禁用切换用户功能"""
    winreg.CreateKey(winreg.HKEY_LOCAL_MACHINE, r'SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\System')
    with winreg.OpenKey(winreg.HKEY_LOCAL_MACHINE, r'SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\System', 0, winreg.KEY_SET_VALUE) as key:
        winreg.SetValueEx(key, 'HideFastUserSwitching', 1, winreg.REG_DWORD, 0)  # 切换用户功能: 1禁用 0允许
        winreg.SetValueEx(key, 'dontdisplaylastusername', 1, winreg.REG_DWORD, 0)  # 上个登录用户: 1不显示 0显示（不显示时可以输入用户名，切换至任意用户）


def check_win_login(win_username: str, win_password: str) -> bool:
    """验证用户名密码是否正确，错误时抛出异常【用户名或密码不正确。】"""
    try:
        win32security.LogonUser(win_username, None, win_password, win32con.LOGON32_LOGON_INTERACTIVE, win32con.LOGON32_PROVIDER_DEFAULT)
        return True
    except Exception as e:
        logging.error(e)
        return False


def disable_uac():
    """关闭UAC账户控制"""
    run_cmd(r'reg.exe add HKLM\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\System /v EnableLUA /t REG_DWORD /d 0 /f')


def active_user(win_username: str):
    run_cmd(f'net user {win_username} /active:yes')  # 启用用户


def check_win_login_locked(win_username: str, win_password: str) -> bool:
    """验证用户名密码被锁定"""
    try:
        win32security.LogonUser(win_username, None, win_password, win32con.LOGON32_LOGON_INTERACTIVE, win32con.LOGON32_PROVIDER_DEFAULT)
    except Exception as e:
        if '已锁定' in str(e):
            active_user(win_username)
            return True
    return False


def is_user_exists(win_username: str):
    return win_username in run_cmd(f'net user {win_username}')


def get_user_profile_dir(win_username: str, win_password: str) -> str:
    """获取用户主目录（新用户需要登录一次才有主目录）"""
    handler = win32security.LogonUser(win_username, None, win_password, win32con.LOGON32_LOGON_INTERACTIVE, win32con.LOGON32_PROVIDER_DEFAULT)
    try:
        return win32profile.GetUserProfileDirectory(handler)
    except Exception as e:
        logging.error(e)
        return ''


def get_user_sid(win_username: str) -> str:
    """获取用户sid"""
    cmd_out = run_cmd(f'{PSGETSID_EXE} -nobanner {win_username}')
    for line in cmd_out.splitlines():
        line = line.strip()
        if line.startswith('S-1-'):
            return line
    else:
        return ''


def setup_auto_login(win_username: str, win_password: str = ''):  # nosec
    if check_win_login(win_username, win_password) is False:
        raise Exception('Windows用户名或密码错误')
    winreg.CreateKey(winreg.HKEY_LOCAL_MACHINE, r'SOFTWARE\Microsoft\Windows NT\CurrentVersion\Winlogon')  # 为避免key不存在打开时报错，要先创建
    with winreg.OpenKey(winreg.HKEY_LOCAL_MACHINE, r'SOFTWARE\Microsoft\Windows NT\CurrentVersion\Winlogon', 0, winreg.KEY_SET_VALUE) as key:
        winreg.SetValueEx(key, 'LastUsedUsername', 1, winreg.REG_SZ, win_username)
        winreg.SetValueEx(key, 'AutoAdminLogon', 1, winreg.REG_SZ, "1")
        winreg.SetValueEx(key, 'DefaultUserName', 1, winreg.REG_SZ, win_username)
        winreg.SetValueEx(key, 'DefaultPassword', 1, winreg.REG_SZ, win_password)
        winreg.SetValueEx(key, 'ForceAutoLogon', 1, winreg.REG_SZ, "1")
        winreg.SetValueEx(key, 'IgnoreShiftOverride', 1, winreg.REG_SZ, "1")


@contextmanager
def keep_user_sign_option(win_username: str):
    """上下文工具函数，效果是用户默认登录方式不变，用于设置自动登录后，恢复用户登录设置"""
    user_sid = get_user_sid(win_username)
    user_sign_option: str = ''
    winreg.CreateKey(winreg.HKEY_LOCAL_MACHINE, r'SOFTWARE\Microsoft\Windows\CurrentVersion\Authentication\LogonUI\UserTile')
    try:
        with winreg.OpenKey(winreg.HKEY_LOCAL_MACHINE, r'SOFTWARE\Microsoft\Windows\CurrentVersion\Authentication\LogonUI\UserTile', 0, winreg.KEY_QUERY_VALUE) as key:
            user_sign_option = winreg.QueryValueEx(key, user_sid)[0]  # 用户默认登录方式（一般为密码、指纹、PIN）
    except Exception:  # nosec
        pass
    yield
    if user_sign_option:
        with winreg.OpenKey(winreg.HKEY_LOCAL_MACHINE, r'SOFTWARE\Microsoft\Windows\CurrentVersion\Authentication\LogonUI\UserTile', 0, winreg.KEY_SET_VALUE) as key:
            winreg.SetValueEx(key, user_sid, 1, winreg.REG_SZ, user_sign_option)


def create_user_profile_dir(win_username: str, win_password: str) -> bool:
    """初始化用户目录（新创建用户时，需要初始化），成功返回True，失败返回False"""
    if get_user_profile_dir(win_username, win_password) == '':
        stdout = run_cmd(f'{PSEXEC_EXE} -u {win_username} -p {win_password} -accepteula -nobanner cmd.exe /c exit')
        logging.info(stdout)
        return get_user_profile_dir(win_username, win_password) != ''
    return True


def create_user(win_username: str, win_password: str):
    """新建RPA用户，并设置用户组"""
    if is_user_exists(win_username) is False:  # 查询用户是否存在
        run_cmd(f'net user {win_username} {win_password} /add /expires:never')  # 创建用户，且用户永不过期（360告警）
        if is_user_exists(win_username) is False:
            logging.error('rpa用户创建不成功')
            raise Exception('rpa用户创建不成功')
    else:
        logging.info(f'{win_username}用户已存在')
    active_user(win_username)  # 启用用户
    run_cmd(f'wmic UserAccount where "Name=\'{win_username}\'" set PasswordExpires=False')  # 设置用户密码永不过期
    # if username in run_cmd(f'net localgroup Users'):
    #     run_cmd(f'net localgroup Users {username} /delete')  # 从Users用户组删除用户(不然用户会出现在登录界面)
    # if username not in run_cmd(f'net localgroup "Remote Desktop Users"'):
    #     run_cmd(f'net localgroup "Remote Desktop Users" {username} /add /homedir:c:/users/{username}')  # 添加用户到远程桌面用户组（360告警）
    if win_username not in run_cmd('net localgroup Administrators'):  # FIXME 会导致关闭所有SAP
        run_cmd(f'net localgroup Administrators {win_username} /add')  # 添加用户到管理员用户组（360告警）
    if create_user_profile_dir(win_username, win_password) is False:
        logging.error('rpa用户profile目录创建失败')
        raise Exception('rpa用户profile目录创建失败')
    else:
        logging.info('rpa用户profile目录创建成功')


def set_user_wallpaper(win_username: str, win_password: str, wallpaper_path: str):
    """设置任意用户桌面壁纸"""
    user_dir = get_user_profile_dir(win_username, win_password)
    ntuser_dat = os.path.realpath(Path(user_dir).joinpath('ntuser.dat').as_posix())
    wallpaper = os.path.realpath(wallpaper_path)
    cmd_open_reg = rf'REG LOAD "HKU\DefUser" "{ntuser_dat}"'
    cmd_add_wallpaper = rf'REG ADD "HKU\DefUser\Control Panel\Desktop" /v "Wallpaper" /d "{wallpaper}" /f'
    cmd_unload_reg = r'REG UNLOAD "HKU\DefUser"'
    cmd_full = f'{cmd_open_reg} && {cmd_add_wallpaper} && {cmd_unload_reg}'
    run_cmd(cmd_full)


def config_user_sap(win_username: str, win_password: str):
    """初始化RPA用户SAP配置"""
    user_dir = get_user_profile_dir(win_username, win_password)
    if user_dir == '':
        raise Exception('rpa用户目录获取错误')
    sap_dir = Path(user_dir).joinpath('AppData/Roaming/SAP/Common')
    sap_dir.mkdir(parents=True, exist_ok=True)
    shutil.copyfile(FILE_SAPLOGON_INI, sap_dir.joinpath('saplogon.ini').as_posix())
    shutil.copyfile(FILE_SAPLOGONTREE_XML, sap_dir.joinpath('SapLogonTree.xml').as_posix())


def setup_rpa_user(win_username: str, win_password: str):
    """初始化RPA用户"""
    import rpa.config
    skip_new_user_privacy_setup()
    # disable_switch_user()
    enable_switch_user()
    create_user(win_username, win_password)
    set_user_wallpaper(win_username, win_password, Path(rpa.config.RESOURCE_DIR).joinpath('images/wallpaper/1920x1080.png').as_posix())
    config_user_sap(win_username, win_password)


def is_user_login(win_username: str) -> bool:
    stdout = run_cmd(f'query user {win_username}')
    return stdout != '' and '没有用户'not in stdout


def is_user_active(win_username: str) -> bool:
    return '运行中' in run_cmd(f'query user {win_username}')


def logoff_user(win_username: str):
    """注销登录"""
    if is_user_login(win_username):
        stdout = run_cmd(f'query user {win_username}')
        result = re.findall(rf'{win_username}\s+[^\s]*\s+(\d+)', stdout)
        if len(result) > 0:
            user_id = result[0]
            run_cmd(f'logoff {user_id}')
            for _ in range(20):
                process_str = run_cmd(f'tasklist /FI "USERNAME eq {win_username}"')
                if "No tasks are running" in process_str or "没有运行的任务" in process_str:
                    break
                sleep(0.5)


def delete_user(win_username: str):
    """删除用户"""
    if is_user_exists(win_username):
        logoff_user(win_username)
        run_cmd(f'net user {win_username} /delete')
        # force_rm user profile dir


def auto_launch_rpa_shell(win_username: str, win_password: str):
    """将rpa_shell.exe复制到rpa用户的启动目录中，并更名为rpa_server.exe"""
    user_dir: str = get_user_profile_dir(win_username, win_password)
    if Path(user_dir).exists() and Path(user_dir).is_absolute():
        startup_dir = Path(user_dir).joinpath('AppData/Roaming/Microsoft/Windows/Start Menu/Programs/Startup').as_posix()
        if Path(startup_dir).joinpath('rpa_server.exe').exists():
            os.remove(Path(startup_dir).joinpath('rpa_server.exe').as_posix())  # 清除旧的启动方式（部分机器上无法启动）
        startup_dir = Path(f'{rpa.config.D_RPA}/Startup').as_posix()  # 添加文件到新的目录
        Path(startup_dir).mkdir(parents=True, exist_ok=True)
        desktop_dir = Path(user_dir).joinpath('Desktop').as_posix()
        Path(startup_dir).mkdir(parents=True, exist_ok=True)
        winreg.CreateKey(winreg.HKEY_LOCAL_MACHINE, r'SOFTWARE\FASTRPA\RPA_SHELL')  # 为避免key不存在打开时报错，要先创建
        with winreg.OpenKey(winreg.HKEY_LOCAL_MACHINE, r'SOFTWARE\FASTRPA\RPA_SHELL', 0, winreg.KEY_QUERY_VALUE) as key:
            try:
                rpa_shell_path: str = winreg.QueryValueEx(key, 'RPA_SHELL_PATH')[0]
                if Path(rpa_shell_path).exists():
                    shutil.copyfile(rpa_shell_path, Path(startup_dir).joinpath('rpa_server.exe').as_posix())
                    shutil.copyfile(rpa_shell_path, Path(desktop_dir).joinpath('退出登录.exe').as_posix())
                else:
                    url_rpa_sehll_exe = 'http://10.133.10.155:19530/fastrpa/rpa_shell.exe'
                    res = requests.get(url_rpa_sehll_exe)
                    if res.status_code == 200:
                        Path(startup_dir).joinpath('rpa_server.exe').write_bytes(res.content)
                        Path(desktop_dir).joinpath('退出登录.exe').write_bytes(res.content)
                    else:
                        raise Exception('rpa_shell下载失败')
                winreg.CreateKey(winreg.HKEY_LOCAL_MACHINE, r'Software\Microsoft\Windows\CurrentVersion\Run')  # 为避免key不存在打开时报错，要先创建
                with winreg.OpenKey(winreg.HKEY_LOCAL_MACHINE, r'Software\Microsoft\Windows\CurrentVersion\Run', 0, winreg.KEY_SET_VALUE) as key:
                    winreg.SetValueEx(key, 'rpa_server', 1, winreg.REG_SZ, os.path.realpath(Path(startup_dir).joinpath('rpa_server.exe').as_posix()))
            except Exception as e:
                logging.error(e)
        if Path(desktop_dir).joinpath('无法返回上个桌面时请执行此程序.exe').exists():
            os.remove(Path(desktop_dir).joinpath('无法返回上个桌面时请执行此程序.exe').as_posix())

    else:
        raise Exception(f'获取{win_username}用户目录失败')


def clear_auto_login():
    winreg.CreateKey(winreg.HKEY_LOCAL_MACHINE, r'SOFTWARE\Microsoft\Windows NT\CurrentVersion\Winlogon')  # 为避免key不存在打开时报错，要先创建
    with winreg.OpenKey(winreg.HKEY_LOCAL_MACHINE, r'SOFTWARE\Microsoft\Windows NT\CurrentVersion\Winlogon', 0, winreg.KEY_SET_VALUE) as key:
        winreg.SetValueEx(key, 'LastUsedUsername', 1, winreg.REG_SZ, "")
        winreg.SetValueEx(key, 'AutoAdminLogon', 1, winreg.REG_SZ, "0")
        for value in ['DefaultUserName', 'DefaultPassword']:
            try:
                winreg.SetValueEx(key, value, 1, winreg.REG_SZ, "")
            except Exception:  # nosec
                pass


def restore_default_login_mode():
    pass  # TODO 将默认的登录方式


def remove_last_used_username():
    winreg.CreateKey(winreg.HKEY_LOCAL_MACHINE, r'SOFTWARE\Microsoft\Windows NT\CurrentVersion\Winlogon')  # 为避免key不存在打开时报错，要先创建
    with winreg.OpenKey(winreg.HKEY_LOCAL_MACHINE, r'SOFTWARE\Microsoft\Windows NT\CurrentVersion\Winlogon', 0, winreg.KEY_SET_VALUE) as key:
        winreg.DeleteKey(key, 'LastUsedUsername')


def lock_screen():
    """电脑锁屏"""
    run_cmd('tsdiscon')


def switch_user(win_username: str, win_password: str):
    """切换到另一个用户（当前用户不注销）"""
    if check_win_login(win_username, win_password) is False:
        raise Exception('用户名或密码错误')
    setup_auto_login(win_username, win_password)  # 设置自动登录
    lock_screen()  # 进入锁屏界面


def wait_user_connected(win_username: str, timeout: int = 60):
    for _ in range(timeout):
        if is_user_active(win_username):
            return
        sleep(1)
    raise Exception(f'用户{win_username}未登录，等待超时')


def get_server_port(win_username: str) -> int:
    """获取rpa用户端口"""
    if is_user_login(win_username) is False:
        raise Exception(f'用户{win_username}未登录')
    cmd_stdout = run_cmd(f'tasklist /FI "USERNAME eq {win_username}"')
    pids = re.findall(r"python.exe .*? (\d+) ", cmd_stdout)
    if len(pids) == 0:
        raise Exception(f'用户{win_username} RPA未启动')
    for pid in pids:
        cmd_stdout = run_cmd(f'cmd.exe /c netstat -aon | findstr "{pid}"')
        ports = re.findall(rf"0.0.0.0:(\d+) .*? {pid}", cmd_stdout)
        for port in ports:
            if int(port) >= 19527:  # 限定端口起始位置
                return int(ports[0])
    else:
        raise Exception(f'用户{win_username}无法找到RPA服务端口')


def launch_server_from_rpa_user(win_username: str, win_password: str, rpa_username: str, rpa_password: str):
    try:
        get_server_port(rpa_username)
        logging.info('RPA服务已启动')
        return  # RPA用户服务已经启动了
    except Exception:  # nosec
        pass
    logoff_user(rpa_username)
    if win_username != get_username():
        logging.error('Windows登录信息验证不通过，请确认用户名是否正确')
        raise Exception('Windows登录信息验证不通过，请确认用户名是否正确')
    if check_win_login(win_username, win_password) is False:
        logging.error('Windows登录信息验证不通过，请确认密码是否正确')
        raise Exception('Windows登录信息验证不通过，请确认密码是否正确')
    if is_user_login(rpa_username) is False:
        logging.error('初始化用户配置')
        setup_rpa_user(rpa_username, rpa_password)
    with keep_user_sign_option(win_username):
        try:
            auto_launch_rpa_shell(rpa_username, rpa_password)
            winreg.CreateKey(winreg.HKEY_LOCAL_MACHINE, r'SOFTWARE\FASTRPA\RPA_SHELL')  # 为避免key不存在打开时报错，要先创建
            with winreg.OpenKey(winreg.HKEY_LOCAL_MACHINE, r'SOFTWARE\FASTRPA\RPA_SHELL', 0, winreg.KEY_SET_VALUE) as key:
                winreg.SetValueEx(key, 'DefaultUserName', 1, winreg.REG_SZ, win_username)  # 默认用户名
                winreg.SetValueEx(key, 'DefaultPassword', 1, winreg.REG_SZ, win_password)  # 默认密码
            setup_auto_login(rpa_username, rpa_password)
            lock_screen()  # 锁屏，自动登录RPA用户
            logging.info('等待rpa用户登录（默认90秒）')
            wait_user_connected(rpa_username)  # 等待rpa用户登录（默认90秒）
            logging.info('rpa用户已登录')
            sleep(3)
            logging.info('等待win用户登录（默认90秒）')
            setup_auto_login(win_username, win_password)
            logging.info('等待切回win用户（默认90秒）')
            wait_user_connected(win_username)  # 等待切回win用户（默认90秒）
            logging.info('win用户已登录')
        except Exception as e:
            logging.error(e)
    clear_auto_login()
    logging.info('尝试获取rpa服务端口')
    for _ in range(10):
        try:
            get_server_port(rpa_username)
            break
        except Exception:
            sleep(1)
    else:
        logging.error('尝试5次仍无法获取rpa服务端口')
        get_server_port(rpa_username)
    logging.info('获取rpa服务端口成功')


def open_user_accounts():
    """打开控制面板用户设置页面"""
    if platform.platform().lower().startswith('windows-10'):
        os.system('start ms-settings:yourinfo')  # nosec win10
    else:
        os.system('start control userpasswords')  # nosec win7


if __name__ == '__main__':
    from rpa.fastrpa.log import config
    config()
    # launch_server_from_rpa_user('mengzhao', 'R33TtuTGqHV', 'fastrpa', 'R33TtuTGqHV')
    create_user('rpa', 'hello')
    auto_launch_rpa_shell('rpa', 'hello')
