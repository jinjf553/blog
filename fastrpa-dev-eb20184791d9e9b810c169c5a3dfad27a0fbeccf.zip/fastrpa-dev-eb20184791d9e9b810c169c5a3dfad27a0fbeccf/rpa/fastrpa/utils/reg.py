import winreg


def show_seconds_in_system_clock():
    """任务栏日期显示到秒"""
    with winreg.OpenKey(winreg.HKEY_CURRENT_USER, r"SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer\Advanced", 0, winreg.KEY_SET_VALUE) as key:
        # [X] 辅助功能与脚本>脚本>启用脚本
        winreg.SetValueEx(key, "ShowSecondsInSystemClock", 1, winreg.REG_DWORD, 1)


def system_ftp_no_pasv():
    with winreg.OpenKey(winreg.HKEY_CURRENT_USER, r"SOFTWARE\Microsoft\FTP", 0, winreg.KEY_SET_VALUE) as key:
        # [X] 辅助功能与脚本>脚本>启用脚本
        winreg.SetValueEx(key, "Use PASV", 1, winreg.REG_SZ, "no")
        winreg.SetValueEx(key, "Use Web Based FTP", 1, winreg.REG_SZ, "no")
