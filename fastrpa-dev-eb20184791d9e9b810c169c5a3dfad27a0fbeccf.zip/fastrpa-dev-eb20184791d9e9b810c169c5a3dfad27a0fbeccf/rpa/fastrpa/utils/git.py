import rpa.config
from rpa.fastrpa.utils.run_cmd import run_cmd


def get_lastest_git_commit_head() -> str:
    """获取打包时git commit信息，写入sitecustomize.py，执行事件时会先打印commit"""
    return run_cmd('git log --pretty=format:"%ai %h %an" -n1', rpa.config.WORKING_DIR)
