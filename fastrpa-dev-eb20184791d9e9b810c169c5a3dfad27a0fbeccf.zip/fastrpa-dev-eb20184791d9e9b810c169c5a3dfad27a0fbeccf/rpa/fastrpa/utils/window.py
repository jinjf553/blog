"""辅助函数库：窗口函数"""
import logging
import operator
import platform
import time
from pathlib import Path
from threading import Thread
from typing import Dict, Optional, Tuple

import pywintypes
import rpa.config
import win32api
import win32com.client
import win32con
import win32gui
from rpa.fastrpa.com import NEW_THREAD_USE_COM
from rpa.fastrpa.utils.peek_encoding import bytes_to_utf8
from rpa.fastrpa.utils.system_dir import get_desktop_dir
from win32com.shell import shell


def restore_window(hwnd: int):
    try:
        shell = win32com.client.Dispatch("WScript.Shell")
        shell.SendKeys('%')
        if win32gui.GetWindowPlacement(hwnd)[1] == win32con.SW_SHOWMINIMIZED:  # 如果窗口处于最小化状态
            win32gui.SendMessage(hwnd, win32con.WM_SYSCOMMAND, win32con.SC_RESTORE, 0)  # 能够从最小化恢复，如果不是最小化，会将窗口调整为默认状态
        win32gui.SetForegroundWindow(hwnd)  # 窗口到最前，窗口最小化时无效，可重复执行
    except Exception:  # nosec
        pass


def show_window(hwnd: int, cmd_show: int = win32con.SW_SHOWNORMAL):
    """显示窗口(默认将窗口从最小化恢复)"""
    win32gui.ShowWindow(hwnd, cmd_show)


def click_allow(class_name=None, window_name=u"SAP GUI 安全性", repeat_times=120) -> None:
    """查找对应类或窗口标题，如发现则点击窗口的确认按钮。"""
    is_clicked = False
    for _ in range(repeat_times):
        dialog = win32gui.FindWindow(class_name, window_name)  # 对话框
        if dialog:
            button = win32gui.FindWindowEx(dialog, 0, 'Button', "&Allow")  # 确定按钮Button
            if not button:
                button = win32gui.FindWindowEx(dialog, 0, 'Button', "允许(&A)")  # 确定按钮Button
            win32gui.PostMessage(button, win32con.WM_LBUTTONDOWN, win32con.MK_LBUTTON, 0)
            win32gui.PostMessage(button, win32con.WM_LBUTTONUP, win32con.MK_LBUTTON, 0)
            is_clicked = True
            time.sleep(0.5)
        elif is_clicked is True:
            break
        time.sleep(0.5)


def pass_sapgui_err_window() -> None:  # 如不关闭，会阻塞SAP运行
    """查找对应类或窗口标题，如发现则点击窗口的确认按钮。"""
    while True:
        try:
            for window_name in [u'SAP GUI for Windows 730', u'SAP GUI for Windows 740', u'SAP GUI for Windows 750']:
                dialog = win32gui.FindWindow(None, window_name)  # 对话框
                if dialog:
                    win32gui.PostMessage(dialog, win32con.WM_CLOSE, 0, 0)
        except Exception:  # nosec
            pass
        time.sleep(5)


def fill_upload_file_window(file_path, classs, text):
    """查找输入框（第一个循环确保找到窗口句柄，第二个循环确保窗口被pass）"""
    # logging.info(f'寻找类为【{classs}】，窗口标题为【{text}】对话框')
    for _ in range(120):
        time.sleep(0.5)
        dialog = win32gui.FindWindow(classs, text)  # 对话框
        if dialog:
            break
    else:
        logging.error(f'未找到{classs}-{text}对话框')
        return
    for _ in range(15):
        dialog = win32gui.FindWindow(classs, text)  # 对话框
        if dialog:
            # logging.info(f'找到{classs}-{text}对话框')
            combo_box_ex_32 = win32gui.FindWindowEx(dialog, 0, 'ComboBoxEx32', None)
            combo_box = win32gui.FindWindowEx(combo_box_ex_32, 0, 'ComboBox', None)
            edit = win32gui.FindWindowEx(combo_box, 0, 'Edit', None)  # 上面三句依次寻找对象，直到找到输入框Edit对象的句柄
            # logging.info(f'找到Edit句柄：{edit}')
            button = win32gui.FindWindowEx(dialog, 0, 'Button', None)  # 确定按钮Button
            time.sleep(1)
            ret_code = win32gui.SendMessage(edit, win32con.WM_SETTEXT, 0, f'"{file_path}"')  # 往输入框输入绝对地址
            logging.info(f'填充文件路径{file_path}，返回值：{ret_code}')
            time.sleep(1)
            # size = win32gui.SendMessage(edit, win32con.WM_GETTEXTLENGTH, 0, 0) + 1  # 要加上截尾的字节
            # str_buffer = win32gui.PyMakeBuffer(size)  # 生成buffer对象
            # win32gui.SendMessage(edit, win32con.WM_GETTEXT, size, str_buffer)  # 获取buffer
            # address, length = win32gui.PyGetBufferAddressAndLen(str_buffer)
            # edit_text = win32gui.PyGetString(address, length)
            # if Path(edit_text).exists() is False:
            #     logging.info(f"上载文件不存在：{edit_text}, 源文件路径：{file_path}")
            # logging.info(f"文件名(N): {edit_text}")
            ret_code = win32gui.SendMessage(dialog, win32con.WM_COMMAND, 1, button)  # 按button
            # logging.info(f'SendMessage点击确认按钮{button}，返回值：{ret_code}')
            time.sleep(0.5)
            continue
        break
    else:
        logging.error(f'{classs}-{text}对话框关闭失败')


def pass_excel_compatibility_checker():
    """Microsoft Excel - 兼容性检查器"""
    # TODO 找到永久关闭兼容性检查的办法
    for _ in range(240):
        dialog = win32gui.FindWindow("NUIDialog", "Microsoft Excel - 兼容性检查器")
        if dialog:
            _ui = win32gui.FindWindowEx(dialog, 0, 'NetUIHWND', None)
            win32api.PostMessage(_ui, win32con.WM_KEYDOWN, ord('H'), 0)  # 去除勾选[保存此工作簿时检查兼容性(H)]
            win32api.PostMessage(_ui, win32con.WM_KEYDOWN, win32con.VK_RETURN, 0)  # 发送回车键
            win32api.PostMessage(_ui, win32con.WM_KEYUP, win32con.VK_RETURN, 0)
            break
        time.sleep(0.5)


def pass_upload_window(filename, title=u'选择上传文件'):
    """上传文件弹出窗口填入路径并点击确定"""
    _t = Thread(target=pass_excel_compatibility_checker)
    _t.setDaemon(True)
    _t.start()
    _t1 = Thread(target=fill_upload_file_window, args=(filename, None, title))
    _t1.setDaemon(True)
    _t1.start()


def get_windws_list() -> Dict[int, str]:
    """获取窗口列表"""
    hwnd_dict: Dict[int, str] = {}
    system_version = platform.platform()
    if system_version.lower()[:9] == 'windows-7':  # windows 7系统 EnumWindows 会卡住
        return {}
    win32gui.EnumWindows(lambda hWnd, param: param.update({hWnd: win32gui.GetWindowText(hWnd)}), hwnd_dict)
    return hwnd_dict


def fuzz_search_window(title) -> Dict[int, str]:
    """根据title模糊搜索hwnd-title

    Args:
        title ([type]): 窗口标题要的文本

    Returns:
        Dict[int, str]: hwnd: title的键对
    """
    hwnd_dict: Dict[int, str] = get_windws_list()
    return {_hwnd: _title for _hwnd, _title in hwnd_dict.items() if title in _title}


def get_screen_0_pixel() -> Tuple[int, int]:
    """获取屏幕区域宽高"""
    screen_0_x: int = win32api.GetSystemMetrics(win32con.SM_CXFULLSCREEN)
    screen_0_y: int = win32api.GetSystemMetrics(win32con.SM_CYFULLSCREEN)
    return screen_0_x, screen_0_y  # 对于1080P屏幕，值为1920*1017


def move_window_to_screen(hwnd: Optional[int] = None, screen_idx: int = 0) -> bool:
    """将窗口挪至指定屏幕"""
    return True  # TODO 待完善
    # screen_left = 1920 * screen_idx
    # screen_top = 0
    # width, height = get_screen_0_pixel()
    # repaint = True
    # try:
    #     win32gui.MoveWindow(hwnd, screen_left, screen_top, width, height, repaint)  # 为了保证能录制到SAP屏幕，将SAP窗口挪至此位置
    #     return True
    # except Exception:
    #     return False


def activate_window(hwnd: int) -> bool:
    """激活窗口"""
    try:
        with NEW_THREAD_USE_COM():
            shell = win32com.client.Dispatch("WScript.Shell")
            shell.SendKeys('%')
    except Exception:  # nosec
        pass
    try:
        win32gui.SetForegroundWindow(hwnd)
        return True
    except pywintypes.error:  # pylint: disable=fixme, no-member
        return False


def message_box_ok(hwnd: Optional[int] = None, message: str = '', title: str = '') -> None:
    """弹出消息确认框"""
    try:
        win32api.MessageBox(hwnd, message, title, win32con.MB_OK)
    except pywintypes.error:  # pylint: disable=fixme, no-member
        pass


def message_box_okcancel(hwnd: Optional[int] = None, message: str = '', title: str = '') -> bool:
    """弹出消息确认框"""
    try:
        if win32gui.MessageBox(hwnd, message, title, win32con.MB_OKCANCEL) == 1:  # 确认
            return True
        else:
            return False
    except pywintypes.error:  # pylint: disable=fixme, no-member
        return False


def get_open_file_name(hwnd: Optional[int] = None, init_dir=get_desktop_dir(), filter_str='Excel 文件（*.xlsx）\x00*.xlsx\x00') -> str:
    """打开文件对话框"""
    init_dir = rpa.config.D_RPA if init_dir is None else init_dir
    try:
        fname, _, _ = win32gui.GetOpenFileNameW(hwnd, InitialDir=init_dir, Filter=filter_str)
        return Path(fname).as_posix()
    except pywintypes.error:  # pylint: disable=fixme, no-member
        return ''


def get_save_as_file_name(hwnd: Optional[int] = None, init_dir=get_desktop_dir(), filter_str='Excel 文件（*.xlsx）\x00*.xlsx\x00', default_filename: str = '') -> str:
    """保存文件对话框"""
    init_dir = rpa.config.D_RPA if init_dir is None else init_dir
    try:
        fname, _, _ = win32gui.GetSaveFileNameW(hwnd, InitialDir=init_dir, Filter=filter_str, File=default_filename)
        if not fname.endswith('.xlsx'):
            fname = fname + '.xlsx'
        return Path(fname).as_posix()
    except pywintypes.error:  # pylint: disable=fixme, no-member
        return ''


def set_topmost(hwnd: Optional[int] = None, is_topmost: bool = True) -> bool:
    """设置窗口最前"""
    try:
        left, top, right, bottom = win32gui.GetWindowRect(hwnd)
        width = right - left
        height = bottom - top
        insert_after = win32con.HWND_TOPMOST if is_topmost is True else win32con.HWND_NOTOPMOST
        win32gui.SetWindowPos(hwnd, insert_after, left, top, width, height, 0)
        return True
    except pywintypes.error:  # pylint: disable=fixme, no-member
        return False


def set_alpha(hwnd: int, alpha: int = 255) -> bool:
    """设置窗口透明度，alpha为0~255之间的值，默认为255，不透明"""
    try:
        hwnd_style = win32gui.GetWindowLong(hwnd, win32con.GWL_EXSTYLE)
        win32gui.SetWindowLong(hwnd, win32con.GWL_EXSTYLE, operator.ior(hwnd_style, win32con.WS_EX_LAYERED))
        win32gui.SetLayeredWindowAttributes(hwnd, 0, alpha, win32con.LWA_ALPHA)
        return True
    except Exception:
        return False


def find_window(class_name: Optional[str] = None, title: Optional[str] = None) -> int:
    """查找窗口句柄"""
    try:
        return win32gui.FindWindow(class_name, title)
    except pywintypes.error:  # pylint: disable=fixme, no-member
        return 0


def maximum_window(hwnd: int):
    """最大化窗口"""
    win32gui.ShowWindow(hwnd, win32con.SW_MAXIMIZE)


def disable_max_button(hwnd: int, is_disable: bool = True):
    """禁用最大化按钮"""
    hwnd_style = win32gui.GetWindowLong(hwnd, win32con.GWL_STYLE)
    new_hwnd_style = operator.ior(hwnd_style, win32con.WS_MAXIMIZEBOX)
    if is_disable is True:
        new_hwnd_style = operator.ixor(new_hwnd_style, win32con.WS_MAXIMIZEBOX)
    win32gui.SetWindowLong(hwnd, win32con.GWL_STYLE, new_hwnd_style)


def disable_resize_window(hwnd: int, is_disable: bool = True):
    """禁止调节窗口大小"""
    hwnd_style = win32gui.GetWindowLong(hwnd, win32con.GWL_STYLE)
    new_hwnd_style = operator.ior(hwnd_style, win32con.WS_THICKFRAME)
    if is_disable is True:
        new_hwnd_style = operator.ixor(new_hwnd_style, win32con.WS_THICKFRAME)
    win32gui.SetWindowLong(hwnd, win32con.GWL_STYLE, new_hwnd_style)


def set_window_icon(hwnd: int, icon_path: str):
    """设置窗口图标"""
    h_module = win32api.GetModuleHandle(None)
    h_icon = win32gui.LoadImage(h_module, icon_path, win32con.IMAGE_ICON, 0, 0, win32con.LR_LOADFROMFILE | win32con.LR_CREATEDIBSECTION)
    win32api.SendMessage(hwnd, win32con.WM_SETICON, win32con.ICON_BIG, h_icon)
    win32api.SendMessage(hwnd, win32con.WM_SETICON, win32con.ICON_SMALL, h_icon)
    # win32gui.DestroyIcon(h_icon)


def get_window_class_name(hwnd: int) -> str:
    try:
        return win32gui.GetClassName(hwnd)
    except Exception:
        return ''


def open_dir(hwnd: int) -> str:
    pidl, display_name, image_list = shell.SHBrowseForFolder(
        hwnd,  # win32gui.GetDesktopWindow(),
        [],
        "选择一个文件夹",
        0,
        None,
        None
    )
    try:
        dir_bytes: bytes = shell.SHGetPathFromIDList(pidl)
        dir_str = bytes_to_utf8(dir_bytes)
    except Exception:
        raise Exception('请选择有效的文件路径')
    if Path(dir_str).is_dir() is True and Path(dir_str).exists() is True:
        return Path(dir_str).as_posix()
    else:
        return ''


if __name__ == "__main__":
    from rpa.fastrpa.log import config
    config()
