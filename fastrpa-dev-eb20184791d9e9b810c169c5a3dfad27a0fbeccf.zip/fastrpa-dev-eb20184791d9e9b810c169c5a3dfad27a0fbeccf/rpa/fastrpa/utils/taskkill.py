import logging
import subprocess

from rpa.fastrpa.net import get_username


def taskkill(exe_name: str, log_flag=False):
    """强制终止进程"""
    if log_flag is True:
        logging.info(f'taskkill {exe_name}')
    try:
        subprocess.call(f'CMD /C "@taskkill /F /FI \"USERNAME eq {get_username()}\" /IM \"{exe_name}\" >nul 2>&1"', timeout=5)
        subprocess.call(f'CMD /C "@taskkill /F /FI \"USERNAME eq {get_username()}\" /IM \"{exe_name}\" >nul 2>&1"', timeout=5)  # 超时未关闭再次尝试
    except Exception:
        pass


if __name__ == '__main__':
    taskkill('saplogon.exe')
