import win32api
from rpa.fastrpa.utils.taskkill import taskkill


def restart_explorer():
    """强制重启explorer.exe，有刷新托盘图标的作用"""
    taskkill('explorer.exe')
    win32api.ShellExecute(0, 'open', 'explorer.exe', '', '', 1)
