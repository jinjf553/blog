import os
import shutil
import sys
from pathlib import Path
from time import sleep


def _clean(temp_dir, exclude_dir):
    sleep(30)
    try:
        for file in Path(temp_dir).rglob('_MEI*'):
            if file.is_dir() is True:
                filepath = file.as_posix()
                if exclude_dir == '' or filepath != exclude_dir:
                    try:
                        shutil.rmtree(filepath)
                    except Exception as e:
                        pass
    except Exception:
        pass


def clean_pyinstaller_cache():
    """启动新线程清理临时目录下pyinstaller缓存文件"""
    if hasattr(sys, '_MEIPASS'):
        temp_dir = Path(sys._MEIPASS).parent.as_posix()  # pylint: disable=fixme, no-member
        exclude_dir = Path(sys._MEIPASS).as_posix()  # pylint: disable=fixme, no-member
    elif 'TEMP' in os.environ.keys():
        temp_dir = Path(os.environ['TEMP'])
        exclude_dir = ''
    elif 'TMP' in os.environ.keys():
        temp_dir = Path(os.environ['TMP'])
        exclude_dir = ''
    else:
        return
    _clean(temp_dir, exclude_dir)


if __name__ == '__main__':
    clean_pyinstaller_cache()
