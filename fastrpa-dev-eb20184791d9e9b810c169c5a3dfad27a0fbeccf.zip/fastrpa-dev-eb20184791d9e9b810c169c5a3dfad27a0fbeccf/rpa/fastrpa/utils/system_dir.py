import ctypes
from ctypes.wintypes import MAX_PATH
from pathlib import Path
from typing import Optional

from win32comext.shell.shellcon import CSIDL_DESKTOP, CSIDL_PERSONAL

SHGFP_TYPE_CURRENT = 0


def get_system_dir(csidl: int) -> Optional[str]:
    """获取系统文件夹路径"""
    try:
        buf = ctypes.create_unicode_buffer(MAX_PATH)
        ctypes.windll.shell32.SHGetFolderPathW(None, csidl, None, SHGFP_TYPE_CURRENT, buf)
        documnet_dir: str = buf.value
        if documnet_dir.startswith('/'):
            return None
        else:
            return Path(documnet_dir).as_posix()
    except Exception:
        return None


def get_document_dir() -> Optional[str]:
    """获取我的文档路径"""
    return get_system_dir(CSIDL_PERSONAL)


def get_desktop_dir() -> Optional[str]:
    """获取桌面路径"""
    return get_system_dir(CSIDL_DESKTOP)
