import os
import shutil
import sys


def fix_tkinter_path():
    tcl_path = [os.path.dirname(x) for x in sys.path if x.endswith(".zip")][0]
    if not os.path.exists(tcl_path + "/lib/tcl8.6"):
        shutil.copytree(tcl_path + "/tcl/tcl8.6", tcl_path + "/lib/tcl8.6")
    if not os.path.exists(tcl_path + "/lib/tk8.6"):
        shutil.copytree(tcl_path + "/tcl/tk8.6", tcl_path + "/lib/tk8.6")
