import logging
import os
import subprocess  # nosec
from pathlib import Path
from typing import Dict, Optional, Union

from rpa.fastrpa.utils.peek_encoding import peek_bytes_encoding


def create_env(env: Dict[str, str] = {}):
    """创建新的虚拟环境"""
    new_env = os.environ.copy()
    new_env.update(env)
    return new_env


def run_cmd(cmd_line: str, cwd: Optional[str] = None, collect_output=True, wait_for_end=True, env: Dict[str, str] = {}, islog=False) -> Union[int, str, subprocess.Popen]:
    """执行cmd命令

    Args:
        cmd_line (str): 命令行参数
        cwd (Optional[str], optional): 执行目录，默认为x:/rpa/temp
        collect_output (bool, optional): 是否收集控制台输出结果
        wait_for_end (bool, optional): 是否等待结束

    Raises:
        Exception: cwd路径不存在时，报错

    Returns:
        Union[int, str, subprocess.Popen]: collect_output=True wait_for_end=True时返回str类型
                                           collect_output=False wait_for_end=True时返回int类型
                                           collect_output=False wait_for_end=False时返回subprocess.Popen类型
    """
    if cwd is not None and Path(cwd).exists() is False:
        raise Exception(f'{cwd}不存在')
    merged_env = create_env(env)
    if collect_output is True:
        p = subprocess.Popen(cmd_line, cwd=cwd, env=merged_env, shell=True, start_new_session=True, stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=subprocess.PIPE)  # nosec
        if p.stdout is not None:
            _bytes = p.stdout.read()
            _encoding = peek_bytes_encoding(_bytes)
            stdout_str = _bytes.decode(_encoding)
        else:
            stdout_str = ''
        if islog:
            logging.info(stdout_str)
        return stdout_str
    elif wait_for_end is True:
        p = subprocess.Popen(cmd_line, cwd=cwd, env=merged_env)  # nosec
        p.communicate()
        if islog:
            logging.info(p.returncode)
        return p.returncode
    else:
        p = subprocess.Popen(cmd_line, cwd=cwd, env=merged_env, shell=True, start_new_session=True, stdout=None, stderr=None)  # nosec
        return p


if __name__ == '__main__':
    print(run_cmd('query user fastrpa'))
