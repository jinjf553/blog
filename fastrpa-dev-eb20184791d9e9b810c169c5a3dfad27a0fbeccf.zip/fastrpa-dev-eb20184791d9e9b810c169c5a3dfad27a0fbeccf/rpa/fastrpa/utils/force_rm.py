import os
import shutil
import stat
from pathlib import Path


def force_rm(filename: str) -> bool:
    """删除文件或目录
      （shutil.rmtree删除非只读文件报错，不能删除文件，os.remove只能删除文件，这里抽象下，能删除各种类型的文件）
    """
    is_delete_succ = True

    def _readonly_handler(func, path, execinfo):
        try:
            os.chmod(path, stat.S_IWRITE)
            os.remove(path)
        except Exception as e:
            print(path)
            is_delete_succ = False
    _f = Path(filename)
    try:
        if _f.exists():
            if _f.is_absolute():
                if _f.is_dir():
                    shutil.rmtree(Path(filename), onerror=_readonly_handler)
                    return is_delete_succ
                else:
                    os.chmod(filename, stat.S_IWRITE)
                    os.remove(filename)
            else:
                return False
        return True
    except Exception as e:
        print(e)
        return False
