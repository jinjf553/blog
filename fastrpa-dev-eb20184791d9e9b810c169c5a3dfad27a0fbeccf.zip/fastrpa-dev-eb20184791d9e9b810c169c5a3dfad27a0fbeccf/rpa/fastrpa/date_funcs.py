import datetime
import winreg
from typing import Optional

from dateutil import relativedelta  # type: ignore
from rpa.fastrpa.utils.run_cmd import run_cmd


def sync_sys_time(auto_time=True, auto_zone=True):
    """同步系统时间，默认服务器为time.windows.com"""
    winreg.CreateKey(winreg.HKEY_LOCAL_MACHINE, r'SYSTEM\CurrentControlSet\Services\W32Time\Parameters')
    with winreg.OpenKey(winreg.HKEY_LOCAL_MACHINE, r'SYSTEM\CurrentControlSet\Services\W32Time\Parameters', 0, winreg.KEY_SET_VALUE) as key:
        if auto_time is True:
            winreg.SetValueEx(key, 'Type', 1, winreg.REG_SZ, "NTP")  # 自动设置时间
        else:
            winreg.SetValueEx(key, 'Type', 1, winreg.REG_SZ, "NoSync")  # 不自动设置时间
    winreg.CreateKey(winreg.HKEY_LOCAL_MACHINE, r'SYSTEM\CurrentControlSet\Services\tzautoupdate')
    with winreg.OpenKey(winreg.HKEY_LOCAL_MACHINE, r'SYSTEM\CurrentControlSet\Services\tzautoupdate', 0, winreg.KEY_SET_VALUE) as key:
        if auto_zone is True:
            winreg.SetValueEx(key, 'Start', 1, winreg.REG_DWORD, 3)  # 自动设置时间
        else:
            winreg.SetValueEx(key, 'Start', 1, winreg.REG_DWORD, 4)  # 自动设置时间
    run_cmd('sc config W32Time start=auto')  # 设置Windows Time服务为启动
    run_cmd('net start W32Time')  # 启动Windows Time服务


def valid_date(yyyymmdd: str) -> bool:
    """验证date是否为合法的yyyyMMdd日期"""
    try:
        datetime.datetime.strptime(yyyymmdd, "%Y%m%d")
        return len(yyyymmdd) == 8
    except Exception:
        return False


def hhmmss() -> str:
    """返回时分秒"""
    return datetime.datetime.now().strftime(r'%H%M%S')


def to_yyyymmdd(date: str) -> str:
    """将SAP日期转化为标准的8位日期
       已要求个人SAP账号日期格式必须为YYYY/MM/DD、YYYY.MM.DD、YYYY-MM-DD三者之一
       设置方法：系统->用户参数文件->个人数据->默认->Datumsdarstellung->YYYY/MM/DD
    """
    return date.strip().replace('.', '').replace('/', '').replace('-', '')


def today_yyyymmdd() -> str:
    """今天"""
    return datetime.datetime.now().strftime(r'%Y%m%d')


def day_before(yyyymmdd: str, n: int) -> str:
    return (datetime.datetime.strptime(yyyymmdd, "%Y%m%d") + datetime.timedelta(days=-n)).strftime('%Y%m%d')


def day_after(yyyymmdd: str, n: int) -> str:
    return (datetime.datetime.strptime(yyyymmdd, "%Y%m%d") + datetime.timedelta(days=n)).strftime('%Y%m%d')


def month_01(yyyymm_or_yyyymmdd: Optional[str] = None) -> str:
    """本月1号"""
    if yyyymm_or_yyyymmdd is not None:
        yyyymm = yyyymm_or_yyyymmdd[:6]
    else:
        yyyymm = today_yyyymmdd()[:6]
    return datetime.datetime.strptime(yyyymm, "%Y%m").strftime('%Y%m01')


def month_end(yyyymm_or_yyyymmdd: Optional[str] = None) -> str:
    """返回月末日期"""
    if yyyymm_or_yyyymmdd is not None:
        yyyymm = yyyymm_or_yyyymmdd[:6]
    else:
        yyyymm = today_yyyymmdd()[:6]
    return (datetime.datetime.strptime(yyyymm, "%Y%m") + relativedelta.relativedelta(months=1, days=-1)).strftime('%Y%m%d')


def prev_day(yyyymmdd: Optional[str] = None) -> str:
    """获取前一天日期"""
    if yyyymmdd is None:
        yyyymmdd = today_yyyymmdd()
    return (datetime.datetime.strptime(yyyymmdd, "%Y%m%d") - datetime.timedelta(days=1)).strftime('%Y%m%d')


def next_day(yyyymmdd: Optional[str] = None) -> str:
    """获取下一天日期"""
    if yyyymmdd is None:
        yyyymmdd = today_yyyymmdd()
    return (datetime.datetime.strptime(yyyymmdd, "%Y%m%d") + datetime.timedelta(days=1)).strftime('%Y%m%d')


def next_month_01(yyyymm_or_yyyymmdd: Optional[str] = None) -> str:
    """下月1号"""
    if yyyymm_or_yyyymmdd is not None:
        yyyymm = yyyymm_or_yyyymmdd[:6]
    else:
        yyyymm = today_yyyymmdd()[:6]
    return (datetime.datetime.strptime(yyyymm, "%Y%m") + relativedelta.relativedelta(months=1)).strftime('%Y%m01')


def next_month_end(yyyymm_or_yyyymmdd: Optional[str] = None) -> str:
    """返回月末日期"""
    if yyyymm_or_yyyymmdd is not None:
        yyyymm = yyyymm_or_yyyymmdd[:6]
    else:
        yyyymm = today_yyyymmdd()[:6]
    return (datetime.datetime.strptime(yyyymm, "%Y%m") + relativedelta.relativedelta(months=2, days=-1)).strftime('%Y%m%d')


def prev_month_01(yyyymm_or_yyyymmdd: Optional[str] = None) -> str:
    """下月1号"""
    if yyyymm_or_yyyymmdd is not None:
        yyyymm = yyyymm_or_yyyymmdd[:6]
    else:
        yyyymm = today_yyyymmdd()[:6]
    return (datetime.datetime.strptime(yyyymm, "%Y%m") + relativedelta.relativedelta(months=-1)).strftime('%Y%m01')


def prev_month_end(yyyymm_or_yyyymmdd: Optional[str] = None) -> str:
    """返回月末日期"""
    if yyyymm_or_yyyymmdd is not None:
        yyyymm = yyyymm_or_yyyymmdd[:6]
    else:
        yyyymm = today_yyyymmdd()[:6]
    return prev_day(month_01(yyyymm))


if __name__ == '__main__':
    print(day_before(today_yyyymmdd(), 3))
