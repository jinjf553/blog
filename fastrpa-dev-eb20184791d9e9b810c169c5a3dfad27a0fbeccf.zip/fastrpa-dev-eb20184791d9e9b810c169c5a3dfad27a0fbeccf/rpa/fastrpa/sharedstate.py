from multiprocessing.shared_memory import SharedMemory
from typing import Optional


class SharedState(object):
    sm: SharedMemory

    def __init__(self, name: str, value: Optional[str] = None, size: int = 0):
        if name.isidentifier() is False:
            raise ValueError('SHARED_STATE: name必须是合法的标识符名称')
        name = 'RPA_' + name
        if value is not None and size == 0:
            size = len(value)
        if value is not None and size < len(value):
            raise Exception('SHARED_STATE: size小于value长度')
        elif isinstance(value, str) and '\x00' in value:
            raise ValueError('SHARED_STATE: 不能包含\\x00')
        try:
            self.sm = SharedMemory(name, create=True, size=size)
        except (FileExistsError, OSError):
            self.sm = SharedMemory(name, create=False, size=size)
        if value is not None:
            self.value = value

    @property
    def value(self) -> str:
        try:
            return bytes(self.sm.buf).decode('utf-8').replace('\x00', '')
        except Exception:
            return ''

    @value.setter
    def value(self, new_value: str):
        buffer = self.sm.buf
        if buffer.shape[0] < len(new_value):  # pylint: disable=fixme, unsubscriptable-object
            raise Exception('SHARED_STATE: value超过最大长度')
        buffer[:len(new_value)] = bytearray(new_value, 'utf-8')

    def __enter__(self):
        return self

    def __exit__(self, _type, value, traceback):
        self.sm.close()


if __name__ == '__main__':
    ss = SharedState('hello1', 'hello')
    ss.value = "11"
    print(ss.value)
