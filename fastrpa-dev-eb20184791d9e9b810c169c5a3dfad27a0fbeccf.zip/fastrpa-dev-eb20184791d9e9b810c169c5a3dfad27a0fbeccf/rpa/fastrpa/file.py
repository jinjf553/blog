from pathlib import Path

import win32file


def is_file_inuse(filename: str) -> bool:
    """判断文件是否被占用"""
    _p = Path(filename)
    if _p.exists() is True and _p.is_file() is True:
        try:
            vHandle = win32file.CreateFile(filename, win32file.GENERIC_READ, 0, None, win32file.OPEN_EXISTING, win32file.FILE_ATTRIBUTE_NORMAL, None)
            return int(vHandle) == win32file.INVALID_HANDLE_VALUE
        except Exception:  # nosec
            return True
        finally:
            try:
                win32file.CloseHandle(vHandle)
            except Exception:  # nosec
                pass
    return True


if __name__ == '__main__':
    print(is_file_inuse(r"x:\mengzhao\Desktop\无单号-X420-销售建岗-郭运.xlsx"))
