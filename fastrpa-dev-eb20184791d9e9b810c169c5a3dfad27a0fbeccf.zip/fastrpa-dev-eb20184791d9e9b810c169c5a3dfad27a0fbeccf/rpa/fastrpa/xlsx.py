import logging
import os
import pathlib
import shutil
import sys
from pathlib import Path

import win32com.client as win32
from openpyxl.utils import get_column_letter
from rpa.fastrpa.adtable import AdTable, load_from_xlsx_file
from rpa.fastrpa.log import config
from rpa.fastrpa.tempdir import gentempdir
from rpa.fastrpa.utils.taskkill import taskkill
from win32com.client import Dispatch

xlLastCell = 11


def clean_gen_py_dir():
    """清理gen_py文件夹(避免pywin32报错gen_py相关信息)"""
    temp_gen_py_dir = pathlib.Path(str(os.environ.get('Temp'))).joinpath('gen_py')
    if temp_gen_py_dir.exists():
        try:
            shutil.rmtree(temp_gen_py_dir.as_posix())
        except Exception as e:
            logging.warning(e)
    try:
        xl_app = Dispatch('Excel.Application')
        gen_py_dir = Path(sys.modules[xl_app.__module__].__file__).parent.parent.parent
        if gen_py_dir.name == 'gen_py' and gen_py_dir.exists():
            shutil.rmtree(temp_gen_py_dir.as_posix())
    except Exception as e:
        logging.warning(e)


def fix_excel(filename: str):
    """修复openpyxl生成的问题xlsx文件（SAP批导错误） 弃用"""
    return
    logging.info(f'正在尝试修复：\t{os.path.basename(filename)}')
    try:
        clean_gen_py_dir()
        xl_app = Dispatch('Excel.Application')
        xl_app.DisplayAlerts = False
        xl_book = xl_app.Workbooks.Open(filename)
        xl_book.SaveAs(filename, FileFormat=51)
        xl_book.Close(SaveChanges=0)
        del xl_app
    except Exception as e:
        logging.warning(f'文件修复失败，错误原因{e}')


def clear_comments_and_bgcolor_of_file(filename: str, sheet_name=None, skip_header=1, pwd=None):
    """清除xlsx文件批注及背景颜色，默认将活动页，A列值进行清空，skip_header为跳过开始行数"""
    clean_gen_py_dir()
    excel = Dispatch('Excel.Application')
    # excel.Visible = True
    wb = excel.Workbooks.Open(filename)
    if pwd:
        try:
            wb.Unprotect(pwd)
        except Exception as e:
            logging.error(f'文件{filename}密码不正确，解锁失败！')
            raise e
    if wb is None:  # FIXME 已知问题：当同名文件已打开时，wb=None
        excel.Quit()
        del excel
        clean_gen_py_dir()
        excel = Dispatch('Excel.Application')
        wb = excel.Workbooks.Open(filename)
    if sheet_name is not None:
        ws = wb.Sheets(sheet_name)
    else:
        ws = wb.ActiveSheet
    max_row = ws.Cells.SpecialCells(xlLastCell).Row
    try:
        ws.Rows(f'{skip_header+1}:{max_row}').ClearComments()  # 清空批注
        ws.Rows(f'{skip_header+1}:{max_row}').Interior.ColorIndex = -4142  # 清空背景色
    except Exception:
        logging.error(f'文件{filename}被锁定，无法清除批注')
    wb.Save()
    wb.Close()
    excel.Quit()
    del excel


def clear_comments_and_bgcolor(xlsx: AdTable) -> AdTable:
    _skip_header = xlsx.skip_header
    temp_dir = gentempdir()
    filename = xlsx.save_to(temp_dir)
    filename = pathlib.Path(temp_dir).joinpath(filename).as_posix()
    min_column_letter = 'A'
    min_row = xlsx.skip_header + 1
    max_column_letter = get_column_letter(xlsx.ws.max_column)
    max_row = xlsx.ws.max_row
    rng = f'{min_column_letter}{min_row}:{max_column_letter}{max_row}'
    clear_comments_and_bgcolor_of_file(filename, rng)
    return load_from_xlsx_file(filename, skip_header=_skip_header)


def convert_xls_to_xlsx(filename: str):
    # 将xls 转为 xlsx
    if filename.lower().endswith('.xls'):
        logging.info('检测出---附件表扩展名是：xls，将其转为xlsx')
        filename = os.path.realpath(filename)
        kill_excel()
        clean_gen_py_dir()
        excel = win32.gencache.EnsureDispatch('Excel.Application')
        wb = excel.Workbooks.Open(filename)
        filename = filename[:-4] + '.xlsx'
        wb.SaveAs(filename, FileFormat=51)  # FileFormat = 51 is for .xlsx extension
        wb.Close()  # FileFormat = 56 is for .xls extension
        excel.Application.Quit()
        taskkill('Excel.EXE')
    return filename
    # from win32com.client.gencache import EnsureDispatch
    # import sys
    # xl = EnsureDispatch("Word.Application")
    # logging.info(sys.modules[xl.__module__].__file__)


def convert_xlsx_to_xls(filename: str):
    # 将xlsx 转为 xls
    filename = os.path.realpath(filename)
    filename_xls = filename[:-5] + '.xls'
    try:
        taskkill('Excel.EXE')
        if filename.lower().endswith('.xlsx'):
            logging.info('检测出---附件表扩展名是：xlsx，将其转为xls')
            clean_gen_py_dir()
            excel = win32.gencache.EnsureDispatch('Excel.Application')
            excel.DisplayAlerts = False
            wb = excel.Workbooks.Open(filename)
            wb.SaveAs(filename_xls, FileFormat=56)  # FileFormat = 51 is for .xlsx extension
            wb.Close()  # FileFormat = 56 is for .xls extension
            excel.Application.Quit()
            del excel
    except Exception as e:
        logging.info(f"文件{filename}由.xlsx转.xls发生异常{e}，跳过继续执行。")
    taskkill('Excel.EXE')
    return filename_xls, filename


def kill_excel():
    # TODO 先关尝试正常关闭Excel，再强制终止Excel
    taskkill('Excel.exe')


def connect_to_excel(repeat_times=3):
    clean_gen_py_dir()
    excel = Dispatch('Excel.Application')
    if repeat_times == 0:
        return excel
    try:
        excel.DisplayAlerts = False
        return excel
    except Exception:
        kill_excel()
        return connect_to_excel(repeat_times - 1)


if __name__ == '__main__':
    clear_comments_and_bgcolor_of_file(r"E:\HR码表库\调配码表库\人事二组.xlsx")
