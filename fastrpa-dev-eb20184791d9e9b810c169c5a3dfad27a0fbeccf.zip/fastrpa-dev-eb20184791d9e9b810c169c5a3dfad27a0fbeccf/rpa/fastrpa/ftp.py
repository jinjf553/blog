import logging
import pathlib
from typing import List

from rpa.public.myftp import MYFTP


def upload_files(filenames: List[str], ftp_path: str) -> bool:
    """上传一系列文件到ftp路径下"""
    try:
        with MYFTP() as ftp:
            logging.info(f'删除ftp文件路径：{ftp_path}')
            ftp.rmd(ftp_path)  # 删除旧文件
            if isinstance(filenames, str):
                filenames = [filenames]
            for filename in filenames:
                src_filename = pathlib.Path(filename).absolute().as_posix()  # 转化为绝对路径
                ftp_filename = pathlib.Path(ftp_path).joinpath(pathlib.Path(filename).parts[-1]).as_posix()
                logging.info(f'上传文件【{src_filename}】至FTP【{ftp_filename}】')
                ftp.upload_file(src_filename, ftp_filename)  # TODO 待调整FTP库，文件大小相同时不会覆盖
        return True
    except Exception as e:
        logging.info(e)
        return False
