from ctypes import windll

import win32api

hwnd = windll.user32.GetForegroundWindow()
out = windll.kernel32.GetStdHandle(-0xb)  # stdin: 0xa, stdout: 0xb, stderr: 0xc
IS_IN_CONSOLE = bool(windll.kernel32.SetConsoleTextAttribute(out, 0x7))  # 是否处于控制台


def set_close_fn(fn):
    def on_close(sig) -> bool:
        fn()
        return True
    if IS_IN_CONSOLE is True:
        win32api.SetConsoleCtrlHandler(on_close, True)
