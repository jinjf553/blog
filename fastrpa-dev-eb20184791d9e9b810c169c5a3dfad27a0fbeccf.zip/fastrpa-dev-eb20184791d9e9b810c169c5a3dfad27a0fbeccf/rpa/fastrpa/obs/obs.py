import datetime
import logging
import os
import subprocess  # nosec
from os.path import exists, getsize, join
from pathlib import Path
from time import sleep

import rpa.config
import win32con
import win32gui
from rpa.fastrpa.third_party.zip7 import ZIP7_EXE_PATH
from rpa.fastrpa.utils.refresh_tray_pannel import refresh_tray_pannel
from rpa.fastrpa.utils.taskkill import taskkill
from rpa.public.myftp import MYFTP

OBS_RPA_PROFILE_TEXT = Path(__file__).parent.joinpath('rpa.ini').read_text(encoding='utf-8')
OBS_RPA_SCENE_TEXT = Path(__file__).parent.joinpath('rpa.json').read_text(encoding='utf-8')

OBS_PATH = f'{rpa.config.D_RPA}/安装包/OBS-Studio-25.0.8-Full-x64'
OBS_EXE_PATH = f'{OBS_PATH}/bin/64bit/obs64.exe'
OBS_CWD = f'{OBS_PATH}/bin/64bit/'
OBS_RPA_PROFILE = f'{OBS_PATH}/config/obs-studio/basic/profiles/rpa/basic.ini'
OBS_RPA_SCENE = f'{OBS_PATH}/config/obs-studio/basic/scenes/rpa.json'


def write_obs_config(video_filename: str):
    video_output_path = Path(video_filename).parent.as_posix()
    video_filename = Path(video_filename).name[:-4]
    rpa_profile_text = OBS_RPA_PROFILE_TEXT.replace('{此处替换录像文件名}', video_filename)
    rpa_profile_text = rpa_profile_text.replace('{此处替换输出路径}', video_output_path)
    Path(OBS_RPA_PROFILE).parent.mkdir(parents=True, exist_ok=True)
    Path(OBS_RPA_SCENE).parent.mkdir(parents=True, exist_ok=True)
    Path(OBS_RPA_PROFILE).write_text(rpa_profile_text, encoding='utf-8')
    Path(OBS_RPA_SCENE).write_text(OBS_RPA_SCENE_TEXT, encoding='utf-8')
    return Path(video_output_path).joinpath(f'{video_filename}.mkv').as_posix()


def close_obs():
    """查找OBS窗口及托盘图标，并关闭OBS"""
    dialog_obs = 0
    for _ in range(1):
        dialog_obs = win32gui.FindWindow(None, "OBS 25.0.8 (64-bit, windows) - 配置文件: rpa - 场景: rpa")
        if dialog_obs:
            break
        dialog_obs = win32gui.FindWindow(None, "OBS 25.0.8 (64-bit, windows) - Portable Mode - 配置文件: rpa - 场景: rpa")
        if dialog_obs:
            break
        sleep(0.1)
    if dialog_obs:
        win32gui.PostMessage(dialog_obs, win32con.WM_CLOSE, 0, 0)
        for _ in range(100):
            dialog_ask_quit = win32gui.FindWindow(None, "退出OBS?")
            if dialog_ask_quit:
                win32gui.PostMessage(dialog_ask_quit, win32con.WM_QUIT, 0, 0)
                break
            sleep(0.1)
    refresh_tray_pannel()


def run_obs():
    """启动OBS最小化到托盘，并进行录制
       注意：不要直接调用该函数进行录制，因为OBS可能已执行
    """
    subprocess.Popen(f'{OBS_EXE_PATH} -p --profile "rpa" --startrecording --minimize-to-tray', shell=True, cwd=OBS_CWD, start_new_session=True)  # nosec
    for _ in range(20):
        dialog_ask_repeat = win32gui.FindWindow(None, "OBS 已在运行")
        if dialog_ask_repeat:
            taskkill('obs64.exe')
            run_obs()
            break
        else:
            sleep(0.1)


def init_obs() -> None:
    """
        判断本地位置：‘x:/rpa/安装包’下是否存在OBS目录
        不存在时到FTP下载并解压运行
    """
    dir_path, zip_path = f"{rpa.config.D_RPA}/安装包/OBS-Studio-25.0.8-Full-x64", f"{rpa.config.D_RPA}/安装包/OBS-Studio-25.0.8-Full-x64.zip"
    for _ in range(5):
        if exists(dir_path):
            folder_size = sum([sum([getsize(join(r, f)) for f in fs]) for r, ds, fs in os.walk(dir_path)])
            if not (240000000 < folder_size < 270000000):
                if not exists(zip_path) or not (90000000 < getsize(zip_path) < 110000000):
                    with MYFTP() as ftp:
                        ftp.download_file(zip_path, "/安装包/OBS-Studio-25.0.8-Full-x64.zip")
                os.system(f'{ZIP7_EXE_PATH} x "{zip_path}" -o"{os.path.dirname(dir_path)}" -aos -r')  # nosec
            else:
                break
        else:
            if not exists(zip_path) or not (90000000 < getsize(zip_path) < 110000000):
                with MYFTP() as ftp:
                    ftp.download_file(zip_path, "/安装包/OBS-Studio-25.0.8-Full-x64.zip")
            os.system(f'{ZIP7_EXE_PATH} x "{zip_path}" -o"{os.path.dirname(dir_path)}" -aos -r')  # nosec
    else:
        logging.info("OBS初始化失败")


class OBS_REC(object):
    video_filename: str

    def __init__(self, video_filename: str):
        """[summary]

        Args:
            video_filename (str): 录像文件名
        """
        _filename = video_filename
        if Path(video_filename).is_absolute():
            _filename = Path(video_filename).name
        if '.' in _filename:
            _filename = _filename.split('.')[0]
        yyyymm = datetime.datetime.now().strftime(r'%Y%m')
        yyyymmdd = datetime.datetime.now().strftime(r'%Y%m%d')
        hhmmss = datetime.datetime.now().strftime(r'%H%M%S')
        self.video_filename = Path(f'{rpa.config.D_RPA}/录像/{yyyymm}/{yyyymmdd}/{hhmmss}_{_filename}.mkv').as_posix()
        Path(self.video_filename).parent.mkdir(parents=True, exist_ok=True)

    def __enter__(self):
        pass
        taskkill('obs64.exe')
        taskkill('obs.exe')
        try:
            close_obs()
            write_obs_config(self.video_filename)
            if Path(OBS_EXE_PATH).exists() is True:
                run_obs()
                logging.info(f'OBS开始录屏，录像文件名：{self.video_filename}')
            else:
                logging.warning('未检测到OBS，不进行录屏')
        except Exception as e:
            logging.error(f'OBS录屏执行遇到错误：{e}')

    def __exit__(self, exc_type, exc_val, exc_tb):
        pass
        try:
            close_obs()
        except Exception as e:
            logging.error(f'OBS录屏退出遇到错误：{e}')


if __name__ == '__main__':
    from rpa.fastrpa.log import config
    config()
    with OBS_REC('test'):
        sleep(10)  # 录制10秒钟
