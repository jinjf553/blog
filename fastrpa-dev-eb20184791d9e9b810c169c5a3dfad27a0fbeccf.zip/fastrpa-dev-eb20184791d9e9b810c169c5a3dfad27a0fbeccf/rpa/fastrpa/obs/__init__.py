from rpa.fastrpa.obs.obs import OBS_REC, close_obs
