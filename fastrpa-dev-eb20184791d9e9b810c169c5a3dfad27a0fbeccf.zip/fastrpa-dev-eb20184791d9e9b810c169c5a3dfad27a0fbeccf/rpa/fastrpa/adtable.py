"""矩阵表单定位库"""
import logging
import os
import pathlib
import re
import shutil
import sys
from pathlib import Path
from typing import Iterator, List, Union

from openpyxl import Workbook, load_workbook
from openpyxl.comments import Comment
from openpyxl.styles import PatternFill
from openpyxl.styles.colors import Color
from openpyxl.utils import (column_index_from_string, get_column_interval,
                            get_column_letter)
from openpyxl.worksheet.worksheet import Worksheet
from pandas import DataFrame
from rpa.fastrpa.utils.taskkill import taskkill
from win32com.client import Dispatch

# 颜色常量
RED = 'FF0000'  # 红色
BLUE = '0000FF'  # 蓝色
WHITE = 'FFFFFF'  # 白色
GREEN = '00FF00'  # 绿色
PURPLE = 'FF00FF'  # 紫色
PINK = 'FFC0CB'  # 粉红色
LIGHTPINK = 'FFB6C1'  # 浅粉色
ORANGE = 'FFA500'  # 橙色
YELLOW = 'FFFF00'  # 黄色
BLACK = '000000'  # 黑色
CLEAR = Color(rgb='00000000', indexed=None, auto=None, theme=None, tint=0.0, type='rgb')  # 透明


def clean_gen_py_dir():
    """清理gen_py文件夹(避免pywin32报错gen_py相关信息)"""
    temp_gen_py_dir = pathlib.Path(str(os.environ.get('Temp'))).joinpath('gen_py')
    if temp_gen_py_dir.exists():
        try:
            shutil.rmtree(temp_gen_py_dir.as_posix())
        except Exception as e:
            logging.warning(e)
    try:
        xl_app = Dispatch('Excel.Application')
        gen_py_dir = Path(sys.modules[xl_app.__module__].__file__).parent.parent.parent
        if gen_py_dir.name == 'gen_py' and gen_py_dir.exists():
            shutil.rmtree(temp_gen_py_dir.as_posix())
    except Exception as e:
        logging.warning(e)


def fix_excel(filename: str):
    """修复openpyxl生成的问题xlsx文件（SAP批导错误）"""
    taskkill('excel.exe')
    clean_gen_py_dir()
    xl_app = Dispatch('Excel.Application')
    xl_book = xl_app.Workbooks.Open(filename)
    xl_book.Save()
    xl_book.Close(SaveChanges=0)
    del xl_app


def _normalize_column_letter(column: Union[str, int]) -> str:
    """规整化列名，如果是整数，则将其转化为对应列的字母，如果是字母，则转为大写，其余情况抛出异常。"""
    if isinstance(column, int):
        return get_column_letter(column)
    elif isinstance(column, str):
        if column.isalpha():
            return column.upper()
        elif column.isdigit():
            return get_column_letter(int(column))
    raise Exception('column必须为列序号或字母')


class Pos(object):
    column_letter: str
    row_idx: str

    def __init__(self, column: Union[str, int], row: Union[str, int]):
        self.column_letter = _normalize_column_letter(column)
        self.row_idx = str(row)

    def __str__(self):
        return f'{self.column_letter}{self.row_idx}'

    def __repr__(self):
        return f'<Pos:{self.column_letter}{self.row_idx}>'


def _unpack_pos(pos: str) -> Pos:
    result: List[str] = re.findall(r'^([a-zA-Z]+)([0-9]+)$', pos)
    if len(result) == 1:
        column_letter = result[0][0]
        row_rn = result[0][1]
        return Pos(column_letter, row_rn)
    raise Exception(f'坐标点 {pos} 不是合法的格式')


class AdTable(object):
    """表格"""
    filename: str
    wb: Workbook
    ws: Worksheet
    skip_header: int

    def __repr__(self):
        return f'<AdTable {self.filename}.xlsx>'

    def __init__(self, filename: str, wb=None, ws=None, skip_header=1):
        if wb is None:
            wb = Workbook()
            if ws is None:
                ws = wb.active
        self.filename = filename
        self.wb = wb
        self.ws = ws
        self.skip_header = skip_header
        for cell in self.cells:
            cell.value = cell.value  # 初始化内容

    def __iter__(self) -> Iterator:
        _rows = [AdTableRow(self.filename, self.wb, self.ws, self.skip_header, r)
                 for r in range(1 + self.skip_header, 1 + self.ws.max_row)]
        return iter(_rows)

    def __getitem__(self, column: Union[str, int]):
        return AdTableColumn(self.filename, self.wb, self.ws, self.skip_header, column)

    def __setitem__(self, column: str, row):
        """自上而下逐个复制目标列单元格的值到当前列"""
        if isinstance(row, AdTableColumn):
            for idx, value in enumerate(row.values, start=1):
                self.__getitem__(column)[self.skip_header + idx].value = value
        else:
            raise Exception('不支持的类型')

    @property
    def sheet_name(self) -> str:
        return self.ws.title

    @sheet_name.setter
    def sheet_name(self, new_name) -> None:
        self.ws.title = new_name

    @property
    def letters(self) -> List[str]:
        return [get_column_letter(idx) for idx in range(1, 1 + self.max_column)]

    @property
    def columns(self):
        _columns = [AdTableColumn(self.filename, self.wb, self.ws, self.skip_header, column)
                    for column in range(1, 1 + self.ws.max_column)]
        return AdTableColumnSet(self.filename, self.wb, self.ws, self.skip_header, _columns)

    def columns_at(self, columns: List[str]):
        _columns = [AdTableColumn(
            self.filename, self.wb, self.ws, self.skip_header, c) for c in columns]
        return AdTableColumnSet(self.filename, self.wb, self.ws, self.skip_header, _columns)

    @property
    def rows(self):
        _rows = [AdTableRow(self.filename, self.wb, self.ws, self.skip_header, r)
                 for r in range(1 + self.skip_header, 1 + self.ws.max_row)]
        return AdTableRowSet(self.filename, self.wb, self.ws, self.skip_header, _rows)

    @property
    def max_row(self) -> int:
        return self.ws.max_row

    @property
    def max_column(self) -> int:
        return self.ws.max_column

    def row_at(self, row: int):
        return AdTableRow(self.filename, self.wb, self.ws, self.skip_header, row)

    def rows_at(self, rows: List[Union[str, int]]):
        _rows = [AdTableRow(self.filename, self.wb, self.ws,
                            self.skip_header, r) for r in rows]
        return AdTableRowSet(self.filename, self.wb, self.ws, self.skip_header, _rows)

    @property
    def cells(self):
        _cells = [AdTableCell(self.filename, self.wb, self.ws, self.skip_header, column, row)
                  for column in range(1, 1 + self.ws.max_column)
                  for row in range(1 + self.skip_header, 1 + self.ws.max_row)]
        return AdTableCellSet(self.filename, self.wb, self.ws, self.skip_header, _cells)

    def cells_at(self, pos: List[str]):
        _pos: List[Pos] = [_unpack_pos(p) for p in pos]
        _cells = [AdTableCell(self.filename, self.wb, self.ws,
                              self.skip_header, p.column_letter, p.row_idx) for p in _pos]
        return AdTableCellSet(self.filename, self.wb, self.ws, self.skip_header, _cells)

    def cell_at(self, pos: str):
        """简化访问单元格，如lt.cell_at("A10")"""
        _pos: Pos = _unpack_pos(pos)
        return AdTableCell(self.filename, self.wb, self.ws,
                           self.skip_header, _pos.column_letter, _pos.row_idx)

    @property
    def values(self) -> List[str]:
        return self.cells.values

    def values_at(self, pos: List[str]) -> List[str]:
        return self.cells_at(pos).values

    def order_by(self, column, test_fn=str):
        _rows = sorted(self.rows, key=lambda r: test_fn(r[column].value))
        return AdTableRowSet(self.filename, self.wb, self.ws, self.skip_header, _rows)

    def row(self, row: int):
        return AdTableRow(self.filename, self.wb, self.ws, self.skip_header, row)

    def save(self, filename: str) -> str:
        """另存为文件"""
        Path(filename).parent.mkdir(parents=True, exist_ok=True)  # 目录不存在则创建
        self.wb.save(filename)
        # fix_excel(filename)
        return filename

    def save_to(self, dir_name: str) -> str:
        """另存为文件"""
        Path(dir_name).mkdir(parents=True, exist_ok=True)  # 目录不存在则创建/
        _filename = Path(self.filename).name
        if _filename.lower().endswith('.xlsx'):
            _filename = _filename[:-5]
        fspath = Path(dir_name).joinpath(_filename + '.xlsx').as_posix()
        self.wb.save(fspath)
        # fix_excel(fspath)
        return fspath

    def add_row(self):
        row = self.ws.max_row + 1
        return AdTableRow(self.filename, self.wb, self.ws, self.skip_header, row)

    def apply(self, fn):
        for cell in self.cells:
            cell.value = fn(cell.value)

    def del_blank_rows_by_column(self, column: str):
        """根据表格中特定列，从尾部删除连续的空白行"""
        values = self.__getitem__(column).values
        rows = [idx for idx, value in enumerate(values, start=self.skip_header + 1) if value == '']
        if len(rows) > 0 and rows[-1] == self.max_row:  # 最后一行是空白单元格时，从后往前删除
            last_blank_rows = [i for i, j in zip(reversed(rows), reversed(range(rows[-1] + 1))) if i == j]
            begin_row = min(last_blank_rows)
            amount = len(last_blank_rows)
            logging.info(f'文件{self.filename}的{column}列末尾存在空白单元格，移除文件{begin_row}至{max(last_blank_rows)}行')
            self.ws.delete_rows(begin_row, amount)

    def re_index(self, column: str) -> None:
        """从1设置数据区的索引值"""
        for idx, cell in enumerate(self[column].cells, start=1):
            cell.value = str(idx)

    def to_dataframe(self) -> DataFrame:
        """当前sheet页数据区域转为pandas.DataFrame，列名为A、B、C..."""
        letters = self.letters
        _table = []
        for rn in range(1 + self.skip_header, 1 + self.max_row):
            _table.append([self.ws[f'{column}{rn}'].value for column in letters])
        _df = DataFrame(_table)
        _df = _df.fillna('')
        if len(_df.columns) > 0:
            _df.columns = letters
        _df.index += 1 + self.skip_header  # 索引号=行号
        return _df

    def clear_comment_and_fgcolor(self):
        """清除sheet页批注及背景颜色（openpyxl>=3.0.6）"""
        self.clear_all_comments()
        self.clear_all_fgcolors()

    def clear_all_comments(self):
        """清除当前sheet页所有批注（含表头）"""
        _cells = [AdTableCell(self.filename, self.wb, self.ws, self.skip_header, column, row)
                  for column in range(1, 1 + self.ws.max_column)
                  for row in range(1, 1 + self.ws.max_row)]
        for cell in _cells:
            try:
                cell.comment = None
            except AttributeError:
                logging.error(f'{cell}是合并单元格，无法修改批注')  # 合并单元格comment属性是只读的

    def clear_all_fgcolors(self):
        """清除数据区域单元格背景颜色"""
        for cell in self.cells:
            cell.clear_fg_color()

    def uniq_all_column_comments(self):
        """精简批注个数，优化文件打开速度
           遍历每一列的单元格，相同内容批注只保留一个（最上方的单元格）
        """
        for column in self.columns:
            comment_history = []
            for cell in column.cells:
                comment_text = str(cell.comment)
                if comment_text in comment_history:
                    cell.comment = None
                else:
                    comment_history.append(comment_text)

    def replace_content_by(self, new_adtable):
        """用另一个adtable的内容替换当前adtable"""
        for column in range(1, 1 + new_adtable.ws.max_column):
            for row in range(1, 1 + new_adtable.ws.max_row):
                column_letter = get_column_letter(column)
                self.ws[f'{column_letter}{row}'].value = new_adtable.ws[f'{column_letter}{row}'].value

    def delete_all_contents(self):
        self.ws.delete_rows(self.skip_header + 1, self.ws.max_row - self.skip_header)


class AdTableCell(object):
    filename: str
    wb: Workbook
    ws: Worksheet
    skip_header: int
    column_letter: str
    row_idx: str
    headers = dict([(column, idx) for idx, column in enumerate(
        get_column_interval(1, 200), start=1)])

    def __repr__(self):
        return f'<AdTableCell {self.filename}.xlsx pos:{self.pos} value:{self.value}>'

    def __init__(self, filename: str, wb: Workbook, ws: Worksheet, skip_header: int, column: Union[str, int],
                 row: Union[str, int]):
        self.filename = filename
        self.wb = wb
        self.ws = ws
        self.skip_header = skip_header
        self.column_letter = _normalize_column_letter(column)
        self.row_idx = str(row)

    def __eq__(self, _: object):
        raise Exception('AdTableCell不支持直接比对，请加.value属性对单元格内容进行判断')

    @property
    def link_str(self):
        return '#' + self.ws.title + '!' + self.pos

    @property
    def hyperlink(self):
        return self.cell.hyperlink

    @hyperlink.setter
    def hyperlink(self, link):
        if link is None:
            self.cell.hyperlink = None
        elif isinstance(link, AdTableCell):
            self.cell.hyperlink = link.link_str
        elif isinstance(link, str):
            self.cell.hyperlink = link

    @property
    def table(self):
        return AdTable(self.filename, self.wb, self.ws, self.skip_header)

    @property
    def up_cell(self):
        return AdTableCell(self.filename, self.wb, self.ws, self.skip_header, self.column_letter, int(self.row_idx) - 1)

    @property
    def down_cell(self):
        return AdTableCell(self.filename, self.wb, self.ws, self.skip_header, self.column_letter, int(self.row_idx) + 1)

    @property
    def left_cell(self):
        column = column_index_from_string(self.column_letter)
        if column == 1:  # 已是最左列单元格
            return None
        else:
            return AdTableCell(self.filename, self.wb, self.ws, self.skip_header, column - 1, self.row_idx)

    @property
    def right_cell(self):
        column = column_index_from_string(self.column_letter)
        if column == self.ws.max_column:  # 已是最右列单元格
            return None
        else:
            return AdTableCell(self.filename, self.wb, self.ws, self.skip_header, column + 1, self.row_idx)

    def assert_value(self, value: str):
        if self.value == value:
            return self
        else:
            raise ValueError(f'单元格{self.pos}值为{self.value}，对比值为{value}，不匹配，请核查！')

    @property
    def pos(self) -> str:
        return str(Pos(self.column_letter, self.row_idx))

    @property
    def cell(self):
        return self.ws[f'{self.column_letter}{self.row_idx}']

    @property
    def value(self) -> str:
        return '' if self.cell.value is None else str(self.cell.value)

    @value.setter
    def value(self, new_value):
        try:
            self.cell.value = '' if new_value is None else new_value  # str(new_value).rstrip(' \t\r\n')
        except AttributeError:  # 合并单元格的内容是只读的，不可变更。
            pass

    @property
    def left_part(self) -> str:
        """以第一个空格为分隔，返回左半部分文本"""
        matches = re.match(r'([^ ]*) ', str(self.value))
        if matches is not None:
            return matches.groups()[0]
        raise Exception(f'单元格 {self.pos} 未发现空格')

    @property
    def right_part(self) -> str:
        """以第一个空格为分隔，返回左半部分文本"""
        matches = re.match(r'[^ ]* (.*)', str(self.value))
        if matches is not None:
            return matches.groups()[0]
        raise Exception(f'单元格 {self.pos} 未发现空格')

    @property
    def column(self):
        return AdTableColumn(self.filename, self.wb, self.ws, self.skip_header, self.column_letter)

    @property
    def row(self):
        return AdTableRow(self.filename, self.wb, self.ws, self.skip_header, self.row_idx)

    @property
    def comment(self):
        return self.cell.comment

    @comment.setter
    def comment(self, comment: Comment) -> None:
        self.cell.comment = comment

    def find_above_until(self, value: str):
        """从当前单元格开始，逐个向上寻找，直到找到满足条件的单元格并返回。找不到时抛出ValueError"""
        up_cell = self.up_cell
        while True:
            try:
                if up_cell.value == value:
                    return up_cell
                else:
                    up_cell = up_cell.up_cell
            except Exception:
                raise ValueError(f'{self}上方找不到值{value}')

    def clear_fg_color(self):
        self.cell.fill = PatternFill(fill_type=None)

    def set_fgcolor(self, color: str) -> None:
        if color == 'red':
            self.cell.fill = PatternFill("solid", 'FF0000')  # 红色
        elif color == 'blue':
            self.cell.fill = PatternFill("solid", '0000FF')  # 蓝色
        elif color == 'white':
            self.cell.fill = PatternFill("solid", 'FFFFFF')  # 白色
        elif color == 'green':
            self.cell.fill = PatternFill("solid", '00FF00')  # 绿色
        elif color == 'purple':
            self.cell.fill = PatternFill("solid", 'FF00FF')  # 紫色
        elif color == 'pink':
            self.cell.fill = PatternFill("solid", 'FFC0CB')  # 粉红色
        elif color == 'lightpink':
            self.cell.fill = PatternFill("solid", 'FFB6C1')  # 浅粉色
        elif color == 'orange':
            self.cell.fill = PatternFill("solid", 'FFA500')  # 橙色
        elif color == 'yellow':
            self.cell.fill = PatternFill("solid", 'FFFF00')  # 黄色
        elif color == 'clear':
            self.cell.fill = PatternFill(fill_type=None)  # 透明
        else:
            self.cell.fill = PatternFill("solid", color)  # FFFFFF 格式的颜色

    def set_comment_and_fgcolor(self, comment: str, author: str, color: str) -> None:
        self.set_fgcolor(color)
        try:
            self.comment = Comment(comment, author)
        except AttributeError as e:
            logging.error(f'单元格{self.pos}设置批注报错，错误原因：{e}')
            raise e

    def cmt(self, color: str, comment=None, ignore_error=True):
        """如已存在批注，则追加"""
        if color == 'red' and ignore_error is False:
            filename = self.filename
            sheetname = self.table.sheet_name
            pos = self.pos
            value = self.value
            logging.error(f'[{filename}·{sheetname}·{pos}·{value}] {comment}')
        if self.comment is not None:
            # 如果已有批注，则在原批注上追加内容
            prev_comment_text = self.comment.content
            prev_comment_author = self.comment.author
            comment = prev_comment_text.replace(prev_comment_author + ':\n', '').rstrip('\n') + '\n\n' + comment
        self.set_comment_and_fgcolor(comment, 'rpa', color)

    def same_line(self, column: str):
        """寻找与单元格在同一行的某列"""
        return AdTableCell(self.filename, self.wb, self.ws, self.skip_header, column, self.row_idx)

    def same_column(self, row):
        """寻找与单元格在同一列的某单元格"""
        return AdTableCell(self.filename, self.wb, self.ws, self.skip_header, self.column_letter, row)

    def find_to_left_until_no_empty(self):
        """寻找合并单元格的值"""
        cell = self
        while True:
            if cell.value != '':
                break
            else:
                left_cell = cell.left_cell
                if left_cell is None:  # 已到最左列
                    break
                else:
                    cell = cell.left_cell  # 继续向左寻找非''单元格
        return cell


class AdTableCellSet(object):
    filename: str
    wb: Workbook
    ws: Worksheet
    skip_header: int
    cells: List[AdTableCell]

    def __repr__(self):
        return f'<AdTableCellSet {self.filename}.xlsx>'

    def __init__(self, filename: str, wb: Workbook, ws: Worksheet, skip_header: int, cells: List[AdTableCell]):
        self.filename = filename
        self.wb = wb
        self.ws = ws
        self.skip_header = skip_header
        self.cells = cells

    def __iter__(self) -> Iterator[AdTableCell]:
        return iter(self.cells)

    def find(self, value, match_mode='equal'):
        if match_mode == 'equal':
            for cell in self.cells:
                if cell.value == value:
                    return cell
        elif match_mode == 'include':
            for cell in self.cells:
                if value in cell.value:
                    return cell
        else:
            raise Exception('match_mode非预定义值')

    def find_all(self, value: str, match_mode='equal'):
        if match_mode == 'equal':
            _cells = [cell for cell in self.cells if cell.value == value]
            return AdTableCellSet(self.filename, self.wb, self.ws, self.skip_header, _cells)
        elif match_mode == 'include':
            _cells = [cell for cell in self.cells if value in cell.value]
            return AdTableCellSet(self.filename, self.wb, self.ws, self.skip_header, _cells)
        else:
            raise Exception('match_mode非预定义值')

    @property
    def table(self):
        return AdTable(self.filename, self.wb, self.ws, self.skip_header)

    @property
    def rows(self):
        _rows = [cell.row for cell in self.cells]
        return AdTableRowSet(self.filename, self.wb, self.ws, self.skip_header, _rows)

    @property
    def columns(self):
        _columns = [cell.column for cell in self.cells]
        return AdTableColumnSet(self.filename, self.wb, self.ws, self.skip_header, _columns)

    @property
    def values(self):
        return [cell.value for cell in self.cells]

    def same_line(self, column: str):
        _cells = [cell.same_line(column) for cell in self.cells]
        return AdTableCellSet(self.filename, self.wb, self.ws, self.skip_header, _cells)

    def apply(self, fn):
        for cell in self.cells:
            cell.value = fn(cell.value)

    def asc(self):
        """根据值升序排序"""
        _cells = sorted(self.cells, key=lambda cell: cell.value)
        return AdTableCellSet(self.filename, self.wb, self.ws, self.skip_header, _cells)


class AdTableColumn(object):
    """选取某一列"""
    filename: str
    wb: Workbook
    ws: Worksheet
    skip_header: int
    column_letter: str

    def __repr__(self):
        return f'<AdTableColumn {self.filename}.xlsx column:{self.column_letter}>'

    def __init__(self, filename: str, wb: Workbook, ws: Worksheet, skip_header: int, column: Union[str, int]):
        self.filename = filename
        self.wb = wb
        self.ws = ws
        self.skip_header = skip_header
        self.column_letter = _normalize_column_letter(column)

    def __getitem__(self, row: Union[str, int]):
        return AdTableCell(self.filename, self.wb, self.ws, self.skip_header, self.column_letter, row)

    def __iter__(self) -> Iterator[AdTableCell]:
        _cells = [AdTableCell(self.filename, self.wb, self.ws, self.skip_header,
                              self.column_letter, row) for row in range(1 + self.skip_header, 1 + self.ws.max_row)]
        return iter(_cells)

    @property
    def table(self):
        return AdTable(self.filename, self.wb, self.ws, self.skip_header)

    @property
    def values(self):
        return self.cells.values

    @property
    def cells(self):
        _cells = [AdTableCell(self.filename, self.wb, self.ws, self.skip_header,
                              self.column_letter, row) for row in range(1 + self.skip_header, 1 + self.ws.max_row)]
        return AdTableCellSet(self.filename, self.wb, self.ws, self.skip_header, _cells)

    def apply(self, fn):
        for cell in self.cells:
            cell.value = fn(cell.value)

    def find(self, value, match_mode='equal'):
        """在列中定位第一次出现value的单元格，找不到时抛出异常"""
        if match_mode == 'equal':
            for cell in self.cells:
                if cell.value == value:
                    return cell
        elif match_mode == 'include':
            for cell in self.cells:
                if cell.value == value:
                    return cell
        else:
            raise Exception('match_mode非预定义值')

    def find_all(self, value, match_mode='equal') -> AdTableCellSet:
        if match_mode == 'equal':
            _cells = [cell for cell in self.cells if cell.value == value]
            return AdTableCellSet(self.filename, self.wb, self.ws, self.skip_header, _cells)
        elif match_mode == 'include':
            _cells = [cell for cell in self.cells if value in cell.value]
            return AdTableCellSet(self.filename, self.wb, self.ws, self.skip_header, _cells)
        else:
            raise Exception('match_mode非预定义值')

    def order_by(self, test_fn) -> AdTableCellSet:
        _cells = sorted([cell for cell in self.cells], key=lambda c: test_fn(c.value))  # ?
        return AdTableCellSet(self.filename, self.wb, self.ws, self.skip_header, _cells)

    def asc(self):
        """根据值升序排序"""
        return self.cells.asc()


class AdTableColumnSet(object):
    filename: str
    wb: Workbook
    ws: Worksheet
    skip_header: int
    columns: List[AdTableColumn]

    def __repr__(self):
        return f'<AdTableColumnSet {self.filename}.xlsx>'

    def __init__(self, filename: str, wb: Workbook, ws: Worksheet, skip_header: int, columns: List[AdTableColumn]):
        self.filename = filename
        self.wb = wb
        self.ws = ws
        self.skip_header = skip_header
        self.columns = columns

    def __iter__(self) -> Iterator[AdTableColumn]:
        return iter(self.columns)

    def __getitem__(self, row):
        _cells = [column[row] for column in self.columns]
        return AdTableCellSet(self.filename, self.wb, self.ws, self.skip_header, _cells)

    @property
    def table(self):
        return AdTable(self.filename, self.wb, self.ws, self.skip_header)

    @property
    def cells(self):
        _cells = [cell for column in self.columns for cell in column.cells]
        return AdTableCellSet(self.filename, self.wb, self.ws, self.skip_header, _cells)

    @property
    def values(self):
        return self.cells.values

    def apply(self, fn):
        for cell in self.cells:
            cell.value = fn(cell.value)


class AdTableRow(object):
    """选取某一行（可选择表头行，通常用于判断表单是否正确）"""
    _filename: str
    wb: Workbook
    ws: Worksheet
    skip_header: int
    row_idx: str

    def __repr__(self):
        return f'<AdTableRow {self._filename}.xlsx row:{self.row_idx}>'

    def __init__(self, filename: str, wb: Workbook, ws: Worksheet, skip_header: int, row: Union[str, int]):
        self._filename = filename
        self.wb = wb
        self.ws = ws
        self.skip_header = skip_header
        self.row_idx = str(row)

    def __getitem__(self, column: Union[str, int]):
        return AdTableCell(self._filename, self.wb, self.ws, self.skip_header, column, self.row_idx)

    def __iter__(self) -> Iterator[AdTableCell]:
        _cells = [AdTableCell(self._filename, self.wb, self.ws, self.skip_header,
                              column, self.row_idx) for column in range(1, 1 + self.ws.max_column)]
        return iter(_cells)

    @property
    def table(self):
        return AdTable(self._filename, self.wb, self.ws, self.skip_header)

    @property
    def values(self):
        return [cell.value for cell in self.cells]

    @values.setter
    def values(self, values):
        for column, value in enumerate(values, start=1):
            self.__getitem__(column).value = value

    @property
    def cells(self) -> AdTableCellSet:
        _cells = [AdTableCell(self._filename, self.wb, self.ws, self.skip_header,
                              column, self.row_idx) for column in range(1, 1 + self.ws.max_column)]
        return AdTableCellSet(self._filename, self.wb, self.ws, self.skip_header, _cells)

    def apply(self, fn):
        for cell in self.cells:
            cell.value = fn(cell.value)

    def find(self, value: str, match_mode='equal'):
        if match_mode == 'equal':
            for cell in self.cells:
                if cell.value == value:
                    return cell
        elif match_mode == 'include':
            for cell in self.cells:
                if value in cell.value:
                    return cell
        else:
            raise Exception('match_mode非预定义值')

    def find_all(self, value: str, match_mode='equal'):
        if match_mode == 'equal':
            _cells = [cell for cell in self.cells if cell.value == value]
            return AdTableCellSet(self._filename, self.wb, self.ws, self.skip_header, _cells)
        elif match_mode == 'include':
            _cells = [cell for cell in self.cells if value in cell.value]
            return AdTableCellSet(self._filename, self.wb, self.ws, self.skip_header, _cells)
        else:
            raise Exception('match_mode非预定义值')


class AdTableRowSet(object):
    filename: str
    wb: Workbook
    ws: Worksheet
    skip_header: int
    rows: List[AdTableRow]

    def __repr__(self):
        return f'<AdTableRowSet {self.filename}.xlsx>'

    def __init__(self, filename: str, wb: Workbook, ws: Worksheet, skip_header: int, rows: List[AdTableRow]):
        self.filename = filename
        self.wb = wb
        self.ws = ws
        self.skip_header = skip_header
        self.rows = rows

    def __iter__(self) -> Iterator[AdTableRow]:
        return iter(self.rows)

    def __getitem__(self, column: str):
        _cells = [row[column] for row in self.rows]
        return AdTableCellSet(self.filename, self.wb, self.ws, self.skip_header, _cells)

    @property
    def table(self):
        return AdTable(self.filename, self.wb, self.ws, self.skip_header)

    @property
    def cells(self):
        _cells = [cell for row in self.rows for cell in row.cells]
        return AdTableCellSet(self.filename, self.wb, self.ws, self.skip_header, _cells)

    @property
    def values(self):
        return [cell.value for cell in self.cells]

    def apply(self, fn):
        for cell in self.cells:
            cell.value = fn(cell.value)


def load_from_xlsx_file(xlsx_filename: str, sheet_name=None, skip_header=1, data_only=False) -> AdTable:
    """加载xlsx文件（通常用于加载表单/模板文件）"""
    wb = load_workbook(xlsx_filename, data_only=data_only)
    filename = Path(xlsx_filename).name[:-5]  # 去除扩展名
    if sheet_name is None:
        ws = wb.active
    else:
        ws = wb[sheet_name]
    ws.protection.disable()  # 如果加锁则解锁
    return AdTable(filename, wb, ws, skip_header)
