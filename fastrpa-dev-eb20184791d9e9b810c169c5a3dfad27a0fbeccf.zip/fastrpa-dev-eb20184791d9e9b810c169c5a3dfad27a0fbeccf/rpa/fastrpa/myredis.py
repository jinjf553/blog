from redis import Redis
from rpa.fastrpa.third_party.isa import decrypt
from rpa.public.config import redis_user_readonly


class MyRedis(object):
    redis_url: str = '127.0.0.1'
    redis_port: str = '6379'
    redis_password: str = ''
    _redis: Redis

    def __init__(self):
        self.redis_url, self.redis_port, self.redis_password = redis_user_readonly()
        self.redis_password = decrypt(self.redis_password)

    def __enter__(self) -> Redis:
        self._redis = Redis(host=self.redis_url, port=self.redis_port, password=self.redis_password, decode_responses=True, charset='UTF-8', encoding='UTF-8')
        return self._redis

    def __exit__(self, exc_type, exc_val, exc_tb):
        self._redis.close()


if __name__ == '__main__':
    with MyRedis() as r:
        r.set('test', 'test redis')
        print(r.get('test'))
