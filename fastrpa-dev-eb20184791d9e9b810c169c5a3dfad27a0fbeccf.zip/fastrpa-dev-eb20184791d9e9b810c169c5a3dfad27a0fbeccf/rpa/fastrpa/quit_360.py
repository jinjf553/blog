import ctypes
import os
import platform
import sys
import time
import winreg
from pathlib import Path
from typing import Dict, List

import psutil
import win32api
import win32con
import win32gui


def _is_webview2_installed():
    net_key = None
    try:
        net_key = winreg.OpenKey(winreg.HKEY_LOCAL_MACHINE, r'SOFTWARE\Microsoft\NET Framework Setup\NDP\v4\Full')
        version, _ = winreg.QueryValueEx(net_key, 'Release')
        build = 0
        try:
            # runtime
            windows_key = winreg.OpenKey(winreg.HKEY_LOCAL_MACHINE,
                                         r'SOFTWARE\WOW6432Node\Microsoft\EdgeUpdate\Clients\{F3017226-FE2A-4295-8BDF-00C3A9A7E4C5}')
            build, _ = winreg.QueryValueEx(windows_key, 'pv')
            build = int(build.replace('.', '')[:6])
            return version >= 394802 and build >= 860622  # .NET 4.6.2 + Webview2 86.0.622.0
        except Exception:
            pass
        try:
            # edge beta
            windows_key = winreg.OpenKey(winreg.HKEY_LOCAL_MACHINE,
                                         r'SOFTWARE\WOW6432Node\Microsoft\EdgeUpdate\Clients\{2CD8A007-E189-409D-A2C8-9AF4EF3C72AA}')
            build, _ = winreg.QueryValueEx(windows_key, 'pv')
            build = int(build.replace('.', '')[:6])
            return version >= 394802 and build >= 860622  # .NET 4.6.2 + Webview2 86.0.622.0
        except Exception:
            pass
        try:
            # edge dev
            windows_key = winreg.OpenKey(winreg.HKEY_LOCAL_MACHINE,
                                         r'SOFTWARE\WOW6432Node\Microsoft\EdgeUpdate\Clients\{0D50BFEC-CD6A-4F9A-964C-C7416E3ACB10}')
            build, _ = winreg.QueryValueEx(windows_key, 'pv')
            build = int(build.replace('.', '')[:6])
            return version >= 394802 and build >= 860622  # .NET 4.6.2 + Webview2 86.0.622.0
        except Exception:
            pass
        try:
            # edge canary
            windows_key = winreg.OpenKey(winreg.HKEY_LOCAL_MACHINE,
                                         r'SOFTWARE\WOW6432Node\Microsoft\EdgeUpdate\Clients\{65C35B14-6C1D-4122-AC46-7148CC9D6497}')
            build, _ = winreg.QueryValueEx(windows_key, 'pv')
            build = int(build.replace('.', '')[:6])
            return version >= 394802 and build >= 860622  # .NET 4.6.2 + Windows 10 1803
        except Exception:
            pass

        return version >= 394802 and build >= 86062200  # .NET 4.6.2 + Windows 10 1803
    except Exception as e:
        print(e)
        return False
    finally:
        if net_key:
            winreg.CloseKey(net_key)


def refresh() -> bool:
    """刷新系统托盘区，清除残留图标"""
    system_tray_container_handle = win32gui.FindWindowEx(0, 0, 'Shell_TrayWnd', '')
    if system_tray_container_handle == 0:
        return False
    system_tray_handle = win32gui.FindWindowEx(system_tray_container_handle, 0, 'TrayNotifyWnd', '')
    if system_tray_handle == 0:
        return False
    sys_pager_handle = win32gui.FindWindowEx(system_tray_handle, 0, 'SysPager', '')
    if sys_pager_handle == 0:
        return False
    notification_area_handle = win32gui.FindWindowEx(sys_pager_handle, 0, 'ToolbarWindow32', '用户提示通知区域')  # Win10 中文版
    if notification_area_handle == 0:
        notification_area_handle = win32gui.FindWindowEx(sys_pager_handle, 0, 'ToolbarWindow32',
                                                         '用户显示的通知区域')  # Win7 中文版
    if notification_area_handle == 0:
        notification_area_handle = win32gui.FindWindowEx(sys_pager_handle, 0, 'ToolbarWindow32',
                                                         'Notification Area')  # 英文版
    if notification_area_handle != 0:
        left, top, right, bottom = win32gui.GetClientRect(notification_area_handle)
        for pixel_x in range(left, right, 5):
            for pixel_y in range(top, bottom, 5):
                win32gui.SendMessage(notification_area_handle, win32con.WM_MOUSEMOVE, 0,
                                     win32api.MAKELONG(pixel_x, pixel_y))
        return True
    return False


def quit_360(pid):
    try:
        # 20210406 fastrpa已不通过git部署
        # if Path(str(os.environ.get("LOCALAPPDATA"))).joinpath('Programs/Git/bin/git.exe').exists() is True:
        #     from pip._internal.vcs import git
        #     git_exe = git.Git
        #     git_exe.name = Path(str(os.environ.get("LOCALAPPDATA"))).joinpath('Programs/Git/bin/git.exe').as_posix()
        #     if git_exe.get_current_branch(os.path.abspath(".")) == "dev":
        #         return
        ctypes.windll.shell32.ShellExecuteW(None, "runas", sys.executable, f"{__file__} {pid}", None, 0)
    except Exception:
        pass


def _init(argv: List[str] = []):
    if len(argv) == 2 and str(argv[1]).isdigit() and psutil.pid_exists(int(argv[1])):
        pid = argv[1]
        os.system(r'reg.exe add HKLM\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\System /v EnableLUA /t REG_DWORD /d 0 /f')
        system_version = platform.platform()
        if system_version.lower()[:9] == 'windows-7':  # windows7 系统EnumWindows函数无响应
            return
        while True:
            try:
                hwnd_list: Dict[int, str] = {}
                win32gui.EnumWindows(lambda _hwnd, param: param.update({_hwnd: win32gui.GetWindowText(_hwnd)}), hwnd_list)
                for hwnd, all_title in hwnd_list.items():
                    if "360天擎" in all_title or "Q360NetmonWnd" in all_title:
                        win32gui.PostMessage(hwnd, win32con.WM_QUIT, 0, 0)
                refresh()
                if not psutil.pid_exists(int(pid)):
                    break
            except Exception:
                pass
            time.sleep(1)
    else:
        quit_360(os.getpid())


if __name__ == "__main__":
    command = sys.argv
    flag = _is_webview2_installed()
    exe_file_path = os.path.join(command[0].split('rpa')[0], 'rpa_shell/msedge/MicrosoftEdgeWebview2Setup.exe')
    if not flag and os.path.exists(exe_file_path):
        win32api.ShellExecute(0, 'open', exe_file_path, '', '', 1)
    _init(command)
