"""邮件发送模块"""
import logging
import os

from exchangelib import (DELEGATE, NTLM, Account, Configuration, Credentials,
                         FileAttachment, Mailbox, Message)
from exchangelib.protocol import BaseProtocol, NoVerifyHTTPAdapter


def sendmail(receivers: str, subject: str = None, body: str = None, attachments: str = None):
    """
            EXCHANGE发送邮件
            receivers：接收者
            subject:标题  body：邮件正文  attachments：附件路径
        """
    server, sender, psw = "mail.sinopec.com", "gxvdirpa1.ssc@sinopec.com", "Rpa13579"
    try:
        BaseProtocol.HTTP_ADAPTER_CLS = NoVerifyHTTPAdapter
        cred = Credentials(sender, psw)
        config = Configuration(server=server, credentials=cred, auth_type=NTLM)
        a = Account(
            primary_smtp_address=sender, config=config, autodiscover=False, access_type=DELEGATE
        )

        m = Message(
            account=a,
            folder=a.sent,
            subject=subject,
            body=body,
            to_recipients=[Mailbox(email_address=receivers)]
        )
        if attachments is not None:
            for attachment in attachments.split(','):
                if os.path.exists(attachment):
                    with open(attachment, 'rb') as f:
                        file_content = f.read()
                        file_name = os.path.basename(os.path.realpath(attachment))
                        m.attach(FileAttachment(name=file_name, content=file_content))
        m.send_and_save()
        logging.info("exchange发送邮件成功")
    except Exception as e:
        logging.error("exchange发送邮件失败，失败原因如下：")
        logging.error(e)
