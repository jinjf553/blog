import os
import sys
from pathlib import Path

ZIP7_EXE_PATH = ''
if hasattr(sys, '_MEIPASS') is False:
    ZIP7_EXE_PATH = Path(__file__).parent.joinpath('7z.exe').as_posix()


def unzip(zipped_filename: str, output_dir: str):
    cmd = f'{ZIP7_EXE_PATH} x "{zipped_filename}" -o"{output_dir}" -aos -r'
    os.system(cmd)
