import os
import shutil
from pathlib import Path

FILE_SAPLOGON_INI = Path(__file__).parent.joinpath('saplogon.ini').as_posix()  # SAP配置文件
FILE_SAPLOGONTREE_XML = Path(__file__).parent.joinpath('SapLogonTree.xml').as_posix()  # SAP配置文件


def init_sap_config():
    """设置SAP连接信息（注意：会覆盖当前用户配置，一般在后台运行的用户下执行）"""
    roaming_dir = Path(str(os.environ['APPDATA']))
    shutil.copy(FILE_SAPLOGON_INI, Path(roaming_dir).joinpath('SAP/Common/saplogon.ini'))  # 复制SAP配置文件
    shutil.copy(FILE_SAPLOGONTREE_XML, Path(roaming_dir).joinpath('SAP/Common/SapLogonTree.xml'))


if __name__ == '__main__':
    if 'ONLY_RPA_SERVER' in os.environ.keys():
        init_sap_config()
