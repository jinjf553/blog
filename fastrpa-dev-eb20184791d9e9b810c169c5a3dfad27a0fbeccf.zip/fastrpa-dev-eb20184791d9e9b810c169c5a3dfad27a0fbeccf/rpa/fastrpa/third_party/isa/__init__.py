import binascii
import logging
import platform
from functools import lru_cache
from pathlib import Path
from typing import List, Union

from rpa.fastrpa.utils.run_cmd import run_cmd

system_name = platform.system()
system_version = platform.platform()


def utf8str_to_hexstr(utf8_str: str) -> str:
    return binascii.hexlify(utf8_str.encode('utf-8')).decode('utf-8').upper()  # '呵呵' => 'E591B5E591B5'


def hexstr_to_utf8str(base64_str: str) -> str:
    return binascii.unhexlify(base64_str.encode('utf-8')).decode('utf-8')  # 'E591B5E591B5' => '呵呵'


def _get_exe_path() -> str:
    exe_path = ''
    if system_name.lower() == 'windows':
        if len(system_version) >= 10 and system_version.lower()[:9] == 'windows-7':  # Win7默认使用.net2版本
            exe_path = Path(__file__).parent.joinpath('EncryptUtil_v2.exe').as_posix()
        elif len(system_version) >= 10 and system_version.lower()[:10] == 'windows-10':  # Win10默认使用.net4版本
            exe_path = Path(__file__).parent.joinpath('EncryptUtil_v4.exe').as_posix()
    if Path(exe_path).exists() is False:
        raise FileNotFoundError(exe_path)
    return exe_path


@lru_cache()
def get_isa_output(cmd_line: str, mode: str = 'str'):
    encrypt_str = run_cmd(cmd_line)
    if mode == 'str':
        return hexstr_to_utf8str(encrypt_str)
    else:
        return [hexstr_to_utf8str(s) for s in encrypt_str.strip(' \r\n\t').split(' ')]


def encrypt(input: Union[str, List[str]]) -> Union[str, List[str]]:
    """加密"""
    if isinstance(input, str):
        mode = 'str'
        s = utf8str_to_hexstr(input)
    elif isinstance(input, list):
        mode = 'list'
        s = ' '.join([utf8str_to_hexstr(i) for i in input])
    else:
        raise Exception('encrypt 入参必须为 Union[str, List[str]]')
    if "\n" in s:
        raise Exception("不支持加密包含换行符的字符串")
    try:
        exe_path = _get_exe_path()
        cmd_line = f'{exe_path} --encrypt {s}'
        return get_isa_output(cmd_line, mode)
    except Exception as e:
        logging.error(e)
    return ''


def decrypt(input: Union[str, List[str]]) -> Union[str, List[str]]:
    """解密"""
    if isinstance(input, str):
        mode = 'str'
        s = utf8str_to_hexstr(input)
    elif isinstance(input, list):
        mode = 'list'
        s = ' '.join([utf8str_to_hexstr(i) for i in input])
    else:
        raise Exception('decrypt 入参必须为 Union[str, List[str]]')
    if "\n" in s:
        raise Exception("不支持解密包含换行符的字符串")
    try:
        exe_path = _get_exe_path()
        cmd_line = f'{exe_path} --decrypt {s}'
        return get_isa_output(cmd_line, mode)
    except Exception as e:
        logging.error(e)
    return ''


if __name__ == '__main__':
    # assert decrypt(encrypt(' "&<>^|@!')) == ' "&<>^|@!'  # 20210616 增加对特殊字符的兼容
    # assert decrypt(encrypt([' "&<>^|@!a', ' "&<>^|@!b'])) == [' "&<>^|@!a', ' "&<>^|@!b']
    for code in range(32, 127):
        char = chr(code)
        encrypt_char = encrypt(char)
        decrypt_char = decrypt(encrypt_char)
        if encrypt_char != '' and decrypt_char == char:
            continue
        else:
            print(code, char, encrypt_char, decrypt_char)
    else:
        print('所有ASCII可打印字符均能正确转码解码')
