import logging
import shutil
import subprocess  # nosec
from pathlib import Path
from time import sleep

import rpa.config
import win32con
import win32gui
from rpa.config import IS_PYINSTALLER_EXE
from rpa.fastrpa.utils.taskkill import taskkill
from rpa.fastrpa.utils.window import fuzz_search_window

DONT_SLEEP_INI = """[Program]
TestIni=eeee
last_power_sheme=no_name
please_sleep_mode=0
tray_start=1
startup_disabled=0
block_screensaver=0
block_shutdown=0
block_logof=0
"""


def close_dont_sleep():
    for hwnd, _ in fuzz_search_window('Don\'t Sleep 6.41 - OS:').items():
        try:
            win32gui.PostMessage(hwnd, win32con.WM_QUIT, 0, 0)
            sleep(1)
        except Exception:  # nosec
            pass
    taskkill('DontSleep_x64_p.exe')


def dont_sleep():
    """禁用系统休眠、锁屏"""
    if IS_PYINSTALLER_EXE is False:
        try:
            Path(f'{rpa.config.D_RPA}/安装包/DontSleep').mkdir(parents=True, exist_ok=True)
            src_dont_sleep_exe = Path(__file__).parent.joinpath('DontSleep_x64_p.exe')
            dst_dont_sleep_exe = Path(f'{rpa.config.D_RPA}/安装包/DontSleep/DontSleep_x64_p.exe')
            dst_dont_sleep_ini = Path(f'{rpa.config.D_RPA}/安装包/DontSleep/DontSleep.ini')
            if dst_dont_sleep_exe.exists() is False:
                shutil.copyfile(src_dont_sleep_exe, dst_dont_sleep_exe)
            if dst_dont_sleep_exe.exists() is True:
                close_dont_sleep()
                dst_dont_sleep_ini.write_text(DONT_SLEEP_INI, encoding='utf-8')
                subprocess.Popen(dst_dont_sleep_exe.as_posix(), shell=True)  # nosec
        except Exception as e:
            logging.error(e)


class DONT_SLEEP(object):

    def __enter__(self):
        dont_sleep()

    def __exit__(self, exc_type, exc_val, exc_tb):
        # close_dont_sleep()
        pass


if __name__ == "__main__":
    dont_sleep()
