from typing import Any


class GuiTable(object):
    session: Any
    id: str
    row_count: int
    column_count: int

    def __init__(self, session: Any, gui_table_id: str):
        self.session = session
        self.id = gui_table_id.replace(self.session.id + '/', '')
        self.row_count = self.session.findById(gui_table_id).RowCount - 10  # 末尾包含10个空行
        self.column_count = len(self.session.findById(gui_table_id).Columns)

    def __select__(self, row: int, column) -> str:
        self.session.findById(self.id).verticalScrollbar.position = row  # 可视区域的开始位置
        self.session.findById(f"{self.id}/txtDYNP4300_TC_QUERIES-NAME[0,0]").setFocus()
        text = self.session.findById(self.id).GetCell(0, column).Text  # 这里的0,0是相对可视区域的位置
        return text

    def __find__(self, begin: int, end: int, column: int, name: str):
        if begin < end:
            mid = begin + (end - begin) // 2
            if self.__select__(mid, column) == name:
                return mid
            elif self.__select__(mid, column) > name:
                if mid != begin:
                    return self.__find__(begin, mid, column, name)
                else:
                    return -1
            else:
                if begin != mid:
                    return self.__find__(mid, end, column, name)
                else:
                    return -1
        else:
            return -1

    def find_by_name(self, name: str, column=0) -> int:
        return self.__find__(0, self.row_count, column, name)
