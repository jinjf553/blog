import os
import platform
from pathlib import Path

system_name = platform.system()
system_version = platform.platform()


def _get_exe_path() -> str:
    exe_path = ''
    if system_name.lower() == 'windows':
        if len(system_version) >= 10 and system_version.lower()[:9] == 'windows-7':  # Win7默认使用.net2版本
            exe_path = Path(__file__).parent.joinpath('AllowSystemMessages_v2.exe').as_posix()
        elif len(system_version) >= 10 and system_version.lower()[:10] == 'windows-10':  # Win10默认使用.net4版本
            exe_path = Path(__file__).parent.joinpath('AllowSystemMessages_v4.exe').as_posix()
    return exe_path


def allow_system_messages(is_allow: bool = False):
    """设置SAP系统消息打开或关闭（系统消息随时弹出，影响RPA正常执行）
       暂时只支持关闭"""
    exe_path = _get_exe_path()
    if is_allow is False:
        os.popen(exe_path).read()
    else:
        pass  # TODO 打开SAP系统消息
