from typing import Any, List

from rpa.fastrpa.adtable import AdTable


class GridViewCtrlCell(object):
    _session: Any
    id: str
    column_id: str
    row: int

    def __init__(self, session: Any, grid_view_ctrl_id: str, column_id: str, row: int):
        self._session = session
        self.id = grid_view_ctrl_id.replace(self._session.id + '/', '')
        self.column_id = column_id
        self.row = row

    def foucs(self) -> None:
        self._session.findById(self.id).firstVisibleRow = self.row
        self._session.findById(self.id).setCurrentCell(self.row, self.column_id)

    @property
    def value(self) -> str:
        self.foucs()
        value = self._session.findById(self.id).getCellValue(self.row, self.column_id)
        return value

    def press_button(self) -> None:
        self.foucs()
        self._session.findById(self.id).pressButtonCurrentCell()

    def double_click(self) -> None:
        self._session.findById(self.id).firstVisibleRow = self.row
        self._session.findById(self.id).setCurrentCell(self.row, self.column_id)
        self._session.findById(self.id).doubleClickCurrentCell()

    @property
    def grid_column_count(self) -> int:
        return self._session.findById(self.id).columnCount

    @property
    def grid_row_count(self) -> int:
        return self._session.findById(self.id).rowCount

    @property
    def grid_header_ids(self) -> List[str]:
        return [self._session.findById(self.id).columnOrder(j) for j in range(self.grid_column_count)]

    @property
    def grid_header_names(self) -> List[str]:
        """标题行名称"""
        result = []
        for header_id in self.grid_header_ids:
            header_name = self._session.findById(self.id).GetColumnTitles(header_id)[0]
            result.append(header_name)
        return result

    def same_line(self, column):
        if isinstance(column, int):
            column_id = self._session.findById(self.id).columnOrder(column)
            return GridViewCtrlCell(self._session, self.id, column_id, self.row)
        if column in self.grid_header_names:
            idx = self.grid_header_names.index(column)
            column_id = self.grid_header_ids[idx]
            return GridViewCtrlCell(self._session, self.id, column_id, self.row)
        if column in self.grid_header_ids:
            column_id = column
            return GridViewCtrlCell(self._session, self.id, column_id, self.row)
        raise Exception('same_line(): GridViewCtrl列索引必须是SAP_ID、整数、标题名之一')


class GridViewCtrlColumn(object):
    session: Any
    id: str
    column_id: str

    def __init__(self, session: Any, grid_view_ctrl_id: str, column_id: str):
        self.session = session
        self.id = grid_view_ctrl_id.replace(self.session.id + '/', '')
        self.column_id = column_id

    def __getitem__(self, row: int) -> str:
        self.session.findById(self.id).firstVisibleRow = row
        self.session.findById(self.id).setCurrentCell(row, self.column_id)
        value = self.session.findById(self.id).getCellValue(row, self.column_id)
        return value

    def __len__(self) -> int:
        return self.session.findById(self.id).rowCount

    @property
    def row_count(self) -> int:
        return self.session.findById(self.id).rowCount

    def find(self, value: str):
        for row in range(self.row_count):
            if self.__getitem__(row) == value:
                return GridViewCtrlCell(self.session, self.id, self.column_id, row)
        raise Exception(f'在GridViewCtrl组件{self.header_name}列找不到值{value}')

    @property
    def header_id(self) -> str:
        return self.column_id

    @property
    def header_name(self) -> str:
        return self.session.findById(self.id).GetColumnTitles(self.header_id)[0]


class GridViewCtrl(object):
    session: Any
    id: str

    def __init__(self, session, grid_view_ctrl_id: str):
        self.session = session
        self.id = grid_view_ctrl_id.replace(self.session.id + '/', '')

    def __len__(self) -> int:
        return self.session.findById(self.id).rowCount

    @property
    def header_ids(self) -> List[str]:
        return [self.session.findById(self.id).columnOrder(j) for j in range(self.column_count)]

    @property
    def header_names(self) -> List[str]:
        """标题行名称"""
        result = []
        for header_id in self.header_ids:
            header_name = self.session.findById(self.id).GetColumnTitles(header_id)[0]
            result.append(header_name)
        return result

    @property
    def column_count(self) -> int:
        return self.session.findById(self.id).columnCount

    @property
    def row_count(self) -> int:
        return self.session.findById(self.id).rowCount

    @property
    def values(self) -> List[List[str]]:
        table_values = []
        for row in range(self.row_count):
            row_values = []
            self.session.findById(self.id).firstVisibleRow = row
            for column in range(self.column_count):
                column_id = self.session.findById(self.id).columnOrder(column)
                row_values.append(self.session.findById(self.id).getCellValue(row, column_id))
            table_values.append(row_values)
        return table_values

    def __getitem__(self, column) -> GridViewCtrlColumn:
        if isinstance(column, int):
            column_id = self.session.findById(self.id).columnOrder(column)
            return GridViewCtrlColumn(self.session, self.id, column_id)
        if column in self.header_names:
            idx = self.header_names.index(column)
            column_id = self.header_ids[idx]
            return GridViewCtrlColumn(self.session, self.id, column_id)
        if column in self.header_ids:
            column_id = column
            return GridViewCtrlColumn(self.session, self.id, column_id)
        raise Exception('__getitem__(): GridViewCtrl列索引必须是SAP_ID、整数、标题名之一')

    def to_adtable(self, _table=None) -> AdTable:
        if _table is None:
            _table = AdTable('grid_view_ctrl')
        for column, value in enumerate(self.header_names, start=1):  # 标题行
            _table[column][1].value = value
        for row, line in enumerate(self.values, start=2):  # 内容
            for column, value in enumerate(line, start=1):
                _table[column][row].value = value
        return _table

    def to_dataframe(self):
        import pandas as pd
        _df = pd.DataFrame(columns=self.header_names)  # 标题
        for row, line in enumerate(self.values, start=1):  # 内容
            _df.loc[row] = line
        return _df
