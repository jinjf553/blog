from typing import Any, List


class GuiTree(object):
    session: Any
    id: str

    def __init__(self, session: Any, gui_tree_id: str):
        self.session = session
        self.id = gui_tree_id.replace(self.session.id + '/', '')

    @property
    def header_ids(self) -> List[str]:
        return list(self.session.findById(self.id).GetColumnNames())

    @property
    def header_names(self) -> List[str]:
        # TODO
        pass

    @property
    def row_ids(self) -> List[str]:
        return list(self.session.findById(self.id).GetAllNodeKeys())

    @property
    def row_count(self) -> int:
        return len(self.row_ids)

    @property
    def column_count(self) -> int:
        return len(self.header_ids)

    @property
    def values(self) -> List[List[str]]:
        """[[行1], [行2], ... [行n]]"""
        result: List[List[str]] = []
        for row in self.row_ids:
            row_values = []
            for column in self.header_ids:
                self.session.findById(self.id).ensureVisibleHorizontalItem(row, column)
                value = self.session.findById(self.id).GetItemText(row, column)
                row_values.append(value.strip(' \t\r\n'))
            result.append(row_values)
        return result


# example
# gui_tree = GuiTree(session, "wnd[0]/usr/cntlCUSTOM_CONTROL/shellcont/shell/shellcont[1]/shell[1]")
# gui_tree.values
