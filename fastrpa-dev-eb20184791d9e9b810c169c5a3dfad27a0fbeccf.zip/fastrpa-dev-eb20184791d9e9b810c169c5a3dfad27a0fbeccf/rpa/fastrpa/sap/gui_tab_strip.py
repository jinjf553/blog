from typing import Any, Iterator, List


class GuiTab(object):
    session: Any
    id: str

    @property
    def Text(self) -> str:  # noqa: N802
        return self.session.findById(self.id).Text

    def __init__(self, session: Any, gui_tab_id: str):
        self.session = session
        self.id = gui_tab_id

    def select(self):
        self.session.findById(self.id).select()

    def findById(self, id: str):  # noqa: N802
        """GuiTab是一个容器，可以包含子元素，这里findById可以使用相对id定位子元素"""
        return self.session.findById(self.id).findById(id)


class GuiTabStrip(object):
    session: Any
    id: str
    gui_tab_ids: List[str]
    gui_tab_texts: List[str]

    @property
    def gui_tabs(self) -> List[GuiTab]:
        return [GuiTab(self.session, gui_tab_id) for gui_tab_id in self.gui_tab_ids]

    def __init__(self, session: Any, gui_tab_strip_id: str):
        self.session = session
        self.id = gui_tab_strip_id.replace(self.session.id + '/', '')
        self.gui_tab_ids = [child.id.replace(self.session.id + '/', '') for child in self.session.findById(self.id).Children]
        self.gui_tab_texts = [self.session.findById(gui_tab_id).Text for gui_tab_id in self.gui_tab_ids]

    def __getitem__(self, gui_tab) -> GuiTab:
        if isinstance(gui_tab, str):
            if gui_tab in self.gui_tab_texts:
                idx = self.gui_tab_texts.index(gui_tab)
                return GuiTab(self.session, self.gui_tab_ids[idx])
            elif gui_tab in self.gui_tab_ids:
                return GuiTab(self.session, gui_tab)
        raise Exception('__getitem__(): GuiTabStrip列索引必须是GuiTab的Text或ID之一')

    def __iter__(self) -> Iterator[GuiTab]:
        return iter(self.gui_tabs)
