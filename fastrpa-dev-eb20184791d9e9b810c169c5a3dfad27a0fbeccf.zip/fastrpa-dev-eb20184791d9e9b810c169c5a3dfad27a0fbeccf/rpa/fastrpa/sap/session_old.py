"""与SAP会话有关的工具函数"""
import ctypes.wintypes
import datetime
import logging
import os
import re
import threading
import time
import winreg
from pathlib import Path
from threading import Thread
from time import sleep
from typing import Any, List, Optional, Tuple

import pythoncom
import requests
import rpa.config
import win32api
import win32com
import win32com.client
import win32con
import win32gui
from pythoncom import com_error  # pylint: disable=fixme, no-name-in-module
from rpa.config import CHROME_DRIVER_EXE_PATH
from rpa.fastrpa.chromium import CHROME_EXE, init_chromium
from rpa.fastrpa.console import set_close_fn
from rpa.fastrpa.log import config, logfn
from rpa.fastrpa.myredis import MyRedis
from rpa.fastrpa.named_lock import NamedLock
from rpa.fastrpa.sap.allow_system_messages import allow_system_messages
from rpa.fastrpa.third_party.isa import decrypt
from rpa.fastrpa.utils.force_rm import force_rm
from rpa.fastrpa.utils.window import (click_allow, move_window_to_screen,
                                      pass_sapgui_err_window)
from rpa.public.config import recv_user, send_mail, user_name
from rpa.public.myftp import MYFTP
from rpa.public.run_sap import login_sap
from rpa.ssc.hr.orm.orm_ope import get_session
from rpa.ssc.hr.orm.session import DbSession
from rpa.ssc.hr.orm.tb_dim_hr_staff import TB_DIM_HR_STAFF
from rpa.ssc.hr.orm.tb_user import User
from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.support import expected_conditions
from selenium.webdriver.support.wait import WebDriverWait
from win32com.client import CDispatch as COMObject

CSIDL_PERSONAL = 5       # My Documents
SHGFP_TYPE_CURRENT = 0   # Get current, not default value
SUPPORTED_ENTER_MODES: List[str] = ['login_tx', 'reopen', 'share', 'reuse', 'new_connection', 'new_session']
SUPPORTED_EXIT_MODES: List[str] = ['close_sap', 'back_to_main_window', 'nothing_to_do', 'close_connection', 'close_session']


def init_sap_logon_config() -> None:
    winreg.CreateKey(winreg.HKEY_CURRENT_USER, r"SOFTWARE\SAP\SAPGUI Front\SAP Frontend Server\Security")  # 为避免key不存在打开时报错，要先创建
    with winreg.OpenKey(winreg.HKEY_CURRENT_USER, r"SOFTWARE\SAP\SAPGUI Front\SAP Frontend Server\Security", 0, winreg.KEY_SET_VALUE) as key:
        # [X] 辅助功能与脚本>脚本>启用脚本
        winreg.SetValueEx(key, "UserScripting", 1, winreg.REG_DWORD, 1)
        # [ ] 辅助功能与脚本>脚本>在脚本附加到 SAP GUI 时发出通知(N)
        winreg.SetValueEx(key, "WarnOnAttach", 1, winreg.REG_DWORD, 0)
        # [ ] 辅助功能与脚本>脚本>在脚本打开连接时发出通知(W)
        winreg.SetValueEx(key, "WarnOnConnection", 1, winreg.REG_DWORD, 0)
        # [X] 安全性>安全设置>安全规则状态>缺省操作：允许
        winreg.SetValueEx(key, "DefaultAction", 1, winreg.REG_DWORD, 0)  # 这里0代表允许，1代表询问
    winreg.CreateKey(winreg.HKEY_CURRENT_USER, r"SOFTWARE\SAP\SAPGUI Front\SAP Frontend Server\Scripting")
    with winreg.OpenKey(winreg.HKEY_CURRENT_USER, r"SOFTWARE\SAP\SAPGUI Front\SAP Frontend Server\Scripting", 0, winreg.KEY_SET_VALUE) as key:
        # [ ] 辅助功能与脚本>脚本>显示本机 Microsoft Windows 对话框(S)
        winreg.SetValueEx(key, "ShowNativeWinDlgs", 1, winreg.REG_DWORD, 0)
    winreg.CreateKey(winreg.HKEY_CURRENT_USER, r"SOFTWARE\SAP\SAPGUI Front\SAP Frontend Server\LocalData")
    with winreg.OpenKey(winreg.HKEY_CURRENT_USER, r"SOFTWARE\SAP\SAPGUI Front\SAP Frontend Server\LocalData", 0, winreg.KEY_SET_VALUE) as key:
        # [X] 本地数据>文件生存期>删除文档文件夹中的文件和子文件夹 在 SAP Logon (Pad) 关闭期间始终
        winreg.SetValueEx(key, "DeleteDocuments", 1, winreg.REG_DWORD, 1)
        # [X] 本地数据>文件生存期>删除跟踪文件夹中的文件 在 SAP Logon (Pad) 关闭期间始终
        winreg.SetValueEx(key, "DeleteTraces", 1, winreg.REG_DWORD, 1)


@logfn
def save_sap_window_clip():
    from PIL import Image
    now = datetime.datetime.now()
    yyyymm = now.strftime(r'%Y%m')
    yyyymmdd = now.strftime(r'%Y%m%d')
    hhmmss = now.strftime(r'%H%M%S')
    p = Path(f'{rpa.config.RPA_SCREENSHOTS_DIR}/{yyyymm}/{yyyymmdd}/{hhmmss}_{rpa.config.STAFF_GROUP}_{rpa.config.STAFF_NAME}')
    try:
        sap_gui_auto = win32com.client.GetObject("SAPGUI")
        application = sap_gui_auto.GetScriptingEngine
    except Exception:
        return
    with MYFTP() as myftp:
        for connection in application.children:
            for session in connection.children:
                staff_funj = str(session.info.user).strip()
                if staff_funj != '':
                    for window in session.children:
                        if '中国石化人力资源管理系统用户菜单' in window.Text:
                            continue  # 主屏幕不保存截图（价值不大）
                        window_id: str = window.id
                        p.mkdir(parents=True, exist_ok=True)
                        sleep(1)  # 延迟1秒截图
                        bmp_filename = str(p.joinpath(staff_funj + '_' + window_id.replace('/', '_') + '.bmp'))
                        webp_filename = str(p.joinpath(staff_funj + '_' + window_id.replace('/', '_') + '.webp'))
                        remote_webp_filename = Path(webp_filename).relative_to('d:').as_posix()
                        window.HardCopy(bmp_filename)  # 保存窗口截图
                        if Path(bmp_filename).exists():
                            Image.open(bmp_filename).save(webp_filename, format='webp', quality=1)
                            logging.info(f'保存SAP截图: {webp_filename}')
                            myftp.upload_file(webp_filename, remote_webp_filename, log_flag=False)
                            if Path(bmp_filename).exists():
                                os.remove(bmp_filename)


def restore_pa20_pa30_window():
    try:
        sap_gui_auto = win32com.client.GetObject("SAPGUI")
        application = sap_gui_auto.GetScriptingEngine
        for connection in application.children:
            for session in connection.children:
                session.findById("wnd[0]/tbar[0]/okcd").text = "/n pa20"
                session.findById("wnd[0]").sendVKey(0)
                session.findById("wnd[0]").resizeWorkingPane(232, 38, 0)
                session.findById("wnd[0]/shellcont").dockerPixelSize = 318
                session.findById("wnd[0]/tbar[0]/okcd").text = "/n pa30"
                session.findById("wnd[0]").sendVKey(0)
                session.findById("wnd[0]").resizeWorkingPane(232, 38, 0)
                session.findById("wnd[0]/shellcont").dockerPixelSize = 318
    except Exception:
        return


def close_sap() -> None:
    """关闭SAP"""
    save_sap_window_clip()
    restore_pa20_pa30_window()
    for _ in range(100):
        dialog = win32gui.FindWindow(u"SAP_FRONTEND_SESSION", None)  # 对话框
        if dialog:
            win32gui.PostMessage(dialog, win32con.WM_CLOSE, 0, 0)
            time.sleep(1)

    for _ in range(100):
        dialog = win32gui.FindWindow(None, "SAP Logon 750")  # 对话框
        if dialog:
            win32gui.PostMessage(dialog, win32con.WM_CLOSE, 0, 0)
            time.sleep(1)

    for _ in range(100):
        dialog = win32gui.FindWindow(None, "SAP Logon 740")  # 对话框
        if dialog:
            win32gui.PostMessage(dialog, win32con.WM_CLOSE, 0, 0)
            time.sleep(1)

    for _ in range(100):
        dialog = win32gui.FindWindow(None, "SAP Logon 730")  # 对话框
        if dialog:
            win32gui.PostMessage(dialog, win32con.WM_CLOSE, 0, 0)
            time.sleep(1)
    try:
        force_rm(f'{rpa.config.D_RPA}/lock/sap_sessions')
    except FileNotFoundError:
        pass


def connect_to_sap(skip_session_ids=[], repeat_times=120, recur_error=False) -> COMObject:
    """尝试连接SAP，成功返回会话ID，连接失败返回None，其他情况抛出异常。"""
    for _ in range(repeat_times):
        try:
            sap_gui_auto = win32com.client.GetObject("SAPGUI")
            application = sap_gui_auto.GetScriptingEngine
            if application.AllowSystemMessages is True:  # 关闭SAP系统消息，系统消息如邮件通知可随时弹出，影响RPA执行
                allow_system_messages(False)
            for connection in application.children:
                for session in connection.children:
                    session_id: str = session.id
                    try:
                        with NamedLock(session_id, timeout=0, recur_error=recur_error):  # session未被占用，可以连接
                            pass_sap_login_window(session)
                            if session_id in skip_session_ids:  # 跳过会话
                                continue
                            else:
                                session.findById("wnd[0]")  # 验证session是否有效
                            return session
                    except Exception:  # nosec
                        pass
        except pythoncom.com_error:  # pylint: disable=fixme, no-member
            pass
        time.sleep(0.5)
    raise Exception('连接SAP失败')


def pass_sap_login_window(session: COMObject) -> None:
    if "口令不正确" in session.findById("wnd[0]/sbar/pane[0]").text:
        session.findById("wnd[0]/tbar[0]/okcd").text = "/nex"
        session.findById("wnd[0]").sendVKey(0)
        with DbSession() as db_session:
            sap_username, _ = user_name()
            db_session.query(User).filter_by(username=sap_username).update({'state': '0'})
            send_mail(recv_user(), sap_username)
        close_sap()
        raise Exception('SAP口令不正确')
    try:
        if "多次登录许可信息" in session.findById("wnd[1]").Text:
            session.findById("wnd[1]/usr/radMULTI_LOGON_OPT2").select()
            session.findById("wnd[1]/usr/radMULTI_LOGON_OPT2").setFocus()
            session.findById("wnd[1]/tbar[0]/btn[0]").press()
    except com_error:
        pass


def windowlist(browser, number=2, duration=10):
    handles = browser.window_handles
    for i in range(duration * 2):
        handles = browser.window_handles
        if len(handles) == number:
            return handles
        else:
            time.sleep(0.5)
    else:
        raise Exception('Timeout: %s window' % str(len(handles)))


def fetch_tx(fso_username: Optional[str] = None, repeat_times: int = 3) -> str:
    """登录业务人员FSO账号，获取对应的.tx文件内容，保存至Redis
       业务人员无法直接登录SAP，只能通过FSO穿GUI登录
       RPA可以模拟人登录FSO网站，下载.tx用于登录当前用户的SAP账号"""
    if not isinstance(fso_username, str):
        fso_username = rpa.config.FSO_USERNAME
    if fso_username is None or fso_username == '':
        raise Exception('当前用户未登录')
    fso_password = ''  # nosec
    with DbSession() as db_session:
        req: Optional[TB_DIM_HR_STAFF] = db_session.query(TB_DIM_HR_STAFF).filter(TB_DIM_HR_STAFF.fso_username == fso_username).first()
        if req:
            fso_password = str(decrypt(req.fso_password))
        else:
            raise Exception('当前用户FSO账号无效')
    logging.info('重新获取SAP用户登录票据')
    chrome_options = webdriver.ChromeOptions()
    chrome_options.binary_location = CHROME_EXE
    chrome_options.headless = True
    browser = webdriver.Chrome(
        executable_path=CHROME_DRIVER_EXE_PATH, chrome_options=chrome_options)
    browser.get("https://fso.sinopec.com")
    sleep(3)
    browser.maximize_window()
    wait = WebDriverWait(browser, 30)
    if '待办事项' in browser.title:  # 已登录
        pass
    else:
        wait.until(lambda x: x.find_element_by_xpath('//*[@id="j_username"]')).send_keys("z")  # 用户名输入框获取焦点
        wait.until(lambda x: x.find_element_by_xpath('//*[@id="j_username"]')).clear()  # 清除内容
        wait.until(lambda x: x.find_element_by_xpath('//*[@id="j_username"]')).send_keys(fso_username)  # 输入用户名
        wait.until(lambda x: x.find_element_by_xpath('//*[@id="j_password"]')).send_keys("p")  # 密码输入框获取焦点
        wait.until(lambda x: x.find_element_by_xpath('//*[@id="j_password"]')).clear()  # 清除内容
        wait.until(lambda x: x.find_element_by_xpath('//*[@id="j_password"]')).send_keys(fso_password)  # 输入密码
        try:
            wait.until(lambda x: x.find_element_by_xpath('//*[@id="authen1Form"]/button')).click()  # 点击[登录]
        finally:
            try:
                Path(f'{rpa.config.RPA_SCREENSHOTS_DIR}/chromium').mkdir(parents=True, exist_ok=True)
                browser.get_screenshot_as_file(f'{rpa.config.RPA_SCREENSHOTS_DIR}/chromium/01点击登录后_{repeat_times}.webp')  # 保存网页截图
            except (FileNotFoundError, PermissionError):
                pass
        sleep(3)
        if '密码过期提醒' in browser.title:
            try:
                wait.until(lambda x: x.find_element_by_xpath('//*[@id="login-form-cancel"]')).click()  # 点击[跳过]
            except Exception:
                error_info = wait.until(lambda t: t.find_element_by_xpath('//*[@id="errorDivMsg"]')).text
                raise Exception(error_info)  # 您的密码将于5日后过期;是否重新设置您的密码
        try:
            wait.until(expected_conditions.frame_to_be_available_and_switch_to_it((By.XPATH, '//*[@id="CRMApplicationFrame"]')))
            wait.until(expected_conditions.frame_to_be_available_and_switch_to_it((By.XPATH, '//*[@id="WorkAreaFrame1"]')))
        except Exception:
            try:
                error_info = wait.until(lambda t: t.find_element_by_xpath('//*[@id="errorDivMsg"]')).text
                warn_info = wait.until(lambda t: t.find_element_by_xpath('//*[@id="otpOrSmsErrorDivMsg"]')).text
            except Exception:
                error_info, warn_info = '认证失败', ""
            if "认证失败" in error_info or "failed" in error_info or "验证码" in warn_info or \
                    "verification" in warn_info or "您已登录" in error_info or "Your" in error_info or "密码已过期" in error_info:
                with DbSession() as s:
                    res = s.query(TB_DIM_HR_STAFF).filter(TB_DIM_HR_STAFF.fso_username == fso_username)
                    if res.first():
                        if str(res.first().fso_state).isdigit():
                            if int(res.first().fso_state) > 4:
                                res.update({"fso_state": 0, "update_time": datetime.datetime.now()})
                            else:
                                res.update({"fso_state": int(res.first().fso_state) + 1, "update_time": datetime.datetime.now()})
                        else:
                            res.update({"fso_state": '1', 'update_time': datetime.datetime.now()})
                raise Exception(warn_info)
    try:
        Path(f'{rpa.config.RPA_SCREENSHOTS_DIR}/chromium').mkdir(parents=True, exist_ok=True)
        browser.get_screenshot_as_file(f'{rpa.config.RPA_SCREENSHOTS_DIR}/chromium/02点击HR本地GUI前_{repeat_times}.webp')  # 保存网页截图
    except Exception:  # nosec
        pass
    try:
        wait.until(lambda t: t.find_element_by_xpath('//*[@id="C4_W17_V18_ZURL_EP_HR"]')).click()  # 点击HR本地GUI
    except Exception as e:
        logging.error('点击[HR本地UGI]错误')
        try:
            Path(f'{rpa.config.RPA_SCREENSHOTS_DIR}/chromium').mkdir(parents=True, exist_ok=True)
            browser.get_screenshot_as_file(f'{rpa.config.RPA_SCREENSHOTS_DIR}/chromium/03点击HR本地GUI后_{repeat_times}.webp')  # 保存网页截图
        except Exception:  # nosec
            pass
        if repeat_times > 0:
            return fetch_tx(fso_username, repeat_times - 1)
        else:
            raise e
    handles = windowlist(browser)
    browser.switch_to.window(handles[1])
    html = browser.page_source
    url = re.findall(r'src="(http://10.*?)">', html)[0].replace('amp;', '') + '&%24Roundtrip=true&%24DebugAction=null'
    con = requests.get(url)
    tx = f"{str(con.text)}|{str(time.strftime('%Y%m%d%H%M%S'))}"
    if '[System]' in con.text:
        # with DbSession() as s:
        #     s.query(TB_DIM_HR_STAFF).filter(TB_DIM_HR_STAFF.fso_username == fso_username).update({'remark2': tx, 'update_time': datetime.datetime.now()})
        with MyRedis() as myredis:
            redis_id = f'fso_tx:{fso_username}'
            myredis.set(redis_id, tx)
    browser.quit()
    return tx


def connect_tx_session(tx: str) -> COMObject:
    """连接至tx对应的sap会话"""
    Path(f'{rpa.config.D_RPA}/tx.sap').write_text(tx, encoding='utf-8')
    win32api.ShellExecute(0, 'open', 'sapshcut.exe', f'{rpa.config.D_RPA}/tx.sap', '', 1)
    return connect_to_sap(repeat_times=30)


def is_tx_session_outdated(session: Any) -> bool:
    """检查tx对应的session是否过期"""
    sap_status = session.findById("wnd[0]/sbar/pane[0]").text
    return '票已过期' in sap_status


def valid_tx_session_funj(staff_sap_session: Any):
    """校验TX登录后FUNJ与业务人员在数据库中登记的FUNJ是否一致"""
    staff_funj = str(staff_sap_session.info.user)
    if staff_funj != rpa.config.SAP_FUNJ:
        close_sap()
        raise Exception(f'用户注册时FUNJ为{rpa.config.SAP_FUNJ}，个人SAP账号FUNJ为{staff_funj}，两者不一致，请核实注册信息是否有误！')


def login_tx(fso_username: Optional[str] = None):
    init_chromium()
    if fso_username is None:
        fso_username = rpa.config.FSO_USERNAME
    if fso_username is None or len(fso_username) == 0:
        raise Exception('未登录，无法打开业务人员SAP账号')
    tx: str = ''
    with MyRedis() as myredis:
        redis_key = f'fso_tx:{fso_username}'
        tx = myredis.get(redis_key) or ''
    close_sap()
    if tx == '':
        logging.info('当前用户无SAP登录信息，重新登录FSO获取')
        tx = fetch_tx(fso_username)
        session = connect_tx_session(tx)
    else:
        try:
            session = connect_tx_session(tx)
            sap_status = session.findById("wnd[0]/sbar/pane[0]").text
            if '票已过期' in sap_status:
                with MyRedis() as myredis:
                    redis_key = f'fso_tx:{fso_username}'
                    myredis.delete(redis_key)
            if sap_status != '':
                logging.error(sap_status)
                raise Exception(sap_status)
        except Exception:
            close_sap()
            tx = fetch_tx(fso_username)
            session = connect_tx_session(tx)
        if is_tx_session_outdated(session):
            close_sap()
            tx = fetch_tx(fso_username)
            session = connect_tx_session(tx)
    valid_tx_session_funj(session)  # 验证FUNJ
    logging.info(f'=========登录业务人员(FSO_USERNAME：{fso_username}，FUNJ：{rpa.config.SAP_FUNJ})SAP账号执行操作=========')


def open_sap(sysname='PH3', client='800') -> None:
    """打开SAP"""
    init_sap_logon_config()
    username, password = user_name()
    win32api.ShellExecute(0, 'open', r"sapshcut.exe",
                          f'-maxgui -user={username} -pw={password} -sysname={sysname} -client={client}', '', 1)
    _ = Thread(target=click_allow)  # 关闭[SAP GUI 安全性]窗口
    _.setDaemon(True)
    _.start()
    session = connect_to_sap(repeat_times=30)
    if "口令不正确" in session.findById("wnd[0]/sbar/pane[0]").text:
        session.findById("wnd[0]/tbar[0]/okcd").text = "/nex"
        session.findById("wnd[0]").sendVKey(0)
        close_sap()
        session = get_session()
        session.query(User).filter_by(username=username).update({'state': '0'})
        session.commit()
        send_mail(recv_user(), username)
        raise Exception('SAP口令不正确')
    try:
        if "多次登录许可信息" in session.findById("wnd[1]").Text:
            session.findById("wnd[1]/usr/radMULTI_LOGON_OPT2").select()
            session.findById("wnd[1]/usr/radMULTI_LOGON_OPT2").setFocus()
            session.findById("wnd[1]/tbar[0]/btn[0]").press()
    except pythoncom.com_error:  # pylint: disable=fixme, no-member
        pass


def get_connection_and_session_cnt() -> Tuple[int, int]:
    """返回connection数量，和最后一个connection的session数量"""
    for _ in range(30):
        try:
            sap_gui_auto = win32com.client.GetObject("SAPGUI")
            application = sap_gui_auto.GetScriptingEngine
            connection_cnt = len(application.children)
            connection = application.children(connection_cnt - 1)
            session_cnt = len(connection.Children)
            return connection_cnt, session_cnt
        except pythoncom.com_error:  # pylint: disable=fixme, no-member
            time.sleep(0.5)
    raise Exception('SAP未启动')


def pass_repeat_login_window(session: Any):
    """SAP【多次登录许可信息】窗口，勾选继续此登录，确认。"""
    try:
        if '多次登录许可信息' in session.findById("wnd[1]").text:
            session.findById("wnd[1]/usr/radMULTI_LOGON_OPT2").select()
            session.findById("wnd[1]/tbar[0]/btn[0]").press()
    except Exception:  # nosec
        pass


def back_to_main_window(session):
    """返回SAP首屏"""
    try:
        session.findById("wnd[0]/tbar[0]/okcd").text = "/n"
        session.findById("wnd[0]").sendVKey(0)
        session.findById("wnd[0]/tbar[0]/okcd").text = "/n"
        session.findById("wnd[0]").sendVKey(0)
        session.findById("wnd[0]/usr/btnSTARTBUTTON").press()
    except Exception as e:
        raise e


def create_new_session(session) -> Any:
    """创建会话，并返回新会话的session，一次登录最多可创建6个会话"""
    session.findById("wnd[0]/mbar/menu[4]/menu[0]").select()  # 创建新session
    try:
        if '达到最大会话数目' in session.findById("wnd[1]/usr/txtMESSTXT1").Text:
            session.findById("wnd[1]/tbar[0]/btn[0]").press()  # 点击[对号]确认
            raise Exception('达到最大会话数目')
    except pythoncom.com_error:  # pylint: disable=fixme, no-member
        pass
    for i in range(5):  # 必须循环，点击创建会话后，新会话不是立即生成
        sap_gui_auto = win32com.client.GetObject("SAPGUI")
        application = sap_gui_auto.GetScriptingEngine
        logging.info(len(application.children))
        connection = application.children(0)
        logging.info(len(connection.Children))
        for s in connection.Children:
            try:
                Path(f'{rpa.config.D_RPA}/lock/sap_sessions/').joinpath(s.Id.replace('/', '_')).mkdir(parents=True, exist_ok=False)
                return s
            except FileExistsError:
                pass
        sleep(1)
    raise Exception('创建新会话失败')


def close_session(session):
    """结束会话"""
    session.findById("wnd[0]/mbar/menu[4]/menu[1]").select()  # 结束会话


FIRST_TIME_RUN = True


def attach_sap(mode: str = 'reopen', *, fso_username: Optional[str] = None) -> Any:
    """参数:
            mode='login_tx' 登录业务人员SAP账号
                 ,'reopen' 强制重新打开SAP
                 ,'share' 尝试连接已打开的SAP（如SAP未打开，则报错，适用于人机交互场景）
                 ,'reuse' 尝试连接已打开的SAP，并返回首屏（如SAP未打开，则重新打开SAP，尽可能复用已打开的SAP）
            recur 无需传参，程序内部维护，避免share模式连接SAP失败时产生无限递归
            如调用成功，返回SAP
    """
    global FIRST_TIME_RUN
    if fso_username is None:
        fso_username = rpa.config.FSO_USERNAME
    if mode not in SUPPORTED_ENTER_MODES:
        raise Exception(f'attach_sap mode={mode}，应为{SUPPORTED_ENTER_MODES}之一。')
    if mode == 'login_tx':
        login_tx(fso_username)
        session = connect_to_sap(repeat_times=1)
    elif mode not in ['share', 'reuse']:  # 这两种模式复用已有会话，所以不知道会话的账号是什么
        logging.info("=========登录RPA(FUNJ：FUNJ0016)SAP账号执行操作=========")
    if mode == 'reopen':  # 强制重新打开SAP（如SAP已登录，则先关闭），使用场景：RPA启动后第一次操作SAP
        close_sap()
        open_sap()
        session = connect_to_sap(repeat_times=1)
    elif mode == 'share':  # 获取SAP实例句柄，使用场景：业务人员已执行某些个性化操作，RPA需要继续往下执行
        session = connect_to_sap(repeat_times=1)
    elif mode == 'reuse':  # 复用现有的SAP实例（如SAP已打开，则返回主屏）
        try:
            session = connect_to_sap(repeat_times=1)
            back_to_main_window(session)
        except Exception:
            session = attach_sap('reopen').session
    elif mode == 'login_sap':
        session = login_sap()
        move_window_to_screen(session.findById('wnd[0]').Handle, 0)
        return session
    elif mode == 'new_session':  # 返回一个新session
        with NamedLock('new_session'):
            if FIRST_TIME_RUN is True:
                close_sap()
            FIRST_TIME_RUN = False
            try:
                base_session = connect_to_sap(repeat_times=1)
            except Exception:
                # close_sap() 这里不能close_sap，因为可能关闭其他线程的SAP会话
                open_sap()
                base_session = connect_to_sap(repeat_times=1)
            s = create_new_session(base_session)
            session = s  # 根据第一个session派生新会话
            logging.info(f'连接SAP会话{s.id}')
            sleep(5)
            return s

    class SapSession:
        """解决SAP收到邮件时突然出现的弹窗问题"""

        def __init__(self, session: Any) -> None:
            self.session = session

        @property
        def id(self) -> str:
            return self.session.id

        @property
        def parent(self) -> str:
            return self.session.parent

        @property
        def children(self) -> COMObject:
            return self.session.children

        @property
        def info(self):
            return self.session.info  # GuiSessionInfo对象，其中user属性存储FUNJ号

        def findById(self, s: str, throw_exception: bool = False) -> COMObject:  # noqa: N802
            if self.session.findById("wnd[1]", False) is not None:
                if self.session.findById("wnd[1]").text == "SAPoffice 快件信息":
                    self.session.findById("wnd[1]/tbar[0]/btn[0]").press()
            return self.session.findById(s, throw_exception)

    move_window_to_screen(session.findById('wnd[0]').Handle, 0)  # 为了保证能录制到SAP屏幕，将SAP窗口挪至此位置

    return SapSession(session)


def close_sap_when_main_thread_exit(current_thread: Thread):
    while True:
        if threading.main_thread().is_alive() is True and current_thread.is_alive() is True:  # 主线程执行
            sleep(0.5)
        else:  # 主线程退出
            close_sap()
            return


thread_close_sap = None
thread_pass_sapgui_err_window = None


class SapClose(object):
    """创建子线程，当主线程退出，或with语句结束时，关闭SAP（开启调试模式时无效）"""

    def __enter__(self):
        global thread_close_sap
        global thread_pass_sapgui_err_window
        if thread_close_sap is None:
            thread_close_sap = Thread(target=close_sap_when_main_thread_exit, args=[threading.current_thread()])
            thread_close_sap.start()
        if thread_pass_sapgui_err_window is None:
            thread_pass_sapgui_err_window = Thread(target=pass_sapgui_err_window)
            thread_pass_sapgui_err_window.setDaemon(True)
            thread_pass_sapgui_err_window.start()
        set_close_fn(close_sap)
        close_sap()

    def __exit__(self, exc_type, exc_val, exc_tb):
        close_sap()


class SapSessionClose(object):

    def __init__(self, session: Any):
        self.session = session

    def __enter__(self):
        pass

    def __exit__(self, exc_type, exc_val, exc_tb):
        with NamedLock('new_session'):
            close_session(self.session)


def clean_sap_gui_cache_dir():
    """清理SAP缓存目录"""
    try:
        buf = ctypes.create_unicode_buffer(ctypes.wintypes.MAX_PATH)
        ctypes.windll.shell32.SHGetFolderPathW(None, CSIDL_PERSONAL, None, SHGFP_TYPE_CURRENT, buf)
        documnet_dir = buf.value
        if documnet_dir[0] == '/':
            raise Exception('获取文档目录失败')
    except Exception:
        logging.error('获取文档目录失败')
        return
    sap_gui_cache_dir = Path(documnet_dir).joinpath('SAP').as_posix()
    if Path(sap_gui_cache_dir).exists() is True:
        # logging.info(f'清理SAP文档缓存路径：{sap_gui_cache_dir}')
        force_rm(sap_gui_cache_dir)


if __name__ == '__main__':
    config()
