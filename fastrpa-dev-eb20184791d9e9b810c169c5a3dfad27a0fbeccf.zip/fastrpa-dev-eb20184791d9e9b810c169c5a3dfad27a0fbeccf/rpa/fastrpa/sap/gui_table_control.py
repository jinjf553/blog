from typing import Any, List


def calc_visible_row_count(visible_row_count: int, row: int):
    """尽可能多地展示元素前面的内容"""
    # visible_row_count是从1开始的整数，row是从0开始的整数
    if row + 1 < visible_row_count:
        return 0, row
    else:
        return row - visible_row_count + 1, visible_row_count - 1


class GuiTableControlCell(object):
    session: Any
    id: str
    column_idx: int
    row: int
    row_count: int
    visible_row_count: int

    @property
    def value(self) -> str:
        return self.Text

    @property
    def Text(self) -> str:
        position, row = calc_visible_row_count(self.visible_row_count, self.row)
        self.session.findById(self.id).VerticalScrollbar.position = position
        return str(self.session.findById(self.id).GetCell(row, self.column_idx).Text)

    @property
    def ToolTip(self) -> str:
        position, row = calc_visible_row_count(self.visible_row_count, self.row)
        self.session.findById(self.id).VerticalScrollbar.position = position
        return str(self.session.findById(self.id).GetCell(row, self.column_idx).ToolTip)

    @property
    def Row(self):
        return GuiTableControlRow(self.session, self.id, self.row)

    def __init__(self, session: Any, gui_table_control_id: str, column_idx: int, row: int):
        self.session = session
        self.id = gui_table_control_id.replace(self.session.id + '/', '')
        self.column_idx = column_idx
        self.row = row
        self.visible_row_count = session.findById(gui_table_control_id).VisibleRowCount
        self.row_count = session.findById(gui_table_control_id).RowCount - (self.visible_row_count - 1)

    def select_row(self):
        position, _ = calc_visible_row_count(self.visible_row_count, self.row)
        self.session.findById(self.id).VerticalScrollbar.position = position
        self.session.findById(self.id).getAbsoluteRow(self.row).selected = -1


class GuiTableColumn(object):
    session: Any
    id: str
    column_idx: int
    column_count: int
    row_count: int
    visible_row_count: int

    @property
    def values(self) -> List[str]:
        return [self.__getitem__(row).value for row in range(self.row_count)]

    def __init__(self, session: Any, gui_table_control_id: str, column_idx: int):
        self.session = session
        self.id = gui_table_control_id.replace(self.session.id + '/', '')
        self.column_idx = column_idx
        self.column_count = len(session.findById(gui_table_control_id).Columns)
        self.visible_row_count = session.findById(gui_table_control_id).VisibleRowCount
        self.row_count = session.findById(gui_table_control_id).RowCount - (self.visible_row_count - 1)

    def __getitem__(self, row: int):
        return GuiTableControlCell(self.session, self.id, self.column_idx, row)

    def find(self, value: str):
        for row in range(self.row_count):
            if self.__getitem__(row).value == value:
                return self.__getitem__(row)


class GuiTableControlRow(object):
    session: Any
    id: str
    row: int
    column_count: int
    row_count: int
    visible_row_count: int

    @property
    def values(self) -> List[str]:
        return [self.__getitem__(column_idx).value for column_idx in range(self.column_count)]

    @property
    def header_names(self) -> List[str]:
        return [column.Title for column in self.session.findById(self.id).Columns]

    @property
    def header_ids(self) -> List[int]:
        return list(range(self.column_count))

    def __init__(self, session: Any, gui_table_control_id: str, row: int):
        self.session = session
        self.id = gui_table_control_id.replace(self.session.id + '/', '')
        self.row = row
        self.column_count = len(session.findById(gui_table_control_id).Columns)
        self.visible_row_count = session.findById(gui_table_control_id).VisibleRowCount
        self.row_count = session.findById(gui_table_control_id).RowCount - (self.visible_row_count - 1)

    def __getitem__(self, column) -> GuiTableControlCell:
        if isinstance(column, int):
            return GuiTableControlCell(self.session, self.id, column, self.row)
        elif isinstance(column, str) and column in self.header_names:
            idx = self.header_names.index(column)
            return GuiTableControlCell(self.session, self.id, idx, self.row)
        raise Exception('__getitem__(): GuiTableControl列索引必须是整数、标题名之一')


class GuiTableControl(object):
    session: Any
    id: str
    column_count: int
    row_count: int
    visible_row_count: int

    @property
    def header_names(self) -> List[str]:
        return [column.Title for column in self.session.findById(self.id).Columns]

    @property
    def header_ids(self) -> List[int]:
        return list(range(self.column_count))

    @property
    def rows(self) -> List[GuiTableControlRow]:
        return [GuiTableControlRow(self.session, self.id, row) for row in range(self.row_count)]

    @property
    def columns(self) -> List[GuiTableColumn]:
        return [self.__getitem__(header_name) for header_name in self.header_names]

    def __init__(self, session: Any, gui_table_control_id: str):
        self.session = session
        self.id = gui_table_control_id.replace(self.session.id + '/', '')
        self.column_count = len(session.findById(gui_table_control_id).Columns)
        self.visible_row_count = session.findById(gui_table_control_id).VisibleRowCount
        self.row_count = session.findById(gui_table_control_id).RowCount - (self.visible_row_count - 1)

    def __getitem__(self, column) -> GuiTableColumn:
        if isinstance(column, int):
            return GuiTableColumn(self.session, self.id, column)
        elif isinstance(column, str) and column in self.header_names:
            idx = self.header_names.index(column)
            return GuiTableColumn(self.session, self.id, idx)
        raise Exception('__getitem__(): GuiTableControl列索引必须是整数、标题名之一')
