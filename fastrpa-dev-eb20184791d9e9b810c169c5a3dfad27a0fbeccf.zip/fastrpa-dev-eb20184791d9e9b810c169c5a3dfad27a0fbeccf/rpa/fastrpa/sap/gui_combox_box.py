from typing import Any


class GuiComboxBox(object):
    session: Any
    id: str

    def __init__(self, session: Any, gui_combox_box_id: str):
        self.session = session
        self.id = gui_combox_box_id.replace(self.session.id + '/', '')

    @property
    def values(self):
        return [entire.Value for entire in self.session.findById(self.id).Entries]

    @property
    def keys(self):
        return [entire.Value for entire in self.session.findById(self.id).Entries]

    def select_by_key(self, key: str):
        self.session.findById(self.id).key = key

    def select_by_value(self, value: str):
        for entire in self.session.findById(self.id).Entries:
            if entire.Value == value:
                return self.select_by_key(entire.key)
        raise Exception(f'GuiComboxBox:{self.id}没有找到值{value}')
