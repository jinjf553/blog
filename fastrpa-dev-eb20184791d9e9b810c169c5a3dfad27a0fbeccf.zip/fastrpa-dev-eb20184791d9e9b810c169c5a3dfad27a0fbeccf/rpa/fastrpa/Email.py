import logging
import os
from datetime import datetime, timedelta

from exchangelib import (DELEGATE, Account, Configuration, Credentials,
                         EWSDateTime, EWSTimeZone, FileAttachment, Mailbox,
                         Message)
from exchangelib.protocol import CachingProtocol

mail_config = {
    'server': 'mail.sinopec.com',
    'username': "gxvdirpa1.ssc@sinopec.com",
    'password': "Rpa13579"
}


class Email():
    def __init__(self, server: str = '', username: str = '', password: str = '') -> None:  # nosec
        '''参数：\n
            server: str, 邮箱服务地址 eg：mail.sinopec.com; \n
            username: str, 邮箱账号 eg: gxvdirpa1.ssc@sinopec.com; \n
            password: str, 邮箱密码
        '''
        self.server = server or mail_config['server']
        self.username = username or mail_config['username']
        self.password = password or mail_config['password']
        self.account = self.connect_to_mailbox()

    def connect_to_mailbox(self):
        try:
            cred = Credentials(self.username, self.password)
            config = Configuration(server="mail.sinopec.com", credentials=cred,)
            account = Account(
                primary_smtp_address=self.username,
                config=config,
                autodiscover=False,
                access_type=DELEGATE,
            )
            print("--------Connected--------")
        except Exception as e:
            raise Exception(f"{e}\n连接邮箱服务器失败，请检查邮箱配置信息")
        return account

    def rece_email(self, send_date: str = '20200101', subject_like: str = '', sender: str = '') -> list:
        """
        :param send_date: 收件日期 eg：20200101
        :param subject_like: 邮件主题包含字符
        :param sender: 发件人
        :return: list type
        """
        tz = EWSTimeZone.timezone("Asia/Shanghai")
        email_list = []
        _send_date = datetime.strptime(send_date, "%Y%m%d")
        inbox = self.account.inbox.filter(
            datetime_sent__gte=tz.localize(
                EWSDateTime(_send_date.year, _send_date.month, _send_date.day)
            )
        )

        for item in inbox.all().order_by("-datetime_sent"):
            if not item.sender:
                continue
            dic = {
                '主题': item.subject,
                '发送人': item.sender.name,
                '地址': item.sender.email_address,
                '内容': item.text_body,
                '接收时间': (item.datetime_sent + timedelta(hours=8)).strftime("%Y-%m-%d %H:%M:%S"),
                '附件': [{'附件名': attach.name, '附件内容': attach} for attach in item.attachments if isinstance(attach, FileAttachment)]
            }
            b1 = True if not subject_like or subject_like.lower() in item.subject.lower() else False
            b2 = True if not sender or sender.lower() in item.sender.name.lower() else False
            if b1 and b2:
                email_list.append(dic)
        print("{}至今共收到 {} 封邮件".format(_send_date, len(email_list)))
        return email_list

    def send_email(self, receivers: str = '', subject: str = '', body: str = '', attachments: list = []) -> None:
        '''
            :param receivers: 接收人地址,
            :param subject: 主题,
            :param body: 内容,
            :param attachments: 附件列表,文件路径地址
        '''
        try:
            receivers = receivers or mail_config['username']
            m = Message(
                account=self.account,
                folder=self.account.sent,
                subject=subject,
                body=body,
                to_recipients=[Mailbox(email_address=receivers)]
            )
            if attachments:
                for attachment in attachments:
                    if os.path.exists(attachment):
                        with open(attachment, 'rb') as f:
                            file_content = f.read()
                            file_name = os.path.basename(os.path.realpath(attachment))
                            m.attach(FileAttachment(name=file_name, content=file_content))
            m.send_and_save()
            logging.info("exchange发送邮件成功")
        except Exception as e:
            logging.error("exchange发送邮件失败，失败原因如下：")
            logging.error(e)

    @staticmethod
    def close_connections():
        CachingProtocol.clear_cache()


if __name__ == "__main__":
    email = Email()
    email_list = email.rece_email(send_date="20201012")
    first_file = email_list[0]['附件'][0]
    print(first_file)
    open(f'x:/{first_file["附件名"]}', 'wb').write(first_file["附件内容"].content)
    # email.send_email(receivers='553041800@qq.com', subject='测试')
    email.close_connections()
