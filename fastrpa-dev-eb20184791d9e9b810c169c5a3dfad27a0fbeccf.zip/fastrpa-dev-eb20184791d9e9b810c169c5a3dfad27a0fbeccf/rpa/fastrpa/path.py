from pathlib import Path


def to_windows_path_format(path: str) -> str:
    """将路径名转化为SAP要求的格式。即双斜杠作为路径分隔符"""
    return str(Path(path))
