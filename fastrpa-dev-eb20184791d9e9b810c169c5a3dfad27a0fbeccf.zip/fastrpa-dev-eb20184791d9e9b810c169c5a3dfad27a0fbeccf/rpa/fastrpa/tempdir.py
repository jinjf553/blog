import datetime
import logging
import shutil
import threading
import uuid
from pathlib import Path

import rpa.config

PREFIX_TEMP_DIR = ''

threading.main_thread().getName()


def reset_tempdir() -> str:
    global PREFIX_TEMP_DIR
    yyyymm = datetime.datetime.now().strftime(r'%Y%m')
    yyyymmdd = datetime.datetime.now().strftime(r'%Y%m%d')
    hhmmss = datetime.datetime.now().strftime(r'%H%M%S')
    p = Path(rpa.config.RPA_TEMP_DIR).joinpath(yyyymm).joinpath(yyyymmdd).joinpath(hhmmss)  # nosec
    p.mkdir(parents=True, exist_ok=True)
    PREFIX_TEMP_DIR = p.as_posix()
    logging.info('中间文件夹路径: ' + PREFIX_TEMP_DIR)
    return PREFIX_TEMP_DIR


def gentempdir() -> str:
    if PREFIX_TEMP_DIR == '':
        reset_tempdir()
    current_thread_name = threading.current_thread().getName()
    if current_thread_name == 'MainThread':
        current_thread_name = ''
    elif current_thread_name.isidentifier() is False:  # 如果线程名不是合法的目录名，则用uuid随机生成
        current_thread_name = str(uuid.uuid1())
    p = Path(PREFIX_TEMP_DIR).joinpath(current_thread_name)
    p.mkdir(parents=True, exist_ok=True)
    return p.as_posix()


def clean_last_3mon_temp_dir() -> None:
    yyyymm = datetime.datetime.now().strftime(r'%Y%m')  # 当月 yyyyMM 格式
    yyyymm01 = yyyymm + '01'
    last_yyyymm = (datetime.datetime.strptime(yyyymm01, "%Y%m%d") - datetime.timedelta(days=1)).strftime(r'%Y%m')  # 上月 yyyyMM 格式
    for file in Path(rpa.config.RPA_TEMP_DIR).glob('*'):
        if file.is_dir() is True and file.name not in (yyyymm, last_yyyymm):
            logging.info('清理过期文件夹: ' + file.as_posix())
            shutil.rmtree(file.as_posix())
