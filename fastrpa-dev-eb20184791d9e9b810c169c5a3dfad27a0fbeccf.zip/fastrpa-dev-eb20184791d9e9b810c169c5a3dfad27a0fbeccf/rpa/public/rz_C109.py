import pyperclip
from rpa.public.check_card import more_icon


def _C109(session, IDs):
    session.findById("wnd[0]").maximize()
    session.findById("wnd[0]/tbar[0]/okcd").text = "/n S_PH0_48000513"
    session.findById("wnd[0]").sendVKey(0)
    session.findById("wnd[1]/usr/cmbDYNP4100-DD_WORKSPACE").setFocus()
    session.findById("wnd[1]/usr/cmbDYNP4100-DD_WORKSPACE").key = "2"
    session.findById("wnd[1]/usr/cmbDYNP4100-DD_USERGROUP").setFocus()
    session.findById("wnd[1]/usr/cmbDYNP4100-DD_USERGROUP").key = "109"
    session.findById("wnd[1]/usr/tblSAPLAQ_INT_FUNCTIONSTCH_FUNCAREAS").getAbsoluteRow(0).selected = -1
    session.findById("wnd[1]/tbar[0]/btn[0]").press()
    sap_id = "wnd[0]/shellcont[1]/shell/shellcont[0]/shell/shellcont[1]/shell[1]"
    session.findById(sap_id).expandNode("          2")
    session.findById(sap_id).topNode = "          1"
    session.findById(sap_id).selectItem("          3", "C          4")
    session.findById(sap_id).ensureVisibleHorizontalItem("          3", "C          4")
    session.findById(sap_id).itemContextMenu("          3", "C          4")
    session.findById(sap_id).selectContextMenuItem("OUTPUT_BOTH")
    session.findById(sap_id).expandNode("          4")
    session.findById(sap_id).topNode = "          1"
    session.findById(sap_id).selectItem("         11", "C          4")
    session.findById(sap_id).ensureVisibleHorizontalItem("         11", "C          4")
    session.findById(sap_id).itemContextMenu("         11", "C          4")
    session.findById(sap_id).selectContextMenuItem("OUTPUT_BOTH")
    session.findById(sap_id).expandNode("         18")
    session.findById(sap_id).topNode = "          4"
    session.findById(sap_id).selectItem("         27", "C          4")
    session.findById(sap_id).ensureVisibleHorizontalItem("         27", "C          4")
    session.findById(sap_id).topNode = "         12"
    session.findById(sap_id).itemContextMenu("         27", "C          4")
    session.findById(sap_id).selectContextMenuItem("OUTPUT_BOTH")
    session.findById(sap_id).selectItem("         25", "C          4")
    session.findById(sap_id).ensureVisibleHorizontalItem("         25", "C          4")
    session.findById(sap_id).topNode = "         16"
    session.findById(sap_id).itemContextMenu("         25", "C          4")
    session.findById(sap_id).selectContextMenuItem("OUTPUT_BOTH")
    session.findById(sap_id).expandNode("        151")
    session.findById(sap_id).topNode = "         44"
    session.findById(sap_id).selectItem("        157", "C          4")
    session.findById(sap_id).ensureVisibleHorizontalItem("        157", "C          4")
    session.findById(sap_id).topNode = "         50"
    session.findById(sap_id).itemContextMenu("        157", "C          4")
    session.findById(sap_id).changeCheckbox("        157", "C          4", -1)
    session.findById(sap_id).selectItem("        157", "C          3")
    session.findById(sap_id).ensureVisibleHorizontalItem("        157", "C          3")
    session.findById(sap_id).changeCheckbox("        157", "C          3", -1)
    more_icon(session, "")
    text = "\r\n".join([id_ for id_ in IDs if isinstance(id_, str)])
    pyperclip.copy(text)
    session.findById("wnd[1]/tbar[0]/btn[16]").press()
    session.findById("wnd[1]/tbar[0]/btn[24]").press()
    session.findById("wnd[1]/tbar[0]/btn[8]").press()
    session.findById("wnd[0]/tbar[1]/btn[8]").press()
