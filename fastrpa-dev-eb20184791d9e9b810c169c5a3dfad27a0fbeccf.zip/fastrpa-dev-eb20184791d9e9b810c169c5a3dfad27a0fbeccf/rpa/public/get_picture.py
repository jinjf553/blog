#!/usr/bin/env python
# -*- coding: utf-8 -*-
# @File    : get_picture.py
# @Author  : jinjianfeng
# @Contact : 553041800@qq.com
# @Link    : https://github.com/jinjf553
# @software: PyCharm
# @Date    : 2019/8/31 14:21
# @Version : ??
import logging
import os
import shutil
import zipfile

import xlrd
from openpyxl import load_workbook
from rpa.config import TEMPLATE_DIR
from rpa.fastrpa.xlsx import fix_excel
from rpa.public.config import local_path


def isfile_exist(file_path):
    if not os.path.isfile(file_path):
        logging.info(f"It's not a file or no such file exist ! {file_path}")
        return False
    else:
        return True


# 修改指定目录下的文件类型名，将excel后缀名修改为.zip


def change_file_name(file_path, new_type='.zip'):
    if not isfile_exist(file_path):
        return ''

    extend = os.path.splitext(file_path)[1]  # 获取文件拓展名
    if extend != '.xlsx':
        logging.info(f"It's not a excel file! {file_path}")
        return False
    dir_path = os.path.dirname(file_path)  # 获取文件所在目录
    shutil.copyfile(file_path, dir_path + "/tmp.xlsx", follow_symlinks=True)
    file_name = dir_path + "/tmp.xlsx"  # os.path.basename(file_path)  # 获取文件名
    new_name = os.path.splitext(file_name)[0] + new_type  # 新的文件名，命名为：xxx.zip

    new_path = os.path.join(dir_path, new_name)  # 新的文件路径
    if os.path.exists(new_path):
        os.remove(new_path)

    os.rename(dir_path + "/tmp.xlsx", new_path)  # 保存新文件，旧文件会替换掉

    return new_path  # 返回新的文件路径，压缩包


# 解压文件
def unzip_file(zipfile_path):
    if not isfile_exist(zipfile_path):
        return False

    if os.path.splitext(zipfile_path)[1] != '.zip':
        logging.info(f"It's not a zip file! {zipfile_path}")
        return False

    file_zip = zipfile.ZipFile(zipfile_path, 'r')
    file_name = os.path.basename(zipfile_path)  # 获取文件名
    zipdir = os.path.join(os.path.dirname(zipfile_path), str(file_name.split('.')[0].strip()))  # 获取文件所在目录
    for files in file_zip.namelist():
        file_zip.extract(files, os.path.join(zipfile_path, zipdir))  # 解压到指定文件目录

    file_zip.close()
    return True


# 读取解压后的文件夹，打印图片路径
def read_img(zipfile_path):
    if not isfile_exist(zipfile_path):
        return False

    dir_path = os.path.dirname(zipfile_path)  # 获取文件所在目录
    file_name = os.path.basename(zipfile_path)  # 获取文件名
    pic_dir = 'xl' + os.sep + 'media'  # excel变成压缩包后，再解压，图片在media目录
    pic_path = os.path.join(dir_path, str(file_name.split('.')[0].strip()), pic_dir)
    if not os.path.exists(pic_path):
        return False
    file_list = os.listdir(pic_path)
    if file_list:
        file_list.reverse()
    for file in file_list:
        filepath = os.path.join(pic_path, file)
        if os.path.getsize(filepath) != 58769:
            return filepath


# 组合各个函数
def compenent(excel_file_path):
    zip_file_path = change_file_name(excel_file_path)
    if zip_file_path != '':
        if unzip_file(zip_file_path):
            return read_img(zip_file_path)


def xlrd_fix_excel(file):
    wbx = xlrd.open_workbook(file)
    if "新入职员工信息采集" in wbx.sheet_names():
        wsx = wbx.sheet_by_name("新入职员工信息采集")
    else:
        wsx = wbx.sheet_by_index(0)
    wb = load_workbook(TEMPLATE_DIR + "/采集表-标准表.xlsx")
    ws = wb.active
    for i in range(wsx.nrows):
        for j in range(wsx.ncols):
            if wsx.cell_value(i, j):
                try:
                    ws.cell(i + 1, j + 2 if (i, j) == (7, 18) else j + 1).value = wsx.cell_value(i, j)
                except Exception:
                    logging.info(f"可能出现丢失采集表单元格（{i + 1}, {j + 1})的值")
    wb.save(TEMPLATE_DIR + "/tmp.xlsx")
    return TEMPLATE_DIR + "/tmp.xlsx"


#  整理采集表
def cai_ji_biao(file, file_str):
    if file_str:
        file_path = local_path + "\\" + file_str
    else:
        file_path = os.path.dirname(file)
    logging.info("开始整理采集表...")
    for _file, dirs, files in os.walk(file_path):
        for filename in files:
            logging.info(f"    正在整理《{filename}》采集表...")
            filename = os.path.join(_file, filename)
            if filename.endswith(".xlsx"):
                if not os.path.exists(file_path + "/采集表"):
                    os.makedirs(file_path + "/采集表")
                try:
                    wb = load_workbook(filename)
                except Exception:
                    try:
                        fix_excel(filename)
                        wb = load_workbook(filename)
                    except Exception:
                        os.makedirs(file_path + "/问题采集表", exist_ok=True)
                        try:
                            shutil.copyfile(filename, file_path + "/问题采集表/" + os.path.basename(filename))
                        except Exception:
                            pass
                        continue
                ws = wb.active
                if ws["A2"].value == "姓名" and ws["L7"].value == "身份证号" and ws["C2"].value:
                    name = str(ws["C2"].value).replace(" ", '').replace("\n", '')
                    # new_file = f'{file_path}/采集表/{name}.xlsx'
                    # if os.path.exists(new_file):
                    #     shutil.move(new_file, f'{new_file[:-5]}(姓名重复).xlsx')
                    #     logging.warning(f'姓名重复提示：【{name}--{os.path.basename(filename)}】')
                    try:
                        shutil.copyfile(filename, file_path + "/采集表/" + name + ".xlsx")
                    except shutil.SameFileError:
                        continue
                    # 删除除了["新入职员工信息采集", "码表"]以外的sheet页，防止有隐藏图片在其他sheet页影响获取照片的操作
                    for x in wb.get_sheet_names():
                        if x not in str(ws) and x != "码表":
                            wb.remove_sheet(wb[x])
                    wb.save(filename)
                    img = compenent(filename)
                    if not os.path.exists(file_path + "/照片"):
                        os.makedirs(file_path + "/照片")
                    if img:
                        shutil.copyfile(img, file_path + "/照片/" + name + os.path.splitext(img)[1])
                    if os.path.exists(os.path.dirname(filename) + "/tmp.zip"):
                        os.remove(os.path.dirname(filename) + "/tmp.zip")
                        shutil.rmtree(os.path.dirname(filename) + "/tmp")
