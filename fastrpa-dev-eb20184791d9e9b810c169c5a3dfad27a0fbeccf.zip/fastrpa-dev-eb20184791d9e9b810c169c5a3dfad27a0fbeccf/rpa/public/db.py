#!/usr/bin/env python
# -*- coding: utf-8 -*-
# @File    : db.py
# @Author  : jinjianfeng
# @Contact : 553041800@qq.com
# @Link    : https://github.com/jinjf553
# @software: PyCharm
# @Date    : 2019/12/2 9:37
# @Version : ??
import os
import time
from collections import defaultdict
from datetime import datetime

import win32api
import win32con
from openpyxl import load_workbook
from rpa.ssc.hr.orm.orm_ope import DbSession, Insert, Query
from rpa.ssc.hr.orm.tb_hr_ruzhi_log import RZLog
from rpa.ssc.hr.orm.tb_hr_ruzhi_log_detail import RZLog_detail


def update_db(file, text):
    lis = os.path.basename(file[:-5]).split("-")
    if not file:
        return True
    if len(lis) < 4:
        win32api.MessageBox(0, "事件模板名格式应为：（单号-人事范围-事件类型-业务人员.xlsx）\n"
                               "例如：1000000001-X000-岗位变动-常盛.xlsx", "提示", win32con.MB_OK)
        return False
    sr, code, comment, worker = lis[:4]
    wb = load_workbook(file)
    serial_id = wb.properties.description
    ws = wb.active
    code_dict = defaultdict(dict)
    tmp_dict = {"重新录用": ("C", "B"), "员工入职": ("B", "CA"), "大学生入职": ("B", "CA"), "岗位变动": ("C", "B"),
                "离职": ("C", "B"), "内退": ("C", "B"), "劳务工退回": ("C", "B"), "离退休减册": ("C", "B")}
    for k, v in tmp_dict.items():
        code_dict[k] = {str(ws[f"{v[0]}{x}"].value).replace(" ", ""):
                        "0" * (8 - len(str(ws[f"{v[1]}{x}"].value))) + str(ws[f"{v[1]}{x}"].value) for x in
                        range(7, len(ws["B"]) + 1) if ws[f"{v[0]}{x}"].value}
    # if not code_dict[comment]:
    #     showinfo(title="提示", text="所选事件模板没有正确的人员姓名或者编号。")
    date = time.strftime("%Y%m%d", time.localtime(time.time()))
    if not [res.sr for res in Query(table=RZLog) if res.sr == sr]:
        Insert(table=RZLog, sr=sr, code=code, content=os.path.basename(file), comment=comment,
               date=date, people_num=str(len(code_dict[comment])), step=text, worker=worker)
    with DbSession() as s:
        for name, personnel_code in code_dict[comment].items():
            personnel_code = personnel_code if personnel_code != "0000None" else ""
            res = s.query(RZLog_detail).filter(RZLog_detail.sr == sr, RZLog_detail.name == name)
            if res.first():
                res.update({"code": personnel_code})
                continue
            s.add(RZLog_detail(sr=sr, name=name, code=personnel_code, start_date=date, ywlx=comment, times=1,
                               create_time=datetime.now(), update_time=datetime.now(), remark=serial_id))
    wb.close()
    return code_dict[comment]
