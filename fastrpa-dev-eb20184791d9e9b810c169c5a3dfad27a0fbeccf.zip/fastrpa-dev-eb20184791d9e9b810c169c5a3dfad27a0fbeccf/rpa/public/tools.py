#!/usr/bin/env python
# -*- coding: utf-8 -*-
# @Date    : 2019-03-09 20:26:10
# 为改善硬加time.sleep(*)而开发
import logging
import os
import shutil
import time
import tkinter
import traceback
from pathlib import Path
from tkinter.messagebox import askokcancel
from typing import Union

import win32api
import win32con
import win32gui
from openpyxl.comments import Comment
from openpyxl.styles import PatternFill, colors
from openpyxl.utils import get_column_letter
from openpyxl.worksheet.worksheet import Worksheet
from rpa.fastrpa.utils.refresh_tray_pannel import refresh_tray_pannel
from rpa.public.myftp import MYFTP
from win32com.client import CDispatch


def click_able(browser, xpath):
    for i in range(40):
        try:
            browser.find_element_by_xpath(xpath).click()
            return '发现元素并执行点击操作'
        except Exception as e:
            time.sleep(0.5)
    logging.info('Timeout')


def click_able_on_link_text(browser, xpath):
    for i in range(40):
        try:
            browser.find_element_by_link_text(xpath).click()
            return '发现元素并执行点击操作'
        except Exception as e:
            time.sleep(0.5)
    logging.info('Timeout')


def get_attr(browser, xpath, attribute, value, duration=10):
    for i in range(duration * 4):
        try:
            if browser.find_element_by_xpath(xpath).get_attribute(attribute) == value:
                return True
            else:
                time.sleep(0.5)
        except Exception as e:
            time.sleep(0.5)
    logging.info('Timeout')
    return False


def windowlist(browser, number=2, duration=10):
    handles = []
    for i in range(duration * 2):
        handles = browser.window_handles
        if len(handles) == number:
            return handles
        else:
            time.sleep(0.5)
    raise Exception('Timeout: %s window' % str(len(handles)))


def find_window(file_path, classs, text):
    is_find_window = False
    file_path = str(Path(file_path))
    for _ in range(240):
        dialog = win32gui.FindWindow(classs, text)  # 对话框
        if dialog:
            is_find_window = True
            ComboBoxEx32 = win32gui.FindWindowEx(dialog, 0, 'ComboBoxEx32', None)
            ComboBox = win32gui.FindWindowEx(ComboBoxEx32, 0, 'ComboBox', None)
            Edit = win32gui.FindWindowEx(ComboBox, 0, 'Edit', None)  # 上面三句依次寻找对象，直到找到输入框Edit对象的句柄
            button = win32gui.FindWindowEx(dialog, 0, 'Button', None)  # 确定按钮Button
            time.sleep(1)
            logging.info(f"dialog: {dialog}  file_path: {file_path}")
            try:
                win32gui.SendMessage(Edit, win32con.WM_SETTEXT, 0, file_path)  # 往输入框输入绝对地址
                time.sleep(1)
                win32gui.SendMessage(dialog, win32con.WM_COMMAND, 1, button)  # 按button
            except Exception as e:
                logging.error(e)
                logging.error(f"异常原因: {traceback.format_exc()}")
        elif is_find_window is True:
            logging.info(f"dialog: {dialog}  file_path: {file_path}，已关闭")
            break  # 窗口确实被关闭了
        time.sleep(0.5)
    else:
        logging.error('未找到SAP批导弹窗')


def click_continue():
    for i in range(240):
        dialog = win32gui.FindWindow("NUIDialog", "Microsoft Excel - 兼容性检查器")
        if dialog:
            aa = win32gui.FindWindowEx(dialog, 0, 'NetUIHWND', None)
            win32api.PostMessage(aa, win32con.WM_KEYDOWN, win32con.VK_RETURN, 0)  # 发送回车键
            win32api.PostMessage(aa, win32con.WM_KEYUP, win32con.VK_RETURN, 0)
            break
        time.sleep(0.5)


def quit_bro(browser):
    browser.quit()
    logging.info('浏览器成功退出...')


def ask_message(title, message):
    top = tkinter.Tk()
    top.wm_attributes('-topmost', 1)
    top.withdraw()
    top.update()
    txt = askokcancel(title, message)
    top.destroy()
    return txt


def cel(sht: Worksheet, x: Union[tuple, str]) -> str:
    """

    :rtype:
    """
    if isinstance(x, tuple):
        key = str(sht.cell(x[0], x[1]).value).replace("None", "").strip()
        try:
            sht.cell(x[0], x[1]).value = key
        except Exception:
            pass
        return key
    else:
        key = str(sht[x].value).replace("None", "").strip()
        try:
            sht[x].value = key
        except Exception:
            pass
        return key


def cells(ws: Union[Worksheet, CDispatch], cell: str or tuple, content: str, color: int or colors):
    if isinstance(ws, Worksheet):
        if not isinstance(cell, str):
            cell = get_column_letter(cell[1]) + str(cell[0])
        ws[cell].fill = PatternFill("solid", color)
        ws[cell].comment = Comment(f"{content}|{str(ws[cell].comment)[9:-9]}", "Robot")
    else:
        if isinstance(cell, str):
            ws.Range(cell).ClearComments()
            ws.Range(cell).AddComment(content)
            ws.Range(cell).Interior.ColorIndex = color
        else:
            i, j = cell[0], cell[1]
            ws.Cells(i, j).ClearComments()
            ws.Cells(i, j).AddComment(content)
            ws.Cells(i, j).Interior.ColorIndex = color


def move_file(mode, lfile, rfile, ftp: MYFTP = None):
    if os.path.exists(lfile):
        if mode == "copy":
            shutil.copyfile(lfile, rfile)
        if mode == "upload" and ftp:
            ftp.upload_file(lfile, rfile)
    else:
        logging.info(f"本地文件【{lfile}】不存在，跳过操作")
