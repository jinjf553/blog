import os
import time
from functools import wraps
from typing import Optional

from rpa.config import TEMPLATE_DIR
from rpa.fastrpa.mail import sendmail
from rpa.fastrpa.tempdir import gentempdir
from rpa.fastrpa.third_party.isa import decrypt
from rpa.ssc.hr.orm.orm_ope import Query
from rpa.ssc.hr.orm.session import DbSession
from rpa.ssc.hr.orm.tb_dim_hr_staff import TB_DIM_HR_STAFF
from rpa.ssc.hr.orm.tb_user import User


def db_error(fn):
    """为函数添加日志，正常执行时，打印执行时长，错误时打印传参及异常原因。"""
    @wraps(fn)
    def foo(*args):
        try:
            return fn(*args)
        except Exception as e:
            if 'Can\'t connect to MySQL server on' in str(e):
                raise Exception('无法连接至MySQL服务器')
            else:
                raise e
    return foo


@db_error
def recv_user():
    for res in Query(table=User, system='接收', parment='HR', business='人事', state='1'):
        return decrypt(res.username)
    else:
        raise Exception("hr.tb_user 表中不存在接收,HR,人事的用户！")


def send_mail(receivers, *args):
    content = '与' + str(args) + '相关的密码已过期，请及时更新。\n更新之后请将状态（state)置为1。'
    sendmail(receivers=receivers, subject='密码过期提醒', body=content)


@db_error
def user_name():
    for res in Query(table=User, system='SAP', parment='HR', business='人事'):  # , state='1'
        # 20210415 增加注释：当账号密码变更时，SAP登录失败会将 state置为0，修改数据库密码后，同时需要将state置为1才可恢复大账号，否则还是会报错
        return decrypt(res.username), decrypt(res.password)
    else:
        send_mail(recv_user(), "SAP", "HR", "人事")
        raise Exception('SAP-HR-人事账号信息错误，已发送邮件至管理员邮箱。')


#
# def fso_user():
#     for res in Query(table=User, system='fso', parment='HR', business='拆单', state='1'):
#         return decrypt(res.username), decrypt(res.password), decrypt(res.address)
#     else:
#         send_mail(recv_user(), "fso", "HR", "拆单")
#         raise Exception('fso-HR-拆单账号信息错误，已发送邮件至管理员邮箱。')


@db_error
def fso_user(fso_username='changsh55', fso_address='https://fso.sinopec.com'):
    """自动拆单、手动拆单关联的FSO账号"""
    try:
        with DbSession() as s:
            req: Optional[TB_DIM_HR_STAFF] = s.query(TB_DIM_HR_STAFF).filter(TB_DIM_HR_STAFF.fso_username == fso_username).filter(TB_DIM_HR_STAFF.fso_state != 0).first()
            if req is not None:
                return fso_username, decrypt(req.fso_password), fso_address
    except Exception:  # nosec
        pass
    send_mail(recv_user(), "fso", "HR", "拆单")
    raise Exception('fso-HR-拆单账号信息错误，已发送邮件至管理员邮箱。')


@db_error
def ftp_user():
    for res in Query(table=User, system='FTP', parment='HR', business='共享文件夹', state='1'):
        return decrypt(res.address), decrypt(res.password), decrypt(res.remark), decrypt(res.username)
    else:
        send_mail(recv_user(), "FTP", "HR", "共享文件夹")
        raise Exception('FTP-HR-共享文件夹账号信息错误，已发送邮件至管理员邮箱。')


@db_error
def ftp_user_readonly():
    for res in Query(table=User, system='只读FTP', parment='HR', business='只读FTP', state='1'):
        return decrypt(res.address), decrypt(res.password), decrypt(res.remark), decrypt(res.username)
    else:
        send_mail(recv_user(), "FTP", "HR", "共享文件夹")
        raise Exception('FTP-HR-共享文件夹账号信息错误，已发送邮件至管理员邮箱。')


@db_error
def redis_user_readonly():
    for res in Query(table=User, system='redis', parment='HR', business='redis', state='1'):
        return decrypt(res.address), decrypt(res.remark), decrypt(res.password)
    else:
        send_mail(recv_user(), "redis", "HR", "redis")
        raise Exception('REDIS-HR-redis账号信息错误，已发送邮件至管理员邮箱。')


date = time.strftime("%Y%m%d", time.localtime(time.time()))
FILE_PATH = gentempdir()
if not os.path.exists(FILE_PATH):
    os.makedirs(FILE_PATH)
templates = TEMPLATE_DIR
remote_path = "/HR人事/岗位变动/%s/%s/" % (date[:6], date)
remote_lz = "/HR人事/在职减册/%s/%s/" % (date[:6], date)
remote_nt = "/HR人事/内退/%s/%s/" % (date[:6], date)
remote_lwg = "/HR人事/劳务工退回/%s/%s/" % (date[:6], date)
remote_jg = "/HR人事/销售建岗/%s/%s/" % (date[:6], date)
remote_ltx = "/HR人事/离退休减册/%s/%s/" % (date[:6], date)
remote_ruzhi_path = "/HR人事/员工入职/%s/%s/" % (date[:6], date)
remote_robotA_path = "/HR人事/拆单"
remote_daiban = "/HR人事/待办/"
local_path = gentempdir()

if __name__ == '__main__':
    ftp_user()
