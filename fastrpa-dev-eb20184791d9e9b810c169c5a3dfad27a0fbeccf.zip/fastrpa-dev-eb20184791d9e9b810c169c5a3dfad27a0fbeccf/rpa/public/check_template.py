#!/usr/bin/env python
# -*- coding: utf-8 -*-
# @File    : check_template.py
# @Author  : jinjianfeng
import time
from collections import defaultdict

from openpyxl import load_workbook
from openpyxl.styles.colors import BLUE
from rpa.fastrpa.adtable import RED
from rpa.public.tools import cel, cells
from rpa.ssc.hr.orm.orm_ope import Query
from rpa.ssc.hr.orm.td_hr_gang_wei_diao_pei_rulebase import Event


def check_degree_template(file, flag_dict):
    wb = load_workbook(file)
    ws = wb.active
    db_CH_CG = {res.db_CH.strip(): res.db_CG.strip() for res in Query(table=Event) if res.db_CH and res.db_CG}  # 学历
    db_CH_CJ = {res.db_CJ.strip(): res.db_CI.strip() for res in Query(table=Event) if res.db_CI and res.db_CJ}  # 学位
    db_CM_CL = {res.db_CM.strip(): res.db_CL.strip() for res in Query(table=Event) if res.db_CM and res.db_CL}  # 学位
    li1, li2, li3 = [], [], []
    tmp_dict = defaultdict(int)
    for i in range(7, len(ws["C"]) + 1):
        if not cel(ws, f"C{i}"):
            continue
        if ws[f"G{i}"].value not in db_CH_CG.keys():
            for k, v in {"G": "学历详情非码值", "F": "学历教育类型为空"}.items():
                cells(ws, f"{k}{i}", v, RED)
                flag_dict[True].append(f"学{k}{i}")

        if ws[f"I{i}"].value and cel(ws, f"I{i}") not in db_CH_CJ.keys():
            for k, v in {"I": "学位非码值", "H": "学位类别为空"}.items():
                cells(ws, f"{k}{i}", v, RED)
                flag_dict[True].append(f"学{k}{i}")

        for j in ["J", "Y", "D"]:
            try:
                if j == "J" and not cel(ws, f"I{i}"):
                    continue
                time.strptime(cel(ws, f"{j}{i}"), '%Y%m%d')
                if len(cel(ws, f"{j}{i}")) != 8:
                    raise Exception('日期错误')
                if j == "D" and int(cel(ws, f"D{i}")) > tmp_dict[cel(ws, f"C{i}")] and "普通全日制" in cel(ws, f"S{i}"):
                    tmp_dict[cel(ws, f"C{i}")] = int(cel(ws, f"D{i}"))
            except Exception:
                cells(ws, f"{j}{i}", "日期非正确值", RED)
                flag_dict[True].append(f"学{j}{i}")

        for k, v in {"K": [li1, "最高学历"], "L": [li2, "最高学位"], "M": [li3, "第一学历"]}.items():
            if ws[f"C{i}"].value in v[0] and ws[f"{k}{i}"].value == "X":
                cells(ws, f"{k}{i}", f"{v[1]}标识非单值", RED)
                flag_dict[True].append(f"学{k}{i}")
            elif ws[f"{k}{i}"].value == "X":
                v[0].append(ws[f"C{i}"].value)

        if not cel(ws, f"R{i}"):
            ws[f"R{i}"] = "CN  中国"
            cells(ws, f"R{i}", "请核实毕业院校所属国籍是否正确", RED)

        if cel(ws, f"S{i}") not in ["1 普通全日制", "2 在职全脱产", "3 在职半脱产", "4 在职不脱产", "9 其他"]:
            cells(ws, f"S{i}", "从学方式非码值", RED)
            flag_dict[True].append(f"学S{i}")

        #  20200917增加校验规则：校验专业类别关联关系
        for x, (y, z) in {"T": ("U", 2), "U": ("V", 4), "V": ("W", 6), }.items():
            if cel(ws, f"{y}{i}") and not cel(ws, f"{x}{i}"):
                cells(ws, f"{y}{i}", f"{x}列专业类别不应为空", RED)
                flag_dict[True].append(f"学{y}{i}")
            elif cel(ws, f"{y}{i}") and cel(ws, f"{y}{i}")[:z] != cel(ws, f"{x}{i}")[:z]:
                cells(ws, f"{y}{i}", f"专业类别应在{x}列专业类别下, 例如：{cel(ws, f'{x}{i}')[:z]}01", RED)
                flag_dict[True].append(f"学{y}{i}")

        if cel(ws, f"X{i}") and cel(ws, f"X{i}")[:2] < "60":
            for j in ["T", "U", "V"]:
                if not cel(ws, f"{j}{i}"):
                    cells(ws, f"{j}{i}", "专业类别为空", RED)
                    flag_dict[True].append(f"学{j}{i}")
            if not cel(ws, f"V{i}") and not cel(ws, f"W{i}"):
                cells(ws, f"W{i}", "专业类别为空", RED)
                flag_dict[True].append(f"学W{i}")

        if not (cel(ws, f"Z{i}").isdigit() and 1 < int(cel(ws, f"Z{i}")) < 7) and "90" not in cel(ws, f"F{i}"):
            cells(ws, f"Z{i}", "学制非正常值", BLUE)
            # flag_dict[True].append(f"学Z{i}")

        if "普通全日制" in cel(ws, f"S{i}"):
            if cel(ws, f"AC{i}") and cel(ws, f"AC{i}") < cel(ws, f"D{i}"):
                cells(ws, f"D{i}", "毕业日期不应大于入职日期", RED)
                flag_dict[True].append(f"学D{i}")

        if cel(ws, f"P{i}") not in db_CM_CL.keys():
            cells(ws, f"P{i}", "毕业学校及单位代码非码值", RED)
            flag_dict[True].append(f"学P{i}")
        elif cel(ws, f"O{i}") != db_CM_CL[cel(ws, f"P{i}")]:
            cells(ws, f"O{i}", "毕业学校及单位区域与毕业学校及单位代码不对应", RED)
            flag_dict[True].append(f"学O{i}")
    wb.save(file)
    return tmp_dict, flag_dict


def check_family_members_template(file, flag_dict):
    wb = load_workbook(file)
    ws = wb.active
    db_CV = [res.db_CV.replace(" ", "") for res in Query(Event) if res.db_CV]  # 政治面貌
    for i in range(7, len(ws["C"]) + 1):
        if not cel(ws, f"C{i}"):
            continue
        for j in ["D", "I"]:
            try:
                if len(cel(ws, f"{j}{i}")) != 8:
                    raise Exception('日期错误')
                time.strptime(cel(ws, f"{j}{i}"), '%Y%m%d')
            except Exception:
                cells(ws, f"{j}{i}", "日期非正常值", RED)
                flag_dict[True].append(f"家{j}{i}")

        if cel(ws, f"K{i}").replace(" ", "") and cel(ws, f"K{i}").replace(" ", "") not in db_CV:
            cells(ws, f"K{i}", "字段数值非码值", RED)
            flag_dict[True].append(f"家K{i}")

        if len(cel(ws, f"L{i}")) > 20:
            cells(ws, f"L{i}", "字符长度超出20", RED)
            flag_dict[True].append(f"家L{i}")

        if "未知" in cel(ws, f"H{i}"):
            cells(ws, f"H{i}", "请核实F列与H列数据", RED)
            flag_dict[True].append(f"家H{i}")
    wb.save(file)
    wb.close()
    return flag_dict


def check_work_experience(file, flag_dict):
    wb = load_workbook(file)
    ws = wb.active
    for i in range(7, len(ws["C"]) + 1):
        if not cel(ws, f"C{i}"):
            continue
        for j in ["D", "E"]:
            try:
                if len(cel(ws, f"{j}{i}")) != 8:
                    raise Exception('日期错误')
                time.strptime(cel(ws, f"{j}{i}"), '%Y%m%d')
            except Exception:
                cells(ws, f"{j}{i}", "日期非正确值", RED)
                flag_dict[True].append(f"工{j}{i}")

        if not ws[f"F{i}"].value or len(str(ws[f"F{i}"].value)) > 40:
            cells(ws, f"F{i}", "所在单位和部门不能为空或者超长（>40）", RED)
            flag_dict[True].append(f"工F{i}")

        if not ws[f"G{i}"].value:
            cells(ws, f"G{i}", "从事工作及职务不能为空", RED)
            flag_dict[True].append(f"工G{i}")
    wb.save(file)
    wb.close()
    return flag_dict
