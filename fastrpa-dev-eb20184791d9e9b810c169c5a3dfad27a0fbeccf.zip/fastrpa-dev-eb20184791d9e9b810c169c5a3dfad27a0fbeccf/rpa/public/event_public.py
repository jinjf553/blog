#!/usr/bin/env python
# -*- coding: utf-8 -*-
# @File    : event_public.py
# @Author  : jinjianfeng
import logging
import os
from datetime import datetime

from openpyxl import load_workbook
from rpa.fastrpa.adtable import RED
from rpa.public.config import templates
from rpa.public.myftp import MYFTP
# 规则1.1.1: 校验事件模板
from rpa.public.tools import cells
from rpa.ssc.hr.orm.session import DbSession
from rpa.ssc.hr.orm.tb_hr_ruzhi_log import RZLog


def clear_all_colour_and_comment(s_file, template, remote):
    """
        清除“事件模板”上所有的批注及单元格颜色。
    """
    # # 删除FTP已经有的文件
    # with MYFTP() as my_ftp:
    #     my_ftp.rmd(remote + "失败/" + s_file.split('\\')[-1].split(".")[0] + "/")
    #     my_ftp.rmd(remote + "成功/" + s_file.split('\\')[-1].split(".")[0] + "/")
    wb = load_workbook(s_file)
    ws = wb.active
    wb_mb = load_workbook(os.path.join(templates, f"{template}.xlsx"))
    ws_mb = wb_mb.active

    rows = len(ws["A"])
    cols = len(list(ws.columns))
    for i in range(6, rows + 1):
        for j in range(1, cols + 1):
            ws_mb.cell(i, j).value = ws.cell(i, j).value
    wb_mb.save(s_file)
    update_database(s_file, "清空批注和颜色")


def update_database(file, text):
    sr = os.path.basename(file)[:10]
    if not str(sr).isdigit():
        return
    with DbSession() as s:
        res = s.query(RZLog).with_for_update().filter(RZLog.sr == sr)
        if res.first():
            res.update({"step": text,
                        "result": f"{res.first().result}| {datetime.now()} update: {res.first().step}"[-250:]})


# 规则1.1.11: 检查模板表是否有批注，有批注发邮件协同，否则继续
def send_email(s_file):
    wb = load_workbook(s_file)
    ws = wb.active
    rows = list(ws.rows)
    flag, li = False, []
    for i in range(6, len(rows)):
        for cell in rows[i]:
            if "rgb='00FF0000'" in str(cell.fill):
                flag = True
                li.append(str(cell).split(".")[-1][:-1])
                continue
    if flag:
        cells(ws, f"A1", f"未通过检查:{li}", RED)
        wb.save(s_file)
        logging.info(f"模板批导前校验未通过，发现问题单元格为：{li}")
        update_database(s_file, "批导前校验未通过，发送邮件通知")
        return flag
    logging.info(f"模板批导前校验通过，可执行批导事件")
    return False
