import logging
import os
import shutil
import time
from collections import defaultdict
from typing import Tuple

import pyperclip
from openpyxl.reader.excel import load_workbook
from rpa.config import STAFF_NAME, TEMPLATE_DIR
from rpa.fastrpa.log import config
from rpa.fastrpa.sap.session import SAP, attach_sap, close_sap
from rpa.fastrpa.sap.session_old import connect_to_sap
from rpa.fastrpa.xlsx import convert_xlsx_to_xls
from rpa.public.config import FILE_PATH
from rpa.public.tools import cel
from rpa.ssc.hr.sap.export_103 import export_103
from rpa.ssc.sap.query import export_query


def create_work_experience_template(work_experience_file_path: str, file_path_103: str, staff_ids: list = None,
                                    key_date: str = "") -> str:
    ws = load_workbook(file_path_103).active
    people_code_dict = defaultdict(dict)
    if len(ws["A"]) + 1 < 3:
        return ".xlsx", ".xls"
    for i in range(2, len(ws["A"]) + 1):
        dic = {"开始日期": cel(ws, f"C{i}"), "所在单位及部门名称": cel(ws, f"W{i}"), "从事工作及担任职务": cel(ws, f"Y{i}")}
        people_code_dict[cel(ws, f"A{i}").lstrip('0')] = dic
        del dic

    wb = load_workbook(work_experience_file_path)
    ws = wb.active
    wait_insert_row_dict = defaultdict(dict)
    people_code_flag, row_flag = '', 0
    for i in range(2, len(ws["A"]) + 1):
        ws[f"G{i}"] = cel(ws, f"G{i}").replace('.', '').replace('/', '')
        ws[f"H{i}"] = cel(ws, f"H{i}").replace('.', '').replace('/', '')
        ws[f"K{i}"] = cel(ws, f"K{i}").replace('.', '').replace('/', '')
        if not cel(ws, f"D{i - 1}").isdigit():
            if i == len(ws["A"]) and cel(ws, f"E{i}") in ['1', '9']:
                wait_insert_row_dict[i + 1] = [cel(ws, f"B{i}").lstrip('0'), cel(ws, f"C{i}"), cel(ws, f"A{i}"),
                                               cel(ws, f"D{i}")]
            continue
        if cel(ws, f"B{i - 1}").lstrip('0') == people_code_flag:
            ws[f"D{i - 1}"] = str(row_flag + 2)
            row_flag += 1
            continue
        if not (cel(ws, f"E{i}") in ['1', '9'] and int(cel(ws, f"D{i}")) > int(cel(ws, f"D{i - 1}"))):
            people_code_flag, row_flag = cel(ws, f"B{i - 1}").lstrip('0'), int(cel(ws, f"D{i - 1}"))
            wait_insert_row_dict[i] = [cel(ws, f"B{i - 1}").lstrip('0'), cel(ws, f"C{i - 1}"), cel(ws, f"A{i - 1}"),
                                       cel(ws, f"D{i - 1}")]
        if i == len(ws["A"]) and cel(ws, f"E{i}") in ['1', '9']:
            wait_insert_row_dict[i + 1] = [cel(ws, f"B{i}").lstrip('0'), cel(ws, f"C{i}"), cel(ws, f"A{i}"),
                                           cel(ws, f"D{i}")]
    for row in list(reversed(wait_insert_row_dict.keys())):
        lis = wait_insert_row_dict[row]
        ws.insert_rows(row)
        ws[f"A{row}"] = lis[2]
        ws[f"B{row}"] = lis[0]
        ws[f"C{row}"] = lis[1]
        if not str(lis[3]).isdigit():
            raise Exception(f"简历模板{row}行D列【简历显示顺序】为非数字，请检查。")
        ws[f"D{row}"] = str(int(lis[3]) + 1)
        ws[f"E{row}"] = '9'
        ws[f"F{row}"] = '工作经历(含教育培训)'
        # if date_dict and lis[0] in date_dict.keys() and date_dict[lis[0]][0].isdigit():
        #     ws[f"G{row}"] = date_dict[lis[0]][0]
        #     ws[f"H{row-1}"] = date_dict[lis[0]][0]
        if lis[0] in staff_ids:
            ws[f"G{row}"] = key_date
            ws[f"H{row - 1}"] = key_date
            ws[f"I{row}"] = people_code_dict[lis[0]]['所在单位及部门名称']  # date_dict[lis[0]][1]
            ws[f"J{row}"] = people_code_dict[lis[0]]['从事工作及担任职务']  # date_dict[lis[0]][2]
        else:
            ws[f"G{row}"] = people_code_dict[lis[0]]['开始日期'].replace('.', '')
            ws[f"H{row - 1}"] = people_code_dict[lis[0]]['开始日期'].replace('.', '')
            ws[f"I{row}"] = people_code_dict[lis[0]]['所在单位及部门名称']
            ws[f"J{row}"] = people_code_dict[lis[0]]['从事工作及担任职务']
        ws[f"H{row}"] = '99991231'

        ws[f"K{row}"] = time.strftime('%Y%m%d')
    wb.save(work_experience_file_path)
    return convert_xlsx_to_xls(work_experience_file_path)


def create_work_experience(session, file_path_103):
    logging.info('编辑简历模块')
    ws = load_workbook(file_path_103).active
    people_code_dict = defaultdict(dict)
    if len(ws["A"]) + 1 < 3:
        return True, ".xlsx", ".xls"
    for i in range(2, len(ws["A"]) + 1):
        dic = {"开始日期": cel(ws, f"C{i}"), "描述1": cel(ws, f"W{i}"), "描述2": cel(ws, f"Y{i}")}
        people_code_dict[cel(ws, f"A{i}").lstrip('0')] = dic
        del dic
    table, row, people_flag = session.findById("wnd[0]/usr/cntlGRID1/shellcont/shell"), 0, ''
    while True:
        if row >= table.rowCount:
            break
        table.firstVisibleRow = row - 10 if row > 10 else 0
        if table.rowCount > 0:
            PERNR1 = table.getCellValue(row, 'PERNR').lstrip('0')
            if PERNR1 == people_flag or PERNR1 not in people_code_dict.keys():
                row += 1
                continue
            s_date = table.getCellValue(row, 'BEGDA').strip().replace('.', '')
            if row + 1 < table.rowCount:
                PERNR2 = table.getCellValue(row + 1, 'PERNR').lstrip('0')
                type_name = table.getCellValue(row + 1, 'LX_STEXT').strip()
            else:
                PERNR2, type_name = PERNR1, '空行'
            date = people_code_dict[PERNR1]['开始日期']
            des1 = people_code_dict[PERNR1]['描述1']
            des2 = people_code_dict[PERNR1]['描述2']
            if (type_name == '空行' or PERNR1 != PERNR2) and s_date != date:
                table.selectedRows = str(row)
                session.findById("wnd[0]/tbar[1]/btn[7]").press()
                table = session.findById("wnd[0]/usr/cntlGRID1/shellcont/shell")
                table.modifyCell(row, "ENDDA", date)  # FIXME 结束日期99991231
                table.modifyCell(row + 1, "BEGDA", date)  # FIXME 开始日期(二调直调取自模板BB列，岗变取自AO列)
                table.modifyCell(row + 1, "ZZ_JLMS", des1)
                table.modifyCell(row + 1, "ZZ_JLMS2", des2)
                people_flag = PERNR1
                logging.info(f'人员编号：{PERNR1} 拆入行: date:{date}, 描述1：{des1}, 描述2：{des2}')
        row += 1
    # 保存 简历
    session.findById("wnd[0]/tbar[1]/btn[23]").press()
    err_flag = True
    for i in range(table.rowCount + 1):
        before_text = session.findById("wnd[0]/sbar/pane[0]").text
        session.findById("wnd[0]").sendVKey(0)
        after_text = session.findById("wnd[0]/sbar/pane[0]").text
        if '保存完毕' in after_text or '保存成功' in after_text:
            break
        if not after_text.strip():
            logging.error(f'修改简历失败， 原因：{before_text}')
            err_flag = False
            break
    export_query(session, grid_view_ctrl_id=r"wnd[0]/usr/cntlGRID1/shellcont/shell",
                 template_file=f'{TEMPLATE_DIR}/简历模板.xlsx', query_name='简历').save_to(FILE_PATH)
    if os.path.exists(f'{FILE_PATH}/简历模板.xlsx'):
        wb = load_workbook(f'{FILE_PATH}/简历模板.xlsx', data_only=True)
        wb.properties.description = f'{str(err_flag)}|{before_text}'
        wb.save(f'{FILE_PATH}/简历模板.xlsx')
        shutil.move(f'{FILE_PATH}/简历模板.xlsx', f'{FILE_PATH}/简历模板_事后.xlsx')
        return err_flag, f'{FILE_PATH}/简历模板_事后.xlsx', ''
    return err_flag, '', ''


def download_work_experience_template(staff_ids: list, key_date: str, area_codes: list) -> Tuple[bool, str, str]:
    session = attach_sap("login_tx")
    if not os.path.exists(FILE_PATH + "/模板_103.xlsx"):
        export_103(session, staff_ids, key_date).save_to(FILE_PATH)
    session.findById("wnd[0]/tbar[0]/okcd").text = "/n zhrpa175"
    session.findById("wnd[0]").sendVKey(0)
    session.findById("wnd[0]/usr/ctxtPNPWERKS-LOW").text = "1880"  # 人事范围填入占位值
    session.findById("wnd[0]/usr/btn%_PNPWERKS_%_APP_%-VALU_PUSH").press()  # 人事范围多项选择
    session.findById("wnd[1]/tbar[0]/btn[16]").press()  # 删除全部选择行（Shift+F4）
    pyperclip.copy('\r\n'.join(area_codes))  # 复制到剪切板
    session.findById("wnd[1]/tbar[0]/btn[24]").press()  # 从剪切板上载（Shift+F12）
    session.findById("wnd[1]/tbar[0]/btn[8]").press()  # 确认
    session.findById("wnd[0]/usr/btn%_PNPPERNR_%_APP_%-VALU_PUSH").press()
    session.findById("wnd[1]/tbar[0]/btn[16]").press()
    pyperclip.copy('\r\n'.join(staff_ids))
    session.findById("wnd[1]/tbar[0]/btn[24]").press()
    session.findById("wnd[1]/tbar[0]/btn[8]").press()
    session.findById("wnd[0]/tbar[1]/btn[8]").press()
    export_query(session, grid_view_ctrl_id=r"wnd[0]/usr/cntlGRID1/shellcont/shell",
                 template_file=f'{TEMPLATE_DIR}/简历模板.xlsx', query_name='简历').save_to(FILE_PATH)
    if os.path.exists(f'{FILE_PATH}/简历模板.xlsx'):
        shutil.move(f'{FILE_PATH}/简历模板.xlsx', f'{FILE_PATH}/简历模板_事前.xlsx')

    file_before, file_after, err_flag = f'{FILE_PATH}/简历模板_事前.xlsx', f'{FILE_PATH}/简历模板_事后.xlsx', True
    if os.path.exists(file_before):
        try:
            err_flag, file_after, _ = create_work_experience(session, FILE_PATH + "/模板_103.xlsx")
            # create_work_experience_template(file_before, file_path + "/模板_103.xlsx", staff_ids, key_date)
        except Exception as e:
            logging.error(f"下载简历模板出现异常：{e}")
        logging.info(f"生成简历模板{file_before}成功")
    session.findById("wnd[0]/tbar[0]/okcd").text = "/nex"
    session.findById("wnd[0]").sendVKey(0)
    return err_flag, file_before, file_after


def new_work_experience_modify(ep_dict):  # {'人员编号 ':[‘开始时间’，‘所在机构名称’，‘所在岗位’]}
    logging.info(ep_dict)
    t1_lst = []
    with SAP('login_tx') as session:
        for k, v in ep_dict.items():
            session.findById("wnd[0]/tbar[0]/okcd").text = "/n pa30"
            session.findById("wnd[0]").sendVKey(0)
            logging.info(f'\t\t正在修改完善【{k}】的简历信息....')
            session.findById("wnd[0]/usr/ctxtRP50G-PERNR").text = k
            session.findById("wnd[0]").sendVKey(0)
            session.findById("wnd[0]/usr/tabsMENU_TABSTRIP/tabpTAB01").select()
            session.findById(
                "wnd[0]/usr/tabsMENU_TABSTRIP/tabpTAB01/ssubSUBSCR_MENU:SAPMP50A:0400/subSUBSCR_ITMENU:SAPMP50A:0310/tblSAPMP50ATC_MENU").getAbsoluteRow(
                6).selected = -1
            tmp = session.findById(
                "wnd[0]/usr/tabsMENU_TABSTRIP/tabpTAB01/ssubSUBSCR_MENU:SAPMP50A:0400/subSUBSCR_ITMENU:SAPMP50A:0310/tblSAPMP50ATC_MENU/lblINF_EX[1,6]").toolTip
            if '不存在' in tmp:
                logging.warning(f'\t\t[{k}]不存在简历记录...')
                session.findById("wnd[0]/tbar[1]/btn[5]").press()  # 新建
                if session.findById("wnd[1]", False) is not None:  # 信息类型“简历”的子类型(可能会弹出)
                    session.findById("wnd[1]/usr/lbl[1,12]").setFocus()
                    session.findById("wnd[1]/usr/lbl[1,12]").caretPosition = 3  # 工作经历（含教育培训）
                    session.findById("wnd[1]").sendVKey(2)
                if '工作经历(含教育培训)' in session.findById("wnd[0]/usr/cmbP9252-ZZ_JLLX").value:
                    session.findById("wnd[0]/usr/ctxtP9252-BEGDA").text = v[0]  # 开始日期
                    session.findById("wnd[0]/usr/txtP9252-ZZ_XSSX").text = "1"  # 显示顺序
                    session.findById("wnd[0]/usr/txtP9252-ZZ_JLMS").text = v[1]  # 简历描述1
                    session.findById("wnd[0]/usr/txtP9252-ZZ_JLMS2").text = v[2]  # 简历描述2
                    session.findById("wnd[0]/tbar[0]/btn[11]").press()  # 保存
                    continue
                else:
                    logging.error('简历类型不是“9 工作经历(含教育培训)”')
                    raise Exception(session.findById("wnd[0]/usr/cmbP9252-ZZ_JLLX").value)
            session.findById("wnd[0]/tbar[1]/btn[20]").press()
            nrows = int(session.findById("wnd[0]/usr/txtRP50M-PAGEC").text)
            for i in range(nrows):
                l4 = session.findById(f"wnd[0]/usr/tblMP925200TC3000/ctxtP9252-ZZ_JLLX[3,{i}]").text
                l3 = int(session.findById(f"wnd[0]/usr/tblMP925200TC3000/txtP9252-ZZ_XSSX[2,{i}]").text)
                l1 = (session.findById(f"wnd[0]/usr/tblMP925200TC3000/txtP9252-BEGDA[0,{i}]").text).replace('/',
                                                                                                            '').replace('-',
                                                                                                                        '').replace(
                    '.', '')
                t1_lst.append((l1, l3, l4))
            if 'Z' not in [x[2] for x in t1_lst]:
                session.findById("wnd[0]/usr/ctxtRP50M-SUBTY").text = "9"
                session.findById("wnd[0]/tbar[1]/btn[5]").press()
                session.findById("wnd[0]/usr/ctxtP9252-BEGDA").text = v[0]
                session.findById("wnd[0]/usr/txtP9252-ZZ_XSSX").text = str(nrows + 1)
                session.findById("wnd[0]/usr/txtP9252-ZZ_JLMS").text = v[1]
                session.findById("wnd[0]/usr/txtP9252-ZZ_JLMS2").text = v[2]
                session.findById("wnd[0]/tbar[0]/btn[11]").press()
                session.findById("wnd[0]/usr/ctxtRP50M-SUBTY").text = ""
                session.findById("wnd[0]").sendVKey(0)
            else:
                n1 = min([int(x[1]) for x in t1_lst if x[2] == 'Z'])
                for i in range(nrows):
                    l3 = int(session.findById(f"wnd[0]/usr/tblMP925200TC3000/txtP9252-ZZ_XSSX[2,{i}]").text)
                    if l3 < n1:
                        continue
                    session.findById("wnd[0]/usr/tblMP925200TC3000").getAbsoluteRow(i).selected = -1
                    session.findById("wnd[0]/tbar[1]/btn[6]").press()
                    session.findById("wnd[0]/usr/txtP9252-ZZ_XSSX").text = str(l3 + 1)
                    session.findById("wnd[0]/tbar[0]/btn[11]").press()
                session.findById("wnd[0]/usr/ctxtRP50M-SUBTY").text = "9"
                session.findById("wnd[0]/usr/tblMP925200TC3000").getAbsoluteRow(n1).selected = -1
                session.findById("wnd[0]/tbar[1]/btn[5]").press()
                session.findById("wnd[0]/usr/ctxtP9252-BEGDA").text = v[0]
                session.findById("wnd[0]/usr/txtP9252-ZZ_XSSX").text = str(n1)
                session.findById("wnd[0]/usr/txtP9252-ZZ_JLMS").text = v[1]
                session.findById("wnd[0]/usr/txtP9252-ZZ_JLMS2").text = v[2]
                session.findById("wnd[0]/tbar[0]/btn[11]").press()
                session.findById("wnd[0]/usr/ctxtRP50M-SUBTY").text = ""
                session.findById("wnd[0]").sendVKey(0)
        session.findById("wnd[0]/tbar[0]/okcd").text = "/nex"
        session.findById("wnd[0]").sendVKey(0)
        logging.info('本次事件简历信息维护完成！')
