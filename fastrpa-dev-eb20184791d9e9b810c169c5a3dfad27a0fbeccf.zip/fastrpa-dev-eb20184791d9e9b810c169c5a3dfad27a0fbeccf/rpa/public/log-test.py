import datetime
import logging
import os


def log(log_file=''):
    logger = logging.getLogger(__name__)
    logger.setLevel(level=logging.INFO)
    fname = log_file if log_file else 'log.txt'
    log_file = f"{os.path.dirname(__file__)}/{fname}"
    handler = logging.FileHandler(log_file)
    handler.setLevel(logging.INFO)
    formatter = logging.Formatter('%(asctime)s - %(name)s - %(levelname)s - %(message)s')
    handler.setFormatter(formatter)

    console = logging.StreamHandler()
    console.setLevel(logging.DEBUG)

    logger.addHandler(handler)
    logger.addHandler(console)
    return logger


if __name__ == '__main__':
    filename = r"x:\Users\HR-HDH\Desktop\è¡¨121.xlsx"
    logger = log(f'log-{datetime.datetime.today().strftime("%Y%m%d-%H%M%S")}.log')
    logger.info("Start print log")
    logger.debug("Do something")
    logger.warning("Something maybe fail.")
    logger.info("Finish")
