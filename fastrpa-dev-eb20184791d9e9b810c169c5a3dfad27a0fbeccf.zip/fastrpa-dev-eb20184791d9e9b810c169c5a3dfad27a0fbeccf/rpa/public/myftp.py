#!/usr/bin/env python
# -*- coding: utf-8 -*-
# @File    : myftp.py
# @Author  : jinjianfeng
# @Contact : 553041800@qq.com
# @Link    : https://github.com/jinjf553
# @software: PyCharm
# @Date    : 2020/2/18 9:34
# @Version : ??
import logging
import os
import socket
import traceback
from ftplib import FTP  # nosec
from pathlib import Path
from stat import S_ISDIR
from typing import List

import paramiko  # type: ignore
from rpa.fastrpa.log import config
from rpa.public.config import ftp_user

# def _makepasv(self):
#     import ftplib
#     return ftplib.parse229(self.sendcmd('EPSV'), self.sock.getpeername())

# FTP.makepasv = _makepasv


class MyFTP:

    def __init__(self, host, port=21):
        """ 初始化 FTP 客户端
        参数:
                 host:ip地址
                 port:端口号
        """
        self.host = host
        self.port = port
        self.ftp = FTP()
        self.ftp.set_pasv(False)  # False主动模式 True被动模式
        # 重新设置下编码方式
        self.ftp.encoding = 'gbk'
        self.file_list: List[str] = []

    def login(self, username, password):
        """ 初始化 FTP 客户端
            参数:
                  username: 用户名
                 password: 密码
            """
        try:
            timeout = 30
            socket.setdefaulttimeout(timeout)
            # False主动模式 True被动模式
            self.ftp.set_pasv(False)
            # 打开调试级别2，显示详细信息
            # self.ftp.set_debuglevel(2)

            self.ftp.connect(self.host, self.port)
            self.ftp.login(username, password)
            if "Serv-U" not in self.ftp.getwelcome():
                self.ftp.encoding = "utf8"
            # logging.info(f'成功登录到FTP: {self.host}')

        except Exception as err:
            raise Exception(f'FTP 连接或登录失败 ，错误描述为：{err}')

    def download_file(self, local_file, remote_file) -> bool:
        """从ftp下载文件
            参数:
                local_file: 本地文件
                remote_file: 远程文件
        """
        _p = Path(local_file)
        if _p.exists() and _p.is_file():
            os.remove(_p)
        try:
            buf_size = 1024
            if not os.path.exists(os.path.dirname(local_file)):
                os.makedirs(os.path.dirname(local_file))
            with open(local_file, 'wb') as file_handler:
                self.ftp.retrbinary('RETR %s' % remote_file, file_handler.write, buf_size)
            logging.info(f"下载文件成功 【远程】={remote_file}, 【本地】={local_file}")
            return True
        except Exception as err:
            logging.error(f'下载文件出错 -【远程】={remote_file}，出现异常：{err} ')
            logging.error(f"调用栈: {traceback.format_exc()}")
            return False

    def download_file_tree(self, local_path, remote_path) -> bool:
        """从远程目录下载多个文件到本地目录
            参数:
                local_path: 本地路径
                remote_path: 远程路径
        """
        is_all_download_succ = True
        local_path, remote_path = local_path.replace("\\", "/"), remote_path.replace("\\", "/")
        try:
            self.ftp.cwd("/")
            self.ftp.cwd(remote_path)
        except Exception as err:
            logging.error(f'远程目录%s不存在，继续...{remote_path}异常描述为：{err}')
            return False

        local = local_path + "/" + remote_path.strip("/").split("/")[-1]
        if not os.path.isdir(local):
            logging.info(f'本地目录{local}不存在，先创建本地目录')
            os.makedirs(local)

        # self.ftp.pwd()
        self.file_list = []
        # 方法回调
        self.ftp.dir(self.__get_file_list)
        remote_names = self.file_list
        for item in remote_names:
            remote_path1 = remote_path + "/" + item[1]
            if item[0] == 'd':
                is_all_download_succ = is_all_download_succ and self.download_file_tree(local, remote_path1)
            else:
                is_all_download_succ = is_all_download_succ and self.download_file(local + '/' + item[1], remote_path1)
        self.ftp.cwd("..")
        logging.info(f"下载目录成功  【远程】={remote_path}, 【本地】={local_path}")
        return is_all_download_succ

    def upload_file(self, local_file, remote_file, log_flag=True, skip_exists=False):
        """从本地上传文件到ftp
           参数:
             local_path: 本地文件
             remote_path: 远程文件
        """
        if not os.path.isfile(local_file):
            logging.error(f'本地文件不存在{local_file}')
            return

        self.ftp.cwd("/")
        dir_list = remote_file.split('/')
        for x in dir_list[:-1]:
            try:
                self.ftp.mkd(x)
            except Exception:  # nosec
                pass
            self.ftp.cwd(x)

        remote_file_exists = Path(local_file).name in [filename for filename, _ in self.ftp.mlsd()]

        if remote_file_exists is False or skip_exists is False:
            buf_size = 1024
            with open(local_file, 'rb') as file_handler:
                self.ftp.storbinary('STOR %s' % dir_list[-1], file_handler, buf_size)
            if log_flag is True:
                logging.info(f'上传文件成功  【本地】={local_file}, 【远程】={remote_file}')

    def upload_file_tree(self, local_path, remote_path, log_flag=True, skip_exists=False):
        """从本地上传目录下多个文件到ftp
           参数:
             local_path: 本地路径
             remote_path: 远程路径
        """
        if not os.path.isdir(local_path):
            logging.error(f'本地目录 {local_path} 不存在')
            return
        self.ftp.cwd("/")
        dir_list = remote_path.split('/')
        for x in dir_list:
            try:
                self.ftp.mkd(x)
            except Exception:  # nosec
                pass
            self.ftp.cwd(x)
        self.ftp.pwd()

        local_name_list = os.listdir(local_path)
        for local_name in local_name_list:
            src = os.path.join(local_path, local_name)
            if os.path.isdir(src):
                try:
                    self.ftp.mkd(local_name)
                except Exception:  # nosec
                    pass
                self.upload_file_tree(src, remote_path + "/" + local_name, log_flag, skip_exists)
            else:
                self.upload_file(src, remote_path + "/" + local_name, log_flag, skip_exists)
        self.ftp.cwd("..")
        if log_flag is True:
            logging.info(f"上传目录成功  【本地】={local_path}, 【远程】={remote_path}")

    def delete(self, remote_file):
        """
            删除远程文件
            参数：
            remote_file: 远程文件
        """
        try:
            self.ftp.delete(remote_file)
            logging.info(f"删除文件成功  【远程】={remote_file}")
        except Exception:
            logging.error(f"删除文件失败 - 【远程】={remote_file}")

    def rmd(self, remote_path):
        """
            删除远程目录
            参数：
            remote_path： 远程目录
        """
        remote_path = remote_path.replace("\\", "/")
        try:
            self.ftp.cwd("/")
            self.ftp.cwd(remote_path)
            logging.warning(f"远程目录 {remote_path}已删除")
        except Exception:
            return
        self.file_list = []
        self.ftp.dir(self.__get_file_list)
        remote_names = self.file_list
        if not remote_names:
            self.ftp.rmd(remote_path)
            return

        for item in remote_names:
            remote_path1 = remote_path + "/" + item[1]
            if item[0] == "d":
                self.rmd(remote_path1)
            else:
                self.ftp.delete(remote_path1)
        self.ftp.rmd(remote_path)
        logging.info(f"删除目录成功  【远程】={remote_path}")

    def close(self):
        """ 退出ftp
        """
        # logging.info("FTP会话释放...")
        self.ftp.quit()

    def get_all_files(self, remote_dir, files=None):
        if files is None:
            files = list()
            _, remote_dir = (remote_dir.rstrip("/") + "/").split("/"), remote_dir.rstrip("/") + "/"
        self.file_list = []
        self.ftp.dir(remote_dir, self.__get_file_list, )
        files = files
        for file in self.file_list:
            if "d" in file[0]:
                dir_name = str(file[1]).lstrip() + "/"
                self.get_all_files(remote_dir=remote_dir + dir_name, files=files)
            else:
                files.append(remote_dir + file[1])
        return files

    def __get_file_list(self, line):
        """ 获取文件列表
            参数：
                line：
        """
        file_arr = self.__get_file_name(line)
        # 去除  . 和  ..
        if file_arr[1] not in ['.', '..']:
            self.file_list.append(file_arr)

    @staticmethod
    def __get_file_name(line):
        """ 获取文件名
            参数：
                line：
        """
        pos = line.rfind(':')
        while line[pos] != ' ':
            pos += 1
        while line[pos] == ' ':
            pos += 1
        file_arr = [line[0], line[pos:]]
        return file_arr


class MyXFTP:

    def __init__(self, host: str, user: str, pwd: str, port: int = 22) -> None:
        self.host = host
        self.port = port
        self.ftp = self.login(username=user, password=pwd)
        self.file_list: List[str] = []

    def login(self, username, password):
        try:
            # noinspection PyTypeChecker
            transport = paramiko.Transport((self.host, self.port))
            transport.connect(username=username, password=password)
            a = paramiko.SFTPClient.from_transport(transport)
            return a
        except Exception as err:
            raise Exception("SFTP 连接或登录失败 ，错误描述为：%s" % err)

    def download_file(self, local_file, remote_file) -> bool:
        """从ftp下载文件
            参数:
                local_file: 本地文件

                remote_file: 远程文件
        """
        _p = Path(local_file)
        if _p.exists() and _p.is_file():
            os.remove(_p)
        try:
            if not os.path.exists(os.path.dirname(local_file)):
                os.makedirs(os.path.dirname(local_file))
            with self.ftp.open(remote_file, "rb") as infile:
                with open(local_file, "wb") as outfile:
                    for chunk in infile.readlines():
                        outfile.write(chunk)
            # self.ftp.get(remotepath=remote_file, localpath=local_file)
            logging.info(f"下载文件成功 【本地】={local_file}, 【远程】={remote_file}")
            return True
        except Exception as err:
            logging.error(f'下载文件出错 -【远程】={remote_file}，出现异常：%s ' % err)
            logging.error(f"调用栈: {traceback.format_exc()}")
            return False

    def download_file_tree(self, local_path, remote_path) -> bool:
        """从远程目录下载多个文件到本地目录
            参数:
                local_path: 本地路径
                remote_path: 远程路径
        """
        is_all_download_succ = True
        try:
            files = self.get_all_files(remote_path)
        except Exception as err:
            logging.error(f"远程目录 {remote_path} 不存在，继续...,异常描述为：{err}")
            return False

        if not os.path.isdir(local_path):
            logging.info(f'本地目录 {local_path} 不存在，先创建本地目录')
            os.makedirs(local_path)

        for remote_file in files:
            a = (remote_path.rstrip("/") + "/").split("/")
            remote_path = remote_path[:-len(a) - 1]
            is_all_download_succ = is_all_download_succ and self.download_file(local_path.rstrip("/" and "\\") + "/" + remote_file, remote_path + remote_file)
        logging.info(f"下载目录成功  【远程】={remote_path}, 【本地】={local_path}")
        return is_all_download_succ

    def upload_file(self, local_file, remote_file, log_flag=True, skip_exists=False):
        """从本地上传文件到ftp
           参数:
             local_path: 本地文件
             remote_path: 远程文件
        """
        try:
            new_dirs = "/"
            for new_dir in remote_file.split("/")[1:-1]:
                new_dirs += new_dir + "/"
                try:
                    self.ftp.mkdir(new_dirs)
                except Exception:  # nosec
                    pass
            remote_file_exists = Path(local_file).name in self.ftp.listdir(Path(remote_file).parent.as_posix())
            if remote_file_exists is False or skip_exists is False:
                self.ftp.put(local_file, remote_file)
                if log_flag is True:
                    logging.info(f"上传文件成功  【本地】={local_file}, 【远程】={remote_file}")
        except socket.timeout:
            logging.error('连接FTP超时，请检查网络连接和Windows防火墙策略（入站规则是否禁止python.exe访问远程地址）')
            logging.error('或尝试以管理员身份打开Powershell，并执行命令：netsh advfirewall firewall set rule name="python.exe" new action=allow')
        except Exception as err:
            logging.error(f'上传文件出错 - 【本地】={local_file}， 出现异常：{err}')

    def upload_file_tree(self, local_path, remote_path, log_flag=True, skip_exists=False):
        """从本地上传目录下多个文件到ftp
           参数:
             local_path: 本地路径
             remote_path: 远程路径
        """
        if not os.path.isdir(local_path):
            logging.error(f'本地目录 {local_path} 不存在')
            return
        for _file, dirs, files in os.walk(local_path):
            for file in files:
                remote = remote_path.rstrip("/") + "/" + os.path.basename(local_path) + "/" + _file[len(local_path):]
                self.upload_file(_file + "/" + file, remote.replace("\\", "/") + "/" + file, log_flag, skip_exists)
        if log_flag is True:
            logging.info(f"上传目录成功  【本地】={local_path}, 【远程】={remote_path}")

    def delete(self, remote_file):
        """
            删除远程文件
            参数：
            remote_file: 远程文件
        """
        try:
            self.ftp.remove(remote_file)
            logging.info(f"删除文件成功  【远程】={remote_file}")
        except Exception:
            logging.error(f"删除文件失败 - 【远程】={remote_file}")

    def rmd(self, remote_path):
        """
            删除远程目录
            参数：
            remote_path： 远程目录
        """
        try:
            files = self.ftp.listdir(path=remote_path)
            for f in files:
                filepath = os.path.join(remote_path, f)
                if S_ISDIR(self.ftp.stat(filepath).st_mode):
                    self.rmd(filepath)
                else:
                    self.ftp.remove(filepath)
            self.ftp.rmdir(remote_path)
            logging.info(f"删除目录成功  【远程】={remote_path}")
        except Exception as err:
            # raise err
            logging.error(f"删除目录失败  【远程】={remote_path}, 异常描述为：{err}")

    def close(self):
        """ 退出ftp
        """
        logging.info("SFTP会话释放...")
        self.ftp.close()

    def get_all_files(self, remote_dir='/', dirs=None):
        if dirs is None:
            a, remote_dir = (remote_dir.rstrip("/") + "/").split("/"), remote_dir.rstrip("/") + "/"
            dirs = remote_dir[:-len(a[-2]) - 1]
        all_files = list()
        if remote_dir[-1] == '/':
            remote_dir = remote_dir[0:-1]
        files = self.ftp.listdir_attr(remote_dir)
        for x in files:
            filename = remote_dir + '/' + x.filename
            if S_ISDIR(x.st_mode):
                all_files.extend(self.get_all_files(filename, dirs))
            else:
                all_files.append(filename[len(dirs):])
        return all_files

    def __get_file_list(self, line):
        """ 获取文件列表
            参数：
                line：
        """
        pass

    def __get_file_name(self, line):
        """ 获取文件名
            参数：
                line：
        """
        pass


def _myftp():
    FTP_ADDRESS, FTP_PASSWORD, FTP_PORT, FTP_USERNAME = ftp_user()
    if FTP_PORT == "21":
        my_ftp = MyFTP(FTP_ADDRESS)
        my_ftp.login(FTP_USERNAME, FTP_PASSWORD)
    # elif FTP_PORT == "22":
    #     my_ftp = MyXFTP(FTP_ADDRESS, FTP_USERNAME, FTP_PASSWORD)
    else:
        raise Exception(f"FTP端口错误：（{FTP_PORT},端口应为21或者22,请修改数据库user_password表{FTP_USERNAME}数据的"
                        f"remark字段数据为：21或者22）")
    return my_ftp


class MYFTP(object):
    """请使用使用该工具类访问ftp & sftp"""

    def __init__(self):
        self.ftp = _myftp()

    def __enter__(self):
        return self.ftp

    def __exit__(self, exc_type, exc_val, exc_tb):
        self.ftp.close()


if __name__ == '__main__':
    config()
    with MYFTP() as ftp:
        ftp.upload_file("x:/test.log", "/test/test.log", False, False)
