import logging
import os
import shutil

from loguru import logger
from rpa.fastrpa.log import config
from rpa.public.all_party_up import (batch_import, check_result2, data_check,
                                     export_party103, file_archive,
                                     form_checking, judge, sap_modify,
                                     tableprocess, updateDB)
from rpa.public.config import local_path
from rpa.public.run_sap import close_sap


def all_Party(filename: str):
    # work_dir = get_work_path(filename, ctype='政治面貌')
    fname = os.path.basename(filename)
    shutil.copyfile(filename, f"{local_path}/{fname}")
    form_fname = f"{local_path}/{fname}"
    config(f'{os.path.splitext(fname)[0]}.log')

    # 检测新旧表单
    xflag = False if judge(form_fname, '政治面貌信息表') else True
    # 检查表单文件格式，确定有无数据
    numbers = form_checking(form_fname, xflag, ctype='政治面貌')
    if not numbers:
        logging.info('请检查表单文件格式是否错误（或有无数据）！')
        logger.info(f'企业表单文件格式有误或数据为空！（{form_fname}）')
        file_archive(form_fname, is_succ=False, ctype='政治面貌')
        # uploadFtp(form_fname, is_succ=False)
        return

    result_file, n = tableprocess(form_fname, xflag)
    # SAP中导出事前信息
    file103 = f'{os.path.splitext(form_fname)[0]}_103.xlsx'
    if not export_party103(numbers, file103):
        file103 = ''
        logger.info(f'从SAP系统中未查询到数据！（{form_fname}）')

    # 表单数据和SAP数据进行逻辑检查
    result = data_check(result_file, file103)
    if result is None:
        return
    if result < 0:
        logger.info(f'表单或103文件打开失败！（{form_fname}）')
        file_archive(form_fname, is_succ=False, ctype='政治面貌')
        # uploadFtp(form_fname, is_succ=False)
        return
    elif result == 0:
        logger.info(f'没有符合条件需要处理的数据！（{form_fname}）')
        return

    # 检查有无模板文件，如有批导
    updateDB(os.path.split(form_fname)[-1], n, '开始执行')
    batches = batch_import(result_file)
    # SAP信息零星维护
    result = sap_modify(result_file, batches)
    if not result:
        file_archive(form_fname, is_succ=False, ctype='政治面貌')
        # uploadFtp(form_fname, is_succ=False)
        return

    # SAP导出事后结果表
    file1032 = f'{os.path.splitext(form_fname)[0]}_103_2.xlsx'
    _ = export_party103(numbers, file1032)
    close_sap()
    # 检查执行结果并写入结果表
    result = check_result2(result_file, file1032)

    # # 更新数据库将结果上传FTP服务器
    updateDB(os.path.split(form_fname)[-1], n, '执行结束')
    file_archive(form_fname, is_succ=True, ctype='政治面貌')
    # uploadFtp(form_fname, is_succ=True, ctype='政治面貌')

    logging.info(f'{result}, ok')
