#!/usr/bin/env python
# -*- coding: utf-8 -*-
# @File    : deal_excel.py
# @Author  : jinjianfeng
# @Contact : 553041800@qq.com
# @Link    : https://github.com/jinjf553
# @software: PyCharm
# @Date    : 2019/4/14 22:08
# @Version : ??
import logging

from openpyxl import Workbook, load_workbook
from openpyxl.comments import Comment
from openpyxl.styles import PatternFill
from rpa.fastrpa.adtable import RED


def add_comment_to_excel(file, code, content):
    wb = load_workbook(file)
    ws = wb.active
    for row_values in ws.rows:
        for value in row_values:
            if value.value and len(str(value.value)) > 5 and str(value.value) in code:
                logging.info(f'{code}, {value}')
                value.comment = Comment(content, 'RPA')
                value.fill = PatternFill("solid", RED)
                break
        else:
            continue
        break
    wb.save(file)


def save_as_excel(file):
    wb = load_workbook(file)
    ws = wb.active

    index = 0
    data = []
    for j in ws.columns:  # we.rows 获取每一列数据
        if "中文名称" in [k.value for k in j]:
            index = [k.value for k in j].index("序列号")
            data.append([k.value for k in j][index + 1:])
        if "人员编号" in [k.value for k in j]:
            data.append([k.value for k in j][index + 1:])
        if "人员姓名" in [k.value for k in j]:
            data.append([k.value for k in j][index + 1:])
    if not data:
        raise Exception("模板表格式有误或者无数据...")

    inti_list = [['序号', '人员编号', '姓名', '备注']] * 4

    wb1 = Workbook()
    ws1 = wb1.active
    for x in inti_list:
        ws1.append(x)

    for x in list(zip(*data)):
        ws1.append(x)
    wb1.save("tmp.xlsx")
    return "tmp.xlsx"
