#!/usr/bin/env python
# -*- coding: utf-8 -*-
# @File    : run_sap.py
# @Author  : jinjianfeng
# @Contact : 553041800@qq.com
# @Link    : https://github.com/jinjf553
# @software: PyCharm
# @Date    : 2019/7/12 11:01
# @Version : ??
import time
from threading import Thread

import rpa.ssc.hr.orm.tb_user
import win32api
import win32com.client
import win32con
import win32gui
from rpa.fastrpa.utils.window import click_allow
from rpa.public.config import recv_user, send_mail, user_name
from rpa.ssc.hr.orm.orm_ope import get_session


def login_sap():
    username, password = user_name()
    close_sap()
    win32api.ShellExecute(0, 'open', r"saplogon.exe", '"PH3" 02', '', 1)
    t = Thread(target=click_allow)
    t.setDaemon(True)
    t.start()

    for x in range(30):
        try:
            SapGuiAuto = win32com.client.GetObject("SAPGUI")
            application = SapGuiAuto.GetScriptingEngine
            connection = application.Children(0)
            session = connection.Children(0)
            # logging.info('连接PH3成功！')
            break
        except Exception as e:
            time.sleep(0.5)
    else:
        raise Exception("未能连接到SAP系统！")
    session.findById("wnd[0]").maximize()
    session.findById("wnd[0]/usr/txtRSYST-BNAME").text = username
    session.findById("wnd[0]/usr/pwdRSYST-BCODE").text = password
    session.findById("wnd[0]/tbar[0]/btn[0]").press()
    if u"口令不正确" in session.findById("wnd[0]/sbar/pane[0]").text:
        session.findById("wnd[0]/tbar[0]/okcd").text = "/nex"
        session.findById("wnd[0]").sendVKey(0)
        close_sap()
        session = get_session()
        session.query(rpa.ssc.hr.orm.tb_user.User).filter_by(username=username).update({'state': '0'})
        session.commit()
        send_mail(recv_user(), username)
        raise Exception('SAP口令不正确')

    try:
        session.findById("wnd[1]/usr/radMULTI_LOGON_OPT2").select()
        session.findById("wnd[1]/usr/radMULTI_LOGON_OPT2").setFocus()
        session.findById("wnd[1]").sendVKey(0)
    except Exception as e:
        pass
    return session


def close_sap():
    for i in range(100):
        dialog = win32gui.FindWindow(u"SAP_FRONTEND_SESSION", None)  # 对话框
        if dialog:
            win32gui.PostMessage(dialog, win32con.WM_CLOSE, 0, 0)
            time.sleep(1)

    for i in range(100):
        dialog = win32gui.FindWindow(None, "SAP Logon 740")  # 对话框
        if dialog:
            win32gui.PostMessage(dialog, win32con.WM_CLOSE, 0, 0)
            time.sleep(1)

    for i in range(100):
        dialog = win32gui.FindWindow(None, "SAP Logon 730")  # 对话框
        if dialog:
            win32gui.PostMessage(dialog, win32con.WM_CLOSE, 0, 0)
            time.sleep(1)


def close_err_sap():
    while True:
        for i in ["3", "4", "5"]:
            dialog = win32gui.FindWindow(None, f"SAP GUI for Windows 7{i}0")  # 对话框
            if dialog:
                win32gui.PostMessage(dialog, win32con.WM_CLOSE, 0, 0)
                time.sleep(1)
        time.sleep(2)
