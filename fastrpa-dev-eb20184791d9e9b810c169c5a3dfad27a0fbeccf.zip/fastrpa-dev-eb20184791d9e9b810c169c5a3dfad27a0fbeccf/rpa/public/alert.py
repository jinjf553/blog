#!/usr/bin/env python
# -*- coding: utf-8 -*-
# @File    : alert.py
# @Author  : jinjianfeng
import time
from contextlib import contextmanager
from ctypes import windll
from multiprocessing.context import Process
from threading import Thread
from tkinter import Label, Text, Toplevel, W


def show_message(duration, content='自动拆单等待中...\n倒计时结束或者手动关闭可恢复拆单。', lbx='距离窗口关闭还有'):
    flag = {True: 0}

    def close(x):
        x.destroy()
        flag.update({True: 1})

    top = Toplevel()
    top.wm_attributes('-topmost', 1)
    top.overrideredirect(True)
    top.title('请等待...')
    screenWidth = top.winfo_screenwidth()
    screenHeight = top.winfo_screenheight()
    ww, wh = 600, 480
    top.geometry('%dx%d+%d+%d' % (ww, wh, (screenWidth - ww) / 2, (screenHeight - wh) / 2 - 100))
    top.resizable(False, False)
    txt = Text(top, width=180)
    txt.grid(row=0, column=0)
    txt.insert('0.0', content)
    # txt.delete('1.0', 'end')
    # txt.insert('0.0', '假设阅读这些文字需要9秒钟时间')
    # bt = Button(top, text="关闭", command=lambda: close(top))
    # bt.place(x=160, y=70, width=40)
    lb = Label(top, fg='red', anchor='w')
    lb.grid(row=1, column=0, sticky=W)
    t = Thread(target=autoClose, args=(top, lb, duration, lbx))
    t.setDaemon(True)
    t.start()
    try:
        top.mainloop()
        top.destroy()
    except Exception:  # nosec
        pass
    return flag[True]


def autoClose(top, lb, duration: int = 10, lbx='距离窗口关闭还有'):
    if lbx != "距离窗口关闭还有":
        t = 0
        while True:
            try:
                if t > 3600:
                    txt = f"{int(t / 3600)}时{int((t % 3600) / 60)}分{t % 60}秒"
                elif t > 60:
                    txt = f"{int(t / 60)}分{t % 60}秒"
                else:
                    txt = f"{t % 60}秒"
                lb['text'] = f'{lbx}({txt})'
                t += 1
                time.sleep(1)
            except Exception:  # nosec
                pass
    for i in range(duration):
        t = duration - i
        if t > 3600:
            txt = f"{int(t / 3600)}时{int((t % 3600) / 60)}分{t % 60}秒"
        elif t > 60:
            txt = f"{int(t / 60)}分{t % 60}秒"
        else:
            txt = f"{t % 60}秒"
        try:
            lb['text'] = f'距离窗口关闭还有{txt}'
        except Exception:  # nosec
            pass
        time.sleep(1)
    top.destroy()


@contextmanager
def show_state(mode: int = 1):
    try:
        t = Process(target=show_message, args=(10, "自动拆单进行中...\n请等待拆单完成，期间禁用键盘鼠标", "已等待"))
        t.start()
        if mode == 1:
            windll.user32.BlockInput(1)
        yield
    except Exception as e:
        raise e
    else:
        windll.user32.BlockInput(0)
        t.terminate()
