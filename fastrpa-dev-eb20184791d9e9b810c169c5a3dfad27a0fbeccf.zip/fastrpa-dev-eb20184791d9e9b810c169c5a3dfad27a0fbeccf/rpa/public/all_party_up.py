import copy
import logging
import os
import re
import shutil
import time
from collections import Counter, defaultdict
from datetime import datetime
from threading import Thread
from typing import Any

import pyperclip
import rpa.config
from loguru import logger
from openpyxl import Workbook, load_workbook
from openpyxl.comments import Comment
from openpyxl.styles import PatternFill
from openpyxl.utils import get_column_letter
from rpa.fastrpa.adtable import BLUE, RED, AdTable
from rpa.fastrpa.date_funcs import to_yyyymmdd
from rpa.fastrpa.sap.session import attach_sap
from rpa.public.config import templates
from rpa.public.date_parser import DateParser
from rpa.public.myftp import MYFTP
from rpa.public.run_sap import click_allow, close_sap
from rpa.public.tools import click_continue, find_window
from rpa.ssc.hr.orm.orm_ope import Insert, Query, Update
from rpa.ssc.hr.orm.tb_hr_ruzhi_log import RZLog
from rpa.ssc.sap.query import export_query, parse_query_string

st_dict = dict(党员='01 中共党员', 党='01 中共党员', 预备='02 中共预备党员', 团员='03 共青团员', 团='03 共青团员', 无='13 群众')
st_list = ('01 中共党员', '02 中共预备党员', '03 共青团员', '04 民革会员', '05 民盟盟员', '06 民建会员', '07 民进会员',
           '08 农工党党员', '09 致公党党员', '10 九三学社社员', '11 台盟盟员', '12 无党派民主人士', '13 群众')


def tableprocess(form_fname: str, xflag=False):
    """新旧表单转换成模板 新表单格式 xfalg 为True"""
    if xflag:
        dydict = dict(A='A', B='B', C='C', D='E', F='F', G='G', H='H', I='I', J='D')
        col, shtname, start = 'F', '基本信息修改表', 8
    else:
        dydict = dict(A='A', B='B', C='C', D='E', F='D', H='F', I='G', J='H')
        col, shtname, start = 'D', '政治面貌信息', 7

    try:
        wb_form = load_workbook(form_fname)
        ws_form = wb_form[shtname]
    except Exception:  # nosec
        logger.error(f'企业表单文件打开失败!（{form_fname}）')
        return -1
    try:
        wb_mb = load_workbook(os.path.join(templates, '0534_HR_BI_0534-政治面貌信息.xlsx'))
        ws_mb = wb_mb['0534_政治面貌信息']
    except Exception:  # nosec
        logger.error('0534政治面貌模板文件打开失败!')
        return -1
    n = 6
    for i in range(start, ws_form.max_row + 1):
        if str(ws_form[f'{col}{i}'].value).replace('None', '').strip():  # and ws_form[f'{col}{i}'].value in st_list:
            n += 1
            for k, v in dydict.items():
                ws_mb[f'{k}{n}'] = ws_form[f'{v}{i}'].value
    mb_file = os.path.join(os.path.dirname(form_fname), '政治面貌信息维护_结果文件.xlsx')
    wb_mb.save(mb_file)
    wb_mb.close()
    wb_form.close()
    return mb_file, n - 6


def form_checking(filename: str, xflag=False, ctype='政治面貌'):
    """表单文件格式检查，如为非标准格式返回 None"""
    if ctype == '政治面貌':
        st_data = dict(A1='政治面貌信息表', B3='人员编号', C3='姓名', D3='政治面貌', E3='加入时间', A6='取值举例')
        shtname = '政治面貌信息'
        if xflag:
            st_data = dict(A2='员工基本信息综合表', B4='人员编号', C4='姓名', F4='政治面貌', E4='开始日期', A7='取值举例')
            shtname = '基本信息修改表'
    elif ctype == '年度考核':
        st_data = dict(A1='员工考核信息表', B3='人员编号', H3='考核结果等级', D3='开始日期', F3='考核类型', A6='取值举例')
        shtname = '员工考核信息'
        if xflag:
            st_data = dict(A2='员工考核信息表', B4='人员编号', C4='姓名', F4='考核类型', D4='开始日期', A7='取值举例')
    else:
        logging.error("表单检查参数错误!")
        return None

    try:
        wb = load_workbook(filename)
        ws = wb[f"{shtname}"]
    except Exception as e:
        logging.error(f"打开表单文件失败!{e}")
        return None
    for key, value in st_data.items():
        if value not in str(ws[key].value):
            fill_notes(ws['A2' if xflag else 'A1'], "请检查是否为标准规范表单！", RED)
            wb.save(filename)
            logging.error(f'表单格式错误，请检查表单是否为规范表单（{os.path.split(filename)[-1]}）')
            logger.error(f'表单格式错误，请检查表单是否为规范表单（{os.path.split(filename)[-1]}）')
            return None
    if xflag:
        t1 = [str(x.value) for x in ws['B']][7:]
        tf = [str(x.value) for x in ws['F']][7:]
        t = [x for x in t1 if tf[t1.index(x)] != 'None']
    else:
        t = [str(x.value) for x in ws['B']][6:]
    numbersform = [y.strip() for y in t if y.strip() != 'None']
    # logging.info(f'{t}, {numbersform}')
    if not numbersform:
        fill_notes(ws['A2' if xflag else 'A1'], "文件数据为空，请检查！", RED)
        wb.save(filename)
        logging.info(f'文件数据为空，请检查！（{os.path.split(filename)[-1]}）')
        logger.error('表单文件数据为空（{os.path.split(filename)[-1]}）')
        return None
    logger.info('企业表单格式数据符合要求，检查完成！')
    return numbersform


@logger.catch
def data_check(fname: str, sap_fname: str):
    sap_datas: Any = defaultdict(dict)
    try:
        wb_sap = load_workbook(sap_fname)
        ws_sap = wb_sap.active  # ["Sheet"] wb_sap.worksheets[0]
    except Exception as e:
        print("sap数据文件打开失败!", e)
        logger.error(f'sap数据文件打开失败!（{sap_fname}）')
        return 0
    for i in range(2, ws_sap.max_row + 1):
        t = [str(x.value).strip().replace('None', '') for x in ws_sap[i]]
        t1 = [t[2][:10].replace('.', ''), t[3][:10].replace('.', ''), t[8], t[9], t[10], '']
        t0, t2 = re.sub(r'^0+(?!$)', '', t[0]), f'{t[6]} {t[7]}'
        if not t0 or not t2 or t1[0] == '00000000':
            continue
        if t0 not in sap_datas:
            sap_datas[t0] = ({t[1]: {t2: t1}})
        elif t[1] not in sap_datas[t0]:
            sap_datas[t0][t[1]] = ({t2: t1})
        elif t2 not in sap_datas[t0][t[1]]:
            sap_datas[t0][t[1]][t2] = t1
    # print(sap_datas)
    wb_sap.close()
    try:
        wb_form = load_workbook(fname)
        ws_form = wb_form.worksheets[0]  # [0534_'政治面貌信息']  wb_form["Sheet1"]
    except Exception as e:
        logging.error(f"过程文件打开失败!{e}")
        logger.error(f'过程文件打开失败!（{fname}）')
        return -1
    sap_new = copy.deepcopy(sap_datas)
    sap_copy = copy.deepcopy(sap_datas)
    for i in range(7, ws_form.max_row + 1):
        ws_form[f"K{i}"] = ''
        t = [str(x.value).strip().replace('None', '') for x in ws_form[i]][1:10]
        # 人员编号去0处理
        t0, t1 = re.sub(r'^0+(?!$)', '', t[0]), t[1]  # type: ignore
        if not t0 or not t1:
            continue
        t2, t3 = trans_mb(t[4], st_dict, st_list), trans_date(t[2])
        if not t2:
            fill_notes(ws_form[f'F{i}'], '政治面貌码表值错误', RED)
            ws_form[f'K{i}'] = '政治面貌码表值错误'
            continue
        if not t3:
            fill_notes(ws_form[f'D{i}'], '加入日期值错误', RED)
            ws_form[f'K{i}'] = '加入日期值错误'
            continue

        if t0 not in sap_datas:  # SAP中无记录
            sap_copy[t0][t1] = {t2: [t3, '99991231', '', t[6], t[7], '新增']}
            sap_new[t0][t1] = {t2: [t3, '99991231', '', t[6], t[7], '新增']}
            continue

        if not trans_flag(t[2]):
            fill_notes(ws_form[f"K{i}"], '加入日期为不确定值', BLUE)

        if t1 not in sap_datas[t0]:
            fill_notes(ws_form[f'C{i}'], f'姓名不一致(系统：{list(sap_datas[t0].keys())[0]}!)', RED)
            ws_form[f'K{i}'] = '姓名与系统不一致'
            continue
        if t2 in sap_datas[t0][t1]:
            if t3 == sap_datas[t0][t1][t2][0]:
                if '删除' in t[8]:
                    sap_copy[t0][t1][t2][5] = '删除'
                else:
                    ws_form[f"K{i}"] = '系统已有相同记录未处理'
            elif '修改' in t[8]:
                sap_new[t0][t1][t2][0] = t3
            else:
                ws_form[f"K{i}"] = '与系统记录有冲突'
            continue
        else:
            for k, v in sap_copy[t0][t1].items():
                if v[0] == t3 and '修改' in t[8]:
                    sap_copy[t0][t1].pop(k)
                    sap_new[t0][t1].pop(k)
                    sap_copy[t0][t1][t2] = [t3, v[1], v[2], v[3], v[4], '修改']
                    sap_new[t0][t1][t2] = [t3, v[1], v[2], v[3], v[4], '修改']
                elif v[5] != '新增':
                    ws_form[f"K{i}"] = '时间记录已有，检查是否需要修改'
                break
            else:
                sap_copy[t0][t1][t2] = [t3, '99991231', '', t[6], t[7], '新增']
                sap_new[t0][t1][t2] = [t3, '99991231', '', t[6], t[7], '新增']

    wb_form.save(fname)

    for i in range(7, ws_form.max_row + 1):
        if not ws_form[f"K{i}"]:
            continue
        t = [str(x.value).strip().replace('None', '') for x in ws_form[i]][1:10]
        # 人员编号去0处理
        t0, t1 = re.sub(r'^0+(?!$)', '', t[0]), t[1]  # type: ignore
        t2, t3 = trans_mb(t[4], st_dict, st_list), trans_date(t[2])
        # 逻辑检查
        sort_t = sorted((sap_new[t0][t1]).items(), key=lambda x: x[1][0], reverse=True)
        # logger.opt(exception=True).info(f'({t1}, {t2},{t3}, {sort_t})')
        err_flag, rec_no = False, 0
        for j in sort_t:
            if '新增' in t[8] and logic_test(t2, t3, j[0], j[1][0]):
                fill_notes(ws_form[f'D{i}'], f'表单【{t2}:{t3}】\n系统【{j[0]}:{j[1][0]}】', RED)
                ws_form[f"K{i}"] = '日期和系统数据出现逻辑错误！'
                err_flag = True
                break
        if err_flag:
            continue

        for n, j in enumerate(sort_t):
            if t3 > j[1][0]:
                rec_no = n
                break
        else:
            rec_no = len(sap_datas[t0][t1])
        xfg = False
        for j in range(len(sort_t)):
            type1, b1, b2 = sort_t[j][0], sort_t[j][1][0], sort_t[j][1][1]
            if t2 == type1:
                ed = '99991231' if j == 0 else trans_h(sort_t[j - 1][1][0])
                sap_copy[t0][t1][t2] = [t3, ed, '', t[6], t[7], '新增' if '新增' in sort_t[j][1][5] else '修改']
                xfg = True
            elif t3 == b1:
                # todo 需要检查系统中是否有预备或正式 时间逻辑
                sap_copy[t0][t1].pop(type1)
                if t2 not in sap_copy[t0][t1]:
                    sap_copy[t0][t1][t2] = [t3, b2, '', '', '', '修改']
            elif j == rec_no:
                if not xfg:
                    ed = '99991231' if j == 0 else trans_h(sort_t[j - 1][1][0])
                    sap_copy[t0][t1][t2] = [t3, ed, '', t[6], t[7], '新增']
                    sap_copy[t0][t1][type1][1] = trans_h(t3)
                if not sap_copy[t0][t1][type1][5]:
                    sap_copy[t0][t1][type1][1] = trans_h(t3)
                    sap_copy[t0][t1][type1][5] = '定界'
            else:
                if j == 0 and b2 != '99991231':
                    sap_copy[t0][t1][type1][1] = '99991231'
                    if not sap_copy[t0][t1][type1][5]:
                        sap_copy[t0][t1][type1][5] = '修改'
                elif j > 0 and b2 != trans_h(sort_t[j - 1][1][0]):
                    sap_copy[t0][t1][type1][1] = trans_h(sort_t[j - 1][1][0])
                    if not sap_copy[t0][t1][type1][5]:
                        sap_copy[t0][t1][type1][5] = '定界'
        if rec_no == len(sort_t):  # and t2 not in sap_copy[t0][t1]:
            sap_copy[t0][t1][t2] = [t3, trans_h(sort_t[rec_no - 1][1][0]), '', t[6], t[7], '新增']

    try:
        wb_form.remove(wb_form['temp'])  # del wb_form['temp']
    except Exception:  # nosec
        pass
    ws = wb_form.create_sheet(title='temp')  # ws = wb_form.copy_worksheet(ws_form)
    ws.append(('中文名称', '人员编号', '姓名', '开始日期', '结束日期', '政治面貌', '参加单位', '介绍人1', '介绍人2', '修改标志'))
    total_number = 0
    for k, v in sap_copy.items():
        for k1, v1 in sap_copy[k].items():
            for k2, v2 in sap_copy[k][k1].items():
                if v2[5]:
                    total_number += 1
                    ws.append((total_number, k, k1, v2[0], v2[1], k2, v2[2], v2[3], v2[4], v2[5]))
    wb_form.save(fname)
    wb_form.close()
    logger.info(f'数据逻辑检查预处理完成,请查看:【{fname}】中[temp]工作表内容！')
    return total_number


def Party_C103(session, date):
    # session.findById("wnd[0]").maximize()
    session.findById("wnd[0]/tbar[0]/okcd").text = "/n S_PH0_48000513"
    session.findById("wnd[0]").sendVKey(0)
    session.findById("wnd[1]/usr/cmbDYNP4100-DD_WORKSPACE").key = "2"
    session.findById("wnd[1]/usr/cmbDYNP4100-DD_USERGROUP").key = "103"
    session.findById("wnd[1]/usr/tblSAPLAQ_INT_FUNCTIONSTCH_FUNCAREAS").getAbsoluteRow(1).selected = -1
    session.findById("wnd[1]/tbar[0]/btn[0]").press()
    temp = "wnd[0]/shellcont[1]/shell/shellcont[0]/shell/shellcont[1]/shell[1]"
    session.findById(temp).expandNode("          2")
    session.findById(temp).changeCheckbox("          3", "C          3", -1)
    session.findById(temp).itemContextMenu("          3", "C          4")
    session.findById(temp).selectContextMenuItem("OUTPUT_BOTH")
    session.findById(temp).expandNode("        132")
    session.findById(temp).changeCheckbox("        133", "C          4", -1)
    session.findById(temp).changeCheckbox("        134", "C          4", -1)
    session.findById(temp).changeCheckbox("        135", "C          4", -1)
    session.findById(temp).changeCheckbox("        136", "C          4", -1)
    session.findById(temp).itemContextMenu("        137", "C          4")
    session.findById(temp).selectContextMenuItem("OUTPUT_BOTH")
    session.findById(temp).changeCheckbox("        138", "C          4", -1)
    session.findById(temp).changeCheckbox("        139", "C          4", -1)
    session.findById(temp).changeCheckbox("        140", "C          4", -1)
    session.findById(
        "wnd[0]/usr/subSUB_MAIN:SAPLAQ_ADHOC:0210/subSUB_APPLICATION:SAPLHR_QUERY_APPL_AREA:0122/subSUB:SAPLHR_QUERY_APPL_AREA:0121/btnDYNP121-EVALUATION_PERIOD_TEXT").press()
    session.findById(
        "wnd[0]/usr/subSUB_MAIN:SAPLAQ_ADHOC:0210/subSUB_APPLICATION:SAPLHR_QUERY_APPL_AREA:0122/subSUB:SAPLHR_QUERY_APPL_AREA:0120/cmbDD_DATE").setFocus()
    session.findById(
        "wnd[0]/usr/subSUB_MAIN:SAPLAQ_ADHOC:0210/subSUB_APPLICATION:SAPLHR_QUERY_APPL_AREA:0122/subSUB:SAPLHR_QUERY_APPL_AREA:0120/cmbDD_DATE").key = "4"
    session.findById(
        "wnd[0]/usr/subSUB_MAIN:SAPLAQ_ADHOC:0210/subSUB_SELECTION:SAPLAQ_ADHOC:0310/cntlSEL_DEF_CONTAINER/shellcont/shell").currentCellColumn = "MORE_ICON"
    session.findById(
        "wnd[0]/usr/subSUB_MAIN:SAPLAQ_ADHOC:0210/subSUB_SELECTION:SAPLAQ_ADHOC:0310/cntlSEL_DEF_CONTAINER/shellcont/shell").pressButtonCurrentCell()
    session.findById("wnd[1]/tbar[0]/btn[16]").press()


def export_party103(text, filename, type1=Party_C103):
    # 导出103表政治面貌和年度考核信息（全部）
    date = time.strftime("%Y%m%d", time.localtime(time.time()))
    numbers = '\r\n'.join(text)
    session = attach_sap()
    if not session:
        return False
    type1(session, date)
    pyperclip.copy(numbers)
    session.findById("wnd[1]/tbar[0]/btn[24]").press()
    session.findById("wnd[1]/tbar[0]/btn[8]").press()
    session.findById("wnd[0]/tbar[1]/btn[8]").press()
    string = session.findById("wnd[0]/sbar/pane[0]").text
    if string in ['系统不能读取任何值', '未找到命中']:
        return False
    if os.path.exists(filename):
        os.remove(filename)
    tb: AdTable = export_query(session, query_name='103表政治面貌和年度考核信息')
    tb.filename = os.path.splitext(os.path.split(filename)[-1])[0]
    tflag = tb.save_to(os.path.dirname(filename))
    session.findById("wnd[0]/tbar[0]/okcd").text = "/n"
    session.findById("wnd[0]").sendVKey(0)
    if session:
        close_sap()
    return tflag


def batch_import(fname):
    try:
        wb_form = load_workbook(fname)
        ws_form = wb_form["temp"]  # wb_form['政治面貌信息']
    except Exception as e:
        logging.error(f"过程数据文件打开失败!{e}")
        logger.error(f'过程数据文件打开失败!（{fname}）')
        return {}
    t = [str(x.value).strip() for x in ws_form['J'] if x.value][1:]
    t_dict = Counter(t)
    if t_dict['新增'] < 30:
        return {}
    try:
        wb_mb = load_workbook(os.path.join(templates, '0534_HR_BI_0534-政治面貌信息.xlsx'))
        ws_mb = wb_mb['0534_政治面貌信息']
    except Exception as e:
        print("0534模板文件打开失败!", e)
        logger.error('0534模板文件打开失败!（0534_HR_BI_0534-模板文件.xlsx）')
        return {}
    no = 1
    for i in range(2, ws_form.max_row + 1):
        if '新增' in ws_form[f'J{i}'].value:
            no += 1
            ws_mb[f'A{no + 5}'] = no - 1
            for cc in ['B', 'C', 'D', 'E', 'F', 'G', "H", 'I', 'J']:
                ws_mb[f'{cc}{no + 5}'] = ws_form[f'{cc}{i}'].value

    mb_file = os.path.splitext(fname)[0] + '_mb.xlsx'
    wb_mb.save(mb_file)
    wb_mb.close()
    wb_form.close()
    for i in range(10):
        session = attach_sap()
        session.findById("wnd[0]/tbar[0]/okcd").text = "/n zhrbi0013"
        session.findById("wnd[0]").sendVKey(0)
        session.findById("wnd[0]/usr/radRB_M_PA").select()
        session.findById("wnd[0]/tbar[1]/btn[8]").press()
        session.findById("wnd[0]/usr/ctxtP_SRTFD").text = '0534->HR_BI_0534'
        session.findById("wnd[0]/usr/radRB_UP").select()
        # fix_excel(file)
        t = Thread(target=click_continue)
        t.setDaemon(True)
        t.start()
        t = Thread(target=find_window1, args=(mb_file, '#32770', u'选择上传文件'))
        t.setDaemon(True)
        t.start()
        session.findById("wnd[0]/tbar[1]/btn[8]").press()
        try:
            result = session.findById("wnd[1]/usr/txtSPOP-TEXTLINE2").text
            session.findById("wnd[1]/usr/btnSPOP-OPTION1").press()
            if "失败0" in result:
                break
        except Exception:  # nosec
            pass
        if "没有需要处理的数据或数据错误" in session.findById("wnd[0]/sbar/pane[0]").text:
            logging.info(f'没有需要处理的数据,{i}次')
            logger.error(f'sap批导时没有需要处理的数据!第{i}次批导尝试')
            session.findById("wnd[0]").close()
            # return False
        if session.findById("wnd[0]/sbar/pane[0]").text not in ["上载的模板中没有数据或数据错误", "文件不符合要求"]:
            logging.info(f'模板中没有数据或数据错误,{i}次')
            logger.error(f'sap批导时没有需要处理的数据或数据错误!第{i}次批导尝试')
            session.findById("wnd[0]").close()
            # return False
        # session.findById("wnd[0]").close()
    else:
        os.rename(mb_file, mb_file[:-5] + "_批导失败" + ".xlsx")
        return {}

    session.findById("wnd[0]").close()
    # session.findById("wnd[0]/tbar[0]/okcd").text = "/nex"
    # session.findById("wnd[0]").sendVKey(0)
    logger.info('0534政治面貌模板批导成功！')

    try:
        wb_mb = load_workbook(mb_file)
        ws_mb = wb_mb['0534_政治面貌信息']
    except Exception as e:
        logging.error(f"0534模板文件打开失败!{e}")
        logger.error(f'0534模板文件打开失败!{mb_file}')
        return {}
    batches = defaultdict(str)  # 记录成功
    for i in range(7, ws_mb.max_row + 1):
        if ws_mb[f'J{i}'].value and '成功' in ws_mb[f'J{i}'].value:
            t0, t1 = str(ws_mb[f'B{i}'].value).strip(), str(ws_mb[f'F{i}'].value).strip()[:2]
            t = '0' * (8 - len(t0)) + t0 + t1
            batches[t] = 1
    # logging.info(batches)
    return batches


def sap_modify(fname, batches):
    wb = load_workbook(fname)
    ws = wb['temp']
    numbersform = [str(x.value) for x in ws['B'] if str(x.value) != 'None'][1:]
    text = '\r\n'.join(numbersform)
    try:
        session = attach_sap()
        session.findById("wnd[0]/tbar[0]/okcd").text = '/n pa30'
        session.findById("wnd[0]").sendVKey(0)
        temp = "wnd[0]/shellcont/shell/shellcont[0]/shell/shellcont[1]/shell[1]"
        session.findById(temp).clickLink("          2", "&Hierarchy")
        session.findById("wnd[1]/usr/tabsG_SELONETABSTRIP/tabpTAB002").select()
        pyperclip.copy(text)
        session.findById(
            "wnd[1]/usr/tabsG_SELONETABSTRIP/tabpTAB003/ssubSUBSCR_PRESEL:SAPLSDH4:0220/sub:SAPLSDH4:0220/btnG_SELFLD_TAB-MORE[4,56]").press()
        session.findById("wnd[2]/tbar[0]/btn[16]").press()
        session.findById("wnd[2]/tbar[0]/btn[24]").press()
        session.findById("wnd[2]/tbar[0]/btn[8]").press()
        session.findById("wnd[1]/tbar[0]/btn[0]").press()
        session.findById("wnd[0]/usr/tabsMENU_TABSTRIP/tabpTAB01").select()
        session.findById(
            "wnd[0]/usr/tabsMENU_TABSTRIP/tabpTAB01/ssubSUBSCR_MENU:SAPMP50A:0400/subSUBSCR_ITMENU:SAPMP50A:0310/tblSAPMP50ATC_MENU").getAbsoluteRow(
            3).selected = -1
        nRow = session.findById("wnd[0]/shellcont/shell/shellcont[1]/shell").RowCount
        temp = session.findById("wnd[0]/shellcont/shell/shellcont[1]/shell/")
        code = [temp.getCellValue(i, temp.columnOrder(0)) for i in range(nRow)]
        for i in range(2, ws.max_row + 1):
            t = [str(x.value).strip().replace('None', '') for x in ws[i]][1:10]
            t0 = '0' * (8 - len(t[0])) + t[0]
            tmp = t0 + t[4][:2]
            session.findById("wnd[0]/shellcont/shell/shellcont[1]/shell").setCurrentCell(int(code.index(t0)),
                                                                                         "ADD_FIELD2")
            session.findById("wnd[0]/shellcont/shell/shellcont[1]/shell").selectedRows = str(code.index(t0))
            session.findById("wnd[0]/shellcont/shell/shellcont[1]/shell").doubleClickCurrentCell()
            if i == 2:
                session.findById("wnd[0]/tbar[1]/btn[20]").press()  # 5 新建 6 编辑 14 删除 21复制  20浏览
            if '新增' in t[8] and tmp not in batches:
                # print(session.findById("wnd[0]/usr/tblMP053400TC3000").RowCount)
                # print(session.findById("wnd[0]/usr/tblMP053400TC3000").Rows(0).Selectable)
                # print(session.findById("wnd[0]/usr/tblMP053400TC3000/ctxtP0534-PCODE[2,0]").Text)
                # print(session.findById("wnd[0]/usr/tblMP053400TC3000").GetCell(0, 0).Text)
                session.findById("wnd[0]/tbar[1]/btn[5]").press()
                session.findById("wnd[0]/usr/ctxtP0534-BEGDA").text = t[2]
                session.findById("wnd[0]/usr/ctxtP0534-ENDDA").text = t[3]
                session.findById("wnd[0]/usr/cmbP0534-PCODE").key = t[4][:2]
                if t[5]:
                    session.findById("wnd[0]/usr/txtP0534-JOINU").text = t[5]
                if t[6]:
                    session.findById("wnd[0]/usr/txtP0534-INTR1").text = t[6]
                if t[7]:
                    session.findById("wnd[0]/usr/txtP0534-INTR2").text = t[7]
                session.findById("wnd[0]").sendVKey(0)  # 11保存 3 返回 15 退出 12 取消
                if '请保存你的输入' in session.findById("wnd[0]/sbar/pane[0]").text:
                    session.findById("wnd[0]/tbar[0]/btn[11]").press()

            elif '修改' in t[8]:
                for j in range(int(session.findById("wnd[0]/usr/txtRP50M-PAGEC").text) + 1):
                    if session.findById("wnd[0]/usr/tblMP053400TC3000").Rows(j).Selectable:
                        party_no = session.findById(f"wnd[0]/usr/tblMP053400TC3000/ctxtP0534-PCODE[2,{j}]").text
                        start_dt = session.findById(f"wnd[0]/usr/tblMP053400TC3000/txtP0534-BEGDA[0,{j}]").text
                        start_dt = to_yyyymmdd(start_dt)
                        if party_no == t[4][:2] or start_dt == t[2]:
                            session.findById("wnd[0]/usr/tblMP053400TC3000").getAbsoluteRow(j).selected = -1
                            session.findById("wnd[0]/tbar[1]/btn[6]").press()
                            session.findById("wnd[0]/usr/ctxtP0534-BEGDA").text = t[2]
                            session.findById("wnd[0]/usr/ctxtP0534-ENDDA").text = t[3]
                            session.findById("wnd[0]/usr/cmbP0534-PCODE").key = t[4][:2]
                            if t[5]:
                                session.findById("wnd[0]/usr/txtP0534-JOINU").text = t[5]
                            if t[6]:
                                session.findById("wnd[0]/usr/txtP0534-INTR1").text = t[6]
                            if t[7]:
                                session.findById("wnd[0]/usr/txtP0534-INTR2").text = t[7]
                            session.findById("wnd[0]").sendVKey(0)  # 11保存 3 返回 15 退出 12 取消
                            if '请保存你的输入' in session.findById("wnd[0]/sbar/pane[0]").text:
                                session.findById("wnd[0]/tbar[0]/btn[11]").press()
                            break
                        else:
                            continue

            elif '定界' in t[8]:
                for j in range(int(session.findById("wnd[0]/usr/txtRP50M-PAGEC").text) + 1):
                    if session.findById("wnd[0]/usr/tblMP053400TC3000").Rows(j).Selectable:
                        party_no = session.findById(f"wnd[0]/usr/tblMP053400TC3000/ctxtP0534-PCODE[2,{j}]").text
                        start_dt = session.findById(f"wnd[0]/usr/tblMP053400TC3000/txtP0534-BEGDA[0,{j}]").text
                        if party_no == t[4][:2] and start_dt.replace('.', '') == t[2]:
                            session.findById("wnd[0]/usr/tblMP053400TC3000").getAbsoluteRow(j).selected = -1
                            session.findById("wnd[0]/tbar[1]/btn[6]").press()
                            # session.findById("wnd[0]/usr/ctxtP0534-BEGDA").text = t[2]
                            tmp = session.findById("wnd[0]/usr/ctxtP0534-ENDDA").text
                            if tmp.strip().replace('.', '') != t[3]:
                                session.findById("wnd[0]/usr/ctxtP0534-ENDDA").text = t[3]
                                # session.findById("wnd[0]/usr/cmbP0534-PCODE").key = t[4][:2]
                                if t[5]:
                                    session.findById("wnd[0]/usr/txtP0534-JOINU").text = t[5]
                                if t[6]:
                                    session.findById("wnd[0]/usr/txtP0534-INTR1").text = t[6]
                                if t[7]:
                                    session.findById("wnd[0]/usr/txtP0534-INTR2").text = t[7]
                                session.findById("wnd[0]").sendVKey(0)  # 11保存 3 返回 15 退出 12 取消
                                if '请保存你的输入' in session.findById("wnd[0]/sbar/pane[0]").text:
                                    session.findById("wnd[0]/tbar[0]/btn[11]").press()
                            break
                        else:
                            continue
            elif '删除' in t[8]:
                for j in range(int(session.findById("wnd[0]/usr/txtRP50M-PAGEC").text) + 1):
                    if session.findById("wnd[0]/usr/tblMP053400TC3000").Rows(j).Selectable:
                        party_no = session.findById(f"wnd[0]/usr/tblMP053400TC3000/ctxtP0534-PCODE[2,{j}]").text
                        start_dt = session.findById(f"wnd[0]/usr/tblMP053400TC3000/txtP0534-BEGDA[0,{j}]").text
                        if party_no == t[4][:2] and to_yyyymmdd(start_dt) == t[2]:
                            session.findById("wnd[0]/usr/tblMP053400TC3000").getAbsoluteRow(j).selected = -1
                            session.findById("wnd[0]/tbar[1]/btn[14]").press()
                            session.findById("wnd[0]/tbar[1]/btn[14]").press()
                            break
                        else:
                            continue

        session.findById("wnd[0]/tbar[0]/okcd").text = "/n"
        session.findById("wnd[0]").sendVKey(0)
        return True
    except Exception:
        return False


def check_result2(fname, result_103):
    # 导出结果检查-增加事后多条记录逻辑检查
    sap_datas = defaultdict(dict)
    try:
        wb_sap = load_workbook(result_103)
        ws_sap = wb_sap.active  # ["Sheet1"]
    except Exception as e:
        logging.error(f"事后103表文件打开失败!{e}")
        return False
    for i in range(2, ws_sap.max_row + 1):
        t = [str(x.value).strip().replace('None', '') for x in ws_sap[i]]
        t1 = [t[2][:10].replace('.', ''), t[3][:10].replace('.', '')]
        t0, t2 = re.sub(r'^0+(?!$)', '', t[0]), f'{t[6].strip()} {t[7].strip()}'
        if not t0 or not t2 or t1[0] == '00000000':
            continue
        if t0 not in sap_datas:
            sap_datas[t0] = dict({t[1]: dict({t2: t1})})
        elif t[1] not in sap_datas[t0]:
            sap_datas[t0][t[1]] = dict({t2: t1})
        elif t2 not in sap_datas[t0][t[1]]:
            sap_datas[t0][t[1]][t2] = t1
    wb_sap.close()

    try:
        wb_form = load_workbook(fname)
        ws_form = wb_form['temp']  # wb_form["Sheet1"]
    except Exception as e:
        logging.error(f"企业表单文件打开失败!{e}")
        return False
    for i in range(2, ws_form.max_row + 1):
        sap2 = 0
        t = [str(x.value).strip().replace('None', '') for x in ws_form[i]]
        t2, t3 = t[3][:10].replace('-', ''), t[4][:10].replace('-', '')
        t0, t1, t5 = re.sub(r'^0+(?!$)', '', t[1]), t[2], t[5].strip()
        if t5 not in sap_datas[t0][t1].keys():
            ws_form[f'K{i}'] = "处理未成功"
            ws_form[f'F{i}'].fill = PatternFill(fill_type='solid', fgColor='FF0000')
        elif t2 != sap_datas[t0][t1][t5][0]:
            ws_form[f'K{i}'] = "开始日期未成功"
            ws_form[f'D{i}'].fill = PatternFill(fill_type='solid', fgColor='FF0000')
        elif t3 != sap_datas[t0][t1][t5][1]:
            ws_form[f'K{i}'] = "结束日期未成功"
            ws_form[f'E{i}'].fill = PatternFill(fill_type='solid', fgColor='FF0000')
        for k, v in sap_datas[t0][t1].items():
            if logic_test(t5, t2, k, v[0]):
                ws_form[f'K{i}'] = "数据逻辑错误,请检查"
                break
            if v[1] == '99991231':
                sap2 += 1
        if sap2 > 1:
            fill_notes(ws_form[f'B{i}'], '有多条当前记录！', RED)

    wb_form.save(fname)
    wb_form.close()
    logger.info(f'事后结果检查完成，请在{fname}中【temp】检查！')
    return True


def check_result(fname, result_103):
    # 导出结果检查
    sap_datas = defaultdict(int)
    sap2 = defaultdict(int)
    try:
        wb_sap = load_workbook(result_103)
        ws_sap = wb_sap.active  # ["Sheet1"]
    except Exception as e:
        logging.error(f"事后103表文件打开失败!{e}")
        logger.error('导出事后103表打开失败！')
        return False
    for i in range(2, ws_sap.max_row + 1):
        t = [str(x.value).strip().replace('None', '') for x in ws_sap[i]]
        t2, t3 = t[2][:10].replace('-', '').replace('.', ''), t[3][:10].replace('-', '').replace('.', '')
        t0, t1 = re.sub(r'^0+(?!$)', '', t[0]), t[6]
        t_all = ''.join((t0, t2, t3, t1))
        if t_all not in sap_datas:
            sap_datas[t_all] = 1
        if t0 in sap2 and t3 == '99991231':
            sap2[t0] += 1
        if t0 not in sap2 and t3 == '99991231':
            sap2[t0] = 0

    wb_sap.close()
    try:
        wb_form = load_workbook(fname)
        ws_form = wb_form['temp']  # wb_form["Sheet1"]
    except Exception as e:
        logging.error(f"企业表单文件打开失败!{e}")
        logger.error('企业表单文件打开失败！')
        return False
    for i in range(2, ws_form.max_row + 1):
        t = [str(x.value).strip().replace('None', '') for x in ws_form[i]]
        t2, t3 = t[3][:10].replace('-', ''), t[4][:10].replace('-', '')
        t0, t1 = re.sub(r'^0+(?!$)', '', t[1]), t[5].strip()[:2]
        t_all = ''.join((t0, t2, t3, t1))
        # logging.info(f'{t_all},{sap2}')
        if t_all not in sap_datas.keys():
            ws_form[f'K{i}'] = "未成功,请检查"
            ws_form[f'F{i}'].fill = PatternFill(fill_type='solid', fgColor='FF0000')
        if sap2[t0] > 0 and t3 == '99991231':
            fill_notes(ws_form[f'B{i}'], '有多条当前记录！', RED)

    wb_form.save(fname)
    wb_form.close()
    logger.info(f'事后结果检查完成，请在{fname}中【temp】检查！')
    return True


def str_to_date(str_date):
    '''校验字符串日期是否合法有效'''
    try:
        date = datetime.strptime(str_date, "%Y%m%d")
        return date
    except Exception:  # nosec
        return


def file_archive(filename: str, is_succ: bool, ctype='政治面貌'):
    '''is_succ 成功失败标识  ctype业务类型标识 政治面貌 年度考核 离岗 不在岗变动etc'''
    logging.info(f"文件路径：{filename}")
    temp_dir, fname = os.path.split(filename)
    temp_dir, fname = temp_dir.replace('/', '\\'), fname[:-5]
    date = time.strftime("%Y%m%d %H%M%S", time.localtime(time.time()))
    yyyymm, (yyyymmdd, hhmmss) = date[:6], date.split()
    tmpstr = f"{ctype}/{yyyymm}/{yyyymmdd}/{hhmmss}_{fname}_{'成功' if is_succ else '失败'}"
    flag = '信息维护/' if ctype in ['政治面貌', '年度考核'] else ('其他事件/' if ctype not in ['离岗', '不在岗变动', '年金'] else '')
    work_path = f'{rpa.config.D_RPA}/HR人事/{flag}{tmpstr}/'
    if not os.path.exists(work_path.replace("/", "\\")):
        os.makedirs(work_path.replace("/", "\\"), exist_ok=True)
    for file in os.listdir(temp_dir):
        if "query_string.txt" not in file:
            shutil.move(fr"{temp_dir}\\{file}", work_path.replace("/", "\\"))
    remote = work_path[6:]
    try:
        with MYFTP() as ftp:
            ftp.rmd(remote)
            ftp.upload_file_tree(work_path, remote)
    except Exception as e:
        logging.error(f'上传FTP失败！错误提示：{e}')
    shutil.rmtree(temp_dir)


# def get_work_path(filename, ctype='政治面貌'):
#     fname = os.path.splitext(os.path.basename(filename))[0]
#     date = time.strftime("%Y%m%d %H%M%S", time.localtime(time.time()))
#     yyyymm, (yyyymmdd, hhmmss) = date[:6], date.split()
#     if ctype in ['离岗', '不在岗变动','年金']:
#         work_path = f"{rpa.config.D_RPA}/HR人事/{ctype}/{yyyymm}/{yyyymmdd}/{hhmmss}_{fname}/"
#     elif ctype in ['政治面貌', '年度考核']:
#         work_path = f'{rpa.config.D_RPA}/HR人事/信息维护/{ctype}/{yyyymm}/{yyyymmdd}/{hhmmss}_{fname}/'
#     else:
#         work_path = f'{rpa.config.D_RPA}/HR人事/其他事件/{ctype}/{yyyymm}/{yyyymmdd}/{hhmmss}_{fname}/'
#     wotk_path = f'{work_path}'.replace("/", "\\")
#     if not os.path.exists(wotk_path): os.makedirs(wotk_path, exist_ok=True)
#     return work_path
#
#
# def uploadFtp(filename: str, is_succ: bool, ctype='政治面貌'):
#     '''is_succ 成功失败标识  ctype业务类型标识 政治面貌 年度考核 离岗 不在岗变动etc'''
#     remote_xx_path = filename.replace('\\', '/')[6:-5]
#     result_dir = os.path.dirname(filename).replace('\\', '/')
#     remote = f"{remote_xx_path}_{'成功' if is_succ else '失败'}"
#     try:
#         with MYFTP() as ftp:
#             ftp.rmd(remote)
#             ftp.upload_file_tree(result_dir, remote)
#     except Exception as e:
#         logging.error(f'上传FTP失败！错误提示：{e}')


def ftp_tasks():
    remote_zzmm = '/HR人事/待办/政治面貌/'
    return_file = None
    with MYFTP() as my_ftp:
        files = my_ftp.get_all_files(remote_zzmm)
        # logging.info(files)
        date = time.strftime("%Y%m%d %H:%M", time.localtime(time.time()))
        for file in files:
            filename = file.replace('政治面貌/', "")
            filepath, extname = f"{rpa.config.RPA_TEMP_DIR}/{date.split()[0]}/" + os.path.splitext(filename)[0], \
                                os.path.splitext(filename)[1]
            if extname.lower() == '.xlsx':
                if not os.path.exists(filepath):
                    os.makedirs(filepath)
                if not my_ftp.is_same_size(filepath + f'/{filename}',  # pylint: disable=fixme, no-member
                                           remote_zzmm + f'{filename}'):  # pylint: disable=fixme, no-member
                    my_ftp.download_file(filepath + f'/{filename}', remote_zzmm + f'{filename}')
                if judge(filepath + f'/{filename}', '政治面貌信息'):
                    # Insert(sr=sr, code=code, date=date, step=state, content=content, worker='', comment=comment,
                    #        people_num=count, remark='RPA', zubie='', mjml=text, start_time=date_time, ctype="手动执行")
                    return_file = filepath + f'/{filename}'
    return return_file


def fill_notes(cell, note, color):
    """插入单元格底色并加批注  red->"FF0000" blue->"63B8FF"  """
    # color1 = "FF0000" if color == "RED" else "63B8FF"
    cell.fill = PatternFill(fill_type='solid', fgColor=color)
    cell.comment = Comment(note, 'RPA_XX')


def clear_comments_backgrand(fname, header=7):
    """清除EXCEL文件单元格背景和批注，header -> 表头行数"""
    # 用Win32com实现
    # try:
    #     xl = Dispatch('Excel.Application')
    #     wb = xl.Workbooks.Open(fname)
    #     ws = wb.ActiveSheet
    #     wsRange = ws.Range(f"{row}:{ws.Rows.Count}")
    #     wsRange.ClearComments()  # 清除批注
    #     wsRange.Interior.Pattern = -4142  # 清除背景色
    #     wb.Save()
    #     wb.Close()
    # except Exception as e:
    #     logging.error(f'清除背景和批注失败,错误原因：”{e}“')
    # finally:
    #     if xl: xl.Quit()
    # 用Openpyxl实现
    try:
        wb = load_workbook(fname)
        ws = wb.active  # wb['sheet_name']
        edsel = get_column_letter(ws.max_column)
        for cells in ws[f'A{header}:{edsel}{ws.max_column}']:
            for cell in cells:
                cell.fill = PatternFill(fill_type=None)
                if cell.comment:
                    cell.comment = None
        ws[f'{edsel}1'].comment = Comment('标识位勿删', '')  # 修正openpyxl3.0.6以下版本Bug
        wb.save(fname)
        wb.close()
    except Exception as e:
        logging.error(f'清除背景和批注失败,错误原因：”{e}“')


def trans_date(text):
    dp = DateParser()
    return dp.convert(str(text), "%Y%m%d")


def trans_flag(text):
    dp = DateParser()
    return all(dp.parse(str(text))[1]) if dp.parse(str(text)) is not None else None


def trans_h(text):
    dp = DateParser()
    return dp.date_ago(str(text))


def trans_comp(text1, text2):
    dp = DateParser()
    return dp.date_cmp2(str(text1), str(text2))


def trans_mb(text, st_dict, st_list):
    text = str(text).strip()
    text = st_dict.get(text, text)
    # for k, v in st_dict.items():
    #     if k == text: text = v; break
    for st in st_list:
        if text in st:
            return st
    return None


@logger.catch
def logic_test(t0, t1, st0, st1):
    st_l1 = ['01 中共党员', '02 中共预备党员', '03 共青团员']  # todo 共青团员??
    st_l2 = ['04 民革会员', '05 民盟盟员', '06 民建会员', '07 民进会员', '08 农工党党员', '09 致公党党员',
             '10 九三学社社员', '11 台盟盟员', '12 无党派民主人士']
    flag = (t0 == '01 中共党员' and ((st1 >= t1 or trans_comp(st1, t1) < 365) and st0 == '02 中共预备党员')) \
        or (t0 == '02 中共预备党员' and ((st1 <= t1 or trans_comp(st1, t1) < 365) and st0 == '01 中共党员')) \
        or (t0 == '03 共青团员' and st1 <= t1 and (st0 == '02 中共预备党员' or st0 == '01 中共党员')) \
        or (t0 in st_l1 and st0 in st_l2) or (st0 in st_l1 and t0 in st_l2) \
        or (t0 != st0 and t1 == st1)  # and (st0 != '13 群众' or t0 != '13 群众'))
    return flag


def judge(mb_file, text):
    wb = load_workbook(mb_file)  # , read_only=True)
    ws = wb.active
    str1 = ws['A1'].value
    wb.close()
    return text in str1


def find_window1(file_path, classs, text):
    find_window(file_path, classs, text)
    time.sleep(1)
    click_allow()
    time.sleep(1)
    click_allow()


def translate(filename, data):
    if not data or '-' * 10 not in data:
        logging.error('保存文件失败！')
        logger.error('SAP组合逻辑查询导出文件保存失败！')
        return False
    if os.path.exists(filename):
        if os.path.exists(f'{os.path.splitext(filename)[0]}_f.xlsx'):
            os.remove(f'{os.path.splitext(filename)[0]}_f.xlsx')
        os.rename(filename, f'{os.path.splitext(filename)[0]}_f.xlsx')
    wb = Workbook()
    ws = wb.active
    ws.title = 'Sheet1'
    header_names, contents = parse_query_string(data)
    ws.append(header_names)
    for cts in contents:
        ws.append(cts)
    wb.save(filename)
    wb.close()
    logger.info('文件保存完成，文件路径：' + filename)
    return True


def updateDB(file, numbers, step='开始执行'):
    fname = os.path.basename(file)
    sr, code, comment, worker = fname.split('-')
    worker = worker.split('.')[0]
    for k, v in {'离岗': 'LG', '不在岗变动': 'BZG', '政治面貌': 'ZM', '年度考核': 'KH'}.items():
        if k in comment:
            sr = f'{sr}-{v}'
            break
    date = time.strftime("%Y%m%d %H:%M:%S", time.localtime(time.time()))
    if not [res.sr for res in Query(table=RZLog, sr=sr)]:
        Insert(table=RZLog, sr=sr, code=code, content=fname, comment=comment,
               date=date[:8], people_num=numbers, step=step, worker=worker)
    else:
        Update(table=RZLog, sr=sr, result=date, step=step)


# def clipboard_get():  # """获取剪贴板数据"""
#     win32clipboard.OpenClipboard()
#     data = win32clipboard.GetClipboardData()
#     win32clipboard.CloseClipboard()
#     return data
#
#
# def clipboard_set(data):  # """设置剪贴板数据"""
#     win32clipboard.OpenClipboard()
#     win32clipboard.SetClipboardData(13, data)
#     win32clipboard.CloseClipboard()
#     return True
