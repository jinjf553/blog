#!/usr/bin/env python
# -*- coding: utf-8 -*-
# @File    : check_card.py
# @Author  : jinjianfeng
# @Contact : 553041800@qq.com
# @Link    : https://github.com/jinjf553
# @software: PyCharm
# @Date    : 2019/10/8 9:55
# @Version : ??
from rpa.fastrpa.sap.session import attach_sap


def more_icon(session, date: str, key='8', end_date="99991231"):
    if date != '':
        if isinstance(date, float):
            date = int(date)
        if isinstance(date, str) is False:
            date = str(date)
        if date.isdigit() is False or end_date.isdigit() is False:
            raise Exception(f'组合逻辑查询日期必须为纯数字，当前值：{date}')
    sap_id = "wnd[0]/usr/subSUB_MAIN:SAPLAQ_ADHOC:0210/subSUB_APPLICATION:SAPLHR_QUERY_APPL_AREA:0122/subSUB:SAPLHR_QUERY_APPL_AREA:0121/btnDYNP121-EVALUATION_PERIOD_TEXT"
    sap_id1 = "wnd[0]/usr/subSUB_MAIN:SAPLAQ_ADHOC:0210/subSUB_APPLICATION:SAPLHR_QUERY_APPL_AREA:0122/subSUB:SAPLHR_QUERY_APPL_AREA:0120/cmbDD_DATE"
    sap_id2 = "wnd[0]/usr/subSUB_MAIN:SAPLAQ_ADHOC:0210/subSUB_APPLICATION:SAPLHR_QUERY_APPL_AREA:0122/subSUB:SAPLHR_QUERY_APPL_AREA:0120/ctxtG_APPL_AREA-BEGDA"
    sap_id3 = "wnd[0]/usr/subSUB_MAIN:SAPLAQ_ADHOC:0210/subSUB_SELECTION:SAPLAQ_ADHOC:0310/cntlSEL_DEF_CONTAINER/shellcont/shell"
    sap_id4 = "wnd[0]/usr/subSUB_MAIN:SAPLAQ_ADHOC:0210/subSUB_APPLICATION:SAPLHR_QUERY_APPL_AREA:0122/subSUB:SAPLHR_QUERY_APPL_AREA:0120/ctxtG_APPL_AREA-ENDDA"
    session.findById(sap_id).press()
    if key == "7" and date:
        session.findById(sap_id1).key = key
        session.findById(sap_id2).text = date  # 关键日期
    elif key == "8" and date and end_date:
        session.findById(sap_id1).key = key
        session.findById(sap_id2).text = date  # 开始日期
        session.findById(sap_id4).text = end_date
    session.findById(sap_id3).currentCellColumn = "MORE_ICON"
    session.findById(sap_id3).pressButtonCurrentCell()


def _C103_card(session):
    session.findById("wnd[0]").maximize()
    session.findById("wnd[0]/tbar[0]/okcd").text = "/n S_PH0_48000513"
    session.findById("wnd[0]").sendVKey(0)
    session.findById("wnd[1]/usr/cmbDYNP4100-DD_WORKSPACE").setFocus()
    session.findById("wnd[1]/usr/cmbDYNP4100-DD_WORKSPACE").key = "2"
    session.findById("wnd[1]/usr/cmbDYNP4100-DD_USERGROUP").setFocus()
    session.findById("wnd[1]/usr/cmbDYNP4100-DD_USERGROUP").key = "103"
    session.findById("wnd[1]/usr/tblSAPLAQ_INT_FUNCTIONSTCH_FUNCAREAS").getAbsoluteRow(1).selected = -1
    session.findById("wnd[1]/usr/tblSAPLAQ_INT_FUNCTIONSTCH_FUNCAREAS/txtDYNP4100_TC_FUNCAREAS-NAME[0,1]").setFocus()
    session.findById(
        "wnd[1]/usr/tblSAPLAQ_INT_FUNCTIONSTCH_FUNCAREAS/txtDYNP4100_TC_FUNCAREAS-NAME[0,1]").caretPosition = 0
    session.findById("wnd[1]/tbar[0]/btn[0]").press()
    session.findById("wnd[0]/shellcont[1]/shell/shellcont[0]/shell/shellcont[1]/shell[1]").expandNode("          2")
    session.findById("wnd[0]/shellcont[1]/shell/shellcont[0]/shell/shellcont[1]/shell[1]").topNode = "          1"
    session.findById("wnd[0]/shellcont[1]/shell/shellcont[0]/shell/shellcont[1]/shell[1]").selectItem("          3",
                                                                                                      "C          4")
    session.findById("wnd[0]/shellcont[1]/shell/shellcont[0]/shell/shellcont[1]/shell[1]").ensureVisibleHorizontalItem(
        "          3", "C          4")
    session.findById("wnd[0]/shellcont[1]/shell/shellcont[0]/shell/shellcont[1]/shell[1]").itemContextMenu(
        "          3", "C          4")
    session.findById("wnd[0]/shellcont[1]/shell/shellcont[0]/shell/shellcont[1]/shell[1]").selectContextMenuItem(
        "OUTPUT_BOTH")
    session.findById("wnd[0]/shellcont[1]/shell/shellcont[0]/shell/shellcont[1]/shell[1]").expandNode("          4")
    session.findById("wnd[0]/shellcont[1]/shell/shellcont[0]/shell/shellcont[1]/shell[1]").topNode = "          1"
    session.findById("wnd[0]/shellcont[1]/shell/shellcont[0]/shell/shellcont[1]/shell[1]").selectItem("         12",
                                                                                                      "C          4")
    session.findById("wnd[0]/shellcont[1]/shell/shellcont[0]/shell/shellcont[1]/shell[1]").ensureVisibleHorizontalItem(
        "         12", "C          4")
    session.findById("wnd[0]/shellcont[1]/shell/shellcont[0]/shell/shellcont[1]/shell[1]").itemContextMenu(
        "         12", "C          4")
    session.findById("wnd[0]/shellcont[1]/shell/shellcont[0]/shell/shellcont[1]/shell[1]").selectContextMenuItem(
        "OUTPUT_BOTH")
    session.findById("wnd[0]/shellcont[1]/shell/shellcont[0]/shell/shellcont[1]/shell[1]").expandNode("         19")
    session.findById("wnd[0]/shellcont[1]/shell/shellcont[0]/shell/shellcont[1]/shell[1]").topNode = "          1"
    session.findById("wnd[0]/shellcont[1]/shell/shellcont[0]/shell/shellcont[1]/shell[1]").selectItem("         28",
                                                                                                      "C          4")
    session.findById("wnd[0]/shellcont[1]/shell/shellcont[0]/shell/shellcont[1]/shell[1]").ensureVisibleHorizontalItem(
        "         28", "C          4")
    session.findById("wnd[0]/shellcont[1]/shell/shellcont[0]/shell/shellcont[1]/shell[1]").topNode = "          3"
    session.findById("wnd[0]/shellcont[1]/shell/shellcont[0]/shell/shellcont[1]/shell[1]").itemContextMenu(
        "         28", "C          4")
    session.findById("wnd[0]/shellcont[1]/shell/shellcont[0]/shell/shellcont[1]/shell[1]").selectContextMenuItem(
        "OUTPUT_BOTH")
    session.findById("wnd[0]/shellcont[1]/shell/shellcont[0]/shell/shellcont[1]/shell[1]").selectItem("         29",
                                                                                                      "C          4")
    session.findById("wnd[0]/shellcont[1]/shell/shellcont[0]/shell/shellcont[1]/shell[1]").ensureVisibleHorizontalItem(
        "         29", "C          4")
    session.findById("wnd[0]/shellcont[1]/shell/shellcont[0]/shell/shellcont[1]/shell[1]").itemContextMenu(
        "         29", "C          4")
    session.findById("wnd[0]/shellcont[1]/shell/shellcont[0]/shell/shellcont[1]/shell[1]").selectContextMenuItem(
        "OUTPUT_BOTH")
    session.findById("wnd[0]/shellcont[1]/shell/shellcont[0]/shell/shellcont[1]/shell[1]").selectItem("         32",
                                                                                                      "C          4")
    session.findById("wnd[0]/shellcont[1]/shell/shellcont[0]/shell/shellcont[1]/shell[1]").ensureVisibleHorizontalItem(
        "         32", "C          4")
    session.findById("wnd[0]/shellcont[1]/shell/shellcont[0]/shell/shellcont[1]/shell[1]").itemContextMenu(
        "         32", "C          4")
    session.findById("wnd[0]/shellcont[1]/shell/shellcont[0]/shell/shellcont[1]/shell[1]").selectContextMenuItem(
        "OUTPUT_BOTH")
    session.findById("wnd[0]/shellcont[1]/shell/shellcont[0]/shell/shellcont[1]/shell[1]").expandNode("        160")
    session.findById("wnd[0]/shellcont[1]/shell/shellcont[0]/shell/shellcont[1]/shell[1]").topNode = "         50"
    session.findById("wnd[0]/shellcont[1]/shell/shellcont[0]/shell/shellcont[1]/shell[1]").selectItem("        166",
                                                                                                      "C          4")
    session.findById("wnd[0]/shellcont[1]/shell/shellcont[0]/shell/shellcont[1]/shell[1]").ensureVisibleHorizontalItem(
        "        166", "C          4")
    session.findById("wnd[0]/shellcont[1]/shell/shellcont[0]/shell/shellcont[1]/shell[1]").topNode = "         53"
    session.findById("wnd[0]/shellcont[1]/shell/shellcont[0]/shell/shellcont[1]/shell[1]").itemContextMenu(
        "        166", "C          4")
    session.findById("wnd[0]/shellcont[1]/shell/shellcont[0]/shell/shellcont[1]/shell[1]").selectContextMenuItem(
        "OUTPUT_ONLYVALUE")
    session.findById("wnd[0]/shellcont[1]/shell/shellcont[0]/shell/shellcont[1]/shell[1]").selectItem("        166",
                                                                                                      "C          3")
    session.findById("wnd[0]/shellcont[1]/shell/shellcont[0]/shell/shellcont[1]/shell[1]").ensureVisibleHorizontalItem(
        "        166", "C          3")
    session.findById("wnd[0]/shellcont[1]/shell/shellcont[0]/shell/shellcont[1]/shell[1]").changeCheckbox("        166",
                                                                                                          "C          3",
                                                                                                          -1)
    session.findById("wnd[0]/shellcont[1]/shell/shellcont[0]/shell/shellcont[1]/shell[1]").selectItem("         31",
                                                                                                      "C          4")
    session.findById("wnd[0]/shellcont[1]/shell/shellcont[0]/shell/shellcont[1]/shell[1]").ensureVisibleHorizontalItem(
        "         31", "C          4")
    session.findById("wnd[0]/shellcont[1]/shell/shellcont[0]/shell/shellcont[1]/shell[1]").topNode = "         10"
    session.findById("wnd[0]/shellcont[1]/shell/shellcont[0]/shell/shellcont[1]/shell[1]").itemContextMenu(
        "         31", "C          4")
    session.findById("wnd[0]/shellcont[1]/shell/shellcont[0]/shell/shellcont[1]/shell[1]").selectContextMenuItem(
        "OUTPUT_BOTH")
    more_icon(session, "")
    session.findById("wnd[1]/tbar[0]/btn[16]").press()
