import os
from collections import defaultdict

from openpyxl import load_workbook
from openpyxl.comments import Comment
from openpyxl.styles import PatternFill
from rpa.fastrpa.adtable import BLUE, RED
from rpa.public.config import user_name
from rpa.public.tools import cel, cells
from rpa.ssc.hr.orm.orm_ope import DbSession
from rpa.ssc.hr.orm.tb_hr_ruzhi_log_detail import RZLog_detail
from rpa.ssc.hr.orm.td_hr_gang_wei_diao_pei_rulebase import Event


def add_color_comment(cell, color, message, result_dict):
    cell.fill = PatternFill(fill_type='solid', fgColor=color)
    result_dict.append(f'[{cell.coordinate}]{message}')
    comment = cell.comment.text if cell.comment else ""
    message = message + "\r\n" + comment
    cell.comment = Comment(message, "Robot")


def check_103(file, file_103, file_1071, file_1072):
    sr = os.path.basename(file)[:10] if os.path.basename(file)[:10].isdigit() else None
    username, password = user_name()
    wb_mb = load_workbook(file)
    ws_mb = wb_mb.active
    lis = ["CM", "CQ", "CO", "N", "CE", "CF"]
    dict_mb = {str(ws_mb[f"E{x}"].value).lstrip("0"): {y: str(ws_mb[f"{y}{x}"].value).strip() for y in lis}
               for x in range(7, len(ws_mb["B"]) + 1)}
    wb_mb.close()

    wb_103 = load_workbook(file_103)
    ws_103 = wb_103.active

    wb_1071 = load_workbook(file_1071)
    ws_1071 = wb_1071.active
    dict_1071 = {str(ws_1071[f"A{x}"].value).lstrip("0") + str(ws_1071[f"B{x}"].value).strip():
                 {"P": str(ws_1071[f"P{x}"].value).strip(), "Z": str(ws_1071[f"Z{x}"].value).strip()}
                 for x in range(2, len(ws_1071["A"]) + 1)}

    wb_1072 = load_workbook(file_1072)
    ws_1072 = wb_1072.active
    dict_1072 = {str(ws_1072[f"A{x}"].value).lstrip("0"): {"G": str(ws_1072[f"G{x + 1}"].value).strip(),
                                                           "H": str(ws_1072[f"H{x}"].value).strip()}
                 for x in range(1, len(ws_1072["A"])) if "S" in ws_1072[f"B{x}"].value}
    wb_1072.close()

    result = defaultdict(list)
    # if len(ws_mb["B"]) - 7 != len(ws_103["A"]) - 2:
    #     cells(ws_103, "A2", "有入职人员可能未生成人员编号，请检查确认入职模板DA列数据", RED)
    for i in range(2, len(ws_103["A"]) + 1):
        i, personnel_code = str(i), "0" * (8 - len(str(ws_103[f"A{i}"].value))) + str(ws_103[f"A{i}"].value)
        # 1.事件是否执行成功
        if ws_103[f"H{i}"].value is None or ws_103[f"G{i}"].value is None:
            add_color_comment(ws_103[f"G{i}"], RED, "请检查此人员入职是否成功！", result[personnel_code])

        # 2. 人员组
        if ws_103[f"S{i}"].value in ('K', 'N', 'S'):
            add_color_comment(ws_103[f"S{i}"], RED, "请检查人员组！", result[personnel_code])
        elif ws_103[f"S{i}"].value not in ('A', 'B', 'C'):
            add_color_comment(ws_103[f"S{i}"], BLUE, "请核对人员组！", result[personnel_code])

        # 3.人员子组
        t, av, s1, s2, s3 = ws_103[f"T{i}"].value, ws_103[f"AV{i}"].value, '管理序列', '专业技术序列', '技能操作序列'
        if (t in ('12', '13') and s1 not in av) or (t == '15' and s2 not in av) or (t in ('16', '17') and s3 not in av):
            add_color_comment(ws_103[f"T{i}"], RED, "人员子组和职位序列不匹配！", result[personnel_code])

        # 4.工资核算范围
        if None in [x.value for x in ws_103[f"P{i}:T{i}"][0]] + [ws_103[f"Z{i}"].value]:
            add_color_comment(ws_103[f"Z{i}"], RED, "请检查工资核算范围！", result[personnel_code])
        elif "00" in ws_103[f"Z{i}"].value:
            add_color_comment(ws_103[f"Z{i}"], BLUE, "请检查工资核算范围！", result[personnel_code])
        else:
            with DbSession() as sess:
                res = sess.query(Event).filter(Event.db_AA == ws_103[f"P{i}"].value,
                                               Event.db_AB == (str(ws_103[f"Q{i}"].value) + ' ' + str(
                                                   ws_103[f"R{i}"].value)).strip(),
                                               Event.db_AC.like(f'%{ws_103[f"S{i}"].value}%'),
                                               Event.db_AD.like(f'%{ws_103[f"T{i}"].value}%'),
                                               Event.db_AE == ws_103[f"Z{i}"].value).first()
                if not res:
                    add_color_comment(ws_103[f"Z{i}"], RED, "请检查工资核算范围！", result[personnel_code])

        # 5 从事职业（工种）信息
        if '技能操作序列' in str(ws_103[f"AV{i}"].value) and not (
                ws_103[f"BT{i}"].value == ws_103[f"C{i}"].value and str(ws_103[f"BU{i}"].value) == '9999.12.31'):
            add_color_comment(ws_103[f"BU{i}"], RED, "请检查职业工种信息！", result[personnel_code])
        if '技能操作序列' not in str(ws_103[f"AV{i}"].value) and str(ws_103[f"BU{i}"].value) == '9999.12.31':
            add_color_comment(ws_103[f"BU{i}"], RED, "请检查职业工种信息！", result[personnel_code])

        # 6.入职时间
        for k, v in {"L": "M", "AR": "AS", "CB": "CC", "BT": "BU"}.items():
            if ws_103[f"C{i}"].value != ws_103[f"{k}{i}"].value:
                add_color_comment(ws_103[f"{k}{i}"], RED, "请检查事件开始日期！", result[personnel_code])
            if ws_103[f"D{i}"].value != ws_103[f"{v}{i}"].value:
                add_color_comment(ws_103[f"{v}{i}"], RED, "请检查事件结束日期！", result[personnel_code])

        # 7.兼任职务标识
        if "是" in str(ws_103[f"AZ{i}"].value) and None in [x.value for x in ws_103[f"BA{i}:BC{i}"][0]]:
            add_color_comment(ws_103[f"BA{i}"], RED, "请检查兼任职务信息！", result[personnel_code])
        if "否" in str(ws_103[f"AZ{i}"].value) and None not in [x.value for x in ws_103[f"BA{i}:BC{i}"][0]]:
            add_color_comment(ws_103[f"BA{i}"], RED, "请检查兼任职务信息！", result[personnel_code])

        # 8.机构名称
        code = str(ws_103[f"X{i}"].value).lstrip("0")
        if code in dict_1072.keys() and code in dict_mb.keys() and (dict_1072[code]["G"] not in dict_mb[code][
                "CM"] and str(dict_mb[code]["CM"]).strip() not in str(ws_103[f"W{i}"].value)):
            add_color_comment(ws_103[f"W{i}"], RED, f'"模板信息："{dict_mb[code]["CM"], dict_1072[code]["G"]}',
                              result[personnel_code])

        # 9.岗位名称
        if code in dict_1072.keys() and dict_1072[code]["H"] != str(ws_103[f"Y{i}"].value).strip():
            add_color_comment(ws_103[f"Y{i}"], RED, f'\"岗位信息：\"{dict_1072[code]["H"]}', result[personnel_code])

        # 10.工种
        if code in dict_mb.keys() and dict_mb[code]["CQ"] == "None":
            add_color_comment(ws_103[f"BY{i}"], BLUE, '模板信息为空', result[personnel_code])
        elif code in dict_mb.keys() and dict_mb[code]["CQ"] != str(ws_103[f"BY{i}"].value).strip():
            add_color_comment(ws_103[f"BY{i}"], RED, f'"模板信息："{dict_mb[code]["CQ"]}', result[personnel_code])

        # 11.从事专业类别名称
        if cel(ws_103, f'BF{i}') and code in dict_mb.keys():
            if dict_mb[code]["CO"] == "None":
                add_color_comment(ws_103[f"BF{i}"], BLUE, '模板信息为空', result[personnel_code])
            if dict_mb[code]["CO"] != str(ws_103[f"BF{i}"].value).strip():
                add_color_comment(ws_103[f"BF{i}"], RED, f'"模板信息："{dict_mb[code]["CO"]}', result[personnel_code])

        #  12.岗位分类序列
        if code + "S" in dict_1071.keys() and not (dict_1071[code + "S"]["P"][0] == dict_1071[code + "S"]["Z"][0] or (
                dict_1071[code + "S"]["P"][0] == "3" and dict_1071[code + "S"]["Z"][0] == "4")):
            add_color_comment(ws_103[f"X{i}"], RED, "岗位分类序列和薪酬标杆类别不匹配！", result[personnel_code])
        # wb_103.save(file_103)

        # 13.企业统计标识
        if "否" in str(ws_103[f"AP{i}"].value):
            add_color_comment(ws_103[f"AP{i}"], BLUE, "请核对企业统计标识！", result[personnel_code])

        # 14.总部统计唯一标识
        if "None" in str(ws_103[f"AQ{i}"].value):
            add_color_comment(ws_103[f"AQ{i}"], RED, "请核对总部统计唯一标识！", result[personnel_code])

        # S列人员组为【A、B、H、I、W】且AQ列总部统计标识不为10红色提示，如为C且标识不含用工统计,蓝色提示”
        if cel(ws_103, f"S{i}") in ['A', 'B', 'H', 'I', 'W'] and '用工统计' not in cel(ws_103, f"AQ{i}"):
            cells(ws_103, f"AQ{i}", '请检查总部统计标识！', RED)
        elif cel(ws_103, f"S{i}") == 'C' and '用工统计' not in cel(ws_103, f"AQ{i}"):
            cells(ws_103, f"AQ{i}", '请核实总部统计标识！', BLUE)

        # 15.企业自定义分类
        for k, (x, y) in {"N": ("AD", "AE"), "CE": ("AF", "AG"), "CF": ("AH", "AI")}.items():
            value = (str(ws_103[f"{x}{i}"].value) + str(ws_103[f"{y}{i}"].value)).replace(" ", "").replace("None", "")
            if code in dict_mb.keys() and value != dict_mb[code][k].replace(" ", "").replace("None", ""):
                add_color_comment(ws_103[f"{x}{i}"], RED, f'模板信息：{dict_mb[code][k]}', result[personnel_code])

        # 16.薪酬标杆类别
        for x, y in {("12", "13"): ("1",), ("15",): ("2",), ("16", "17"): ("3", "4")}.items():
            if ws_103[f"T{i}"].value in x and str(ws_103[f"BH{i}"].value)[0] not in y:
                add_color_comment(ws_103[f"BH{i}"], RED, "人员子组与薪酬标杆类别不一致！", result[personnel_code])

        # 17.成本中心
        ci, cj, ck, cl = ws_103[f"CI{i}"].value, ws_103[f"CJ{i}"].value, ws_103[f"CK{i}"].value, ws_103[f"CL{i}"].value
        if [ci, cj, ck, cl] == [None] * 4:
            add_color_comment(ws_103[f"CI{i}"], RED, "请检查机构和岗位成本中心设置！", result[personnel_code])
        if (ci is not None and ck is not None) or (ci is not None and cl is not None):
            add_color_comment(ws_103[f"CK{i}"], BLUE, "请检查岗位成本中心设置！", result[personnel_code])

        # 18.业务范围
        if ws_103[f"AL{i}"].value is None or ws_103[f"AM{i}"].value is None:
            add_color_comment(ws_103[f"AL{i}"], RED, "请检查业务范围！", result[personnel_code])

        # 19.工资总额控制范围
        if ws_103[f"AB{i}"].value is None and str(ws_103[f"Z{i}"].value).strip() != "00":
            add_color_comment(ws_103[f"AB{i}"], RED, "请核对工资总额控制范围！", result[personnel_code])

        # 20.职务岗位码
        if ws_103[f"AJ{i}"].value is None:
            add_color_comment(ws_103[f"AJ{i}"], RED, "职务岗位码需核对！", result[personnel_code])

        # 21.工作经历       todo 简历功能维护暂时取消检查
        # for k, v in {"BL": "BM"}.items():
        #     if ws_103[f"C{i}"].value != ws_103[f"{k}{i}"].value:
        #         add_color_comment(ws_103[f"{k}{i}"], RED, "请核对工作经历信息！", result[personnel_code])
        #     if ws_103[f"D{i}"].value != ws_103[f"{v}{i}"].value:
        #         add_color_comment(ws_103[f"{v}{i}"], RED, "请核对工作经历信息！", result[personnel_code])

        # 22.简历
        if ws_103[f"F{i}"].value != ws_103[f"BO{i}"].value or ws_103[f"BN{i}"].value != ws_103[f"E{i}"].value:
            add_color_comment(ws_103[f"BO{i}"], RED, "请检查简历是否生成！", result[personnel_code])

        #  23 在107-1表中检查是否存在一岗多人的情况（【B】列连续出现两个“P”）
        if code + "S" in dict_1071.keys():
            index, lis = list(dict_1071.keys()).index(code + "S"), list(dict_1071.keys())
            if len(lis) >= index + 3 and lis[index + 1][-1] == lis[index + 2][-1] == "P":
                add_color_comment(ws_103[f"X{i}"], RED, "请检查存在一岗多人情况！", result[personnel_code])

        #  24 检查政治面貌 和证件信息-身份证号是否成功
        for pos, text in {'CM': '请检查政治面貌信息！', 'CN': '请检查证件信息！'}:
            tmp = str(ws_103[f'{pos}{i}'].value).replace('None', '').strip()
            if not tmp:
                add_color_comment(ws_103[f"{pos}{i}"], RED, text, result[personnel_code])

        #  25 检查其他用工信息
        tmps, tmpcp, tmpcq = cel(ws_103, f'S{i}'), cel(ws_103, f'CP{i}'), cel(ws_103, f'CQ{i}')
        if tmps == 'C' or tmps == 'I':
            if not tmpcp:
                add_color_comment(ws_103[f"CP{i}"], RED, '请检查其他用工信息！', result[personnel_code])
            if not tmpcq:
                add_color_comment(ws_103[f"CQ{i}"], BLUE, '请检查劳务派遣单位类别信息！', result[personnel_code])
        elif tmps == 'H':  # H 职业雇员 80 石化系统聘用的职业雇员
            if tmpcp and tmpcp[:2] != '80':
                add_color_comment(ws_103[f"CP{i}"], RED, 'H类人员只能为80职业雇员！', result[personnel_code])
        elif tmps in ['A', 'B'] and (tmpcp or tmpcq):
            add_color_comment(ws_103[f"CP{i}"], BLUE, '非C类I类H类人员请检查其他用工信息！', result[personnel_code])

    wb_103.save(file_103)

    with DbSession() as sess:
        for key, value in result.items():
            sess.query(RZLog_detail).filter(RZLog_detail.sr == sr, RZLog_detail.code == key).update(
                {RZLog_detail.shjcjg: str(value)[:250]})
