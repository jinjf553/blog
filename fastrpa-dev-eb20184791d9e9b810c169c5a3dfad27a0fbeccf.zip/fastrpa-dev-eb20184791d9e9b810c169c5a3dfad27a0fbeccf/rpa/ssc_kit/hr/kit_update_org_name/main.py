"""单位简化全称命名
   pyinstaller --clean -F --noconfirm --noupx --key=PBmmQGUYL3xF4kbD -n 单位简化全称命名 ./rpa/ssc_kit/hr/reduce_name/main.py
"""

import logging
import sys
from pathlib import Path

import pandas as pd
from rpa.fastrpa.log import config, logfn


@logfn
def main(filename: str):
    df = pd.read_excel(filename, dtype=str)
    df = df.iloc[:, 0:15]  # 取前15列
    df.columns = ['A-对象标识', 'B-OT', 'C-开始日期', 'D-结束日期', 'E-机构简称', 'F-机构全称', 'G-单位简化全称', 'H-领导班子管理层级',
                  'I-机构层次', 'J-机构层次', 'K-单位级别', 'L-单位级别.1', 'M-虚机构标识', 'N-RO', 'O-相关对象的标识']
    df['C-开始日期'] = df['C-开始日期'].apply(lambda v: v[:10].replace('-', '/') if isinstance(v, str) and len(v) >= 8 else '')
    df['D-结束日期'] = df['D-结束日期'].apply(lambda v: v[:10].replace('-', '/') if isinstance(v, str) and len(v) >= 8 else '')
    # df = df[['A-对象标识', 'E-机构简称', 'I-机构层次', 'M-虚机构标识', 'O-相关对象的标识']]
    df = df.fillna('')
    df = df.applymap(lambda v: v.strip(' \t\r\n') if isinstance(v, str) else v)

    def calc_i(row):
        if row['I-机构层次'] in ('29', '30'):
            return row['E-机构简称']
        if row['M-虚机构标识'] == 'X':
            e_list = []
        else:
            e_list = [row['E-机构简称']]
        _o = row['O-相关对象的标识']
        while True:
            _row = df[df['A-对象标识'] == _o]
            if len(_row) != 1:
                e_list = ['匹配错误']
                break
            elif _row['M-虚机构标识'].values[0] == 'X':  # 是X则忽略
                _o = _row['O-相关对象的标识'].values[0]
            else:
                e_list.append(_row['E-机构简称'].values[0])
                break
        e_list.reverse()
        return ''.join(e_list)
    df['I'] = df.apply(calc_i, axis=1)
    df.to_excel(Path(filename).parent.joinpath(Path(filename).name[:-5] + '_修改后.xlsx').as_posix(), index=False)


if __name__ == '__main__':
    config('reduce_name.log')
    logging.info('提示：请拖动文件到程序上执行，执行结束后，会在文件同目录下生成“__修改后.xlsx”。')
    print(sys.argv)
    input('按回车继续，或关闭窗口重新操作')
    if len(sys.argv) >= 2:
        filename = sys.argv[1]
        if filename[-5:].lower() == '.xlsx':
            main(filename)
            input('程序执行完毕')
        else:
            input(f'文件不是xlsx格式，文件名：{filename}')
    else:
        # main('x:/取名.xlsx')
        input('请拖动模板文件到程序上执行')
