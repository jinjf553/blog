import datetime
import logging
import os
import shutil
from collections import defaultdict

import pyperclip
from dateutil.relativedelta import relativedelta  # type: ignore
from openpyxl import load_workbook
from openpyxl.utils import get_column_letter
from rpa.fastrpa.adtable import AdTable
from rpa.fastrpa.named_lock import ClipboardLock
from rpa.fastrpa.sap.session import SAP
from rpa.fastrpa.tempdir import gentempdir
from rpa.public.all_party_up import file_archive, str_to_date
from rpa.public.config import templates
from rpa.ssc.hr.sap.export_103 import enter_103
from rpa.ssc.sap.query import export_query
from rpa.ssc_kit.hr.kit_nian_jin.first_participate import (
    export_otherinfo_annuity, get_classify, get_id_from_org_no,
    get_pernr_from_sfid, style_cell)

process_path = ''


def main(filename, date, end_date):
    global process_path
    process_path = gentempdir()
    if date is None or end_date is None:
        logging.warning('请输入开始日期和结束日期！')
        return
        # date = datetime.datetime.now().strftime("%Y%m01")
    else:
        dt = str_to_date(f'{date[:6]}01')
        edt = str_to_date(end_date)
        if dt is None or edt is None:
            logging.warning('错误的年月日期格式！')
            return
    if os.path.exists(filename):
        file = f"{process_path}/{os.path.basename(filename)}"
        shutil.copyfile(filename, file)
        wb = load_workbook(file, data_only=True)
        ws = wb.active
        id_lst = list(filter(lambda x: len(str(x)) == 18, [v.value for v in ws['C']][6:]))
        wb.close()
        staff_ids = get_pernr_from_sfid(id_lst, date, end_date)
        if not retire_pay(list(staff_ids.keys()), date, end_date):
            return
        file_archive(file, is_succ=True, ctype='年金')
    elif len(filename) == 8 and filename.isdigit():
        staff_ids = get_id_from_org_no(filename, date, end_date, ctype='ZK')
        if staff_ids:
            if not retire_pay(list(staff_ids.keys()), date, end_date):
                return
            file_archive(fr'{process_path}\3企业年金账户支付确认单.xlsx', is_succ=True, ctype='年金')
        else:
            logging.info(f'在{filename}机构下未找到{date[:6]}新增人员记录！')
    else:
        logging.warning('未找到匹配记录，请检查输入是否正确！')
    logging.info('处理完成，请注意检查!')


def retire_pay(staff_ids, date, end_date):
    date1 = datetime.datetime.strptime(f'{date[:6]}01', '%Y%m%d')
    last_month_end = (date1 - relativedelta(days=1)).strftime("%Y%m%d")
    # rpa.config.FSO_USERNAME = 'zhoub25.ssc'
    # rpa.config.SAP_FUNJ = 'FUNJ0111'
    with SAP('login_tx') as session:
        base_info = get_retiree_info(session, staff_ids, date, end_date)
        if not base_info:
            logging.error('错误：导出系统数据出错！')
            shutil.rmtree(process_path)
            return False
        gz_dict = export_otherinfo_annuity(session, staff_ids, date=f"{date[:6]}01", end_date=end_date, ctype='职业资格')
        zc_dict = export_otherinfo_annuity(session, staff_ids, date=f"{date[:6]}01", end_date=end_date, ctype='职称')
        zw_dict = export_otherinfo_annuity(session, staff_ids, date=last_month_end, end_date=date, ctype='职位级别')

    wb = load_workbook(fr"{templates}\年金配套\3企业年金账户支付确认单.xlsx")
    ws = wb.active
    wb2 = load_workbook(fr"{templates}\年金配套\5待遇支付多期测算批量模板.xlsx")
    ws2 = wb2.active
    current_date = datetime.datetime.now().strftime("%Y.%m.01")
    ws["L3"] = f'填报时间：{current_date[:4]} 年 {current_date[5:7]} 月 {current_date[-2:]} 日'
    for i, (k, v) in enumerate(base_info.items(), start=6):
        # 生成退休支付计划表
        try:
            if i % 18 == 0:
                ws.insert_rows(i + 1)
            ws[f'A{i}'], ws[f'B{i}'], ws[f'C{i}'], ws[f'D{i}'] = i - 5, v[0], v[1], v[2]
            ws[f'E{i}'], ws[f'F{i}'] = v[3], int(v[3][:4])
            ws[f'G{i}'] = get_classify(v[6], zc_dict.get(k, ''), gz_dict.get(k, ''))
            ws[f'H{i}'] = f'=IFERROR(VLOOKUP(G{i},码表勿删!$A$1:$W$11,MATCH(F{i},码表勿删!$A$1:$W$1,0)),"")'
            ws[f'I{i}'] = current_date
            for k1, v1 in {'工行': '中国工商银行', '建行': '中国建设银行', '农行': '中国农业银行', '中行': '中国银行', '交行': '交通银行'}.items():
                if k1 in v[4]:
                    ws[f'J{i}'] = v1
                    break
            else:
                ws[f'J{i}'] = f"{v[4].split('银行')[0]}银行" if len(v[4].split('银行')) > 1 else ''
            ws[f'K{i}'], ws[f'L{i}'] = v[4], f"{v[5]}"
            ws[f'Q{i}'], ws[f'R{i}'], ws[f'S{i}'] = zw_dict.get(k, ''), zc_dict.get(k, ''), gz_dict.get(k, '')
        except Exception as e:
            logging.warning(f'数据填写错误：{e}')
            wb.save(fr'{process_path}\3企业年金账户支付确认单.xlsx')

        try:
            ws2[f'A{i - 4}'], ws2[f'B{i - 4}'] = v[7], v[0]
            ws2[f'C{i - 4}'], ws2[f'D{i - 4}'] = '身份证', v[1]
            ws2[f'E{i - 4}'], ws2[f'F{i - 4}'] = '', '一年'
            ws2[f'G{i - 4}'], ws2[f'H{i - 4}'] = 1, 10
        except Exception as e:
            logging.warning(f'数据填写错误：{e}')
            wb2.save(fr'{process_path}\5待遇支付多期测算批量模板.xlsx')

    style_cell(ws, 7, i)
    ws[f'B{i + 1}'], ws[f'G{i + 1}'], ws[f'L{i + 1}'] = '部门负责人：', '经办人：', '联系电话：'
    ws.merge_cells(f'A{i + 2}:N{i + 3}')
    ws[f'A{i + 2}'] = ' 注：1、本单位承诺上述填报信息真实、准确；\r\n    2、职工根据个人账户余额、个人所得税税负等情况选择企业年金领取期数，最长不超过20期，领取期数一经确定不得更改。'
    ws.row_dimensions[i + 2].height = 30
    ws.row_dimensions[i + 2].auto_size = True
    logging.info(process_path)
    wb.save(fr'{process_path}\3企业年金账户支付确认单.xlsx')
    wb.close()
    style_cell(ws2, 2, i - 4)
    wb2.save(fr'{process_path}\5待遇支付多期测算批量模板.xlsx')
    wb2.close()
    # validate_result(fr'{process_path}\1年金计划表.xlsx', fr'{process_path}\2年金批导模板.xlsx', repeat_id, nab)
    # file_archive(file, is_succ=True, ctype='年金')
    logging.info('处理完成，请注意检查!')
    return True


# def validate_result(schedule_file, batch_import_file, repeat_id, nab):
#     logging.info('正在校验生成的计划表和模板......')
#     result_dict, result_dict2 = defaultdict(list), defaultdict(list)
#     clear_comments_backgrand(schedule_file, header=4)
#     clear_comments_backgrand(batch_import_file, header=1)
#     wb = load_workbook(schedule_file)
#     ws = wb.active
#     for i in range(5, len(ws['D']) + 1):
#         if ws[f'D{i}'].value is None: continue
#         t_value = [ws[f'{get_column_letter(x)}{i}'].value for x in range(1, 24)]
#         if t_value[2] not in {'身份证', '户口本', '护照', '其他', '士兵证', '港澳台通行证', '警官证', '外国人居留证', '临时身份证'}:
#             add_color_comment(ws[f"C{i}"], RED, '证件类型非码值', result_dict[t_value[3]])
#         if t_value[4] not in {'男', '女'}:
#             add_color_comment(ws[f"E{i}"], RED, '性别非码值', result_dict[t_value[3]])
#         if t_value[8] not in {'是', '否'}:
#             add_color_comment(ws[f"I{i}"], RED, '引进人才非码值', result_dict[t_value[3]])
#         if t_value[12] not in {'党组领导', '高管人员', '中层领导人员', '基层领导及以下人员'}:
#             add_color_comment(ws[f"M{i}"], RED, '员工类别非码值', result_dict[t_value[3]])
#         if t_value[14] not in {'经营管理', '专业技术', '技能操作'}:
#             add_color_comment(ws[f"O{i}"], RED, '队伍序列非码值', result_dict[t_value[3]])
#         if t_value[15] not in {'副高级', '员级', '正高级', '中级', '助理级', '无'}:
#             add_color_comment(ws[f"P{i}"], RED, '职称非码值', result_dict[t_value[3]])
#         if t_value[17] not in {'是', '否'}:
#             add_color_comment(ws[f"R{i}"], RED, '高管在职非码值', result_dict[t_value[3]])
#         if t_value[18] not in {'高级技师', '技师', '高级工', '中级工', '初级工', '无'}:
#             add_color_comment(ws[f"S{i}"], RED, '职业资格非码值', result_dict[t_value[3]])
#         if t_value[19] not in {'处级', '科级', '其他', '正职', '副职', '科级', '中级职称', '正高职称', '副高职称', '高级技师', '技师'}:
#             add_color_comment(ws[f"T{i}"], RED, '企业补贴人员分类非码值', result_dict[t_value[3]])
#         if t_value[21] not in {'关键岗位', '主体岗位', '普通岗位'}:
#             add_color_comment(ws[f"V{i}"], RED, '所在岗位类别非码值', result_dict[t_value[3]])
#         if t_value[21] == '普通岗位':
#             add_color_comment(ws[f"V{i}"], RED, '所在岗位为普通岗位', result_dict[t_value[3]])
#         if t_value[3] in repeat_id:  # 身份证号重复，批注显示重复人员编号
#             add_color_comment(ws[f"D{i}"], RED, '\r\n'.join(repeat_id[t_value[3]]), result_dict[t_value[3]])
#         if t_value[5] in nab:  # 人员组不为A、B类人员
#             add_color_comment(ws[f"B{i}"], RED, nab[t_value[5]], result_dict[t_value[3]])
#         if (int(t_value[3][-2]) % 2 == 1 and t_value[4] != '男') or (int(t_value[3][-2]) % 2 == 0 and t_value[4] != '女'):
#             add_color_comment(ws[f"E{i}"], RED, '性别与身份证号不匹配', result_dict[t_value[3]])
#         if t_value[9].replace('-', '') != t_value[3][6:14]:
#             add_color_comment(ws[f"J{i}"], RED, '出生日期与身份证号不匹配', result_dict[t_value[3]])
#         if t_value[6] > t_value[11]:
#             add_color_comment(ws[f"G{i}"], RED, '加入本企业时间晚于建立年金时间', result_dict[t_value[3]])
#         for cl, n in {'N': 13, 'W': 22}.items():
#             if not t_value[n]: add_color_comment(ws[f"{cl}{i}"], RED, '单元格无数据', result_dict[t_value[3]])
#     wb.save(schedule_file)
#     wb.close()
#     wb2 = load_workbook(batch_import_file)
#     ws2 = wb2.active
#     for i in range(2, len(ws2['D']) + 1):
#         if ws2[f'D{i}'].value is None: continue
#         t_value = [ws2[f'{get_column_letter(x)}{i}'].value for x in range(1, 33)]
#         if t_value[2] not in {'身份证', '户口本', '护照', '其他', '士兵证', '港澳台通行证', '警官证', '外国人居留证', '临时身份证'}:
#             add_color_comment(ws2[f"C{i}"], RED, '证件类型非码值', result_dict2[t_value[5]])
#         if t_value[4] not in {'男', '女'}:
#             add_color_comment(ws2[f"E{i}"], RED, '性别非码值', result_dict2[t_value[5]])
#         if t_value[9] not in {'是', '否'}:
#             add_color_comment(ws2[f"J{i}"], RED, '引进人才非码值', result_dict2[t_value[5]])
#         if t_value[13] not in {'党组领导', '高管人员', '中层领导人员', '基层领导及以下人员'}:
#             add_color_comment(ws2[f"N{i}"], RED, '员工类别非码值', result_dict2[t_value[5]])
#         if t_value[18] not in {'经营管理', '专业技术', '技能操作'}:
#             add_color_comment(ws2[f"S{i}"], RED, '队伍序列非码值', result_dict2[t_value[5]])
#         if t_value[16] not in {'副高级', '员级', '正高级', '中级', '助理级', '无'}:
#             add_color_comment(ws2[f"Q{i}"], RED, '职称非码值', result_dict2[t_value[5]])
#         if t_value[19] not in {'是', '否'}:
#             add_color_comment(ws2[f"T{i}"], RED, '高管在职非码值', result_dict2[t_value[5]])
#         if t_value[20] not in {'高级技师', '技师', '高级工', '中级工', '初级工', '无'}:
#             add_color_comment(ws2[f"U{i}"], RED, '职业资格非码值', result_dict2[t_value[5]])
#         if t_value[24] not in {'处级', '科级', '其他', '正职', '副职', '科级', '中级职称', '正高职称', '副高职称', '高级技师', '技师'}:
#             add_color_comment(ws2[f"Y{i}"], RED, '企业补贴人员分类非码值', result_dict2[t_value[5]])
#         if str(t_value[21]).isdigit() and str(int(t_value[21])) not in [str(x) for x in range(1, 24)]:
#             add_color_comment(ws2[f"V{i}"], RED, '所在岗位类别非码值', result_dict2[t_value[5]])
#         for cl, n in dict(O=14, P=15, AB=27, AC=28, AD=29, AF=31).items():
#             if not t_value[n]: add_color_comment(ws2[f"{cl}{i}"], RED, '单元格无数据', result_dict2[t_value[5]])
#         if t_value[3] in repeat_id:  # 身份证号重复，批注显示重复人员编号
#             add_color_comment(ws2[f"D{i}"], RED, '\r\n'.join(repeat_id[t_value[3]]), result_dict2[t_value[5]])
#         if t_value[5] in nab:  # 人员组不为A、B类人员
#             add_color_comment(ws2[f"B{i}"], RED, nab[t_value[5]], result_dict2[t_value[5]])
#         if t_value[3] and ((int(t_value[3][-2]) % 2 == 1 and t_value[4] != '男') or (
#                 int(t_value[3][-2]) % 2 == 0 and t_value[4] != '女')):
#             add_color_comment(ws2[f"E{i}"], RED, '性别与身份证号不匹配', result_dict2[t_value[5]])
#         if t_value[3] and t_value[10] and t_value[10].replace('-', '') != t_value[3][6:14]:
#             print(t_value[10].replace('-', ''), t_value[3][6:14])
#             add_color_comment(ws2[f"K{i}"], RED, '出生日期与身份证号不匹配', result_dict2[t_value[5]])
#         if t_value[7] and t_value[12] and t_value[7] > t_value[12]:
#             add_color_comment(ws2[f"H{i}"], RED, '建立年金时间早于加入本企业时间', result_dict2[t_value[5]])
#     wb2.save(batch_import_file)
#     wb2.close()
#     logging.info("计划表和批导表检查完成，检查结果：")
#     if result_dict: logging.info(f"\t计划表：{result_dict}")
#     if result_dict2: logging.info(f"\t批导表：{result_dict2}")


def get_retiree_info(session, staffs_id, date, end_date):
    '''根据人员编号查询获得指定月份退休人员信息'''
    # date1 = datetime.datetime.strptime(f'{date[:6]}01', '%Y%m%d')
    # end_date = (date1 + relativedelta(months=1) - relativedelta(days=1)).strftime('%Y%m%d')
    enter_103(session)
    table = session.findById("wnd[0]/shellcont[1]/shell/shellcont[0]/shell/shellcont[1]/shell[1]")
    table.expandNode("          2")
    table.itemContextMenu("          3", "C          4")
    table.selectContextMenuItem("OUTPUT_BOTH")
    table.changeCheckbox("          3", "C          3", -1)  # 人员编号
    table.expandNode("        160")
    table.changeCheckbox("        166", "C          4", -1)
    table.expandNode("         63")
    table.changeCheckbox("         71", "C          4", -1)
    table.expandNode("        568")
    table.topNode = "        387"
    table.changeCheckbox("        570", "C          4", -1)
    table.expandNode("       1222")
    table.changeCheckbox("       1230", "C          4", -1)
    table.changeCheckbox("       1231", "C          4", -1)
    table.expandNode("         19")
    table.itemContextMenu("         32", "C          4")
    table.selectContextMenuItem("OUTPUT_ONLYVALUE")
    table.changeCheckbox("         28", "C          4", -1)
    tmpid = "wnd[0]/usr/subSUB_MAIN:SAPLAQ_ADHOC:0210/subSUB_APPLICATION:SAPLHR_QUERY_APPL_AREA:0122/subSUB:SAPLHR_QUERY_APPL_AREA:"
    session.findById(f'{tmpid}0121/btnDYNP121-EVALUATION_PERIOD_TEXT').press()
    session.findById(f"{tmpid}0120/cmbDD_DATE").key = "8"
    session.findById(f"{tmpid}0120/ctxtG_APPL_AREA-BEGDA").text = f'{date[:6]}01'
    session.findById(f"{tmpid}0120/ctxtG_APPL_AREA-ENDDA").text = end_date
    table = session.findById(
        "wnd[0]/usr/subSUB_MAIN:SAPLAQ_ADHOC:0210/subSUB_SELECTION:SAPLAQ_ADHOC:0310/cntlSEL_DEF_CONTAINER/shellcont/shell")
    table.currentCellColumn = "MORE_ICON"
    table.pressButtonCurrentCell()
    session.findById("wnd[1]/tbar[0]/btn[16]").press()
    with ClipboardLock():
        pyperclip.copy('\r\n'.join(staffs_id))
        session.findById("wnd[1]/tbar[0]/btn[24]").press()
    try:
        session.findById("wnd[2]/tbar[0]/btn[0]").press()
    except Exception:  # nosec
        pass
    session.findById("wnd[1]/tbar[0]/btn[8]").press()
    session.findById("wnd[0]/tbar[1]/btn[8]").press()
    export_dict = defaultdict(list)
    try:
        _table: AdTable = export_query(session, query_name='年金8')
    except Exception as e:  # nosec
        logging.error(e)
        return export_dict
    for i in range(2, 1 + _table.max_row):
        sfid = _table.ws[f"A{i}"].value
        export_dict[sfid] = [_table.ws[f"{get_column_letter(x)}{i}"].value for x in range(2, 10)]
    return export_dict


if __name__ == '__main__':
    from rpa.fastrpa.log import config

    config('年金计划')
    # file = r"x:\rpa\tmp\202101\20210128\083134\3企业年金账户支付确认单.xlsx"
    # main('10010023', '20210101', '20210401')
    retire_pay(['1318060'], '20200101', '20210101')
