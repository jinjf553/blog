# -- coding: utf-8 --
import datetime
import logging
import os
import shutil

import pandas as pd
from rpa.fastrpa.log import config
from rpa.fastrpa.pandas_helper import append_df_to_excel


def gen_confi_table(filename):
    """根据账管系统和HR系统信息核查结果生成企业年金账户管理系统与HR系统信息差异情况统计表和确认表"""
    fname = rf'{os.path.dirname(filename)}\{os.path.basename(filename).replace(" 账管数据", "-信息确认表")}'
    shutil.copyfile(rf'{os.path.dirname(filename)}\差异情况统计表_确认表.xlsx', fname)
    unit = os.path.basename(filename).replace(' 账管数据.xlsx', '')
    logging.info(f'正在生成【{unit}】企业年金账户管理系统与HR系统信息差异情况统计表和确认表......')
    try:
        df = pd.read_excel(filename, sheet_name=0, index_col=None,
                           usecols=[6, 8, 9, 10, 12, 13, 14, 16, 43, 44, 45, 46, 47, 48, 49],
                           # dtype={'人员编号':'string'},
                           )
        # df = df.fillna('')
        for x in ['职工状态', '姓名', '证件号码', '企业内部员工编号', '性别', '出生时间', '参加工作时间', '加入本企业时间']:
            df[x] = df[x].apply(lambda y: y.replace('\t', ''))

        dic = {'人员姓名': ['姓名不一致', '姓名', '人员姓名'],
               '人员编号': ['人员编号不一致', '企业内部员工编号', '人员编号'],
               '出生时间.1': ['出生日期不一致', '出生时间', '出生时间.1'],
               '工作时间': ['参加工作时间不一致', '参加工作时间', '工作时间'],
               '本企业时间': ['加入本企业时间不一致', '加入本企业时间', '本企业时间']}
        with pd.option_context('mode.chained_assignment', None):
            s1 = df.loc[df['身份证号'].map(lambda x: not pd.isnull(x))]
            s1.loc[:, '信息确认'] = ''
            s1.loc[:, '差异类别'] = 'SAP系统内未找到及身份证不一致人员'
            s1.loc[:, '账管系统信息'], s1.loc[:, 'HR系统信息'] = '有此人信息', '无此人信息'
            d = s1[['企业内部员工编号', '姓名', '差异类别', '账管系统信息', 'HR系统信息', '信息确认', '证件号码']]
            for k, (v1, v2, v3) in dic.items():
                s1 = None
                s1 = df.loc[df[k].map(lambda x: not pd.isnull(x))]
                s1.loc[:, '信息确认'] = ''
                s1.loc[:, '差异类别'] = v1
                s1.loc[:, '账管系统信息'] = s1[v2].map(lambda x: x if '-' not in str(x) else str(x).replace('-', ''))
                s1.loc[:, 'HR系统信息'] = s1[v3].map(lambda x: x if '-' not in str(x) else str(x).replace('-', ''))

                d1 = s1[['企业内部员工编号', '姓名', '差异类别', '账管系统信息', 'HR系统信息', '信息确认', '证件号码']]
                sd = pd.concat([d, d1])
                d = sd
        d = d.reset_index(drop=True)
        d.index = d.index + 1

        s1 = pd.pivot_table(df, index=['职工状态'],
                            values=['身份证号', '人员姓名', '人员编号', '性别.1', '出生时间.1', '工作时间', '本企业时间'],
                            aggfunc='count', margins=True, margins_name='合计', dropna=False)
        s1['差异人数合计'] = s1.apply(sum, axis=1)
        s1['账管系统人数'] = df.groupby(['职工状态'])['姓名'].agg('count')
        order = ['账管系统人数', '差异人数合计', '人员编号', '人员姓名', '性别.1', '出生时间.1', '工作时间', '本企业时间', '身份证号']
        s2 = s1[order]
        s2.loc['合计', '账管系统人数'] = s2['账管系统人数'].sum()

        # append_df_to_excel(r"x:\Users\HR-HDH\Desktop\数据核对RPA需求\aa2.xlsx",s2, sheet_name='数据汇总', index=True, startrow=2,header=False,startcol=2)
        append_df_to_excel(fname, d, sheet_name='确认表', index=True, startrow=3, header=False)

        from openpyxl import load_workbook
        wb = load_workbook(fname)
        ws = wb['数据汇总']
        for v, x in {'正常': 3, '暂停缴费': 4, '暂时封存': 5, '保留账户': 6, '分期支付中': 7, '合计': 8}.items():
            # print(x,v,s2.index) s2.iloc[0,11]  df.groupby(['职工状态'])['姓名'].agg('count')
            if x == 8:
                ws[f'B{x}'] = '合计'
            else:
                ws[f'L{x}'] = v
                ws[f'B{x}'] = unit
            if v in s2.index:
                for n in range(9):
                    ws[f'{chr(67 + n)}{x}'] = s2.loc[v, :][n]

        ws = wb['确认表']
        ws['A2'], ws['G2'] = f'直属单位（章）：{unit}', f'日期：{datetime.datetime.now().strftime("%Y%m%d")}'
        # style_cell(ws, start=4, end=len(d) + 3)
        wb.save(fname)
        wb.close()
        logging.info(f'成功完成：【{unit}】企业年金账户管理系统与HR系统信息差异情况统计表和确认表！')
        logging.info(f'文件路径：【 {fname} 】')
    except Exception as e:
        logging.info(f'生成失败，错误原因：【{e}】！')


if __name__ == '__main__':
    filename = r"x:\Users\HR-HDH\Desktop\数据核对RPA需求\安徽石油 账管数据.xlsx"
    config()
    gen_confi_table(filename)
