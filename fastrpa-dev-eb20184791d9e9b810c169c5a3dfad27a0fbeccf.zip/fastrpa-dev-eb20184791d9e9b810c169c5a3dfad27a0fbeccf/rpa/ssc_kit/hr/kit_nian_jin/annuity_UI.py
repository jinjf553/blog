import datetime
import logging
import os
import time
import tkinter as tk
import tkinter.filedialog
from tkinter import INSERT, messagebox, scrolledtext, ttk

import windnd
from dateutil.relativedelta import relativedelta  # type: ignore
from notebooks.ssc_rpa.hr.hdh_tools.Clear_records import clear_records
from notebooks.ssc_rpa.hr.hdh_tools.org_dist_mod import org_dist_mod
from rpa.fastrpa.log import config
from rpa.ssc_kit.hr.kit_nian_jin.first_participate import main

exec_file = ""


class Main22:
    def __init__(self):
        self.win = tk.Tk()
        self.win.withdraw()  # self.win.update(); self.win.deiconify() 避免防止窗口闪烁
        self.win.iconbitmap(fr"{os.path.dirname(__file__)}\Aicn.ico")
        self.win.title("Annuity-Tools")
        self.win.geometry('870x520+380+250')
        self.win.resizable(0, 0)
        self.win.protocol('WM_DELETE_WINDOW', self.on_closing)
        windnd.hook_dropfiles(self.win, func=self.dragged_files)
        filey = ttk.LabelFrame(self.win, text=' 拖拽或浏览选择执行文件 ')
        filey.grid(column=0, row=0, padx=5, pady=4)
        self.name = tk.StringVar()
        self.l1 = ttk.Entry(filey, width=80, textvariable=self.name).grid(column=0, row=0, padx=10, pady=10)
        ttk.Button(filey, text="浏览...", width=10, command=self.select_file).grid(column=1, row=0, padx=5, pady=5)
        mess = ttk.LabelFrame(self.win, text=' 程序运行日志 ')
        mess.grid(column=0, row=1, padx=5, pady=5, rowspan=15)
        self.scr = scrolledtext.ScrolledText(mess, width=91, height=26, font="Arial 9")  # , wrap=tk.WORD)
        self.scr.grid(column=0, row=3, sticky='WE', padx=10, pady=7, columnspan=1, rowspan=15)
        config('HR-TOOLS.log', tk_scrolled_text=self.scr)
        t1 = ttk.Button(self.win, text="首参计划", width=18, command=lambda n="t1": self.setup_config(n))
        t1.grid(column=1, row=0, ipadx=10, ipady=10, padx=10)
        t2 = ttk.Button(self.win, text="退休支付", width=18, command=lambda n="t2": self.setup_config(n))
        t2.grid(column=1, row=1, ipadx=10, ipady=10, padx=10, pady=0)
        t3 = ttk.Button(self.win, text="待添加功能", width=18,
                        command=lambda n="t3": self.setup_config(n), state='disabled')
        t3.grid(column=1, row=2, ipadx=10, ipady=10, padx=10, pady=0)
        # t3.configure(state='disabled')
        t4 = ttk.Button(self.win, text="清除日志", width=18, command=self.delet_log)
        t4.grid(column=1, row=13, ipadx=10, ipady=10, padx=10, pady=0)
        t5 = ttk.Button(self.win, text="退出程序", width=18, command=self.on_closing)
        t5.grid(column=1, row=14, ipadx=10, ipady=10, padx=10, pady=0)

        # self.win.after(1000, self.sd)
        self.win.update()
        self.win.deiconify()
        self.win.mainloop()

    def dragged_files(self, files):
        global exec_file
        if len(files) == 1 and os.path.splitext(files[0])[1] in [b'.xlsx']:
            self.name.set(files[0].decode('gbk'))
            exec_file = files[0].decode('gbk')
            logging.info(f'执行文件路径：{exec_file}')
        else:
            self.name.set('')
            msg = '\n'.join((item.decode('gbk') for item in files))
            logging.info('文件类型错误！只支持拖放单个EXCEL文件（.xlsx）')
            messagebox.showwarning('警告：文件类型错误！', f"只支持拖放单个EXCEL文件（.xlsx）！\n{msg}")

    # def sd(self):
    #     global i
    #     self.refreshText()
    #
    # def refreshText(self):
    #     global i
    #     # self.scr.delete(0.0, tk.END)
    #     self.scr.insert(tk.INSERT, f'日志{i}行\n')
    #     self.scr.update()
    #     self.win.after(1000, self.refreshText)

    def on_change(self, n1):
        self.insert_log(n1)

    def on_closing(self):
        if messagebox.askokcancel("提示...", "\r  你确定要退出本程序吗？"):
            self.win.destroy()
            self.win.quit()

    def select_file(self):
        global exec_file
        filename = tk.filedialog.askopenfilename()
        self.name.set(filename)
        exec_file = filename
        logging.info(f"已选择文件{filename}" if filename else "请选择执行文件~~~")

    def delet_log(self):
        self.scr.configure(state='normal')
        self.scr.delete(1.0, tk.END)
        self.scr.configure(state='disabled')

    def insert_log(self, message):
        import time
        ltime = time.strftime('%Y-%m-%d %H:%M:%S', time.localtime())
        self.scr.insert(INSERT, f"[{ltime}]:\t\t{message}\n")
        self.scr.see(tk.END)

    def confimCB(self):
        self.insert_log('和气生财~~')

    def setup_config(self, fg):
        res = self.ask_userinfo(fg)
        if res is None:
            return
        # if fg == 't1':
        #     self.name.set(res)
        # elif fg == 't2':
        #     self.name.set(res)
        # elif fg == 't3':
        #     self.name.set(res)
        # else:
        #     print("Error")
        # print(res)

    def ask_userinfo(self, fg):
        self.win.attributes('-disabled', True)
        try:
            if fg == "t1":
                dg_px = MyDialog()
            elif fg == "t2":
                dg_px = Dg_Clear()
            elif fg == "t3":
                dg_px = Org_Dist_mod()
            else:
                dg_px = None
                print("error")
        except Exception as e:
            logging.error(f"程序出错:{e}~~")

            return
        finally:
            self.win.attributes('-disabled', False)
        if dg_px is None:
            return
        # self.delet_log()
        # if fg == 't1':
        #     logging.info('选择执行岗位排序操作')
        # elif fg == 't2':
        #     logging.info('选择执行数据清除操作')
        # else:
        #     logging.info('选择执行其他操作')

        self.win.wait_window(dg_px)  # 这一句很重要！！！
        self.win.attributes('-disabled', False)
        return dg_px.userinfo


class MyDialog(tk.Toplevel):
    def __init__(self):
        super().__init__()
        self.withdraw()
        self.iconbitmap(fr"{os.path.dirname(__file__)}\Aicn.ico")
        self.userinfo = None
        self.title('首次参加年金计划')
        self.geometry('400x150+500+400')
        self.resizable(0, 0)
        self.wm_attributes('-topmost', 1)
        monty1 = ttk.LabelFrame(self, text='请输入机构编码：')
        monty1.grid(column=0, row=0, padx=10, pady=10, ipady=10, rowspan=5)
        self.v1 = tkinter.StringVar()
        self.e1 = ttk.Entry(monty1, textvariable=self.v1, width=30)
        self.e1.grid(row=1, column=0, padx=5, pady=6)
        if exec_file:
            fname = os.path.basename(exec_file)
            monty1.config(text="已选择文件:")
            self.v1.set(fname)  # f'{fname[:17]}...' if len(fname) > 17 else fname)
            self.e1.configure(state='disabled')
        ttk.Label(monty1, text="\n     如选择文件则执行文件中身份证号信息，\n  未选文件请输入机构编号，再执行。").grid(column=0, row=3)
        self.b1 = ttk.Button(self, text="开始执行", width=15, command=self.ok).grid(column=1, row=1, ipadx=4, ipady=5)
        ttk.Button(self, text="取消执行", width=15, command=self.cancel).grid(column=1, row=2, ipadx=4, ipady=5)

        self.update()
        self.deiconify()

    def ok(self):
        self.userinfo = self.v1.get()
        self.destroy()

        logging.info(f"程序开始执行，开始时间：{time.strftime('%Y-%m-%d %H:%M:%S', time.localtime())}")
        # os.system(fr"{dirpath}\exe\Scripts\python.exe {dirpath}\rpa\notebooks\ssc_rpa\hr\temporary_test\job_ranking.py")
        if exec_file:
            # try:
            pass

        if len(self.userinfo) < 9 and self.userinfo.isdigit():
            main(self.userinfo)
        else:
            logging.warning("请选择文件输入或输入机构编号！")
            return
        logging.info(f"程序执行完成，结束时间：{time.strftime('%Y-%m-%d %H:%M:%S', time.localtime())}")

    def cancel(self):
        self.destroy()
        logging.info('您已取消首参计划操作')


class Dg_Clear(tk.Toplevel):
    def __init__(self):
        super().__init__()
        self.withdraw()
        self.iconbitmap(fr"{os.path.dirname(__file__)}\Aicn.ico")
        self.userinfo = None
        self.title('退休支付')
        self.geometry('400x200+500+400')
        # self.resizable(0, 0)
        lf1 = ttk.LabelFrame(self, text='请选择退休支付机构和月份：')
        lf1.grid(column=0, row=0, padx=10, pady=10, ipady=10, rowspan=5, columnspan=2)
        self.v11 = tkinter.StringVar()
        ttk.Label(lf1, text="  机构编码：").grid(column=0, row=1, padx=2, pady=0)
        self.e11 = ttk.Entry(lf1, textvariable=self.v11, width=17)
        self.e11.grid(row=1, column=1, ipadx=5, ipady=3, pady=10)
        self.v2 = tkinter.StringVar()
        ttk.Label(lf1, text="  退休月份：").grid(column=0, row=2, padx=2, pady=0)
        Chosen = ttk.Combobox(lf1, width=16, textvariable=self.v2, state='readonly')
        Chosen['values'] = [(datetime.datetime.now() + relativedelta(months=i)).strftime("%Y%m") for i in range(-10, 2)]
        Chosen.grid(row=2, column=1, ipady=3, padx=10, pady=5)
        Chosen.current(1)
        Chosen.config(state='readonly')
        ttk.Label(lf1, text="\n   请选择机构和月份后再执行。").grid(column=0, row=4, columnspan=2)
        ttk.Button(self, text="开始执行", width=15, command=self.ok1).grid(column=2, row=1, ipadx=4, ipady=5,
                                                                       padx=5, pady=2)
        ttk.Button(self, text="取消执行", width=15, command=self.cancel1).grid(column=2, row=2, ipadx=4, ipady=5,
                                                                           padx=5, pady=2)
        self.update()
        self.deiconify()

    def ok1(self):
        self.userinfo = self.v2.get()
        self.destroy()
        # print('OK1:', self.userinfo, file)
        if not self.userinfo:
            return
        type_flag = (self.userinfo).replace('信息', '')
        logging.info(f"开始执行{self.userinfo}退休支付")
        clear_records(exec_file, type_flag)
        # os.system(fr"{dirpath}\exe\Scripts\python.exe {dirpath}\rpa\notebooks\ssc_rpa\hr\temporary_test\Clear_records.py")

    def cancel1(self):
        logging.info('您已取退休支付操作')
        self.destroy()


class Org_Dist_mod(tk.Toplevel):
    def __init__(self):
        super().__init__()
        self.withdraw()
        self.iconbitmap(fr"{os.path.dirname(__file__)}\Aicn.ico")
        self.userinfo = None
        self.title('组织分配信息修改')
        self.geometry('400x150+500+400')
        self.resizable(0, 0)
        lf1 = ttk.LabelFrame(self, text='请选择需修改的信息：')
        lf1.grid(column=0, row=0, padx=10, pady=10, ipady=10, rowspan=5)
        self.v2 = tkinter.StringVar()
        chosen = ttk.Combobox(lf1, width=25, textvariable=self.v2, state='readonly')  # lf1['text'] = str(chosen.get())
        chosen['values'] = ('企业自定义分类2', '企业自定义分类3', '工资范围', '工资总额控制范围')
        chosen.grid(row=1, column=0, padx=10, pady=6)
        chosen.current(1)
        chosen.config(state='readonly')
        ttk.Label(lf1, text="\n     支持企业自定义分类2、3和工资范围、\n  总额范围等信息的修改，请谨慎执行。").grid(column=0, row=2)
        ttk.Button(self, text="开始执行", width=15, command=self.ok2).grid(column=1, row=1, ipadx=4, ipady=5,
                                                                       padx=5, pady=4)
        ttk.Button(self, text="取消执行", width=15, command=self.cancel2).grid(column=1, row=2, ipadx=4, ipady=5,
                                                                           padx=5, pady=4)
        self.update()
        self.deiconify()

    def ok2(self):
        self.userinfo = self.v2.get()
        self.destroy()
        if not self.userinfo:
            return
        type_flag = self.userinfo.strip()
        logging.info(f"开始执行{self.userinfo}信息修改")
        org_dist_mod(exec_file, type_flag)

    def cancel2(self):
        logging.info('您已取消组织分配屏信息修改操作')
        self.destroy()


if __name__ == '__main__':
    Main22()
