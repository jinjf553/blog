# -- coding: utf-8 --
import datetime
import logging
import os
import shutil
from collections import defaultdict

import pyperclip
from openpyxl import load_workbook
from openpyxl.utils import get_column_letter
from rpa.fastrpa.adtable import AdTable
from rpa.fastrpa.log import config
from rpa.fastrpa.named_lock import ClipboardLock
from rpa.fastrpa.sap.session import SAP
from rpa.fastrpa.tempdir import gentempdir
from rpa.public.all_party_up import file_archive, str_to_date
from rpa.public.config import templates
from rpa.ssc.hr.sap.export_103 import enter_103
from rpa.ssc.sap.query import export_query
from rpa.ssc_kit.hr.kit_nian_jin.first_participate import (get_pernr_from_sfid,
                                                           style_cell)

process_path = ''


def main(filename, date, end_date):
    global process_path
    process_path = gentempdir()
    if date is None or end_date is None:
        logging.warning('请输入开始日期和结束日期！')
        return
    else:
        dt = str_to_date(f'{date[:6]}01')
        edt = str_to_date(end_date)
        if dt is None or edt is None:
            logging.warning('错误的年月日期格式！')
            return
    if os.path.exists(filename):
        file = f"{process_path}/{os.path.basename(filename)}"
        shutil.copyfile(filename, file)
        wb = load_workbook(file, data_only=True)
        ws = wb.active
        id_lst = list(filter(lambda x: len(str(x)) == 18, [v.value for v in ws['D']][6:]))
        wb.close()
        staff_ids = get_pernr_from_sfid(id_lst, date, end_date)
        intra_infos = get_outinfo_from_org_no(list(staff_ids.keys()), date, end_date)

    elif len(filename) == 8 and filename.isdigit():
        intra_infos = get_outinfo_from_org_no(filename, date, end_date)
        file = rf'{process_path}\{filename}-8集团外转出变动表.xlsx'
    else:
        logging.warning('未找到匹配记录，请检查输入是否正确！')
        return
    if intra_infos:
        out_trans(file, intra_infos)
        file_archive(file, is_succ=True, ctype='年金')
    else:
        logging.info(f'在{filename}机构下{date}-{end_date}期间未找到集团内转移人员记录！')


def get_outinfo_from_org_no(org_code: str or list, date: str, end_date: str):
    """
    获得指定机构编号下指定月份期间集团外流动人员信息
    org_code 组织机构代码 或 人员编号列表
    """
    export_dict = defaultdict(list)
    with SAP('login_tx') as session:
        enter_103(session)
        table = session.findById("wnd[0]/shellcont[1]/shell/shellcont[0]/shell/shellcont[1]/shell[1]")
        table.expandNode("          2")
        table.itemContextMenu("          3", "C          4")
        table.selectContextMenuItem("OUTPUT_BOTH")
        table.expandNode("          4")
        table.changeCheckbox("          6", "C          4", -1)
        table.changeCheckbox("         10", "C          3", -1)
        table.itemContextMenu("         11", "C          4")
        table.selectContextMenuItem("OUTPUT_BOTH")
        table.expandNode("         19")
        table.changeCheckbox("         35", "C          4", -1)
        table.expandNode("        160")
        table.changeCheckbox("        166", "C          4", -1)
        tmpid = "wnd[0]/usr/subSUB_MAIN:SAPLAQ_ADHOC:0210/subSUB_APPLICATION:SAPLHR_QUERY_APPL_AREA:0122/subSUB:SAPLHR_QUERY_APPL_AREA:"
        session.findById(f'{tmpid}0121/btnDYNP121-EVALUATION_PERIOD_TEXT').press()
        session.findById(f"{tmpid}0120/cmbDD_DATE").key = "8"
        session.findById(f"{tmpid}0120/ctxtG_APPL_AREA-BEGDA").text = date
        session.findById(f"{tmpid}0120/ctxtG_APPL_AREA-ENDDA").text = end_date
        if isinstance(org_code, str):
            logging.info(f'正在查询【{org_code}】下符合条件的人员信息...')
            table = session.findById(
                "wnd[0]/usr/subSUB_MAIN:SAPLAQ_ADHOC:0210/subSUB_OBJECT_HEADER:SAPLAQ_ADHOC:0300/cntlEVAL_SET_RESTRIC_BY/shellcont/shell")
            table.pressContextButton("COPY_RESULT")
            table.selectContextMenuItem("1")
            table.pressButton("1")
            session.findById("wnd[1]/tbar[0]/btn[71]").press()
            session.findById("wnd[2]/usr/sub/1[0,0]/sub/1/2[0,0]/sub/1/2/3[0,3]/lbl[4,3]").setFocus()
            session.findById("wnd[2]").sendVKey(2)
            session.findById(
                "wnd[2]/usr/tabsG_SELONETABSTRIP/tabpTAB001/ssubSUBSCR_PRESEL:SAPLSDH4:0220/sub:SAPLSDH4:0220/txtG_SELFLD_TAB-LOW[0,24]").text = org_code
            session.findById("wnd[2]/tbar[0]/btn[0]").press()
            if '此选择没有值' in session.findById('wnd[0]/sbar/pane[0]').text:
                logging.warning('未查询到此机构信息....')
                return export_dict
            session.findById("wnd[2]/usr/sub/1[0,0]/sub/1/2[0,0]/sub/1/2/3[0,3]/chk[1,3]").selected = -1
            session.findById("wnd[2]/tbar[0]/btn[0]").press()
            table = session.findById("wnd[1]/usr/subSUB_SEARCH:SAPLRHWH:0300/cntlSEARCH_TREE/shellcont/shell")
            table.changeCheckbox(table.GetFocusedNodeKey(), "SEAR_CHECKBX", -1)
            session.findById("wnd[1]/tbar[0]/btn[0]").press()
            table = session.findById(
                "wnd[0]/usr/subSUB_MAIN:SAPLAQ_ADHOC:0210/subSUB_SELECTION:SAPLAQ_ADHOC:0310/cntlSEL_DEF_CONTAINER/shellcont/shell")
            table.modifyCell(0, "LOW", "ZL")

        elif isinstance(org_code, list):
            logging.info(f'\t正在查询指定人员信息...')
            table.changeCheckbox("          3", "C          3", -1)
            table = session.findById(
                "wnd[0]/usr/subSUB_MAIN:SAPLAQ_ADHOC:0210/subSUB_SELECTION:SAPLAQ_ADHOC:0310/cntlSEL_DEF_CONTAINER/shellcont/shell")
            table.modifyCell(0, "LOW", "ZG")
            table.currentCellRow = 1
            table.currentCellColumn = "MORE_ICON"
            table.pressButtonCurrentCell()
            session.findById("wnd[1]/tbar[0]/btn[16]").press()
            with ClipboardLock():
                pyperclip.copy('\r\n'.join(org_code))
                session.findById("wnd[1]/tbar[0]/btn[24]").press()
            session.findById("wnd[1]/tbar[0]/btn[8]").press()
        try:
            session.findById("wnd[2]/tbar[0]/btn[0]").press()
        except Exception:
            pass
        session.findById("wnd[0]/tbar[1]/btn[8]").press()
        if '不能读取任何数值' in session.findById('wnd[0]/sbar/pane[0]').text:
            logging.warning('未查询到此类人员信息....')
            return export_dict
        try:
            _table: AdTable = export_query(session, query_name='年金9')
        except Exception as e:
            logging.error(e)
            return export_dict
        for i in range(2, 1 + _table.max_row):
            id = _table.ws[f"A{i}"].value
            export_dict[id] = [_table.ws[f"{get_column_letter(x)}{i}"].value for x in range(2, 9)]

        return export_dict


def out_trans(fname, export_dict):
    global process_path
    if not export_dict:
        logging.error('错误：导出系统数据出错！')
        shutil.rmtree(process_path)
        return

    wb = load_workbook(fr"{templates}\年金配套\8集团外转出变动表.xlsx")
    ws = wb.active
    current_date = datetime.datetime.now().strftime("%Y.%m.01")
    ws["M3"] = f'填报时间：{current_date[:4]}年{current_date[5:7]}月{current_date[-2:]}日'
    for i, (k, v) in enumerate(export_dict.items(), start=5):
        # 生成集团外转出变动表
        try:
            ws[f'A{i}'], ws[f'B{i}'], ws[f'C{i}'], ws[f'D{i}'] = i - 4, v[0], '身份证', v[5]
            ws[f'E{i}'] = '转保留账户'
            ws[f'P{i}'] = f"{v[2]} {v[3]}"
        except Exception as e:
            logging.warning(f'数据填写错误：{e}')
            wb.save(fname)
    if i > 5:
        style_cell(ws, 5, i)
        ws[f'A{i + 1}'] = '注：本单位承诺上述填报数据真实、准确'
        ws[f'B{i + 2}'], ws[f'F{i + 2}'] = '负责人：', '经办人：'
        ws[f'I{i + 2}'], ws[f'L{i + 2}'] = '联系电话：', '填报时间：'
        wb.save(fname)
        wb.close()
    # validate_result(fr'{process_path}\1年金计划表.xlsx', fr'{process_path}\2年金批导模板.xlsx', repeat_id, nab)
    # file_archive(file, is_succ=True, ctype='年金')
    logging.info(f'处理完成，请注意检查!')
    return fname


if __name__ == '__main__':
    config()
    main('10010004', '20200901', '20210201')
