import datetime
import logging
import os
import shutil
from collections import defaultdict
from copy import copy
from typing import Any, List

import pyperclip
from openpyxl import load_workbook
from openpyxl.utils import get_column_letter
from rpa.fastrpa.adtable import RED, AdTable
from rpa.fastrpa.named_lock import ClipboardLock
from rpa.fastrpa.sap.session import SAP
from rpa.fastrpa.tempdir import gentempdir
from rpa.public.all_party_up import (clear_comments_backgrand, file_archive,
                                     str_to_date)
from rpa.public.config import templates
from rpa.public.validate_103 import add_color_comment
from rpa.ssc.hr.sap.export_103 import enter_103
from rpa.ssc.hr.sap.export_1071 import enter_1071
from rpa.ssc.sap.query import export_query

process_path = ''


def main(filename, sdate=None, edate=None):
    global process_path
    process_path = gentempdir()
    if sdate is None and edate is None:
        logging.warning('请输入开始日期和结束日期！')
        return
        # date = datetime.datetime.now().strftime("%Y%m01")
    else:
        dt = str_to_date(f'{sdate[:6]}01')
        edt = str_to_date(edate)
        if dt is None or edt is None:
            logging.warning('错误的年月日期格式！')
            return

    if os.path.exists(filename):
        file = f"{process_path}/{os.path.basename(filename)}"
        shutil.copyfile(filename, file)
        wb = load_workbook(file, data_only=True)
        ws = wb.active
        id_lst = list(filter(lambda x: len(str(x)) == 18, [v.value for v in ws['D']][4:]))
        wb.close()
        staffs_id = get_pernr_from_sfid(id_lst, sdate, edate)
        first_partic(staffs_id, sdate, edate)
        file_archive(file, is_succ=True, ctype='年金')
    elif len(filename) == 8 and filename.isdigit():
        staffs_id = get_id_from_org_no(filename, sdate, edate)
        if staffs_id:
            first_partic(list(staffs_id.keys()), sdate, edate)
            file_archive(fr'{process_path}\1年金计划表.xlsx', is_succ=True, ctype='年金')
        else:
            logging.info(f'在{process_path}机构下未找到{sdate[:6]}新增人员记录！')
    else:
        logging.warning('未找到匹配记录，请检查输入是否正确(选择文件或输入机构编码和日期)！')
    logging.info('处理完成，请注意检查!')


def first_partic(staff_ids, date, end_date):
    global process_path
    if not staff_ids:
        logging.warning('表中数据为空或有误！')
        return
    with SAP('login_tx') as session:
        baseinfo_dict = export_103_annuity_baseinfo(session, staff_ids, date=date, end_date=end_date)
        post_num = [v[14] for v in baseinfo_dict.values()]
        gzx_dict = export_otherinfo_annuity(session, staff_ids, date=date, end_date=end_date, ctype='工资项')
        gz_dict = export_otherinfo_annuity(session, staff_ids, date=date, end_date=end_date, ctype='职业资格')
        zc_dict = export_otherinfo_annuity(session, staff_ids, date=date, end_date=end_date, ctype='职称')
        cell_dict = export_otherinfo_annuity(session, staff_ids, date=date, end_date=end_date, ctype='电话')
        gw_dict = export_job_classification(session, post_num)
    if not baseinfo_dict:  # or not gzx_dict:
        logging.error('错误：导出系统数据出错！')
        shutil.rmtree(process_path)
        return

    wb = load_workbook(fr"{templates}\年金配套\1员工首次参加年金计划-标准表.xlsx")
    ws = wb.active
    wb2 = load_workbook(fr"{templates}\年金配套\2员工首次参加年金计划批导模板-标准表.xlsx")
    ws2 = wb2.active
    current_date = datetime.datetime.now().strftime("%Y-%m-01")
    category_dict = {'10': '党组领导', '11': '高管人员', '12': '中层领导人员'}
    job_dict = {'1': '经营管理', '2': '专业技术', '3': '技能操作'}
    for i, (k, v) in enumerate(baseinfo_dict.items(), start=5):
        # 生成年金计划表
        ws[f'A{i}'], ws[f'B{i}'], ws[f'C{i}'], ws[f'D{i}'] = i - 4, v[0], '身份证', v[1]
        ws[f'E{i}'], ws[f'F{i}'], ws[f'G{i}'] = v[2], k, v[3].replace('.', '-')
        ws[f'H{i}'], ws[f'I{i}'], ws[f'J{i}'] = current_date, '否', v[4].replace('.', '-')
        ws[f'K{i}'], ws[f'L{i}'] = v[5].replace('.', '-'), current_date
        ws[f'M{i}'] = category_dict.get(v[6], '基层领导及以下人员')
        ws[f'N{i}'], ws[f'O{i}'] = gzx_dict.get(f'{k}|4099', ''), job_dict.get(v[7], '无')
        ws[f'P{i}'], ws[f'Q{i}'] = zc_dict.get(k, '无'), cell_dict.get(k, '')
        ws[f'R{i}'], ws[f'S{i}'] = '是' if v[6] in ['11', '10'] and v[15] == '在职' else '否', gz_dict.get(k, '无')
        ws[f'T{i}'], ws[f'U{i}'] = get_classify(v[6], zc_dict.get(k, ''), gz_dict.get(k, '')), v[12]
        ws[f'V{i}'] = '关键岗位' if 'A' in gw_dict.get(v[14], '') else ('主体岗位' if 'B' in gw_dict.get(v[14], '') else '普通岗位')
        ws[f'W{i}'] = gzx_dict.get(f'{k}|4098', '')
        # 生成年金计划批导模板
        ws2[f'A{i - 3}'], ws2[f'B{i - 3}'], ws2[f'C{i - 3}'], ws2[f'D{i - 3}'] = v[12], v[0], '身份证', v[1]
        ws2[f'E{i - 3}'], ws2[f'F{i - 3}'], ws2[f'G{i - 3}'], ws2[f'H{i - 3}'] = v[2], k, '', v[3].replace('.', '-')
        ws2[f'I{i - 3}'], ws2[f'J{i - 3}'], ws2[f'K{i - 3}'] = current_date, '否', v[4].replace('.', '-')
        ws2[f'L{i - 3}'], ws2[f'M{i - 3}'] = v[5].replace('.', '-'), current_date
        ws2[f'N{i - 3}'] = category_dict.get(v[6], '基层领导及以下人员')
        ws2[f'O{i - 3}'], ws2[f'P{i - 3}'] = gzx_dict.get(f'{k}|4099', ''), gzx_dict.get(f'{k}|4015', '')
        ws2[f'Q{i - 3}'], ws2[f'R{i - 3}'] = zc_dict.get(k, '无'), cell_dict.get(k, '')
        ws2[f'S{i - 3}'] = job_dict.get(v[7], '无')
        ws2[f'T{i - 3}'] = '是' if v[6] in ['11', '10'] and v[15] == '在职' else '否'
        ws2[f'U{i - 3}'], ws2[f'W{i - 3}'], ws2[f'X{i - 3}'] = gz_dict.get(k, '无'), '', v[12]
        ws2[f'V{i - 3}'] = int(v[8]) if str(v[8]).isdigit() else v[8]
        ws2[f'Y{i - 3}'], ws2[f'Z{i - 3}'] = get_classify(v[6], zc_dict.get(k, ''), gz_dict.get(k, '')), ''
        bd, rd = datetime.datetime.strptime(v[4], '%Y.%m.%d'), 60 if '男' in v[2] else 55
        retire_data = datetime.date(bd.year + rd, bd.month, bd.day) - datetime.timedelta(days=1)
        ws2[f'AA{i - 3}'], ws2[f'AC{i - 3}'] = retire_data.strftime('%Y-%m-%d'), v[10]
        ws2[f'AB{i - 3}'] = (v[10].split('银行')[0] + '银行' if len(v[10].split('银行')) > 1 else '')
        ws2[f'AD{i - 3}'], ws2[f'AE{i - 3}'], ws2[f'AF{i - 3}'] = v[9], v[0], gzx_dict.get(f'{k}|4098', '')

    style_cell(ws, 6, i)
    wb.save(fr'{process_path}\1年金计划表.xlsx')
    wb.close()
    wb2.save(fr'{process_path}\2年金批导模板.xlsx')
    wb2.close()
    nab = {k: v[16] for k, v in baseinfo_dict.items() if v[16] not in {'原正式职工', '合同制员工'}}
    validate_result(fr'{process_path}\1年金计划表.xlsx', fr'{process_path}\2年金批导模板.xlsx', nab)


def get_id_from_org_no(org_code: str, date: str, end_date, ctype='ZA'):
    '''获得指定机构编号下指定月份新增(退休)人员的信息(ZA新增 ZK退休)'''
    # date1 = datetime.datetime.strptime(f'{date[:6]}01', '%Y%m%d')
    # end_date = (date1 + relativedelta(months=1) - relativedelta(days=1)).strftime('%Y%m%d')
    logging.info(f'正在查询【{org_code}】下符合条件的人员信息...')
    export_dict = defaultdict(list)
    with SAP('login_tx') as session:
        enter_103(session)
        table = session.findById("wnd[0]/shellcont[1]/shell/shellcont[0]/shell/shellcont[1]/shell[1]")
        table.expandNode("          2")
        table.itemContextMenu("          3", "C          4")
        table.selectContextMenuItem("OUTPUT_ONLYVALUE")
        table.expandNode("        160")
        table.changeCheckbox("        166", "C          4", -1)
        table.expandNode("          4")
        table.changeCheckbox("         10", "C          3", -1)
        if ctype == 'ZA':
            table.expandNode("         19")
            table.changeCheckbox("         31", "C          3", -1)
        tmpid = "wnd[0]/usr/subSUB_MAIN:SAPLAQ_ADHOC:0210/subSUB_APPLICATION:SAPLHR_QUERY_APPL_AREA:0122/subSUB:SAPLHR_QUERY_APPL_AREA:"
        session.findById(f'{tmpid}0121/btnDYNP121-EVALUATION_PERIOD_TEXT').press()
        session.findById(f"{tmpid}0120/cmbDD_DATE").key = "8"
        session.findById(f"{tmpid}0120/ctxtG_APPL_AREA-BEGDA").text = f'{date[:6]}01'
        session.findById(f"{tmpid}0120/ctxtG_APPL_AREA-ENDDA").text = end_date
        table = session.findById(
            "wnd[0]/usr/subSUB_MAIN:SAPLAQ_ADHOC:0210/subSUB_OBJECT_HEADER:SAPLAQ_ADHOC:0300/cntlEVAL_SET_RESTRIC_BY/shellcont/shell")
        table.pressContextButton("COPY_RESULT")
        table.selectContextMenuItem("1")
        table.pressButton("1")
        session.findById("wnd[1]/tbar[0]/btn[71]").press()
        session.findById("wnd[2]/usr/sub/1[0,0]/sub/1/2[0,0]/sub/1/2/3[0,3]/lbl[4,3]").setFocus()
        session.findById("wnd[2]").sendVKey(2)
        session.findById(
            "wnd[2]/usr/tabsG_SELONETABSTRIP/tabpTAB001/ssubSUBSCR_PRESEL:SAPLSDH4:0220/sub:SAPLSDH4:0220/txtG_SELFLD_TAB-LOW[0,24]").text = org_code
        session.findById("wnd[2]/tbar[0]/btn[0]").press()
        session.findById("wnd[2]/usr/sub/1[0,0]/sub/1/2[0,0]/sub/1/2/3[0,3]/chk[1,3]").selected = -1
        session.findById("wnd[2]/tbar[0]/btn[0]").press()
        if '此选择没有值' in session.findById('wnd[0]/sbar/pane[0]').text:
            logging.warning('未查询到此机构信息....')
            return export_dict
        table = session.findById("wnd[1]/usr/subSUB_SEARCH:SAPLRHWH:0300/cntlSEARCH_TREE/shellcont/shell")
        table.changeCheckbox(table.GetFocusedNodeKey(), "SEAR_CHECKBX", -1)
        session.findById("wnd[1]/tbar[0]/btn[0]").press()
        table = session.findById(
            "wnd[0]/usr/subSUB_MAIN:SAPLAQ_ADHOC:0210/subSUB_SELECTION:SAPLAQ_ADHOC:0310/cntlSEL_DEF_CONTAINER/shellcont/shell")
        table.modifyCell(0, "LOW", ctype)
        # table.currentCellColumn = "LOW"
        if ctype == 'ZA':
            table.modifyCell(1, "LOW", "B")
        session.findById("wnd[0]/tbar[1]/btn[8]").press()
        try:
            _table: AdTable = export_query(session, query_name='年金1')
        except Exception as e:
            logging.error(e)
            return export_dict
        for i in range(2, 1 + _table.max_row):
            sfid = _table.ws[f"A{i}"].value
            export_dict[sfid] = _table.ws[f"B{i}"].value
        return export_dict


def get_pernr_from_sfid(sfid_lst, date, end_date):
    # date1 = datetime.datetime.strptime(f'{date[:6]}01', '%Y%m%d')
    # end_date = (date1 + relativedelta(months=1) - relativedelta(days=1)).strftime('%Y%m%d')
    with SAP('login_tx') as session:
        enter_103(session)
        table = session.findById("wnd[0]/shellcont[1]/shell/shellcont[0]/shell/shellcont[1]/shell[1]")
        table.expandNode("          2")
        table.itemContextMenu("          3", "C          4")
        table.selectContextMenuItem("OUTPUT_ONLYVALUE")
        table.expandNode("        160")
        table.changeCheckbox("        166", "C          4", -1)
        table.changeCheckbox("        166", "C          3", -1)
        tmpid = "wnd[0]/usr/subSUB_MAIN:SAPLAQ_ADHOC:0210/subSUB_APPLICATION:SAPLHR_QUERY_APPL_AREA:0122/subSUB:SAPLHR_QUERY_APPL_AREA:"
        session.findById(f'{tmpid}0121/btnDYNP121-EVALUATION_PERIOD_TEXT').press()
        session.findById(f"{tmpid}0120/cmbDD_DATE").key = "8"
        session.findById(f"{tmpid}0120/ctxtG_APPL_AREA-BEGDA").text = f'{date[:6]}01'
        session.findById(f"{tmpid}0120/ctxtG_APPL_AREA-ENDDA").text = end_date
        sapid = session.findById(
            "wnd[0]/usr/subSUB_MAIN:SAPLAQ_ADHOC:0210/subSUB_SELECTION:SAPLAQ_ADHOC:0310/cntlSEL_DEF_CONTAINER/shellcont/shell")
        sapid.currentCellColumn = "MORE_ICON"
        sapid.pressButtonCurrentCell()
        session.findById("wnd[1]/tbar[0]/btn[16]").press()
        with ClipboardLock():
            pyperclip.copy('\r\n'.join(sfid_lst))
            session.findById("wnd[1]/tbar[0]/btn[24]").press()
        try:
            session.findById("wnd[2]/tbar[0]/btn[0]").press()
        except Exception:  # nosec
            pass
        session.findById("wnd[1]/tbar[0]/btn[8]").press()
        session.findById("wnd[0]/tbar[1]/btn[8]").press()
        export_dict = defaultdict(str)
        try:
            _table: AdTable = export_query(session, query_name='年金2')
        except Exception as e:  # nosec
            logging.error(e)
            return export_dict
        for i in range(2, 1 + _table.max_row):
            sfid = _table.ws[f"A{i}"].value
            export_dict[sfid] = _table.ws[f"B{i}"].value
        return export_dict


def export_otherinfo_annuity(session, staff_ids, date, end_date, ctype='工资项'):
    tmp_dict = defaultdict(str)
    enter_103(session)
    tmpid = "wnd[0]/usr/subSUB_MAIN:SAPLAQ_ADHOC:0210/subSUB_APPLICATION:SAPLHR_QUERY_APPL_AREA:0122/subSUB:SAPLHR_QUERY_APPL_AREA:"
    session.findById(f"{tmpid}0121/btnDYNP121-EVALUATION_PERIOD_TEXT").press()
    session.findById(f"{tmpid}0120/cmbDD_DATE").key = "8"
    session.findById(f"{tmpid}0120/ctxtG_APPL_AREA-BEGDA").text = f'{date[:6]}01'
    session.findById(f"{tmpid}0120/ctxtG_APPL_AREA-ENDDA").text = end_date
    session.findById("wnd[0]").sendVKey(0)
    sapid = session.findById("wnd[0]/shellcont[1]/shell/shellcont[0]/shell/shellcont[1]/shell[1]")
    sapid2 = session.findById(
        "wnd[0]/usr/subSUB_MAIN:SAPLAQ_ADHOC:0210/subSUB_SELECTION:SAPLAQ_ADHOC:0310/cntlSEL_DEF_CONTAINER/shellcont/shell")
    sapid.expandNode("          2")
    sapid.itemContextMenu("          3", "C          4")
    sapid.selectContextMenuItem("OUTPUT_ONLYVALUE")
    sapid.changeCheckbox("          3", "C          3", -1)  # 人员编号
    # sapid.expandNode("        160")
    # sapid.changeCheckbox("        166", "C          4", -1)     #身份证号
    # sapid.changeCheckbox("        166", "C          3", -1)
    if ctype == '工资项':
        logging.info('正在查询工资项信息......')
        sapid.expandNode("       1234")
        sapid.itemContextMenu("       1240", "C          4")
        sapid.selectContextMenuItem("OUTPUT_ONLYVALUE")
        sapid.changeCheckbox("       1240", "C          3", -1)
        sapid.changeCheckbox("       1241", "C          4", -1)
        sapid2.currentCellRow = 1
        sapid2.currentCellColumn = "MORE_ICON"
        sapid2.pressButtonCurrentCell()
        for n, d in enumerate(('4099', '4098', '4015')):
            session.findById(
                f"wnd[1]/usr/tabsTAB_STRIP/tabpSIVA/ssubSCREEN_HEADER:SAPLALDB:3010/tblSAPLALDBSINGLE/ctxtRSCSEL-SLOW_I[1,{n}]").text = d
        session.findById("wnd[1]/tbar[0]/btn[8]").press()
    elif ctype == '职称':
        logging.info('正在查询职称信息......')
        sapid.expandNode("        877")
        sapid.changeCheckbox("        884", "C          4", -1)
        sapid.changeCheckbox("        892", "C          3", -1)
        sapid2.modifyCell(1, "LOW", "X")
    elif ctype == '职业资格':
        logging.info('正在查询职业工种信息......')
        sapid.expandNode("        935")
        sapid.changeCheckbox("        943", "C          4", -1)
        sapid.changeCheckbox("        948", "C          3", -1)
        sapid2.modifyCell(1, "LOW", "X")
    elif ctype == '电话':
        logging.info('正在查询移动电话信息......')
        sapid.expandNode("        238")
        sapid.changeCheckbox("        243", "C          3", -1)
        sapid.changeCheckbox("        245", "C          4", -1)
        sapid2.modifyCell(1, "LOW", "CELL")
    elif ctype == '职位级别':
        logging.info('正在查询职位级别信息......')
        sapid.expandNode("        387")
        sapid.changeCheckbox("        395", "C          4", -1)
        # sapid.itemContextMenu("        395", "C          4")
        # sapid.selectContextMenuItem("OUTPUT_BOTH")
    else:
        logging.warning('导出类型选择错误')
        return tmp_dict

    sapid2.currentCellRow = 0
    sapid2.currentCellColumn = "MORE_ICON"
    sapid2.pressButtonCurrentCell()
    session.findById("wnd[1]/tbar[0]/btn[16]").press()
    with ClipboardLock():
        pyperclip.copy('\r\n'.join(staff_ids))
        session.findById("wnd[1]/tbar[0]/btn[24]").press()
    try:
        session.findById("wnd[2]/tbar[0]/btn[0]").press()
    except Exception:  # nosec
        pass
    session.findById("wnd[1]/tbar[0]/btn[8]").press()
    session.findById("wnd[0]/tbar[1]/btn[8]").press()
    try:
        _table: AdTable = export_query(session, query_name='年金3')
    except Exception as e:  # nosec
        logging.warning(e)
        return tmp_dict
    for i in range(2, 1 + _table.max_row):
        if ctype == '工资项':
            tmp_dict[f'{_table.ws[f"A{i}"].value}|{_table.ws[f"B{i}"].value}'] = _table.ws[f"C{i}"].value
        if ctype in ('职称', '职业资格', '电话', '职位级别'):
            tmp_dict[f'{_table.ws[f"A{i}"].value}'] = _table.ws[f"B{i}"].value
    if not tmp_dict:
        logging.warning(f'无 {ctype} 数据！')
    return tmp_dict


def export_103_annuity_baseinfo(session: Any, staff_ids: List[str], date, end_date):
    enter_103(session)
    tmpid = "wnd[0]/usr/subSUB_MAIN:SAPLAQ_ADHOC:0210/subSUB_APPLICATION:SAPLHR_QUERY_APPL_AREA:0122/subSUB:SAPLHR_QUERY_APPL_AREA:"
    session.findById(f'{tmpid}0121/btnDYNP121-EVALUATION_PERIOD_TEXT').press()
    session.findById(f"{tmpid}0120/cmbDD_DATE").key = "8"
    session.findById(f"{tmpid}0120/ctxtG_APPL_AREA-BEGDA").text = f'{date[:6]}01'
    session.findById(f"{tmpid}0120/ctxtG_APPL_AREA-ENDDA").text = end_date
    sapid = session.findById("wnd[0]/shellcont[1]/shell/shellcont[0]/shell/shellcont[1]/shell[1]")
    sapid.expandNode("        160")
    # sapid.changeCheckbox("        166", "C          3", -1) #身份证号
    sapid.expandNode("          2")
    sapid.itemContextMenu("          3", "C          4")
    sapid.selectContextMenuItem("OUTPUT_BOTH")
    sapid.changeCheckbox("          3", "C          3", -1)  # 人员编号
    sapid.changeCheckbox("        166", "C          4", -1)
    sapid.expandNode("         63")
    sapid.changeCheckbox("         71", "C          4", -1)
    sapid.expandNode("        294")
    sapid.changeCheckbox("        303", "C          4", -1)
    sapid.changeCheckbox("         72", "C          4", -1)
    sapid.changeCheckbox("        301", "C          4", -1)
    sapid.expandNode("         19")
    sapid.itemContextMenu("         32", "C          4")
    sapid.selectContextMenuItem("OUTPUT_ONLYVALUE")
    sapid.expandNode("        387")
    sapid.itemContextMenu("        393", "C          4")
    sapid.selectContextMenuItem("OUTPUT_ONLYVALUE")
    sapid.expandNode("       1196")
    sapid.changeCheckbox("       1206", "C          4", -1)
    sapid.expandNode("       1222")
    sapid.changeCheckbox("       1231", "C          4", -1)
    sapid.itemContextMenu("       1230", "C          4")
    sapid.selectContextMenuItem("OUTPUT_ONLYTEXT")
    sapid.itemContextMenu("         28", "C          4")
    sapid.selectContextMenuItem("OUTPUT_ONLYVALUE")
    sapid.itemContextMenu("         29", "C          4")
    sapid.selectContextMenuItem("OUTPUT_ONLYTEXT")
    sapid.itemContextMenu("         99", "C          4")
    sapid.selectContextMenuItem("OUTPUT_ONLYVALUE")
    sapid.itemContextMenu("         36", "C          4")
    sapid.selectContextMenuItem("OUTPUT_ONLYVALUE")
    sapid.expandNode("          4")
    sapid.changeCheckbox("         13", "C          4", -1)
    sapid.changeCheckbox("         31", "C          4", -1)
    sapid = session.findById(
        "wnd[0]/usr/subSUB_MAIN:SAPLAQ_ADHOC:0210/subSUB_SELECTION:SAPLAQ_ADHOC:0310/cntlSEL_DEF_CONTAINER/shellcont/shell")
    sapid.currentCellColumn = "MORE_ICON"
    sapid.pressButtonCurrentCell()
    session.findById("wnd[1]/tbar[0]/btn[16]").press()
    with ClipboardLock():
        pyperclip.copy('\r\n'.join(staff_ids))
        session.findById("wnd[1]/tbar[0]/btn[24]").press()
    try:
        session.findById("wnd[2]/tbar[0]/btn[0]").press()
    except Exception:  # nosec
        pass
    session.findById("wnd[1]/tbar[0]/btn[8]").press()
    session.findById("wnd[0]/tbar[1]/btn[8]").press()
    tmp_dict, repeat_id, nab = defaultdict(list), defaultdict(list), defaultdict(str)
    try:
        _table: AdTable = export_query(session, query_name='年金4')
    except Exception as e:  # nosec
        logging.error(e)
        return tmp_dict
    for i in range(2, 1 + _table.max_row):
        sfid = _table.ws[f"A{i}"].value
        tmp_dict[sfid] = [_table.ws[f"{chr(x)}{i}"].value for x in range(66, 84)]
    return tmp_dict


def export_job_classification(session, staff_ids):
    logging.info('正在查询所在岗位类型信息......')
    enter_1071(session)
    sapid = session.findById("wnd[0]/shellcont[1]/shell/shellcont[0]/shell/shellcont[1]/shell[1]")
    sapid.changeCheckbox("          8", "C          3", -1)
    sapid.changeCheckbox("         11", "C          3", -1)
    sapid.changeCheckbox("         10", "C          3", -1)
    sapid.changeCheckbox("         12", "C          3", -1)
    sapid.expandNode("        156")
    sapid.changeCheckbox("        159", "C          4", -1)
    sapid.changeCheckbox("        162", "C          4", -1)
    sapid = session.findById(
        "wnd[0]/usr/subSUB_MAIN:SAPLAQ_ADHOC:0212/subSUB_SELECTION:SAPLAQ_ADHOC:0310/cntlSEL_DEF_CONTAINER/shellcont/shell")
    sapid.modifyCell(1, "LOW", "S")
    sapid.modifyCell(3, "LOW", "01")
    sapid.modifyCell(2, "LOW", "1")
    sapid.currentCellRow = 0
    sapid.currentCellColumn = "MORE_ICON"
    sapid.pressButtonCurrentCell()
    session.findById("wnd[1]/tbar[0]/btn[16]").press()
    with ClipboardLock():
        pyperclip.copy('\r\n'.join(staff_ids))
        session.findById("wnd[1]/tbar[0]/btn[24]").press()
    try:
        session.findById("wnd[2]/tbar[0]/btn[0]").press()
    except Exception:  # nosec
        pass
    session.findById("wnd[1]/tbar[0]/btn[8]").press()
    session.findById("wnd[0]/tbar[1]/btn[8]").press()
    tmp_dict = defaultdict(str)
    try:
        _table: AdTable = export_query(session, query_name='年金5')
    except Exception as e:  # nosec
        logging.error(e)
        return tmp_dict
    for i in range(2, 1 + _table.max_row):
        tmp_dict[f'{_table.ws[f"A{i}"].value}'] = str(_table.ws[f"B{i}"].value)
    return tmp_dict


def validate_result(schedule_file, batch_import_file, nab):
    logging.info('正在校验生成的计划表和模板......')
    result_dict, result_dict2 = defaultdict(list), defaultdict(list)
    clear_comments_backgrand(schedule_file, header=4)
    clear_comments_backgrand(batch_import_file, header=1)
    wb = load_workbook(schedule_file)
    ws = wb.active
    repeat_id = [x.value for x in ws['D'] if x.value]
    for i in range(5, len(ws['D']) + 1):
        if ws[f'D{i}'].value is None:
            continue
        t_value = [ws[f'{get_column_letter(x)}{i}'].value for x in range(1, 24)]
        if t_value[2] not in {'身份证', '户口本', '护照', '其他', '士兵证', '港澳台通行证', '警官证', '外国人居留证', '临时身份证'}:
            add_color_comment(ws[f"C{i}"], RED, '证件类型非码值', result_dict[t_value[3]])
        if t_value[4] not in {'男', '女'}:
            add_color_comment(ws[f"E{i}"], RED, '性别非码值', result_dict[t_value[3]])
        if t_value[8] not in {'是', '否'}:
            add_color_comment(ws[f"I{i}"], RED, '引进人才非码值', result_dict[t_value[3]])
        if t_value[12] not in {'党组领导', '高管人员', '中层领导人员', '基层领导及以下人员'}:
            add_color_comment(ws[f"M{i}"], RED, '员工类别非码值', result_dict[t_value[3]])
        if t_value[14] not in {'经营管理', '专业技术', '技能操作'}:
            add_color_comment(ws[f"O{i}"], RED, '队伍序列非码值', result_dict[t_value[3]])
        if t_value[15] not in {'副高级', '员级', '正高级', '中级', '助理级', '无'}:
            add_color_comment(ws[f"P{i}"], RED, '职称非码值', result_dict[t_value[3]])
        if t_value[17] not in {'是', '否'}:
            add_color_comment(ws[f"R{i}"], RED, '高管在职非码值', result_dict[t_value[3]])
        if t_value[18] not in {'高级技师', '技师', '高级工', '中级工', '初级工', '无'}:
            add_color_comment(ws[f"S{i}"], RED, '职业资格非码值', result_dict[t_value[3]])
        if t_value[19] not in {'处级', '科级', '其他', '正职', '副职', '科级', '中级职称', '正高职称', '副高职称', '高级技师', '技师'}:
            add_color_comment(ws[f"T{i}"], RED, '企业补贴人员分类非码值', result_dict[t_value[3]])
        if t_value[21] not in {'关键岗位', '主体岗位', '普通岗位'}:
            add_color_comment(ws[f"V{i}"], RED, '所在岗位类别非码值', result_dict[t_value[3]])
        if t_value[21] == '普通岗位':
            add_color_comment(ws[f"V{i}"], RED, '所在岗位为普通岗位', result_dict[t_value[3]])
        if repeat_id.count(t_value[3]) > 1:
            add_color_comment(ws[f"D{i}"], RED, '身份证号重复', result_dict[t_value[3]])
        if t_value[5] in nab:  # 人员组不为A、B类人员
            add_color_comment(ws[f"B{i}"], RED, nab[t_value[5]], result_dict[t_value[3]])
        if (int(t_value[3][-2]) % 2 == 1 and t_value[4] != '男') or (int(t_value[3][-2]) % 2 == 0 and t_value[4] != '女'):
            add_color_comment(ws[f"E{i}"], RED, '性别与身份证号不匹配', result_dict[t_value[3]])
        if t_value[9].replace('-', '') != t_value[3][6:14]:
            add_color_comment(ws[f"J{i}"], RED, '出生日期与身份证号不匹配', result_dict[t_value[3]])
        if t_value[6] > t_value[11]:
            add_color_comment(ws[f"G{i}"], RED, '加入本企业时间晚于建立年金时间', result_dict[t_value[3]])
        for cl, n in {'N': 13, 'W': 22}.items():
            if not t_value[n]:
                add_color_comment(ws[f"{cl}{i}"], RED, '单元格无数据', result_dict[t_value[3]])
    wb.save(schedule_file)
    wb.close()
    wb2 = load_workbook(batch_import_file)
    ws2 = wb2.active
    repeat_id = [x.value for x in ws['D'] if x.value]
    for i in range(2, len(ws2['D']) + 1):
        if ws2[f'D{i}'].value is None:
            continue
        t_value = [ws2[f'{get_column_letter(x)}{i}'].value for x in range(1, 33)]
        if t_value[2] not in {'身份证', '户口本', '护照', '其他', '士兵证', '港澳台通行证', '警官证', '外国人居留证', '临时身份证'}:
            add_color_comment(ws2[f"C{i}"], RED, '证件类型非码值', result_dict2[t_value[5]])
        if t_value[4] not in {'男', '女'}:
            add_color_comment(ws2[f"E{i}"], RED, '性别非码值', result_dict2[t_value[5]])
        if t_value[9] not in {'是', '否'}:
            add_color_comment(ws2[f"J{i}"], RED, '引进人才非码值', result_dict2[t_value[5]])
        if t_value[13] not in {'党组领导', '高管人员', '中层领导人员', '基层领导及以下人员'}:
            add_color_comment(ws2[f"N{i}"], RED, '员工类别非码值', result_dict2[t_value[5]])
        if t_value[18] not in {'经营管理', '专业技术', '技能操作'}:
            add_color_comment(ws2[f"S{i}"], RED, '队伍序列非码值', result_dict2[t_value[5]])
        if t_value[16] not in {'副高级', '员级', '正高级', '中级', '助理级', '无'}:
            add_color_comment(ws2[f"Q{i}"], RED, '职称非码值', result_dict2[t_value[5]])
        if t_value[19] not in {'是', '否'}:
            add_color_comment(ws2[f"T{i}"], RED, '高管在职非码值', result_dict2[t_value[5]])
        if t_value[20] not in {'高级技师', '技师', '高级工', '中级工', '初级工', '无'}:
            add_color_comment(ws2[f"U{i}"], RED, '职业资格非码值', result_dict2[t_value[5]])
        if t_value[24] not in {'处级', '科级', '其他', '正职', '副职', '科级', '中级职称', '正高职称', '副高职称', '高级技师', '技师'}:
            add_color_comment(ws2[f"Y{i}"], RED, '企业补贴人员分类非码值', result_dict2[t_value[5]])
        if str(t_value[21]).isdigit() and str(int(t_value[21])) not in [str(x) for x in range(1, 24)]:
            add_color_comment(ws2[f"V{i}"], RED, '所在岗位类别非码值', result_dict2[t_value[5]])
        for cl, n in dict(O=14, P=15, AB=27, AC=28, AD=29, AF=31).items():
            if not t_value[n]:
                add_color_comment(ws2[f"{cl}{i}"], RED, '单元格无数据', result_dict2[t_value[5]])
        if repeat_id.count(t_value[3]) > 1:
            add_color_comment(ws2[f"D{i}"], RED, '身份证号重复', result_dict2[t_value[5]])
        if t_value[5] in nab:  # 人员组不为A、B类人员
            add_color_comment(ws2[f"B{i}"], RED, nab[t_value[5]], result_dict2[t_value[5]])
        if t_value[3] and ((int(t_value[3][-2]) % 2 == 1 and t_value[4] != '男') or (
                int(t_value[3][-2]) % 2 == 0 and t_value[4] != '女')):
            add_color_comment(ws2[f"E{i}"], RED, '性别与身份证号不匹配', result_dict2[t_value[5]])
        if t_value[3] and t_value[10] and t_value[10].replace('-', '') != t_value[3][6:14]:
            add_color_comment(ws2[f"K{i}"], RED, '出生日期与身份证号不匹配', result_dict2[t_value[5]])
        if t_value[7] and t_value[12] and t_value[7] > t_value[12]:
            add_color_comment(ws2[f"H{i}"], RED, '建立年金时间早于加入本企业时间', result_dict2[t_value[5]])
    wb2.save(batch_import_file)
    wb2.close()
    logging.info("计划表和批导表检查完成，检查结果：")
    if result_dict:
        logging.info(f"\t计划表：{result_dict}")
    if result_dict2:
        logging.info(f"\t批导表：{result_dict2}")


def get_classify(ryzz, zc, gz):
    if zc == '正高级':
        return '正高职称'
    elif ryzz == '12':
        return '处级'
    elif zc == '副高级':
        return '副高职称'
    elif gz == '高级技师':
        return gz
    elif ryzz == '13':
        return '科级'
    elif zc == '中级':
        return '中级职称'
    elif gz == '技师':
        return gz
    elif ryzz == '14':  # ????
        return '副职'
    else:
        return '其他'


def style_cell(ws, start, end):
    '''复制指定工作表单元格格式至指定行数'''
    height = ws.row_dimensions[start - 1].height
    for row in range(start, end + 1):
        ws.row_dimensions[row].height = height
        # ws.row_dimensions[row].auto_size = True
        for n in range(1, ws.max_column + 1):
            cod = get_column_letter(n)
            if ws[f'{get_column_letter(n)}{start - 1}'].has_style:
                ws[f'{cod}{row}'].font = copy(ws[f'{cod}{start - 1}'].font)
                ws[f'{cod}{row}'].border = copy(ws[f'{cod}{start - 1}'].border)
                ws[f'{cod}{row}'].fill = copy(ws[f'{cod}{start - 1}'].fill)
                ws[f'{cod}{row}'].number_format = copy(ws[f'{cod}{start - 1}'].number_format)
                ws[f'{cod}{row}'].alignment = copy(ws[f'{cod}{start - 1}'].alignment)
                ws[f'{cod}{row}'].protection = copy(ws[f'{cod}{start - 1}'].protection)
