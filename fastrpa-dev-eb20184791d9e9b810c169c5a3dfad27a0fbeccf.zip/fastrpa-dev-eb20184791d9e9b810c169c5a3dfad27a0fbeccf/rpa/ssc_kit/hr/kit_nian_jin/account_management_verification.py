import datetime
import logging
import os
import shutil
from collections import defaultdict

import pandas as pd
from openpyxl import load_workbook
from openpyxl.styles import PatternFill
from rpa.fastrpa.log import config
from rpa.fastrpa.pandas_helper import append_df_to_excel
from rpa.public.config import templates


def account_verif(dir_path):
    path1 = os.path.join(dir_path, '账管系统数据')
    path2 = os.path.join(dir_path, 'SAP系统数据')
    dic, dt = defaultdict(list), datetime.datetime.now()
    if not os.path.exists(path1) or not os.path.exists(path2):
        logging.error(f'【{path1}】或【{path2}】目录不存在！')
        return
    for cjb in os.listdir(path1):
        if '账管数据' not in cjb or cjb[-5:].lower() != '.xlsx':
            logging.info(f'\t\t《{cjb}》可能不是正确的名称或格式...')
            continue
        tmpfile = rf'{path2}\{cjb.replace(" 账管数据", "")}'
        logging.info(rf'{path1}\{cjb}')
        wb = load_workbook(rf'{path1}\{cjb}')
        ws = wb.active
        logging.info(f"正在处理《{os.path.basename(tmpfile)[:-5]}》的数据, 共{len(ws['G']) - 1}行...")
        dic.clear()
        if not os.path.exists(tmpfile):
            logging.info(f"无《{os.path.basename(tmpfile)[:-5]}》的对应系统数据，跳过...")
            ws['AR2'] = '无对应文件'
            wb.save(rf'{path1}\{cjb}')
            continue
        wb1 = load_workbook(tmpfile)
        ws1 = wb1.active
        for i in range(2, len(ws1['O'])):
            id1 = str(ws1[f'O{i}'].value).strip()
            # 'A'人员编号 , 'B'姓名, 'M'性别, 'N'出生日期, 'P'工作时间, 'Q'本企业时间
            dic[id1] = [ws1[f'{x}{i}'].value for x in ['A', 'B', 'M', 'N', 'P', 'Q', 'F', 'H']]
            # logging.info(f'{id1}:{dic[id1]}')
        wb1.close()
        for k, v in dict(AR='身份证号', AS='人员姓名', AT='人员编号', AU='性别', AV='出生时间', AW='工作时间', AX='本企业时间', AY='人事子范围',
                         AZ='人员组').items():
            ws[f'{k}1'].fill = PatternFill("solid", '00FF00')
            ws[f'{k}1'] = v
        for i in range(2, len(ws['G']) + 1):
            # logging.info(f'\t\t\t正在检查{cjb}第{i-1}行数据...')
            for row in ws[f'AR{i}:AX{i}']:
                for cell in row:
                    cell.value = ''
            id = str(ws[f'I{i}'].value).strip()
            if id not in dic:
                ws[f'AR{i}'] = '无此身份证号'
                continue
            if str(dic[id][0]) not in str(ws[f'K{i}'].value).lstrip('0'):
                ws[f'AT{i}'] = dic[id][0]
            if dic[id][1] not in ws[f'G{i}'].value.strip():
                ws[f'AS{i}'] = dic[id][1]
            if dic[id][2] not in ws[f'M{i}'].value.strip():
                ws[f'AU{i}'] = dic[id][2]
            ws[f'AY{i}'], ws[f'AZ{i}'] = dic[id][6], dic[id][7]
            if dic[id][3]:
                if isinstance(dic[id][3], type(dt)):
                    if dic[id][3].strftime('%Y-%m-%d') != str(ws[f'N{i}'].value).strip():
                        ws[f'AV{i}'] = dic[id][3].strftime('%Y-%m-%d')
                else:
                    logging.warning(f'\t\t{id} 出生日期非日期格式')
                    ws[f'AV{i}'] = '非日期格式'
            else:
                ws[f'AV{i}'] = '空值'
            if dic[id][4]:
                if isinstance(dic[id][4], type(dt)):
                    if dic[id][4].strftime('%Y-%m-%d') != str(ws[f'O{i}'].value).strip():
                        ws[f'AW{i}'] = dic[id][4].strftime('%Y-%m-%d')
                else:
                    logging.warning(f'\t\t{id} 工作时间非日期格式')
                    ws[f'AW{i}'] = '非日期格式'
            else:
                ws[f'AW{i}'] = '空值'
            if dic[id][5]:
                if isinstance(dic[id][5], type(dt)):
                    if dic[id][5].strftime('%Y-%m-%d') != str(ws[f'Q{i}'].value).strip():
                        ws[f'AX{i}'] = dic[id][5].strftime('%Y-%m-%d')
                else:
                    logging.warning(f'\t\t{id} 本企业时间非日期格式')
                    ws[f'AX{i}'] = '非日期格式'
            else:
                ws[f'AX{i}'] = '空值'
        wb.save(rf'{path1}\{cjb}')
        wb.close()
        gen_confi_table(rf'{path1}\{cjb}')
    logging.info('处理完毕！')


def gen_confi_table(filename):
    """根据账管系统和HR系统信息核查结果生成企业年金账户管理系统与HR系统信息差异情况统计表和确认表"""
    fname = rf'{os.path.dirname(filename)}\{os.path.basename(filename).replace(" 账管数据", "-信息确认表")}'
    shutil.copyfile(rf'{templates}\年金配套\6账管系统差异情况统计表_确认表.xlsx', fname)
    unit = os.path.basename(filename).replace(' 账管数据.xlsx', '')
    logging.info(f'正在生成【{unit}】企业年金账户管理系统与HR系统信息差异情况统计表和确认表......')
    try:
        df = pd.read_excel(filename, sheet_name=0, index_col=None,
                           usecols=[6, 8, 9, 10, 12, 13, 14, 16, 43, 44, 45, 46, 47, 48, 49, 50, 51]
                           # dtype={'人员编号':'string'},
                           )
        # df = df.fillna('')
        for x in ['职工状态', '姓名', '证件号码', '企业内部员工编号', '性别', '出生时间', '参加工作时间', '加入本企业时间']:
            df[x] = df[x].apply(lambda y: str(y).replace('\t', ''))

        dic = {'人员姓名': ['姓名不一致', '姓名', '人员姓名'],
               '人员编号': ['人员编号不一致', '企业内部员工编号', '人员编号'],
               '出生时间.1': ['出生日期不一致', '出生时间', '出生时间.1'],
               '工作时间': ['参加工作时间不一致', '参加工作时间', '工作时间'],
               '本企业时间': ['加入本企业时间不一致', '加入本企业时间', '本企业时间']}
        with pd.option_context('mode.chained_assignment', None):
            s1 = df.loc[df['身份证号'].notna()]  # map(lambda x: not pd.isnull(x))]
            s1.loc[:, '信息确认'] = ''
            s1.loc[:, '差异类别'] = 'SAP系统内未找到及身份证不一致人员'
            s1.loc[:, '账管系统信息'], s1.loc[:, 'HR系统信息'] = '有此人信息', '无此人信息'
            d = s1[['企业内部员工编号', '姓名', '差异类别', '账管系统信息', 'HR系统信息', '信息确认', '证件号码', '职工状态', '人事子范围', '人员组']]
            s1 = df[df['身份证号'].isna() & df['人员组'] == '减册人员']
            if s1.shape[0] > 0:
                s1.loc[:, '信息确认'] = ''
                s1.loc[:, '差异类别'] = 'SAP系统内未找到及身份证不一致人员'
                s1.loc[:, '账管系统信息'], s1.loc[:, 'HR系统信息'] = '', ''
                d1 = s1[['企业内部员工编号', '姓名', '差异类别', '账管系统信息', 'HR系统信息', '信息确认', '证件号码', '职工状态', '人事子范围', '人员组']]
                d = pd.concat([d, d1])
            for k, (v1, v2, v3) in dic.items():
                s1, d1 = None, None
                s1 = df.loc[df[k].map(lambda x: not pd.isnull(x))]
                if s1.shape[0] == 0:
                    logging.info(f" {k} 无不一致人员")
                    continue
                s1.loc[:, '信息确认'] = ''
                s1.loc[:, '差异类别'] = v1
                s1.loc[:, '账管系统信息'] = s1[v2].map(lambda x: x if '-' not in str(x) else str(x).replace('-', ''))
                s1.loc[:, 'HR系统信息'] = s1[v3].map(lambda x: x if '-' not in str(x) else str(x).replace('-', ''))

                d1 = s1[['企业内部员工编号', '姓名', '差异类别', '账管系统信息', 'HR系统信息', '信息确认', '证件号码', '职工状态', '人事子范围', '人员组']]
                sd = pd.concat([d, d1])
                d = sd
        d = d.reset_index(drop=True)
        d.index = d.index + 1

        s1 = pd.pivot_table(df, index=['职工状态'],
                            values=['身份证号', '人员姓名', '人员编号', '性别.1', '出生时间.1', '工作时间', '本企业时间'],
                            aggfunc='count', margins=True, margins_name='合计', dropna=False)
        s1['差异人数合计'] = s1.apply(sum, axis=1)
        s1['账管系统人数'] = df.groupby(['职工状态'])['姓名'].agg('count')
        order = ['账管系统人数', '差异人数合计', '人员编号', '人员姓名', '性别.1', '出生时间.1', '工作时间', '本企业时间', '身份证号']
        s2 = s1[order]
        s2.loc['合计', '账管系统人数'] = s2['账管系统人数'].sum()

        # append_df_to_excel(r"x:\Users\HR-HDH\Desktop\数据核对RPA需求\aa2.xlsx",s2, sheet_name='数据汇总', index=True, startrow=2,header=False,startcol=2)
        append_df_to_excel(fname, d, sheet_name='确认表', index=True, startrow=3, header=False)

        from openpyxl import load_workbook
        wb = load_workbook(fname)
        ws = wb['数据汇总']
        for v, x in {'正常': 3, '暂停缴费': 4, '暂时封存': 5, '保留账户': 6, '其他状态': 7, '合计': 8}.items():  # '分期支付中': 7,
            # print(x,v,s2.index) s2.iloc[0,11]  df.groupby(['职工状态'])['姓名'].agg('count')
            if x == 8:
                ws[f'B{x}'] = '合计'
            else:
                ws[f'L{x}'] = v
                ws[f'B{x}'] = unit
            if v in s2.index:
                for n in range(9):
                    ws[f'{chr(67 + n)}{x}'] = s2.loc[v, :][n]

        ws = wb['确认表']
        ws['A2'], ws['I2'] = f'直属单位（章）：{unit}', f'日期：{datetime.datetime.now().strftime("%Y%m%d")}'
        # style_cell(ws, start=4, end=len(d) + 3)
        wb.save(fname)
        wb.close()
        logging.info(f'成功完成：【{unit}】企业年金账户管理系统与HR系统信息差异情况统计表和确认表！')
        logging.info(f'文件路径：【 {fname} 】')
    except Exception as e:
        logging.info(f'生成失败，错误原因：【{e}】！')


if __name__ == '__main__':
    dir_path = r"x:\Users\HR-HDH\Desktop\tetst\3\新建文件夹(1)"
    config("aa")
    account_verif(dir_path)
