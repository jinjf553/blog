#!/usr/bin/env python
# -*- coding: utf-8 -*-
# @File    : no_job_change.py
# @Author  : jinjianfeng
import logging
import os
import sys
import time
from collections import defaultdict
from tkinter import END, Button, Entry, Label, Tk
from tkinter.filedialog import askopenfilename
from typing import Any, List

import pyperclip
from msedge.selenium_tools import Edge, EdgeOptions
from openpyxl import load_workbook
from rpa.config import CHROME_DRIVER_EXE_PATH
from rpa.fastrpa.adtable import RED, AdTable
from rpa.fastrpa.log import config
from rpa.fastrpa.sap.session import attach_sap, close_sap
from rpa.public.tools import ask_message, cel, cells, click_able
from rpa.ssc.hr.sap.export_1072 import enter_1072
from rpa.ssc.sap.query import export_query, query_selection
from selenium.common.exceptions import (TimeoutException,
                                        UnexpectedAlertPresentException)
from selenium.webdriver.common.by import By
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.support.wait import WebDriverWait
from win32com import client

HEADER_2 = ["VALUE1", "VALUE5", "VALUE6", "VALUE7", "VALUE8", "VALUE11", "VALUE9", "VALUE10", "VALUE26", "VALUE27",
            "VALUE28", "VALUE29", "VALUE30", "VALUE14", "VALUE15", "VALUE16", "VALUE17", "VALUE21", "VALUE33",
            "VALUE34", "VALUE35", "VALUE36", "VALUE38", "VALUE39", "VALUE40", "VALUE41", "TEXT41", "VALUE113",
            "VALUE114", "VALUE115", "VALUE116", "TEXT117", "VALUE118", "TEXT119", "TEXT120", "TEXT121", "TEXT122",
            "VALUE123", "VALUE124", "TEXT125", "TEXT126", "TEXT130", "TEXT131", "TEXT107", "VALUE524", "VALUE525",
            "VALUE526", "VALUE527", "TEXT528", "VALUE44", "VALUE45", "VALUE46", "VALUE47", "VALUE49", "VALUE50",
            "VALUE51", "VALUE138", "VALUE139", "VALUE140", "VALUE141", "VALUE142", "VALUE143", "VALUE279", "VALUE280",
            "VALUE281", "VALUE282", "TEXT283", "TEXT284", "TEXT285", "VALUE213", "VALUE214", "VALUE215", "VALUE216",
            "TEXT217", "TEXT218", "TEXT219", "TEXT220", "TEXT221", "TEXT222", "VALUE223", "VALUE224", "TEXT225",
            "TEXT226", "VALUE227", "VALUE405", "VALUE406", "VALUE407", "VALUE408", "VALUE409", "TEXT410", "TEXT411",
            "TEXT412", "VALUE593", "VALUE594", "VALUE595", "TEXT595", "TEXT596", "TEXT182"]

HEADER_3: List[str] = []

HEADER_4 = ['VALUE1', 'VALUE2', 'VALUE5', 'VALUE6', 'VALUE7', 'VALUE8', 'VALUE9', 'VALUE10', 'VALUE524', 'VALUE525',
            'VALUE526', 'VALUE527', 'TEXT528']


def getInput(title):
    def get_file(event):
        desk = os.path.join(os.path.expanduser("~"), "Desktop")
        f = askopenfilename(title=u'选择文件', initialdir=desk, filetypes=[("Excel", ".xlsx")])
        entry4.delete(0, END)
        entry4.insert(0, f)

    def return_callback(event):
        print('quit...')
        wind.quit()

    def close():
        wind.quit()
        # sys.exit()

    wind = Tk(className=title)
    wind.wm_attributes('-topmost', 1)
    screenwidth, screenheight = wind.maxsize()
    width = 190
    height = 110
    size = '%dx%d+%d+%d' % (width, height, (screenwidth - width) / 2, (screenheight - height) / 2)
    wind.geometry(size)
    wind.resizable(0, 0)
    Label(wind, text="用户名").grid(row=0, sticky="w")
    Label(wind, text="密码").grid(row=1, sticky="w")
    Label(wind, text="文件").grid(row=2, sticky="w")

    entry2 = Entry(wind)
    entry2.grid(row=0, column=1)
    entry3 = Entry(wind, show="*")
    entry3.grid(row=1, column=1)
    entry4 = Entry(wind, width=20)
    entry4.place(x=42, y=47, width=120)
    button = Button(text="浏览")
    button.bind('<Button-1>', get_file)
    button.place(x=162, y=47, width=30, height=20)
    button1 = Button(text="提交", width=10)
    button1.bind('<Button-1>', return_callback)
    button1.grid(row=3, columnspan=3, pady=5)
    wind.bind('<Return>', return_callback)
    entry2.focus_set()
    wind.protocol("WM_DELETE_WINDOW", close)
    wind.mainloop()
    user, password, file = entry2.get(), entry3.get(), entry4.get()
    wind.destroy()
    print(user, password, file)
    return user, password, file


def select_fn(session):
    print("重新勾选失败，请手动保存变式，程序退出")
    sys.exit()


def fill_107(session: Any, job_ids) -> None:
    """填充1072"""
    if isinstance(job_ids, list):
        try:
            session.findById("wnd[0]/usr/subSUB_MAIN:SAPLAQ_ADHOC:0212/subSUB_SELECTION:SAPLAQ_ADHOC:0310/cntlSEL_DEF_CONTAINER/shellcont/shell").currentCellColumn = "MORE_ICON"
            session.findById("wnd[0]/usr/subSUB_MAIN:SAPLAQ_ADHOC:0212/subSUB_SELECTION:SAPLAQ_ADHOC:0310/cntlSEL_DEF_CONTAINER/shellcont/shell").pressButtonCurrentCell()
        except Exception:
            session.findById("wnd[0]/usr/subSUB_MAIN:SAPLAQ_ADHOC:0212/subSUB_SELECTION:SAPLAQ_ADHOC:0310/cntlSEL_DEF_CONTAINER/shellcont/shell").setCurrentCell(1, "MORE_ICON")
            session.findById("wnd[0]/usr/subSUB_MAIN:SAPLAQ_ADHOC:0212/subSUB_SELECTION:SAPLAQ_ADHOC:0310/cntlSEL_DEF_CONTAINER/shellcont/shell").pressButtonCurrentCell()
        session.findById("wnd[1]/tbar[0]/btn[16]").press()
        pyperclip.copy('\r\n'.join(job_ids))  # 复制到剪切板
        session.findById("wnd[1]/tbar[0]/btn[24]").press()  # 粘贴
        session.findById("wnd[1]/tbar[0]/btn[8]").press()
    else:
        session.findById("wnd[0]/usr/subSUB_MAIN:SAPLAQ_ADHOC:0212/subSUB_SELECTION:SAPLAQ_ADHOC:0310/cntlSEL_DEF_CONTAINER/shellcont/shell").modifyCell(1, "LOW", job_ids)
    try:
        session.findById("wnd[0]/usr/subSUB_MAIN:SAPLAQ_ADHOC:0212/subSUB_APPLICATION:SAPLHR_QUERY_APPL_AREA:0122/subSUB:SAPLHR_QUERY_APPL_AREA:0121/btnDYNP121-EVALUATION_PERIOD_TEXT").press()
    except Exception:  # nosec
        pass
    session.findById("wnd[0]/usr/subSUB_MAIN:SAPLAQ_ADHOC:0212/subSUB_APPLICATION:SAPLHR_QUERY_APPL_AREA:0122/subSUB:SAPLHR_QUERY_APPL_AREA:0120/cmbDD_DATE").setFocus()
    session.findById("wnd[0]/usr/subSUB_MAIN:SAPLAQ_ADHOC:0212/subSUB_APPLICATION:SAPLHR_QUERY_APPL_AREA:0122/subSUB:SAPLHR_QUERY_APPL_AREA:0120/cmbDD_DATE").key = "8"
    cur_month = time.strftime("%Y%m01", time.localtime(time.time()))
    session.findById("wnd[0]/usr/subSUB_MAIN:SAPLAQ_ADHOC:0212/subSUB_APPLICATION:SAPLHR_QUERY_APPL_AREA:0122/subSUB:SAPLHR_QUERY_APPL_AREA:0120/ctxtG_APPL_AREA-BEGDA").text = cur_month
    session.findById("wnd[0]/usr/subSUB_MAIN:SAPLAQ_ADHOC:0212/subSUB_APPLICATION:SAPLHR_QUERY_APPL_AREA:0122/subSUB:SAPLHR_QUERY_APPL_AREA:0120/ctxtG_APPL_AREA-ENDDA").text = "9999.12.31"
    # session.findById("wnd[0]/usr/subSUB_MAIN:SAPLAQ_ADHOC:0212/subSUB_APPLICATION:SAPLHR_QUERY_APPL_AREA:0122/subSUB:SAPLHR_QUERY_APPL_AREA:0120/ctxtG_APPL_AREA-BEGDA").text = key_date
    session.findById("wnd[0]/usr/subSUB_MAIN:SAPLAQ_ADHOC:0212/subSUB_APPLICATION:SAPLHR_QUERY_APPL_AREA:0122/subSUB:SAPLHR_QUERY_APPL_AREA:0120/ctxtG_APPL_AREA-BEGDA").setFocus()
    session.findById("wnd[0]/usr/subSUB_MAIN:SAPLAQ_ADHOC:0212/subSUB_APPLICATION:SAPLHR_QUERY_APPL_AREA:0122/subSUB:SAPLHR_QUERY_APPL_AREA:0120/ctxtG_APPL_AREA-BEGDA").caretPosition = 10
    session.findById("wnd[0]/tbar[1]/btn[8]").press()


def export_excel(li, file, name, query_name, HEADER):
    if not li:
        return
    session = attach_sap()
    enter_1072(session)  # 进入1072信息集查询屏
    query_selection(session, query_name, select_fn, HEADER)  # 勾选1072选项
    fill_107(session, li)  # 填入员工编号和关键日期，并查询
    try:
        _table: AdTable = export_query(session, query_name=query_name)
        _table.filename = name
        _table.save_to(os.path.dirname(file))
    except Exception:  # nosec
        pass


def check_de(code, code_e):
    if not code.isdigit():
        return
    try:
        sap_gui_auto = client.GetObject("SAPGUI")
        application = sap_gui_auto.GetScriptingEngine
        connection = application.Children(0)
        session: Any = connection.Children(0)
        fill_107(session, code)  # 填入员工编号和关键日期，并查询
    except Exception:
        session = attach_sap()
        enter_1072(session)  # 进入1072信息集查询屏
        query_selection(session, "----T88", select_fn, HEADER_4)  # 勾选1072选项
        fill_107(session, code)  # 填入员工编号和关键日期，并查询
    sap_status = session.findById("wnd[0]/sbar/pane[0]").text
    time.sleep(10)
    if '未选取数据' in sap_status or '系统不能读取任何数据' in sap_status:
        return True
    table = session.findById("wnd[0]/usr/cntlGRID1/shellcont/shell")
    for x in range(table.rowCount):
        value = table.getCellValue(x, "P1000-OBJID")
        if str(value).strip() == code_e:
            session.findById("wnd[0]/tbar[0]/btn[3]").press()
            return
    else:
        session.findById("wnd[0]/tbar[0]/btn[3]").press()
        return True


def check_excel_file(r_file):
    wb = load_workbook(r_file)
    ws = wb.active
    count = len([x for x in range(2, len(ws["A"]) + 1) if ws[f"B{x}"].value])
    if ws["Q1"].value == f"{count}条数据校验通过":
        return True

    # 提取码表库中各项码值
    if "码表" in wb.sheetnames:
        ws_ = wb["码表"]
    else:
        return
    bp_vl = [x.value for x in ws_["BP"] if x.value]
    e_vl = [x.value for x in ws_["E"] if x.value]
    h_vl = [x.value for x in ws_["H"] if x.value]
    bx_vl = [x.value for x in ws_["BX"] if x.value]
    bw_vl = [x.value for x in ws_["BW"] if x.value]
    bw_vd = {ws_[f"BW{x}"].value: str(ws_[f"BV{x}"].value) for x in range(2, len(ws_["BW"]) + 1) if ws_[f"BW{x}"]}
    ar_vl = [x.value for x in ws_["AR"] if x.value]
    au_vl = [x.value for x in ws_["AU"] if x.value]
    cc_vl = [x.value for x in ws_["CC"] if x.value]

    # 导出组合逻辑查询1072、1073、1074表
    d_li = [str(x.value).strip()[:8] for x in ws["D"] if str(x.value).strip()[:8].isdigit()]
    e_li = [str(x.value).strip()[:8] for x in ws["E"] if str(x.value).strip()[:8].isdigit()]
    if d_li:
        export_excel(d_li, r_file, "1072", "----T87", HEADER_2)
    if e_li:
        export_excel(e_li, r_file, "1073", "----T87", HEADER_2)
    t_2, t_3, flag = [], {}, True
    if os.path.exists(os.path.dirname(r_file) + "/1072.xlsx"):
        _ws = load_workbook(os.path.dirname(r_file) + "/1072.xlsx").active
        t_2 = [str(x.value).strip() for x in _ws["A"] if x.value]
        os.remove(os.path.dirname(r_file) + "/1072.xlsx")

    if os.path.exists(os.path.dirname(r_file) + "/1073.xlsx"):
        _ws = load_workbook(os.path.dirname(r_file) + "/1073.xlsx").active
        t_3 = {str(_ws[f"A{x}"].value).strip(): str(_ws[f"AW{x}"].value).strip().replace("None", "") for x in range(2, len(_ws["A"]) + 1)}
        os.remove(os.path.dirname(r_file) + "/1073.xlsx")

    d_li = defaultdict(bool)
    for i in range(2, len(ws["A"]) + 1):
        if not ws[f"B{i}"].value:
            continue
        # 校验【机构编码申请模板-【B至 L】】的值是否全都不为空。
        for j in range(2, 13):
            if not ws.cell(i, j).value:
                cells(ws, (i, j), "必填项不能为空", RED)
                flag = False

        # 校验【机构编码申请模板-【B-单位简称】】值的长度是否小于等于12。
        if len(str(ws[f"B{i}"].value)) > 12:
            cells(ws, f"B{i}", "单位简称超过12个字符！", RED)
            flag = False

        # 校验【机构编码申请模板 -【C - 单位全称】】值的长度是否小于等于40。
        if len(str(ws[f"C{i}"].value)) > 40:
            cells(ws, f"B{i}", "单位全称超过40个字符！", RED)
            flag = False

        # 去除【机构编码申请模板-【D-隶属上级机构】】的空格并保存，校验其前8位是否全为数字，且长度等于8。
        ws[f"D{i}"] = str(ws[f"D{i}"].value).replace(" ", "").replace("None", "")
        if not (str(ws[f"D{i}"].value)[:8].isdigit() and len(str(ws[f"D{i}"].value)[:8]) == 8):
            cells(ws, f"D{i}", "隶属上级机构的编码有误！", RED)
            flag = False

        # 去除【机构编码申请模板-【E-隶属直属机构】】的空格并保存，校验其前8位是否全为数字，且长度等于8。
        ws[f"E{i}"] = str(ws[f"E{i}"].value).replace(" ", "").replace("None", "")
        if not (str(ws[f"E{i}"].value)[:8].isdigit() and len(str(ws[f"E{i}"].value)[:8]) == 8):
            cells(ws, f"E{i}", "隶属直属机构的编码有误！", RED)
            flag = False

        # 校验【机构编码申请模板-【F-人事单位层次】】的值是否是【码表-【BP】】的值。
        if str(ws[f"F{i}"].value).replace(" ", "") not in bp_vl:
            cells(ws, f"F{i}", "人事单位层次非码值！", RED)
            flag = False

        # 校验【机构编码申请模板-【G-上市标识】】的值是否是【码表-【E】】的值。
        if str(ws[f"G{i}"].value).replace(" ", "") not in e_vl:
            cells(ws, f"G{i}", "上市标识非码值！", RED)
            flag = False

        # 校验【机构编码申请模板-【H-虚机构标识】】的值是否是【码表-【H】】的值。
        if str(ws[f"H{i}"].value).replace(" ", "") not in h_vl:
            cells(ws, f"H{i}", "虚机构标识非码值！", RED)
            flag = False

        # 校验【机构编码申请模板-【I-地区】】的值是否是【码表-【BV】】的值。
        tmp_l = [x for x in bx_vl if str(ws[f"I{i}"].value).replace(" ", "") in x]
        if tmp_l:
            ws[f"I{i}"] = tmp_l[0]
        if str(ws[f"I{i}"].value).replace(" ", "") not in bx_vl:
            cells(ws, f"I{i}", "地区非码值！", RED)
            flag = False

        # 校验【机构编码申请模板-【J-城市】】的值是否是【码表-【BW】】的值；
        # 提取【码表-【BV】】的值，检验其与【机构编码申请模板-【I-地区】】的值是否相同。
        tmp_l = [x for x in bw_vl if str(ws[f"J{i}"].value).replace(" ", "") in x]
        if tmp_l:
            ws[f"J{i}"] = tmp_l[0]
        if str(ws[f"J{i}"].value).replace(" ", "") not in bw_vl:
            cells(ws, f"J{i}", "城市非码值！", RED)
            flag = False
        elif str(ws[f"I{i}"].value).replace(" ", "") not in bw_vd[str(ws[f"J{i}"].value).replace(" ", "")]:
            cells(ws, f"I{i}", "地区与城市不对应！", RED)
            flag = False

        # 校验【机构编码申请模板-【K-通讯地址】】值的长度是否小于等于200。
        if len(str(ws[f"K{i}"].value)) > 200:
            cells(ws, f"K{i}", "通讯地址超过200个字符！", RED)
            flag = False

        # 校验【机构编码申请模板-【L-邮政编码】】的值是否全为数字，且长度等于6。
        if len(str(ws[f"L{i}"].value)) != 6 or not str(ws[f"L{i}"].value).isdigit():
            cells(ws, f"L{i}", "邮政编码有误！", RED)
            flag = False

        # 若【机构编码申请模板 -【M至O】】任一单元格不为空，检验【M至O】是否全都有值
        if not ws[f"M{i}"].value and (ws[f"N{i}"].value or ws[f"O{i}"].value):
            cells(ws, f"M{i}", "不能为空！", RED)
            flag = False
        if not ws[f"N{i}"].value and (ws[f"M{i}"].value or ws[f"O{i}"].value):
            cells(ws, f"N{i}", "不能为空！", RED)
            flag = False
        if not ws[f"O{i}"].value and (ws[f"N{i}"].value or ws[f"M{i}"].value):
            cells(ws, f"O{i}", "不能为空！", RED)
            flag = False

        # 校验【机构编码申请模板-【M-单位业务类型】】的值是否是【码表-【AR】】的值。
        if ws[f"M{i}"].value and ws[f"M{i}"].value not in ar_vl:
            cells(ws, f"M{i}", "单位业务类型有误！", RED)
            flag = False

        # 校验【机构编码申请模板-【N-产权属性】】的值是否是【码表-【AU】】的值。
        if ws[f"N{i}"].value and ws[f"N{i}"].value not in au_vl:
            cells(ws, f"N{i}", "产权属性有误！", RED)
            flag = False

        # 校验【机构编码申请模板-【O-成本中心代码】】的值是否是10位英文+数字。
        if ws[f"O{i}"].value and len(str(ws[f"O{i}"].value)) != 10:
            cells(ws, f"O{i}", "成本中心代码有误！", RED)
            flag = False

        if not t_2:
            cells(ws, f"D{i}", "上级机构编码有误！", RED)
            flag = False
        elif str(ws[f"D{i}"].value).strip()[:8] not in t_2:
            cells(ws, f"D{i}", "隶属上级机构编码有误！", RED)
            flag = False

        if not t_3:
            cells(ws, f"E{i}", "直属机构编码有误！", RED)
            flag = False
        elif str(ws[f"E{i}"].value).strip()[:8] not in t_3.keys():
            cells(ws, f"E{i}", "隶属直属机构有误！", RED)
            flag = False
        if t_3 and str(ws[f"E{i}"].value).strip()[:8] in t_3.keys():
            if t_3[str(ws[f"E{i}"].value).strip()[:8]] not in cc_vl:
                cells(ws, f"E{i}", "请勿选择中层及以下级别的机构，应选择直属及其以上级别的机构！", RED)
                flag = False
        print(str(ws[f"D{i}"].value)[:8], d_li.keys())
        if str(ws[f"D{i}"].value)[:8] not in d_li.keys():
            if check_de(str(ws[f"D{i}"].value)[:8], str(ws[f"E{i}"].value)[:8]):
                cells(ws, f"E{i}", "隶属上级机构与隶属直属机构不对应！", RED)
                flag = False
                d_li[str(ws[f"D{i}"].value)[:8]] = True
            else:
                d_li[str(ws[f"D{i}"].value)[:8]] = False
        elif d_li[str(ws[f"D{i}"].value)[:8]]:
            cells(ws, f"E{i}", "隶属上级机构与隶属直属机构不对应！", RED)
            flag = False

        if cel(ws, f"D{i}") == "10010000":
            cells(ws, f"D{i}", "隶属上级机构编码不能为10010000！", RED)
            flag = False

        if cel(ws, f"E{i}") == "10010000":
            cells(ws, f"E{i}", "隶属直属机构编码不能为10010000！", RED)
            flag = False
    if flag:
        ws["Q1"] = f"{count}条数据校验通过"
    wb.save(r_file)
    close_sap()
    return flag


def start_edge(username="", password=""):  # nosec
    options = EdgeOptions()
    if not username or not password:
        options.use_chromium = True
        # options.debugger_address = "localhost:9222"
        options.add_argument(r'--user-data-dir=C:\Users\jinjf\AppData\Local\Microsoft\Edge\User Data - 副本 (3)')
        options.binary_location = r"C:\Program Files (x86)\Microsoft\Edge\Application\msedge.exe"
    # browser = webdriver.Chrome(executable_path=CHROME_DRIVER_EXE_PATH, options=options)
    browser = Edge(executable_path=CHROME_DRIVER_EXE_PATH, options=options)
    if username or password:
        browser.get("http://infostd.sinopec.com/Material.jsp")
    browser.maximize_window()
    # browser.refresh()
    print(browser.title)
    wait = WebDriverWait(browser, 20)
    try:
        if username or password:
            wait.until(lambda x: x.find_element_by_xpath('//*[@id="j_username"]')).send_keys(username)
            wait.until(lambda x: x.find_element_by_xpath('//*[@id="j_password"]')).send_keys(password)
            wait.until(lambda x: x.find_element_by_xpath('//*[@id="authen1Form"]/button')).click()
        WebDriverWait(browser, 5).until(
            EC.frame_to_be_available_and_switch_to_it((By.XPATH, '//*[@id="null,10000395-body"]/iframe')))
        wait.until(EC.frame_to_be_available_and_switch_to_it((By.XPATH, '//*[@id="ivuFrm_page0ivu0"]')))
        wait.until(EC.frame_to_be_available_and_switch_to_it((By.XPATH, '//*[@id="isolatedWorkArea"]')))
        wait.until(lambda x: x.find_element_by_xpath(
            '//*[@id="aaabPGFG.InnersV3DetailView.TabStrip-tbl"]/tbody/tr/td[2]/span/span/span')).click()
        wait.until(EC.frame_to_be_available_and_switch_to_it((By.XPATH, '//*[@id="ivuFrm_page0ivu0"]')))
        wait.until(EC.frame_to_be_available_and_switch_to_it((By.XPATH, '//*[@id="isolatedWorkArea"]')))
    except Exception:
        try:
            WebDriverWait(browser, 5).until(lambda x: x.find_element_by_xpath('//*[text()="信息代码在线管理"]')).click()
        except (UnexpectedAlertPresentException, TimeoutException):
            ask_message("提示", "请刷新浏览器后重启程序！")
            sys.exit()
        click_able(browser, '//*[text()="内部单位"]')
        time.sleep(2)
        wait.until(lambda x: x.find_element_by_xpath('//*[@id="treeview-1020-record-10000146"]/td/div/span')).click()
        time.sleep(1)
        wait.until(lambda x: x.find_element_by_xpath('//*[@id="treeview-1020-record-10000395"]/td/div/span')).click()
        time.sleep(5)
        wait.until(EC.frame_to_be_available_and_switch_to_it((By.XPATH, '//*[@id="null,10000395-body"]/iframe')))
        wait.until(EC.frame_to_be_available_and_switch_to_it((By.XPATH, '//*[@id="ivuFrm_page0ivu0"]')))
        wait.until(EC.frame_to_be_available_and_switch_to_it((By.XPATH, '//*[@id="isolatedWorkArea"]')))
    return browser


def read_excel(r_file, browser):
    wb = load_workbook(r_file)
    ws = wb.active
    v_dict = defaultdict(list)
    for i in range(2, len(ws["A"]) + 1):
        v_list = [str(x.value).strip().replace("None", "") for x in ws[f"B{i}:Q{i}"][0]]
        v_dict[i] = [x.value for x in ws[f"B{i}:Q{i}"][0]]
        if ws[f"P{i}"].value or not ws[f"B{i}"].value:
            continue
        print(v_list)
        code, res = open_edge(v_list, browser)
        if res:
            if ws[f"Q{i}"].value and str(ws[f"Q{i}"].value).isdigit():
                ws[f"Q{i}"] = int(ws[f"Q{i}"].value) + 1
            else:
                ws[f"Q{i}"] = 1
        else:
            ws[f"P{i}"] = code
        wb.save(r_file)
        # break
    return v_dict


def open_edge(v_list, browser):
    wait = WebDriverWait(browser, 40)
    click_able(browser, '//*[@id="aaabPGFG.InnersV3DetailView.TabStrip-tbl"]/tbody/tr/td[2]/span/span/span')
    # wait.until(lambda x: x.find_element_by_xpath(
    #     '//*[@id="aaabPGFG.InnersV3DetailView.TabStrip-tbl"]/tbody/tr/td[2]/span/span/span')).click()
    time.sleep(1)
    label1 = wait.until(lambda x: x.find_element_by_xpath(
        '//*[@id="aaabPGFG.InnersV3DetailView.TabStrip-tbl"]/tbody/tr/td[4]/span/span/span')).text
    if "人事视图" not in label1:
        wait.until(lambda x: x.find_element_by_xpath('//*[@id="aaabPGFG.InnersV3DetailView.HR_Flag-img"]')).click()

    time.sleep(2)
    label2 = wait.until(lambda x: x.find_element_by_xpath(
        '//*[@id="aaabPGFG.InnersV3DetailView.TabStrip-tbl"]/tbody/tr/td[6]/span/span/span')).text
    if (v_list[11] and "销售视图" not in label2) or (not v_list[11] and "销售视图" in label2):
        print(label2)
        wait.until(lambda x: x.find_element_by_xpath('//*[@id="aaabPGFG.InnersV3DetailView.SD_Flag-img"]')).click()
    time.sleep(1)
    # 单位全称
    wait.until(lambda x: x.find_element_by_xpath('//*[@id="aaabPGFG.InnersV3DetailView.full_Name"]')).clear()
    wait.until(lambda x: x.find_element_by_xpath('//*[@id="aaabPGFG.InnersV3DetailView.full_Name"]')).send_keys(
        v_list[1])

    # 单位简称
    wait.until(lambda x: x.find_element_by_xpath('//*[@id="aaabPGFG.InnersV3DetailView.short_Name"]')).clear()
    wait.until(lambda x: x.find_element_by_xpath('//*[@id="aaabPGFG.InnersV3DetailView.short_Name"]')).send_keys(
        v_list[0])

    # 上市标识
    wait.until(lambda x: x.find_element_by_xpath('//*[@id="aaabPGFG.InnersV3DetailView.Listed_Flag_Button"]')).click()
    wait.until(lambda x: x.find_element_by_xpath(
        '//*[@id="aaabPGFGPHLI.CommonPickupListV2View.TableList.2147483643"]')).send_keys(f"{v_list[5]}\n")
    click_able(browser, '//*[@id="aaabPGFGPHLI.CommonPickupListV2View.ToolBarItems"]')

    # 虚实单位标识
    click_able(browser, '//*[@id="aaabPGFG.InnersV3DetailView.VitCo_Flag_Button"]')
    wait.until(lambda x: x.find_element_by_xpath(
        '//*[@id="aaabPGFGPHLI.CommonPickupListV2View.TableList.2147483643"]')).send_keys(f"{v_list[6]}\n")
    click_able(browser, '//*[@id="aaabPGFGPHLI.CommonPickupListV2View.ToolBarItems"]')

    # 所属地区
    click_able(browser, '//*[@id="aaabPGFG.InnersV3DetailView.Region_Button"]')
    wait.until(lambda x: x.find_element_by_xpath(
        '//*[@id="aaabPGFGPHLI.CommonPickupListV2View.TableList.2147483643"]')).send_keys(f"{v_list[8]}\n")
    click_able(browser, '//*[@id="aaabPGFGPHLI.CommonPickupListV2View.ToolBarItems"]')

    # 地区
    click_able(browser, '//*[@id="aaabPGFG.InnersV3DetailView.Area_Button"]')
    wait.until(lambda x: x.find_element_by_xpath(
        '//*[@id="aaabPGFGPHLI.CommonPickupListV2View.TableList.2147483643"]')).send_keys(f"{v_list[7]}\n")
    click_able(browser, '//*[@id="aaabPGFGPHLI.CommonPickupListV2View.ToolBarItems"]')

    # 城市
    click_able(browser, '//*[@id="aaabPGFG.InnersV3DetailView.city"]')
    wait.until(lambda x: x.find_element_by_xpath('//*[@id="aaabPGFG.InnersV3DetailView.city"]')).clear()
    wait.until(lambda x: x.find_element_by_xpath('//*[@id="aaabPGFG.InnersV3DetailView.city"]')).send_keys(v_list[8])

    # 通讯地址
    click_able(browser, '//*[@id="aaabPGFG.InnersV3DetailView.address"]')
    wait.until(lambda x: x.find_element_by_xpath('//*[@id="aaabPGFG.InnersV3DetailView.address"]')).clear()
    wait.until(lambda x: x.find_element_by_xpath('//*[@id="aaabPGFG.InnersV3DetailView.address"]')).send_keys(v_list[9])

    # 邮政编码
    click_able(browser, '//*[@id="aaabPGFG.InnersV3DetailView.post_Code"]')
    wait.until(lambda x: x.find_element_by_xpath('//*[@id="aaabPGFG.InnersV3DetailView.post_Code"]')).clear()
    wait.until(lambda x: x.find_element_by_xpath('//*[@id="aaabPGFG.InnersV3DetailView.post_Code"]')).send_keys(
        v_list[10])
    # wait.until(lambda x: x.find_element_by_xpath('//*[@id="aaabPGFGPHLI.CommonPickupListV2View.ToolBarItems"]')).click()
    time.sleep(0.5)

    # 人事视图
    # wait.until(lambda x: x.find_element_by_xpath('//*[@id="aaabPGFG.InnersV3DetailView.HR_Flag-img"]')).click()
    wait.until(lambda x: x.find_element_by_xpath(
        '//*[@id="aaabPGFG.InnersV3DetailView.TabStrip-tbl"]/tbody/tr/td[4]/span/span/span')).click()

    # 隶属直属单位
    click_able(browser, '//*[@id="aaabPGFG.InnersV3DetailView.HR_First_Class_Button"]')
    wait.until(lambda x: x.find_element_by_xpath(
        '//*[@id="aaabPGFGIFJH.CommonPickupListMainTableView._5"]')).send_keys(f"{v_list[3][:8]}\n")
    click_able(browser, '//*[@id="aaabPGFGIFJH.CommonPickupListMainTableView.Confirm_ToolBarItems"]')

    # 隶属上级单位
    click_able(browser, '//*[@id="aaabPGFG.InnersV3DetailView.HR_Superior_Class_Button"]')
    wait.until(lambda x: x.find_element_by_xpath(
        '//*[@id="aaabPGFGIFJH.CommonPickupListMainTableView._5"]')).send_keys(f"{v_list[2][:8]}\n")
    click_able(browser, '//*[@id="aaabPGFGIFJH.CommonPickupListMainTableView.Confirm_ToolBarItems"]')

    # 人事单位层次
    click_able(browser, '//*[@id="aaabPGFG.InnersV3DetailView.HR_Unit_Level_Button"]')
    wait.until(lambda x: x.find_element_by_xpath(
        '//*[@id="aaabPGFGPHLI.CommonPickupListV2View.TableList.2147483643"]')).send_keys(f"{v_list[4]}\n")
    click_able(browser, '//*[@id="aaabPGFGPHLI.CommonPickupListV2View.ToolBarItems"]')
    # click_able(browser, '//*[@id="aaabPGFG.InnersV3DetailView.post_Code"]')

    if v_list[11]:
        # 销售视图
        time.sleep(1)
        wait.until(lambda x: x.find_element_by_xpath(
            '//*[@id="aaabPGFG.InnersV3DetailView.TabStrip-tbl"]/tbody/tr/td[6]/span/span/span')).click()

        # 单位业务类型
        click_able(browser, '//*[@id="aaabPGFG.InnersV3DetailView.SD_Business_Class_Button"]')
        wait.until(lambda x: x.find_element_by_xpath(
            '//*[@id="aaabPGFGPHLI.CommonPickupListV2View.TableList.2147483643"]')).send_keys(f"{v_list[11]}\n")
        click_able(browser, '//*[@id="aaabPGFGPHLI.CommonPickupListV2View.ToolBarItems"]')

        # 产权属性
        click_able(browser, '//*[@id="aaabPGFG.InnersV3DetailView.Station_Property_Button"]')
        wait.until(lambda x: x.find_element_by_xpath(
            '//*[@id="aaabPGFGPHLI.CommonPickupListV2View.TableList.2147483643"]')).send_keys(f"{v_list[12]}\n")
        click_able(browser, '//*[@id="aaabPGFGPHLI.CommonPickupListV2View.ToolBarItems"]')

        # 成本中心代码
        click_able(browser, '//*[@id="aaabPGFG.InnersV3DetailView.costCenter_Code"]')
        wait.until(lambda x: x.find_element_by_xpath('//*[@id="aaabPGFG.InnersV3DetailView.costCenter_Code"]')).clear()
        wait.until(lambda x: x.find_element_by_xpath('//*[@id="aaabPGFG.InnersV3DetailView.costCenter_Code"]')).send_keys(v_list[13])

    # 提交
    click_able(browser, '//*[@id="aaabPGFG.InnersV3DetailView.Submit_TBButton"]')
    # wait.until(EC.frame_to_be_available_and_switch_to_it((By.XPATH, '//*[@id="aaabPGFGBJBK4f"]/iframe')))
    # wait.until(lambda x: x.find_element_by_xpath('//*[@id="aaabPGFG.InnersV3DetailView.address"]')).clear()
    click_able(browser, '//*[text()="确认"]')
    text = WebDriverWait(browser, 240).until(lambda x: x.find_element_by_xpath('//*[@id="aaab.CreateFrameWorkViewV2.MessageArea-txt"]')).text
    click_able(browser, '//*[@id="aaabPGFG.InnersV3DetailView.Create_TBButton"]')
    print(text)
    return text, ""


def main():
    file = r"C:\Users\jinjf\Desktop\20201106-高韧.xlsx"
    username, password = "", ""
    username, password, file = getInput("输入账号密码")
    if not username or not password or not file:
        logging.info("账号、密码和文件路径输入不全")
        return
    result = check_excel_file(file)
    print(result)
    if result:
        browser = start_edge(username=username, password=password)
        read_excel(file, browser)


if __name__ == "__main__":
    config()
    main()
