"""FIXME: 程序仍存在问题，进入概览屏对比数据结果是否一致时，出现特殊情况"""
import logging
import os
from pathlib import Path
from time import sleep
from typing import List

import rpa.config
from rpa.fastrpa.log import config, logfn
from rpa.fastrpa.obs.obs import OBS_REC
from rpa.fastrpa.path import to_windows_path_format
from rpa.fastrpa.sap.gui_tab_strip import GuiTabStrip
from rpa.fastrpa.sap.gui_table_control import GuiTableControl
from rpa.fastrpa.sap.session import (SAP, SapSession, close_sap,
                                     get_all_children_ids)
from rpa.ssc.sap.utils import init_sap_id


def enter_pa20(session: SapSession, staff_id: str):
    session.findById("wnd[0]").maximize()
    session.findById("wnd[0]/tbar[0]/okcd").text = "/n pa20"
    session.findById("wnd[0]").sendVKey(0)
    session.findById("wnd[0]/usr/ctxtRP50G-PERNR").text = staff_id  # 人员编号
    session.findById("wnd[0]/usr/ctxtRP50G-PERNR").caretPosition = 8
    session.findById("wnd[0]").sendVKey(0)
    sap_status = session.findById("wnd[0]/sbar/pane[0]").text
    if sap_status != '':
        logging.error(sap_status)  # 人员编号有误
        raise Exception(sap_status)


def enter_pa30(session: SapSession, staff_id: str):
    session.findById("wnd[0]").maximize()
    session.findById("wnd[0]/tbar[0]/okcd").text = "/n pa30"
    session.findById("wnd[0]").sendVKey(0)
    session.findById("wnd[0]/usr/ctxtRP50G-PERNR").text = staff_id  # 人员编号
    session.findById("wnd[0]/usr/ctxtRP50G-PERNR").caretPosition = 8
    session.findById("wnd[0]").sendVKey(0)
    sap_status = session.findById("wnd[0]/sbar/pane[0]").text
    if sap_status != '':
        logging.error(sap_status)  # 人员编号有误
        raise Exception(sap_status)


def save_pa30(session: SapSession) -> bool:
    session.findById("wnd[0]").sendVKey(0)
    session.findById("wnd[0]").sendVKey(0)  # 2次回车，刷新码值对应的文本
    session.findById("wnd[0]/tbar[0]/btn[11]").press()  # 保存
    sap_status = ''
    for i in range(10):
        sap_status = session.findById("wnd[0]/sbar/pane[0]").text
        if '记录已创建' in sap_status:
            return True
        else:
            sleep(0.2)
            session.findById("wnd[0]").sendVKey(0)  # 回车
    try:
        if '学历学位 (0022) 创建' in session.findById("wnd[1]").Text:  # 是否设置为最高学历
            session.findById("wnd[1]/usr/btnBUTTON_2").press()  # 点击否
            sap_status = session.findById("wnd[0]/sbar/pane[0]").text
            if '记录已创建' in sap_status:
                return True
    except Exception:  # nosec
        pass
    logging.error(f'PA30 保存失败，状态栏消息：{sap_status}')
    if '记录已创建' not in sap_status and sap_status.strip(' ') != '':  # 原屏修改保存时，SAP状态栏信息为空
        session.findById("wnd[0]/tbar[0]/btn[12]").press()  # 取消
        try:
            session.findById("wnd[1]/usr/btnSPOP-OPTION1").press()  # 是
        except Exception:  # nosec 还有可能直接取消，不需要确认
            pass
    return False


def copy_field(pa20_session: SapSession, pa30_session: SapSession, id: str):
    """复制单个元素状态"""
    try:
        type_str = pa20_session.findById(id).Type
        if type_str in ('GuiCTextField', 'GuiTextField') and pa30_session.findById(id).Changeable is True:  # 输入框
            pa30_session.findById(id).text = pa20_session.findById(id).text
        elif type_str == 'GuiComboBox' and pa30_session.findById(id).Changeable is True:  # 下拉选择框
            pa30_session.findById(id).value = pa20_session.findById(id).value
        elif type_str == 'GuiCheckBox' and pa30_session.findById(id).Changeable is True:  # 复选框
            pa30_session.findById(id).selected = pa20_session.findById(id).selected
        elif type_str == 'GuiRadioButton' and pa30_session.findById(id).Changeable is True:  # 单选框
            pa30_session.findById(id).selected = pa20_session.findById(id).selected
        else:
            pass
    except Exception:  # nosec
        pass


def copy_ming_xi(pa20_session: SapSession, pa30_session: SapSession, route_path: List[str]):
    """复制数据明细"""
    Path('f:/国家管网').mkdir(parents=True, exist_ok=True)
    pa20_screenshot = to_windows_path_format(Path(f'{rpa.config.RPA_SCREENSHOTS_DIR}/国家管网/').joinpath('#'.join(route_path) + '_pa20.bmp').as_posix())
    pa30_screenshot = to_windows_path_format(Path(f'{rpa.config.RPA_SCREENSHOTS_DIR}/国家管网/').joinpath('#'.join(route_path) + '_pa30.bmp').as_posix())
    log_prefix = '[' + '#'.join(route_path) + ']'
    if Path(pa30_screenshot).exists() is True:  # 已经做过了，点击取消保存
        pa30_session.findById("wnd[0]/tbar[0]/btn[12]").press()  # 取消
        try:
            pa30_session.findById("wnd[1]/usr/btnSPOP-OPTION1").press()  # 是
        except Exception:  # nosec 还有可能直接取消，不需要确认
            pass
        logging.info(f'{log_prefix}记录已创建，PA30取消保存')
    else:
        children_ids = get_all_children_ids(pa20_session)
        for id in children_ids:
            copy_field(pa20_session, pa30_session, id)
        logging.info(f'{log_prefix}复制完成')
        if '专长信息' in route_path:  # 专长信息特殊处理
            pa30_session.findById("wnd[0]/usr/txtP9207-ZZ_ZCSM").text = "其他"  # 专长说明
            try:
                pa30_session.findById("wnd[0]/usr/txtP9207-ZZ_BZ").text = "其他"  # 备注
            except Exception:  # nosec
                pass  # 有的没有备注字段
        if '兼任职务信息' in route_path:  # 专长信息特殊处理
            pa30_session.findById("wnd[0]/usr/txtP9242-ZZ_BZ").text = "其他"  # 备注
        if '语言能力' in route_path:
            pa30_session.findById("wnd[0]/usr/txtP9205-ZZ_BZ").text = "其他"  # 备注
        if '社会(学术)团体任职信息' in route_path:
            pa30_session.findById("wnd[0]/usr/txtP9208-ZZ_BZ").text = "其他"  # 备注
        pa30_session.findById("wnd[0]").sendVKey(0)
        pa30_session.findById("wnd[0]").sendVKey(0)  # 2次回车，刷新码值对应的文本
        pa20_session.findById('wnd[0]').HardCopy(pa20_screenshot)  # 屏幕截图
        pa30_session.findById('wnd[0]').HardCopy(pa30_screenshot)
        if save_pa30(pa30_session) is True:  # PA30 保存
            logging.info(f'{log_prefix}PA30保存成功')
        else:
            os.remove(pa20_screenshot)  # 保存失败，移除截图文件
            os.remove(pa30_screenshot)
            logging.error(f'{log_prefix}PA30保存失败')
    pa20_session.findById("wnd[0]/tbar[0]/btn[3]").press()  # PA20 点击[返回]


def copy_gai_lan(pa20_session: SapSession, pa30_session: SapSession, route_path: List[str]):
    """复制概览屏"""
    pa20_session.findById("wnd[0]/tbar[1]/btn[20]").press()  # 点击[概览]按钮
    log_prefix = '[' + '#'.join(route_path) + ']'
    logging.info(log_prefix + pa20_session.findById('wnd[0]').Text)
    for child in pa20_session.findById('wnd[0]/usr').Children:
        if child.Type == 'GuiTableControl':  # GuiTableControl会变，要动态获取
            pa20_gui_table_control_id = child.id.replace(pa20_session.id + '/', '')
            pa20_gui_table_control = GuiTableControl(pa20_session, pa20_gui_table_control_id)
            for idx, pa20_gui_table_control_row in enumerate(pa20_gui_table_control.rows, start=1):
                Path('f:/国家管网').mkdir(parents=True, exist_ok=True)
                pa30_screenshot = to_windows_path_format(Path(f'{rpa.config.RPA_SCREENSHOTS_DIR}/国家管网/').joinpath('#'.join(route_path + [str(idx)]) + '_pa30.bmp').as_posix())
                if Path(pa30_screenshot).exists() is True:
                    logging.info(f'{log_prefix}记录已创建，跳过该行复制')
                    continue
                logging.info(f'{log_prefix}进入概览屏，准备复制第{idx}条记录')
                pa20_gui_table_control_row[1].select_row()
                info_types = [{'信息类型': '家庭成员及社会关系', 'STy': '11'},
                              {'信息类型': '通讯信息', 'STy': '0001'},
                              {'信息类型': '行政党派职务信息', 'STy': '0001'},
                              {'信息类型': '专家称号信息', 'STy': '10'},
                              {'信息类型': '员工参加培训班信息', 'STy': '1'},
                              {'信息类型': '简历', 'STy': '1'},
                              {'信息类型': '兼任职务信息', 'STy': '1'},
                              {'信息类型': '语言能力', 'STy': '0001'},
                              {'信息类型': '拟调出人员信息', 'STy': '0001'}, ]
                for info_type in info_types:
                    if info_type['信息类型'] in route_path[-1]:
                        pa30_session.findById('wnd[0]/usr/tabsMENU_TABSTRIP/tabpTAB01/ssubSUBSCR_MENU:SAPMP50A:0400/subSUBSCR_ITKEYS:SAPMP50A:0350/ctxtRP50G-CHOIC').text = info_type['信息类型']
                        pa30_session.findById('wnd[0]/usr/tabsMENU_TABSTRIP/tabpTAB01/ssubSUBSCR_MENU:SAPMP50A:0400/subSUBSCR_ITKEYS:SAPMP50A:0350/ctxtRP50G-SUBTY').text = info_type['STy']  # 填充占位符
                pa30_session.findById("wnd[0]/tbar[1]/btn[5]").press()  # PA30 点击[创建]按钮
                is_unknown_info_type = False
                try:
                    pa30_session.findById("wnd[1]")  # 未知的信息类型
                    pa30_session.findById("wnd[1]/tbar[0]/btn[12]").press()  # 点击取消
                    logging.error('开发时未遇到的信息类型，跳过复制本行，后续请手工操作')
                    is_unknown_info_type = True
                except Exception:  # nosec
                    pass
                if is_unknown_info_type is True:
                    continue  # 跳过这一行
                else:
                    sap_status = pa30_session.findById("wnd[0]/sbar/pane[0]").text
                    if sap_status != '':
                        logging.error(f'{log_prefix}PA30新建操作报错，跳过处理。错误信息：{sap_status}')
                    else:
                        pa20_session.findById("wnd[0]/tbar[1]/btn[2]").press()  # PA20 点击[选择]按钮
                        copy_ming_xi(pa20_session, pa30_session, route_path + [str(idx)])
            pa20_session.findById("wnd[0]/tbar[0]/btn[3]").press()  # PA20 点击[返回]
            break


def check_gai_lan(pa20_session: SapSession, pa30_session: SapSession, route_path: List[str]) -> bool:
    """检查PA20概览屏数据量与PA30数据量是否一致
    """
    if pa20_session.findById("wnd[0]").Text != '显示人力资源主数据':
        return False
    if pa30_session.findById("wnd[0]").Text != '维护人力资源主数据':
        return False
    pa20_session.findById("wnd[0]/usr/tabsMENU_TABSTRIP/tabpTAB01/ssubSUBSCR_MENU:SAPMP50A:0400/subSUBSCR_ITKEYS:SAPMP50A:0350/ctxtRP50G-SUBTY").text = ""  # STy置空
    pa30_session.findById("wnd[0]/usr/tabsMENU_TABSTRIP/tabpTAB01/ssubSUBSCR_MENU:SAPMP50A:0400/subSUBSCR_ITKEYS:SAPMP50A:0350/ctxtRP50G-SUBTY").text = ""  # STy置空
    pa20_session.findById("wnd[0]/tbar[1]/btn[20]").press()  # PA20 点击[概览]按钮
    pa30_session.findById("wnd[0]/tbar[1]/btn[20]").press()  # PA30 点击[概览]按钮
    Path('f:/国家管网/概览').mkdir(parents=True, exist_ok=True)
    pa20_gai_lan_screenshot = to_windows_path_format(Path(f'{rpa.config.RPA_SCREENSHOTS_DIR}/国家管网/概览').joinpath('#'.join(route_path) + '_pa20.bmp').as_posix())
    pa30_gai_lan_screenshot = to_windows_path_format(Path(f'{rpa.config.RPA_SCREENSHOTS_DIR}/国家管网/概览').joinpath('#'.join(route_path) + '_pa30.bmp').as_posix())
    pa20_session.findById('wnd[0]').HardCopy(pa20_gai_lan_screenshot)  # 屏幕截图
    pa30_session.findById('wnd[0]').HardCopy(pa30_gai_lan_screenshot)
    try:
        pa30_session.findById("wnd[0]/usr/txtRP50M-PAGEC").text
    except Exception:
        logging.error('pause')
        return False
    if pa20_session.findById("wnd[0]/usr/txtRP50M-PAGEC").text == pa30_session.findById("wnd[0]/usr/txtRP50M-PAGEC").text:  # 数据量一致
        os.remove(pa20_gai_lan_screenshot)
        os.remove(pa30_gai_lan_screenshot)
        pa20_session.findById("wnd[0]/tbar[0]/btn[12]").press()  # PA20 点击[取消]按钮
        pa30_session.findById("wnd[0]/tbar[0]/btn[12]").press()  # PA30 点击[取消]按钮
        return True
    # 数据量不一致时，查找不一致的行，并报错
    pa20_gui_table_control_id = ''
    pa30_gui_table_control_id = ''
    for child in pa20_session.findById('wnd[0]/usr').Children:
        if child.Type == 'GuiTableControl':  # GuiTableControl会变，要动态获取
            pa20_gui_table_control_id = child.id.replace(pa20_session.id + '/', '')
    for child in pa30_session.findById('wnd[0]/usr').Children:
        if child.Type == 'GuiTableControl':  # GuiTableControl会变，要动态获取
            pa30_gui_table_control_id = child.id.replace(pa30_session.id + '/', '')
    if pa20_gui_table_control_id == '' or pa30_gui_table_control_id == '':
        return False
    pa20_gui_table_control = GuiTableControl(pa20_session, pa20_gui_table_control_id)
    pa30_gui_table_control = GuiTableControl(pa30_session, pa30_gui_table_control_id)
    pa30_values = [row.values for row in pa30_gui_table_control.rows]
    is_pa30_includes_pa20 = True
    for idx, row in enumerate(pa20_gui_table_control.rows, start=1):
        if row.values not in pa30_values:
            is_pa30_includes_pa20 = False
            pa30_screenshot = to_windows_path_format(Path(f'{rpa.config.RPA_SCREENSHOTS_DIR}/国家管网/').joinpath('#'.join(route_path + [str(idx)]) + '_pa30.bmp').as_posix())
            if Path(pa30_screenshot).exists() is True:
                os.remove(pa30_screenshot)
    if is_pa30_includes_pa20 is True:
        if pa20_session.findById("wnd[0]/usr/txtRP50M-PAGEC").text != pa30_session.findById("wnd[0]/usr/txtRP50M-PAGEC").text:  # PA30数据重了
            pa20_session.findById("wnd[0]/tbar[0]/btn[12]").press()  # PA20 点击[取消]按钮
            pa30_session.findById("wnd[0]/tbar[0]/btn[12]").press()  # PA30 点击[取消]按钮
            return False
    pa20_session.findById("wnd[0]/tbar[0]/btn[12]").press()  # PA20 点击[取消]按钮
    pa30_session.findById("wnd[0]/tbar[0]/btn[12]").press()  # PA30 点击[取消]按钮
    return is_pa30_includes_pa20


@logfn
def copy_pa20_to_pa30(pa20_staff_id: str, pa30_staff_id):
    pa20_staff_id = init_sap_id(pa20_staff_id)
    pa30_staff_id = init_sap_id(pa30_staff_id)
    close_sap()
    with SAP('new_connection', 'nothing_to_do', 0) as pa30_session:
        with SAP('new_connection', 'nothing_to_do', 1) as pa20_session:
            enter_pa20(pa20_session, pa20_staff_id)
            enter_pa30(pa30_session, pa30_staff_id)
            pa20_gui_table_strip = GuiTabStrip(pa20_session, "wnd[0]/usr/tabsMENU_TABSTRIP")
            pa30_gui_table_strip = GuiTabStrip(pa30_session, "wnd[0]/usr/tabsMENU_TABSTRIP")
            for pa20_gui_tab in pa20_gui_table_strip.gui_tabs:
                pa20_gui_tab.select()
                pa30_gui_table_strip[pa20_gui_tab.Text].select()
                pa20_gui_table_control_id = pa20_gui_tab.findById('ssubSUBSCR_MENU:SAPMP50A:0400/subSUBSCR_ITMENU:SAPMP50A:0310/tblSAPMP50ATC_MENU').id
                gui_table_control_id = pa20_gui_table_control_id.replace(pa20_session.id + '/', '')
                pa20_gui_table_control = GuiTableControl(pa20_session, gui_table_control_id)
                pa30_gui_table_control = GuiTableControl(pa30_session, gui_table_control_id)
                for pa20_gui_table_control_row in pa20_gui_table_control.rows:
                    if pa20_gui_table_control_row['状态'].ToolTip == '存在':  # 状态为存在时，说明有数据
                        gui_tab_text = pa20_gui_tab.Text
                        info_type_text = pa20_gui_table_control_row['信息类型文本'].Text
                        if gui_tab_text in ['薪酬保险', '时间管理']:
                            logging.info(f'[{pa20_staff_id}>{pa30_staff_id}>{gui_tab_text}]跳过')
                            break  # 跳过
                        if gui_tab_text == '人员基本情况' and info_type_text in ['人事调配事件', '人员基本信息', '证件信息', '简历 ']:  # 简历不在这一屏做
                            logging.info(f'[{pa20_staff_id}>{pa30_staff_id}>{gui_tab_text}>{info_type_text}]跳过')
                            continue  # 跳过
                        if gui_tab_text == '劳动关系' and info_type_text in ['组织分配及岗位聘任 ', '特殊日期记录']:  # 特殊日期记录添加后无法删除，由人工维护
                            logging.info(f'[{pa20_staff_id}>{pa30_staff_id}>{gui_tab_text}>{info_type_text}]跳过（特殊日期记录添加后无法删除，由人工维护）')
                            continue  # 跳过
                        if info_type_text in ['员工参加培训课程信息', '行政党派职务信息', '优化配置与人员增减信息 ', '劳动合同', '员工参加培训班信息 ',
                                              '考核与档案#奖惩(行政及党内)信息', '奖惩(行政及党内)信息', '内部讲师信息']:  # 没有维护授权存
                            logging.info(f'[{pa20_staff_id}>{pa30_staff_id}>{gui_tab_text}>{info_type_text}]跳过，没有维护授权')
                            continue  # 跳过
                        if info_type_text in ['通讯信息']:
                            logging.info(f'[{pa20_staff_id}>{pa30_staff_id}>{gui_tab_text}>{info_type_text}]跳过，通讯信息是编号不能重用，无法复制')
                            continue  # 跳过
                        if info_type_text in ['专长信息']:
                            logging.info(f'[{pa20_staff_id}>{pa30_staff_id}>{gui_tab_text}>{info_type_text}]跳过，专长主次序号不能重复，无法复制')
                            continue  # 跳过
                        if info_type_text in ['论文论著信息']:  # 部分成功，保存失败，状态栏消息：填入所有必需的条目字段
                            logging.info(f'[{pa20_staff_id}>{pa30_staff_id}>{gui_tab_text}>{info_type_text}]跳过，论文论著信息，无法复制')
                            continue  # 跳过
                        if info_type_text in ['职业(上岗)资格证书信息']:  # 复制保存后跳转到[人事业务提醒创建]屏，无法复制
                            logging.info(f'[{pa20_staff_id}>{pa30_staff_id}>{gui_tab_text}>{info_type_text}]跳过，职业(上岗)资格证书信息，无法复制')
                            continue  # 跳过
                        if info_type_text in ['拟调出人员信息 ']:  # 信息类型9210不能直接新建，要通过人事活动新建
                            logging.info(f'[{pa20_staff_id}>{pa30_staff_id}>{gui_tab_text}>{info_type_text}]跳过，信息类型9210不能直接新建，要通过人事活动新建')
                            continue  # 跳过
                        pa20_gui_table_control_row['信息类型文本'].select_row()
                        try:
                            _cell = pa30_gui_table_control['信息类型文本'].find(info_type_text)
                            _cell.select_row()
                        except ValueError:
                            logging.error(f'[{pa20_staff_id}>{pa30_staff_id}>{gui_tab_text}>{info_type_text}]{info_type_text}不在PA30里')
                            continue  # 跳过
                        if _cell.Row['状态'].ToolTip == '存在':
                            if check_gai_lan(pa20_session, pa30_session, [pa20_staff_id, pa30_staff_id, gui_tab_text, info_type_text]) is True:  # 1.事前校验是否一致
                                logging.info(f'[{pa20_staff_id}#{pa30_staff_id}#{gui_tab_text}#{info_type_text}] PA20与PA30数据量一致，跳过复制')
                                continue
                        logging.info(f'[{pa20_staff_id}#{pa30_staff_id}#{gui_tab_text}#{info_type_text}]进入')
                        copy_gai_lan(pa20_session, pa30_session, [pa20_staff_id, pa30_staff_id, gui_tab_text, info_type_text])  # 2.复制概览屏幕
                        if _cell.Row['状态'].ToolTip == '存在':
                            if check_gai_lan(pa20_session, pa30_session, [pa20_staff_id, pa30_staff_id, gui_tab_text, info_type_text]) is False:  # 3.复制完成后校验数据量是否一致
                                logging.error(f'[{pa20_staff_id}#{pa30_staff_id}#{gui_tab_text}#{info_type_text}]数据量不一致')


def main():
    # [('03443733', '00465426'),
    #  ('00464128', '03443808'),
    #  ('00200008', '03443809'),
    #  ('00464114', '03443810'),
    #  ('00956342', '03443811'),
    #  ('01528540', '03443812'),
    #  ('00956344', '03443813'),
    #  ('00956384', '03443814'),
    #  ('01485767', '03443815'),
    #  ('00954392', '03443816'),
    #  ('00860457', '03443817'),
    #  ('00955803', '03443818'),
    #  ('00955835', '03443819'),
    #  ('01533537', '03443820'),
    #  ('01647144', '03443821'),
    #  ('01566534', '03443822'),
    #  ('01538006', '03443823'),
    #  ('01536569', '03443824'),
    #  ('01539155', '03443825'),
    #  ('01537098', '03443826'), ]
    for pa20_staff_id, pa30_staff_id in [('01533537', '03443820')]:
        copy_pa20_to_pa30(pa20_staff_id, pa30_staff_id)


if __name__ == '__main__':
    config('copy_pa20_to_pa30')
    with OBS_REC('copy_pa20_to_pa30'):
        logging.info('开始执行')
        main()
        logging.info('结束执行')
