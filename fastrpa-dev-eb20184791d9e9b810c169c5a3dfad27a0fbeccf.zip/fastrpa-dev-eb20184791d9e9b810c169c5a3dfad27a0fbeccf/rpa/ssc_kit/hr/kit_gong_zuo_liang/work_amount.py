"""人事工作量统计"""
import datetime
import logging
import pathlib
import re
from typing import List, Union

import pandas as pd
import win32com.client as win32
from openpyxl.utils import get_column_letter
from pandas import DataFrame
from rpa.config import EXE_DIR
from rpa.fastrpa.adtable import AdTable, load_from_xlsx_file
from rpa.fastrpa.date_funcs import valid_date
from rpa.fastrpa.log import config, logfn
from rpa.fastrpa.pandas_helper import append_df_to_excel
from rpa.ssc.date_funcs import (get_month_str, get_today, get_week_range,
                                get_week_str)

xlFillDefault = 0  # 【常规】格式
xlPasteFormats = -4122	 # 粘贴格式
xlPasteAll = -4104  # 粘贴所有内容
xlCenter = -4108  # 居中
xlFillCopy = 1  # 复制
xlUp = -4162

IS_MASTER_VERSION = True  # 是否是领导版本（非领导版本屏蔽部分功能）


def valid_week_range(day_begin: str, day_end: str):
    if valid_date(day_begin) is False or valid_date(day_end) is False:
        raise Exception(f'日期范围{day_begin}-{day_end}必须是合法的日期，如20210318-20210324')
    _day_begin, _day_end = get_week_range(day_begin)
    if day_begin != _day_begin:
        raise Exception(f'{day_begin}不是一周的开始，一周必须从周四开始')
    if day_end != _day_end:
        raise Exception(f'{day_end}不是一周的结束，一周必须以周三结束')
    _day_begin, _ = get_week_range(get_today())
    # _last_week_day_begin = get_week_range(before_day(_day_begin))
    # if day_begin not in [_day_begin, _last_week_day_begin]:
    #     raise Exception(f'只能上传本周或本周的工作量，请修改日期范围{day_begin}-{day_end}')


def chk_sheet1(lt_sheet1: AdTable, lt_dims: AdTable, day_begin: str, day_end: str) -> bool:
    """校验【工作量统计】sheet页"""
    # lt_sheet1 = load_from_xlsx_file(filename, '工作量统计', skip_header=2)
    # lt_sheet1.del_blank_rows_by_column('B')
    # lt_dims = load_from_xlsx_file(filename, '码表', skip_header=2)
    df_dims = lt_dims.to_dataframe()
    staff_groups = {'人事一组': 'L', '人事二组': 'M', '人事三组': 'N', '人事四组': 'O', '人事五组': 'P', '人事六组': 'Q', 'RPA团队': 'R'}
    is_check_passed = True
    lt_dims_c_values = lt_dims['C'].values
    lt_dims_corps = lt_dims.columns_at(['E', 'F', 'G', 'H', 'I', 'J', 'K']).values
    staff_group_keys = staff_groups.keys()
    lt_dims_groups = dict([(key, lt_dims[staff_groups[key]].values) for key in staff_group_keys])
    for row in lt_sheet1.rows:
        # if row['A'].value == '':
        #     row['A'].cmt('red', '序号不应为空')
        #     is_check_passed = False
        if row['B'].value == '':
            row['B'].cmt('red', '服务请求号不应为空')
            is_check_passed = False
        if row['C'].value == '':
            row['C'].cmt('red', '服务类型大类不应为空')
            is_check_passed = False
        if row['D'].value == '':
            row['D'].cmt('red', '服务类型小类不应为空')
            is_check_passed = False
        # 服务类型大类、小类是否一致
        serv_parent_name = row['C'].value  # 服务类型大类
        serv_child_name = row['D'].value  # 服务类型小类
        if serv_parent_name != '' and serv_child_name != '':
            df_tmp = df_dims[(df_dims['B'] == serv_parent_name) & (df_dims['C'] == serv_child_name)]
            if df_tmp.empty is True:
                row['C'].cmt('red', '服务类型大类、小类不一致')
                row['D'].cmt('red', '服务类型大类、小类不一致')
                is_check_passed = False
        if row['D'].value not in lt_dims_c_values:
            row['D'].cmt('red', '服务类型小类非码值')
            is_check_passed = False
        if row['E'].value == '':
            row['E'].cmt('red', '人次不应为空')
            is_check_passed = False
        if re.match('[1-9][0-9]*', row['E'].value) is None:
            row['E'].cmt('red', '人次应为正整数')
            is_check_passed = False
        if row['F'].value == '':
            row['F'].cmt('red', '业务组不应为空')
            is_check_passed = False
        if row['F'].value not in staff_group_keys:
            row['F'].cmt('red', '业务组非码值')
            is_check_passed = False
        if row['G'].value == '':
            row['G'].cmt('red', '服务请求单位不应为空')
            is_check_passed = False
        if row['G'].value not in lt_dims_corps:
            row['G'].cmt('red', '服务请求单位非码值')
            is_check_passed = False
        if row['H'].value == '':
            row['H'].cmt('red', '维护时间不应为空')
            is_check_passed = False
        if valid_date(row['H'].value.replace('/', '')) is False:
            row['H'].cmt('red', '维护时间不是正确的日期格式，应为yyyy/mm/dd')
            is_check_passed = False
        if row['I'].value == '':
            row['I'].cmt('red', '维护人不应为空')
            is_check_passed = False
        if row['F'].value in staff_group_keys:
            if row['I'].value not in lt_dims_groups[row['F'].value]:
                row['I'].cmt('red', '业务组、维护人不对应')
                is_check_passed = False
        if day_begin is not None and day_end is not None:
            if row['H'].value.replace('/', '') >= day_begin and row['H'].value.replace('/', '') <= day_end:
                pass
            else:
                row['H'].cmt('red', f'维护时间应在{day_begin}-{day_end}之间')
                is_check_passed = False
    return is_check_passed


def chk_sheet2() -> bool:
    """校验【码表】sheet页"""
    pass


def chk_sheet3() -> bool:
    """校验【系数】sheet页"""
    pass


def chk_sheet4() -> bool:
    """校验【按人员统计】sheet页"""
    pass


def chk_sheet5() -> bool:
    """校验【按机构统计】sheet页"""
    pass


def chk_sheet6() -> bool:
    """校验【绩效考核】sheet页"""
    pass


def check_sheets(df_work: DataFrame) -> bool:
    """校验sheet页"""
    pass


def check_sheet6_b(df_work: DataFrame) -> bool:
    """校验【绩效考核】sheet页领导输入内容是否符合约定"""


def load_sheet1(filename: str) -> DataFrame:
    names = ['序号', '服务请求号', '服务类型大类', '服务类型小类', '人次',
             '业务组', '服务请求单位', '维护时间', '维护人', '协同反馈次数', '专项工作名称']
    df_sheet1 = pd.read_excel(filename, sheet_name='工作量统计', skiprows=1, dtype=str)
    df_sheet1 = df_sheet1.iloc[:, list(range(11))]
    df_sheet1.columns = names
    df_sheet1['人次'] = df_sheet1['人次'].fillna('0')  # TODO 后续在校验环节验证，此处暂时置为0
    df_sheet1 = df_sheet1.fillna('')
    df_sheet1 = df_sheet1.applymap(str)
    df_sheet1['人次'] = df_sheet1['人次'].astype(int)
    df_sheet1.columns = names
    return df_sheet1.copy(deep=True).reset_index()


def load_sheet2(filename: str) -> DataFrame:
    pass


def load_sheet3(filename: str) -> DataFrame:
    """读取系数页，并转化为DataFrame"""
    lt_factor = load_from_xlsx_file(filename, '系数')
    tmp = []
    for column in range(3, 1 + lt_factor.max_column):
        for row in range(4, 1 + lt_factor.max_row):
            cell = lt_factor[column][row]  # 单元格
            value = cell.value  # 系数
            busi_group = cell.same_line('A').value  # 工单对应业务组
            company_nm = cell.same_line('B').value  # 服务请求单位
            busi_type = cell.same_column('3').value  # 服务类型小类
            busi_parent_type = cell.same_column('1').find_to_left_until_no_empty().value  # 服务类型大类
            max_amount = int(lt_factor[column][2].value)  # 最大人次(超过最大人次则按最大人次计算人次)
            tmp.append([busi_parent_type, busi_type, busi_group, company_nm, value, max_amount])
    df_sheet3 = DataFrame(tmp)
    df_sheet3.columns = ['服务类型大类', '服务类型小类', '工单对应业务组', '服务请求单位', '系数', '最大人次']
    df_sheet3['系数'] = df_sheet3['系数'].astype(float)
    df_sheet3 = df_sheet3[['服务类型大类', '服务类型小类', '服务请求单位', '工单对应业务组', '系数', '最大人次']]
    return df_sheet3.copy(deep=True).reset_index()


def generate_sheet4(filename: str, month_str: str) -> None:
    """根据码表数据动态扩展【按人员统计】页"""
    xlApp = win32.Dispatch('Excel.Application')
    xlApp.Visible = True
    xlApp.WindowState = -4137  # 最大化
    wb = xlApp.Workbooks.Open(filename)
    ws = wb.Sheets("按人员统计")
    ws.Select()
    # 清除旧数据
    ws.Columns("D:ZZ").Delete()
    ws.Rows("6:1000").Delete()
    ws.Range("A5:A100").ClearContents()
    # 生成左侧人员信息
    df_staff_infos = load_staff_infos(filename)
    for idx, row in df_staff_infos.iterrows():
        rn = idx + 5
        # ws.Range(f'A{rn}').FormulaR1C1 = row['业务组']  # 20210323更新：由于人员组别变动，【按人员统计】sheet页移除【A-组别】列
        ws.Range(f'B{rn}').FormulaR1C1 = row['维护人']
    rn_sum = len(df_staff_infos) + 5
    ws.Range(f'A{rn_sum}').FormulaR1C1 = ""
    ws.Range(f'B{rn_sum}').FormulaR1C1 = "合计"
    # 调整人员信息样式
    ws.Range("B5:B5").Copy()
    ws.Range(f"B5:B{rn_sum}").Select()
    xlApp.Selection.PasteSpecial(Paste=xlPasteFormats)
    # TODO 合并人员组
    # 带格式粘贴事件信息(转置粘贴在2016家庭版无效，现在改为逐个粘贴)
    max_row = wb.Sheets("码表").Range("C65536").End(xlUp).Row + 1
    for rn in range(3, max_row):
        column = get_column_letter(rn)
        wb.Sheets("码表").Range(f'B{rn}').Copy()
        ws.Range(f'{column}3').PasteSpecial(Paste=xlPasteAll)
        wb.Sheets("码表").Range(f'C{rn}').Copy()
        ws.Range(f'{column}4').PasteSpecial(Paste=xlPasteAll)
    column_sum = get_column_letter(max_row)
    ws.Range(f'{column_sum}4').FormulaR1C1 = "合计"
    # TODO 合并事件大类
    # 生成公式
    ws.Range('C5').FormulaR1C1 = '=IFERROR(SUMIFS(按人员统计_中间结果!C6,按人员统计_中间结果!C1,R2C1,按人员统计_中间结果!C2,按人员统计!R3C1,按人员统计_中间结果!C3,R4C,按人员统计_中间结果!C5,RC2),"")'
    ws.Range("C5:C5").AutoFill(ws.Range(f"C5:{column_sum}5"), xlFillDefault)
    ws.Range(f"C5:{column_sum}5").AutoFill(ws.Range(f"C5:{column_sum}{rn_sum}"), xlFillDefault)
    # 合计项背景颜色
    ws.Range(f'{column_sum}4:{column_sum}{rn_sum},A{rn_sum}:{column_sum}{rn_sum}').Interior.Color = 255  # 合计单元格填充背景红色
    # 删除右下角的单元格
    ws.Range(f'{column_sum}{rn_sum}').Delete()
    # 内容居中
    ws.Range(f'C4:{column_sum}{rn_sum}').HorizontalAlignment = xlCenter
    ws.Range(f'C4:{column_sum}{rn_sum}').VerticalAlignment = xlCenter
    # 结束，光标定位至A1单元格
    ws.Range('A1').Select()
    ws.Range("A2").FormulaR1C1 = month_str  # 调整默认月份
    ws.Range("A3").FormulaR1C1 = "合计"
    wb.Save()
    wb.Close()
    xlApp.Quit()
    del xlApp


def update_sheet4(filename: str) -> None:
    """以`工作量统计`为基础，分别以`月份`、`当月周次（分类、合计）`、`人员`、`事件类型（分类、合计）`为维度，求和`人次`"""
    # =IFERROR(SUMIFS(按人员统计_中间结果!$F:$F,按人员统计_中间结果!$A:$A,$A$2,按人员统计_中间结果!$B:$B,$B$2,按人员统计_中间结果!$C:$C,C$4,按人员统计_中间结果!$E:$E,$B5),"")
    df = load_sheet1(filename)
    df['月份'] = df['维护时间'].apply(lambda s: s.replace('/', '')).apply(get_month_str)
    df['周'] = df['维护时间'].apply(lambda s: s.replace('/', '')).apply(get_week_str)
    df = df.drop(labels=['序号', '服务请求号', '服务类型大类', '服务请求单位', '维护时间', '专项工作名称'], axis=1)
    # 周(明细),服务类型小类(明细),维护人(明细)
    df1 = df.copy(deep=True)
    df1['人次'] = df['人次'].groupby([df['月份'], df['周'], df['服务类型小类'], df['业务组'], df['维护人']]).transform('sum')
    # 周(明细),服务类型小类(明细),维护人(合计)
    df2 = df.copy(deep=True)
    df2['人次'] = df['人次'].groupby([df['月份'], df['周'], df['服务类型小类']]).transform('sum')
    df2['业务组'] = '合计'
    df2['维护人'] = '合计'
    # 周(明细),服务类型小类(合计),维护人(明细)
    df3 = df.copy(deep=True)
    df3['人次'] = df['人次'].groupby([df['月份'], df['周'], df['业务组'], df['维护人']]).transform('sum')
    df3['服务类型小类'] = '合计'
    # 周(明细),服务类型小类(合计),维护人(合计)
    df4 = df.copy(deep=True)
    df4['人次'] = df['人次'].groupby([df['月份'], df['周']]).transform('sum')
    df4['服务类型小类'] = '合计'
    df4['业务组'] = '合计'
    df4['维护人'] = '合计'
    # 周(合计),服务类型小类(明细),维护人(明细)
    df5 = df.copy(deep=True)
    df5['人次'] = df['人次'].groupby([df['月份'], df['服务类型小类'], df['业务组'], df['维护人']]).transform('sum')
    df5['周'] = '合计'
    # 周(合计),服务类型小类(明细),维护人(合计)
    df6 = df.copy(deep=True)
    df6['人次'] = df['人次'].groupby([df['月份'], df['服务类型小类']]).transform('sum')
    df6['周'] = '合计'
    df6['业务组'] = '合计'
    df6['维护人'] = '合计'
    # 周(合计),服务类型小类(合计),维护人(明细)
    df7 = df.copy(deep=True)
    df7['人次'] = df['人次'].groupby([df['月份'], df['业务组'], df['维护人']]).transform('sum')
    df7['周'] = '合计'
    df7['服务类型小类'] = '合计'
    # 周(合计),服务类型小类(合计),维护人(合计)
    df8 = df.copy(deep=True)
    df8['人次'] = df['人次'].groupby([df['月份']]).transform('sum')
    df8['周'] = '合计'
    df8['服务类型小类'] = '合计'
    df8['业务组'] = '合计'
    df8['维护人'] = '合计'
    # 合并结果
    df = pd.concat([df1, df2, df3, df4, df5, df6, df7, df8])
    df = df.drop_duplicates(['月份', '周', '业务组', '服务类型小类', '业务组', '维护人', '人次'])
    df = df.copy(deep=True)
    df = df[['月份', '周', '服务类型小类', '业务组', '维护人', '人次']]  # 只能增加列，不能调整已有列顺序，否则影响excel中引用
    append_df_to_excel(filename, df, sheet_name='按人员统计_中间结果', startrow=0, truncate_sheet=True, hidden=True, index=False)


def generate_sheet5(filename: str, month_str: str) -> None:
    """根据码表数据动态扩展【按机构统计】页"""
    xlApp = win32.Dispatch('Excel.Application')
    xlApp.Visible = True
    xlApp.WindowState = -4137  # 最大化
    wb = xlApp.Workbooks.Open(filename)
    ws = wb.Sheets("按机构统计")
    ws.Select()
    # 清除旧数据
    ws.Columns("D:ZZ").Delete()
    ws.Rows("6:1000").Delete()
    ws.Range("A5:A100").ClearContents()
    # 生成左侧机构信息
    df_corp_infos = load_corp_infos(filename)
    for idx, row in df_corp_infos.iterrows():
        rn = idx + 5
        # ws.Range(f'A{rn}').FormulaR1C1 = row['业务组']  # 20210323更新：由于机构组别变动，【按机构统计】sheet页移除【A-组别】列
        ws.Range(f'B{rn}').FormulaR1C1 = row['机构名称']
    rn_sum = len(df_corp_infos) + 5
    ws.Range(f'A{rn_sum}').FormulaR1C1 = ""
    ws.Range(f'B{rn_sum}').FormulaR1C1 = "合计"
    rn_score = len(df_corp_infos) + 6
    ws.Range(f'A{rn_score}').FormulaR1C1 = ""
    ws.Range(f'B{rn_score}').FormulaR1C1 = "得分"
    # 调整机构信息样式
    ws.Range("B5:B5").Copy()
    ws.Range(f"B5:B{rn_score}").Select()
    xlApp.Selection.PasteSpecial(Paste=xlPasteFormats)
    # TODO 合并相同业务组单元格
    # 带格式粘贴事件信息(转置粘贴在2016家庭版无效，现在改为逐个粘贴)
    max_row = wb.Sheets("码表").Range("C65536").End(xlUp).Row + 1
    for rn in range(3, max_row):
        column = get_column_letter(rn)
        wb.Sheets("码表").Range(f'B{rn}').Copy()
        ws.Range(f'{column}3').PasteSpecial(Paste=xlPasteAll)
        wb.Sheets("码表").Range(f'C{rn}').Copy()
        ws.Range(f'{column}4').PasteSpecial(Paste=xlPasteAll)
    column_sum = get_column_letter(max_row)
    ws.Range(f'{column_sum}4').FormulaR1C1 = "合计"
    column_score = get_column_letter(max_row + 1)
    if IS_MASTER_VERSION is True:
        ws.Range(f'{column_score}4').FormulaR1C1 = "得分"
    column_rank = get_column_letter(max_row + 2)
    if IS_MASTER_VERSION is True:
        ws.Range(f'{column_rank}4').FormulaR1C1 = "排名"
    # TODO 合并事件大类
    # 生成公式
    ws.Range(f'C5:{column_rank}{rn_score}').NumberFormatLocal = "G/通用格式"
    ws.Range('C5').FormulaR1C1 = r'=IFERROR(SUMIFS(按机构统计_中间结果!C5,按机构统计_中间结果!C1,R2C1,按机构统计_中间结果!C2,R3C1,按机构统计_中间结果!C3,R4C,按机构统计_中间结果!C4,RC2),"")'
    ws.Range("C5:C5").AutoFill(ws.Range(f"C5:{column_sum}5"), xlFillDefault)
    if IS_MASTER_VERSION is True:
        ws.Range(f'{column_score}5').FormulaR1C1 = r'=SUMIFS(绩效考核_中间结果0!C19,绩效考核_中间结果0!C5,R2C1,绩效考核_中间结果0!C11,RC2)'  # 得分
        rn_count = len(df_corp_infos) + 4  # 最后一个机构所在行号
        ws.Range('BA5').FormulaR1C1 = f'=SUMPRODUCT((R5C52:R{rn_count}C52>RC52)/COUNTIF(R5C52:R{rn_count}C52,R5C52:R{rn_count}C52))+1'  # 排名
    ws.Range(f"C5:{column_rank}5").AutoFill(ws.Range(f"C5:{column_rank}{rn_sum}"), xlFillDefault)
    if IS_MASTER_VERSION is True:
        ws.Range(f'C{rn_score}').FormulaR1C1 = "=SUMIFS(绩效考核_中间结果0!C19,绩效考核_中间结果0!C5,R2C1,绩效考核_中间结果0!C9,按机构统计!R4C)"  # 得分
    ws.Range(f"C{rn_score}").AutoFill(ws.Range(f"C{rn_score}:{column_sum}{rn_score}"), xlFillDefault)
    # 单元格颜色
    ws.Range(f'{column_sum}4:{column_sum}{rn_sum},A{rn_sum}:{column_sum}{rn_sum}').Interior.Color = 255  # 合计单元格填充背景红色
    if IS_MASTER_VERSION is True:
        ws.Range(f'{column_score}4:{column_score}{rn_score},A{rn_score}:{column_score}{rn_score}').Interior.Color = 15773696  # 得分单元格填充背景靛蓝
        ws.Range(f'{column_rank}4:{column_rank}{rn_score}').Interior.Color = 49407  # 排名单元格填充背景米黄
    # 删除右下角的无用单元格
    ws.Range(f'{column_sum}{rn_sum}:{column_rank}{rn_score}').Delete()
    # 内容居中
    ws.Range(f'C4:{column_rank}{rn_score}').HorizontalAlignment = xlCenter
    ws.Range(f'C4:{column_rank}{rn_score}').VerticalAlignment = xlCenter
    # 结束，光标定位至A1单元格
    ws.Range('A1').Select()
    ws.Range("A2").FormulaR1C1 = month_str  # 调整默认月份
    ws.Range("A3").FormulaR1C1 = "合计"
    wb.Save()
    wb.Close()
    xlApp.Quit()
    del xlApp


def update_sheet5(filename: str) -> None:
    """以`工作量统计`为基础，分别以`月份`、`当月周次（分类、合计）`、`机构`、`事件类型（分类、合计）`为维度，求和`人次`"""
    # =IFERROR(SUMIFS(按机构统计_中间结果!$E:$E,按机构统计_中间结果!$A:$A,$A$2,按机构统计_中间结果!$B:$B,$B$2,按机构统计_中间结果!$C:$C,C$3,按机构统计_中间结果!$D:$D,$B4),"")
    df = load_sheet1(filename)
    df['月份'] = df['维护时间'].apply(lambda s: s.replace('/', '')).apply(get_month_str)
    df['周'] = df['维护时间'].apply(lambda s: s.replace('/', '')).apply(get_week_str)
    df = df.drop(labels=['序号', '服务请求号', '服务类型大类', '业务组', '维护人', '维护时间', '专项工作名称'], axis=1)
    # 周(明细),服务类型小类(明细),服务请求单位(明细)
    df1 = df.copy(deep=True)
    df1['人次'] = df['人次'].groupby([df['月份'], df['周'], df['服务类型小类'], df['服务请求单位']]).transform('sum')
    # 周(明细),服务类型小类(明细),服务请求单位(合计)
    df2 = df.copy(deep=True)
    df2['人次'] = df['人次'].groupby([df['月份'], df['周'], df['服务类型小类']]).transform('sum')
    df2['服务请求单位'] = '合计'
    # 周(明细),服务类型小类(合计),服务请求单位(明细)
    df3 = df.copy(deep=True)
    df3['人次'] = df['人次'].groupby([df['月份'], df['周'], df['服务请求单位']]).transform('sum')
    df3['服务类型小类'] = '合计'
    # 周(明细),服务类型小类(合计),服务请求单位(合计)
    df4 = df.copy(deep=True)
    df4['人次'] = df['人次'].groupby([df['月份'], df['周']]).transform('sum')
    df4['服务类型小类'] = '合计'
    df4['服务请求单位'] = '合计'
    # 周(合计),服务类型小类(明细),服务请求单位(明细)
    df5 = df.copy(deep=True)
    df5['人次'] = df['人次'].groupby([df['月份'], df['服务类型小类'], df['服务请求单位']]).transform('sum')
    df5['周'] = '合计'
    # 周(合计),服务类型小类(明细),服务请求单位(合计)
    df6 = df.copy(deep=True)
    df6['人次'] = df['人次'].groupby([df['月份'], df['服务类型小类']]).transform('sum')
    df6['周'] = '合计'
    df6['服务请求单位'] = '合计'
    # 周(合计),服务类型小类(合计),服务请求单位(明细)
    df7 = df.copy(deep=True)
    df7['人次'] = df['人次'].groupby([df['月份'], df['服务请求单位']]).transform('sum')
    df7['周'] = '合计'
    df7['服务类型小类'] = '合计'
    # 周(合计),服务类型小类(合计),服务请求单位(合计)
    df8 = df.copy(deep=True)
    df8['人次'] = df['人次'].groupby([df['月份']]).transform('sum')
    df8['周'] = '合计'
    df8['服务类型小类'] = '合计'
    df8['服务请求单位'] = '合计'
    # 合并结果
    df = pd.concat([df1, df2, df3, df4, df5, df6, df7, df8])
    df = df.drop_duplicates(['月份', '周', '服务类型小类', '服务请求单位', '人次'])
    df = df.copy(deep=True)
    df = df[['月份', '周', '服务类型小类', '服务请求单位', '人次']]  # 只能增加列，不能调整已有列顺序，否则影响excel中引用
    append_df_to_excel(filename, df, sheet_name='按机构统计_中间结果', startrow=0, truncate_sheet=True, hidden=True, index=False)


def load_staff_infos(filename: str) -> DataFrame:
    df = pd.read_excel(filename, sheet_name='码表', skiprows=1, dtype=str)
    df = df.applymap(lambda s: s.strip(' \t\r\n') if isinstance(s, str) else s)
    # 人事一组
    df1 = DataFrame({'维护人': list(df.iloc[:, 11].dropna().values)})
    df1['业务组'] = '人事一组'
    df1['角色'] = df1['维护人'].apply(lambda s: '组长' if s in list(df.iloc[:, 22].dropna().values) else '业务人员')
    # 人事二组
    df2 = DataFrame({'维护人': list(df.iloc[:, 12].dropna().values)})
    df2['业务组'] = '人事二组'
    df2['角色'] = df2['维护人'].apply(lambda s: '组长' if s in list(df.iloc[:, 23].dropna().values) else '业务人员')
    # 人事三组
    df3 = DataFrame({'维护人': list(df.iloc[:, 13].dropna().values)})
    df3['业务组'] = '人事三组'
    df3['角色'] = df3['维护人'].apply(lambda s: '组长' if s in list(df.iloc[:, 24].dropna().values) else '业务人员')
    # 人事四组
    df4 = DataFrame({'维护人': list(df.iloc[:, 14].dropna().values)})
    df4['业务组'] = '人事四组'
    df4['角色'] = df4['维护人'].apply(lambda s: '组长' if s in list(df.iloc[:, 25].dropna().values) else '业务人员')
    # 人事五组
    df5 = DataFrame({'维护人': list(df.iloc[:, 15].dropna().values)})
    df5['业务组'] = '人事五组'
    df5['角色'] = df5['维护人'].apply(lambda s: '组长' if s in list(df.iloc[:, 26].dropna().values) else '业务人员')
    # 人事六组
    df6 = DataFrame({'维护人': list(df.iloc[:, 16].dropna().values)})
    df6['业务组'] = '人事六组'
    df6['角色'] = df6['维护人'].apply(lambda s: '组长' if s in list(df.iloc[:, 27].dropna().values) else '业务人员')
    # RPA团队人员
    df7 = DataFrame({'维护人': list(df.iloc[:, 17].dropna().values)})
    df7['业务组'] = 'RPA团队'
    df7['角色'] = df7['维护人'].apply(lambda s: '组长' if s in list(df.iloc[:, 28].dropna().values) else '业务人员')
    df = pd.concat([df1, df2, df3, df4, df5, df6, df7])
    df['组内人数'] = df['维护人'].groupby([df['业务组']]).transform('count')
    df = df[['业务组', '角色', '维护人', '组内人数']]
    return df.copy(deep=True).reset_index()


def load_corp_infos(filename: str) -> DataFrame:
    lt_dims = load_from_xlsx_file(filename, '码表', skip_header=2)
    crop_names1 = [v for v in lt_dims['E'].values if v != '']
    df1 = DataFrame(crop_names1)
    df1.columns = ['机构名称']
    return df1.copy(deep=True).reset_index()


def generate_sheet6(filename: str, month_str: str) -> None:
    """根据码表数据动态扩展【绩效考核】页"""
    xlApp = win32.Dispatch('Excel.Application')
    xlApp.Visible = True
    xlApp.WindowState = -4137  # 最大化
    wb = xlApp.Workbooks.Open(filename)
    ws = wb.Sheets("绩效考核")
    ws.Select()
    # 生成左侧人员信息
    df_staff_infos = load_staff_infos(filename)
    # 补足行数

    linenum = ws.Range("B65536").End(xlUp).Row - 5
    len_df_staff_infos = len(df_staff_infos)
    if len_df_staff_infos > linenum:  # 如果数据行数大于excel已有的行数，则插入行以补足
        xlFormatFromLeftOrAbove = 0
        for _ in range(len_df_staff_infos - linenum):
            ws.Rows("7:7").Insert(CopyOrigin=xlFormatFromLeftOrAbove)
    else:
        for _ in range(linenum - len_df_staff_infos):
            ws.Rows("7:7").Delete()
    # 插入人员信息
    for idx, row in df_staff_infos.iterrows():
        rn = idx + 6
        ws.Range(f'A{rn}').FormulaR1C1 = row['业务组']
        ws.Range(f'B{rn}').FormulaR1C1 = row['维护人']

    rn_max = len(df_staff_infos) + 5
    # 公式填充
    ws.Range("AA6:AA6").AutoFill(ws.Range(f"AA6:AA{rn_max}"), xlFillCopy)
    ws.Range("AB6:BB6").AutoFill(ws.Range(f"AB6:BB{rn_max}"), xlFillDefault)
    ws.Range("D6:D6").AutoFill(ws.Range(f"D6:D{rn_max}"), xlFillDefault)  # 工作量得分
    ws.Range("O6:O6").AutoFill(ws.Range(f"O6:O{rn_max}"), xlFillDefault)  # 总分
    ws.Range("R6:R6").AutoFill(ws.Range(f"R6:R{rn_max}"), xlFillDefault)  # 月度奖金
    # RPA团队特殊处理
    for idx, row in df_staff_infos.iterrows():
        rn = idx + 6
        if row['业务组'] == 'RPA团队':
            logging.info('20210522更新-例外情况：RPA团队-' + row['维护人'])
            logging.info('20210522更新-例外情况：RPA团队分值固定为40分')
            ws.Range(f'D{rn}').FormulaR1C1 = '40'
            logging.info('20210522更新-例外情况：RPA团队不计入业务组总分、均分名次')
            ws.Range(f'AK{rn}').FormulaR1C1 = ''
            ws.Range(f'AL{rn}').FormulaR1C1 = ''
            ws.Range(f'AM{rn}').FormulaR1C1 = ''
            ws.Range(f'AN{rn}').FormulaR1C1 = ''
            ws.Range(f'AZ{rn}').FormulaR1C1 = ''
            if row['角色'] == '组长':
                logging.info('20210522更新-例外情况：RPA团队组长BA列设置为5分（其余各组得分的平均分）')
                ws.Range(f'BA{rn}').FormulaR1C1 = '5'
                logging.info('20210522更新-例外情况：RPA团队组长BB列设置为20分（其余各组得分的平均分）')
                ws.Range(f'BB{rn}').FormulaR1C1 = '20'
            else:
                ws.Range(f'BA{rn}').FormulaR1C1 = ''
                ws.Range(f'BB{rn}').FormulaR1C1 = ''
    # 清空内容
    ws.Range(f"C6:C{rn_max},E6:N{rn_max},P6:Q{rn_max},S6:T{rn_max}").ClearContents()
    ws.Range("A1").FormulaR1C1 = month_str  # 调整默认月份
    wb.Save()
    wb.Close()
    xlApp.Quit()
    del xlApp


def load_sheet6(filename: str) -> DataFrame:
    """加载领导数据"""
    df = pd.read_excel(filename, sheet_name='绩效考核', skiprows=4, dtype=str)
    df = df.iloc[:, list(range(19))]
    df.columns = ['业务组', '维护人', '工作量得分', '认定工作量得分', '准确分', '及时分', '沟通协调分', '日常业务', '日常管理',
                  '加扣分', '加分项1原因', '加分项2原因', '加分项3原因', '总分', '奖金基数', '约束性指标', '月度奖金', '能力得分', '备注']
    df = df.fillna('')
    return df


def update_sheet6_1(filename: str) -> None:
    """明细数据"""
    df_sheet1 = load_sheet1(filename)  # 加载【工作量统计】
    df_sheet1['月份'] = df_sheet1['维护时间'].apply(lambda s: s.replace('/', '')).apply(get_month_str)
    df_sheet3 = load_sheet3(filename)  # 加载【系数】
    df_staff_infos = load_staff_infos(filename)
    df0 = DataFrame()
    for month in set(df_sheet1['月份'].values):
        df0_tmp = df_staff_infos.copy(deep=True).reset_index()
        df0_tmp['月份'] = month
        df0 = pd.concat([df0, df0_tmp])
    df_sheet1['工单数'] = 1
    df = df0.merge(df_sheet1, on=['月份', '业务组', '维护人'], how='outer')  # 这个地方报错KeyError月份不存在一般是工作量下载结果为空
    df['工单数'] = df['工单数'].fillna(0)
    df['工单数'].astype(int)
    df = df.merge(df_sheet3, on=['服务类型小类', '服务请求单位'], how='left')  # 经沟通，只用小类进行关联即可
    df['实际每单得分'] = df['人次'].mul(df['系数'])
    df['最大每单得分'] = df['最大人次'].mul(df['系数'])
    df['每单得分'] = df.apply(lambda row: row['最大每单得分'] if row['实际每单得分'] > row['最大每单得分'] else row['实际每单得分'], axis=1)
    df = df[['业务组', '角色', '维护人', '组内人数', '月份', '序号', '服务请求号', '服务类型大类_x', '服务类型小类', '人次', '服务请求单位', '维护时间', '协同反馈次数',
             '专项工作名称', '工单数', '服务类型大类_y', '工单对应业务组', '系数', '每单得分', '实际每单得分', '最大每单得分']]  # 只能增加列，不能调整已有列顺序，否则影响excel中引用
    append_df_to_excel(filename, df, sheet_name='绩效考核_中间结果0', startrow=0, truncate_sheet=True, hidden=True, index=False)
    #
    df1 = df['工单数'].groupby([df['月份'], df['业务组'], df['角色'], df['维护人']]).sum().reset_index(level=None, drop=False, name=None, inplace=False)
    df1.columns = ['月份', '业务组', '角色', '维护人', '完成单数']
    df2 = df['人次'].groupby([df['月份'], df['业务组'], df['维护人']]).sum().reset_index(level=None, drop=False, name=None, inplace=False)
    df2.columns = ['月份', '业务组', '维护人', '完成人次']
    df3 = df['工单数'].groupby([df['月份'], df['业务组']]).sum().reset_index(level=None, drop=False, name=None, inplace=False)
    df3.columns = ['月份', '业务组', '业务组总单数']
    df4 = df['人次'].groupby([df['月份'], df['业务组']]).sum().reset_index(level=None, drop=False, name=None, inplace=False)
    df4.columns = ['月份', '业务组', '业务组总人次']
    df5 = df['工单数'].groupby([df['月份']]).sum().reset_index(level=None, drop=False, name=None, inplace=False)
    df5.columns = ['月份', '服务部总单数']
    df6 = df['人次'].groupby([df['月份']]).sum().reset_index(level=None, drop=False, name=None, inplace=False)
    df6.columns = ['月份', '服务部总人次']
    df7 = df['每单得分'].groupby([df['月份'], df['业务组'], df['维护人']]).sum().reset_index(level=None, drop=False, name=None, inplace=False)
    df7.columns = ['月份', '业务组', '维护人', '业务人员实际得分']
    df8 = df['每单得分'].groupby([df['月份'], df['业务组']]).sum().reset_index(level=None, drop=False, name=None, inplace=False)
    df8.columns = ['月份', '业务组', '业务组实际得分']
    df9 = df['每单得分'].groupby([df['月份']]).sum().reset_index(level=None, drop=False, name=None, inplace=False)
    df9.columns = ['月份', '服务部实际总分']
    # 合并
    df10 = df1.merge(df2, on=['月份', '业务组', '维护人'], how='outer')
    df10 = df10.merge(df3, on=['月份', '业务组'], how='outer')
    df10 = df10.merge(df4, on=['月份', '业务组'], how='outer')
    df10 = df10.merge(df5, on=['月份'], how='outer')
    df10 = df10.merge(df6, on=['月份'], how='outer')
    df10 = df10.merge(df7, on=['月份', '业务组', '维护人'], how='outer')
    df10 = df10.merge(df8, on=['月份', '业务组'], how='outer')
    df10 = df10.merge(df9, on=['月份'], how='outer')
    df10 = df0.merge(df10, on=['月份', '业务组', '角色', '维护人'], how='outer')
    df10['每分完成单数'] = df10['完成单数'].div(df10['业务人员实际得分'])
    df10['每分完成人次'] = df10['完成人次'].div(df10['业务人员实际得分'])
    df10['业务组每分单数'] = df10['业务组总单数'].div(df10['业务组实际得分'])
    df10['业务组每分人数'] = df10['业务组总人次'].div(df10['业务组实际得分'])
    df10['服务部每分单数'] = df10['服务部总单数'].div(df10['服务部实际总分'])
    df10['服务部每分人数'] = df10['服务部总人次'].div(df10['服务部实际总分'])
    df10 = df10.fillna(0)
    df10 = df10[['月份', '业务组', '角色', '维护人', '完成单数', '完成人次', '业务组总单数', '业务组总人次', '服务部总单数',
                 '服务部总人次', '业务人员实际得分', '业务组实际得分', '服务部实际总分', '每分完成单数', '每分完成人次',
                 '业务组每分单数', '业务组每分人数', '服务部每分单数', '服务部每分人数', '组内人数']]  # 只能增加列，不能调整已有列顺序，否则影响excel中引用
    append_df_to_excel(filename, df10, sheet_name='绩效考核_中间结果1', startrow=0, truncate_sheet=True, hidden=True, index=False)


def save_file(filename: str):
    xlApp = win32.Dispatch('Excel.Application')
    xlApp.Visible = True
    xlApp.WindowState = -4137  # 最大化
    wb = xlApp.Workbooks.Open(filename)
    wb.Sheets("工作量统计").Range("A:K").ClearComments()  # 清除批注
    try:
        wb.Sheets("工作量统计").Range("A:K").Interior.ColorIndex = -4142  # 清除背景色
    except Exception:
        logging.error(f'模板写保护{filename}，RPA无法修改，请解除保护后再执行RPA')
        wb.Close()
        xlApp.Quit()
        del xlApp
        raise Exception(f'模板写保护{filename}，RPA无法修改，请解除保护后再执行RPA')
    wb.Save()


def before_check(filenames: Union[List[str], str], day_begin: str, day_end: str) -> bool:
    valid_week_range(day_begin, day_end)
    logging.info('正在进行前置校验')
    if isinstance(filenames, str):
        filenames = [filenames]
    if valid_date(day_begin) is False or valid_date(day_end) is False:
        raise Exception(f'{day_begin}-{day_end}不是合法的工作量日期区间')
    for filename in filenames:
        logging.info(f'正在校验文件{filename}')
        lt_sheet1 = load_from_xlsx_file(filename, '工作量统计', skip_header=2)
        # lt_sheet1.del_blank_rows_by_column('B')
        lt_dims = load_from_xlsx_file(filename, '码表', skip_header=2)
        is_check_passed = chk_sheet1(lt_sheet1, lt_dims, day_begin, day_end)
        lt_sheet1.save(filename)
    if is_check_passed is False:
        raise Exception(f'文件{filename}前置校验未通过，请检查批注信息')
    return True


def merge_files(filenames: List[str]) -> str:
    if len(filenames) == 0:
        raise Exception('未选定文件')
    else:
        if IS_MASTER_VERSION is True:
            template_name = '工作量统计-服务部.xlsx'
        else:
            template_name = '工作量统计-业务组.xlsx'
        lt_demo = load_from_xlsx_file(pathlib.Path(EXE_DIR).joinpath(template_name).as_posix(), '工作量统计', skip_header=2, data_only=False)  # 模板文件
        lt_demo.ws.delete_rows(3, lt_demo.max_row)  # 删除工作量统计模板-工作量统计页内容
        df = pd.concat([load_sheet1(filename) for filename in filenames])  # 加载工作量文件
        for _, df_row in df.iterrows():
            lt_row = lt_demo.add_row()
            lt_row['B'].value = df_row['服务请求号']
            lt_row['C'].value = df_row['服务类型大类']
            lt_row['D'].value = df_row['服务类型小类']
            lt_row['E'].value = df_row['人次']
            lt_row['F'].value = df_row['业务组']
            lt_row['G'].value = df_row['服务请求单位']
            lt_row['H'].value = df_row['维护时间']
            lt_row['I'].value = df_row['维护人']
            lt_row['J'].value = df_row['协同反馈次数']
            lt_row['K'].value = df_row['专项工作名称']
        lt_demo.re_index('A')
        yyyymmdd = datetime.datetime.now().strftime(r'%Y%m%d')
        lt_demo.filename = f'工作量汇总_{yyyymmdd}'
        filename = lt_demo.save_to(EXE_DIR)
        return filename


@logfn
def main(filename: str, day_begin: str, day_end: str, is_before_check=True, is_calc=True, is_master_version=False) -> bool:
    global IS_MASTER_VERSION
    lt = load_from_xlsx_file(filename, '工作量统计', skip_header=2)
    df = lt.to_dataframe()
    if len(df) == 0:
        logging.info('工作量文件为空，跳过汇总')
        return True
    IS_MASTER_VERSION = is_master_version and True if '绩效考核' in lt.wb.sheetnames else False
    logging.info(f'工作量文件名：{filename}')
    if is_before_check is True and before_check([filename], day_begin, day_end) is False:
        return False
    if is_calc is False:
        return True
    month_str = str(int(day_begin[4:6])) + '月'
    try:
        logging.info('正在计算【按人员统计】中间结果')
        update_sheet4(filename)
        logging.info('正在计算【按机构统计】中间结果')
        update_sheet5(filename)
        if IS_MASTER_VERSION is True:
            logging.info('正在计算【绩效考核】中间结果')
            update_sheet6_1(filename)
        logging.info('中间结果计算完毕')
    except PermissionError:
        logging.error('编辑遇到错误，请检查文件是否被占用')
    try:
        logging.info('正在更新【按人员统计】sheet页')
        if '按人员统计' in lt.wb.sheetnames:
            generate_sheet4(filename, month_str)
        else:
            raise Exception('文件不存在【按人员统计】sheet页')
        logging.info('正在更新【按机构统计】sheet页')
        if '按机构统计' in lt.wb.sheetnames:
            generate_sheet5(filename, month_str)
        else:
            raise Exception('文件不存在【按机构统计】sheet页')
        if IS_MASTER_VERSION is True:
            logging.info('正在更新【绩效考核】sheet页')
            if '绩效考核' in lt.wb.sheetnames:
                generate_sheet6(filename, month_str)
            else:
                raise Exception('文件不存在【绩效考核】sheet页')
        logging.info('sheet页已更新')
        save_file(filename)
        logging.info(f'结果文件已保存：{filename}')
    except Exception as e:
        logging.error(e)
        raise e
    return True


def main2(filenames: List[str], day_begin: str, day_end: str, is_master_version=False):
    if before_check(filenames, day_begin, day_end) is False:
        return False
    global IS_MASTER_VERSION
    IS_MASTER_VERSION = is_master_version
    filename = merge_files(filenames)
    # lt_sheet1 = load_from_xlsx_file(filename, '工作量统计', skip_header=2)
    # lt_sheet1.del_blank_rows_by_column('B')
    main(filename, day_begin, day_end, is_before_check=False, is_calc=True, is_master_version=False)


if __name__ == '__main__':
    config()
    logging.info('程序开始执行')
    filenames = [r"x:\mengzhao\Desktop\业务部工作量_20210225-20210324.xlsx"]
    main(filenames[0], '20210225', '20210324', False, True, True)
    logging.info('程序结束执行')
