import logging

from pandas import DataFrame
from rpa.fastrpa.adtable import AdTable


def chk_01(lt_103_t69_2: AdTable, df_103_t69_2: DataFrame):  # 39
    """标记无组织分配K的人员"""
    for rn in df_103_t69_2.index:
        if df_103_t69_2['Z'][rn] == '':
            lt_103_t69_2['Z'][rn].cmt('red', '组织分配屏成本中心为空！')


def chk_02(lt_103_t69_2: AdTable, df_103_t69_2: DataFrame):  # 40-41
    """标记组织分配有多个K的人员，并查询是否已被定界"""
    for rn in df_103_t69_2.index:
        staff_id = df_103_t69_2['A'][rn]
        _df = df_103_t69_2[df_103_t69_2['A'] == staff_id]
        if _df.empty is False:
            if(len(set(_df['Z'].values))) > 1:
                lt_103_t69_2['Z'][rn].cmt('purple', '组织分配屏成本中心有多个码值！')  # 40
        if df_103_t69_2['W'][rn] != '9999.12.31':
            lt_103_t69_2['W'][rn].cmt('red', '组织分配屏结束日期不为99991231！')  # 40


def chk_03(lt_103_t69_2: AdTable, df_107_t83_2: DataFrame):  # 42-45
    """定位组织分配K的来源（先岗位再机构），并查询是否已被定界"""
    for row in lt_103_t69_2.rows:
        _aj = row['AJ'].value  # 42
        _df1 = df_107_t83_2[(df_107_t83_2['A'] == _aj) & (df_107_t83_2['B'] == 'S') & (df_107_t83_2['K'] == 'K')]
        if _df1.empty is True:
            _ah = row['AH'].value
            is_exist = False
            while True:
                _df2 = df_107_t83_2[(df_107_t83_2['A'] == _ah) & (df_107_t83_2['B'] == 'O') & (df_107_t83_2['K'] == 'K')]
                if _df2.empty is True:
                    _df3 = df_107_t83_2[(df_107_t83_2['A'] == _ah) & (df_107_t83_2['B'] == 'O') & (df_107_t83_2['K'] == 'O')]
                    if _df3.empty is True:
                        row['AH'].cmt('970080', '该人员所在岗位、所在隶属机构及其上级所有机构的财科，均未设置K！请检查组织分配屏成本中心来源！')  # 深紫色
                        break
                    else:
                        _ah = _df3['L'].values[0]
                else:
                    is_exist = True
                    break
            if is_exist is True:  # 43
                _l = _df2['L'].values[0]
                _h = _df2['H'].values[0]
                _z = row['Z'].value + 'SINO'
                if _h == '9999.12.31' and _l == _z:
                    info_text = _df2['A'].values[0] + '  ' + _df2['F'].values[0]
                    row['AH'].cmt('green', f'组织分配屏成本中心继承自机构：{info_text}')
                elif _h == '9999.12.31' and _l != _z:
                    info_text = _df2['A'].values[0] + '  ' + _df2['F'].values[0] + '  ' + _df2['L'].values[0].replace('SINO', '')
                    row['AH'].cmt('red', f'组织分配屏成本中心继承自机构财科K，但两者码值并不相同！机构财科K为：{info_text}')
                elif _h != '9999.12.31' and _l == _z:
                    info_text = _df2['A'].values[0] + '  ' + _df2['F'].values[0]
                    row['AH'].cmt('pink', f'组织分配屏成本中心继承自机构，但机构财科K结束日期不为99991231！：{info_text}')
                elif _h != '9999.12.31' and _l != _z:
                    info_text = _df2['A'].values[0] + '  ' + _df2['F'].values[0] + '  ' + _df2['L'].values[0].replace('SINO', '')
                    row['AH'].cmt('pink', f'组织分配屏成本中心继承自机构财科K，但两者码值并不相同，且其结束日期不为99991231！机构财科K为：{info_text}')
        else:  # 44
            _l = _df1['L'].values[0]
            _h = _df1['H'].values[0]
            _z = row['Z'].value + 'SINO'
            if _h == '9999.12.31' and _l == _z:
                row['AJ'].cmt('blue', '组织分配屏成本中心继承自岗位财科K！')
            elif _h == '9999.12.31' and _l != _z:
                _k = str(_l).replace('SINO', '')
                row['AJ'].cmt('red', f'组织分配屏成本中心与岗位财科K不同，岗位财科K为：{_k}')
            elif _h != '9999.12.31' and _l == _z:
                row['AJ'].cmt('pink', '组织分配屏成本中心继承自岗位财科K，但岗位财科K结束日期不为99991231！')
            elif _h != '9999.12.31' and _l != _z:
                _k = str(_l).replace('SINO', '')
                row['AJ'].cmt('purple', f'组织分配屏成本中心与岗位财科K不同，且岗位财科K结束日期不为99991231，岗位财科K为：{_k}')
            _ah = row['AH'].value
            is_exist = False
            while True:
                _df2 = df_107_t83_2[(df_107_t83_2['A'] == _ah) & (df_107_t83_2['B'] == 'O') & (df_107_t83_2['K'] == 'K')]
                if _df2.empty is True:
                    _df3 = df_107_t83_2[(df_107_t83_2['A'] == _ah) & (df_107_t83_2['B'] == 'O') & (df_107_t83_2['K'] == 'O')]
                    if _df3.empty is True:
                        row['AI'].cmt('red', '该人员所在隶属机构及其上级所有机构的财科，均未设置K！')
                        break
                    else:
                        _ah = _df3['L'].values[0]
                else:
                    is_exist = True
                    break
            if is_exist is True:  # 45
                _l = _df2['L'].values[0]
                _h = _df2['H'].values[0]
                _z = row['Z'].value + 'SINO'
                if _h == '9999.12.31' and _l == _z:
                    row['AI'].cmt('orange', '岗位财科K与机构财科K相同，可定界岗位财科K！')
                if _h == '9999.12.31' and _l != _z:
                    _k = _df2['A'].values[0] + '  ' + _df2['F'].values[0] + '  ' + _l.replace('SINO', '')
                    row['AI'].cmt('purple', f'岗位财科K与机构财科K不同，机构财科的K为：{_k}')
                if _h != '9999.12.31' and _l == _z:
                    row['AI'].cmt('pink', '岗位财科K与机构财科K相同，可定界岗位财科K！')
                if _h != '9999.12.31' and _l != _z:
                    _k = _df2['A'].values[0] + '  ' + _df2['F'].values[0] + '  ' + _l.replace('SINO', '')
                    row['AI'].cmt('lightpink', f'岗位财科K与机构财科K不同，但机构财科K结束日期不为99991231！机构财科的K为：{_k}')


def chk_04(lt_103_t69_2: AdTable, df_107_t83_2: DataFrame):  # 46-47
    """判断岗位和机构上是否存在成本分配，并查询是否已被定界"""
    for row in lt_103_t69_2.rows:
        _aj = row['AJ'].value  # 46
        _df = df_107_t83_2[(df_107_t83_2['A'] == _aj) & (df_107_t83_2['B'] == 'S')]
        if _df.empty is False:
            if max(_df[['AB', 'AC', 'AD']].values.flatten()) != '':
                if _df['Y'].values[0] == '9999.12.31' and _df['AB'].values[0] != '':
                    row['A'].cmt('red', '岗位成本分配上有成本中心！')
                if _df['Y'].values[0] == '9999.12.31' and _df['AC'].values[0] != '':
                    row['B'].cmt('red', '岗位成本分配上有订单！')
                if _df['Y'].values[0] == '9999.12.31' and _df['AD'].values[0] != '':
                    row['C'].cmt('red', '岗位成本分配上有WBS元素！')
                if _df['Y'].values[0] != '9999.12.31' and _df['AB'].values[0] != '':
                    row['A'].cmt('purple', '岗位成本分配上有成本中心，但其结束日期不为99991231！')
                if _df['Y'].values[0] != '9999.12.31' and _df['AC'].values[0] != '':
                    row['B'].cmt('purple', '岗位成本分配上有订单，但其结束日期不为99991231！')
                if _df['Y'].values[0] != '9999.12.31' and _df['AD'].values[0] != '':
                    row['C'].cmt('purple', '岗位成本分配上有WBS元素，但其结束日期不为99991231！')
        _ah = row['AH'].value
        _df = df_107_t83_2[(df_107_t83_2['A'] == _ah) & (df_107_t83_2['B'] == 'O')]
        if _df.empty is False:
            if max(_df[['AB', 'AC', 'AD']].values.flatten()) != '':  # 46-47 存在不存在都执行此项规则
                if _df['Y'].values[0] == '9999.12.31' and _df['AB'].values[0] != '':
                    row['D'].cmt('blue', '机构成本分配上有成本中心！')
                if _df['Y'].values[0] == '9999.12.31' and _df['AC'].values[0] != '':
                    row['E'].cmt('blue', '机构成本分配上有订单！')
                if _df['Y'].values[0] == '9999.12.31' and _df['AD'].values[0] != '':
                    row['F'].cmt('blue', '机构成本分配上有WBS元素！')
                if _df['Y'].values[0] != '9999.12.31' and _df['AB'].values[0] != '':
                    row['D'].cmt('red', '机构成本分配上有成本中心，但其结束日期不为99991231！')
                if _df['Y'].values[0] != '9999.12.31' and _df['AC'].values[0] != '':
                    row['E'].cmt('red', '机构成本分配上有订单，但其结束日期不为99991231！')
                if _df['Y'].values[0] != '9999.12.31' and _df['AD'].values[0] != '':
                    row['F'].cmt('red', '机构成本分配上有WBS元素，但其结束日期不为99991231！')


def chk_05(lt_103_t69_2: AdTable, df_107_t83_2: DataFrame):  # 48
    """判断人身上是否存在成本分配，并查询是否已被定界"""
    for row in lt_103_t69_2.rows:  # 48
        if row['P'].value != '':
            row['P'].cmt('blue', '人员成本分配上有成本中心！')
        if row['R'].value != '':
            row['R'].cmt('blue', '人员成本分配上有订单！')
        if row['T'].value != '':
            row['T'].cmt('blue', '人员成本分配上有WBS元素！')
        if row['M'].value != '0000.00.00' and row['M'].value != '9999.12.31':
            row['M'].cmt('red', '人员成本分配的结束日期不为99991231！')


def chk_06(lt_103_t69_2: AdTable, df_107_t83_2: DataFrame):  # 49-63
    """定位组织分配信息继承自岗位财科还是机构财科，并查询财科是否已被定界"""
    for row in lt_103_t69_2.rows:
        _aj = row['AJ'].value
        _df1 = df_107_t83_2[(df_107_t83_2['A'] == _aj) & (df_107_t83_2['B'] == 'S')]
        if _df1.empty is False:
            if _df1['S'].values[0] != '':  # 49
                _p = _df1['P'].values[0]
                _s = _df1['S'].values[0]
                if _p == '9999.12.31' and _s == row['AB'].value:
                    row['AA'].cmt('blue', '人事范围继承自岗位财科！')
                elif _p == '9999.12.31' and _s != row['AB'].value:
                    row['AA'].cmt('red', '人事范围继承自岗位财科，但两者不同！')
                elif _p != '9999.12.31' and _s == row['AB'].value:
                    row['AA'].cmt('pink', '人事范围继承自岗位财科，但岗位财科结束日期不为99991231！')
                elif _p != '9999.12.31' and _s != row['AB'].value:
                    row['AA'].cmt('purple', '人事范围与岗位财科不同，且岗位财科结束日期不为99991231！')
            else:  # 50
                _ah = row['AH'].value
                _df2 = df_107_t83_2[(df_107_t83_2['A'] == _ah) & (df_107_t83_2['B'] == 'O')]
                if _df2.empty is False and _df2['S'].values[0] != '':
                    _s = _df2['S'].values[0]
                    _p = _df2['P'].values[0]
                    if _p == '9999.12.31' and _s == row['AB'].value:
                        row['AB'].cmt('blue', '岗位财科无值，人事范围继承自隶属机构财科！')
                    elif _p == '9999.12.31' and _s != row['AB'].value:
                        row['AB'].cmt('red', '岗位财科无值，人事范围与隶属机构财科不同！')
                    elif _p != '9999.12.31' and _s == row['AB'].value:
                        row['AB'].cmt('pink', '岗位财科无值，人事范围继承自隶属机构财科，但机构财科结束日期不为99991231！')
                    elif _p != '9999.12.31' and _s != row['AB'].value:
                        row['AB'].cmt('purple', '岗位财科无值，人事范围与隶属机构财科不同，且机构财科结束日期不为99991231！')
                else:  # 51
                    row['AB'].cmt('green', '岗位财科无值，人事范围继承的是上级机构财科，不是本级隶属机构！')
            if _df1['T'].values[0] != '':  # 52
                _p = _df1['P'].values[0]
                _t = _df1['T'].values[0]
                if _p == '9999.12.31' and _t == row['AC'].value:
                    row['AC'].cmt('blue', '人事子范围代码继承自岗位财科！')
                elif _p == '9999.12.31' and _t != row['AC'].value:
                    row['AC'].cmt('red', '人事子范围代码继承自岗位财科，但两者不同！')
                elif _p != '9999.12.31' and _t == row['AC'].value:
                    row['AC'].cmt('pink', '人事子范围代码继承自岗位财科，但岗位财科结束日期不为99991231！')
                elif _p != '9999.12.31' and _t != row['AC'].value:
                    row['AC'].cmt('purple', '人事子范围代码继承自岗位财科，但两者不同且岗位财科结束日期不为99991231！')
            else:  # 53
                _ah = row['AH'].value
                _df2 = df_107_t83_2[(df_107_t83_2['A'] == _ah) & (df_107_t83_2['B'] == 'O')]
                if _df2.empty is False:
                    _t = _df2['T'].values[0]
                    if _t != '':
                        _p = _df2['P'].values[0]
                        if row['AC'].value == _t and _p == '9999.12.31':
                            row['AD'].cmt('blue', '岗位财科无值，人事子范围代码继承自隶属机构财科！')
                        elif row['AC'].value != _t and _p == '9999.12.31':
                            row['AD'].cmt('red', '岗位财科无值，人事子范围代码与隶属机构财科不同！')
                        elif row['AC'].value == _t and _p != '9999.12.31':
                            row['AD'].cmt('pink', '岗位财科无值，人事子范围代码继承自隶属机构财科，但隶属机构财科结束日期不为99991231！')
                        elif row['AC'].value != _t and _p != '9999.12.31':
                            row['AD'].cmt('purple', '岗位财科无值，人事子范围代码与隶属机构财科不同，且隶属机构财科结束日期不为99991231！')
                    else:  # 54
                        row['AD'].cmt('green', '岗位财科无值，人事子范围代码继承的是上级机构财科，不是本级隶属机构！')
            if _df1['U'].values[0] != '':  # 55
                _p = _df1['P'].values[0]
                _u = _df1['U'].values[0]
                if _p == '9999.12.31' and _u == row['AD'].value:
                    row['AE'].cmt('blue', '人事子范围文本继承自岗位财科！')
                elif _p == '9999.12.31' and _u != row['AD'].value:
                    row['AE'].cmt('red', '人事子范围文本继承自岗位财科，但两者不同！！')
                elif _p != '9999.12.31' and _u == row['AD'].value:
                    row['AE'].cmt('pink', '人事子范围文本继承自岗位财科，但岗位财科结束日期不为99991231！')
                elif _p != '9999.12.31' and _u != row['AD'].value:
                    row['AE'].cmt('purple', '人事子范围文本继承自岗位财科，但两者不同且岗位财科结束日期不为99991231！')
            else:  # 56
                _ah = row['AH'].value
                _df2 = df_107_t83_2[(df_107_t83_2['A'] == _ah) & (df_107_t83_2['B'] == 'O')]
                if _df2.empty is False:
                    _u = _df2['U'].values[0]
                    if _u != '':
                        _p = _df2['P'].values[0]
                        if _p == '9999.12.31' and _u == row['AD'].value:
                            row['AF'].cmt('blue', '岗位财科无值，人事子范围文本继承自隶属机构财科！')
                        elif _p == '9999.12.31' and _u != row['AD'].value:
                            row['AF'].cmt('red', '岗位财科无值，人事子范围文本与隶属机构财科不同！')
                        elif _p != '9999.12.31' and _u == row['AD'].value:
                            row['AF'].cmt('pink', '岗位财科无值，人事子范围文本继承自隶属机构财科，但隶属机构财科结束日期不为99991231！')
                        elif _p != '9999.12.31' and _u != row['AD'].value:
                            row['AF'].cmt('purple', '岗位财科无值，人事子范围文本与隶属机构财科不同，且隶属机构财科结束日期不为99991231！')
                    else:  # 57
                        row['AF'].cmt('green', '岗位财科无值，人事子范围文本继承的是上级机构财科，不是本级隶属机构！')
            if _df1['V'].values[0] != '':  # 58
                _p = _df1['P'].values[0]
                _v = _df1['V'].values[0]
                if _p == '9999.12.31' and _v == row['BB'].value:
                    row['BB'].cmt('blue', '公司代码继承自岗位财科！')
                elif _p == '9999.12.31' and _v != row['BB'].value:
                    row['BB'].cmt('red', '公司代码继承自岗位财科，但两者不同！！')
                elif _p != '9999.12.31' and _v == row['BB'].value:
                    row['BB'].cmt('pink', '公司代码继承自岗位财科，但岗位财科结束日期不为99991231！')
                elif _p != '9999.12.31' and _v != row['BB'].value:
                    row['BB'].cmt('purple', '公司代码继承自岗位财科，但两者不同且岗位财科结束日期不为99991231！')
            else:  # 59
                _ah = row['AH'].value
                _df2 = df_107_t83_2[(df_107_t83_2['A'] == _ah) & (df_107_t83_2['B'] == 'O')]
                if _df2.empty is False:
                    _v = _df2['V'].values[0]
                    if _v != '':
                        _p = _df2['P'].values[0]
                        if _p == '9999.12.31' and _v == row['BB'].value:
                            row['BC'].cmt('blue', '岗位财科无值，公司代码继承自隶属机构财科！')
                        elif _p == '9999.12.31' and _v != row['BB'].value:
                            row['BC'].cmt('red', '岗位财科无值，公司代码与隶属机构财科不同！')
                        elif _p != '9999.12.31' and _v == row['BB'].value:
                            row['BC'].cmt('pink', '岗位财科无值，公司代码继承自隶属机构财科，但隶属机构财科结束日期不为99991231！')
                        elif _p != '9999.12.31' and _v != row['BB'].value:
                            row['BC'].cmt('purple', '岗位财科无值，公司代码与隶属机构财科不同，且隶属机构财科结束日期不为99991231！')
                    else:  # 60
                        row['BC'].cmt('green', '岗位财科无值，公司代码继承的是上级机构财科，不是本级隶属机构！')
            if _df1['W'].values[0] != '':  # 61
                _p = _df1['P'].values[0]
                _w = _df1['W'].values[0]
                if _p == '9999.12.31' and _w == row['AX'].value:
                    row['AX'].cmt('blue', '业务范围继承自隶属机构财科！')
                elif _p == '9999.12.31' and _w != row['AX'].value:
                    row['AX'].cmt('red', '业务范围继承自岗位财科，但两者不同！！')
                elif _p != '9999.12.31' and _w == row['AX'].value:
                    row['AX'].cmt('pink', '业务范围继承自岗位财科，但岗位财科结束日期不为99991231！')
                elif _p != '9999.12.31' and _w != row['AX'].value:
                    row['AX'].cmt('purple', '业务范围继承自岗位财科，但两者不同且岗位财科结束日期不为99991231！')
            else:  # 62
                _ah = row['AH'].value
                _df2 = df_107_t83_2[(df_107_t83_2['A'] == _ah) & (df_107_t83_2['B'] == 'O')]
                if _df2.empty is False:
                    _w = _df2['W'].values[0]
                    if _w != '':
                        _p = _df2['P'].values[0]
                        if _p == '9999.12.31' and _w == row['AX'].value:
                            row['AY'].cmt('blue', '岗位财科无值，业务范围继承自隶属机构财科！')
                        elif _p == '9999.12.31' and _w != row['AX'].value:
                            row['AY'].cmt('red', '岗位财科无值，业务范围与隶属机构财科不同！')
                        elif _p != '9999.12.31' and _w == row['AX'].value:
                            row['AY'].cmt('pink', '岗位财科无值，业务范围继承自隶属机构财科，但隶属机构财科结束日期不为99991231！')
                        elif _p != '9999.12.31' and _w != row['AX'].value:
                            row['AY'].cmt('purple', '岗位财科无值，业务范围与隶属机构财科不同，且隶属机构财科结束日期不为99991231！')
                    else:  # 63
                        row['AY'].cmt('green', '岗位财科无值，业务范围继承的是上级机构财科，不是本级隶属机构！')


def chk_07(lt_103_t69_2: AdTable):  # 64-65
    """判断人身上成本分配与组织分配屏成本中心是否相同"""
    df_103_t69_2: DataFrame = lt_103_t69_2.to_dataframe()
    for rn in df_103_t69_2.index:
        if df_103_t69_2['P'][rn] != '' and df_103_t69_2['P'][rn] == df_103_t69_2['Z'][rn]:
            lt_103_t69_2['Q'][rn].cmt('orange', '人员成本分配屏上的成本中心与组织分配屏的成本中心相同！')


def checker2(lt_103_t69_2: AdTable, lt_107_t83_2: AdTable):
    df_103_t69_2 = lt_103_t69_2.to_dataframe()
    df_107_t83_2 = lt_107_t83_2.to_dataframe()
    logging.info('执行校验项：39 标记无组织分配K的人员')
    chk_01(lt_103_t69_2, df_103_t69_2)
    logging.info('执行校验项：40-41 标记组织分配有多个K的人员，并查询是否已被定界')
    chk_02(lt_103_t69_2, df_103_t69_2)
    logging.info('执行校验项：42-45 定位组织分配K的来源（先岗位再机构），并查询是否已被定界')
    chk_03(lt_103_t69_2, df_107_t83_2)
    logging.info('执行校验项：46-47 判断岗位和机构上是否存在成本分配，并查询是否已被定界')
    chk_04(lt_103_t69_2, df_107_t83_2)
    logging.info('执行校验项：48 判断人身上是否存在成本分配，并查询是否已被定界')
    chk_05(lt_103_t69_2, df_107_t83_2)
    logging.info('执行校验项：49-63 定位组织分配信息继承自岗位财科还是机构财科，并查询财科是否已被定界')
    chk_06(lt_103_t69_2, df_107_t83_2)
    logging.info('执行校验项：64-65 判断人身上成本分配与组织分配屏成本中心是否相同')
    chk_07(lt_103_t69_2)
