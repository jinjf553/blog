import logging

from pandas import DataFrame
from rpa.fastrpa.adtable import AdTable, AdTableRow
from rpa.ssc.hr.sap.export_103_t69 import export_103_t69
from rpa.ssc.hr.sap.export_107_t83_3 import export_107_t83_3
from rpa.ssc.hr.sap.export_107_t83_4 import export_107_t83_4
from rpa.ssc.hr.sap.export_ks02 import export_ks02


def chk_01(lt_t83_2: AdTable, df_t83_2: DataFrame):  # 4
    """机构存在成本分配"""
    _df = df_t83_2[(df_t83_2['B'] == 'O') & (df_t83_2['K'] == 'O') & (df_t83_2['Y'] != '0000.00.00') & (df_t83_2['Y'] == '9999.12.31')]
    for rn in _df.index:
        if df_t83_2['AB'][rn] != '':
            lt_t83_2['AB'][rn].cmt('purple', '机构成本分配上有成本中心！')  # 紫色
        if df_t83_2['AC'][rn] != '':
            lt_t83_2['AC'][rn].cmt('purple', '机构成本分配上有订单！')
        if df_t83_2['AD'][rn] != '':
            lt_t83_2['AD'][rn].cmt('purple', '机构成本分配上有WBS元素！')


def chk_02(lt_t83_2: AdTable, df_t83_2: DataFrame):  # 5
    """机构存在成本分配，且已被定界"""
    _df = df_t83_2[(df_t83_2['B'] == 'O') & (df_t83_2['K'] == 'O') & (df_t83_2['Y'] != '0000.00.00') & (df_t83_2['Y'] != '9999.12.31')]
    for rn in _df.index:
        if df_t83_2['AB'][rn] != '':
            lt_t83_2['AB'][rn].cmt('red', '机构成本分配上有成本中心，且其结束日期不为99991231！')
        if df_t83_2['AC'][rn] != '':
            lt_t83_2['AC'][rn].cmt('red', '机构成本分配上有订单，且其结束日期不为99991231！')
        if df_t83_2['AD'][rn] != '':
            lt_t83_2['AD'][rn].cmt('red', '机构成本分配上有WBS元素，且其结束日期不为99991231！')


def chk_03(lt_t83_2: AdTable, df_t83_2: DataFrame):  # 6
    """机构财科为空"""
    _df = df_t83_2[(df_t83_2['B'] == 'O') & (df_t83_2['K'] == 'O') & (df_t83_2['P'] != '0000.00.00') & (df_t83_2['P'] == '9999.12.31')]
    for rn in _df.index:
        if df_t83_2['S'][rn] == '':
            lt_t83_2['S'][rn].cmt('purple', '人事范围未设置在机构财务科目设置上！')
        if df_t83_2['T'][rn] == '':
            lt_t83_2['T'][rn].cmt('purple', '人事子范围未设置在机构财务科目设置上！')
        if df_t83_2['V'][rn] == '':
            lt_t83_2['V'][rn].cmt('blue', '公司代码未设置在机构财务科目设置上！')
        if df_t83_2['W'][rn] == '':
            lt_t83_2['W'][rn].cmt('blue', '业务范围未设置在机构财务科目设置上！')


def chk_04(lt_t83_2: AdTable, df_t83_2: DataFrame):  # 7
    """机构财科为空，且已被定界"""
    _df = df_t83_2[(df_t83_2['B'] == 'O') & (df_t83_2['K'] == 'O') & (df_t83_2['P'] != '0000.00.00') & (df_t83_2['P'] != '9999.12.31')]
    for rn in _df.index:
        if df_t83_2['S'][rn] == '':
            lt_t83_2['S'][rn].cmt('red', '人事范围未设置在机构财务科目设置上，且其结束日期不为99991231！')
        if df_t83_2['T'][rn] == '':
            lt_t83_2['T'][rn].cmt('red', '人事子范围未设置在机构财务科目设置上，且其结束日期不为99991231！')
        if df_t83_2['V'][rn] == '':
            lt_t83_2['V'][rn].cmt('pink', '公司代码未设置在机构财务科目设置上，且其结束日期不为99991231！')  # 粉色
        if df_t83_2['W'][rn] == '':
            lt_t83_2['W'][rn].cmt('pink', '业务范围未设置在机构财务科目设置上，且其结束日期不为99991231！')  # 粉色


def chk_05(lt_t83_2: AdTable, df_t83_2: DataFrame):  # 8
    """岗位存在成本分配"""
    _df = df_t83_2[(df_t83_2['B'] == 'S') & (df_t83_2['Y'] != '0000.00.00') & (df_t83_2['Y'] == '9999.12.31')]
    for rn in _df.index:
        if df_t83_2['AB'][rn] != '':
            lt_t83_2['AB'][rn].cmt('970080', '岗位成本分配上有成本中心！')  # 深紫色
        if df_t83_2['AC'][rn] != '':
            lt_t83_2['AC'][rn].cmt('970080', '岗位成本分配上有订单！')  # 深紫色
        if df_t83_2['AD'][rn] != '':
            lt_t83_2['AD'][rn].cmt('970080', '岗位成本分配上有WBS元素！')  # 深紫色


def chk_06(lt_t83_2: AdTable, df_t83_2: DataFrame):  # 9
    """岗位存在成本分配，且已被定界"""
    _df = df_t83_2[(df_t83_2['B'] == 'S') & (df_t83_2['Y'] != '0000.00.00') & (df_t83_2['Y'] != '9999.12.31')]
    for rn in _df.index:
        if df_t83_2['AB'][rn] != '':
            lt_t83_2['AB'][rn].cmt('E681B6', '岗位成本分配上有成本中心，且其结束日期不为99991231！')  # 淡紫色
        if df_t83_2['AC'][rn] != '':
            lt_t83_2['AC'][rn].cmt('E681B6', '岗位成本分配上有订单，且其结束日期不为99991231！')  # 淡紫色
        if df_t83_2['AD'][rn] != '':
            lt_t83_2['AD'][rn].cmt('E681B6', '岗位成本分配上有WBS元素，且其结束日期不为99991231！')  # 淡紫色


def chk_07(lt_t83_2: AdTable, df_t83_2: DataFrame):  # 10
    """岗位财科为空"""
    _df = df_t83_2[(df_t83_2['B'] == 'S') & (df_t83_2['P'] != '0000.00.00') & (df_t83_2['P'] == '9999.12.31')]
    for rn in _df.index:
        if df_t83_2['S'][rn] != '':
            lt_t83_2['S'][rn].cmt('970080', '人事范围设置在岗位财务科目设置上！')  # 深紫色
        if df_t83_2['T'][rn] != '':
            lt_t83_2['T'][rn].cmt('970080', '人事子范围设置在岗位财务科目设置上！')  # 深紫色
        if df_t83_2['V'][rn] != '':
            lt_t83_2['V'][rn].cmt('970080', '公司代码设置在岗位财务科目设置上！')  # 深紫色
        if df_t83_2['W'][rn] != '':
            lt_t83_2['W'][rn].cmt('970080', '业务范围设置在岗位财务科目设置上！')  # 深紫色


def chk_08(lt_t83_2: AdTable, df_t83_2: DataFrame):  # 11
    """岗位财科为空，且已被定界"""
    _df = df_t83_2[(df_t83_2['B'] == 'S') & (df_t83_2['P'] != '0000.00.00') & (df_t83_2['P'] != '9999.12.31')]
    for rn in _df.index:
        if df_t83_2['S'][rn] != '':
            lt_t83_2['S'][rn].cmt('E681B6', '人事范围未设置在岗位财务科目设置上，且其结束日期不为99991231！')  # 淡紫色
        if df_t83_2['T'][rn] != '':
            lt_t83_2['T'][rn].cmt('E681B6', '人事子范围设置在岗位财务科目设置上，且其结束日期不为99991231！')  # 淡紫色
        if df_t83_2['V'][rn] != '':
            lt_t83_2['V'][rn].cmt('E681B6', '公司代码设置在岗位财务科目设置上，且其结束日期不为99991231！')  # 淡紫色
        if df_t83_2['W'][rn] != '':
            lt_t83_2['W'][rn].cmt('E681B6', '业务范围设置在岗位财务科目设置上，且其结束日期不为99991231！')  # 淡紫色


def chk_09(lt_t83_2: AdTable, df_t83_2: DataFrame):  # 12
    """机构财科无K"""
    _df = df_t83_2[(df_t83_2['B'] == 'O')].copy()  # 锁定【T83-2 ~【B-OT】】为“O”的行
    _df['INCLUDE_K'] = _df['K'].apply(lambda v: 1 if v == 'K' else 0)  # 增加新列INCLUDE_K，K列为K置为1，非K置为0
    _df['INCLUDE_ANY_K'] = _df['INCLUDE_K'].groupby([_df['A']]).transform('max')  # 根据A列汇总，取INCLUDE_K列最大值
    for rn in _df[_df['INCLUDE_ANY_K'] == 0].index:
        lt_t83_2['A'][rn].cmt('orange', '成本中心未设置在机构财务科目设置上！')


def chk_10(lt_t83_2: AdTable, df_t83_2: DataFrame):  # 13
    """机构财科有K，且已被定界"""
    _df = df_t83_2[(df_t83_2['B'] == 'O')].copy()  # 锁定【T83-2 ~【B-OT】】为“O”的行
    _df['INCLUDE_K'] = _df.apply(lambda row: 1 if row['K'] == 'K' and row['D'] != '9999.12.31' else 0, axis=1)
    _df['INCLUDE_ANY_K'] = _df['INCLUDE_K'].groupby([_df['A']]).transform('max')
    for rn in _df[_df['INCLUDE_ANY_K'] == 1].index:
        lt_t83_2['D'][rn].cmt('red', '成本中心设置在机构财务科目设置上，但其结束日期不为99991231！')


def _export_107_t83_3(lt_t83_2: AdTable, df_t83_2: DataFrame, key_date='', begin_date='', end_date='') -> AdTable:
    """锁定【T83-2 ~【B-OT】=S 且【K-RO】=K】的【A-对象标识】，进入组合逻辑查询结果处理程序（107----T83-3，自动生成表格）"""
    sap_ids = list(set(df_t83_2[(df_t83_2['B'] == 'S') & (df_t83_2['K'] == 'K')]['A']))
    return export_107_t83_3(None, sap_ids, key_date, begin_date, end_date)


def _export_107_t83_4(lt_t83_3: AdTable, df_t83_3: DataFrame, key_date='', begin_date='', end_date='') -> AdTable:
    """锁定【T83-3 ~【A-对象标识】】，进入组合逻辑查询结果处理程序（107----T83-4，自动生成表格）"""
    sap_ids = list(set(df_t83_3['A']))
    return export_107_t83_4(None, sap_ids, key_date, begin_date, end_date)


def _export_103_t69(row: AdTableRow, lt_t83_3: AdTable, df_t83_3: DataFrame, key_date='', begin_date='', end_date='') -> AdTable:
    """锁定【T83-3 ~【J-相关对象的标识】】，进入组合逻辑查询结果处理程序（103----___T69，自动生成表格）"""
    sap_ids = list(set(df_t83_3['J']))
    if len(sap_ids) == 0:
        row['A'].cmt('green', '该岗位为空岗！')
        raise Exception('该岗位为空岗！')
    return export_103_t69(None, sap_ids, key_date, begin_date, end_date)


def _export_ks02(lt_t83_2: AdTable) -> AdTable:
    """提取【T83-2 ~【K-RO】=K】 的【L-相关对象的标识】，删除重复值，去除末尾的“SINO”，填入“KS02数据提取程序表”，执行“KS02数据提取程序”"""
    df_t83_2: DataFrame = lt_t83_2.to_dataframe()
    sap_ids = list(set(df_t83_2[df_t83_2['K'] == 'K']['L']))
    sap_ids = [sap_id.replace('SINO', '') if 'SINO' in sap_id else sap_id for sap_id in sap_ids]
    return export_ks02(sap_ids)


def t83_2_checker(lt_t83_2: AdTable):
    df_t83_2: DataFrame = lt_t83_2.to_dataframe()
    logging.info('执行校验项：机构存在成本分配')
    chk_01(lt_t83_2, df_t83_2)  # 机构存在成本分配
    logging.info('执行校验项：机构存在成本分配，且已被定界')
    chk_02(lt_t83_2, df_t83_2)  # 机构存在成本分配，且已被定界
    logging.info('执行校验项：机构财科为空')
    chk_03(lt_t83_2, df_t83_2)  # 机构财科为空
    logging.info('执行校验项：机构财科为空，且已被定界')
    chk_04(lt_t83_2, df_t83_2)  # 机构财科为空，且已被定界
    logging.info('执行校验项：岗位存在成本分配')
    chk_05(lt_t83_2, df_t83_2)  # 岗位存在成本分配
    logging.info('执行校验项：岗位存在成本分配，且已被定界')
    chk_06(lt_t83_2, df_t83_2)  # 岗位存在成本分配，且已被定界
    logging.info('执行校验项：岗位财科为空')
    chk_07(lt_t83_2, df_t83_2)  # 岗位财科为空
    logging.info('执行校验项：岗位财科为空，且已被定界')
    chk_08(lt_t83_2, df_t83_2)  # 岗位财科为空，且已被定界
    logging.info('执行校验项：机构财科无K')
    chk_09(lt_t83_2, df_t83_2)  # 机构财科无K
    logging.info('执行校验项：机构财科有K，且已被定界')
    chk_10(lt_t83_2, df_t83_2)  # 机构财科有K，且已被定界


def t83_3_checker(lt_t83_2: AdTable, lt_t83_3: AdTable):
    """导出二次表，以有财科K的岗位为对象，查询岗下是否有人"""
    logging.info('执行校验项：导出二次表，以有财科K的岗位为对象，查询岗下是否有人')
    df_t83_2: DataFrame = lt_t83_2.to_dataframe()
    df_t83_3: DataFrame = lt_t83_3.to_dataframe()
    sap_ids = set(df_t83_2[(df_t83_2['B'] == 'S') & (df_t83_2['K'] == 'K')]['A']) - set(df_t83_3['A'])
    for rn in df_t83_2.index:
        if df_t83_2['B'][rn] == 'S' and df_t83_2['A'][rn] in sap_ids:
            if df_t83_2['D'][rn] == '9999.12.31':
                lt_t83_2['L'][rn].cmt('orange', '成本中心设置在岗位财务科目设置上，岗下无人，可以直接定界岗位财科上的成本中心！')
            else:
                lt_t83_2['L'][rn].cmt('red', '成本中心设置在岗位财务科目设置上，岗下无人，其结束日期不为99991231！请确认岗位财科上的成本中心的定界日期是否正确！')


def t83_4_checker(lt_t83_2: AdTable, lt_t83_4: AdTable):
    """导出三次表，以有财科K且有人的岗位为对象，查询岗位隶属机构财科K"""
    logging.info('执行校验项：导出三次表，以有财科K且有人的岗位为对象，查询岗位隶属机构财科K')
    df_t83_2: DataFrame = lt_t83_2.to_dataframe()
    df_t83_4: DataFrame = lt_t83_4.to_dataframe()
    _df1 = df_t83_4[(df_t83_4['B'] == 'S') & (df_t83_4['M'] == 'K')]  # 锁定【T83-4 ~【B-OT】=S 且【M-RO】=K】的行
    _df2 = df_t83_4[(df_t83_4['B'] == 'O') & (df_t83_4['M'] == 'K')]  # 再锁定“紧邻”的【T83-4 ~【B-OT】=O】且【M-RO】="K"的行
    rns = list(_df2.index)
    for rn in _df1.index:
        try:
            rn2 = min(filter(lambda v: v > rn, rns))
        except ValueError:
            rn2 = None
        if rn2 is None:  # 若不存在
            sap_id = _df1['A'][rn]
            _df3 = df_t83_2[(df_t83_2['B'] == 'S') & (df_t83_2['K'] == 'O') & (df_t83_2['L'] == sap_id)]
            for rn3 in _df3.index:
                lt_t83_2['L'][rn3].cmt('lightpink', '岗位财科K有值，隶属机构财科K无值，岗下有人。')
        else:  # 若存在
            if _df1['N'][rn] == _df2['N'][rn2]:
                sap_id = _df1['A'][rn]
                _df3 = df_t83_2[(df_t83_2['B'] == 'S') & (df_t83_2['K'] == 'O') & (df_t83_2['L'] == sap_id)]
                for rn3 in _df3.index:
                    lt_t83_2['L'][rn3].cmt('pink', '岗位财科K与隶属机构财科K相同，岗下有人，可以直接定界岗位财科上的成本中心。')
            else:
                sap_id = _df1['A'][rn]
                _df3 = df_t83_2[(df_t83_2['B'] == 'S') & (df_t83_2['K'] == 'O') & (df_t83_2['L'] == sap_id)]
                for rn3 in _df3.index:
                    lt_t83_2['L'][rn3].cmt('purple', '岗位财科K与隶属机构财科K不同，岗下有人，请自行判定如何处置！')


def t69_checker(lt_t83_2: AdTable, lt_t69: AdTable):  # 24-27
    """导出四次表，以有财科K的岗位下的人员为对象，查询组织分配K"""
    logging.info('执行校验项：导出四次表，以有财科K的岗位下的人员为对象，查询组织分配K')
    df_t83_2: DataFrame = lt_t83_2.to_dataframe()
    _df = df_t83_2[(df_t83_2['B'] == 'S') & (df_t83_2['K'] == 'K')]
    for rn in _df.index:
        sap_id = _df['A'][rn]
        tmp_aj = lt_t69['AJ'].find(sap_id)
        if tmp_aj is None:
            lt_t83_2['A'][rn].cmt('green', '该岗位为空岗！')  # 24
        else:
            _103_row = tmp_aj.row_idx
            _103_t69_a = _103_row['A'].value  # 人员编号
            if _df['L'][rn] != _103_row['Z'].value + 'SINO':
                # _103_t69_a = _103_row['A'].value  # 人员编号
                # _103_t69_z = _103_row['Z'].value  # 成本中心
                # _103_t69_aa = _103_row['AA'].value  # 成本中心
                lt_t83_2['M'][rn].cmt('red', f'{_103_t69_a}  人员成本分配上有成本中心！')  # 26
            if _103_row['P'].value != '':
                lt_t83_2['X'][rn].cmt('blue', f'{_103_t69_a}  人员成本分配上有成本中心！')  # 27
            if _103_row['R'].value != '':
                lt_t83_2['Y'][rn].cmt('blue', f'{_103_t69_a}  人员成本分配上有成本中心！')  # 27
            if _103_row['T'].value != '':
                lt_t83_2['Z'][rn].cmt('blue', f'{_103_t69_a}  人员成本分配上有成本中心！')  # 27


def ks02_checker(lt_t83_2: AdTable, lt_ks02: AdTable):  # 23-29
    """通过KS02调取成本中心信息，反写进T83-2"""
    df_t83_2: DataFrame = lt_t83_2.to_dataframe()
    _df = df_t83_2[df_t83_2['K'] == 'K']
    lt_t83_2['AG'][1].value = '成本中心关联的公司代码'
    lt_t83_2['AH'][1].value = '成本中心关联的业务范围'
    lt_t83_2['AI'][1].value = '成本中心关联的功能范围'
    lt_t83_2['AJ'][1].value = '成本中心关联的利润中心'
    for rn in _df.index:
        cost_center_id = _df['L'][rn].replace('SINO', '')  # 23
        if lt_ks02['A'].find(cost_center_id) is not None:
            row = lt_ks02['A'].find(cost_center_id).row_idx
            lt_t83_2['AG'][rn].value = row['B'].value
            lt_t83_2['AH'][rn].value = row['C'].value
            lt_t83_2['AI'][rn].value = row['D'].value
            lt_t83_2['AJ'][rn].value = row['E'].value
    df_t83_2 = lt_t83_2.to_dataframe()
    _df = df_t83_2[df_t83_2['K'] == 'K']
    for rn in _df.index:
        if _df['S'][rn] != '':
            if _df['AG'][rn] != _df['S'][rn]:
                lt_t83_2['AF'][rn].cmt('red', '成本中心关联的公司代码与财科中的人事范围不同！')
        if _df['V'][rn] != '':
            if _df['AG'][rn] != _df['V'][rn]:
                lt_t83_2['AG'][rn].cmt('red', '成本中心关联的公司代码与财科中的公司代码不同！')
        if _df['W'][rn] != '':
            if _df['AH'][rn] != _df['W'][rn]:
                lt_t83_2['AG'][rn].cmt('red', '成本中心关联的业务范围与财科中的业务范围不同！')
