import datetime
import logging
import traceback
from pathlib import Path

import rpa.config
from openpyxl.styles import Font
from rpa.fastrpa.adtable import RED, AdTable, load_from_xlsx_file
from rpa.fastrpa.log import config
from rpa.ssc.hr.sap.export_103_t69_2 import export_103_t69_2
from rpa.ssc.hr.sap.export_107_t83_2 import export_107_t83_2
from rpa.ssc_kit.hr.kit_cost_center import checker1, checker2


def alert_header(lt: AdTable) -> None:
    """如某列有批注，则将第一行背景色置为黄色，字体加粗、红色"""
    for column in lt.columns:
        for cell in column.cells:
            if cell.comment is not None:
                lt[column.column_letter][1].set_fgcolor('yellow')
                lt[column.column_letter][1].cell.font = Font(bold=True, color=RED)
                break


def main(filename: str):
    logging.info(f'加载模板文件:{filename}')
    yyyymmdd = datetime.datetime.now().strftime(r'%Y%m%d')
    lt_template: AdTable = load_from_xlsx_file(filename)
    logging.info('加载模板成功')
    lt_template.apply(lambda v: v.strip(' \t') if isinstance(v, str) else v)
    for row in lt_template.rows:
        if row['A'].value == '107' and row['B'].value == '----T83-2':
            is_check_passed = True
            for i in range(3):  # 如出错，尝试3次
                sap_id = row['D'].value  # 机构编码
                key_date = row['E'].value
                begin_date = row['F'].value
                end_date = row['G'].value
                is_check_passed = True
                try:
                    logging.info(f'--------------------- {sap_id} ---------------------')
                    logging.info(f'结果文件保存至[{rpa.config.D_RPA}/成本中心定位/{yyyymmdd}/{sap_id}/]目录下')
                    Path(f'{rpa.config.D_RPA}/成本中心定位/{yyyymmdd}/{sap_id}/').mkdir(parents=True, exist_ok=True)
                    lt_t83_2: AdTable = export_107_t83_2(None, [sap_id], key_date=key_date, begin_date=begin_date, end_date=end_date)
                    lt_t83_2.filename = sap_id + '_' + lt_t83_2.filename
                    checker1.t83_2_checker(lt_t83_2)
                    df_t83_2 = lt_t83_2.to_dataframe()
                    lt_t83_2.uniq_all_column_comments()
                    alert_header(lt_t83_2)
                    lt_t83_2.save_to(f'{rpa.config.D_RPA}成本中心定位/{yyyymmdd}/{sap_id}/')
                    # 导出二次表，以有财科K的岗位为对象，查询岗下是否有人
                    export_msg = ''
                    try:
                        lt_t83_3: AdTable = checker1._export_107_t83_3(lt_t83_2, df_t83_2, key_date=key_date, begin_date=begin_date, end_date=end_date)
                        lt_t83_3.filename = sap_id + '_' + lt_t83_3.filename
                    except Exception as e:
                        export_msg = str(e)
                        if '岗位编号全为空值' not in export_msg and '未选取数据' not in export_msg:  # 其他错误原因
                            raise e
                    if export_msg == '':  # 导出T83-3无错误
                        checker1.t83_3_checker(lt_t83_2, lt_t83_3)
                        df_t83_3 = lt_t83_3.to_dataframe()
                        lt_t83_2.uniq_all_column_comments()
                        alert_header(lt_t83_2)
                        lt_t83_2.save_to(f'{rpa.config.D_RPA}/成本中心定位/{yyyymmdd}/{sap_id}/')
                        lt_t83_3.save_to(f'{rpa.config.D_RPA}/成本中心定位/{yyyymmdd}/{sap_id}/')
                        # 导出三次表，以有财科K且有人的岗位为对象，查询岗位隶属机构财科K
                        lt_t83_4: AdTable = checker1._export_107_t83_4(lt_t83_3, df_t83_3, key_date=key_date, begin_date=begin_date, end_date=end_date)
                        lt_t83_4.filename = sap_id + '_' + lt_t83_4.filename
                        checker1.t83_4_checker(lt_t83_2, lt_t83_4)
                        lt_t83_2.uniq_all_column_comments()
                        alert_header(lt_t83_2)
                        lt_t83_2.save_to(f'{rpa.config.D_RPA}/成本中心定位/{yyyymmdd}/{sap_id}/')
                        lt_t83_3.save_to(f'{rpa.config.D_RPA}/成本中心定位/{yyyymmdd}/{sap_id}/')
                        lt_t83_4.save_to(f'{rpa.config.D_RPA}/成本中心定位/{yyyymmdd}/{sap_id}/')
                        # 导出四次表，以有财科K的岗位下的人员为对象，查询组织分配K
                        lt_103_t69 = checker1._export_103_t69(row, lt_t83_3, df_t83_3, key_date=key_date, begin_date=begin_date, end_date=end_date)
                        lt_103_t69.filename = sap_id + '_' + lt_103_t69.filename
                        lt_103_t69.save_to(f'{rpa.config.D_RPA}/成本中心定位/{yyyymmdd}/{sap_id}/')
                        checker1.t69_checker(lt_t83_2, lt_103_t69)
                        lt_t83_2.uniq_all_column_comments()
                        alert_header(lt_t83_2)
                        lt_t83_2.save_to(f'{rpa.config.D_RPA}/成本中心定位/{yyyymmdd}/{sap_id}/')
                    elif '未选取数据' in export_msg:
                        _df = df_t83_2[(df_t83_2['B'] == 'S') & (df_t83_2['K'] == 'K')]  # 15-16
                        for rn in _df.index:
                            if _df['D'][rn] == '9999.12.31':
                                lt_t83_2['L'][rn].cmt('orange', '成本中心设置在岗位财务科目设置上，岗下无人，可以直接定界岗位财科上的成本中心！')
                            else:
                                lt_t83_2['L'][rn].cmt('red', '成本中心设置在岗位财务科目设置上，岗下无人，其结束日期不为99991231！请确认岗位财科上的成本中心的定界日期是否正确！')
                    # 通过KS02调取成本中心信息，反写进T83-2
                    lt_ks02 = checker1._export_ks02(lt_t83_2)
                    lt_ks02.filename = sap_id + '_' + lt_ks02.filename
                    checker1.ks02_checker(lt_t83_2, lt_ks02)
                    lt_t83_2.uniq_all_column_comments()
                    alert_header(lt_t83_2)
                    lt_t83_2.save_to(f'{rpa.config.D_RPA}/成本中心定位/{yyyymmdd}/{sap_id}/')
                    lt_ks02.save_to(f'{rpa.config.D_RPA}/成本中心定位/{yyyymmdd}/{sap_id}/')
                except Exception as e:
                    is_check_passed = False
                    logging.error(e)
                    logging.error(f"异常原因: {traceback.format_exc()}")
                below_row = row['A'].down_cell.row_idx
                if is_check_passed is True:
                    break
            if is_check_passed is False:  # 尝试3遍仍失败
                with open(f'{rpa.config.D_RPA}/成本中心定位/{yyyymmdd}/失败记录.txt', 'a+', encoding='utf-8', ) as f:
                    f.write(f'{sap_id}第一部分规则尝试执行3次后仍失败\n')
            for i in range(3):  # 如出错，尝试3次
                is_check_passed = True
                if below_row['A'].value == '103' or below_row['B'].value == '___T69-2':  # 第二部分规则
                    sap_id = row['D'].value
                    key_date = row['E'].value
                    begin_date = row['F'].value
                    end_date = row['G'].value
                    try:
                        staff_rngs = [staff_rng.strip(' \t\r\n') for staff_rng in below_row['C'].value.split('、')]  # 人事范围以顿号分割，会有多个
                        begin_date = below_row['F'].value
                        end_date = below_row['G'].value
                        lt_t69_2: AdTable = export_103_t69_2(None, staff_rngs, key_date=key_date, begin_date=begin_date, end_date=end_date)
                        lt_t69_2.filename = sap_id + '_' + lt_t69_2.filename
                        checker2.checker2(lt_t69_2, lt_t83_2)
                        lt_t83_2.uniq_all_column_comments()
                        lt_t69_2.uniq_all_column_comments()
                        alert_header(lt_t83_2)
                        alert_header(lt_t69_2)
                        lt_t83_2.save_to(f'{rpa.config.D_RPA}/成本中心定位/{yyyymmdd}/{sap_id}/')
                        lt_t69_2.save_to(f'{rpa.config.D_RPA}/成本中心定位/{yyyymmdd}/{sap_id}/')
                    except Exception as e:
                        is_check_passed = False
                        logging.error(e)
                        logging.error(f"异常原因: {traceback.format_exc()}")
                if is_check_passed is True:
                    break
            if is_check_passed is False:  # 尝试3遍仍失败
                with open(f'{rpa.config.D_RPA}/成本中心定位/{yyyymmdd}/失败记录.txt', 'a+', encoding='utf-8', ) as f:
                    f.write(f'{sap_id}第二部分规则尝试执行3次后仍失败\n')


# python -m coverage run .\rpa\ssc_kit\hr\cost_center_checker\run.py
# python -m coverage html .\rpa\ssc_kit\hr\cost_center_checker\run.py
if __name__ == '__main__':
    config()
    main('x:/规则模板.xlsx')
