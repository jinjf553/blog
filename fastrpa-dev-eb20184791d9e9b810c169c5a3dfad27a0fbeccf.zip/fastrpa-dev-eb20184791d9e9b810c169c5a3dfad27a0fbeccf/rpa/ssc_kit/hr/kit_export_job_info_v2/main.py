"""机构岗位查询分析_V2(可设置显示深度)
   pyinstaller --clean -F -c --noupx --key=PBmmQGUYL3xF4kbD --add-binary='./rpa/fastrpa/third_party/encrypt;./rpa/fastrpa/third_party/encrypt' -n 机构岗位查询分析_V2[可设置显示深度] ./rpa/ssc_kit/hr/export_job_info_v2/main.py
"""
import logging
import pathlib
import sys
from pathlib import Path
from time import sleep
from typing import Any

import pyperclip
import pythoncom
from rpa.fastrpa.adtable import AdTable, AdTableRow, load_from_xlsx_file
from rpa.fastrpa.date_funcs import valid_date
from rpa.fastrpa.log import config
from rpa.fastrpa.sap.session import SapClose, attach_sap
from rpa.fastrpa.tempdir import gentempdir
from rpa.fastrpa.utils.peek_encoding import peek_file_encoding
from rpa.ssc.hr.rpa_dir import get_rpa_dir
from rpa.ssc.sap.query import parse_query_string
from rpa.ssc.sap.utils import init_sap_id, init_sap_value

RPA_DIR = ''


def chk_01(row: AdTableRow) -> bool:
    """检验机构编码是否8位数字"""
    if len(row['A'].value) != 8:
        row['A'].cmt('red', '机构编码非8位')
        return False
    return True


def chk_02(row: AdTableRow) -> bool:
    """当关键日期有值时，开始日期，结束日期无效；
       当关键日期为空时，检验开始日期，结束日期是否都不为空；
       检验日期格式是否为8位数字，符合常识；"""
    if valid_date(row['B'].value) is True and row['C'].value == '' and row['D'].value == '':
        return True
    # 第4种事务码只有关键日期
    elif row['B'].value == '' and valid_date(row['C'].value) is True and valid_date(row['D'].value) is True and row['E'].value != 'S_AHR_61016503':
        return True
    else:
        row['B'].cmt('red', '请检查【关键日期/开始日期、结束日期】')
        return False


def chk_02b(row: AdTableRow) -> bool:
    key_date = row['B'].value
    keycode = row['E'].value
    if key_date != '':  # 该口令下，所有关键日期应相同(空除外)
        values = [value for value in row.table['E'].find_all(keycode).same_line('B').values if value != '']
        if max(values) != min(values):
            row['B'].cmt('red', '同一口令下，所有关键日期应相同')
            return False
    else:
        values_c = [value for value in row.table['E'].find_all(keycode).same_line('C').values if value != '']
        values_d = [value for value in row.table['E'].find_all(keycode).same_line('D').values if value != '']
        if max(values_c) != min(values_c) or max(values_d) != min(values_d):
            row['C'].cmt('red', '同一口令下，所有开始日期与结束日期应相同')
            return False
    return True


def chk_03(row: AdTableRow) -> bool:
    """检验口令是否是下属四种中的一种：S_AHR_61016493、S_AHR_61016494、S_AHR_61016495、S_AHR_61016503"""
    if row['E'].value in ('S_AHR_61016493', 'S_AHR_61016494', 'S_AHR_61016495', 'S_AHR_61016503'):
        return True
    else:
        row['E'].cmt('red', '口令非预定义值之一（S_AHR_61016493、S_AHR_61016494、S_AHR_61016495、S_AHR_61016503）')
        return False


def chk_04a(row: AdTableRow) -> bool:
    is_check_passed = True
    if row['F'].value not in ('是', '否'):
        row['F'].cmt('red', '【F-标准选择屏幕标识】只能为是或否')
        is_check_passed = False
    elif row['F'].value == '是' and row['G'].value == '':
        row['G'].cmt('red', '评估路径不能为空')
        is_check_passed = False
    elif row['F'].value == '是' and row['H'].value not in ('1', '2', '3', '4', '5', '6', '7', '8', '9', '10'):
        row['H'].cmt('red', '显示深度必须是正整数（当前仅支持1-10）')
        is_check_passed = False
    return is_check_passed


def chk_04(row: AdTableRow) -> str:
    """检验完成后，在命令框输入代码时，前置【/n 】(/n空格)"""
    return '/n ' + row['E'].value


def export_guitree(filename: str, session: Any):
    logging.info(f'正在导出文件：{filename}')
    lt_job = AdTable(filename)
    obj_type_col = 4
    logging.info('展开节点')
    sap_gui_tree = session.findById("wnd[0]/usr/cntlCUSTOM_CONTROL/shellcont/shell/shellcont[1]/shell[1]")
    key = sap_gui_tree.GetAllNodeKeys()[0]
    while True:
        try:
            is_expandable = sap_gui_tree.IsFolderExpandable(key)
            is_expand = sap_gui_tree.IsFolderExpanded(key)
            if is_expandable is True and is_expand is False:
                sap_gui_tree.expandNode(key)
            key = sap_gui_tree.GetNextNodeKey(key)
        except Exception:
            break
    logging.info('导出节点内容')
    sap_gui_tree_column_names = list(sap_gui_tree.GetColumnNames())
    lt_job[1][1].value = '对象层级'
    for col, name in enumerate(sap_gui_tree_column_names, start=2):
        title = sap_gui_tree.GetColumnTitleFromName(name)  # 标题
        lt_job[col][1].value = title
        if title == '对象类型':  # 对象类型列发生变化时，更新列位置
            obj_type_col = col
    for rn, key in enumerate(sap_gui_tree.GetAllNodeKeys(), start=2):
        for col, name in enumerate(sap_gui_tree_column_names, start=2):
            hierarchy = sap_gui_tree.GetHierarchyLevel(key)  # 层级
            text = sap_gui_tree.GetItemText(key, name)  # 文本
            lt_job[1][rn].value = hierarchy
            # if re.match(r'\d{4}\.\d{2}\.\d{2}', text) is not None:
            #     text = text.replace('.', '')
            if '日期' in lt_job[col][1].value:
                lt_job[col][1].value = lt_job[col][1].value.replace('.', '')
            lt_job[col][rn].value = text
    if lt_job[obj_type_col][1].value == '对象类型':
        for row in lt_job.rows:
            level_name = ''
            if row['A'].value in ('0', '1', '2', '3', '4', '5', '6', '7', '8'):
                level_name = {'0': '一级', '1': '二级', '2': '三级', '3': '四级', '4': '五级', '5': '六级', '6': '七级', '7': '八级', '8': '九级'}[row['A'].value]
            obj_name = ''
            if row[obj_type_col].value in ('O', 'S', 'P'):
                obj_name = {'O': '机构', 'S': '岗位', 'P': '人员'}[row[obj_type_col].value]
            row['A'].value = level_name + obj_name
    succ_filename = lt_job.save_to(RPA_DIR)
    logging.info(f'导出文件：{succ_filename}，成功')


def export_original_table(filename: str, session: Any):
    logging.info(f'正在导出文件：{filename}')
    lt_job = AdTable(filename)
    logging.info('表格数据复制到剪切板')
    session.findById("wnd[0]/tbar[1]/btn[9]").press()
    # session.findById("wnd[1]/usr/subSUBSCREEN_STEPLOOP:SAPLSPO5:0150/sub:SAPLSPO5:0150/radSPOPLI-SELFLAG[4,0]").select()  # 勾选[保存到剪切板]
    # session.findById("wnd[1]/tbar[0]/btn[0]").press()  # 确定
    # query_string = pyperclip.paste()
    session.findById("wnd[1]/usr/subSUBSCREEN_STEPLOOP:SAPLSPO5:0150/sub:SAPLSPO5:0150/radSPOPLI-SELFLAG[0,0]").select()  # 勾选[未转换的]
    session.findById("wnd[1]/tbar[0]/btn[0]").press()  # 保存到本地文件
    output_dir = gentempdir()
    query_string_filename = Path(output_dir).joinpath('query_string.txt').as_posix()
    session.findById("wnd[1]/usr/ctxtDY_PATH").text = output_dir  # 目录
    session.findById("wnd[1]/usr/ctxtDY_FILENAME").text = "query_string.txt"  # 文件名（ANSI编码）
    session.findById("wnd[1]/usr/ctxtDY_FILENAME").caretPosition = 16
    if Path(query_string_filename).exists() is True:
        session.findById("wnd[1]/tbar[0]/btn[11]").press()  # 覆盖
    else:
        session.findById("wnd[1]/tbar[0]/btn[0]").press()  # 生成
    for _ in range(60):  # 1分钟，等待文件写完
        sap_status = session.findById("wnd[0]/sbar/pane[0]").text
        if '字节已传输，代码页为' in sap_status:
            break
        else:
            sleep(1)
    # WARN GUI安全性窗口已禁止弹出
    query_string_encoding = peek_file_encoding(Path(output_dir).joinpath('query_string.txt').as_posix())
    query_string = Path(output_dir).joinpath('query_string.txt').read_text(encoding=query_string_encoding)
    logging.info('解析剪切板文本')
    headers, table = parse_query_string(query_string)
    for column, header in enumerate(headers, start=1):
        lt_job[column][1].value = header
    for rn, row in enumerate(table, start=2):
        for column, value in enumerate(row, start=1):
            lt_job[column][rn].value = value
    succ_filename = lt_job.save_to(RPA_DIR)
    logging.info(f'导出文件：{succ_filename}，成功')


def chk_05(_lt: AdTable) -> bool:
    logging.info('执行SAP操作')
    session = attach_sap()
    is_check_passed = True
    action_map = {'S_AHR_61016493': '组织机构', 'S_AHR_61016494': '组织机构内职位', 'S_AHR_61016495': '组织机构内人员', 'S_AHR_61016503': '人员配备情况'}
    for row in _lt.rows:
        filename = action_map[row['E'].value]
        if row['B'].value == '':
            filename = f'{filename}(期间)'
        else:
            filename = f'{filename}(关键日期)'
        job_ids = [job_id.strip(' ') for job_id in row['A'].value.split('、')]
        if len(job_ids) == 0:
            logging.info(f'行{row}机构编码为空，跳过导出')
            continue
        else:
            filename = f'{filename}_{job_ids[0]}'
        keycode = chk_04(row)  # SAP事务码
        logging.info(f'填入事务码：{keycode}')
        session.findById("wnd[0]/tbar[0]/okcd").text = keycode
        session.findById("wnd[0]").sendVKey(0)
        session.findById("wnd[0]/usr/ctxtPCHOBJID-LOW").text = "12345678"  # 先填充机构编码，再清空，否则会报错“警告：将编辑对象类型的所有对象类型”
        session.findById("wnd[0]/usr/btn%_PCHOBJID_%_APP_%-VALU_PUSH").press()  # 多项选择
        try:
            session.findById("wnd[1]/tbar[0]/btn[0]").press()  # 选择计划版本窗口(第一次时弹出，后续不弹出)
        except pythoncom.com_error:  # pylint: disable=fixme, no-member
            pass
        session.findById("wnd[1]/tbar[0]/btn[16]").press()  # 清空
        pyperclip.copy('\r\n'.join(job_ids))  # 复制机构编码到剪切板
        logging.info(f'填入机构编码:{job_ids}')
        session.findById("wnd[1]/tbar[0]/btn[24]").press()  # 粘贴
        session.findById("wnd[1]/tbar[0]/btn[8]").press()  # 确认
        if row['E'].value in ('S_AHR_61016493', 'S_AHR_61016494', 'S_AHR_61016495'):
            session.findById("wnd[0]/usr/btn$PS$ZTST").press()  # 执行
            try:
                session.findById("wnd[1]/tbar[0]/btn[0]").press()  # 选择计划版本窗口(第一次时弹出，后续不弹出)
            except pythoncom.com_error:  # pylint: disable=fixme, no-member
                pass
            if valid_date(row['B'].value) is True:
                session.findById("wnd[0]/usr/ctxtPCHOBEG").text = row['B'].value  # 关键日期
                logging.info(f"填入关键日期：{row['B'].value}")
            else:
                try:
                    session.findById("wnd[0]/usr/btn$PS$PZTR").press()  # 期间
                except pythoncom.com_error:  # pylint: disable=fixme, no-member
                    pass
                session.findById("wnd[0]/usr/btn$PS$ZTRZ").press()  # 其他期间
                session.findById("wnd[0]/usr/ctxtPCHOBEG").text = row['C'].value  # 开始日期
                session.findById("wnd[0]/usr/ctxtPCHOEND").text = row['D'].value  # 结束日期
                logging.info(f"填入开始日期：{row['C'].value}，结束日期：{row['D'].value}")
            if row['F'].value == '是':
                session.findById("wnd[0]/usr/chkSEL_BOX").selected = -1  # 勾选【标准选择屏幕】选择框
                session.findById("wnd[0]/tbar[1]/btn[8]").press()  # 执行
                session.findById("wnd[0]/usr/ctxtPCHWEGID").text = row['G'].value  # 评估路径
                session.findById("wnd[0]/usr/txtPCHDEPTH").text = row['H'].value  # 显示深度
                logging.info('点击执行')
                session.findById("wnd[0]/tbar[1]/btn[8]").press()  # 执行
                sap_status = session.findById("wnd[0]/sbar/pane[0]").text
                if '不允许评估路径' in sap_status:
                    row['G'].cmt('red', sap_status)
                    logging.error(sap_status)
                    is_check_passed = False
                    continue
            else:
                logging.info('点击执行')
                session.findById("wnd[0]/tbar[1]/btn[8]").press()  # 执行
            sap_title = session.findById("wnd[0]").Text
            if '运行时间错误' in sap_title:
                logging.error(f'查询超时：{sap_title}')
                row['A'].cmt('red', f'查询超时：{sap_title}')
                is_check_passed = False
                continue
            sap_status = session.findById("wnd[0]/sbar/pane[0]").text  # SAP状态栏文本
            if '没有找到输入值的数据' in sap_status:
                row['A'].cmt('red', '机构编码不存在')
                logging.error(sap_status)
                is_check_passed = False
                continue
            session.findById("wnd[0]/usr/cntlCUSTOM_CONTROL/shellcont/shell/shellcont[1]/shell[0]").pressButton("&LOAD")  # 选择布局格式
            session.findById("wnd[1]/tbar[0]/btn[71]").press()  # 搜索
            session.findById("wnd[2]/usr/txtGS_SEARCH-VALUE").text = "/CS"  # 检索项
            session.findById("wnd[2]/usr/cmbGS_SEARCH-SEARCH_ORDER").key = "0"  # 搜索方向:由表格开头向下
            session.findById("wnd[2]/usr/chkGS_SEARCH-EXACT_WORD").selected = -1  # 仅查找整个词或值
            session.findById("wnd[2]/tbar[0]/btn[0]").press()  # 确定
            try:
                session.findById("wnd[2]/tbar[0]/btn[12]").press()  # 取消(此时定位到第一个匹配项，点击取消，停止搜索)
            except Exception:  # nosec 在特定机器上需要点击取消按钮
                pass
            session.findById("wnd[1]/usr/cntlGRID/shellcont/shell").clickCurrentCell()  # 双击匹配项
            export_guitree(filename, session)  # 导出层级表
        elif row['E'].value == 'S_AHR_61016503':
            session.findById("wnd[0]/usr/ctxtPCHOBEG").text = row['B'].value  # 关键日期
            if row['F'].value == '是':
                session.findById("wnd[0]/usr/chkSEL_BOX").selected = -1  # 勾选【标准选择屏幕】选择框
                session.findById("wnd[0]/tbar[1]/btn[8]").press()  # 执行
                session.findById("wnd[0]/usr/ctxtPCHWEGID").text = row['G'].value  # 评估路径
                session.findById("wnd[0]/usr/txtPCHDEPTH").text = row['H'].value  # 显示深度
                logging.info('点击执行')
                session.findById("wnd[0]/tbar[1]/btn[8]").press()  # 执行
                sap_status = session.findById("wnd[0]/sbar/pane[0]").text
                if '不允许评估路径' in sap_status:
                    row['G'].cmt('red', sap_status)
                    is_check_passed = False
                    logging.error(sap_status)
                    continue
            else:
                logging.info('点击执行')
                session.findById("wnd[0]/tbar[1]/btn[8]").press()  # 执行
            try:
                session.findById("wnd[1]/tbar[0]/btn[0]").press()  # 选择计划版本窗口(第一次时弹出，后续不弹出)
            except pythoncom.com_error:  # pylint: disable=fixme, no-member
                pass
            try:
                session.findById("wnd[0]/tbar[1]/btn[8]").press()
                row['A'].cmt('red', '机构编码不存在')
                logging.error('机构编码不存在')
                is_check_passed = False
                continue
            except pythoncom.com_error:  # pylint: disable=fixme, no-member
                pass
            sap_title = session.findById("wnd[0]").Text
            if '运行时间错误' in sap_title:
                logging.error(f'查询超时：{sap_title}')
                row['A'].cmt('red', f'查询超时：{sap_title}')
                is_check_passed = False
                continue
            session.findById("wnd[0]/tbar[1]/btn[33]").press()  # 选择
            session.findById("wnd[1]/usr/ssubD0500_SUBSCREEN:SAPLSLVC_DIALOG:0501/cntlG51_CONTAINER/shellcont/shell").contextMenu()  # 右键菜单
            session.findById("wnd[1]/usr/ssubD0500_SUBSCREEN:SAPLSLVC_DIALOG:0501/cntlG51_CONTAINER/shellcont/shell").selectContextMenuItem("&FIND")  # 查找
            session.findById("wnd[2]/usr/txtGS_SEARCH-VALUE").text = "/CS"  # 检索项
            session.findById("wnd[2]/usr/cmbGS_SEARCH-SEARCH_ORDER").key = "0"  # 搜索方向:由表格开头向下
            session.findById("wnd[2]/usr/chkGS_SEARCH-EXACT_WORD").selected = -1  # 仅查找整个词或值
            session.findById("wnd[2]/tbar[0]/btn[0]").press()  # 确定
            try:
                session.findById("wnd[2]/tbar[0]/btn[12]").press()  # 取消(此时定位到第一个匹配项，点击取消，停止搜索)
                # 在特定机器上需要点击取消按钮
            except pythoncom.com_error:  # pylint: disable=fixme, no-member
                pass
            session.findById("wnd[1]/usr/ssubD0500_SUBSCREEN:SAPLSLVC_DIALOG:0501/cntlG51_CONTAINER/shellcont/shell").clickCurrentCell()  # 双击匹配项
            export_original_table(filename, session)
        else:
            row['E'].cmt('red', '口令非预定义值之一（S_AHR_61016493、S_AHR_61016494、S_AHR_61016495、S_AHR_61016503）')
            is_check_passed = False
    return is_check_passed


def check_before(_lt: AdTable) -> bool:
    logging.info('执行前置校验')
    is_check_passed = []
    for row in _lt.rows:
        is_check_passed.append(chk_01(row))
        is_check_passed.append(chk_02(row))
        is_check_passed.append(chk_03(row))
    return all(is_check_passed) is True


def main(filename: str) -> bool:
    global RPA_DIR
    with SapClose():
        RPA_DIR = get_rpa_dir('机构岗位查询分析V2', pathlib.Path(filename).name[:-5], True)
        _lt: AdTable = load_from_xlsx_file(filename)
        _lt.del_blank_rows_by_column('A')
        _lt['A'].apply(init_sap_id)
        _lt.apply(init_sap_value)
        logging.info('进行前置校验')
        if check_before(_lt) is False:  # 前置校验
            err_filename = _lt.save_to(RPA_DIR)
            logging.error(f'前置校验未通过，请查看{err_filename}获取错误信息。')
            return False
        logging.info('前置校验通过')
        logging.info('执行SAP导出操作')
        is_sap_error = chk_05(_lt)  # SAP操作
        logging.info('SAP操作结束')
        if is_sap_error is False:
            err_filename = _lt.save_to(RPA_DIR)
            logging.error(f'SAP操作遇到问题，请查看{err_filename}获取错误信息。')
        else:
            _lt.save_to(RPA_DIR)
            logging.info(f'SAP导出成功，未遇到问题，请查看{RPA_DIR}获取机构岗位信息。')
        return is_sap_error


if __name__ == '__main__':
    config('机构岗位查询分析V2.log')
    logging.info('程序开始执行')
    logging.info(sys.argv)
    if len(sys.argv) >= 2:
        filename = sys.argv[1]
        if filename[-5:].lower() == '.xlsx':
            with SapClose():
                main(filename)
            logging.info('程序执行完毕')
        else:
            logging.info(f'文件不是xlsx格式，文件名：{filename}')
    else:
        # main('x:/机构岗位查询分析_v2.xlsx')
        logging.info('请拖动模板到程序上执行。')
    input('按任意键退出')
