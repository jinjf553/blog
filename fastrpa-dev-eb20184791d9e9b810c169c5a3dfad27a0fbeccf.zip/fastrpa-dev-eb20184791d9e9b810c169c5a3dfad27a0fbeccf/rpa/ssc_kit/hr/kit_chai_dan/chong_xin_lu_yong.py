#!/usr/bin/env python
# -*- coding: utf-8 -*-
# @File    : chong_xin_lu_yong.py
# @Author  : jinjianfeng
# @Contact : 553041800@qq.com
# @Link    : https://github.com/jinjf553
# @software: PyCharm
# @Date    : 2019/8/21 19:49
# @Version : ??
import logging
import os
import re
import shutil
import time
from collections import defaultdict
from datetime import datetime

from openpyxl import load_workbook
from openpyxl.utils import get_column_letter
from rpa.fastrpa.adtable import BLUE, RED
from rpa.public.all_party_up import trans_date, trans_h
from rpa.public.check_template import (check_degree_template,
                                       check_family_members_template,
                                       check_work_experience)
from rpa.public.config import FILE_PATH, local_path, templates
from rpa.public.tools import cel, cells
from rpa.ssc.hr.orm.orm_ope import DbSession, Query
from rpa.ssc.hr.orm.tb_hr_gangweibiandong_log import Log
from rpa.ssc.hr.orm.td_hr_gang_wei_diao_pei_rulebase import Event
from rpa.ssc_kit.hr.kit_chai_dan.check_280 import check_zhrpy280, get_grade
from rpa.ssc_rpa.hr.rpa_chong_xin_lu_yong.chong_xin_lu_yong_shi_jian import \
    get_gwxx_info


def rulebase_16_2(file, file_str):
    wb = load_workbook(file)
    ws_ = wb.active
    value_dict = defaultdict(list)
    for i in range(9, len(ws_["AB"]) + 1):
        c_v = cel(ws_, f"E{i}") if "重新录用" in cel(ws_, f"E{4}") else cel(ws_, f"AB{i}")
        if c_v and c_v.replace(" ", '').isdigit():
            value_dict[c_v.replace(" ", '')] = [str(j.value).strip().strip("None") for j in ws_[f"B{i}:AC{i}"][0]]

    rule_uvw = {res.db_U: [res.db_V, res.db_W] for res in Query(table=Event) if
                res.db_U and res.db_V and res.db_W}  # 17 职位序列、职位层级、职位级别
    rule_lm = {res.db_L: res.db_M for res in Query(table=Event) if res.db_L and res.db_M}  # 17 人员子组、职位序列
    tdt = {8: "BN", 6: "AS", 7: "E", 9: "J", 10: "L", 11: "BO", 12: "AG", 13: "BP", 14: "Y", 15: "F", 18: "AH", 19: "R",
           20: "BQ", 21: "V", 22: "W", 23: "U", 25: "R", 26: "V", 27: "W", 28: "U", 31: "R", 32: "R", 33: "R",
           34: "R", 36: "CW", 37: "R", 38: "R", 44: "DA", 45: "DB", 46: "DC", 47: "DD", 48: "DE", 49: "CZ",
           50: "DF", 52: "DG"}
    rule_dict = defaultdict(list)
    for r in Query(Event):
        for k, v in tdt.items():
            if eval("r.db_" + v):
                rule_dict[k].append(eval("r.db_" + v).replace(" ", ""))
    date = [ws_[f"C{x}"].value for x in range(9, len(ws_["C"]) + 1) if ws_[f"C{x}"].value and str(ws_[f"C{x}"].value).isdigit()]
    if not date:
        logging.info("入职时间错误")
        return
    values_103 = get_gwxx_info(value_dict, os.path.dirname(file), date[0])

    wb_temp = load_workbook(os.path.join(templates, "ZBI0037_重新录用模板.xlsx"))
    ws = wb_temp.active
    logging.info("开始生成并校验重新录用模板数据...")
    for num, (k, v) in enumerate(list(value_dict.items())):
        # 规则 4.2.2 - 4.2.9 & 4.2.12 - 4.2.14  B-AN
        logging.info(f"    正在生成重新录用第{num + 1}条数据...")
        if "重新录用" in cel(ws_, "E4"):
            v[3], v[4] = v[4], v[5]

        ws[f"A{num+7}"] = num + 1
        ws[f"B{num+7}"] = k
        ws[f"C{num+7}"] = v[0] if v[0] != "None" else None
        ws[f"D{num+7}"] = v[1] if v[1] != "None" else None
        ws[f"H{num+7}"] = v[2].strip("重新录用-") if v[2] != "重新录用" else "   重新录用"
        ws[f"I{num+7}"] = v[13] if v[13] != "None" else None
        ws[f"J{num+7}"] = v[14] if v[14] != "None" else None
        ws[f"L{num+7}"] = v[15] if v[15] != "None" else None
        ws[f"O{num+7}"] = v[19] if v[19] != "None" else None
        ws[f"S{num+7}"] = "  " + v[17] if v[17] == "否" else v[17].strip("None")
        ws[f"T{num+7}"] = v[18] if v[18] != "None" else None
        db_U = [(r.db_V, r.db_W) for r in Query(table=Event, db_U=v[16].strip())]
        if db_U:
            db_V, db_W = db_U[0][0], db_U[0][1]
        else:
            db_V, db_W = '', ''
        ws["U%s" % str(num + 7)] = db_V
        ws["V%s" % str(num + 7)] = db_W
        ws["W%s" % str(num + 7)] = v[16] if v[16] != "None" else None
        ws["X%s" % str(num + 7)] = v[4] if v[4] != "None" else None
        ws["P%s" % str(num + 7)] = v[20] if v[20] != "None" else None
        ws["Q%s" % str(num + 7)] = v[21] if v[21] != "None" else None
        ws["AQ%s" % str(num + 7)] = v[3] if v[3] != "None" else None
        ws["AR%s" % str(num + 7)] = v[7] if v[7] != "None" else None
        ws["AS%s" % str(num + 7)] = v[8] if v[8] != "None" else None
        ws["AT%s" % str(num + 7)] = v[9] if v[9] != "None" else None
        ws["AU%s" % str(num + 7)] = v[10] if v[10] != "None" else None
        ws["AV%s" % str(num + 7)] = v[11] if v[11] != "None" else None
        ws["AW%s" % str(num + 7)] = v[22] if v[22] != "None" else None
        ws["AX%s" % str(num + 7)] = v[23] if v[23] != "None" else None
        ws["AY%s" % str(num + 7)] = v[24] if v[24] != "None" else None
        ws["AZ%s" % str(num + 7)] = v[25] if v[25] != "None" else None
        #  校验部分
        if not ws[f"E{num + 7}"].value:
            cells(ws, f"E{num + 7}", "岗位编号不能为空", RED)

        if not ws[f"F{num + 7}"].value:
            cells(ws, f"F{num + 7}", "人事范围不能为空", RED)

        if not ws[f"G{num + 7}"].value:
            cells(ws, f"G{num + 7}", "人事子范围不能为空", RED)

        # 16  检查模板有长度要求的字段符合要求
        if len(str(ws[f"AC{num + 7}"].value).strip()) > 40:
            cells(ws, f"AC{num + 7}", "请检查数据长度超长", RED)

        # 13  检验重新录用所有相关模板中必填项内容不为空
        for j in [get_column_letter(x) for x in range(1, 53)]:
            if "X" in str(ws[j + "3"].value) and ws[f"{j}{num + 7}"].value is None:
                cells(ws, f"{j}{num + 7}", "此单元格为必填项", RED)

        # 15  检验重新录用模板【B】列人员岗位状态
        tmpb = str(ws[f"B{num + 7}"].value).lstrip("0")
        if tmpb in values_103.keys():
            if values_103[tmpb][0] != "None":
                if "在岗" == values_103[tmpb][3] or "减册人员" != values_103[tmpb][-1]:
                    cells(ws, f"B{num + 7}", "系统中此人员已为在岗状态，请注意检查", RED)

        # 15  检验重新录用时间是否符合要求
        tmpd = str(ws[f"D{num + 7}"].value).strip()[:8]
        try:
            time.strptime(tmpd, '%Y%m%d')
            current_date = time.strftime("%d", time.localtime(time.time()))
            current_month = time.strftime("%Y%m01", time.localtime(time.time()))
            next_month = time.strftime("%Y%m01",
                                       time.localtime(time.time() + (32 - int(current_date)) * 24 * 60 * 60))
            if tmpd not in [current_month, next_month]:
                cells(ws, f"D{num + 7}", "请核查此数值是否为有效重新录用时间", RED)
            if num + 7 != 7 and str(ws[f"D{num + 6}"].value).strip() != str(ws[f"D{num + 7}"].value).strip():
                cells(ws, f"D{num + 7}", "请核查此数值是否为有效重新录用时间", RED)
        except Exception:
            cells(ws, f"D{num + 7}", "请核查此数值是否为有效重新录用时间", RED)

        # 12  检验重新录用所有相关模板有码表的均符合码表规则
        for key, val in rule_dict.items():
            if not ws.cell(num + 7, key).value:
                continue
            if str(ws.cell(num + 7, key).value).replace(" ", "") not in val:
                cells(ws, (num + 7, key), "单元格数据不是码值", BLUE if key == 50 else RED)

        # 24  检查人员组与人员子组是否匹配
        tmpi, tmpj = str(ws[f"I{num + 7}"].value).strip().split()[0], str(ws[f"J{num + 7}"].value).strip().split()[0]
        if (tmpi == "B" and tmpj not in ["12", "13", "14", "15", "16", "17", "21", "22"]) or \
                (tmpi == "M" and tmpj not in ["61", "62", "63"]):
            cells(ws, f"I{num + 7}", "请检查人员组与人员子组是否匹配", RED)

        tmpj, tmpw, tmpu, tmpv = [str(ws[f"{x}{num + 7}"].value).strip() for x in ["J", "W", "U", "V"]]
        if tmpw not in rule_uvw.keys() or rule_uvw[tmpw][0] != tmpu or rule_uvw[tmpw][
                1] != tmpv or tmpj not in rule_lm.keys() or tmpu != rule_lm[tmpj]:
            cells(ws, f"J{num + 7}", "请检查人员子组和职位序列信息", RED)
    serial_id = datetime.now().strftime("%Y-%m-%d-%H-%M-%S-%f")
    wb.properties.description = serial_id
    wb_temp.save(FILE_PATH + '/tmp-重新录用模板.xlsx')
    if os.path.exists(FILE_PATH + '/tmp-重新录用模板.xlsx'):
        check_zhrpy280(FILE_PATH + '/tmp-重新录用模板.xlsx')
        file_str = file_str if file_str else os.path.basename(file)
        get_grade(f"{file_str.split('-')[0][:10]}-XX-XX", value_dict, "重新录用", serial_id)


def rulebase_16_3(file, name_dict):
    wb = load_workbook(file)
    ws = wb.active
    value_dict = defaultdict(list)
    for i in range(9, len(ws["B"]) + 1):
        if ws["B%s" % str(i)].value:
            value_dict[cel(ws, f"B{i}").replace(" ", '')] = [str(j.value).strip() for j in
                                                             ws["B%s:AC%s" % (str(i), str(i))][0]]

    wb_temp = load_workbook(os.path.join(templates, "0021_HR_BI_0021家庭成员及社会关系.xlsx"))
    ws_temp = wb_temp.active
    logging.info("开始生成并校验家庭成员及社会关系模板数据...")
    total = 0
    db_CT_CU = {str(res.db_CT).replace(" ", ""): str(res.db_CU) for res in Query(Event) if res.db_CT}
    db_cv = [str(res.db_CV).strip() for res in Query(Event) if res.db_CV]
    for num, (key, value) in enumerate(list(value_dict.items())):
        name_list = name_dict[key]["家庭成员"] if key in name_dict.keys() else []
        for i in name_list:
            total += 1
            ws_temp["A%s" % str(total + 6)] = total
            ws_temp["C%s" % str(total + 6)] = key
            ws_temp["D%s" % str(total + 6)] = value[1] if value[1] != "None" else None
            ws_temp["E%s" % str(total + 6)] = "99991231"
            ws_temp["F%s" % str(total + 6)] = i[0]
            ws_temp["G%s" % str(total + 6)] = str(i[1]).replace(" ", "")
            ws_temp["I%s" % str(total + 6)] = i[2]
            ws_temp["K%s" % str(total + 6)] = i[3]
            if str(i[3]).strip() not in db_cv:
                cells(ws_temp, f"K{total + 6}", "单元格数据非码值", RED)
            ws_temp["L%s" % str(total + 6)] = i[4]
            if len(str(i[4])) > 20:
                cells(ws_temp, f"L{total + 6}", "数据超长", RED)
            tmp_var = str(i[0]).replace(" ", "")
            ws_temp["H%s" % str(total + 6)] = db_CT_CU[tmp_var] if tmp_var in db_CT_CU.keys() else "  未知"
    wb_temp.save(os.path.join(FILE_PATH, "tmp-家庭成员及社会关系模板.xlsx"))
    logging.info("开始检查家庭成员及社会关系模板")
    check_family_members_template(FILE_PATH + "/tmp-家庭成员及社会关系模板.xlsx", defaultdict(list))


def rulebase_16_4(file, name_dict):
    wb = load_workbook(file)
    ws = wb.active
    value_dict = defaultdict(list)
    for i in range(9, len(ws["B"]) + 1):
        if ws["B%s" % str(i)].value:
            value_dict[cel(ws, f"B{i}").replace(" ", "")] = [str(j.value).strip() for j in ws[f"B{i}:AC{i}"][0]]

    wb_temp = load_workbook(os.path.join(templates, "0022_HR_BI_0022学历学位.xlsx"))
    ws_temp = wb_temp.active
    logging.info("开始生成并校验学历学位模板数据...")
    total = 0
    db_CH_CG = {res.db_CH.strip(): res.db_CG.strip() for res in Query(table=Event) if res.db_CH and res.db_CG}  # 学历
    db_CH_CJ = {res.db_CJ.strip(): res.db_CI.strip() for res in Query(table=Event) if res.db_CI and res.db_CJ}  # 学位

    for num, (key, value) in enumerate(list(value_dict.items())):
        xueli_list = name_dict[key]["学历"] if key in name_dict.keys() else []
        for i in xueli_list:
            total += 1
            ws_temp["A%s" % str(total + 6)] = total
            ws_temp["C%s" % str(total + 6)] = key
            ws_temp["AC%s" % str(total + 6)] = value_dict[key][1]
            ws_temp["D%s" % str(total + 6)] = (re.sub("[-－—]", "-", str(i[0])) + "-").split("-")[1]
            ws_temp["E%s" % str(total + 6)] = "99991231"
            ws_temp["F%s" % str(total + 6)] = db_CH_CG[i[3]] if i[3] in db_CH_CG.keys() else ""
            ws_temp["G%s" % str(total + 6)] = i[3]
            ws_temp["H%s" % str(total + 6)] = db_CH_CJ[i[4]] if i[4] in db_CH_CJ.keys() else ""
            ws_temp["I%s" % str(total + 6)] = i[4]
            if i[4]:
                ws_temp["J%s" % str(total + 6)] = (re.sub("[-－—]", "-", str(i[0])) + "-").split("-")[1]
            tmp_var = str(min([int(j[3][:2]) for j in xueli_list if j[3][:2].isdigit()] + [9999]))
            ws_temp["K%s" % str(total + 6)] = "X" if tmp_var in i[3] else ""

            tmp_var = str(min([int(j[4][:1]) for j in xueli_list if j[4] and j[4][:1].isdigit()] + [9999]))
            ws_temp["L%s" % str(total + 6)] = "X" if i[4] and tmp_var in i[4] else ""

            tmp_var = max([int(j[3][:2]) for j in xueli_list if j[5] and j[3][:2].isdigit() and j[5][:1] == "1"] + [0])
            ws_temp["M%s" % str(total + 6)] = "X" if str(tmp_var) in i[3] else ""

            if i[3][:2].isdigit() and int(i[3][:2]) < 44:
                if "党校" in str(i[1]):
                    if "中央" in str(i[1]):
                        if "普通全日制" in str(i[5]):
                            ws_temp["N%s" % str(total + 6)] = "31 党校-中央党校"

                        else:
                            ws_temp["N%s" % str(total + 6)] = "33 党校-中央党校函授"
                    else:
                        if "普通全日制" in str(i[5]):
                            ws_temp["N%s" % str(total + 6)] = "32 党校-省（区、市）委党校"
                        else:
                            ws_temp["N%s" % str(total + 6)] = "34 党校-省（区、市）委党校函授"
                else:
                    if "普通全日制" in str(i[5]):
                        ws_temp["N%s" % str(total + 6)] = "10 普通高等学校 "
                    else:
                        ws_temp["N%s" % str(total + 6)] = "26 成人高等学校-函授大学（学院）"
            elif i[3][:1].isdigit() and int(i[3][:1]) == 5:
                ws_temp["N%s" % str(total + 6)] = "60 中专"
            elif i[3][:1].isdigit() and int(i[3][:1]) == 6:
                ws_temp["N%s" % str(total + 6)] = "70 技校 "
            else:
                ws_temp["N%s" % str(total + 6)] = "99 其他"

            with DbSession() as sess:
                res = sess.query(Event.db_CM, Event.db_CL).filter(
                    Event.db_CM.like("%% %s%%" % i[1] if i[1] else "Z999 其他")).all()
            ws_temp["O%s" % str(total + 6)] = res[0][1] if res else "Z0   其他"
            ws_temp["P%s" % str(total + 6)] = res[0][0] if res else "Z999 其他"
            ws_temp["Q%s" % str(total + 6)] = i[1] if i[1] else ""
            ws_temp["R%s" % str(total + 6)] = "CN  中国" if res and res[0][1][:2] not in ["Y0", "Z0"] else ""
            ws_temp["R%s" % str(total + 6)] = "CN  中国" if i[3][:2].isdigit() and int(i[3][:2]) > 43 else ws_temp[
                "R%s" % str(total + 6)].value
            ws_temp["S%s" % str(total + 6)] = i[5] if i[5] else ""

            with DbSession() as sess:
                cs = sess.query(Event.db_CS).filter(Event.db_CS.like(f"%% {i[2]}%%" if i[2] else "----")).first()
                cs_ = cs[0][:6] if cs else (i[2] if i[2] else "----")
                cr = sess.query(Event.db_CR).filter(Event.db_CR.like(f"%%{cs_}%%")).first()
                cq = sess.query(Event.db_CQ).filter(Event.db_CQ.like(f"{cr[0][:4]}%%" if cr else "----")).first()
                cp = sess.query(Event.db_CP).filter(Event.db_CP.like(f"{cq[0][:2]}%%" if cq else "----")).first()
            ws_temp["T%s" % str(total + 6)] = cp[0] if cp else ""
            ws_temp["U%s" % str(total + 6)] = cq[0] if cq else ""
            ws_temp["V%s" % str(total + 6)] = cr[0] if cr else ""
            ws_temp["W%s" % str(total + 6)] = cs[0] if cs else ""
            ws_temp["X%s" % str(total + 6)] = i[2] if i[2] else ""
            ws_temp["Y%s" % str(total + 6)] = (re.sub(r"[-－—]", "-", str(i[0])) + "-").split("-")[0]
            tmp_re = [x for x in re.findall(r"\d{4,8}", str(i[0])) if x.isdigit()]
            tmp_re = tmp_re if tmp_re else "0"
            ws_temp["Z%s" % str(total + 6)] = str(int(tmp_re[len(tmp_re) - 1][:4]) - int(tmp_re[0][:4]))
    wb_temp.save(os.path.join(FILE_PATH, "tmp-学历学位模板.xlsx"))
    logging.info("开始检查学历学位模板")
    check_degree_template(FILE_PATH + "/tmp-学历学位模板.xlsx", defaultdict(list))


def rulebase_16_5(file, name_dict):
    wb = load_workbook(file)
    ws = wb.active
    value_dict = defaultdict(list)
    for i in range(9, len(ws["B"]) + 1):
        if ws["B%s" % str(i)].value:
            value_dict[cel(ws, f"B{i}").replace(" ", '')] = [str(j.value).strip() for j in
                                                             ws["B%s:AC%s" % (str(i), str(i))][0]]

    wb_temp = load_workbook(os.path.join(templates, "模板_0023_HR_BI_0023_工作经历.xlsx"))
    ws_temp = wb_temp.active
    logging.info("开始生成并校验工作经历模板数据...")
    total = 0
    for num, (key, value) in enumerate(list(value_dict.items())):
        if "重新录用" in cel(ws, "E4"):
            value[3], value[4], value[26] = value[4], value[5], value[3]

        name_list = name_dict[key]["工作经历"] if key in name_dict.keys() else []
        for i in name_list:
            total += 1
            ws_temp["A%s" % str(total + 6)] = total
            ws_temp["C%s" % str(total + 6)] = key
            ws_temp["D%s" % str(total + 6)] = trans_date(i[0]) if trans_date(i[0]) else i[0]
            end_date = "99991231" if "至今" in str(i[1]) else (trans_date(i[1]) if trans_date(i[1]) else i[1])
            ws_temp["E%s" % str(total + 6)] = end_date
            ws_temp["F%s" % str(total + 6)] = str(i[2]).strip().replace("None", "")
            ws_temp["G%s" % str(total + 6)] = str(i[3]).strip().replace("None", "")
            # if name_list.index(i) == len(name_list) - 1:
        if (value[1] > cel(ws_temp, f"D{total+6}") or key != cel(ws_temp, f"C{total+6}")) and value[26] == "None":
            if cel(ws_temp, f"E{total+6}") == "99991231" and key == cel(ws_temp, f"C{total+6}"):
                ws_temp["E%s" % str(total + 6)] = trans_h(value[1])
            total += 1
            ws_temp["A%s" % str(total + 6)] = total
            ws_temp["C%s" % str(total + 6)] = key
            ws_temp["D%s" % str(total + 6)] = value[1] if value[1] != "None" else ""
            ws_temp["E%s" % str(total + 6)] = "99991231"
            ws_temp["F%s" % str(total + 6)] = value[3] if value[3] != "None" else ""
            ws_temp["G%s" % str(total + 6)] = value[4] if value[4] != "None" else ""

    wb_temp.save(os.path.join(FILE_PATH, "tmp-工作经历模板.xlsx"))
    check_work_experience(FILE_PATH + "/tmp-工作经历模板.xlsx", defaultdict(list))


def read_caijibiao(file, file_str):
    dir_path = local_path + "\\" + file_str + "/采集表" if file_str else os.path.dirname(file) + "/采集表"
    logging.info(dir_path)
    if not os.path.exists(dir_path):
        return {}
    tmp_dict = {res.db_CJ[4:]: res.db_CJ for res in Query(table=Event) if res.db_CJ}
    tmp_dict1 = {res.db_CH[3:]: res.db_CH for res in Query(table=Event) if res.db_CH}
    tmp_dict2 = {res.db_CO[2:]: res.db_CO for res in Query(table=Event) if res.db_CO}
    name_dict = defaultdict(dict)
    for filename in os.listdir(dir_path):
        if filename.upper()[-5:] != ".XLSX":
            continue
        logging.info(f"    提取采集表《{filename}》的家庭成员、学历、工作经历等信息...")
        wb = load_workbook(dir_path + "/" + filename)
        ws = wb.active
        # 家庭成员
        name_list = []
        b_v = [''.join(str(x.value).split()) for x in ws["B"]]
        for i in range(b_v.index("称谓") + 3, 31):
            if ws["B%s" % str(i)].value and ws["D%s" % str(i)].value:
                name_list.append([ws["B%s" % str(i)].value, ws["D%s" % str(i)].value, ws["F%s" % str(i)].value,
                                  ws["L%s" % str(i)].value, ws["P%s" % str(i)].value])

        # 学历学位
        xueli_list = []
        for i in range(b_v.index("起止年月") + 2, b_v.index("起始时间") + 1):
            if ws["B%s" % str(i)].value and ws["N%s" % str(i)].value:
                word = "".join(re.findall(".*?([\u4E00-\u9FA5])", str(ws["N%s" % str(i)].value)))
                tmp_str = tmp_dict1[word] if word in tmp_dict1.keys() else ws["N%s" % str(i)].value
                word = "".join(re.findall(".*?([\u4E00-\u9FA5])", str(ws["Q%s" % str(i)].value)))
                tmp_str1 = tmp_dict[word] if word in tmp_dict.keys() else ws["Q%s" % str(i)].value
                word = "".join(re.findall(".*?([\u4E00-\u9FA5])", str(ws["U%s" % str(i)].value)))
                tmp_str2 = tmp_dict2[word] if word in tmp_dict2.keys() else ws["U%s" % str(i)].value

                xueli_list.append([cel(ws, f"B{i}").replace("None", ""),
                                   str(ws["D%s" % str(i)].value).replace("None", ""),
                                   str(ws["J%s" % str(i)].value).replace("None", ""),
                                   tmp_str, tmp_str1, tmp_str2])

        # 工作经历
        work_list = []
        for i in range(b_v.index("起止年月") + 2, b_v.index("起始时间") + 1):
            word = "".join(re.findall(".*?([\u4E00-\u9FA5])", str(ws["N%s" % str(i)].value)))
            if word in tmp_dict1.keys() and "普通全日制" in str(ws["U%s" % str(i)].value):
                number1, number2 = int(tmp_dict1[word][:2]), 1
            else:
                continue
            if ws["B%s" % str(i)].value and ws["N%s" % str(i)].value and number1 < 62 and number2 == 1:
                start_date = re.sub('-|－', '-', cel(ws, f"B{i}")).split("-")[0]
                end_date = (re.sub('-|－', '-', cel(ws, f"B{i}")) + "-").split("-")[1]
                D, J = str(ws["D%s" % str(i)].value).replace("None", ""), str(ws["J%s" % str(i)].value).replace("None",
                                                                                                                "")
                company = D + (J + "专业" if ws["J%s" % str(i)].value else "")
                work_list.append([start_date, end_date, company, "学生"])
        for i in range(b_v.index("起始时间") + 2, b_v.index("称谓") + 1):
            if ws["B%s" % str(i)].value and ws["F%s" % str(i)].value:
                work_list.append([ws["B%s" % str(i)].value, ws["D%s" % str(i)].value, ws["F%s" % str(i)].value,
                                  ws["S%s" % str(i)].value])
        name_dict[filename[:-5]] = {"家庭成员": name_list, "学历": xueli_list, "工作经历": work_list}
    return name_dict


def move_file(file, file_str):
    sr = file_str[:10] if file_str else os.path.basename(file)[:10]
    path = local_path + "\\" + file_str if file_str else os.path.dirname(file)
    with DbSession() as sess:
        res = sess.query(Log).filter(Log.sr == sr).first()
        sr, code, worker = (res.sr, res.code, res.worker) if res else ("0000000000", "0000", "佚名")
    name = f"{sr}-{code}-员工入职-{worker}"
    local = os.path.dirname(file) + f"/{name}"
    length = len(local)
    for x in range(1, 20):
        if os.path.exists(local):
            local = local[:length] + f"-{x}"
        else:
            break
    os.makedirs(local)
    for x, y in {"工作经历模板": "", "家庭成员及社会关系模板": "", "学历学位模板": "", "新入职": name, "重新录用模板": ""}.items():
        if os.path.exists(os.path.join(FILE_PATH, "tmp-%s.xlsx" % x)):
            shutil.move(os.path.join(FILE_PATH, "tmp-%s.xlsx" % x), local + f"/{y if y else x}.xlsx")

    # 删除采集表目录
    tmp_path = path + f"/采集表/"
    if os.path.exists(tmp_path):
        shutil.rmtree(tmp_path)
    # 移动照片目录至local_path
    tmp_path = path + f"/照片/"
    if os.path.exists(tmp_path):
        shutil.move(tmp_path, local)
    else:
        os.makedirs(local, exist_ok=True)
    logging.info(f"完成{file}入职拆单,相关目录及模板已生成。")


def check_degree(name_dict):
    # 20210512 增加无学历人员信息提示
    filename = os.path.join(FILE_PATH, "tmp-新入职.xlsx")
    if not os.path.exists(filename):
        raise Exception("新员工入职模板未生成。")
    logging.info("开始校查入职模板无学历人员...")
    wb = load_workbook(filename)
    ws = wb.active
    tmp_list = []
    for i in range(7, len(ws["A"]) + 1):
        k = cel(ws, f"B{i}").replace(" ", "")
        if k in name_dict and not name_dict[k]['学历']:
            tmp_list.append(k)
    cells(ws, "A1", f"{'、'.join(tmp_list)}等无学历信息", RED)
    wb.save(filename)
    wb.close()
