#!/usr/bin/env python
# -*- coding: utf-8 -*-
# @File    : check_280.py
# @Author  : jinjianfeng
# @Contact : 553041800@qq.com
# @Link    : https://github.com/jinjf553
# @software: PyCharm
# @Date    : 2019/7/22 8:11
# @Version : ??
import logging
import os
import re
import shutil
import time
from collections import defaultdict
from datetime import datetime

from openpyxl import Workbook, load_workbook
from openpyxl.comments import Comment
from openpyxl.styles import PatternFill
from rpa.fastrpa.adtable import RED, load_from_xlsx_file
from rpa.public.config import FILE_PATH, local_path, templates
from rpa.public.event_public import update_database
from rpa.ssc.hr.factor import get_factor
from rpa.ssc.hr.orm.orm_ope import DbSession
from rpa.ssc.hr.orm.tb_hr_gangweibiandong_log import Log
from rpa.ssc.hr.orm.tb_hr_gangweibiandong_log_detail import LogDetail
from rpa.ssc.hr.orm.td_hr_gang_wei_diao_pei_rulebase import Event
from rpa.ssc.hr.sap.zhrpy280 import check_zhrpy280_file
from sqlalchemy import and_, func


def check_zhrpy280(file):
    """
        提取【岗位变动模板-【B-人员编号】、【C-人员姓名】】，复制到【编号姓名核查-【B5-人员编号】、【C5-人员姓名】】。
        检查zhrpy280导入【编号姓名模板】后是否有报错项，若有，将表单协同。
    :return:
    """
    # chk280([])
    tmp_file = save_as_excel(file)
    if check_zhrpy280_file(tmp_file) is False:
        lt = load_from_xlsx_file(tmp_file)
        df = lt.to_dataframe()
        for rn in df.index:
            if df['D'][rn] != '':
                add_comment_to_excel(file, df['B'][rn], df['D'][rn])
    if os.path.exists(tmp_file):
        os.remove(tmp_file)
    update_database(file, "检查280")


def save_as_excel(file):
    wb = load_workbook(file)
    ws = wb.active

    index = 0
    data = []
    for j in ws.columns:  # we.rows 获取每一列数据
        if "中文名称" in [k.value for k in j]:
            index = [k.value for k in j].index("序列号")
            data.append([k.value for k in j][index + 1:])
        if "人员编号" in [k.value for k in j]:
            data.append([k.value for k in j][index + 1:])
        if "人员姓名" in [k.value for k in j]:
            data.append([k.value for k in j][index + 1:])
    if not data:
        raise Exception("模板表格式有误或者无数据...")

    inti_list = [['序号', '人员编号', '姓名', '备注']] * 4

    wb1 = Workbook()
    ws1 = wb1.active
    for x in inti_list:
        ws1.append(x)

    for x in list(zip(*data)):
        ws1.append(x)
    wb1.save(FILE_PATH + "/tmp.xlsx")  # nosec
    return FILE_PATH + "/tmp.xlsx"  # nosec


def add_comment_to_excel(file, code, content):
    wb = load_workbook(file)
    ws = wb.active
    for row_values in ws.rows:
        for value in row_values:
            if value.value and len(str(value.value)) > 5 and str(value.value) in code:
                value.comment = Comment(content, 'RobotA')
                value.fill = PatternFill("solid", RED)
                break
        else:
            continue
        break
    wb.save(file)


def split_file(file, column, excel, local, business_type, flag=True):
    wb = load_workbook(file)
    ws = wb.active
    value_dict = defaultdict(list)
    for i in range(7, len(ws["A"]) + 1):
        value_dict[str(ws["%s%s" % (column, str(i))].value)].append(
            [(ws.cell(i, j).value, ws.cell(i, j).fill, ws.cell(i, j).comment) for j in
             range(1, len(list(ws.columns)) + 1)])

    for num, (key, value) in enumerate(list(value_dict.items())):
        file_str = f"{os.path.basename(local).split('-')[0][:10]}-{key}-XX"
        serial_id = datetime.now().strftime("%Y-%m-%d-%H-%M-%S-%f")
        get_grade(file_str, value, business_type, serial_id)
        if not flag:
            continue
        wb = load_workbook(os.path.join(templates, "%s表.xlsx" % excel))
        ws = wb.active
        for i in range(len(value)):
            for j in range(len(value[i])):
                ws.cell(i + 7, j + 1).value = value[i][j][0]
                if value[i][j][2]:
                    ws.cell(i + 7, j + 1).fill = PatternFill("solid", RED)
                    ws.cell(i + 7, j + 1).comment = value[i][j][2]
        wb.properties.description = serial_id
        wb.save(os.path.join(FILE_PATH, "tmp.xlsx"))
        shutil.move(os.path.join(FILE_PATH, "tmp.xlsx"), local + f"/{os.path.basename(local)[:10]}-{key}-{excel}.xlsx")


def create_dir(file, file_str):
    file = os.path.realpath(file)
    if file_str:
        local = local_path + "\\" + file_str + "\\" + file.split("\\")[-1][:-5].rstrip()
    else:
        local = os.path.dirname(file) + "\\" + file.split("\\")[-1][:-5].rstrip()
    if not os.path.exists(local):
        os.makedirs(local)
    return local


def get_info(file, file_str):
    if os.path.basename(file)[:10].isdigit():
        with DbSession() as s:
            r = s.query(Log).filter(Log.sr == os.path.basename(file)[:10]).first()
            sr, code, worker = (r.sr, r.code, r.worker) if r else ("0000000000", "0000", "XXX")
    elif file_str[:10].isdigit():
        with DbSession() as s:
            r = s.query(Log).filter(Log.sr == os.path.basename(file)[:10]).first()
            sr, code, worker = (r.sr, r.code, r.worker) if r else ("0000000000", "0000", "XXX")
    else:
        sr, code, worker = "0000000000", "0000", "XXX"
    return sr, code, worker


def get_grade(file, value_dict, business_type, serial_id):
    sr, code, worker = file.split("-")
    sr, code, worker = sr[:10], code[:4], worker[:3]
    people_num = len(value_dict)
    with DbSession() as s:
        l_res = s.query(Log).filter(Log.sr == sr).first()
        if not l_res or sr in ["无单号", "0000000000"]:
            while True:
                r = s.query(func.max(Log.sr)).first()
                try:
                    sr_ = int(*r)
                    break
                except Exception:
                    r_ = s.query(Log).filter(Log.sr == r[0])
                    if r_.first():
                        r_.update({"sr": "0000000000", "type": "无单号拆单"})
                    else:
                        sr_ = 0000000000
                        break
            sr_ = str(sr_ + 1) if sr_ >= 9000000000 else "9000000000"
            if l_res:
                s.query(Log).filter(Log.sr == sr).update({"sr": sr_})
            else:
                s.add(Log(sr=sr_, code=code, content="手动拆单", date=time.strftime("%Y%m%d"), people_num=str(people_num),
                          worker=worker[:3] + "X"))
            sr = sr_
        l_res = s.query(Log).filter(Log.sr == sr).first()
        if l_res:
            code = code if code != "XX" else l_res.code
            ins_code = s.query(Event.db_BB).with_for_update(read=True).filter(Event.db_BJ.like(f"%{code}%")).first()
            ins_code = ins_code[0] if ins_code else ""
            grade = float(people_num * get_factor(ins_code, business_type))
            logging.info(f"计算模板{sr}-{code}-{business_type}所值分数：{grade} 分")
            log_detail = s.query(LogDetail).with_for_update().filter(
                and_(LogDetail.log_id == l_res.id, LogDetail.business_type == business_type, LogDetail.code == code))
            if log_detail.first():
                log_detail.update({"people_num": people_num, "grade": grade, "ins_code": ins_code, "remark": serial_id})
            else:
                s.add(LogDetail(log_id=l_res.id, sr=sr, business_type=business_type, people_num=people_num, grade=grade,
                                ins_code=ins_code, code=code, remark=serial_id))


def get_date(dic):
    date = list(dic.values())[0][4]
    date = "".join(re.findall(r"[0-9]", date))
    return date


if __name__ == '__main__':
    tmp_file = save_as_excel('x:/1000299178-X450-岗位变动-岳子渝-湘潭.xlsx')
    print(tmp_file)
