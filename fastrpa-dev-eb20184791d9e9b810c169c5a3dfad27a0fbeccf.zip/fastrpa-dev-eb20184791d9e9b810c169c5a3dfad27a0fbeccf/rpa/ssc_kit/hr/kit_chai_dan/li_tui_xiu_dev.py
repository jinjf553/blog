#!/usr/bin/env python
# -*- coding: utf-8 -*-
# @File    : li_tui_xiu.py
# @Author  : jinjianfeng
# @Contact : 553041800@qq.com
# @Link    : https://github.com/jinjf553
# @software: PyCharm
# @Date    : 2019/6/15 15:46
# @Version : ??
import logging
import os
import shutil
import time
from collections import defaultdict
from datetime import datetime

from openpyxl import load_workbook
from rpa.fastrpa.adtable import BLUE, RED
from rpa.fastrpa.sap.session import close_sap
from rpa.public.config import FILE_PATH, templates
from rpa.public.tools import cel, cells
from rpa.ssc.hr.orm.orm_ope import Query
from rpa.ssc.hr.orm.td_hr_gang_wei_diao_pei_rulebase import Event
from rpa.ssc.hr.orm.td_hr_li_tui_code_rulebase import LiTui
from rpa.ssc.hr.sap.export_1072 import export_1072
from rpa.ssc.hr.sap.export_other_103 import (export_103_li_tui_xiu,
                                             export_103_li_zhi3)
from rpa.ssc_kit.hr.kit_chai_dan.check_280 import (check_zhrpy280, create_dir,
                                                   get_date, get_grade,
                                                   get_info)


def rulebase_11(file, file_str):
    wb_file = load_workbook(file)
    ws_file = wb_file.active
    # 规则 B-11.1.1  提取“人员离退表”的“事件类型”为“离退休”的事件
    value_dict, li = defaultdict(list), []
    for i in range(7, len(ws_file["B"]) + 1):
        if cel(ws_file, f"B{i}") and '离退休' == cel(ws_file, f"D{i}"):
            if cel(ws_file, f"B{i}") in li:
                cells(ws_file, f"B{i}", "人员编号有重复项", RED)
            li.append(cel(ws_file, f"B{i}"))
            value_dict[cel(ws_file, f"B{i}").lstrip('0')] = [str(j.value).replace('None', '').strip() for j in ws_file[f"B{i}:Q{i}"][0]]
    wb_file.save(file)
    if not li:
        logging.info("人员离退表中没有离退休事件。")
        return

    date = get_date(value_dict)
    if not date or len(date) != 8:
        return
    if not str(date).isdigit():
        days = time.strftime("%d", time.localtime(time.time()))
        date = time.strftime("%Y%m01", time.localtime(time.time() + (31 - int(days)) * 24 * 60 % 60))
    try:
        # B-11.1.2	通过组合逻辑查询下载C20-2、C22-3
        export_103_li_tui_xiu(None, li, date).save_to(FILE_PATH)
        export_103_li_zhi3("reuse", li, date).save_to(FILE_PATH)
    except Exception:
        return
    close_sap()
    wb_103 = load_workbook(FILE_PATH + "/C20_离退休.xlsx")
    ws_103 = wb_103.active
    values_103, value_1072 = defaultdict(list), defaultdict(list)
    for i in range(2, len(ws_103["A"]) + 1):
        for x in ['E', 'F', 'H', 'N', 'O', 'Q', 'AS', 'AT', 'AV', 'BE', 'BF', 'BH', 'BP', 'BQ', 'BS', 'BW', 'BX', 'BZ', 'CA', 'CE', 'CF', 'CH', 'CI', 'CK', 'CL']:
            ws_103[f"{x}{i}"] = cel(ws_103, f"{x}{i}").replace(".", "").replace("00000000", "")
        for col in ["AB", "AC", "AF", "AG", "AH", "AI", "AJ", "AK", "AR", "C", "D", "R", "S", "T", "U", "AX", 'BR', "BY", "CB", "CG", "CJ", "CM", "I", "L", "N"]:  # todo
            values_103[cel(ws_103, f"A{i}").lstrip('0')].append(cel(ws_103, f"{col}{i}"))
    wb_103.save(FILE_PATH + "/C20_离退休.xlsx")

    wb_103 = load_workbook(FILE_PATH + "/C23-3劳动合同.xlsx")
    ws_103 = wb_103.active
    values_103_1 = defaultdict(list)
    for i in range(2, len(ws_103["A"]) + 1):
        for x in ["D", "E", "G", "P"]:
            ws_103[f"{x}{i}"] = cel(ws_103, f"{x}{i}").replace(".", "").replace("00000000", "")
        for col in ["D", "E", "Z"]:
            values_103_1[cel(ws_103, f"A{i}").lstrip('0')].append(cel(ws_103, f"{col}{i}"))
    wb_103.save(FILE_PATH + "/C23-3劳动合同.xlsx")

    # 离退码表库
    rule_I = [str(res.db_I).strip() for res in Query(table=LiTui) if res.db_I]  # 工资核算范围
    rule_F = [str(res.db_F).strip() for res in Query(table=Event) if res.db_F]  # 企业自定义分类1
    rule_G = [str(res.db_G).strip() for res in Query(table=Event) if res.db_G]  # 企业自定义分类2
    rule_H = [str(res.db_H).strip() for res in Query(table=Event) if res.db_H]  # 企业自定义分类3
    rule_R = [str(res.db_R).strip() for res in Query(table=Event) if res.db_R]  # 人员标识
    rule_AZ = [str(res.db_AZ).strip() for res in Query(table=Event) if res.db_AZ]  # 岗位状态
    rule_X = [str(res.db_X).strip() for res in Query(table=LiTui) if res.db_X]  # 待遇级别
    rule_Q = [str(res.db_Q).strip() for res in Query(table=LiTui) if res.db_Q]  # 离退休事件原因
    rule_Q_Z = {str(res.db_Q).strip(): str(res.db_Z).strip() for res in Query(table=LiTui) if res.db_Q}  # 离退休原因对应人员子组
    rule_D = [str(res.db_D).strip() for res in Query(table=LiTui) if res.db_D]  # 码值
    rule_Ds, tmp_d = defaultdict(dict), defaultdict(str)  # 码值
    for res in Query(LiTui):
        t = {"C": res.db_C, "D": res.db_D, "E": res.db_E, "F": res.db_F, "G": res.db_G, "H": res.db_H, "I": res.db_I,
             "J": res.db_J, "K": res.db_K, "L": res.db_L, "M": res.db_M, "N": res.db_N}
        if res.db_D:
            tmp_d[str(res.db_D).strip()] = str(res.db_G)
            k = str(res.db_D).strip() + "|" + str(res.db_I).strip()
            rule_Ds[k] = {x: str(y).strip() for x, y in t.items()}
    gang_wei_hao = [tmp_d[x[5]] for x in value_dict.values() if x[5] in tmp_d.keys()]

    wb = load_workbook(os.path.join(templates, "离退休模板表.xlsx"))
    ws = wb.active

    for num, (key, value) in enumerate(list(value_dict.items())):
        j = str(num + 7)
        # B-11.2.1	生成离退休模板-1
        logging.info(f"正在生成并校验离退休模板第{num + 1}条数据...")
        if key not in values_103.keys():
            cells(ws, f"B{j}", "103表中没有该人员编号，请核对", RED)
            continue
        ws[f"A{j}"] = num + 1

        # B-11.2.1 B-11.2.2 B-11.2.3
        for count, col in {0: "B", 1: "C", 3: "E", 4: "D", 5: "AZ", 6: "BA", 10: "AR", 14: "BK"}.items():
            ws[f"{col}{j}"] = value[count] if value[count] != "None" else None

        # B-11.2.4
        if value[6]:
            ws[f"J{j}"] = values_103[key][0] + " " + values_103[key][1] if value[6] == '不变' else value[6]
            if cel(ws, f"J{j}") not in rule_I:
                cells(ws, f"J{j}", "工资核算范围非码值！", RED)
        else:
            cells(ws, f"J{j}", "企业表单工资核算范围未填写！", RED)

        # B-11.2.5
        if value[7]:
            ws[f"AZ{j}"] = values_103[key][2] + " " + values_103[key][3] if value[7] == '不变' else value[7]
            if not cel(ws, f"AZ{j}"):
                ws[f"AZ{j}"] = '清空'
            elif cel(ws, f"AZ{j}") not in rule_F:
                cells(ws, f"AZ{j}", "企业自定义分类1非码值！", RED)
        else:
            ws[f"AZ{j}"] = "清空"

        # B-11.2.6
        if value[8]:
            ws[f"BA{j}"] = values_103[key][4] + " " + values_103[key][5] if value[8] == '不变' else value[8]
            if not cel(ws, f"BA{j}"):
                ws[f"BA{j}"] = '清空'
            elif cel(ws, f"BA{j}") not in rule_G:
                cells(ws, f"BA{j}", "企业自定义分类2非码值！", RED)
        else:
            ws[f"BA{j}"] = "清空"

        # B-11.2.7
        if value[9]:
            ws[f"BB{j}"] = values_103[key][6] + " " + values_103[key][7] if value[9] == '不变' else value[9]
            if not cel(ws, f"BB{j}"):
                ws[f"BB{j}"] = '清空'
            elif cel(ws, f"BB{j}") not in rule_H:
                cells(ws, f"BB{j}", "企业自定义分类3非码值！", RED)
        else:
            ws[f"BB{j}"] = "清空"

        # B-11.2.8
        ws[f"AR{j}"] = value[10]
        if not cel(ws, f"AR{j}"):
            cells(ws, f"AR{j}", "领取企业年金人员标识为空！", BLUE)
        elif cel(ws, f"AR{j}") not in rule_R:
            cells(ws, f"AR{j}", "领取企业年金人员标识非码值!", RED)

        # B-11.2.9
        ws[f"AL{j}"] = value[11]
        if not cel(ws, f"AL{j}") and cel(ws, f"AL{j}") not in rule_X:
            cells(ws, f"AL{j}", "离退休后享受待遇级别非码值！", RED)

        # B-11.3.1 生成离退休模板-2
        if cel(ws, f"E{j}") not in rule_Q_Z.keys():
            cells(ws, f"E{j}", "事件原因非码值", RED)
        else:
            ws[f"I{j}"] = rule_Q_Z[cel(ws, f"E{j}")]

        # B-11.3.2
        ws[f"M{j}"] = 'X 是' if '是' in values_103[key][8] else '  否'

        # B-11.3.3
        if key in values_103_1.keys() and len(values_103_1[key]) == 3 and not values_103_1[key][1]:
            cells(ws, f"AY{j}", "不存在需要定界的劳动合同！", RED)
        else:
            if key in values_103_1.keys():
                ws[f"AF{j}"], ws[f"AY{j}"] = values_103_1[key][:2]
                ws[f"AH{j}"], ws[f"AI{j}"] = '3 合同终止', '离退休'
                try:
                    tmp_ls = values_103_1[key]
                    timeStamp = int(time.mktime(time.strptime(cel(ws, f"D{j}"), "%Y%m%d"))) - int(cel(ws, f"D{j}")[-2:]) * 24 * 60 * 60
                    ws["AG%s" % j] = time.strftime("%Y%m%d", time.localtime(timeStamp))
                    for x in range(0, len(tmp_ls), 3):
                        if tmp_ls[x] and int(cel(ws, f"D{j}")) <= int(tmp_ls[x]):
                            cells(ws, f"S{j}", "该人存在未来时间的劳动合同，请与企业确认如何处理！", RED)
                except Exception:
                    cells(ws, f"S{j}", "D列减册日期非正确值", RED)

        # B-11.3.4
        ws[f"BO{j}"], ws[f"BQ{j}"] = value[5], value[15]
        dic = {"BC": [9], "BD": [10], "BE": [11], "BF": [12, 13], "BP": [14], "BG": [0, 1], "BH": [15]}
        for k, v in dic.items():
            ws[f"{k}{j}"] = " ".join([values_103[key][x] for x in v])
        if not cel(ws, f"BH{j}"):
            cells(ws, f"BH{j}", "调动前职位序列为空，将按照男60岁，女55岁的标准执行校验！", RED)

        # B-11.3.5 B-11.3.6 B-11.3.7 B-11.3.8 B-11.3.9 B-11.3.10
        for k, v in {16: "BI", 17: "BJ", 18: "BK", 19: "BL", 20: "BM", 21: "BN"}.items():
            if str(values_103[key][k]).isdigit() and len(values_103[key][k]) == 8:
                try:
                    if int(values_103[key][k]) >= int(cel(ws, f"D{j}")):
                        timeStamp = int(time.mktime(time.strptime(cel(ws, f"D{j}"), "%Y%m%d"))) - int(cel(ws, f"D{j}")[-2:]) * 24 * 60 * 60
                        ws[f"{v}{j}"] = time.strftime("%Y%m%d", time.localtime(timeStamp))
                except Exception:
                    logging.info("Warning: 离职休模板D列的日期有误")
                    break

        # B-11.3.11
        if cel(ws, f"BO{j}") not in [x.split("|")[0] for x in rule_Ds.keys()]:
            for x in ["BR", "BS", "BT", "BU", "BV", "BW", "BX", "BY", "BZ", "CA", "CB", "CC"]:
                cells(ws, f"{x}{j}", "在离退码表库中未找到“调动后机构岗位”的码值！", RED)
        elif cel(ws, f"BO{j}") + "|" + cel(ws, f"J{j}") in rule_Ds.keys():
            for x, y in {"C": "R", "D": "S", "E": "T", "F": "U", "G": "V", "H": "W",
                         "I": "X", "J": "Y", "K": "Z", "L": "CA", "M": "CB", "N": "CC"}.items():
                ws[f"{'B' if len(y) == 1 else 'C'}{y}{j}"] = rule_Ds[cel(ws, f"BO{j}") + "|" + cel(ws, f"J{j}")][x]
        else:
            ds = [x for x in rule_Ds.keys() if cel(ws, f"BO{j}") == x.split("|")[0]][0]
            for x, y in {"D": "S", "E": "T", "F": "U", "G": "V", "H": "W",
                         "K": "Z", "L": "CA", "M": "CB", "N": "CC"}.items():
                ws[f"{'B' if len(y) == 1 else 'C'}{y}{j}"] = rule_Ds[ds][x]
            cells(ws, f"BX{j}", "离退码表库中该岗位未对应此工资核算范围，请联系组长补充离退码表库", RED)
            cells(ws, f"BY{j}", "离退码表库中该岗位未对应此工资核算范围，请联系组长补充离退码表库", RED)

        # B-11.4.2
        cur_day = time.strftime("%d")
        cur_month = time.strftime("%Y%m")
        next_month = time.strftime("%Y%m", time.localtime(time.time() + (32 - int(cur_day)) * 24 * 60 * 60))
        if cel(ws, f"D{j}").isdigit() and len(cel(ws, f"D{j}")) == 8:
            if cel(ws, f"D{j}") in [f"{cur_month}01", f"{next_month}01"]:
                if values_103[key][22]:
                    cells(ws, f"D{j}", "事件日期为1日，当日有事件！", RED)
            elif cel(ws, f"D{j}") in [f"{cur_month}02", f"{next_month}02"]:
                if "调入" in values_103[key][22] or "调出" in values_103[key][22]:
                    cells(ws, f"D{j}", "事件日期为2日，1日有调动！", BLUE)
                elif not values_103[key][22]:
                    cells(ws, f"D{j}", "事件日期为2日，1日无事件！", RED)
                else:
                    cells(ws, f"D{j}", "事件日期为2日，1日有调动以外的事件！", RED)
            else:
                cells(ws, f"D{j}", "事件日期需核对！", RED)
        else:
            cells(ws, f"D{j}", "事件日期需核对！", RED)

        # B-11.4.3
        if values_103[key][23] in rule_AZ[9:16]:
            cells(ws, f"C{j}", "请核对该人员的岗位状态是否应做离退休事件", RED)

        # B-11.4.4
        if cel(ws, f"J{j}") != cel(ws, f"BX{j}"):
            cells(ws, f"J{j}", "企业表单上填写的工资核算范围与离退码表库不同！", RED)

        # B-11.5.1
        bv = cel(ws, f"BV{j}").lstrip("0")
        if cel(ws, f"BR{j}"):
            if not os.path.exists(FILE_PATH + "/模板_1072.xlsx"):
                logging.info(f"离退休模板BR列有值，下载1072表")
                export_1072(None, gang_wei_hao, date).save_to(FILE_PATH)
                ws_ = load_workbook(FILE_PATH + "/模板_1072.xlsx").active
                for x in range(2, len(ws_["A"]) + 1):
                    t = [("G", x), ("AM", x), ("P", x), ("Q", x), ("R", x), ("P", x + 1), ("Q", x + 1), ("R", x + 1)]
                    if cel(ws_, f"B{x}") == "S":
                        value_1072[cel(ws_, f"A{x}").lstrip('0')] = [cel(ws_, f"{y}{z}") for y, z in t]
            if bv in value_1072.keys():
                if value_1072[bv][0] != cel(ws, f"BW{j}"):
                    cells(ws, f"BW{j}", "岗位名称与离退码表库不同！", RED)
                if value_1072[bv][1] != "是":
                    cells(ws, f"BV{j}", "未勾选虚岗位标识！", RED)
            else:
                cells(ws, f"BV{j}", "未在系统中查找到该岗位编号！", RED)

        # B-11.5.2	逻辑关系校验-人事范围、人事子范围
        if cel(ws, f"BR{j}") and bv in value_1072.keys():
            if not (value_1072[bv][2] or value_1072[bv][3]):
                if not (value_1072[bv][5] or value_1072[bv][6]):
                    cells(ws, f"BT{j}", "岗位及所在机构的财务科目设置的人事范围均为空！", BLUE)  # 10
                elif value_1072[bv][5] != cel(ws, f"BT{j}"):
                    cells(ws, f"BT{j}", "岗位所在机构的财务科目设置的人事范围与模板不一致！", RED)  # 7
                else:
                    if value_1072[bv][6] + " " + value_1072[bv][7] == cel(ws, f"BU{j}"):
                        cells(ws, f"BT{j}", "岗位所在机构的财务科目设置的人事范围、人事子范围与模板一致！", BLUE)  # 8
                    else:
                        cells(ws, f"BT{j}", "岗位所在机构的财务科目设置的人事子范围与模板不一致！", RED)  # 9
            elif not value_1072[bv][2]:
                if value_1072[bv][3] + " " + value_1072[bv][4] == cel(ws, f"BU{j}"):
                    cells(ws, f"BT{j}", "岗位财务科目设置有值，人事范围继承自机构、人事子范围设置在岗位上！", BLUE)  # 1
                else:
                    cells(ws, f"BT{j}", "岗位财务科目设置有值，人事范围继承自机构、人事子范围设置在岗位上但与模板不同！", RED)  # 2
            else:
                if value_1072[bv][2] == cel(ws, f"BT{j}"):
                    if not value_1072[bv][3]:
                        cells(ws, f"BT{j}", "岗位财务科目设置有值，人事范围有值、但人事子范围为空或继承自机构！", BLUE)  # 3
                    elif value_1072[bv][6] + " " + value_1072[bv][7] == cel(ws, f"BU{j}"):
                        cells(ws, f"BT{j}", "岗位财务科目设置有值，人事范围、人事子范围均设置在岗位上且与模板一致！", BLUE)  # 4
                    else:
                        cells(ws, f"BT{j}", "岗位财务科目设置有值，人事范围、人事子范围均设置在岗位上，但人事子范围与模板不一致！", RED)  # 5
                else:
                    cells(ws, f"BT{j}", "岗位财务科目设置有值，但人事范围与模板不一致！", RED)  # 6

        # B-11.5.3
        if cel(ws, f"D{j}") == values_103[key][24]:
            cells(ws, f"A{j}", "组织分配屏本月已有事件！", BLUE)

        # B-11.5.4
        if not ws[f"E{j}"].comment and cel(ws, f"E{j}") in rule_Q[1:6]:
            cells(ws, f"AX{j}", "请确认事件原因为：【离退休模板-【E-离退休事件原因】】", BLUE)

    serial_id = datetime.now().strftime("%Y-%m-%d-%H-%M-%S-%f")
    wb.properties.description = serial_id
    wb.save(FILE_PATH + '/tmp-离退.xlsx')
    check_zhrpy280(FILE_PATH + '/tmp-离退.xlsx')
    local = create_dir(file, file_str)
    sr, code, worker = get_info(file, file_str)
    get_grade(f"{sr}-{code}-{worker}", value_dict, "人员退休", serial_id)
    shutil.move(FILE_PATH + '/C20_离退休.xlsx', local + f"/103_离退休事件_{os.path.basename(file)}")
    shutil.move(FILE_PATH + '/C23-3劳动合同.xlsx', local + f"/103劳动合同_离退休事件_{os.path.basename(file)}")
    shutil.move(FILE_PATH + '/tmp-离退.xlsx', local + f"/{sr}-{code}-离退休-{worker}.xlsx")
    if os.path.exists(FILE_PATH + "/模板_1072.xlsx"):
        shutil.move(FILE_PATH + "/模板_1072.xlsx", local + f"/1072_离退休事件_{os.path.basename(file)}")
