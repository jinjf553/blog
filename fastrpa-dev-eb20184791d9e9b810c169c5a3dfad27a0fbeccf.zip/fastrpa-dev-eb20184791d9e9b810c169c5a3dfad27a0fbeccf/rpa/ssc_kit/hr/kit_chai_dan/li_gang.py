#!/usr/bin/env python
# -*- coding: utf-8 -*-
# @File    : li_gang.py
# @Author  : jinjianfeng
# @Contact : 553041800@qq.com
# @Link    : https://github.com/jinjf553
# @software: PyCharm
# @Date    : 2019/6/13 13:57
# @Version : ??
import logging
import os
import shutil
import time
from collections import defaultdict

from openpyxl import load_workbook
from rpa.fastrpa.adtable import BLUE, RED
from rpa.public.config import FILE_PATH, templates
from rpa.public.tools import cel, cells
from rpa.ssc.hr.orm.orm_ope import Query
from rpa.ssc.hr.orm.td_hr_gang_wei_diao_pei_rulebase import Event
from rpa.ssc.hr.sap.export_103_bk import export_103_bk
from rpa.ssc_kit.hr.kit_chai_dan.check_280 import (check_zhrpy280, create_dir,
                                                   get_date, split_file)


def rulebase_8(file, file_str):
    wb = load_workbook(file)
    ws = wb.active

    # 规则 8.1.1 - 8.1.2
    value_dict, li = defaultdict(list), []
    for i in range(7, len(ws["B"]) + 1):
        # 规则 8.1.1  提取“人员调配表”的“事件类型”为“离岗”的事件
        if ws["B%s" % str(i)].value and '离岗' in str(ws["D%s" % str(i)].value):
            if cel(ws, f"B{i}") in li:
                cells(ws, "B%s" % str(i), "人员编号有重复项", RED)
            li.append(cel(ws, f"B{i}"))
            value_dict[cel(ws, f"B{i}")] = [str(j.value).strip() for j in ws["B%s:W%s" % (str(i), str(i))][0]]
    wb.save(file)
    if not li:
        logging.info("人员调配表中没有离岗事件。")
        return

    date = get_date(value_dict)
    if not date or len(date) != 8:
        return
    export_103_bk(None, li, date).save_to(FILE_PATH)
    wb_103 = load_workbook(FILE_PATH + "/模板_103.xlsx")
    ws_103 = wb_103.active
    values_103 = defaultdict(list)
    for i in range(2, len(ws_103["A"]) + 1):
        for col in ["BC", "AD", "AE", "AK", "Q", "R", "W", "Y", "S", "T", "Z", "AX", "AP", "BI", "G", "J", "P"]:
            values_103[str(ws_103["A%s" % str(i)].value).lstrip('0')].append(str(ws_103["%s%s" % (col, str(i))].value))

    rule_values = defaultdict(list)
    [rule_values[res.db_U.split()[1]].append(res.db_U.split()[0])
     for res in Query(table=Event) if res.db_U]
    rule_J = [res.db_J for res in Query(table=Event) if res.db_J]  # 人员组
    rule_L = [res.db_L for res in Query(table=Event) if res.db_L]  # 人员子组
    rule_AG = [res.db_AG for res in Query(table=Event) if res.db_AG]  # 工资核算范围
    rule_F = [res.db_F for res in Query(table=Event) if res.db_F]  # 企业自定义分类1
    rule_G = [res.db_G.replace(" ", "") for res in Query(table=Event) if res.db_G]  # 企业自定义分类2
    rule_H = [res.db_H.replace(" ", "") for res in Query(table=Event) if res.db_H]  # 企业自定义分类3
    rule_R = [res.db_R for res in Query(table=Event) if res.db_R]  # 人员标识
    rule_BF = [res.db_BF for res in Query(table=Event) if res.db_BF]  # 离岗事件原因
    rule_AZ = [res.db_AZ for res in Query(table=Event) if res.db_AZ]  # 人员标识
    wb_template = load_workbook(os.path.join(templates, "离岗事件模板表.xlsx"))
    ws_template = wb_template.active
    for num, (key, value) in enumerate(list(value_dict.items())):
        # 规则 8.2.2 - 8.2.8  B-W
        for count, col in {0: "B", 1: "C", 3: "E", 4: "D", 5: "I", 7: "J", 8: "V", 9: "W", 10: "AB", 12: "AC",
                           21: "AD", 18: "AE", 19: "AF", 20: "AG"}.items():
            ws_template["%s%s" % (col, str(num + 7))] = value[count] if value[count] != "None" else None

        # 规则 8.2.9  K-企业自定义分类
        if value[14] not in [None, "None"] and "清空" not in value[14]:
            ws_template["K%s" % str(num + 7)] = value[14]
            if value[14] not in rule_F:
                cells(ws_template, "K%s" % str(num + 7), "企业自定义分类1非码值", RED)

        # 规则 8.2.10  L-企业自定义分类2
        if value[15] not in [None, "None"] and "清空" not in value[15]:
            ws_template["L%s" % str(num + 7)] = value[15]
            if value[15] not in rule_G:
                cells(ws_template, "L%s" % str(num + 7), "企业自定义分类2非码值", RED)

        # 规则 8.2.11  U-企业自定义分类3
        if value[16] not in [None, "None"] and "清空" not in value[16]:
            ws_template["U%s" % str(num + 7)] = value[16]
            if value[16].replace(" ", "") not in rule_H:
                cells(ws_template, "U%s" % str(num + 7), "企业自定义分类3非码值", RED)

        # 规则 8.3.2 - 8.3.4  X-调动前机构 & Y-调动前岗位 & Z-调动前人事子范围
        if key.lstrip('0') in values_103.keys():
            ws_template["X%s" % str(num + 7)] = values_103[key.lstrip('0')][6]
            ws_template["Y%s" % str(num + 7)] = values_103[key.lstrip('0')][7]
            ws_template["Z%s" % str(num + 7)] = values_103[key.lstrip('0')][4] + ' ' + values_103[key.lstrip('0')][5]

        # 规则 8.3.5  H-人员组
        if key.lstrip('0') in values_103.keys():
            if [v for v in rule_J if values_103[key.lstrip('0')][8] == v[:1]]:
                ws_template["H%s" % str(num + 7)] = [v for v in rule_J if values_103[key.lstrip('0')][8] == v[:1]][0]
            else:
                raise Exception("规则库中没有人员组为" + values_103[key.lstrip('0')][8] + "的规则，请检查")

        # 规则 8.3.6  M-企业统计标识
        if key.lstrip('0') in values_103.keys():
            if [x for x in rule_R if values_103[key.lstrip('0')][12].strip() in x]:
                ws_template["M%s" % str(num + 7)] = [x for x in rule_R if values_103[key.lstrip('0')][12].strip() in x][
                    0]

        # 规则 8.3.7  I-人员子组
        if str(ws_template["I%s" % str(num + 7)].value).replace(" ", "") == "不变":
            if key.lstrip('0') in values_103.keys():
                if [v for v in rule_L if values_103[key.lstrip('0')][9] in v]:
                    ws_template["I%s" % str(num + 7)] = [v for v in rule_L if values_103[key.lstrip('0')][9] in v][0]
                else:
                    ws_template["I%s" % str(num + 7)] = values_103[key.lstrip('0')][9]
                    cells(ws_template, "I%s" % str(num + 7), "码表库中没有该人员子组，请检查", RED)
        elif ws_template["I%s" % str(num + 7)].value not in rule_L:
            cells(ws_template, "I%s" % str(num + 7), "人员子组非码值", RED)

        # 规则 8.3.8  J-工资核算范围
        if str(ws_template["J%s" % str(num + 7)].value).replace(" ", "") == "不变":
            if key.lstrip('0') in values_103.keys():
                if [v for v in rule_AG if values_103[key.lstrip('0')][10] in v]:
                    ws_template["J%s" % str(num + 7)] = [v for v in rule_AG if values_103[key.lstrip('0')][10] in v][0]
                else:
                    ws_template["J%s" % str(num + 7)] = values_103[key.lstrip('0')][10]
                    cells(ws_template, "J%s" % str(num + 7), "码表库中没有该工资核算范围，请检查", RED)
        elif ws_template["J%s" % str(num + 7)].value not in rule_AG:
            cells(ws_template, "J%s" % str(num + 7), "工资核算范围非码值", RED)

        # 规则 8.3.9  A-序号
        ws_template["A%s" % str(num + 7)] = str(num + 1)

        # 规则 8.3.10  AA-调动前人事范围
        if key.lstrip('0') in values_103.keys():
            ws_template["AA%s" % str(num + 7)] = values_103[key.lstrip('0')][16]

        # 规则 8.4.1  D-岗位变动日期
        try:
            time.strptime(str(ws_template["D%s" % str(num + 7)].value), '%Y%m%d')
            current_date = time.strftime("%d", time.localtime(time.time()))
            current_month = time.strftime("%Y%m01", time.localtime(time.time()))
            next_month = time.strftime("%Y%m01", time.localtime(time.time() + (32 - int(current_date)) * 24 * 60 * 60))
            if str(ws_template["D%s" % str(num + 7)].value) not in [current_month, next_month]:
                cells(ws_template, "D%s" % str(num + 7), "事件日期需核对", RED)
            if num != 0 and ws_template["D%s" % str(num + 6)].value != ws_template["D%s" % str(num + 7)].value:
                cells(ws_template, "D%s" % str(num + 7), "事件日期需核对", RED)
        except Exception:
            cells(ws_template, "D%s" % str(num + 7), "事件日期需核对", RED)

        # 规则 8.4.2  E-调入原因
        if ws_template["E%s" % str(num + 7)].value not in rule_BF:
            cells(ws_template, "E%s" % str(num + 7), "事件原因需核对", RED)

        # 规则 8.4.3  J-人员子组
        if ws_template["J%s" % str(num + 7)].value == rule_L[6]:
            cells(ws_template, "J%s" % str(num + 7), "人员子组不为“22 其他不在岗人员”，需核对", RED)

        # 规则 8.4.5  G-事件类型
        if key.lstrip('0') in values_103.keys() and values_103[key.lstrip('0')][14] != "None":
            cells(ws_template, "A%s" % str(num + 7), "请注意该人员该月已做过事件", RED)

        # 规则 8.4.6  J-人员子组
        if ws_template["J%s" % str(num + 7)].value in rule_L[0:2]:
            if key.lstrip('0') in values_103.keys() and values_103[key.lstrip('0')][9] in rule_L[3:5]:
                cells(ws_template, "F%s" % str(num + 7), "该人员由技能操作序列转为经营管理序列", BLUE)

        # 规则 8.4.7  C-人员姓名
        if key.lstrip('0') in values_103.keys() and values_103[key.lstrip('0')][15] != rule_AZ[0]:
            cells(ws_template, "C%s" % str(num + 7), "该人员目前的岗位状态不是在岗状态，请核对是否应做离岗事件", RED)
    wb_template.save(FILE_PATH + '/tmp-离岗.xlsx')
    check_zhrpy280(FILE_PATH + '/tmp-离岗.xlsx')
    local = create_dir(file, file_str)
    shutil.move(FILE_PATH + "/模板_103.xlsx", local + f"/103_离岗事件_{os.path.basename(file)}")
    split_file(FILE_PATH + '/tmp-离岗.xlsx', "AA", "离岗事件模板", local, "人员离岗")
