#!/usr/bin/env python
# -*- coding: utf-8 -*-
# @File    : li_zhi.py
# @Author  : jinjianfeng
# @Contact : 553041800@qq.com
# @Link    : https://github.com/jinjf553
# @software: PyCharm
# @Date    : 2019/7/16 14:46
# @Version : ??
import logging
import os
import re
import shutil
import time
from collections import defaultdict
from datetime import datetime

from openpyxl import load_workbook
from rpa.fastrpa.adtable import RED
from rpa.public.config import FILE_PATH, templates
from rpa.public.tools import cel, cells
from rpa.ssc.hr.orm.orm_ope import Query
from rpa.ssc.hr.orm.td_hr_li_tui_code_rulebase import LiTui
from rpa.ssc.hr.sap.export_other_103 import (export_103_li_zhi2,
                                             export_103_li_zhi3)
from rpa.ssc_kit.hr.kit_chai_dan.check_280 import (check_zhrpy280, create_dir,
                                                   get_date, get_grade)


def rulebase_14(file, file_str):
    wb = load_workbook(file)
    ws = wb.active
    # 规则 14.1.1  提取“人员离退表”的“事件类型”为“离职”的事件
    value_dict, li = defaultdict(list), []
    for i in range(7, len(ws["B"]) + 1):
        if ws["B%s" % str(i)].value and '离职' in str(ws["D%s" % str(i)].value):
            if cel(ws, f"B{i}") in li:
                cells(ws, "B%s" % str(i), "人员编号有重复项", RED)
            if cel(ws, f"B{i}").strip().isdigit():
                li.append(cel(ws, f"B{i}").strip())
            value_dict[cel(ws, f"B{i}")] = [str(j.value).strip() for j in ws["B%s:T%s" % (str(i), str(i))][0]]
    wb.save(file)
    if not li:
        logging.info("人员离退表中没有离职事件。")
        return
    date = get_date(value_dict)
    if not date or len(date) != 8:
        return
    export_103_li_zhi2(None, li, date).save_to(FILE_PATH)
    # shutil.move(file_path + "/C23-2离职.xlsx", file_path + "/C23-2离职.xlsx")

    try:
        time_stamp = time.mktime(time.strptime(date, "%Y%m%d"))
        yesterday = time.strftime("%Y%m%d", time.localtime(int(time_stamp) - 24 * 60 * 60))
    except Exception:
        yesterday = date
    export_103_li_zhi3("reuse", li, yesterday).save_to(FILE_PATH)
    # shutil.move(file_path + f"/C23-3劳动合同.xlsx", file_path + "/C23-3劳动合同.xlsx")
    wb_103 = load_workbook(FILE_PATH + "/C23-2离职.xlsx")
    ws_103 = wb_103.active
    values_103 = defaultdict(list)
    for i in range(2, len(ws_103["A"]) + 1):
        for x in ["C", "D", "F", "L", "M", "O", "AS", "AT", "AV", "BA", "BB", "BD", "BK", "BM"]:
            ws_103[f"{x}{i}"] = str(ws_103[f"{x}{i}"].value).replace(".", "").replace("00000000", "")
        for col in ["AO", "BM", "R", "P", "BK", "CB", "G", "J", "AP"]:
            values_103[str(ws_103["A%s" % str(i)].value).lstrip('0')].append(str(ws_103["%s%s" % (col, str(i))].value))
    wb_103.save(FILE_PATH + "/C23-2离职.xlsx")

    wb_103 = load_workbook(FILE_PATH + "/C23-3劳动合同.xlsx")
    ws_103 = wb_103.active
    values_103_1 = defaultdict(list)
    for i in range(2, len(ws_103["A"]) + 1):
        for x in ["D", "E", "G", "P"]:
            ws_103[f"{x}{i}"] = str(ws_103[f"{x}{i}"].value).replace(".", "").replace("00000000", "")
        for col in ["D", "E", "Z"]:
            values_103_1[str(ws_103["A%s" % str(i)].value).lstrip('0')].append(
                str(ws_103["%s%s" % (col, str(i))].value))
    wb_103.save(FILE_PATH + "/C23-3劳动合同.xlsx")

    rule_AX = [res.rule_AX for res in Query(table=LiTui) if res.rule_AX]
    rule_AS = [res.rule_AS for res in Query(table=LiTui) if res.rule_AS]
    rule_AT = [res.rule_AT for res in Query(table=LiTui) if res.rule_AT]
    rule_AS_AR = {res.rule_AS: res.rule_AR for res in Query(table=LiTui) if res.rule_AS}

    wb_template = load_workbook(os.path.join(templates, "离职事件模板表.xlsx"))
    ws_t = wb_template.active

    for num, (key, value) in enumerate(list(value_dict.items())):
        logging.info(f"正在生成并校验离职模板第{num + 1}条数据...")
        if key.lstrip('0') not in values_103.keys():
            cells(ws_t, "B%s" % str(num + 7), "103表中没有该人员编号，请核对", RED)
            continue

        # 规则 B-14.1.4 - 14.2.3  B-D
        for count, col in {0: "B", 1: "C", 3: "E", 4: "D", 14: "AE", 15: "AA", 16: "AB"}.items():
            ws_t[f"{col}{num+7}"] = value[count] if value[count] != "None" else None
        # 规则 B-14.1.5  B-14.1.6
        ws_t[f"I{num + 7}"] = value[3] if value[3] != "None" else None
        cur_month = time.strftime("%Y%m01")
        cur_day = time.strftime("%d")
        nex_month = time.strftime("%Y%m01", time.localtime(time.time() + (32 - int(cur_day)) * 24 * 60 * 60))
        if cel(ws_t, f"D{num+7}") not in [cur_month, nex_month]:
            cells(ws_t, f"D{num+7}", "事件执行日期不为1日！", RED)

        # 规则 14.2.4  G-合同解除/终止日期
        if value[12] in [None, "None"]:
            cells(ws_t, "G%s" % str(num + 7), "企业表单减册日期为空", RED)
        else:
            ws_t[f"G{num+7}"] = "".join(re.findall(r"\d+", str(value[12].replace(".", ''))))
            ws_t[f"AC{num+7}"] = "".join(re.findall(r"\d+", str(value[12].replace(".", ''))))

        # 规则 14.2.5  K-单位支付补偿金额
        if value[13] not in [None, "None"]:
            try:
                a = '%.2f' % float(value[13])
                ws_t["K%s" % str(num + 7)] = str(a)
                if float(a) >= 10000000.0:
                    raise
            except Exception:
                cells(ws_t, "K%s" % str(num + 7), "单位支付补偿金额有误！", RED)

        # 规则 B-14.2.1 & 14.3.5  E-减册原因
        if ws_t["E%s" % str(num + 7)].value not in rule_AS:
            cells(ws_t, "E%s" % str(num + 7), "事件原因非码值！", RED)
        # else:
        #     ws_t["I%s" % str(num + 7)] = \
        #         str(ws_t["E%s" % str(num + 7)].value).replace("None", "").split()[-1]
        #     if ws_t["E%s" % str(num + 7)].value in [rule_AS[0], rule_AS[13]]:
        #         ws_t["H%s" % str(num + 7)] = rule_AT[0]
        #     else:
        #         ws_t["H%s" % str(num + 7)] = rule_AT[1]

        # 规则 14.3.3  F-合同生效日期
        if values_103[key.lstrip('0')][0] not in [None, "None", "0000.00.00"]:
            ws_t["F%s" % str(num + 7)] = values_103[key.lstrip('0')][0].replace(".", "")

        # 规则 14.3.6  T-结束日期
        end_date = str(values_103[key.lstrip('0')][8]).replace(".", "").replace("00000000", "")
        ws_t["T%s" % str(num + 7)] = end_date

        # 规则 14.3.7  U-增减变动类别
        if not ws_t["E%s" % str(num + 7)].comment and ws_t[
                "E%s" % str(num + 7)].value in rule_AS_AR.keys():
            ws_t["U%s" % str(num + 7)] = rule_AS_AR[ws_t["E%s" % str(num + 7)].value]

        # 规则 14.3.8  V-调出部门
        ws_t["V%s" % str(num + 7)] = values_103[key.lstrip('0')][2]

        # 规则 14.3.9 & 14.3.10  W-其他用工信息公开日期 & X-博士后研究人员开始日期
        ws_t["W%s" % str(num + 7)] = values_103[key.lstrip('0')][4].replace("0000.00.00", "")
        ws_t["X%s" % str(num + 7)] = values_103[key.lstrip('0')][5].replace("0000.00.00", "")

        # 规则 14.3.11  A-序号
        ws_t["A%s" % str(num + 7)] = str(num + 1)

        # 规则 14.4.2  D-离职日期
        try:
            time.strptime(str(ws_t["D%s" % str(num + 7)].value), '%Y%m%d')
            current_date = time.strftime("%d", time.localtime(time.time()))
            current_month = time.strftime("%Y%m01", time.localtime(time.time()))
            next_month = time.strftime("%Y%m01", time.localtime(time.time() + (32 - int(current_date)) * 24 * 60 * 60))
            if str(ws_t["D%s" % str(num + 7)].value) not in [current_month, next_month]:
                cells(ws_t, "D%s" % str(num + 7), "事件执行日期需核对", RED)
            if num != 0 and ws_t["D%s" % str(num + 6)].value != ws_t["D7"].value:
                cells(ws_t, "D%s" % str(num + 7), "事件执行日期需核对", RED)
        except Exception:
            cells(ws_t, "D%s" % str(num + 7), "事件执行日期需核对", RED)

        # 规则 14.4.3  A-序列号
        if values_103[key.lstrip('0')][6] != "None":
            cells(ws_t, "A%s" % str(num + 7), "请注意该人员该月已做过事件", RED)

        # 规则 14.4.4  C-人员姓名
        if values_103[key.lstrip('0')][7] in rule_AX[9:16]:
            cells(ws_t, "C%s" % str(num + 7), "请核对该人员的岗位状态是否正确", RED)

        # 规则 11.4.5  F-合同生效日期
        # if values_103[key.lstrip('0')][8][:4] not in ["None", "9999", "0000"]:
        #     date = int(time.mktime(time.strptime(values_103[key.lstrip('0')][8], "%Y.%m.%d"))) + 24 * 60 * 60
        #     if int(time.strftime("%Y%m%d", time.localtime(date))) == int(ws_t["D%s" % str(num + 7)].value):
        #         ws_t["F%s" % str(num + 7)] = values_103[key.lstrip('0')][0]
        #     if int(time.strftime("%Y%m%d", time.localtime(date))) < int(ws_t["D%s" % str(num + 7)].value):
        #         ws_t["F%s" % str(num + 7)] = values_103[key.lstrip('0')][0]
        #         cells(ws_t, "F%s" % str(num + 7), "请检验该人员劳动合同结束日期！", RED)

        # 规则 14.4.6  F-合同生效日期
        if ws_t["F%s" % str(num + 7)].value in ["None", None]:
            if key.lstrip("0") in values_103_1.keys() and values_103_1[key.lstrip('0')][0] not in ["None", None]:
                ws_t["F%s" % str(num + 7)] = values_103_1[key.lstrip('0')][0]
                ws_t["G%s" % str(num + 7)] = values_103_1[key.lstrip('0')][1]
            else:
                cells(ws_t, "F%s" % str(num + 7), "请核对该人员是否有劳动合同", RED)

        # 规则 14.4.7  Z-停薪日期
        if values_103[key.lstrip('0')][3] in ["X480", "X48Z", "X481"]:
            try:
                tmp_date = ''.join(re.findall(r"\d+", str(ws_t["Z%s" % str(num + 7)].value)))
                time.strptime(tmp_date, '%Y%m%d')
                if int(tmp_date) < int(str(ws_t["Z%s" % str(num + 7)].value)) or tmp_date[-2:] != "01":
                    cells(ws_t, "Z%s" % str(num + 7), "停薪日期不是01号", RED)
            except Exception:
                if int(time.strftime("%d", time.localtime(time.time()))) > 20:
                    cells(ws_t, "Z%s" % str(num + 7), "停薪日期不是常识日期", RED)
            if int(time.strftime("%d", time.localtime(time.time()))) > 20 and not ws_t[
                    "Z%s" % str(num + 7)].value:
                cells(ws_t, "Z%s" % str(num + 7), "校验日期大于20号，停薪日期应该为必填项", RED)

        # 规则 14.4.8  Y-工资范围
        if ws_t["Z%s" % str(num + 7)].value and key.lstrip('0') in values_103_1.keys():
            ws_t["Y%s" % str(num + 7)] = values_103_1[key.lstrip('0')][2]

        # 规则 14.4.9  I-解除/终止原因
        if values_103[key.lstrip('0')][3] in ["X480", "X48Z", "X481"]:
            ws_t["I%s" % str(num + 7)] = value[14] if value[14] != "None" else ""
    serial_id = datetime.now().strftime("%Y-%m-%d-%H-%M-%S-%f")
    wb_template.properties.description = serial_id
    wb_template.save(FILE_PATH + '/tmp-离职.xlsx')
    check_zhrpy280(FILE_PATH + '/tmp-离职.xlsx')
    local = create_dir(file, file_str)
    # os.remove(file_path + "/C23-2离职.xlsx")
    get_grade(f"{os.path.basename(file).split('-')[0][:10]}-XX-XX", value_dict, "在职人员减册", serial_id)
    shutil.move(FILE_PATH + "/C23-3劳动合同.xlsx", local + f"/103_C23-3劳动合同_{os.path.basename(file)}")
    shutil.move(FILE_PATH + "/C23-2离职.xlsx", local + f"/103_C23-2离职_{os.path.basename(file)}")
    shutil.move(FILE_PATH + '/tmp-离职.xlsx', local + f"/{os.path.basename(file)[:10]}_离职事件模板.xlsx")
