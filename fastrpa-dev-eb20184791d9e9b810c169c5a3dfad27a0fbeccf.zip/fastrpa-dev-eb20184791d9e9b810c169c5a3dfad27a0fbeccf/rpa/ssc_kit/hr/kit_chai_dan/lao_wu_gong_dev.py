#!/usr/bin/env python
# -*- coding: utf-8 -*-
# @File    : lao_wu_gong.py
# @Author  : jinjianfeng
# @Contact : 553041800@qq.com
# @Link    : https://github.com/jinjf553
# @software: PyCharm
# @Date    : 2019/7/20 14:03
# @Version : ??
import logging
import os
import shutil
import time
from collections import defaultdict
from datetime import datetime, timedelta

from openpyxl import load_workbook
from rpa.fastrpa.adtable import BLUE, RED
from rpa.public.config import FILE_PATH, templates
from rpa.public.tools import cel, cells
from rpa.ssc.hr.sap.export_other_103 import (export_103_li_zhi2,
                                             export_103_li_zhi3)
from rpa.ssc_kit.hr.kit_chai_dan.check_280 import (check_zhrpy280, create_dir,
                                                   get_date, get_grade,
                                                   get_info)


def rulebase_15(file, file_str):
    wb = load_workbook(file)
    ws = wb.active
    # 规则 15.1.1  提取“人员离退表”的“事件类型”为“劳务工退回”的事件
    value_dict, li = defaultdict(list), []
    for i in range(7, len(ws["B"]) + 1):
        if cel(ws, f"B{i}") and '劳务工退回' in cel(ws, f"D{i}"):
            if cel(ws, f"B{i}") in li:
                cells(ws, f"B{i}", "人员编号有重复项", RED)
            li.append(cel(ws, f"B{i}"))
            value_dict[cel(ws, f"B{i}").lstrip('0')] = [str(j.value).strip() for j in ws[f"B{i}:Q{i}"][0]]
    wb.save(file)
    if not li:
        logging.info("人员离退表中没有劳务工退回事件。")
        return
    date = get_date(value_dict)
    if not date or len(date) != 8:
        return
    export_103_li_zhi2("reuse", li, date).save_to(FILE_PATH)

    try:
        time_stamp = time.mktime(time.strptime(date, "%Y%m%d"))
        yesterday = time.strftime("%Y%m%d", time.localtime(int(time_stamp) - 24 * 60 * 60))
    except Exception:
        yesterday = date
    export_103_li_zhi3("reuse", li, yesterday).save_to(FILE_PATH)

    wb_103 = load_workbook(FILE_PATH + "/C23-2离职.xlsx")
    ws_103 = wb_103.active
    values_103 = defaultdict(list)
    for i in range(2, len(ws_103["A"]) + 1):
        for x in ["C", "D", "F", "L", "M", "O", "AS", "AT", "AV", "BA", "BB", "BD", "BK", "BM"]:
            ws_103[f"{x}{i}"] = cel(ws_103, f"{x}{i}").replace(".", "").replace("00000000", "")
        for col in ["G", "S", "R", "P", "BK", "CB", "G", "J", "AP", "AT", "BB", "BO", "BK", "BM"]:
            values_103[cel(ws_103, f"A{i}").lstrip('0')].append(cel(ws_103, f"{col}{i}"))
    wb_103.save(FILE_PATH + "/C23-2离职.xlsx")

    wb_103 = load_workbook(FILE_PATH + "/C23-3劳动合同.xlsx")
    ws_103 = wb_103.active
    values_103_1 = defaultdict(list)
    for i in range(2, len(ws_103["A"]) + 1):
        for x in ["D", "E", "G", "P"]:
            ws_103[f"{x}{i}"] = cel(ws_103, f"{x}{i}").replace(".", "").replace("00000000", "")
        for col in ["D", "E", "Z"]:
            values_103_1[cel(ws_103, f"A{i}").lstrip('0')].append(cel(ws_103, f"{col}{i}"))
    wb_103.save(FILE_PATH + "/C23-3劳动合同.xlsx")

    wb_temp = load_workbook(os.path.join(templates, "劳务工退回模板表.xlsx"))
    ws = wb_temp.active

    now = datetime.now()
    next_month = datetime(*(now.year, now.month + 1) if now.month + 1 < 13 else (now.year + 1, 1), 1, 0, 0, 0)
    last_month = datetime(*(now.year, now.month - 1) if now.month - 1 > 0 else (now.year - 1, 12), 1, 0, 0, 0)
    cur_month = datetime(now.year, now.month, 1, 0, 0, 0)
    las, cur, nex = last_month.strftime("%Y%m%d"), cur_month.strftime("%Y%m%d"), next_month.strftime("%Y%m%d")
    for num, (key, value) in enumerate(list(value_dict.items())):
        i = num + 7
        logging.info(f"正在生成并校验劳务工退回模板第{num + 1}条数据...")
        if key not in values_103.keys():
            cells(ws, f"B{i}", "103表中没有该人员编号，请核对", RED)
            continue

        # 15.2.1	生成劳务工退回模板
        ws[f"B{i}"] = str(value[0]).replace("None", "")
        ws[f"C{i}"] = str(value[1]).replace("None", "")
        for count, col in {0: "B", 1: "C", 4: "D", 14: "G"}.items():
            ws["%s%s" % (col, str(num + 7))] = value[count]

        # 15.2.2
        ws[f"D{i}"] = str(value[4]).replace("None", "")
        if cel(ws, f"D{i}") not in [cur, nex]:
            cells(ws, f"D{i}", "事件执行日期不为1日！", RED)

        # 15.2.3
        ws[f"I{i}"] = str(value[15]).replace("None", "")

        # 15.3.1
        if values_103[key][0]:
            cells(ws, f"C{i}", "请注意该人员该月已做过事件", RED)

        # 15.3.2
        if values_103[key][1] != "C":
            cells(ws, f"A{i}", "请注意该人员不是C类劳务派遣工", RED)

        # 15.3.3
        if len(values_103_1[key]) == 3 and not values_103_1[key][1]:
            cells(ws, f"H{i}", "不存在需要定界的劳动合同！", BLUE)
        else:
            ws[f"I{i}"] = values_103_1[key][1]
            try:
                tmp_ls = values_103_1[key]
                for x in range(0, len(tmp_ls), 3):
                    if tmp_ls[x] and cel(ws, f"D{i}").isdigit() and int(cel(ws, f"D{i}")) <= int(tmp_ls[x]):
                        cells(ws, f"H{i}", "该人存在未来时间的劳动合同，请与企业确认如何处理！", RED)
            except Exception:
                cells(ws, f"H{i}", "F列事件日期非正确值", RED)

        # 15.3.4
        if ws[f"T{i}"].comment is None:
            if cel(ws, f"D{i}") in [las, cur, nex]:
                ws[f"J{i}"] = (datetime.strptime(cel(ws, f"D{i}"), "%Y%m%d") - timedelta(days=1)).strftime("%Y%m%d")
            elif cel(ws, f"D{i}").isdigit() and int(las) < int(cel(ws, f"D{i}")) <= int(nex[:-2] + "31"):
                ws[f"J{i}"] = cel(ws, f"D{i}")
            else:
                cells(ws, f"J{i}", "劳务工退回RPA只执行上月、当月、次月的事件！", RED)

        # 规则 15.3.5  A-序号
        ws[f"A{i}"] = str(num + 1)
    serial_id = datetime.now().strftime("%Y-%m-%d-%H-%M-%S-%f")
    wb_temp.properties.description = serial_id
    wb_temp.save(FILE_PATH + '/tmp-劳务工.xlsx')
    check_zhrpy280(FILE_PATH + '/tmp-劳务工.xlsx')
    local = create_dir(file, file_str)
    get_grade(f"{os.path.basename(file).split('-')[0][:10]}-XX-XX", value_dict, "劳务工退回", serial_id)
    sr, code, worker = get_info(file, file_str)
    shutil.move(FILE_PATH + "/C23-2离职.xlsx", local + f"/103_劳务工退回_{os.path.basename(file)}")
    shutil.move(FILE_PATH + "/C23-3劳动合同.xlsx", local + f"/103_劳动合同_{os.path.basename(file)}")
    shutil.move(FILE_PATH + '/tmp-劳务工.xlsx', local + f"/{sr}-{code}-劳务工退回-{worker}.xlsx")
