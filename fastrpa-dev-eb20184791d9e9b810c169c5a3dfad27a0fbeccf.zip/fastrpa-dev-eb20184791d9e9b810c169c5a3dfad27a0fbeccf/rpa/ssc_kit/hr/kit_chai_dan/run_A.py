#!/usr/bin/env python
# -*- coding: utf-8 -*-
# @File    : run_A.py
# @Author  : jinjianfeng
# @Contact : 553041800@qq.com
# @Link    : https://github.com/jinjf553
# @software: PyCharm
# @Date    : 2019/7/25 14:06
# @Version : ??
import logging
import os
import time

from openpyxl import load_workbook
from rpa.fastrpa.mail import sendmail
from rpa.public.config import local_path
from rpa.public.get_picture import cai_ji_biao
from rpa.ssc.hr.orm.orm_ope import Insert, Query, Update
from rpa.ssc.hr.orm.tb_hr_gangweibiandong_log import Log
from rpa.ssc_kit.hr.kit_chai_dan.bu_zai_gang import rulebase_9
from rpa.ssc_kit.hr.kit_chai_dan.chong_xin_lu_yong import (check_degree,
                                                           move_file,
                                                           read_caijibiao,
                                                           rulebase_16_2,
                                                           rulebase_16_3,
                                                           rulebase_16_4,
                                                           rulebase_16_5)
from rpa.ssc_kit.hr.kit_chai_dan.er_ji import rulebase_5
from rpa.ssc_kit.hr.kit_chai_dan.gang_wei import rulebase_3
# from rpa.robotA.lao_wu_gong import rulebase_15
from rpa.ssc_kit.hr.kit_chai_dan.lao_wu_gong_dev import rulebase_15
from rpa.ssc_kit.hr.kit_chai_dan.li_gang import rulebase_8
# from rpa.robotA.li_tui_xiu import rulebase_11
from rpa.ssc_kit.hr.kit_chai_dan.li_tui_xiu_dev import rulebase_11
# from rpa.robotA.li_tui_xiu_jian_ce import rulebase_13
# from rpa.robotA.li_zhi import rulebase_14
from rpa.ssc_kit.hr.kit_chai_dan.li_tui_xiu_jian_ce_dev import rulebase_13
from rpa.ssc_kit.hr.kit_chai_dan.li_zhi_dev import rulebase_14
# from rpa.robotA.nei_tui import rulebase_12
from rpa.ssc_kit.hr.kit_chai_dan.nei_tui_dev import rulebase_12
from rpa.ssc_kit.hr.kit_chai_dan.ru_zhi import rulebase_16
from rpa.ssc_kit.hr.kit_chai_dan.rulebase_10 import rulebase_10
from rpa.ssc_kit.hr.kit_chai_dan.upload import upload
from rpa.ssc_kit.hr.kit_chai_dan.zhi_shu import rulebase_6
from rpa.ssc_kit.hr.kit_chai_dan.zhuan_zheng import rulebase_7

# from rpa.ssc_kit.hr.guo_jia_guan_wang.jinjf.chong_lu_tmp import rulebase_16_2_dev


def run_kit_shou_dong_chai_dan(filename, file_str=""):
    wb = load_workbook(filename)
    ws = wb.active
    update_db(filename, ws)
    if "人员调配表单" in str(ws["A2"].value):
        # 人员调配表
        rulebase_3(filename, file_str)
        rulebase_5(filename, file_str)
        rulebase_6(filename, file_str)
        rulebase_7(filename, file_str)
        rulebase_8(filename, file_str)
        rulebase_9(filename, file_str)
    elif "人员离退表单" in str(ws["A2"].value):
        # 人员离退表
        if not rulebase_10(filename):
            return
        rulebase_11(filename, file_str)
        rulebase_12(filename, file_str)
        rulebase_13(filename, file_str)
        rulebase_14(filename, file_str)
        rulebase_15(filename, file_str)
    elif "新员工入职" in str(ws["A1"].value) or "新员工入职" in str(ws["A2"].value):
        # 新员工入职
        cai_ji_biao(filename, file_str)
        rulebase_16(filename, file_str)
        rulebase_16_2(filename, file_str)
        name_dict = read_caijibiao(filename, file_str)
        rulebase_16_3(filename, name_dict)
        rulebase_16_4(filename, name_dict)
        rulebase_16_5(filename, name_dict)
        check_degree(name_dict)
        move_file(filename, file_str)
    else:
        logging.info("企业表单非标准表")
        sendmail(receivers="6886908@qq.com", subject='企业表单错误',
                 body="企业表单中没有“人员调配表单”或“人员离退表单”或“新员工入职”等字样，请检查。 见附件", attachments=filename)


def upload_file(file, file_str):
    local = (local_path + "\\" + file_str) if file_str else (os.path.dirname(file) if file else None)
    if not local:
        return
    sr = file_str[:10] if file_str else os.path.basename(file)[:10]
    Update(sr=sr, remark="待上载", step="拆单完成")
    upload(sr=sr, paths=local)
    end_time = time.strftime("%Y%m%d-%H%M%S", time.localtime(time.time()))
    Update(sr=sr, remark="待转寄", step="上载完成", end_time=end_time)


def update_db(filename, ws):
    lis = os.path.basename(filename).split('-')
    if len(lis) < 4 or not str(lis[0]).isdigit():
        return
    lis = lis[:4]
    sr, code, content, worker, type_ = lis + ["手动拆单"]
    count = str(len([x.value for x in ws["B"] if x.value]) - (3 if "入职" in ws["A1"].value else 4))
    date = time.strftime("%Y%m%d-%H%M%S", time.localtime(time.time()))
    if sr in [res.sr for res in Query(Log)]:
        Update(table=Log, sr=sr, type=type_)
    else:
        Insert(table=Log, sr=sr, code=code, content=content, date=date[:8], people_num=count, worker=worker[:-5] + "X",
               type=type_, start_time=date, mjml="RS_1_1_9" if "入职" in ws["A1"].value else "RS_9_1")


if __name__ == "__main__":
    print(os.path.exists(str(None)))
