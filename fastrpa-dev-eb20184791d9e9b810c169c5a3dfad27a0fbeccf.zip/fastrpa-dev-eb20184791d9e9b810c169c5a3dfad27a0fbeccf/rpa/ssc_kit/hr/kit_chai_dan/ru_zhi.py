#!/usr/bin/env python
# -*- coding: utf-8 -*-
# @File    : ru_zhi.py
# @Author  : jinjianfeng
# @Contact : 553041800@qq.com
# @Link    : https://github.com/jinjf553
# @software: PyCharm
# @Date    : 2020/2/26 9:59
# @Version : ??
import logging
import os
import re
import time
from collections import defaultdict
from datetime import datetime

from id_validator import validator
from openpyxl import load_workbook
from openpyxl.utils import get_column_letter
from rpa.fastrpa.adtable import BLUE, RED
from rpa.public.all_party_up import str_to_date
from rpa.public.config import FILE_PATH, local_path, templates
from rpa.public.tools import cel, cells
from rpa.ssc.hr.orm.orm_ope import Query
from rpa.ssc.hr.orm.td_hr_gang_wei_diao_pei_rulebase import Event
from rpa.ssc_kit.hr.kit_chai_dan.check_280 import get_grade
from rpa.ssc_kit.hr.kit_chai_dan.sap import rz_export_109
from xpinyin import Pinyin


def rulebase_16(filename, file_str):
    cjb_path = local_path + "/" + file_str + '/采集表' if file_str else os.path.dirname(filename) + '/采集表'

    # 信息表采集表格式校验161
    rulebase_161(filename, cjb_path)
    # rulebase_162(filename)
    rulebase_163(filename, cjb_path, file_str)
    rulebase_164()


def rulebase_161(filename, cjb_path):
    wb = load_workbook(filename)
    ws = wb.active

    ws_st = load_workbook(os.path.join(templates, "入职信息表-标准表.xlsx")).active
    flag1 = not (cel(ws, "A1") == cel(ws_st, "A1") or cel(ws, "A2") == cel(ws_st, "A1"))
    logging.info(f"开始校验入职信息表《{os.path.basename(filename)}》的格式...")
    for i in range(4, 9):  # 检查1及4--8行的列名是否与标准表单一致
        for j in range(1, len(ws['A%s:AC%s' % (i, i)][0]) + 1):
            flag = ''.join(cel(ws, (i, j)).split()) != ''.join(cel(ws_st, (i, j)).split())
            if flag or flag1:
                cells(ws, "A8", "非标准表单", RED)
                logging.info(f"    入职信息表非标准表，不同行列为:({i},{j})；继续《ruzhi_47》")
                wb.save(filename)

    # 采集表格式校验13.1
    if os.path.exists(cjb_path):
        wb_st = load_workbook(os.path.join(templates, "采集表-标准表.xlsx"))
        ws_st = wb_st.active
        for cjb in os.listdir(cjb_path):
            logging.info(f"开始校验采集表《{cjb}》的格式...")
            try:
                wb_cjb_fc = load_workbook(cjb_path + '/' + cjb)
            except Exception:
                logging.info(f"    采集表《{cjb}》格式损坏，继续《ruzhi_59》")
                continue
            ws_cjb = wb_cjb_fc.active
            b_v = [''.join(str(x.value).split()) for x in ws_cjb["B"]]
            flag = [cel(ws_cjb, "A1") != cel(ws_st, "A1"), cel(ws_cjb, "U10") != cel(ws_st, "U10")]
            wb_cjb_fc.close()
            if not {"称谓", "起止年月", "起始时间"}.issubset(b_v) or any(flag):
                if not os.path.exists(cjb_path + "/非标准表_" + cjb):
                    os.rename(cjb_path + '/' + cjb, cjb_path + "/非标准表_" + cjb)
                logging.info(f"    采集表《{cjb}》非标准表，继续《ruzhi_68》")
        wb_st.close()


# 检查表内容
def rulebase_162(filename):
    # 13.2.1 检查信息表中有码表的是否按码表填写
    # D I-M O P Q R S
    logging.info("提取码表库码值")
    results = Query(Event)
    rule_bn = [res.db_BN for res in results if res.db_BN]  # 员工来源
    rule_da = [res.db_DA for res in results if res.db_DA]  # 所属专业类别
    rule_db = [res.db_DB for res in results if res.db_DB]  # 所属专业名称
    rule_dc = [res.db_DC for res in results if res.db_DC]  # 所属工种类别
    rule_dd = [res.db_DD for res in results if res.db_DD]  # 所属工种名称
    rule_de = [res.db_DE for res in results if res.db_DE]  # 所属薪酬标杆岗位类别
    rule_ac = [res.db_AC for res in results if res.db_AC]  # 人员组
    rule_ad = [res.db_AD for res in results if res.db_AD]  # 人员子组
    rule_ag = [res.db_AG for res in results if res.db_AG]  # 工资核算范围
    rule_w = [res.db_W for res in results if res.db_W]  # 职位层级
    rule_s = ["否", "X 是"]  # 企业统计标识
    rule_bq = [res.db_BQ for res in results if res.db_BQ]  # 总部统计唯一标识
    rule_f = [res.db_F for res in results if res.db_F]  # 企业自定义分类1
    rule_g = [res.db_G for res in results if res.db_G]  # 企业自定义分类2
    rule_h = [res.db_H for res in results if res.db_H]  # 企业自定义分类3
    rule_cz = [res.db_CZ for res in results if res.db_CZ]  # 其他用工来源
    rule_df = [res.db_DF for res in results if res.db_DF]  # 劳务派遣单位代码
    rule_dg = [res.db_DG for res in results if res.db_DG]  # 劳务派遣单位类别
    rule_uvw = {res.db_U: (res.db_V, res.db_W) for res in results if res.db_U}  # 职位级别, 职位序列，职位层级

    wb = load_workbook(filename)
    ws = wb.active
    logging.info("开始校验信息表中码值项")
    for col, v in {'D': rule_bn, 'I': rule_da, 'J': rule_db, 'K': rule_dc, 'L': rule_dd, 'M': rule_de, 'O': rule_ac,
                   'P': rule_ad, 'Q': rule_ag, 'R': rule_w, 'S': rule_s, 'T': rule_bq, 'U': rule_f, "V": rule_g,
                   'W': rule_h, 'X': rule_cz, 'Y': rule_df, 'AA': rule_dg}.items():
        col_D = [str(i.value).replace("None", "").strip() for i in ws[col][8:]]
        for i, cd in enumerate(col_D):
            if cd and cd not in v:
                cells(ws, f"{col}{i + 9}", "单元格数据不是码值", RED)

    # 13.2.2 检验信息表中必填项内容不为空
    # 检验【信息表B、C、D、E、F、O、P、Q、R、S、T等列】的值是否不为空。
    logging.info("开始校验信息表中必填项")
    for col in ['B', 'C', 'E', 'F', 'O', 'P', 'Q', 'R', 'S', 'T']:
        col_X = [i.value for i in ws['%s' % col]][8:]
        for k, cx in enumerate(col_X):
            if not cx and ws[f'B{k + 9}'].value:
                cells(ws, f"{col}{k + 9}", "此单元格是必填项", RED)

    # 13.2.3 检验信息表【B】列姓名是否有重名
    # 检验信息表【B】列姓名有无重名
    logging.info("开始校验信息表中是否有重名")
    col_B = [i.value for i in ws['B']][8:]
    for k, cb in enumerate(col_B):
        temp_col_B = col_B[:k] + col_B[k + 1:]
        if cb in temp_col_B:
            cells(ws, f"{col}{k + 9}", "请检查人员姓名重复", RED)

    # 13.2.4 检验信息表【C】列数值符合要求
    # 检验信息表【C】列入职时间是否为本月1日或下月1日
    logging.info("开始校验信息表中入职时间")
    col_dates = [str(i.value).strip() for i in ws['C'][8:]]
    months = [time.strftime("%m"), str((int(time.strftime("%m")) + 1) % 12)]
    for k, cd in enumerate(col_dates):
        if len(cd) != 8 or not cd.isdigit():
            cells(ws, f"C{k + 9}", "请核查此数值是否为有效入职时间", RED)
        elif cd[6:8] != '01' or cd[4:6] not in months:
            cells(ws, f"C{k + 9}", "请核查此数值是否为有效入职时间", RED)

    # 13.2.5 检验信息表岗位信息符合要求
    # 检验信息表中【G】列、【H】列、【IJ、KL】列三者之一必有数据
    logging.info("开始校验岗位信息是否符合要求")
    for i in range(8, len(ws["B"])):
        if not (cel(ws, f"G{i}") or cel(ws, f"H{i}") or (cel(ws, f"I{i}") and cel(ws, f"J{i}")) or
                (cel(ws, f"K{i}") and cel(ws, f"L{i}"))):
            cells(ws, f"G{i}", "无参照岗位分类信息", RED)

    # 13.2.6 检验信息表中人员子组、职位序列、层级和薪酬标杆类别符合逻辑
    # "参照”调配码表库“中[U-W列]的对应关系:
    # 人员子组12-13对应 1管理序列 薪酬标杆首位为1 职位层级为管理序列层次和级别
    # 人员子组15对应 2专业技术序列 薪酬标杆首位为2 职位层级为技术序列层次和级别
    # 人员子组16-17对应 3技操作序列 薪酬标杆首位为3或4 职位层级为操作序列层次和级别"
    col_R = [str(i.value).replace("None", "").strip() for i in ws['R']][8:]  # 职位层级序列
    col_P = [str(i.value).replace("None", "").strip() for i in ws['P']][8:]  # 人员子组
    col_M = [str(i.value).replace("None", "").strip() for i in ws['M']][8:]  # 薪酬标杆岗位类别

    for k, cr in enumerate(col_R):
        # 信息表中‘R’存在于调配码表库中的U，且对应调配码表库中的V值与信息表P值对应
        # 如果信息表M列不空，内容
        if not col_M[k]:
            cells(ws, f"R{k + 9}", "请检查人员子组和职位序列信息", RED)
            continue
        bool_M = col_M[k][0] != (rule_uvw[cr][0][0] if rule_uvw[cr][0][0] != "4" else "3")
        if cr not in rule_uvw.keys() or col_P[k] not in rule_uvw[cr][0] or bool_M:
            cells(ws, f"R{k + 9}", "请检查人员子组和职位序列信息", RED)


# 生成入职模板
def rulebase_163(file, cjb_path, file_str):
    wb = load_workbook(file)
    ws = wb.active
    value_dict = defaultdict(dict)
    v5 = True if "重新录用" in cel(ws, f"E{4}") else False
    for i in range(9, len(ws["B"]) + 1):
        c_v = cel(ws, f"E{i}") if "重新录用" in cel(ws, f"E{4}") else cel(ws, f"AB{i}")
        if ws[f"B{i}"].value and not c_v:
            x = ws[f"A{i}:AC{i}"][0]
            value_dict[cel(ws, f"B{i}")] = {get_column_letter(x.index(j) + 1): j.value for j in x}
    wb.close()

    logging.info("提取码表库的码值")
    rule_cd = [str(res.db_CD).strip() for res in Query(Event) if res.db_CD]  # 增减类别
    rule_uvw = {str(res.db_U).strip(): [res.db_V, res.db_W] for res in Query(Event) if res.db_U}  # U, V, W
    rule_hi = {str(res.db_J).strip(): str(res.db_K).strip() for res in Query(Event) if res.db_J}

    logging.info("提取采集表各项信息")
    cjb_dict = defaultdict(dict)
    tmp_dict = {"出生日期": "C4", "性别": "H2", "国籍": "H3", "婚姻状况": "N5", "籍贯-省": "M2", "籍贯-市": "O2",
                "籍贯-县": "Q2", "出生地-省": "M3", "出生地-市": "O3", "出生地-县": "Q3", "民族": "C3", "户口性质": "T7",
                "户口所在地-省": "O8", "户口所在地-市": "Q8", "户口所在地-县": "T8", "健康状况": "P4", "个人身份": "P9",
                "企业员工编号": "U9", "身份证号": "N7", "参加工作时间": "C5", "核定工龄起算日期": "C6",
                "进入本系统工作时间": "I6", "进入本单位工作日期": "N6", "家庭地址": "C31", "移动电话": "C32",
                "政治面貌": "I4", "政治面貌时间": "I5", "外语语种": "C9", "外语语种及等级": "L9", "专业技术资格": "C7",
                "技术资格时间": "C8", "进入加油站工作时间": "R6", "职业资格": "I7", "职业资格取得时间": "I8"}
    for cjb_file in os.listdir(cjb_path):
        logging.info(f"    提取采集表《{cjb_file}》的信息...")
        cjb_wb = load_workbook(os.path.join(cjb_path, cjb_file))
        cjb_ws = cjb_wb.active
        for k, v in tmp_dict.items():
            cjb_dict[cjb_file[:-5]].update({k: cel(cjb_ws, v)})

    wb = load_workbook(os.path.join(templates, "ZBI0005入职.xlsx"))
    ws = wb.active
    logging.info("开始生成并校验入职模板数据...")
    # 入职模板与信息表数据对应关系字典   #todo 20210412增加 CU劳务派遣单位代码 CV劳务派遣单位名称 CW劳务派遣单位类别提取
    dic = {"C": "C", "D": "D", "H": "O", "I": "P", "K": "Q", "N": "U", "P": "S", "Q": "T", "T": "R", "U": "F",
           "BG": "C", "BV": "E", "CE": "V", "CF": "W", "CM": "E", "CN": "I", "CO": "J", "CP": "K", "CQ": "L",
           "CR": "M", "CT": "X", "CU": "Y", "CV": "Z", "CW": "AA"}
    for num, (key, value) in enumerate(list(value_dict.items())):
        logging.info(f"    正在生成第{num + 1}条数据...")
        if v5:
            value["E"], value["F"] = value["F"], value["G"]
        ws[f"A{num + 7}"] = num + 1
        # 信息表【B】列姓名填入入职模板的【B】列-人员姓名
        # 信息表【C】列入职时间填入入职模板【C】列-入职时间
        # 信息表【D】列员工来源填入入职模板的【D】列-入职原因
        # 信息表【O】列人员组填入入职模板的【H】列-人员组
        # 信息表【P】列人员子组填入入职模板【I】列-人员子组
        # 信息表【Q】列工资核算范围填入入职模板【K】列-工资核算范围
        # "信息表【U】列企业自定义分类1填入入职模板的【N】列-企业自定义分类
        # 信息表【S】列企业统计标识填入入职模板【P】列 - 企业统计标识
        # 信息表【T】列总部统计唯一标识填入入职模板的【Q】列 - 总部统计唯一标识"
        # 信息表【R】列职位层级序列填入入职模板【T】列 - 职位级别
        # 信息表【F】列岗位名称填入入职模板的【U】列 - 职位名称"
        # 将【C】列数据填入入职模板【BG】列-身份证生效日期
        # 信息表【E】列机构名称填入入职模板【BV】列 - 调入（出）部门
        # 信息表【V】列自定义分类2填入入职模板【CE】列
        # 信息表【W】列自定义分类3填入入职模板【CF】列
        # "信息表【E】列机构名称  填入入职模板【CM】列
        # 信息表【I - M】所属专业类别、所属专业名称、所属工种类别、所属工种名称、薪酬标杆类别
        # 分别填入入职模板【CN - CR】列（炼化企业用）
        # 信息表【X】列数据填入入职模板【CT】列 - 其他用工形式
        ws[f"B{num + 7}"] = str(value["B"]).strip().replace(" ", "").replace("None", "")
        for col, i in dic.items():
            ws[f"{col}{num + 7}"] = str(value[i]).strip().replace("None", "")

        # 将"99991231"填入入职模板【BH】列 - 身份证截止日期
        # 将"人员入职"填入入职模板【BZ】列 - 人员增减变动备注
        ws[f"BH{num + 7}"] = "99991231"
        ws[f"BZ{num + 7}"] = "人员入职"

        # "根据信息表【D】列员工来源模糊匹配调配码表库【CD】列数据填入入职模板【BU】列-增减类别
        if [x for x in rule_cd if str(value["D"]).strip()[3:] in x]:
            zjlb = [x for x in rule_cd if str(value["D"]).strip()[3:] in x][0]
        elif len(str(value["D"]).strip()[3:]) > 7 and [x for x in rule_cd if str(value["D"])[6:].strip() in x]:
            zjlb = [x for x in rule_cd if str(value["D"])[6:].strip() in x][0]
        else:
            zjlb = "19000 其他增员"
        ws[f"BU{num + 7}"] = zjlb

        # "根据信息表【R】列职位层级序列匹配调配码表库【U-W】列【V】列填入入职模板【R】列-职位序列
        # 根据信息表【R】列职位层级序列匹配调配码表库【U - W】列【W】列填入入职模板【S】列 - 职位层次
        if value["R"] and str(value["R"]).strip() in rule_uvw.keys():
            ws[f"R{num + 7}"] = str(rule_uvw[str(value["R"]).strip()][0]).strip().replace("None", "")
            ws[f"S{num + 7}"] = str(rule_uvw[str(value["R"]).strip()][1]).strip().replace("None", "")

        # "提取对应人员采集表【C4】数据填入入职模板【AJ】列-出生日期
        # 提取对应人员采集表【H3】数据填入入职模板【AN】列 - 国籍"
        # "提取对应人员采集表【N5】数据填入入职模板【AO】列-婚姻状况
        # 提取对应人员采集表【M2】数据填入入职模板【AP】列 - 籍贯 - 省
        # 提取对应人员采集表【O2】数据填入入职模板【AQ】列 - 籍贯 - 地
        # 提取对应人员采集表【Q2】数据填入入职模板【AR】列 - 籍贯 - 县
        # "提取对应人员采集表【M3】数据填入入职模板【AS】列-出生地-省
        # 提取对应人员采集表【O3】数据填入入职模板【AT】列 - 出生地 - 地
        # 提取对应人员采集表【Q3】数据填入入职模板【AU】列 - 出生地 - 县
        # "提取对应人员采集表【C3】数据填入入职模板【AV】列-民族
        # 提取对应人员采集表【T7】数据填入入职模板【AX】列 - 户口性质
        # 提取对应人员采集表【P4】数据填入入职模板【AZ】列 - 健康状况
        # "提取对应人员采集表【P9】数据填入入职模板【BA】列-个人身份
        # 提取对应人员采集表【U9】数据填入入职模板【BD】列 - 企业员工编号
        # 提取对应人员采集表【N7】数据填入入职模板【BF】列 - 身份证号
        # 提取对应人员采集表【C5】数据填入入职模板【BI】列 - 参加工作时间
        # 提取对应人员采集表【C6】数据填入入职模板【BJ】列 - 核定工龄起算日期
        # "提取对应人员采集表【I6】数据填入入职模板【BK】列-进入本系统工作时间
        # 提取对应人员采集表【N6】数据填入入职模板【BL】列 - 进入本单位工作日期
        # 提取对应人员采集表【C31】数据填入入职模板【BO】列 - 家庭地址
        # 提取对应人员采集表【C32】数据填入入职模板【BS】列 - 移动电话
        # "提取对应人员采集表【I4】数据填入入职模板【CG】列-政治面貌
        # 提取对应人员采集表【I5】数据填入入职模板【CH列 - 政治面貌时间
        # 提取对应人员采集表【C9】数据填入入职模板【CI列 - 外语语种
        # 提取对应人员采集表【L9】数据填入入职模板【CJ】列 - 外语种类及等级
        # "提取对应人员采集表【C7】数据填入入职模板【CK】列-专业技术资格
        # 提取对应人员采集表【C8】数据填入入职模板【CL】列 - 技术资格时间
        # 提取对应人员采集表【R6】数据填入入职模板【CS】列 - 进入加油站工作时间
        if key in cjb_dict.keys():
            for k, v in {"AJ": "出生日期", "AN": "国籍", "AO": "婚姻状况", "AP": "籍贯-省", "AQ": "籍贯-市",
                         "AR": "籍贯-县", "AS": "出生地-省", "AT": "出生地-市", "AU": "出生地-县", "AV": "民族",
                         "AX": "户口性质", "AZ": "健康状况", "BA": "个人身份", "BD": "企业员工编号", "BF": "身份证号",
                         "BI": "参加工作时间", "BJ": "核定工龄起算日期", "BK": "进入本系统工作时间",
                         "BL": "进入本单位工作日期", "BO": "家庭地址", "BS": "移动电话", "CG": "政治面貌",
                         "CH": "政治面貌时间", "CI": "外语语种", "CJ": "外语语种及等级", "CK": "专业技术资格",
                         "CL": "技术资格时间", "CS": "进入加油站工作时间", "CY": "职业资格", "CZ": "职业资格取得时间",
                         "DA": "户口所在地-省", "DB": "户口所在地-市", "DC": "户口所在地-县"}.items():
                ws[f"{k}{num + 7}"] = cjb_dict[key][v]

            for k, v in {"AP": ["籍贯-省", "BT"], "AQ": ["籍贯-市", "BU"], "AR": ["籍贯-县", "BV"],
                         "AS": ["出生地-省", "BT"], "AT": ["出生地-市", "BU"],
                         "AU": ["出生地-县", "BV"]}.items():
                s1, s2 = cjb_dict[key][v[0]], f"_.db_{v[1]}"
                li = [eval(s2) for _ in Query(Event) if len(s1) > 2 and eval(s2) and s1 in eval(s2)] + [s1]
                ws[f"{k}{num + 7}"] = li[0]
            # 需处理列
            ws[f"D{num + 7}"] = cel(ws, f"D{num + 7}").replace("新入职-", "")
            ws[f"CG{num + 7}"] = " ".join(cel(ws, f"CG{num + 7}").strip().split())
            ws[f"CI{num + 7}"] = " ".join(cel(ws, f"CI{num + 7}").strip().split())

            # 提取对应人员采集表【H2】数据填入入职模板【AM】列 - 性别
            ws[f"AM{num + 7}"] = '1 男 ' if "男" in cjb_dict[key]["性别"] else '2 女 '
            # 提取对应人员采集表【O8、Q8、T8】数据合并填入入职模板【AY】列 - un_path（加分隔符方便手工填写）
            li = [str(cjb_dict[key][f'户口所在地-{x}']) for x in ["省", "市", "县"]]
            ws[f"AY{num + 7}"] = "".join(re.findall(r"([\u4E00-\u9FA5])", "".join(li)))
        else:
            cells(ws, f"A{num + 7}", "采集表不存在或者存在问题", RED)

        # 根据信息表中【B】列人员姓名转换填写入职模板【AL】列 - 姓名简拼
        ws[f"AL{num + 7}"] = Pinyin().get_initials(cel(ws, f"B{num + 7}"), '').upper()

        # 校验H-人员组与I-人员子组是否对应
        if cel(ws, f"H{num + 7}") in rule_hi.keys():
            if cel(ws, f"I{num + 7}")[:2] not in rule_hi[cel(ws, f"H{num + 7}")]:
                cells(ws, f"H{num + 7}", f"该人员组对应的人员子组只能在以下范围：{rule_hi[cel(ws, f'H{num + 7}')]}", RED)
        else:
            cells(ws, f"H{num + 7}", f"码表库中没有该人员组", RED)

    logging.info("入职模板生成完毕，文件名为tmp-新入职.xlsx")
    serial_id = datetime.now().strftime("%Y-%m-%d-%H-%M-%S-%f")
    wb.properties.description = serial_id
    wb.save(os.path.join(FILE_PATH, "tmp-新入职.xlsx"))
    file_str = file_str if file_str else os.path.basename(file)
    get_grade(f"{file_str.split('-')[0][:10]}-XX-XX", value_dict, "零星入职", serial_id)


def rulebase_164():
    logging.info("开始校验入职模板的数据...")
    if not os.path.exists(os.path.join(FILE_PATH, "tmp-新入职.xlsx")):
        raise Exception("新员工入职模板未生成。")
    filename = os.path.join(FILE_PATH, "tmp-新入职.xlsx")
    wb = load_workbook(filename)
    ws = wb.active
    # 导出109
    IDs = [str(i.value).replace("None", "") for i in ws['BF'][6:]]
    if rz_export_109(IDs):
        logging.info("系统中没有信息表中身份证号")
        ws_109 = []
    else:
        wb_109 = load_workbook(os.path.join(FILE_PATH, "rz_tmp-109逻辑查询表.xlsx")).active
        ws_109 = [str(x.value).strip() for x in wb_109["I"] if x.value]

    logging.info("提取码表库码表值")
    tdt = {4: "BN", 6: "AS", 7: "E", 8: "J", 9: "L", 10: "BO", 11: "AG", 12: "BP", 13: "Y", 14: "F", 15: "AH", 16: "R",
           17: "BQ", 18: "V", 19: "W", 20: "U", 22: "R", 23: "V", 24: "W", 25: "U", 28: "R", 29: "R", 30: "R",
           31: "R", 33: "CV", 34: "R", 35: "R", 39: "BR", 40: "CN", 41: "BS", 42: "BT", 43: "BU",
           44: "BV", 45: "BT", 46: "BU", 47: "BV", 48: "BW", 49: "BX", 50: "BY", 52: "BZ", 53: "CA", 54: "CB",
           55: "CC", 57: "R", 73: "CD", 75: "CE", 77: "BY", 82: "G", 83: "H", 85: "CV", 87: "CW", 89: "CY", 98: "CZ",
           99: "DF", 101: "DG", 105: "BT", 106: "BU", 107: "BV"}
    rule_dict = defaultdict(list)
    for _ in Query(Event):
        for k, v in tdt.items():
            if eval("_.db_" + v):
                rule_dict[k].append(eval("_.db_" + v).replace(" ", ""))
    rule_uvw = {res.db_U: (res.db_V, res.db_W) for res in Query(Event) if res.db_U}  # 职位级别, 职位序列，职位层级

    cols = [get_column_letter(i + 1) for i, x in enumerate(ws[3]) if "X" in str(x.value)]
    for i in range(7, len(ws["A"]) + 1):
        if not ws[f"A{i}"].value or not ws[f"B{i}"].value or ws[f"CA{i}"].value:
            logging.info(f"   入职模板单元格A{i}或B{i}为空或者CA{i}不为空，跳过此行数据校验...")
            continue
        # 校验为必填项的单元格是否为空，空则标记（3行X标记）
        for col in cols:
            if not ws[f"{col}{i}"].value:
                cells(ws, f"{col}{i}", "必填项不应为空", RED)

        # 码表与调配码表库不匹配，单元格填充红色并插入批注“请检查码表数值！”
        for key, value in rule_dict.items():
            if not ws[f"{get_column_letter(key)}{i}"].value:
                continue
            if cel(ws, f"{get_column_letter(key)}{i}").replace(" ", "") not in value:
                cells(ws, f"{get_column_letter(key)}{i}", "请检查码表数值", BLUE if key == 99 else RED)

        # 填充为日期的单元格数据是否为标准日期格式
        for date_col in ['C', 'AJ', 'BG', 'BH', 'BI', 'BJ', 'BK', 'BL', 'BM', 'BN', 'CH', 'CL', 'CS', 'CZ']:
            date = cel(ws, f"{date_col}{i}")[:8]
            if not date:
                continue
            d, c = str_to_date(date), None
            if date_col == 'C':
                c = d
            if not isinstance(d, datetime):
                cells(ws, f"{date_col}{i}", "异常日期值", RED)
            elif isinstance(c, datetime):
                if date_col in ['BI', 'BJ', 'BK', 'BL', 'BM', 'BN']:
                    if (d - c).days > 15:
                        cells(ws, f"{date_col}{i}", "特殊日期和入职时间逻辑错误", RED)
                elif date_col != 'BH' and (d - c).days > 0:
                    cells(ws, f"{date_col}{i}", "日期晚于入职时间", RED)

        # B列姓名是有重名，单元格填充红色并插入批注“请检查人员姓名重复！”
        if ws[f"B{i}"].value and ws[f"B{i}"].value in [j.value for j in ws['B'][i:]]:
            cells(ws, f"B{i}", "请检查人员姓名重复", RED)

        # C列入职时间不为本月一日或下月一日，单元格填充红色并插入批注“请核实入职时间！”
        months = [int(time.strftime("%m01")), int(str(int(time.strftime("%m")) % 12 + 1) + "01")]
        if cel(ws, f"C{i}").isdigit() and int(cel(ws, f"C{i}")[4:8]) not in months:
            cells(ws, f"C{i}", "请核实入职时间", RED)

        # "如入职模板【S】列是中层管理或小于40，【G】列单元格填充红色并插入批注“请检查中层人员（专家）的人事子范围！”
        s_v = cel(ws, f"S{i}")
        if s_v and ('中层管理' in s_v or (s_v[:2].isdigit() and int(s_v[:2]) < 40)):
            cells(ws, f"G{i}", "请检查中层人员（专家）的人事子范围", RED)

        # 上述规则改--> : R 为管（1）且 S<40  或者  R为2且T为‘专家’，
        # G列单元格填充红色并插入批注“请检查中层人员（专家）的人事子范围！”
        if not ws[f"R{i}"].value or not ws[f"S{i}"].value or not ws[f"T{i}"].value:
            cells(ws, f"G{i}", "R、S、T列中有空值项", RED)
        elif (cel(ws, f"R{i}")[0] == "1" and cel(ws, f"S{i}")[:2].isdigit() and int(cel(ws, f"S{i}")[:2]) < 40) or (
                cel(ws, f"R{i}")[0] == '2' and '专家' in cel(ws, f"T{i}")):
            cells(ws, f"G{i}", "请检查中层人员（专家）的人事子范围", RED)

        # 如【J】列数据为空，将该行【J】列单元格填充红色并插入批注“请检查业务范围”
        # 如【M】列数据为空，将该行【M】列单元格填充红色并插入批注“销售企业请检查工作合同”"
        # 增减类别
        # "如政治面貌为空，在【CG】列单元格填充红色并插入批注“政治面貌不能为空！”
        tmp_dict = {"J": "请检查业务范围", "M": "销售企业请检查工作合同", "BU": "增加类别为空", "CG": "政治面貌不能为空"}
        for cell, comment in tmp_dict.items():
            if not ws[f"{cell}{i}"].value:
                cells(ws, f"{cell}{i}", comment, RED)

        # 如入职模板【S】列为30中层管理或【T】列含专家的人员，
        # 在【O】列单元格填充红色并插入批注“请注意检查中层人员（专家）的总额控制范围！”
        if ws[f"T{i}"].value and (cel(ws, f"S{i}") == '30 中层管理' or '专家' in ws[f"T{i}"].value):
            cells(ws, f"O{i}", '请注意检查中层人员（专家）的总额控制范围', RED)

        # "人员子组、职位序列、薪酬标杆和职位层级有逻辑错误（13.2.6），
        # 【R】列单元格填充红色并插入批注“请核实人员子组、职位层级、薪酬标杆之间逻辑关系！”
        if cel(ws, f"T{i}") in rule_uvw.keys():
            tmp_dic = {"1": ["12", "13", "14"], "2": ["15"], "3": ["16", "17"]}
            if cel(ws, f"R{i}")[0] in tmp_dic.keys() and cel(ws, f"I{i}")[:2] not in tmp_dic[cel(ws, f"R{i}")[0]]:
                cells(ws, f"R{i}", '请核实人员子组、职位层级、薪酬标杆之间逻辑关系！', RED)
        else:
            cells(ws, f"R{i}", '请核实人员子组、职位层级、薪酬标杆之间逻辑关系！', RED)

        # 如入职模板【U】列职位名称长度大于20，【U】列单元格填充红色并插入批注“职位名称字段超长（≤20）！”；"
        if ws[f"U{i}"].value and len(str(ws[f"U{i}"].value)) > 20:
            cells(ws, f"U{i}", '职位名称字段超长（≤20）！', RED)

        # 来往单位名称
        if ws[f"BW{i}"].value and len(str(ws[f"BW{i}"].value)) > 12:
            cells(ws, f"BW{i}", '来往单位名称字段超长（≤12）！', RED)

        # 籍贯详细至区县如为空，单元格填充红色并插入批注“籍贯请详写至区县！”
        for k, v in {"AP": ["AR", "籍贯"], "AS": ["AU", "出生地"]}.items():
            if ws[f"{k}{i}"].value and not ws[f"{v[0]}{i}"].value:
                cells(ws, f"{v[0]}{i}", f'{v[1]}请详写至区县', RED)

        # "身份证号码合规有效，如不符合，单元格填充红色并插入批注“请核实身份证号！”
        # if not cel(ws, f"BF{i}") or len(cel(ws, f"BF{i}")) != 18 or not cel(ws, f"BF{i}")[:17].isdigit():
        if validator.get_info(cel(ws, f"BF{i}")) is False:
            cells(ws, f"BF{i}", '请核实身份证号', RED)

        # 身份证号出生日期与入职模板【AJ】出生日期不同,
        # 在【AJ】列单元格填充红色并插入批注“出生日期与身份证日期不一致, 请注意检查！”
        if cel(ws, f"BF{i}")[6:14] != cel(ws, f"AJ{i}"):
            cells(ws, f"AJ{i}", '出生日期与身份证日期不一致, 请注意检查！', RED)

        # 根据身份证号判断性别与【AM】性别不一致, 在【AM】列单元格填充红色并插入批注“性别与身份证号不匹配, 请注意检查！”"
        bf_v = cel(ws, f"BF{i}")[-2:-1]
        if not bf_v.isdigit() or set({int(bf_v) % 2: cel(ws, f"AM{i}")}.items()).issubset({1: "男", 0: "女"}):
            cells(ws, f"AM{i}", '性别与身份证号不匹配, 请注意检查！', RED)

        # 参加工作时间与出生日期比较，如小于18，在【BI】列单元格填充红色并插入批注“参加工作年龄小于18岁, 请注意检查”！
        aj, bi = cel(ws, f"AI{i}"), cel(ws, f"BI{i}")
        if aj and bi and aj[:4].isdigit() and bi[:4].isdigit() and int(bi[:4]) - int(aj[:4]) < 18:
            cells(ws, f"BI{i}", '参加工作年龄小于18岁, 请注意检查', RED)

        # 如政治面貌不为空，政治面貌时间为空在【CH】列单元格填充红色并插入批注“请填写政治面貌时间！”
        if ws[f"CG{i}"].value and not ws[f"CH{i}"].value:
            cells(ws, f"CH{i}", '请填写政治面貌时间', RED)

        # 如入职模板【CJ】列外语种类及等级中含“四级、六级或专业八级”字符，
        # 【CI列】单元格填充红色并插入批注“请注意填写外语等级！”
        if any(x in cel(ws, f"CJ{i}") for x in ['四级', '六级', '专业八级']):
            cells(ws, f"CI{i}", '请注意填写外语等级', RED)

        # 根据身份证号从SAP组合逻辑查询中导出人员编号、姓名、人员组和岗位状态,
        # 如有记录且人员组不为“减册人员”，【BF】列单元格填充红色并插入批注“系统中已有此身份证号,请核实！”
        if str(ws[f"BF{i}"].value).strip() in ws_109:
            cells(ws, f"BF{i}", '系统中已有此身份证号,请核实！', RED)

        for x, y in {"CK": "请核实专业技术资格", "CY": "请核实职业资格"}.items():
            if ws[f"{x}{i}"].value:
                cells(ws, f"{x}{i}", y, RED)

        # H列人员组为【A、B、H、I、W】且Q列总部统计标识不为10，红色提示'请检查总部统计标识'，如为【C及其他】,蓝色提示'请核实总部统计标识'！”
        if cel(ws, f"H{i}")[:1] in ['A', 'B', 'H', 'I', 'W'] and cel(ws, f"Q{i}")[:2] != '10':
            cells(ws, f"Q{i}", '请检查总部统计标识！', RED)
        elif cel(ws, f"H{i}")[:1] == 'C' and cel(ws, f"Q{i}")[:2] != '10':
            cells(ws, f"Q{i}", '请核实总部统计标识！', BLUE)

    wb.save(filename)
    logging.info('入职模板数据检查完毕')
