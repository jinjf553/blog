#!/usr/bin/env python
# -*- coding: utf-8 -*-
# @File    : rulebase_10.py
# @Author  : jinjianfeng
# @Contact : 553041800@qq.com
# @Link    : https://github.com/jinjf553
# @software: PyCharm
# @Date    : 2019/6/15 11:22
# @Version : ??
import logging
import os

from openpyxl import load_workbook
from rpa.fastrpa.adtable import RED, YELLOW
from rpa.public.config import templates
from rpa.public.tools import cells
from rpa.ssc.hr.orm.orm_ope import Query
from rpa.ssc.hr.orm.td_hr_li_tui_code_rulebase import LiTui


def rulebase_10(file):
    wb = load_workbook(file)
    ws = wb.active
    wb_st = load_workbook(os.path.join(templates, "人员离退标准表.xlsx"))
    ws_st = wb_st.active
    # 规则 10.1.1  检验“人员离退表”的是否为标准表单
    flag = True
    for i in range(1, len(ws["A3:O3"][0]) + 1):
        if ws["A6"].value != ws_st["A6"].value or ws.cell(row=3, column=i).value != ws_st.cell(row=3, column=i).value:
            logging.info("人员离退表非标准表单")
            cells(ws, "A1", "非V5版本标准表单", YELLOW)
            wb.save(file)
            flag = False
            break

    rule_A = [str(res.db_A).strip() for res in Query(LiTui) if res.db_A]
    # 规则 10.1.2 & 10.1.3
    for i in range(7, len(ws["B"]) + 1):
        # 规则 10.1.2  检验“人员离退表”的“事件类型”是否为空
        if ws["B%s" % str(i)].value and ws["D%s" % str(i)].value is None:
            cells(ws, "D%s" % str(i), "事件类型为空", RED)
        # 规则 10.1.3  检验“人员离退表”的“事件类型”是否为码值
        if ws["D%s" % str(i)].value and str(ws["D%s" % str(i)].value).replace(' ', '') not in rule_A:
            cells(ws, "D%s" % str(i), "事件类型不是码值", RED)
    wb.save(file)
    return flag
