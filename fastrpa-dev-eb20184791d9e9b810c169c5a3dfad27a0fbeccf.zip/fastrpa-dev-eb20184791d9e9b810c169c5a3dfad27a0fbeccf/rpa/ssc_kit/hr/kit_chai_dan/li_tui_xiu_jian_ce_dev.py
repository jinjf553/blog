#!/usr/bin/env python
# -*- coding: utf-8 -*-
# @File    : li_tui_xiu_jian_ce.py
# @Author  : jinjianfeng
# @Contact : 553041800@qq.com
# @Link    : https://github.com/jinjf553
# @software: PyCharm
# @Date    : 2019/6/19 1:48
# @Version : ??
import logging
import os
import shutil
import time
from collections import defaultdict
from datetime import datetime

from openpyxl import load_workbook
from rpa.fastrpa.adtable import RED
from rpa.public.config import FILE_PATH, templates
from rpa.public.tools import cel, cells
from rpa.ssc.hr.orm.orm_ope import Query
from rpa.ssc.hr.orm.td_hr_li_tui_code_rulebase import LiTui
from rpa.ssc.hr.sap.export_other_103 import export_103_li_tui_xiu_jian_ce
from rpa.ssc_kit.hr.kit_chai_dan.check_280 import (check_zhrpy280, create_dir,
                                                   get_date, get_grade,
                                                   get_info)


def rulebase_13(file, file_str):
    wb = load_workbook(file)
    ws = wb.active
    # 规则 13.1.1  提取“人员离退表”的“事件类型”为“离退休减册”的事件
    value_dict, li = defaultdict(list), []
    for i in range(7, len(ws["B"]) + 1):
        if ws["B%s" % str(i)].value and '离退休减册' in str(ws["D%s" % str(i)].value):
            if cel(ws, f"B{i}") in li:
                cells(ws, "B%s" % str(i), "人员编号有重复项", RED)
            li.append(cel(ws, f"B{i}"))
            value_dict[cel(ws, f"B{i}").lstrip('0')] = [str(j.value).strip() for j in ws[f"B{i}:T{i}"][0]]
    wb.save(file)
    if not li:
        logging.info("人员离退表中没有离退休减册事件。")
        return

    date = get_date(value_dict)
    if not date or len(date) != 8:
        return
    if date == "None":
        logging.info("离退休减册事件的第一个人员事件日期不应为空！")
        return
    export_103_li_tui_xiu_jian_ce(None, li, date).save_to(FILE_PATH)
    wb_103 = load_workbook(FILE_PATH + "/C21_离退休减册.xlsx")
    ws_103 = wb_103.active
    values_103 = defaultdict(list)
    for i in range(2, len(ws_103["A"]) + 1):
        for col in ["U", "V", "AI", "AJ", "AK", "AL", "AM", "AN", "AP", "AQ", "G", "S", "J", "K"]:
            values_103[cel(ws_103, f"A{i}").lstrip('0')].append(cel(ws_103, f"{col}{i}"))

    rule_W = {str(res.db_W).split()[-1]: str(res.db_W).strip() for res in Query(LiTui) if res.db_W}
    rule_X = {str(res.db_X).split()[-1]: str(res.db_X).strip() for res in Query(LiTui) if res.db_X}
    rule_Y = {str(res.db_Y).split()[-1]: str(res.db_Y).strip() for res in Query(LiTui) if res.db_Y}
    rule_R = [str(res.db_R).strip() for res in Query(LiTui) if res.db_R]

    wb_temp = load_workbook(os.path.join(templates, "离退休减册事件批导.xlsx"))
    ws = wb_temp.active

    for num, (key, value) in enumerate(list(value_dict.items())):
        i = num + 7
        if key not in values_103.keys():
            cells(ws, f"B{i}", "103表中没有该人员编号，请核对", RED)
            continue

        # 规则 13.2.1 - 13.2.5  B-R
        for count, col in {0: "B", 1: "C", 3: "E", 4: "D", 12: "O", 15: "R"}.items():
            ws[f"{col}{i}"] = value[count] if value[count] != "None" else None

        # 规则 13.2.6  F-人员组
        ws[f"F{i}"] = "S 离退休后减册人员"

        # 规则 13.2.7  H-工资核算范围
        ws[f"H{i}"] = "00 不发工资"

        # 规则 13.3.1  G-人员子组
        ws[f"G{i}"] = values_103[key][0] + " " + values_103[key][1]

        # 规则 13.3.2  I-离(退)休人员类别
        if values_103[key][2] in rule_W.keys():
            ws[f"I{i}"] = rule_W[values_103[key][2]]

        # 规则 13.3.3  J-离(退)休后享受待遇级别
        if values_103[key][3] in rule_X.keys():
            ws[f"J{i}"] = rule_X[values_103[key][3]]

        # 规则 13.3.4  K-离（退）休人员来源
        if values_103[key][4] in rule_Y.keys():
            ws[f"K{i}"] = rule_Y[values_103[key][4]]

        # 规则 13.3.5  L-离(退)休后管理单位
        ws[f"L{i}"] = values_103[key][5]

        # 规则 13.3.5.1
        ws[f"M{i}"] = values_103[key][6]

        # 规则 13.3.5.2
        ws[f"N{i}"] = values_103[key][7]

        # 规则 13.3.6  P-返聘标识
        if values_103[key][8]:
            ws[f"P{i}"] = "X 是" if "是" in values_103[key][8] else "  否"

        # 规则 13.3.7  Q-领取企业年金标识
        if values_103[key][9]:
            ws[f"Q{i}"] = "X 是" if "是" in values_103[key][9] else "  否"

        # 规则 13.3.8  A-序号
        ws[f"A{i}"] = str(num + 1)

        # 规则 13.4.2  E-离退休减册事件原因
        if cel(ws, f"E{i}") not in rule_R:
            cells(ws, f"E{i}", "事件原因非码值", RED)

        # 规则 13.4.3  D-离退休时间
        try:
            time.strptime(cel(ws, f"D{i}"), '%Y%m%d')
            current_date = time.strftime("%d", time.localtime(time.time()))
            current_month = time.strftime("%Y%m01", time.localtime(time.time()))
            next_month = time.strftime("%Y%m01", time.localtime(time.time() + (32 - int(current_date)) * 24 * 60 * 60))
            if cel(ws, f"D{i}") not in [current_month, next_month]:
                cells(ws, f"D{i}", "事件日期需核对", RED)
            if num != 0 and cel(ws, f"D{i-1}") != cel(ws, f"D{i}"):
                cells(ws, f"D{i}", "事件日期需核对", RED)
        except Exception:
            cells(ws, f"D{i}", "事件日期需核对", RED)

        # 规则 13.4.4
        if values_103[key][10]:
            cells(ws, f"A{i}", "请注意该人员该月已做过事件", RED)

        # 规则 13.4.5  F-人员组
        if values_103[key][11] != "K":
            cells(ws, f"F{i}", "此人不是离退休人员！", RED)

        # 规则 13.4.6  C-人员姓名
        if values_103[key][12] != "离退休（在册）":
            cells(ws, f"B{i}", "请核对该人员的岗位状态是否正确", RED)

        # 13.4.7
        if values_103[key][13] != "退休":
            cells(ws, f"C{i}", "请核对该人员的雇佣状态是否正确", RED)
    serial_id = datetime.now().strftime("%Y-%m-%d-%H-%M-%S-%f")
    wb_temp.properties.description = serial_id
    wb_temp.save(FILE_PATH + '/tmp-减册.xlsx')
    # 13.4.1	生成离退休减册模板-3
    check_zhrpy280(FILE_PATH + '/tmp-减册.xlsx')
    local = create_dir(file, file_str)
    sr, code, worker = get_info(file, file_str)
    get_grade(f"{os.path.basename(file).split('-')[0][:10]}-XX-XX", value_dict, "离退休减册", serial_id)
    shutil.move(FILE_PATH + "/C21_离退休减册.xlsx", local + f"/103_离退休减册_{os.path.basename(file)}")
    shutil.move(FILE_PATH + '/tmp-减册.xlsx', local + f"/{sr}-{code}-离退休减册-{worker}.xlsx")
