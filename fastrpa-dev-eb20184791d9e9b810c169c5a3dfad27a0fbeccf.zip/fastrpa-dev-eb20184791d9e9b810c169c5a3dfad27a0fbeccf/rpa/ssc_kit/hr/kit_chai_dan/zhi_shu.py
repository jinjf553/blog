#!/usr/bin/env python
# -*- coding: utf-8 -*-
# @File    : zhi_shu.py
# @Author  : jinjianfeng
# @Contact : 553041800@qq.com
# @Link    : https://github.com/jinjf553
# @software: PyCharm
# @Date    : 2019/6/7 13:50
# @Version : ??
import logging
import os
import shutil
import time
from collections import defaultdict

from openpyxl import load_workbook
from rpa.fastrpa.adtable import BLUE, RED
from rpa.fastrpa.sap.session import close_sap
from rpa.public.config import FILE_PATH, templates
from rpa.public.tools import cel, cells
from rpa.ssc.hr.orm.orm_ope import Query
from rpa.ssc.hr.orm.td_hr_gang_wei_diao_pei_rulebase import Event
from rpa.ssc.hr.sap.export_103_bk import export_103_bk
from rpa.ssc.hr.sap.export_1071 import export_1071
from rpa.ssc_kit.hr.kit_chai_dan.check_280 import (check_zhrpy280, create_dir,
                                                   get_date, split_file)


def rulebase_6(file, file_str):
    wb = load_workbook(file)
    ws = wb.active

    # 规则 6.1.1 - 6.1.2
    value_dict, li = defaultdict(list), []
    for i in range(7, len(ws["B"]) + 1):
        # 规则 6.1.1  提取“人员调配表”的“事件类型”为“直属单位间调动”的事件
        if ws["B%s" % str(i)].value and '直属单位间调动' in str(ws["D%s" % str(i)].value):
            if cel(ws, f"B{i}") in li:
                cells(ws, "B%s" % str(i), "人员编号有重复项", RED)
            li.append(cel(ws, f"B{i}"))
            value_dict[cel(ws, f"B{i}")] = [str(j.value).strip() for j in ws["B%s:W%s" % (str(i), str(i))][0]]
    wb.save(file)
    if not li:
        logging.info("人员调配表中没有直属单位间调动事件。")
        return

    date = get_date(value_dict)
    if not date or len(date) != 8:
        return
    export_103_bk(None, li, date).save_to(FILE_PATH)
    wb_103 = load_workbook(FILE_PATH + "/模板_103.xlsx")
    ws_103 = wb_103.active
    values_103, li = defaultdict(list), []
    for i in range(2, len(ws_103["A"]) + 1):
        li.append(str(ws_103["X%s" % str(i)].value).rstrip())
        for col in ["BC", "AD", "AE", "AK", "Q", "R", "W", "Y", "S", "T", "Z", "AX", "AP", "BI", "G", "J", "P", "X"]:
            values_103[str(ws_103["A%s" % str(i)].value).lstrip('0')].append(str(ws_103["%s%s" % (col, str(i))].value))

    # 4.1.3 下载1071
    if not li:
        logging.info("103表中没有《X-职务(岗位)具体名称》的数据")
        return
    export_1071("reuse", li, date).save_to(FILE_PATH)
    close_sap()
    wb_1071 = load_workbook(FILE_PATH + "/模板_1071.xlsx")
    ws_1071 = wb_1071.active
    values_1071 = defaultdict(str)
    for i in range(2, len(ws_1071["A"]) + 1):
        if str(ws_1071["B%s" % str(i)].value) == "S":
            values_1071[str(ws_1071["A%s" % str(i)].value)] = str(ws_1071["K%s" % str(i)].value)

    rule_values = defaultdict(list)
    [rule_values[res.db_U.split()[1]].append(res.db_U.split()[0])
     for res in Query(table=Event) if res.db_U]
    rule_J = [res.db_J for res in Query(table=Event) if res.db_J]  # 人员组
    rule_L = [res.db_L for res in Query(table=Event) if res.db_L]  # 人员子组
    rule_AG = [res.db_AG for res in Query(table=Event) if res.db_AG]  # 工资核算范围
    rule_F = [res.db_F for res in Query(table=Event) if res.db_F]  # 企业自定义分类1
    rule_U = {res.db_U: [res.db_V, res.db_W]
              for res in Query(table=Event) if res.db_U}  # 职位级别 & 职位序列 & 职位层次
    rule_G = [res.db_G.replace(" ", "") for res in Query(table=Event) if res.db_G]  # 企业自定义分类2
    rule_H = [res.db_H.replace(" ", "") for res in Query(table=Event) if res.db_H]  # 企业自定义分类3
    rule_AK = [res.db_AK for res in Query(table=Event) if res.db_AK]  # 二级单位间调动事件调入原因
    rule_R = [res.db_R for res in Query(table=Event) if res.db_R]  # 人员标识
    rule_L_M = {res.db_L: res.db_M for res in Query(table=Event) if res.db_L}  # 人员子组 & 岗位分类序列
    rule_BD_BB_BC = {res.db_BD: [res.db_BB, res.db_BC] for res in Query(table=Event) if res.db_BD}  # 调动前人事范围
    rule_AZ = [res.db_AZ for res in Query(table=Event) if res.db_AZ]  # 人员标识
    rule_AG_AA = defaultdict(list)
    [rule_AG_AA[res.db_AG].append(res.db_AA) for res in Query(table=Event) if res.db_AG]
    wb_template = load_workbook(os.path.join(templates, "调入事件模板表.xlsx"))
    ws_template = wb_template.active
    for num, (key, value) in enumerate(list(value_dict.items())):
        # 规则 6.2.2 - 6.2.9 & 6.2.12 - 6.2.14  B-AN
        for count, col in enumerate(["B", "C", "E", "E", "D", "J", "R", "K", "BC", "S", "BK", "BB", "BL",
                                     "AZ", "AZ", "AZ", "BA", "BN", "BN", "BO", "BP", "BM"]):
            ws_template["%s%s" % (col, str(num + 7))] = value[count] if value[count] != "None" else None
            ws_template["BD%s" % str(num + 7)] = value[9] if value[9] != "None" else None

        # 规则 6.2.10  W-兼任职务级别
        if value[13] in [None, "None"] and key.lstrip('0') in values_103.keys():
            if values_103[key.lstrip('0')][0] is not None and values_103[key.lstrip('0')][0] in rule_values.keys():
                ws_template["W%s" % str(num + 7)] = rule_values[values_103[key.lstrip('0')][0]][0] + ' ' + \
                    values_103[key.lstrip('0')][0]
        elif key.lstrip('0') not in values_103.keys():
            cells(ws_template, "B%s" % str(num + 7), "103表中没有该人员编号，请核对", RED)
            continue
        elif "清空" not in value[13]:
            ws_template["W%s" % str(num + 7)] = value[13]

        # 规则 6.2.11  N-企业自定义分类
        if value[14] not in [None, "None"] and "清空" not in value[14]:
            ws_template["N%s" % str(num + 7)] = value[14]

        # 规则 6.2.15  M-工作合同
        if value[17] not in [None, "None"] and "清空" not in value[17]:
            ws_template["M%s" % str(num + 7)] = value[17]

        # 规则 6.3.2  BB-调动日期
        if ws_template["BB%s" % str(num + 7)].value is None:
            ws_template["BB%s" % str(num + 7)] = ws_template["D%s" % str(num + 7)].value

        # 规则 6.3.3  I-人员组 & BI-调动前人员组
        if key.lstrip('0') in values_103.keys():
            if [v for v in rule_J if values_103[key.lstrip('0')][8] == v[:1]]:
                ws_template["I%s" % str(num + 7)] = [v for v in rule_J if values_103[key.lstrip('0')][8] == v[:1]][0]
                ws_template["BI%s" % str(num + 7)] = [v for v in rule_J if values_103[key.lstrip('0')][8] == v[:1]][0]
            else:
                raise Exception("规则库中没有人员组为" + values_103[key.lstrip('0')][8] + "的规则，请检查")

        # 规则 6.3.4 - 6.3.7  BH-调动前人事子范围 & BE-调动前机构 & BF-调动前岗位 & BG-调动前人事范围
        if key.lstrip('0') in values_103.keys():
            ws_template["BH%s" % str(num + 7)] = values_103[key.lstrip('0')][4] + ' ' + values_103[key.lstrip('0')][5]
            ws_template["BE%s" % str(num + 7)] = values_103[key.lstrip('0')][6]
            ws_template["BF%s" % str(num + 7)] = values_103[key.lstrip('0')][7]
            ws_template["BG%s" % str(num + 7)] = values_103[key.lstrip('0')][16]

        # 规则 6.3.8  J-人员子组
        if str(ws_template["J%s" % str(num + 7)].value).replace(" ", "") == "不变":
            if key.lstrip('0') in values_103.keys():
                if [v for v in rule_L if values_103[key.lstrip('0')][9] in v]:
                    ws_template["J%s" % str(num + 7)] = [v for v in rule_L if values_103[key.lstrip('0')][9] in v][0]
                else:
                    ws_template["J%s" % str(num + 7)] = values_103[key.lstrip('0')][9]
                    cells(ws_template, "J%s" % str(num + 7), "码表库中没有该人员子组，请检查", RED)
        elif ws_template["J%s" % str(num + 7)].value not in rule_L:
            cells(ws_template, "J%s" % str(num + 7), "人员子组非码值", RED)

        # 规则 6.3.9  K-工资核算范围
        if str(ws_template["K%s" % str(num + 7)].value).replace(" ", "") == "不变":
            if key.lstrip('0') in values_103.keys():
                if [v for v in rule_AG if values_103[key.lstrip('0')][10] in v]:
                    ws_template["K%s" % str(num + 7)] = [v for v in rule_AG if values_103[key.lstrip('0')][10] in v][0]
                else:
                    ws_template["K%s" % str(num + 7)] = values_103[key.lstrip('0')][10]
                    cells(ws_template, "K%s" % str(num + 7), "码表库中没有该工资核算范围，请检查", RED)
        elif ws_template["K%s" % str(num + 7)].value not in rule_AG:
            cells(ws_template, "K%s" % str(num + 7), "工资核算范围非码值", RED)
            cells(ws_template, "H%s" % str(num + 7), "未校验事件类型是否正确，请自行验证", RED)
        else:
            cells(ws_template, "K%s" % str(num + 7), "企业表单中工资核算范围填写的值为“不变”", BLUE)
            cells(ws_template, "H%s" % str(num + 7), "未校验事件类型是否正确，请自行验证", RED)

        # 规则 6.3.10  M-工作合同
        if ws_template["M%s" % str(num + 7)].value not in [None, "01 联量/计件工资人员", "02 非联量/计件工资人员"]:
            cells(ws_template, "M%s" % str(num + 7), "工作合同非码值", RED)

        # 规则 6.3.11  N-企业自定义分类
        if ws_template["N%s" % str(num + 7)].value not in rule_F + [None]:
            cells(ws_template, "N%s" % str(num + 7), "企业自定义分类1非码值", RED)

        # 规则 6.3.12  R-职位级别
        if str(ws_template["R%s" % str(num + 7)].value).replace(" ", "") == "不变":
            if key.lstrip('0') in values_103.keys():
                tmp_l = [v for v in rule_U if values_103[key.lstrip('0')][11].strip() == v.split()[-1]]
                if tmp_l:
                    ws_template["R%s" % str(num + 7)] = tmp_l[0]
                else:
                    ws_template["R%s" % str(num + 7)] = values_103[key.lstrip('0')][11]
                    cells(ws_template, f"R{num + 7}", "码表库中没有该职位级别，请检查", RED)
        elif ws_template["R%s" % str(num + 7)].value not in rule_U.keys():
            for col, content in {"R": "职位级别非码值", "P": "职位序列未生成", "Q": "职位层次未生成"}.items():
                cells(ws_template, f"{col}{num+7}", content, RED)

        # 规则 6.3.13  P-职位序列 & Q-职位层次
        if not ws_template["R%s" % str(num + 7)].comment:
            ws_template["P%s" % str(num + 7)] = rule_U[ws_template["R%s" % str(num + 7)].value][0]
            ws_template["Q%s" % str(num + 7)] = rule_U[ws_template["R%s" % str(num + 7)].value][1]

        # 规则 6.3.14  W-兼任职务级别
        if ws_template["W%s" % str(num + 7)].value not in list(rule_U.keys()) + [None, "None"]:
            for col, content in {"W": "兼任职位级别非码值"}.items():
                cells(ws_template, f"{col}{num + 7}", content, RED)

        # 规则 6.3.15  T-兼任职位标识
        if not ws_template["W%s" % str(num + 7)].comment and ws_template[f"W{num+7}"].value:
            ws_template["T%s" % str(num + 7)] = rule_R[1]

        # 规则 6.3.16  U-兼任职位序列
        if not ws_template[f"W{num+7}"].comment and ws_template[f"W{num+7}"].value in rule_U.keys():
            ws_template["U%s" % str(num + 7)] = rule_U[ws_template["W%s" % str(num + 7)].value][0]
            ws_template["V%s" % str(num + 7)] = rule_U[ws_template["W%s" % str(num + 7)].value][1]
            if ws_template["P%s" % str(num + 7)].value == ws_template["U%s" % str(num + 7)].value:
                cells(ws_template, "U%s" % str(num + 7), "兼任职位与主要职位处于同一序列", RED)

        # 规则 6.3.17 & 6.3.18  O-企业统计标识 & X-聘任文号
        if key.lstrip('0') in values_103.keys() and [x for x in rule_R if values_103[key.lstrip('0')][12].strip() in x]:
            ws_template["O%s" % str(num + 7)] = [x for x in rule_R if values_103[key.lstrip('0')][12].strip() in x][0]
            ws_template["X%s" % str(num + 7)] = values_103[key.lstrip('0')][13] if values_103[key.lstrip('0')][
                13] != "None" else None

        # 规则 6.3.19  BB-调动日期
        try:
            time.strptime(str(ws_template["BB%s" % str(num + 7)].value), '%Y%m%d')
        except Exception:
            cells(ws_template, "BB%s" % str(num + 7), "调动日期非正确值", RED)

        # 规则 6.3.20  AZ-企业自定义分类2
        if str(ws_template["AZ%s" % str(num + 7)].value).replace(" ", "") not in ["清空", "None"] + rule_G:
            cells(ws_template, "AZ%s" % str(num + 7), "企业自定义分类2非码值", RED)

        # 规则 6.3.21  BA-企业自定义分类3
        if str(ws_template["BA%s" % str(num + 7)].value).replace(" ", "") not in ["清空", "None"] + rule_H:
            cells(ws_template, "BA%s" % str(num + 7), "企业自定义分类3非码值", RED)

        # 规则 6.3.22  A-序号
        ws_template["A%s" % str(num + 7)] = str(num + 1)

        # 规则 6.3.23  BJ-原岗位类别
        if values_103[key.lstrip('0')][17] in values_1071.keys():
            ws_template["BJ%s" % str(num + 7)] = values_1071[values_103[key.lstrip('0')][17]]

        # 规则 4.3.25  BJ-原岗位类别
        if ws_template["BI%s" % str(num + 7)].value == "B 合同制员工":
            if str(ws_template["BJ%s" % str(num + 7)].value)[:1] == "C":
                cells(ws_template, "BJ%s" % str(num + 7), "B类人员C类岗", RED)

        # 规则 6.4.1  D-岗位变动日期
        try:
            time.strptime(str(ws_template["D%s" % str(num + 7)].value), '%Y%m%d')
            current_date = time.strftime("%d", time.localtime(time.time()))
            current_month = time.strftime("%Y%m01", time.localtime(time.time()))
            next_month = time.strftime("%Y%m01", time.localtime(time.time() + (32 - int(current_date)) * 24 * 60 * 60))
            if str(ws_template["D%s" % str(num + 7)].value) not in [current_month, next_month]:
                cells(ws_template, "D%s" % str(num + 7), "事件日期需核对", RED)
            if num != 0 and ws_template["D%s" % str(num + 6)].value != ws_template["D%s" % str(num + 7)].value:
                cells(ws_template, "D%s" % str(num + 7), "事件日期需核对", RED)
        except Exception:
            cells(ws_template, "D%s" % str(num + 7), "事件日期需核对", RED)

        # 规则 6.4.2  E-调入原因
        if ws_template["E%s" % str(num + 7)].value not in rule_AK:
            cells(ws_template, "E%s" % str(num + 7), "事件原因需核对", RED)

        # 规则 6.4.3  P-职位序列
        if ws_template["J%s" % str(num + 7)].value in rule_L_M.keys():
            if rule_L_M[ws_template["J%s" % str(num + 7)].value] != ws_template["P%s" % str(num + 7)].value:
                cells(ws_template, "P%s" % str(num + 7), "人员子组与职位序列不对应", RED)

        # 规则 6.4.4  J-人员子组
        if ws_template["J%s" % str(num + 7)].value == rule_L[6]:
            cells(ws_template, "J%s" % str(num + 7), "人员子组有误", RED)

        # 规则 6.4.5  G-事件类型
        if key.lstrip('0') in values_103.keys() and values_103[key.lstrip('0')][14] != "None":
            cells(ws_template, "A%s" % str(num + 7), "请注意该人员该月已做过事件", RED)

        # 规则 6.4.6  C-人员姓名
        if key.lstrip('0') in values_103.keys() and values_103[key.lstrip('0')][15] in rule_AZ[8:]:
            cells(ws_template, "C%s" % str(num + 7), "请核对该人员的岗位状态是否应做直属单位间调动事件", RED)
        if key.lstrip('0') in values_103.keys() and values_103[key.lstrip('0')][15] in rule_AZ[1:8]:
            cells(ws_template, "C%s" % str(num + 7), "该人员的岗位状态不为在岗状态", BLUE)

        # 规则 6.4.7  K-工资核算范围
        if not ws_template["K%s" % str(num + 7)].comment:
            if ws_template["K%s" % str(num + 7)].value in rule_AG_AA.keys() and ws_template[
                    "BE%s" % str(num + 7)].value in rule_BD_BB_BC.keys():
                if rule_AG_AA[ws_template["K%s" % str(num + 7)].value][0] in rule_BD_BB_BC.keys():
                    rule_BB, rule_BC = rule_BD_BB_BC[rule_AG_AA[ws_template["K%s" % str(num + 7)].value][0]]
                    temp_BB, temp_BC = rule_BD_BB_BC[rule_AG_AA[ws_template["BE%s" % str(num + 7)].value]]
                    if rule_BB == temp_BB and rule_BC != temp_BC:
                        cells(ws_template, "H%s" % str(num + 7), "事件类型不应为直属单位间调动，请核对事件类型", RED)
                    elif rule_BB != temp_BB:
                        cells(ws_template, "H%s" % str(num + 7), "请注意该调动类型为跨企业调动", RED)

    wb_template.save(FILE_PATH + '/tmp-直属.xlsx')
    check_zhrpy280(FILE_PATH + '/tmp-直属.xlsx')
    local = create_dir(file, file_str)
    split_file(FILE_PATH + '/tmp-直属.xlsx', "BG", "直属单位间调动模板", local, "直属单位间调动", False)
    shutil.move(FILE_PATH + "/模板_103.xlsx", local + f"/103_直属单位间调动_{os.path.basename(file)}")
    shutil.move(FILE_PATH + '/tmp-直属.xlsx', local + f"/{os.path.basename(file)[:10]}_直属单位间调动模板.xlsx")
