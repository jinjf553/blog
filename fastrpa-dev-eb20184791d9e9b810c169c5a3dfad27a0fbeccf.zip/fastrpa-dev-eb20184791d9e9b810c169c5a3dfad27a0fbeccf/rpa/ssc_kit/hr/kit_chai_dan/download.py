import logging
import os
import random
import re
import shutil
import sys
import time
from collections import defaultdict
from datetime import datetime, timedelta
from typing import List

import requests
import rpa.config
import xlrd
from rpa.fastrpa.mail import sendmail
from rpa.fastrpa.third_party.zip7 import ZIP7_EXE_PATH
from rpa.public import tools
from rpa.public.config import local_path, remote_daiban
from rpa.public.myftp import MYFTP
from rpa.ssc.hr.orm.orm_ope import DbSession, Update
from rpa.ssc.hr.orm.tb_dim_hr_staff import TB_DIM_HR_STAFF
from rpa.ssc.hr.orm.tb_hr_gangweibiandong_log import Log
from rpa.ssc.hr.orm.tb_hr_gangweibiandong_log_detail import LogDetail
from rpa.ssc.hr.orm.tb_hr_sr import SR
from rpa.ssc.hr.orm.td_hr_gang_wei_diao_pei_rulebase import Event
from rpa.ssc_kit.hr.kit_chai_dan.run_A import (run_kit_shou_dong_chai_dan,
                                               upload_file)
from rpa.ssc_kit.hr.kit_chai_dan.upload import login, switch_to_frame
from selenium.webdriver.support.wait import WebDriverWait
from sqlalchemy import and_, func
from win32com.client import DispatchEx
from win32com.client.gencache import EnsureDispatch


def download(xpath="C14_W42_V43"):
    browser = login()
    wait = WebDriverWait(browser, 10)
    count = wait.until(lambda x: x.find_elements_by_xpath('//*[@id="%s_ZHSFList_TableHeader"]/tbody/tr' % xpath))
    if "未找到结果" in count[0].text:
        time.sleep(30)
        browser.close()
        return [], ""
    for i in range(1, len(count) + 1):
        sr = WebDriverWait(browser, 30).until(lambda x: x.find_element_by_xpath(
            '//*[@id="%s_DETAIL_Table[%s].OBJECT_ID"]' % (xpath, str(i)))).text  # 获取服务请求编号
        text = wait.until(lambda x: x.find_element_by_xpath(
            '//*[@id="%s_DETAIL_Table[%s].CAT_ID"]' % (xpath, str(i)))).text  # 获取末级目录(RS_9_1)
        with DbSession() as sess:
            res = sess.query(SR).with_for_update().filter(SR.sr == sr)
            if res.first():
                if res.first().state is None:
                    res.update({"state": "拆单"})
                elif res.first().state == "拆单":
                    r = sess.query(Log).filter(Log.sr == sr)
                    if r.first() and r.first().worker == "常盛":
                        continue
                    if r.first() and r.first().date == (datetime.now() - timedelta(days=1)).strftime("%Y%m%d"):
                        if r.first().remark != "未找到业务员" and r.first().worker:
                            r.update({"step": "上载完成", "remark": "待转寄"})
                        else:
                            r.update({"worker": "常盛", "step": "上载完成", "remark": "待转寄"})
                    else:
                        res.update({"state": "1"})
                elif str(res.first().state).isdigit() and int(str(res.first().state)) < 5:
                    res.update({"state": str(int(str(res.first().state)) + 1)})
                else:
                    continue
            else:
                sess.add(SR(sr=sr, create_time=datetime.now(), update_time=datetime.now()))
                continue
        try:
            tools.click_able(browser, '//*[@id="%s_ZHSFList_sel_%s-rowsel"]' % (xpath, str(i)))  # 选中
            tools.click_able(browser, '//*[@id="%s_btn_Execute"]/span/b' % xpath)  # 执行
            if not tools.click_able(browser, '//*[@id="0001_nl1_1_mid"]/table/tbody/tr/td'):  # 服务请求详细信息
                raise Exception(f'点击执行未进入单号界面{sr}')
            # wait.until(lambda x: x.find_element_by_xpath('//*[@id="0001_nl1_1_mid"]/table/tbody/tr/td'))
            break
        except Exception as e:
            logging.error(e)
            if '待办事项' in wait.until(lambda x: x.find_element_by_xpath('//*[@id="bcTitle"]/div')).text:  # 获取待办事项
                tools.click_able(browser, '//*[@id="%s_btn_Refresh"]/img' % xpath)  # 异常时刷新池子
    else:
        time.sleep(10)
        browser.close()
        return [], ""
    xpa = '//*[@id="C18_W59_V61_V64_'
    atr = wait.until(lambda x: x.find_element_by_xpath(f'{xpa}btadminh_struct.object_id"]')).get_attribute("value")
    code = wait.until(lambda x: x.find_element_by_xpath(f'{xpa}btadminh_ext.zzhrrangecode"]')).get_attribute("value")
    date = wait.until(lambda x: x.find_element_by_xpath(f'{xpa}btadminh_struct.posting_date"]')).get_attribute("value")
    date = str(date).replace(".", "")
    state = wait.until(lambda x: x.find_element_by_xpath(f'{xpa}btadminh_lcstatus"]')).get_attribute("value")
    comment = wait.until(lambda x: x.find_element_by_xpath(f'{xpa}btadminh_struct.description"]')).get_attribute("value")
    comment = re.sub(r"[/\\:*?\"<>|]", "", str(comment))
    content = wait.until(lambda x: x.find_element_by_xpath(f'{xpa}btpartnerset_soldto_name"]')).get_attribute("value")
    if atr != sr:
        sendmail(receivers="553041800@qq.com", subject="拆单", body=f"{sr}拆成{atr}")
        sr = atr
    wait.until(lambda x: x.find_element_by_xpath('//*[@id="0004_nl3_3_mid"]/table/tbody/tr/td')).click()  # 点击附件
    try:
        wait.until(lambda x: x.find_element_by_link_text('来自企业的附件')).click()  # 点击
    except Exception:
        insert_db(0, text, wait, browser, code, date, state, sr, content, comment, "待转寄")
        return [], sr + "_" + comment + "_企业没有附件"

    handles = tools.windowlist(browser)  # 获取所有window窗口
    browser.switch_to.window(handles[1])  # 切换窗口
    file_count = len(wait.until(lambda x: x.find_elements_by_xpath('//*[@id="statTable"]/tbody/tr')))

    dir_path = local_path + "\\" + sr + "_" + comment
    date_time = time.strftime("%Y%m%d %H:%M:%S\n", time.localtime(time.time()))
    with open(f"{date_time[:8]}error.log", "a+", encoding="utf-8") as f:
        f.write(date_time)
        f.write(f"dirpath: {dir_path}\nfile_count:{file_count}")
    if not os.path.exists(dir_path):  # 附件存放路径是否存在，否则创建路径
        os.makedirs(dir_path)
    count, file_list, flag = 0, [], False
    for i in range(1, file_count):
        file_name = wait.until(lambda x: x.find_element_by_xpath('//*[@id="%s"]/td[4]' % str(i))).text  # 获取附件的名称
        idname = wait.until(lambda x: x.find_element_by_xpath('//*[@id="%s"]/td[8]/button' % str(i))).get_attribute(
            'id')  # 获取下载的ID属性 //*[@id="down_BEE6D2F3150511EB967A00155D6D1902"]
        strs = 'http://10.246.109.83/ims/imsFssUploadAction_downloadFile.action?id=' + idname[5:] + '&dowFileName=1'
        logging.info(strs)
        file_path = dir_path + '\\' + sr + "_" + file_name
        with open(file_path, 'wb') as f:  # 下载附件并保存到指定路径，以sr号命名
            f.write(requests.get(strs).content)

        un_path, name = os.path.splitext(file_path)
        if name in [".zip", ".ZIP", ".rar", ".RAR", ".7z", ".7Z"]:
            cmd = '{} x "{}" -o"{}" -aos -r'.format(ZIP7_EXE_PATH, file_path, un_path)
            ret = os.system(cmd)  # nosec
            if ret != 0:
                logging.error(f'执行命令【{cmd}】出错')
            count, file_list, flag = tmp_if(un_path, count, file_list)
        else:
            count, file_list, flag = tmp_if(file_path, count, file_list)
        logging.info(f'{count}, {file_list}')

    browser.close()
    browser.switch_to.window(handles[0])  # 切换回主窗口
    switch_to_frame(browser)  # 切换到相应的frame框架内

    if wait.until(lambda x: x.find_element_by_xpath('//*[@id="C18_W59_V61_EDIT"]')).get_attribute(
            'class') == 'th-bt th-bt-icontext':  # 判断编辑是否可以点击
        wait.until(lambda x: x.find_element_by_xpath('//*[@id="C18_W59_V61_EDIT"]')).click()  # 点击编辑

    insert_db(count, text, wait, browser, code, date, state, sr, content, comment)

    if count >= 100 or "RS_8_2_3" in text or flag:
        if count >= 100:
            body = f"中人数为{count}，{'大于' if count > 100 else '等于'}100人。"
        # elif "RS_8_2_3" in text:
        #     body = f"提报路径为‘RS_8_2_3’。"
        else:
            body = "为机构信息类表单。"
        with DbSession() as db_sess:
            res = db_sess.query(Event).filter_by(db_BJ=code).first()
            res = db_sess.query(TB_DIM_HR_STAFF).filter(TB_DIM_HR_STAFF.staff_group == res.db_BL, TB_DIM_HR_STAFF.staff_type == "组长").first()
            if flag:
                Update(table=Log, sr=sr, worker=res.staff_name if res.staff_name.strip() != '常盛' else '侯婷婷')
            if res and res.email:
                sendmail(receivers=res.email,
                         subject='通知—%s_%s' % (sr, comment),
                         body=f"服务请求编号：%s，业务摘要：%s，人事范围编码：%s，服务对象：%s  的企业表单{body}转寄组长并邮件提醒。" % (
                             sr, content, code, comment))

    return file_list, sr + "_" + comment


def download2(xpath, browser, sr, idx, worker):
    wait = WebDriverWait(browser, 10)
    try:
        tools.click_able(browser, '//*[@id="%s_ZHSFList_sel_%s-rowsel"]' % (xpath, str(idx)))  # 选中
        tools.click_able(browser, '//*[@id="%s_btn_Execute"]/span/b' % xpath)  # 执行
        if not tools.click_able(browser, '//*[@id="0001_nl1_1_mid"]/table/tbody/tr/td'):  # 服务请求详细信息
            raise Exception(f'点击执行未进入单号界面{sr}')
    except Exception as e:
        logging.error(e)
        return [], ""
    xpa2 = wait.until(lambda x: x.find_element_by_xpath('//*[text()="请求编号:"]')).get_attribute("id")
    xpa = f'//*[@id="{xpa2[:16]}'
    atr = wait.until(lambda x: x.find_element_by_xpath(f'{xpa}btadminh_struct.object_id"]')).get_attribute("value")
    text = wait.until(lambda x: x.find_element_by_xpath(f'{xpa}btadminh_struct.description"]')).get_attribute("value")
    code = wait.until(lambda x: x.find_element_by_xpath(f'{xpa}btadminh_ext.zzhrrangecode"]')).get_attribute("value")
    date = wait.until(lambda x: x.find_element_by_xpath(f'{xpa}btadminh_struct.posting_date"]')).get_attribute("value")
    date = str(date).replace(".", "")
    state = wait.until(lambda x: x.find_element_by_xpath(f'{xpa}btadminh_lcstatus"]')).get_attribute("value")
    comment = wait.until(lambda x: x.find_element_by_xpath(f'{xpa}btadminh_struct.description"]')).get_attribute("value")
    comment = re.sub(r"[/\\:*?\"<>|]", "", str(comment))
    content = wait.until(lambda x: x.find_element_by_xpath(f'{xpa}btpartnerset_soldto_name"]')).get_attribute("value")
    if atr != sr:
        sendmail(receivers="553041800@qq.com", subject="拆单", body=f"{sr}拆成{atr}")
        sr = atr
    wait.until(lambda x: x.find_element_by_xpath('//*[@id="0004_nl3_3_mid"]/table/tbody/tr/td')).click()  # 点击附件
    try:
        wait.until(lambda x: x.find_element_by_link_text('来自企业的附件')).click()  # 点击
    except Exception:
        insert_db(0, text, wait, browser, code, date, state, sr, content, comment, "待转寄", xpa, worker)
        return [], sr + "_" + comment + "_企业没有附件"

    handles = tools.windowlist(browser)  # 获取所有window窗口
    browser.switch_to.window(handles[1])  # 切换窗口
    file_count = len(wait.until(lambda x: x.find_elements_by_xpath('//*[@id="statTable"]/tbody/tr')))

    dir_path = local_path + "\\" + sr + "_" + comment
    date_time = time.strftime("%Y%m%d %H:%M:%S\n", time.localtime(time.time()))
    with open(f"{date_time[:8]}error.log", "a+", encoding="utf-8") as f:
        f.write(date_time)
        f.write(f"dirpath: {dir_path}\nfile_count:{file_count}")
    if not os.path.exists(dir_path):  # 附件存放路径是否存在，否则创建路径
        os.makedirs(dir_path)
    count, file_list, flag = 0, [], False
    for i in range(1, file_count):
        file_name = wait.until(lambda x: x.find_element_by_xpath('//*[@id="%s"]/td[4]' % str(i))).text  # 获取附件的名称
        idname = wait.until(lambda x: x.find_element_by_xpath('//*[@id="%s"]/td[8]/button' % str(i))).get_attribute(
            'id')  # 获取下载的ID属性 //*[@id="down_BEE6D2F3150511EB967A00155D6D1902"]
        strs = 'http://10.246.109.83/ims/imsFssUploadAction_downloadFile.action?id=' + idname[5:] + '&dowFileName=1'
        logging.info(strs)
        file_path = dir_path + '\\' + sr + "_" + file_name
        with open(file_path, 'wb') as f:  # 下载附件并保存到指定路径，以sr号命名
            f.write(requests.get(strs).content)

        un_path, name = os.path.splitext(file_path)
        if name in [".zip", ".ZIP", ".rar", ".RAR", ".7z", ".7Z"]:
            cmd = '{} x "{}" -o"{}" -aos -r'.format(ZIP7_EXE_PATH, file_path, un_path)
            ret = os.system(cmd)  # nosec
            if ret != 0:
                logging.error(f'执行命令【{cmd}】出错')
            count, file_list, flag = tmp_if(un_path, count, file_list)
        else:
            count, file_list, flag = tmp_if(file_path, count, file_list)
        logging.info(f'{count}, {file_list}')

    browser.close()
    browser.switch_to.window(handles[0])  # 切换回主窗口
    switch_to_frame(browser)  # 切换到相应的frame框架内

    if wait.until(lambda x: x.find_element_by_xpath(f'{xpa[:-4]}EDIT"]')).get_attribute(
            'class') == 'th-bt th-bt-icontext':  # 判断编辑是否可以点击
        wait.until(lambda x: x.find_element_by_xpath(f'{xpa[:-4]}EDIT"]')).click()  # 点击编辑

    insert_db(count, text, wait, browser, code, date, state, sr, content, comment, xpa=xpa, worker=worker)

    return file_list, sr + "_" + comment


def insert_db(count, text, wait, browser, code, date, state, sr, content, comment, remark="待拆单", xpa='//*[@id="C18_W59_V61_V64_', worker=""):
    try:
        count = count - 1 if text == "RS_1_1_9" else count
        wait.until(
            lambda x: x.find_element_by_xpath(f'{xpa}btadminh_ext.zzfld0000bk"]')).clear()  # 清空人次框
        wait.until(lambda x: x.find_element_by_xpath(f'{xpa}btadminh_ext.zzfld0000bk"]')).send_keys(
            count if count > 0 else 1)  # 填入人次
        wait.until(lambda x: x.find_element_by_xpath(f'{xpa[:-4]}SAVE"]')).click()  # 点击保存
    except Exception:  # nosec
        pass

    tools.click_able(browser, '//*[@id="BackButton"]')  # 点击返回
    time.sleep(1)
    browser.quit()
    worker_, zubie = random_worker(code, count)
    worker = worker_.strip() if not worker else worker
    date_time = time.strftime("%Y%m%d-%H%M%S", time.localtime(time.time()))
    with DbSession() as sess:
        res = sess.query(Log).with_for_update().filter(Log.sr == sr)
        if not res.first():
            a = Log(sr=sr, code=code, date=date, step=state, content=content, worker=worker, comment=comment, remark=remark,
                    people_num=count if count > 0 else 0, zubie=zubie, mjml=text, start_time=date_time, type="自动拆单")
            sess.add(a)
        else:
            res.update({'code': code, 'date': date, 'step': state, 'content': content, 'worker': worker, 'comment': comment,
                        'remark': remark, 'people_num': count if count > 0 else 0, 'zubie': zubie, 'mjml': text, 'start_time': date_time, 'type': '自动拆弹'})


def zi_dong_chai_dan(fso_username: str, fso_password: str, *, sr_list: List[str] = []):
    with DbSession() as s:
        res = s.query(TB_DIM_HR_STAFF).filter(TB_DIM_HR_STAFF.fso_username == fso_username).first()
        if res:
            worker = res.staff_name
        else:
            logging.info(f"数据库中不存在业务员账号为：{fso_username}")
            return
    browser = login(chrome="chrome_ziji", user=fso_username, pwd=fso_password)
    wait = WebDriverWait(browser, 40)
    elem = wait.until(lambda x: x.find_element_by_xpath('//*[@id="C2_W12_V13_ZHSF_LIST_MY.ZHSF_LIST/MainWindow"]'))
    elem1 = WebDriverWait(elem, 3).until(lambda x: x.find_element_by_xpath('*//*[text()="服务请求编号"]'))
    ele_id = elem1.get_attribute('id')[:12]
    flag = True
    for i in range(1, 11):
        if i != 1:
            if not tools.click_able(browser, f'//*[@id="{ele_id}ZHSFList_pag_pg-{i}"]/span'):
                logging.info(f"点击第{i}页报错")
                browser.quit()
                break
        time.sleep(0.8)
        for j in range(i * 10 - 9, i * 10 + 1):
            try:
                sr = WebDriverWait(browser, 3).until(lambda x: x.find_element_by_xpath(f'//*[@id="{ele_id}DETAIL_Table[{j}].OBJECT_ID"]'))
                if ("all" not in sr_list and sr.text.strip() in sr_list) or ("all" in sr_list and sr.text.strip() not in sr_list) or not sr_list:
                    if not sr_list and "all" not in sr_list:
                        sr_list.append("all")
                    sr_list.append(sr.text.strip())
                    flag = False
                    file_list, file_str = download2(ele_id.strip("_"), browser, sr.text, j, worker)
                    for file in file_list:
                        run_kit_shou_dong_chai_dan(filename=file, file_str=file_str)
                    # 上载、转寄
                    upload_file("", file_str)
                    if "all" in sr_list:
                        zi_dong_chai_dan(fso_username, fso_password, sr_list=sr_list)
                    return
                elif "all" in sr_list:
                    continue
            except Exception:  # nosec
                if flag:
                    logging.info(f"单号可能提供错误，请检查：{sr_list}")
                    time.sleep(10)
                browser.quit()
                return


def tmp_if(file, count, file_list):
    flag = False
    if os.path.isdir(file):
        logging.info(f"获取目录《{file}》中所有信息表格文件的人数...")
        for _file, dirs, files in os.walk(file):
            for f in files:
                if f.upper().endswith(".XLSX") and "员工信息采集表" not in f:
                    tmp_count, tmp_file, flag_ = get_value(os.path.join(_file, f))
                    if flag_:
                        flag = flag_
                    logging.info(f"   获取文件《{f}》中的人数，人数为{tmp_count}人。")
                    count += tmp_count
                    if tmp_file:
                        file_list.append(tmp_file)
    elif file.endswith(".xlsx") or file.endswith(".XLSX"):
        tmp_count, tmp_file, flag_ = get_value(file)
        if flag_:
            flag = flag_
        logging.info(f"获取文件《{file}》中的人数，人数为{tmp_count}人。")
        count += tmp_count
        if tmp_file:
            file_list.append(tmp_file)
    logging.info(f"共{count}人。")
    return count, file_list, flag


def get_value(file_path):
    """ 读取批导表数据 """
    try:
        workbook = xlrd.open_workbook(file_path)
    except Exception:
        try:
            xl = EnsureDispatch("Word.Application")
            path = sys.modules[xl.__module__].__file__
            os.system("rd /s/q %s" % path[:path.index("gen_py") + 7])  # nosec
            excel = DispatchEx('Excel.Application')
        except Exception:
            return 0, [], False
        try:
            wb = excel.Workbooks.Open(file_path)
        except Exception:
            os.remove(file_path)
            return 0, [], False
        if os.path.exists(f'{rpa.config.D_RPA}\\chaidan\\' + file_path.split("\\")[-1]):
            os.remove(f'{rpa.config.D_RPA}\\chaidan\\' + file_path.split("\\")[-1])
        wb.SaveAs(f'{rpa.config.D_RPA}\\chaidan\\' + file_path.split("\\")[-1], FileFormat=51)
        wb.Close()
        excel.Application.Quit()
        if os.path.exists(file_path + "_文件损坏.xlsx"):
            os.remove(file_path + "_文件损坏.xlsx")
        os.remove(file_path)
        shutil.move(f'{rpa.config.D_RPA}\\chaidan\\' + file_path.split("\\")[-1], file_path)
        workbook = xlrd.open_workbook(file_path)
    sheet = workbook.sheet_by_index(0)
    if "机构类信息" in str(sheet.cell(0, 0).value).strip() or "机构类信息" in str(sheet.cell(1, 0).value).strip():
        return 0, [], True
    if str(sheet.cell(1, 0).value).strip() not in ["人员调配表单", "人员离退表单"] and ("新员工入职" not in str(
            sheet.cell(0, 0).value).strip() or "新员工入职" not in str(sheet.cell(1, 0).value).strip()):
        return 0, [], False
    count = 0
    cols = sheet.col_values(1)
    for i in range(6, len(cols)):
        if cols[i]:
            count += 1
            logging.info(str(sheet.col_values(3)[i]))
    return count, file_path, False


def random_worker(code, count):
    worker_dict = defaultdict(int)
    date = datetime.now().strftime("%Y%m01")
    with DbSession() as db_sess:
        result = db_sess.query(Event).filter_by(db_BJ=code).first()
        group, b_m = result.db_BL, result.db_BM
        if b_m == "1":
            return "常盛", "人事六组"
        worker_list = db_sess.query(TB_DIM_HR_STAFF).filter(TB_DIM_HR_STAFF.staff_group == group, TB_DIM_HR_STAFF.is_valid == 1).all()
        worker_list = [res.staff_name.strip() for res in worker_list if res.staff_name]
        code_list = db_sess.query(Event).filter_by(db_BL=group).all()
        _ = [worker_dict[res] for res in worker_list]
        code_list = [res.db_BJ for res in code_list if res.db_BJ]
        if count > 0:
            sql = db_sess.query(Log).filter(and_(Log.date >= date, Log.people_num > 0)).all()
            for res in sql:
                if res.worker in worker_list and code in code_list:
                    if res.grade is None or (res.people_num != "0" and res.grade == 0):
                        fen_shu = db_sess.query(func.sum(LogDetail.grade)).filter(LogDetail.log_id == res.id).scalar()
                        fen_shu = fen_shu if fen_shu else 0
                        db_sess.query(Log).filter(Log.sr == res.sr).update({"grade": fen_shu})
                        worker_dict[res.worker] += fen_shu
                    else:
                        worker_dict[res.worker] += res.grade
            db_sess.commit()
        else:
            sql = db_sess.query(Log).filter(and_(Log.date >= date, Log.people_num == 0)).all()
            for res in sql:
                if res.worker in worker_list and code in code_list:
                    if res.grade is None:
                        fen_shu = db_sess.query(func.sum(LogDetail.grade)).filter(LogDetail.log_id == res.id).scalar()
                        fen_shu = fen_shu if fen_shu else 0
                        total = db_sess.query(func.sum(LogDetail.people_num)).filter(LogDetail.log_id == res.id).scalar()
                        total = total if total else 0
                        try:
                            db_sess.query(Log).filter(Log.sr == res.sr).update({"grade": fen_shu, "people_num": total})
                        except Exception:
                            logging.info(f'{res.sr}数据被锁，跳过执行')
                    worker_dict[res.worker] += 1
            db_sess.commit()
    value = min(list(worker_dict.values()))
    logging.info(worker_dict)
    random_list = filter(lambda x: value == x[1], worker_dict.items())
    worker = random.choice([name for name, num in random_list])  # nosec
    return worker, group


def check_ftp(type_='拆单'):
    remote = remote_daiban + type_ + "/"
    # remote = "/HR人事/在职减册"
    with MYFTP() as my_ftp:
        files = my_ftp.get_all_files(remote)
        file_path = ""
        date = time.strftime("%Y%m%d %H:%M", time.localtime(time.time()))
        for file in files:
            first_name = file[len(remote.rstrip("/")):]
            file_path = f"{rpa.config.D_RPA}/GWBD/{date.split()[0]}/{first_name.split('/')[1]}"
            remote_dir = remote + "/" + first_name.split("/")[1]
            if len(first_name.split("/")) > 2:
                my_ftp.download_file_tree(f"{rpa.config.D_RPA}/GWBD/{date.split()[0]}/", remote_dir)
                my_ftp.rmd(remote_dir)
            else:
                my_ftp.download_file(file_path, remote_dir)
                my_ftp.delete(remote_dir)
            break
    if type_ == "拆单":
        count, file_list, flag = tmp_if(file_path, 0, [])
        return file_list
    return file_path
