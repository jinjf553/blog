#!/usr/bin/env python
# -*- coding: utf-8 -*-
# @File    : nei_tui.py
# @Author  : jinjianfeng
# @Contact : 553041800@qq.com
# @Link    : https://github.com/jinjf553
# @software: PyCharm
# @Date    : 2019/6/18 23:16
# @Version : ??
import logging
import os
import shutil
import time
from collections import defaultdict
from datetime import datetime

from openpyxl import load_workbook
from rpa.fastrpa.adtable import RED
from rpa.public.config import FILE_PATH, templates
from rpa.public.tools import cel, cells
from rpa.ssc.hr.orm.orm_ope import Query
from rpa.ssc.hr.orm.td_hr_li_tui_code_rulebase import LiTui
from rpa.ssc.hr.sap.export_other_103 import export_103_nei_tui
from rpa.ssc_kit.hr.kit_chai_dan.check_280 import (check_zhrpy280, create_dir,
                                                   get_date, get_grade)


def rulebase_12(file, file_str):
    wb = load_workbook(file)
    ws = wb.active
    # 规则 12.1.1  提取“人员离退表”的“事件类型”为“内退”的事件
    value_dict, li = defaultdict(list), []
    for i in range(7, len(ws["B"]) + 1):
        if ws["B%s" % str(i)].value and '内退' in str(ws["D%s" % str(i)].value):
            if cel(ws, f"B{i}") in li:
                cells(ws, "B%s" % str(i), "人员编号有重复项", RED)
            li.append(cel(ws, f"B{i}"))
            value_dict[cel(ws, f"B{i}")] = [str(j.value).strip() for j in ws["B%s:P%s" % (str(i), str(i))][0]]
    wb.save(file)
    if not li:
        logging.info("人员离退表中没有内退事件。")
        return

    date = get_date(value_dict)
    if not date or len(date) != 8:
        return
    export_103_nei_tui(None, li, date).save_to(FILE_PATH)
    wb_103 = load_workbook(FILE_PATH + "/C22_内退.xlsx")
    ws_103 = wb_103.active
    values_103 = defaultdict(list)
    for i in range(2, len(ws_103["A"]) + 1):
        for col in ["AD", "AE", "AF", "AG", "AI", "AH", "P", "Q", "R", "AN", "G", "J"]:
            values_103[str(ws_103["A%s" % str(i)].value).lstrip('0')].append(str(ws_103["%s%s" % (col, str(i))].value))

    rule_B = [res.rule_B for res in Query(table=LiTui) if res.rule_B]
    rule_C = [res.rule_C for res in Query(table=LiTui) if res.rule_C]
    rule_D = [res.rule_D for res in Query(table=LiTui) if res.rule_D]
    rule_AD = {res.rule_AD: [res.rule_AE, res.rule_AF, res.rule_AG, res.rule_AH, res.rule_AK,
                             res.rule_AJ] for res in Query(table=LiTui) if res.rule_AD}
    rule_AV = {res.rule_AV[:4]: res.rule_AV for res in Query(table=LiTui) if res.rule_AV}
    rule_A_B = defaultdict(list)
    a = (rule_A_B[res.rule_A].append(res.rule_B) for res in Query(table=LiTui) if res.rule_A)
    rule_A_C = defaultdict(list)
    a = (rule_A_C[res.rule_A].append(res.rule_C) for res in Query(table=LiTui) if res.rule_A)
    rule_A_D = defaultdict(list)
    a = (rule_A_D[res.rule_A].append(res.rule_D) for res in Query(table=LiTui) if res.rule_A)
    rule_O = [res.rule_O for res in Query(table=LiTui) if res.rule_O]
    rule_AX = [res.rule_AX for res in Query(table=LiTui) if res.rule_AX]

    wb_template = load_workbook(os.path.join(templates, "内退事件批导.xlsx"))
    ws_template = wb_template.active

    for num, (key, value) in enumerate(list(value_dict.items())):
        if key.lstrip('0') not in values_103.keys():
            cells(ws_template, "B%s" % str(num + 7), "103表中没有该人员编号，请核对", RED)
            continue

        # 规则 12.2.2 - 12.2.6  B-W
        for count, col in {0: "B", 1: "C", 3: "E", 4: "D", 5: "V", 6: "W", 14: "Z"}.items():
            ws_template["%s%s" % (col, str(num + 7))] = value[count] if value[count] != "None" else None

        # 规则 12.2.7  K-企业自定义分类
        if value[7] == "不变" and values_103[key.lstrip('0')][1] != "None":
            ws_template["K%s" % str(num + 7)] = values_103[key.lstrip('0')][0] + " " + values_103[key.lstrip('0')][1]
        elif value[7] and value[7] != "不变" and value[7] not in rule_B:
            cells(ws_template, "K%s" % str(num + 7), "企业自定义分类1非码值", RED)

        # 规则 12.2.8  T-调动后企业自定义分类2
        if value[8] is None:
            ws_template["T%s" % str(num + 7)] = "清空"
        elif value[8] == "不变" and values_103[key.lstrip('0')][3] != "None":
            ws_template["T%s" % str(num + 7)] = values_103[key.lstrip('0')][2] + " " + values_103[key.lstrip('0')][3]
        elif value[8] and value[8] != "不变" and value[8] not in rule_C:
            cells(ws_template, "T%s" % str(num + 7), "企业自定义分类2非码值", RED)

        # 规则 12.2.9  U-调动后企业自定义分类3
        if value[9] is None:
            ws_template["U%s" % str(num + 7)] = "清空"
        elif value[9] == "不变" and values_103[key.lstrip('0')][5] != "None":
            ws_template["U%s" % str(num + 7)] = values_103[key.lstrip('0')][4] + " " + values_103[key.lstrip('0')][5]
        elif value[9] and value[9] != "不变" and value[9] not in rule_D:
            cells(ws_template, "U%s" % str(num + 7), "企业自定义分类3非码值", RED)

        # 规则 12.2.10  G,H,F,J,M,E
        if value[5] in rule_AD.keys():
            for A, B in {"G": 0, "H": 1, "F": 2, "J": 3, "M": 4}.items():
                ws_template["%s%s" % (A, str(num + 7))] = rule_AD[value[5]][B]
        else:
            cells(ws_template, "F%s" % str(num + 7), "调动后机构岗位非码值", RED)
        if ws_template["J%s" % str(num + 7)].value != ws_template["W%s" % str(num + 7)].value:
            cells(ws_template, "J%s" % str(num + 7), "工资核算范围与企业表单不同", RED)
        if value[5] in rule_AD.keys() and rule_AD[value[5]][5] != ws_template["E%s" % str(num + 7)].value:
            cells(ws_template, "E%s" % str(num + 7), "内退原因需核对", RED)

        # 规则 12.3.2  X-调动前人事范围
        if values_103[key.lstrip('0')][6] in rule_AV.keys():
            ws_template["X%s" % str(num + 7)] = rule_AV[values_103[key.lstrip('0')][6]]

        # 规则 12.3.3  Y-调动前人事子范围
        ws_template["Y%s" % str(num + 7)] = ' '.join(values_103[key.lstrip('0')][7:9])

        # 规则 12.3.4  K-企业自定义分类
        if ws_template["K%s" % str(num + 7)].value and ws_template["K%s" % str(num + 7)].comment is None:
            if ws_template["G%s" % str(num + 7)].value in rule_A_B.keys():
                if ws_template["K%s" % str(num + 7)].value not in rule_A_B[ws_template["G%s" % str(num + 7)].value]:
                    cells(ws_template, "K%s" % str(num + 7), "企业自定义分类1与人事范围不匹配", RED)

        # 规则 12.3.5  T-企业自定义分类2
        if ws_template["T%s" % str(num + 7)].value and ws_template["T%s" % str(num + 7)].comment is None:
            if ws_template["G%s" % str(num + 7)].value in rule_A_C.keys():
                if ws_template["T%s" % str(num + 7)].value not in rule_A_C[ws_template["G%s" % str(num + 7)].value]:
                    cells(ws_template, "T%s" % str(num + 7), "企业自定义分类2与人事范围不匹配", RED)

        # 规则 12.3.6  U-企业自定义分类3
        if ws_template["U%s" % str(num + 7)].value and ws_template["U%s" % str(num + 7)].comment is None:
            if ws_template["G%s" % str(num + 7)].value in rule_A_D.keys():
                if ws_template["U%s" % str(num + 7)].value not in rule_A_D[ws_template["G%s" % str(num + 7)].value]:
                    cells(ws_template, "U%s" % str(num + 7), "企业自定义分类3与人事范围不匹配", RED)

        # 规则 12.3.7  A-序号
        ws_template["A%s" % str(num + 7)] = str(num + 1)

        # 规则 12.4.1  D-离退休时间
        try:
            time.strptime(str(ws_template["D%s" % str(num + 7)].value), '%Y%m%d')
            current_date = time.strftime("%d", time.localtime(time.time()))
            current_month = time.strftime("%Y%m01", time.localtime(time.time()))
            next_month = time.strftime("%Y%m01",
                                       time.localtime(time.time() + (32 - int(current_date)) * 24 * 60 * 60))
            if str(ws_template["D%s" % str(num + 7)].value) not in [current_month, next_month]:
                cells(ws_template, "D%s" % str(num + 7), "事件日期需核对", RED)
            if num != 0 and ws_template["D%s" % str(num + 6)].value != ws_template["D%s" % str(num + 7)].value:
                cells(ws_template, "D%s" % str(num + 7), "事件日期需核对", RED)
        except Exception:
            cells(ws_template, "D%s" % str(num + 7), "事件日期需核对", RED)

        # 规则 12.4.2  L-企业统计标识
        if [i for i in rule_O if values_103[key.lstrip('0')][9] in i]:
            ws_template["L%s" % str(num + 7)] = [i for i in rule_O if values_103[key.lstrip('0')][9] in i][0]

        # 规则 12.4.3  A-序列号
        if values_103[key.lstrip('0')][10] != "None":
            cells(ws_template, "A%s" % str(num + 7), "请注意该人员该月已做过事件", RED)

        # 规则 12.4.4  C-人员姓名
        if values_103[key.lstrip('0')][11] in rule_AX[9:15]:
            cells(ws_template, "C%s" % str(num + 7), "请核对该人员的岗位状态是否应做内退事件", RED)
    serial_id = datetime.now().strftime("%Y-%m-%d-%H-%M-%S-%f")
    wb_template.properties.description = serial_id
    wb_template.save(FILE_PATH + '/tmp-内退.xlsx')
    check_zhrpy280(FILE_PATH + '/tmp-内退.xlsx')
    local = create_dir(file, file_str)
    get_grade(f"{os.path.basename(file).split('-')[0][:10]}-XX-XX", value_dict, "内退", serial_id)
    shutil.move(FILE_PATH + "/C22_内退.xlsx", local + f"/103_内退事件_{os.path.basename(file)}")
    shutil.move(FILE_PATH + '/tmp-内退.xlsx', local + f"/{os.path.basename(file)[:10]}_内退事件批导模板.xlsx")
