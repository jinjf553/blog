# 该模块实现转寄功能
import logging
import random
import time

from rpa.public import tools
from rpa.ssc.hr.orm.orm_ope import Query, Update
from rpa.ssc.hr.orm.session import DbSession
from rpa.ssc.hr.orm.tb_dim_hr_staff import TB_DIM_HR_STAFF
from rpa.ssc.hr.orm.tb_hr_gangweibiandong_log import Log
from rpa.ssc_kit.hr.kit_chai_dan.download import random_worker
from rpa.ssc_kit.hr.kit_chai_dan.upload import login
from selenium.webdriver.common.by import By
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.support.wait import WebDriverWait


def send():
    dic = {res.sr: res.worker for res in Query(remark="待转寄")}
    for sr, worker in dic.items():
        send_on(sr, worker)
    logging.info(dic)


def send_on(sr, worker):
    browser = login()
    wait = WebDriverWait(browser, 30)
    page_num, WORKER_LIST, WORKERS = 0, [], []
    dic = {}  # {"X270": "陈文秀", "2620": "徐晓玲", "6310": "徐晓玲"}
    if sr:
        with DbSession() as s:
            res = s.query(Log).filter(Log.sr == sr)
            if res.first():
                if res.first().code in dic.keys():
                    worker = dic[res.first().code]
                    res.update({"worker": worker})
    while True:
        wait.until(lambda x: x.find_element_by_xpath('//*[@id="C13_W42_V43_ZHSFList_TableHeader"]'))
        srs = browser.find_elements_by_xpath('//*[@id="C13_W42_V43_ZHSFList_TableHeader"]/tbody/tr/td[5]/span')
        codes = browser.find_elements_by_xpath('//*[@id="C13_W42_V43_ZHSFList_TableHeader"]/tbody/tr/td[7]/span')
        if not sr or not worker:
            with DbSession() as s:
                for ss in srs:
                    res = s.query(Log).filter(Log.sr == ss.text).first()
                    if res:
                        if res.worker != "常盛" and res.remark != "未找到业务员":
                            sr, worker = res.sr, res.worker
                            break
                        elif res.remark == "未找到业务员":
                            code = codes[srs.index(ss)].text
                            worker, group = random_worker(code, int(res.people_num) if res.people_num and str(res.people_num).isdigit() else 0)
                            if code in dic.keys():
                                worker = dic[code]
                            s.query(Log).filter(Log.sr == ss.text).update({"worker": worker, 'remark': '待转寄'})
                    else:
                        sr, code = ss.text, codes[srs.index(ss)].text
                        worker = WORKER_LIST = [x.staff_name.strip() for x in s.query(TB_DIM_HR_STAFF).filter(TB_DIM_HR_STAFF.is_valid == 1).all()]
                        try:
                            worker, group = random_worker(code, 0)
                        except Exception:  # nosec
                            pass
                        if code in dic.keys():
                            worker = dic[code]
                        if isinstance(worker, list):
                            worker = random.choice(worker) if worker else "常盛"
                        s.add(Log(sr=sr, code=code, worker=worker, people_num='0', content='拆单异常'))
                        break

        if not sr or not worker:
            return

        if sr in [x.text for x in srs]:
            index = [x.text for x in srs].index(sr) + 1 + page_num * 10
            wait.until(lambda x: x.find_element_by_xpath(
                '//*[@id="C13_W42_V43_ZHSFList_sel_{}-rowsel"]'.format(index))).click()
            if tools.get_attr(browser, '//*[@id="C13_W42_V43_ZHSFList_sel_{}-rowsel"]'.format(index), 'title',
                              '取消选择表行'):
                wait.until(lambda x: x.find_element_by_xpath('//*[@id="C13_W42_V43_btn_Forward"]/span/b')).click()
                break
            else:
                logging.info(f'未选中要转寄的服务请求编号：{sr},可能原因：该服务请求编号正在被其他人操作！')
                browser.close()
                return '未选中要转寄的服务请求编号：' + sr + ',可能原因：该服务请求编号正在被其他人操作！'
        else:
            try:
                WebDriverWait(browser, 3).until(
                    lambda x: x.find_element_by_xpath('//*[@id="C13_W42_V43_ZHSFList_pag_fwd"]/span')).click()
                time.sleep(1)
            except Exception:
                logging.info(f'遍历到最后一页未找到服务请求编号：{sr},可能原因：该服务请求编号提供有误！')
                Update(sr=sr, result="成功", remark="", step="转寄完成")
                browser.close()
                return f'遍历到最后一页未找到服务请求编号：{sr},可能原因：该服务请求编号提供有误！'

    handles = tools.windowlist(browser)  # 获取所有window窗口
    browser.switch_to.window(handles[1])
    wait.until(EC.frame_to_be_available_and_switch_to_it((By.XPATH, '//*[@id="WorkAreaFrame1popup"]')))
    wait.until(lambda x: x.find_element_by_xpath('//*[@id="C15_W48_V50_bpnumber_bp_number"]')).click()
    handles = tools.windowlist(browser, 3)  # 获取所有window窗口
    browser.switch_to.window(handles[2])
    wait.until(EC.frame_to_be_available_and_switch_to_it((By.XPATH, '//*[@id="WorkAreaFrame1popup"]')))
    wait.until(lambda x: x.find_element_by_xpath('//*[@id="C16_W52_V54_thtmlb_button_1"]/img')).click()
    page_text = wait.until(lambda x: x.find_element_by_xpath('//*[@id="C16_W52_V54_OrgTree-footer"]/div/div/ul')).text
    page_list = [text for text in page_text.split()]
    if "前进" == page_list[-1]:
        page_num = int(page_list[-2])
    elif page_list:
        page_num = int(page_list[-1])
    else:
        page_num = 1
    for page in range(page_num):
        if page != 0:
            wait.until(lambda x: x.find_element_by_xpath('//*[@id="C16_W52_V54_OrgTree_pag_fwd"]/span')).click()
        wait.until(lambda x: x.find_element_by_xpath('//*[@id="C16_W52_V54_OrgTree__%s__1"]' % str(page * 20 + 1)))
        workers = wait.until(lambda x: x.find_elements_by_xpath('//*[@id="C16_W52_V54_OrgTree_TableHeader"]/tbody/tr//tr'))
        # if isinstance(worker, list):
        #     # worker = [x for x in worker if x in [workers[i].text.replace(' ', '') for i in range(len(workers))]]
        #     worker = random.choice(worker) if worker else "常盛"
        if worker.replace(' ', '') in [workers[i].text.replace(' ', '') for i in range(len(workers))]:
            index = [workers[i].text.replace(' ', '') for i in range(len(workers))].index(worker.replace(' ', '')) + page * 20 + 1
            wait.until(
                lambda x: x.find_element_by_xpath('//*[@id="C16_W52_V54_horgtree_table[{}].stext"]'.format(index))).click()
            browser.switch_to.window(handles[1])
            wait.until(EC.frame_to_be_available_and_switch_to_it((By.XPATH, '//*[@id="WorkAreaFrame1popup"]')))
            time.sleep(2)
            wait.until(lambda x: x.find_element_by_xpath('//*[@id="C15_W48_V50_zreason_zj_reason"]')).clear()
            wait.until(lambda x: x.find_element_by_xpath('//*[@id="C15_W48_V50_zreason_zj_reason"]')).send_keys("RPA转寄")
            wait.until(lambda x: x.find_element_by_xpath('//*[@id="C15_W48_V50_btn_Select"]/span/b')).click()  # 转寄
            time.sleep(3)
            browser.switch_to.window(handles[0])
            Update(sr=sr, result="成功", remark="", step="转寄完成")
            break
        else:
            for i in range(len(workers)):
                if workers[i].text.replace(' ', '') in WORKER_LIST:
                    WORKERS.append(workers[i].text.replace(' ', ''))
    else:
        if WORKERS:
            worker2 = random.choice(WORKERS)
        else:
            worker2 = '常盛'
        wait.until(lambda x: x.find_element_by_xpath('//*[@id="C16_W52_V54_OrgTree_pag_fst"]/span')).click()  # 点击第一页
        for page in range(page_num):
            if page != 0:
                wait.until(lambda x: x.find_element_by_xpath('//*[@id="C16_W52_V54_OrgTree_pag_fwd"]/span')).click()
            wait.until(lambda x: x.find_element_by_xpath('//*[@id="C16_W52_V54_OrgTree__%s__1"]' % str(page * 20 + 1)))
            workers = wait.until(
                lambda x: x.find_elements_by_xpath('//*[@id="C16_W52_V54_OrgTree_TableHeader"]/tbody/tr//tr'))
            if worker2.replace(' ', '') in [workers[i].text.replace(' ', '') for i in range(len(workers))]:
                index = [workers[i].text.replace(' ', '') for i in range(len(workers))].index(
                    worker2.replace(' ', '')) + page * 20 + 1
                wait.until(
                    lambda x: x.find_element_by_xpath(
                        '//*[@id="C16_W52_V54_horgtree_table[{}].stext"]'.format(index))).click()
                browser.switch_to.window(handles[1])
                wait.until(EC.frame_to_be_available_and_switch_to_it((By.XPATH, '//*[@id="WorkAreaFrame1popup"]')))
                time.sleep(0.5)
                wait.until(lambda x: x.find_element_by_xpath('//*[@id="C15_W48_V50_zreason_zj_reason"]')).clear()
                wait.until(lambda x: x.find_element_by_xpath('//*[@id="C15_W48_V50_zreason_zj_reason"]')).send_keys(
                    f"RPA转寄,业务员[{worker}]不存在,随机转寄。{'可转寄人员开关均未打开' if worker2 == '常盛' else ''}")
                wait.until(lambda x: x.find_element_by_xpath('//*[@id="C15_W48_V50_btn_Select"]/span/b')).click()  # 转寄
                time.sleep(3)
                browser.switch_to.window(handles[0])
                Update(sr=sr, result="成功", remark="", step="转寄完成", worker=worker2)
                break
        else:
            browser.close()
            browser.switch_to.window(handles[1])
            browser.close()
            browser.switch_to.window(handles[0])
            Update(sr=sr, remark="未找到业务员", result="失败")
    browser.close()


if __name__ == "__main__":
    with DbSession() as s:
        WORKER_LIST = [x.staff_name.strip() for x in s.query(TB_DIM_HR_STAFF).filter(TB_DIM_HR_STAFF.is_valid == 1).all()]
        print(WORKER_LIST)
