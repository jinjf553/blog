#!/usr/bin/env python
# -*- coding: utf-8 -*-
# @File    : li_zhi_dev.py
# @Author  : jinjianfeng
import logging
import os
import re
import shutil
import time
from collections import defaultdict
from datetime import datetime

from openpyxl import load_workbook
from rpa.fastrpa.adtable import BLUE, RED
from rpa.public.config import FILE_PATH, templates
from rpa.public.tools import cel, cells
from rpa.ssc.hr.orm.orm_ope import Query
from rpa.ssc.hr.orm.td_hr_li_tui_code_rulebase import LiTui
from rpa.ssc.hr.sap.export_other_103 import (export_103_li_zhi2,
                                             export_103_li_zhi3)
from rpa.ssc_kit.hr.kit_chai_dan.check_280 import (check_zhrpy280, create_dir,
                                                   get_date, get_grade,
                                                   get_info)


def rulebase_14(file, file_str):
    wb = load_workbook(file)
    ws = wb.active
    # 规则 14.1.1  提取“人员离退表”的“事件类型”为“离职”的事件
    value_dict, li = defaultdict(list), []
    for i in range(7, len(ws["B"]) + 1):
        if ws["B%s" % str(i)].value and '离职' in str(ws["D%s" % str(i)].value):
            if cel(ws, f"B{i}") in li:
                cells(ws, "B%s" % str(i), "人员编号有重复项", RED)
            if cel(ws, f"B{i}").strip().isdigit():
                li.append(cel(ws, f"B{i}").strip())
            value_dict[cel(ws, f"B{i}").lstrip('0')] = [str(j.value).strip() for j in ws[f"B{i}:T{i}"][0]]
    wb.save(file)
    # B-14.1.2	通过组合逻辑查询下载离职C23-2、C23-3
    if not li:
        logging.info("人员离退表中没有离职事件。")
        return
    date = get_date(value_dict)
    if not date or len(date) != 8:
        return
    export_103_li_zhi2(None, li, date).save_to(FILE_PATH)

    try:
        time_stamp = time.mktime(time.strptime(date, "%Y%m%d"))
        yesterday = time.strftime("%Y%m%d", time.localtime(int(time_stamp) - 24 * 60 * 60))
    except Exception:
        yesterday = date
    export_103_li_zhi3("reuse", li, yesterday).save_to(FILE_PATH)

    wb_103 = load_workbook(FILE_PATH + "/C23-2离职.xlsx")
    ws_103 = wb_103.active
    values_103 = defaultdict(list)
    for i in range(2, len(ws_103["A"]) + 1):
        for x in ["C", "D", "F", "L", "M", "O", "AS", "AT", "AV", "BA", "BB", "BD", "BK", "BM"]:
            ws_103[f"{x}{i}"] = cel(ws_103, f"{x}{i}").replace(".", "").replace("00000000", "")
        for col in ["AO", "BM", "R", "P", "BK", "CB", "G", "J", "AP", "AT", "BB", "BO", "BK", "BM"]:
            values_103[cel(ws_103, f"A{i}").lstrip('0')].append(cel(ws_103, f"{col}{i}"))
    wb_103.save(FILE_PATH + "/C23-2离职.xlsx")

    wb_103 = load_workbook(FILE_PATH + "/C23-3劳动合同.xlsx")
    ws_103 = wb_103.active
    values_103_1 = defaultdict(list)
    for i in range(2, len(ws_103["A"]) + 1):
        for x in ["D", "E", "G", "P"]:
            ws_103[f"{x}{i}"] = cel(ws_103, f"{x}{i}").replace(".", "").replace("00000000", "")
        for col in ["D", "E", "Z"]:
            values_103_1[cel(ws_103, f"A{i}").lstrip('0')].append(cel(ws_103, f"{col}{i}"))
    wb_103.save(FILE_PATH + "/C23-3劳动合同.xlsx")

    rule_s = [str(res.db_S).strip() for res in Query(LiTui) if res.db_S]

    wb_t = load_workbook(os.path.join(templates, "离职事件模板表.xlsx"))
    ws_t = wb_t.active
    for i, (key, value) in enumerate(list(value_dict.items())):
        logging.info(f"正在生成并校验离职模板第{i + 1}条数据...")
        if key.lstrip('0') not in values_103.keys():
            cells(ws_t, "B%s" % str(i + 7), "103表中没有该人员编号，请核对", RED)
            continue

        ws_t[f"A{i+7}"] = str(i + 1)

        # 规则 B-14.1.4 - 14.2.3  B-D
        for count, col in {0: "B", 1: "C", 3: "E", 4: "D", 15: "AE", 16: "AA", 17: "AB"}.items():
            ws_t[f"{col}{i+7}"] = value[count] if value[count] != "None" else None
        # 规则 B-14.1.5  B-14.1.6
        ws_t[f"I{i + 7}"] = value[3] if value[3] != "None" else None
        cur_month = time.strftime("%Y%m01")
        cur_day = time.strftime("%d")
        nex_month = time.strftime("%Y%m01", time.localtime(time.time() + (32 - int(cur_day)) * 24 * 60 * 60))
        if cel(ws_t, f"D{i+7}") not in [cur_month, nex_month]:
            cells(ws_t, f"D{i+7}", "事件执行日期不为1日！", RED)

        # 规则 B-14.1.7  AC-合同解除/终止日期
        if value[13] not in [None, "None", ""]:
            ws_t[f"AC{i+7}"] = "".join(re.findall(r"\d+", str(value[13].replace(".", ''))))

        # 规则 B-14.1.8  K-单位支付补偿金额
        if value[14] not in [None, "None", ""]:
            try:
                a = '%.2f' % float(value[14])
                ws_t["K%s" % str(i + 7)] = str(a)
                if float(a) >= 10000000.0:
                    raise Exception("")
            except Exception:
                cells(ws_t, f"K{i+7}", "单位支付补偿金额有误！", RED)

        # 规则 B-14.2.1  E-减册原因
        if ws_t["E%s" % str(i + 7)].value not in rule_s:
            cells(ws_t, "E%s" % str(i + 7), "事件原因非码值！", RED)

        # 规则 B-14.2.2  AA-停薪日期
        if values_103[key.lstrip('0')][3] in ["X480", "X48Z", "X481"]:
            if cel(ws_t, f"AA{i+7}") not in ["None", None, ""]:
                try:
                    tmp_date = ''.join(re.findall(r"\d+", cel(ws_t, f"AA{i+7}")))
                    time.strptime(tmp_date, '%Y%m%d')
                    ws_t[f"AA{i+7}"] = tmp_date
                    if int(tmp_date) < int(time.strftime("%Y%m%d")) or tmp_date[-2:] != "01":
                        cells(ws_t, f"AA{i+7}", "停薪日期有误！", RED)
                except Exception:
                    cells(ws_t, f"AA{i+7}", "停薪日期有误！", RED)

        # 规则 B-14.2.3
        if len(values_103_1[key]) == 3 and not values_103_1[key][1]:
            cells(ws, f"T{i+7}", "不存在需要定界的劳动合同！", BLUE)
        else:
            if key in values_103_1.keys():
                ws[f"F{i+7}"], ws[f"T{i+7}"] = values_103_1[key][:2]
                try:
                    tmp_ls = values_103_1[key]
                    for x in range(0, len(tmp_ls), 3):
                        if tmp_ls[x] and int(cel(ws, f"D{i+7}")) <= int(tmp_ls[x]):
                            cells(ws, f"S{i+7}", "该人存在未来时间的劳动合同，请与企业确认如何处理！", RED)
                except Exception:
                    cells(ws, f"S{i+7}", "D列减册日期非正确值", RED)

        # 规则 B-14.2.4
        cur_day = time.strftime("%d")
        last_month = time.strftime("%Y%m", time.localtime(time.time() - (5 + int(cur_day)) * 24 * 60 * 60))
        cur_month = time.strftime("%Y%m")
        next_month = time.strftime("%Y%m", time.localtime(time.time() + (32 - int(cur_day)) * 24 * 60 * 60))
        if cel(ws_t, f"AC{i+7}"):
            try:
                tmp_date = ''.join(re.findall(r"\d+", cel(ws_t, f"AC{i+7}")))
                time.strptime(tmp_date, '%Y%m%d')
                ws_t[f"AC{i+7}"] = tmp_date
                try:
                    time.strptime(value[4], "%Y%m%d")
                    if value[4][:-2] in [last_month, cur_month, next_month]:
                        if value[4][-2:] == "01" and int(cel(ws_t, f"AC{i+7}")) > int(value[4]):
                            cells(ws_t, f"AC{i+7}", "企业填写的劳动合同解除日期有误！", RED)
                        elif value[4][-2:] != "01" and int(cel(ws_t, f"AC{i+7}")) >= int(value[4]):
                            cells(ws_t, f"AC{i+7}", "企业填写的劳动合同解除日期有误！", RED)
                except Exception:
                    cells(ws_t, f"D{i+7}", "企业表单中事件执行日期非常识日期！", RED)
            except Exception:
                cells(ws_t, f"AC{i+7}", "企业填写的劳动合同解除日期有误！", RED)

        # 规则 B-14.2.5
        if cel(ws_t, f"AC{i+7}"):
            try:
                if int(cel(ws_t, f"F{i+7}")) > int(cel(ws_t, f"AC{i+7}")):
                    cells(ws_t, f"AC{i+7}", "企业填写的劳动合同解除日期早于或等于合同开始日期！", RED)
            except Exception:
                logging.info("Warning: 离职模板F或者AC的日期有误")

        # 规则 B-14.2.6
        if ws_t[f"T{i+7}"].comment is None:
            if value[4][:-2] in [last_month, cur_month, next_month] and value[4][-2:] == "01":
                tmp_date = time.strptime(value[4], "%Y%m%d")
                time_stamp = time.mktime(tmp_date)
                yesterday = time.strftime("%Y%m%d", time.localtime(int(time_stamp) - 24 * 60 * 60))
                ws_t[f"G{i+7}"] = yesterday
            elif value[4][:-2] in [last_month, cur_month, next_month] and value[4][-2:] != "01":
                ws_t[f"G{i+7}"] = value[4]
            else:
                cells(ws_t, f"G{i+7}", "离职RPA只执行上月、当月、次月的事件！", RED)

        # 规则 B-14.2.7、 B-14.2.7、 B-14.2.8、 B-14.2.9、 B-14.2.10、 B-14.2.11
        for x, y in {9: "Y", 10: "AD", 11: "Z", 12: "W", 13: "X"}.items():
            try:
                tmp_date = time.mktime(time.strptime(value[4], "%Y%m%d"))
                yesterday = time.strftime("%Y%m%d", time.localtime(int(tmp_date) - 24 * 60 * 60))
            except Exception:
                cells(ws_t, f"D{i+7}", "离退表单中执行事件日期有误！", RED)
                break
            if values_103[key.lstrip("0")][x] not in ["None", None, ""]:
                ws_t[f"{y}{i+7}"] = yesterday
        # 规则 B-14.3.2
        if values_103[key.lstrip("0")][6] not in ["None", None, ""]:
            cells(ws_t, f"A{i+7}", "请注意该人员该月已做过事件", RED)

        # 规则 B-14.3.3

    serial_id = datetime.now().strftime("%Y-%m-%d-%H-%M-%S-%f")
    wb_t.properties.description = serial_id
    wb_t.save(FILE_PATH + '/tmp-离职.xlsx')
    # B-14.3.1
    check_zhrpy280(FILE_PATH + '/tmp-离职.xlsx')
    local = create_dir(file, file_str)
    sr, code, worker = get_info(file, file_str)
    get_grade(f"{os.path.basename(file).split('-')[0][:10]}-XX-XX", value_dict, "在职人员减册", serial_id)
    shutil.move(FILE_PATH + "/C23-3劳动合同.xlsx", local + f"/103_C23-3劳动合同_{os.path.basename(file)}")
    shutil.move(FILE_PATH + "/C23-2离职.xlsx", local + f"/103_C23-2离职_{os.path.basename(file)}")
    shutil.move(FILE_PATH + '/tmp-离职.xlsx', local + f"/{sr}-{code}-离职-{worker}.xlsx")
