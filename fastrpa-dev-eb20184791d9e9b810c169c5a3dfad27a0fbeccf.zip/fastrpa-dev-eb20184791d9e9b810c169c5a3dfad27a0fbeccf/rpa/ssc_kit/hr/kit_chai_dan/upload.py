# 该模块实现文件上传功能
import logging
import os
import shutil
import time

import psutil
import rpa.config
import win32con
import win32gui
from rpa.config import CHROME_DRIVER_EXE_PATH
from rpa.fastrpa.third_party.zip7 import ZIP7_EXE_PATH
from rpa.public.config import (fso_user, recv_user, remote_robotA_path,
                               send_mail)
from rpa.public.myftp import MYFTP
from rpa.ssc.hr.orm.orm_ope import DbSession
from rpa.ssc.hr.orm.tb_dim_hr_staff import TB_DIM_HR_STAFF
from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.support.wait import WebDriverWait


def login(chrome="chrome_default", user="", pwd=""):  # nosec
    chrome_path = os.path.expanduser("~")
    Temp_path = f'{chrome_path}/Appdata/Local/Temp'
    for file in os.listdir(Temp_path):
        try:
            if os.path.isdir(rf"{Temp_path}\{file}"):
                shutil.rmtree(rf"{Temp_path}\{file}")
            else:
                os.remove(rf"{Temp_path}\{file}")
        except Exception:  # nosec
            pass
    username, password, address = fso_user()
    username, password = (user, pwd) if user and pwd else (username, password)
    try:
        [p.kill() for p in psutil.process_iter() if p.name() in [f'{chrome}driver.exe', f'{chrome}.exe']]
    except Exception:  # nosec
        pass
    chromeOptions = webdriver.ChromeOptions()
    pref = {
        "profile.managed_default_content_settings.images": 1,
        "profile.content_settings.plugin_whitelist.adobe-flash-player": 1,
        "profile.content_settings.exceptions.plugins.*,*.per_resource.adobe-flash-player": 1,
    }
    chromeOptions.add_experimental_option('prefs', pref)
    chromeOptions.add_argument('disable-infobars')
    chromeOptions.add_argument('--no-sandbox')

    if not os.path.exists(f"{chrome_path}/tmp/Chromium.7z"):
        with MYFTP() as ftp:
            ftp.download_file(f"{chrome_path}/tmp/Chromium.7z", "/安装包/谷歌浏览器/Chromium.7z")
    if not os.path.exists(f"{chrome_path}/Chrome/{chrome}/{chrome}.exe"):
        cmd = f'{ZIP7_EXE_PATH} x "{chrome_path}/tmp/Chromium.7z" -o"{chrome_path}/tmp/{chrome}" -aos -r'
        os.system(cmd)
        # shutil.rmtree(f"{chrome_path}/Chrome/{chrome}")
        shutil.move(f"{chrome_path}/tmp/{chrome}/Chromium", f"{chrome_path}/Chrome/{chrome}")
        shutil.move(f"{chrome_path}/Chrome/{chrome}/chrome.exe", f"{chrome_path}/Chrome/{chrome}/{chrome}.exe")
    chrome_driver = f"{chrome_path}/Chrome/{chrome}/{chrome}driver.exe"
    if not os.path.exists(chrome_driver):
        shutil.copy(CHROME_DRIVER_EXE_PATH, chrome_driver)
    chromeOptions.binary_location = f"{chrome_path}/Chrome/{chrome}/{chrome}.exe"
    try:
        browser = webdriver.Chrome(executable_path=chrome_driver, chrome_options=chromeOptions)
    except Exception:
        shutil.rmtree(f"{chrome_path}/tmp")
        shutil.rmtree(f"{chrome_path}/Chrome")
        browser = login(chrome)
        return browser
    browser.get(address)
    browser.maximize_window()
    wait = WebDriverWait(browser, 40)
    if '待办事项' in browser.title:
        return browser
    else:
        wait.until(lambda x: x.find_element_by_xpath('//*[@id="j_username"]')).send_keys("z")
        wait.until(lambda x: x.find_element_by_xpath('//*[@id="j_username"]')).clear()
        wait.until(lambda x: x.find_element_by_xpath('//*[@id="j_username"]')).send_keys(username)
        wait.until(lambda x: x.find_element_by_xpath('//*[@id="j_password"]')).send_keys("p")
        wait.until(lambda x: x.find_element_by_xpath('//*[@id="j_password"]')).clear()
        wait.until(lambda x: x.find_element_by_xpath('//*[@id="j_password"]')).send_keys(password)
        try:
            wait.until(lambda x: x.find_element_by_xpath('//*[@id="authen1Form"]/button')).click()
        except Exception:
            print("**************************************************************************")
        try:
            wait.until(EC.frame_to_be_available_and_switch_to_it((By.XPATH, '//*[@id="CRMApplicationFrame"]')))
            wait.until(EC.frame_to_be_available_and_switch_to_it((By.XPATH, '//*[@id="WorkAreaFrame1"]')))
        except Exception:
            try:
                error_info = wait.until(lambda x: x.find_element_by_xpath('//*[@id="errorDivMsg"]')).text
                if "认证失败" in error_info:
                    with DbSession() as session:
                        session.query(TB_DIM_HR_STAFF).filter(TB_DIM_HR_STAFF.fso_username == username).update({'fso_state': 1})
                        # session.query(rpa.ssc.hr.orm.tb_user.User).filter_by(username=username).update({'state': '0'})
                    send_mail(recv_user(), username)
                    raise Exception('SAP认证失败')
            except Exception as e:
                raise e
    return browser


def switch_to_frame(browser):
    wait = WebDriverWait(browser, 20)
    wait.until(EC.frame_to_be_available_and_switch_to_it((By.XPATH, '//*[@id="CRMApplicationFrame"]')))
    wait.until(EC.frame_to_be_available_and_switch_to_it((By.XPATH, '//*[@id="WorkAreaFrame1"]')))


def upload(sr, paths):
    date = time.strftime("%Y%m%d")
    with MYFTP() as ftp:
        ftp.upload_file_tree(paths, f"{remote_robotA_path}/{date[:6]}/{date}/{os.path.basename(paths)}")
        local_dir = rf"{rpa.config.D_RPA}\HR人事\拆单\{date[:6]}\{date}"
        if not os.path.exists(local_dir):
            os.makedirs(local_dir)
        if os.path.exists(f'{local_dir}/{os.path.basename(paths)}'):
            try:
                os.rename(f'{local_dir}/{os.path.basename(paths)}', f'{local_dir}/{os.path.basename(paths)}_{time.strftime("%H%M%S")}')
            except Exception:  # nosec
                local_dir += f"/{os.path.basename(paths)}_new{time.strftime('%H%M%S')}"
        shutil.copytree(paths, f'{local_dir}/{os.path.basename(paths)}')


def up_files(file_path, classs, text):
    flag = False
    for i in range(120):
        dialog = win32gui.FindWindow(classs, text)  # 对话框
        logging.info(f'寻找{classs}-{text}对话框')
        if dialog:
            flag = True
            logging.info(f'找到{classs}-{text}对话框')
            ComboBoxEx32 = win32gui.FindWindowEx(dialog, 0, 'ComboBoxEx32', None)
            ComboBox = win32gui.FindWindowEx(ComboBoxEx32, 0, 'ComboBox', None)
            Edit = win32gui.FindWindowEx(ComboBox, 0, 'Edit', None)  # 上面三句依次寻找对象，直到找到输入框Edit对象的句柄
            logging.info(f'找到Edit句柄：{Edit}')
            button = win32gui.FindWindowEx(dialog, 0, 'Button', None)  # 确定按钮Button
            ret_code = win32gui.SendMessage(Edit, win32con.WM_SETTEXT, 0, file_path)  # 往输入框输入绝对地址
            logging.info(f'SendMessage填充文件路径{file_path}，返回值：{ret_code}')
            ret_code = win32gui.SendMessage(dialog, win32con.WM_COMMAND, 1, button)  # 按button
            logging.info(f'SendMessage点击确认按钮{button}，返回值：{ret_code}')
            break
        time.sleep(0.5)
    if flag is False:
        logging.error(f'未找到{classs}-{text}对话框')


if __name__ == "__main__":
    login(chrome="chrometest")
