#!/usr/bin/env python
# -*- coding: utf-8 -*-
# @File    : li_tui_xiu_jian_ce.py
# @Author  : jinjianfeng
# @Contact : 553041800@qq.com
# @Link    : https://github.com/jinjf553
# @software: PyCharm
# @Date    : 2019/6/19 1:48
# @Version : ??
import logging
import os
import shutil
import time
from collections import defaultdict
from datetime import datetime

from openpyxl import load_workbook
from rpa.fastrpa.adtable import RED
from rpa.public.config import FILE_PATH, templates
from rpa.public.tools import cel, cells
from rpa.ssc.hr.orm.orm_ope import Query
from rpa.ssc.hr.orm.td_hr_li_tui_code_rulebase import LiTui
from rpa.ssc.hr.sap.export_other_103 import export_103_li_tui_xiu_jian_ce
from rpa.ssc_kit.hr.kit_chai_dan.check_280 import (check_zhrpy280, create_dir,
                                                   get_date, get_grade)


def rulebase_13(file, file_str):
    wb = load_workbook(file)
    ws = wb.active
    # 规则 13.1.1  提取“人员离退表”的“事件类型”为“离退休减册”的事件
    value_dict, li = defaultdict(list), []
    for i in range(7, len(ws["B"]) + 1):
        if ws["B%s" % str(i)].value and '离退休减册' in str(ws["D%s" % str(i)].value):
            if cel(ws, f"B{i}") in li:
                cells(ws, "B%s" % str(i), "人员编号有重复项", RED)
            li.append(cel(ws, f"B{i}"))
            value_dict[cel(ws, f"B{i}")] = [str(j.value).strip() for j in ws["B%s:P%s" % (str(i), str(i))][0]]
    wb.save(file)
    if not li:
        logging.info("人员离退表中没有离退休减册事件。")
        return

    date = get_date(value_dict)
    if not date or len(date) != 8:
        return
    if date == "None":
        return
    export_103_li_tui_xiu_jian_ce(None, li, date).save_to(FILE_PATH)
    wb_103 = load_workbook(FILE_PATH + "/C21_离退休减册.xlsx")
    ws_103 = wb_103.active
    values_103 = defaultdict(list)
    for i in range(2, len(ws_103["A"]) + 1):
        for col in ["U", "AH", "AI", "AJ", "AK", "AO", "AP", "G", "S", "J"]:
            values_103[str(ws_103["A%s" % str(i)].value).lstrip('0')].append(str(ws_103["%s%s" % (col, str(i))].value))

    rule_G = [res.rule_G for res in Query(table=LiTui) if res.rule_G]
    rule_P = [res.rule_P for res in Query(table=LiTui) if res.rule_P]
    rule_AP = [res.rule_AP for res in Query(table=LiTui) if res.rule_AP]
    rule_AQ = [res.rule_AQ for res in Query(table=LiTui) if res.rule_AQ]
    rule_O = [res.rule_O for res in Query(table=LiTui) if res.rule_O]
    rule_AO = [res.rule_AO for res in Query(table=LiTui) if res.rule_AO]
    rule_AX = [res.rule_AX for res in Query(table=LiTui) if res.rule_AX]

    wb_template = load_workbook(os.path.join(templates, "离退休减册事件批导.xlsx"))
    ws_template = wb_template.active

    for num, (key, value) in enumerate(list(value_dict.items())):
        if key.lstrip('0') not in values_103.keys():
            cells(ws_template, "B%s" % str(num + 7), "103表中没有该人员编号，请核对", RED)
            continue

        # 规则 13.2.1 - 13.2.5  B-R
        for count, col in {0: "B", 1: "C", 3: "E", 4: "D", 11: "O", 14: "R"}.items():
            ws_template["%s%s" % (col, str(num + 7))] = value[count] if value[count] != "None" else None

        # 规则 13.2.6  F-人员组
        ws_template["F%s" % str(num + 7)] = "S 离退休后减册人员"

        # 规则 13.2.7  H-工资核算范围
        ws_template["H%s" % str(num + 7)] = "00 不发工资"

        # 规则 13.3.1  G-人员子组
        if [i for i in rule_G if values_103[key.lstrip('0')][0] in i]:
            ws_template["G%s" % str(num + 7)] = [i for i in rule_G if values_103[key.lstrip('0')][0] in i][0]

        # 规则 13.3.2  I-离(退)休人员类别
        if [i for i in rule_P if values_103[key.lstrip('0')][1] in i]:
            ws_template["I%s" % str(num + 7)] = [i for i in rule_P if values_103[key.lstrip('0')][1] in i][0]

        # 规则 13.3.3  J-离(退)休后享受待遇级别
        if [i for i in rule_AP if values_103[key.lstrip('0')][2] in i]:
            ws_template["J%s" % str(num + 7)] = [i for i in rule_AP if values_103[key.lstrip('0')][2] in i][0]

        # 规则 13.3.4  K-离（退）休人员来源
        if [i for i in rule_AQ if values_103[key.lstrip('0')][3] in i]:
            ws_template["K%s" % str(num + 7)] = [i for i in rule_AQ if values_103[key.lstrip('0')][3] in i][0]

        # 规则 13.3.5  L-离(退)休后管理单位
        ws_template["AK%s" % str(num + 7)] = values_103[key.lstrip('0')][4]

        # 规则 13.3.6  P-返聘标识
        if [i for i in rule_O if values_103[key.lstrip('0')][5] in i]:
            ws_template["P%s" % str(num + 7)] = [i for i in rule_O if values_103[key.lstrip('0')][5] in i][0]

        # 规则 13.3.7  Q-领取企业年金标识
        if [i for i in rule_O if values_103[key.lstrip('0')][6] in i]:
            ws_template["Q%s" % str(num + 7)] = [i for i in rule_O if values_103[key.lstrip('0')][6] in i][0]

        # 规则 13.3.8  A-序号
        ws_template["A%s" % str(num + 7)] = str(num + 1)

        # 规则 13.4.2  E-离退休减册事件原因
        if ws_template["E%s" % str(num + 7)].value not in rule_AO:
            cells(ws_template, "E%s" % str(num + 7), "事件原因非码值", RED)

        # 规则 13.4.3  D-离退休时间
        try:
            time.strptime(str(ws_template["D%s" % str(num + 7)].value), '%Y%m%d')
            current_date = time.strftime("%d", time.localtime(time.time()))
            current_month = time.strftime("%Y%m01", time.localtime(time.time()))
            next_month = time.strftime("%Y%m01",
                                       time.localtime(time.time() + (32 - int(current_date)) * 24 * 60 * 60))
            if str(ws_template["D%s" % str(num + 7)].value) not in [current_month, next_month]:
                cells(ws_template, "D%s" % str(num + 7), "事件日期需核对", RED)
            if num != 0 and ws_template["D%s" % str(num + 6)].value != ws_template["D%s" % str(num + 7)].value:
                cells(ws_template, "D%s" % str(num + 7), "事件日期需核对", RED)
        except Exception:
            cells(ws_template, "D%s" % str(num + 7), "事件日期需核对", RED)

        # 规则 13.4.4  A-序列号
        if values_103[key.lstrip('0')][7] != "None":
            cells(ws_template, "A%s" % str(num + 7), "请注意该人员该月已做过事件", RED)

        # 规则 13.4.5  F-人员组
        if values_103[key.lstrip('0')][8] != "K":
            cells(ws_template, "F%s" % str(num + 7), "此人不是离退休人员！", RED)

        # 规则 13.4.6  C-人员姓名
        if values_103[key.lstrip('0')][9] == rule_AX[9]:
            cells(ws_template, "C%s" % str(num + 7), "请核对该人员的岗位状态是否正确", RED)
    serial_id = datetime.now().strftime("%Y-%m-%d-%H-%M-%S-%f")
    wb_template.properties.description = serial_id
    wb_template.save(FILE_PATH + '/tmp-减册.xlsx')
    check_zhrpy280(FILE_PATH + '/tmp-减册.xlsx')
    local = create_dir(file, file_str)
    get_grade(f"{os.path.basename(file).split('-')[0][:10]}-XX-XX", value_dict, "离退休减册", serial_id)
    shutil.move(FILE_PATH + "/C21_离退休减册.xlsx", local + f"/103_离退休减册_{os.path.basename(file)}")
    shutil.move(FILE_PATH + '/tmp-减册.xlsx', local + f"/{os.path.basename(file)[:10]}_离退休减册模板.xlsx")
