#!/usr/bin/env python
# -*- coding: utf-8 -*-
# @File    : sap.py
# @Author  : jinjianfeng
# @Contact : 553041800@qq.com
# @Link    : https://github.com/jinjf553
# @software: PyCharm
# @Date    : 2019/5/18 16:01
# @Version : ??
import os
import time

import pyperclip
from openpyxl import load_workbook
from openpyxl.styles import PatternFill
from rpa.fastrpa.adtable import YELLOW
from rpa.fastrpa.sap.session import attach_sap
from rpa.public.check_card import _C103_card
from rpa.public.config import FILE_PATH, templates
from rpa.public.rz_C109 import _C109


def export_card_info(text):
    session = attach_sap("reopen")
    _C103_card(session)  # time.strftime("%Y%m", time.localtime(time.time() + 31 * 24 * 60 * 60)) + '01')
    pyperclip.copy(text)
    session.findById("wnd[1]/tbar[0]/btn[24]").press()
    try:
        session.findById("wnd[2]/tbar[0]/btn[0]").press()
    except Exception:
        pass
    session.findById("wnd[1]/tbar[0]/btn[8]").press()
    session.findById("wnd[0]/shellcont[1]/shell/shellcont[0]/shell/shellcont[1]/shell[1]").expandNode("          4")
    session.findById("wnd[0]/shellcont[1]/shell/shellcont[0]/shell/shellcont[1]/shell[1]").topNode = "          1"
    session.findById("wnd[0]/shellcont[1]/shell/shellcont[0]/shell/shellcont[1]/shell[1]").selectItem("         13", "C          3")
    session.findById("wnd[0]/shellcont[1]/shell/shellcont[0]/shell/shellcont[1]/shell[1]").ensureVisibleHorizontalItem("         13", "C          3")
    session.findById("wnd[0]/shellcont[1]/shell/shellcont[0]/shell/shellcont[1]/shell[1]").changeCheckbox("         13", "C          3", -1)
    session.findById("wnd[0]/shellcont[1]/shell/shellcont[0]/shell/shellcont[1]/shell[1]").itemContextMenu("         13", "C          4")
    session.findById("wnd[0]/shellcont[1]/shell/shellcont[0]/shell/shellcont[1]/shell[1]").selectContextMenuItem("OUTPUT_BOTH")
    session.findById("wnd[0]/usr/subSUB_MAIN:SAPLAQ_ADHOC:0210/subSUB_SELECTION:SAPLAQ_ADHOC:0310/cntlSEL_DEF_CONTAINER/shellcont/shell").currentCellRow = 1
    session.findById("wnd[0]/usr/subSUB_MAIN:SAPLAQ_ADHOC:0210/subSUB_SELECTION:SAPLAQ_ADHOC:0310/cntlSEL_DEF_CONTAINER/shellcont/shell").pressButtonCurrentCell()
    session.findById("wnd[1]/tbar[0]/btn[16]").press()
    session.findById("wnd[1]/usr/tabsTAB_STRIP/tabpSIVA/ssubSCREEN_HEADER:SAPLALDB:3010/tblSAPLALDBSINGLE/ctxtRSCSEL-SLOW_I[1,0]").text = "1"
    session.findById("wnd[1]/usr/tabsTAB_STRIP/tabpSIVA/ssubSCREEN_HEADER:SAPLALDB:3010/tblSAPLALDBSINGLE/ctxtRSCSEL-SLOW_I[1,1]").text = "3"
    session.findById("wnd[1]/tbar[0]/btn[8]").press()
    session.findById("wnd[0]/tbar[1]/btn[8]").press()
    if session.findById("wnd[0]/sbar/pane[0]").text in ['未选取数据', '系统不能读取任何数据']:
        time.sleep(3)
        session.findById("wnd[0]/tbar[0]/okcd").text = "/nex"
        session.findById("wnd[0]").sendVKey(0)
        return True

    try:
        session.findById("wnd[0]/tbar[1]/btn[8]").press()
    except Exception:
        pass

    table = session.findById("wnd[0]/usr/cntlGRID1/shellcont/shell")
    tmp103_wb = load_workbook(os.path.join(templates, "身份证信息.xlsx"))
    tmp103_ws = tmp103_wb.get_sheet_by_name("Sheet1")
    for j in range(table.columnCount):
        tmp103_ws.cell(1, j + 1).value = table.getCellValue(-1, table.columnOrder(j))

    for i in range(table.rowCount):
        session.findById("wnd[0]/usr/cntlGRID1/shellcont/shell").firstVisibleRow = i
        table = session.findById("wnd[0]/usr/cntlGRID1/shellcont/shell")
        for j in range(table.columnCount):
            tmp103_ws.cell(i + 2, j + 1).value = table.getCellValue(i, table.columnOrder(j))
            if i + 2 > table.rowCount:
                tmp103_ws.cell(i + 3, j + 1).fill = PatternFill("solid", YELLOW)
    tmp103_wb.save(os.path.join(FILE_PATH, "tmp-card.xlsx"))
    session.findById("wnd[0]/tbar[0]/okcd").text = "/nex"
    session.findById("wnd[0]").sendVKey(0)


def rz_export_109(ids):
    if not [x for x in ids if x]:
        return True
    session = attach_sap("reopen")
    _C109(session, ids)
    if session.findById("wnd[0]/sbar/pane[0]").text in ['未选取数据', '系统不能读取任何数据']:
        session.findById("wnd[0]/tbar[0]/okcd").text = "/nex"
        session.findById("wnd[0]").sendVKey(0)
        return True

    table = session.findById("wnd[0]/usr/cntlGRID1/shellcont/shell")
    tmp109_wb = load_workbook(os.path.join(templates, "rz_模板_109.xlsx"))
    tmp109_ws = tmp109_wb.get_sheet_by_name("109")
    for i in range(table.rowCount):
        session.findById("wnd[0]/usr/cntlGRID1/shellcont/shell").firstVisibleRow = i
        table = session.findById("wnd[0]/usr/cntlGRID1/shellcont/shell")
        for j in range(table.columnCount):
            tmp109_ws.cell(i + 2, j + 1).value = table.getCellValue(i, table.columnOrder(j))
            if i + 2 > table.rowCount:
                tmp109_ws.cell(i + 3, j + 1).fill = PatternFill("solid", YELLOW)
    tmp109_wb.save(os.path.join(FILE_PATH, "rz_tmp-109逻辑查询表.xlsx"))
    session.findById("wnd[0]/tbar[0]/okcd").text = "/nex"
    session.findById("wnd[0]").sendVKey(0)
