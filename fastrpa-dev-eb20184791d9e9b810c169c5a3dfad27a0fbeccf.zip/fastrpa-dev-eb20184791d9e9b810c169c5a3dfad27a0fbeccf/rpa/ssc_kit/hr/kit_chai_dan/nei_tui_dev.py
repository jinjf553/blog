#!/usr/bin/env python
# -*- coding: utf-8 -*-
# @File    : nei_tui.py
# @Author  : jinjianfeng
# @Contact : 553041800@qq.com
# @Link    : https://github.com/jinjf553
# @software: PyCharm
# @Date    : 2019/6/18 23:16
# @Version : ??
import logging
import os
import shutil
import time
from collections import defaultdict
from datetime import datetime

from openpyxl import load_workbook
from rpa.fastrpa.adtable import BLUE, RED
from rpa.public.config import FILE_PATH, templates
from rpa.public.tools import cel, cells
from rpa.ssc.hr.orm.orm_ope import Query
from rpa.ssc.hr.orm.td_hr_gang_wei_diao_pei_rulebase import Event
from rpa.ssc.hr.orm.td_hr_li_tui_code_rulebase import LiTui
from rpa.ssc.hr.sap.export_1072 import export_1072
from rpa.ssc.hr.sap.export_other_103 import export_103_nei_tui
from rpa.ssc_kit.hr.kit_chai_dan.check_280 import (check_zhrpy280, create_dir,
                                                   get_date, get_grade,
                                                   get_info)


def rulebase_12(file, file_str):
    wb_temp = load_workbook(file)
    ws_temp = wb_temp.active
    # 规则 12.1.1  提取“人员离退表”的“事件类型”为“内退”的事件
    value_dict, li = defaultdict(list), []
    for i in range(7, len(ws_temp["B"]) + 1):
        if ws_temp["B%s" % str(i)].value and '内退' in str(ws_temp["D%s" % str(i)].value):
            if cel(ws_temp, f"B{i}") in li:
                cells(ws_temp, "B%s" % str(i), "人员编号有重复项", RED)
            li.append(cel(ws_temp, f"B{i}"))
            value_dict[cel(ws_temp, f"B{i}").lstrip('0')] = [str(j.value).strip() for j in ws_temp[f"B{i}:Q{i}"][0]]
    wb_temp.save(file)
    if not li:
        logging.info("人员离退表中没有内退事件。")
        return

    date = get_date(value_dict)
    if not date or len(date) != 8:
        return
    export_103_nei_tui(None, li, date).save_to(FILE_PATH)
    wb_103 = load_workbook(FILE_PATH + "/C22_内退.xlsx")
    ws_103 = wb_103.active
    values_103, value_1072 = defaultdict(list), defaultdict(list)
    for i in range(2, len(ws_103["A"]) + 1):
        for col in ["Z", "AA", "AD", "AE", "AF", "AG", "AH", "AI", "P", "Q", "R", "AN", "G", "J", "X", "C", "L"]:
            values_103[cel(ws_103, f"A{i}").lstrip('0')].append(cel(ws_103, f"{col}{i}"))

    rule_I = [str(res.db_I).strip() for res in Query(LiTui) if res.db_I]  # 工资核算范围
    rule_F = [str(res.db_F).strip() for res in Query(table=LiTui) if res.db_F]  # 企业自定义分类1
    rule_G = [str(res.db_G).strip() for res in Query(table=LiTui) if res.db_G]  # 企业自定义分类2
    rule_H = [str(res.db_H).strip() for res in Query(table=LiTui) if res.db_H]  # 企业自定义分类3
    rule_Ds, tmp_d = defaultdict(dict), defaultdict(str)  # 码值
    for res in Query(LiTui):
        t = {"C": res.db_C, "D": res.db_D, "E": res.db_E, "F": res.db_F, "G": res.db_G, "H": res.db_H, "I": res.db_I,
             "J": res.db_J, "K": res.db_K, "L": res.db_L, "M": res.db_M, "N": res.db_N}
        if res.db_D:
            tmp_d[str(res.db_D).strip()] = str(res.db_G)
            k = str(res.db_D).strip() + "|" + str(res.db_I).strip()
            rule_Ds[k] = {x: str(y).strip() for x, y in t.items()}
    rule_AZ = [str(res.db_AZ).strip() for res in Query(Event) if res.db_AZ]
    rule_P = [str(res.db_P).strip() for res in Query(table=LiTui) if res.db_P]  # 内退事件原因
    gang_wei_hao = [tmp_d[x[5]] for x in value_dict.values() if x[5] in tmp_d.keys()]
    print(gang_wei_hao)

    wb = load_workbook(os.path.join(templates, "内退事件批导.xlsx"))
    ws = wb.active
    for num, (key, value) in enumerate(list(value_dict.items())):
        i = num + 7
        if key not in values_103.keys():
            cells(ws, "B%s" % str(i), "103表中没有该人员编号，请核对", RED)
            continue

        # 规则 12.2.2 - 12.2.4  B, C, D, E
        for count, col in {0: "B", 1: "C", 3: "E", 4: "D"}.items():
            ws["%s%s" % (col, str(i))] = value[count] if value[count] != "None" else None

        # 12.2.6
        if value[6] not in ["None", "", None]:
            if value[6] == "不变":
                ws[f"X{i}"] = values_103[key][0] + " " + values_103[key][1]
            else:
                ws[f"X{i}"] = value[6]
            if cel(ws, f"X{i}") not in rule_I:
                cells(ws, f"X{i}", "工资核算范围非码值！", RED)
        else:
            cells(ws, f"X{i}", "企业表单工资核算范围未填写！", RED)

        # 12.2.7.1  T-企业自定义分类1
        if value[7] in [None, "None", ""]:
            ws[f"T{i}"] = "清空"
        elif value[7] == "不变":
            if values_103[key][3] in ["None", None, ""]:
                ws[f"T{i}"] = "清空"
            else:
                ws[f"T{i}"] = values_103[key][2] + " " + values_103[key][3]
        else:
            ws[f"T{i}"] = value[7]
            if value[7] not in rule_F:
                cells(ws, f"T{i}", "企业自定义分类1非码值！", RED)

        # 12.2.8.1  U-企业自定义分类2
        if value[8] in [None, "None", ""]:
            ws[f"U{i}"] = "清空"
        elif value[8] == "不变":
            if values_103[key][5] in ["None", None, ""]:
                ws[f"U{i}"] = "清空"
            else:
                ws[f"U{i}"] = values_103[key][4] + " " + values_103[key][5]
        else:
            ws[f"U{i}"] = value[8]
            if value[8] not in rule_G:
                cells(ws, f"U{i}", "企业自定义分类2非码值！", RED)

        # 12.2.9.1  V-企业自定义分类3
        if value[9] in [None, "None", ""]:
            ws[f"V{i}"] = "清空"
        elif value[9] == "不变":
            if values_103[key][7] in ["None", None, ""]:
                ws[f"V{i}"] = "清空"
            else:
                ws[f"V{i}"] = values_103[key][6] + " " + values_103[key][7]
        else:
            ws[f"V{i}"] = value[9]
            if value[9] not in rule_H:
                cells(ws, f"V{i}", "企业自定义分类3非码值！", RED)

        # 12.2.10.1
        ws[f"W{i}"] = str(value[5]).replace("None", "")
        ws[f"AB{i}"] = str(value[15]).replace("None", "")
        ws[f"Y{i}"] = values_103[key][8]
        ws[f"Z{i}"] = values_103[key][9] + " " + values_103[key][10]
        ws[f"AA{i}"] = values_103[key][0] + " " + values_103[key][1]

        # 12.2.10.2
        if cel(ws, f"W{i}") not in [x.split("|")[0] for x in rule_Ds.keys()]:
            for x in ["AC", "AD", "AE", "AF", "AG", "AH", "AI", "AJ", "AK", "AL", "AM", "AN"]:
                cells(ws, f"{x}{i}", "在离退码表库中未找到“调动后机构岗位”的码值！", RED)
        elif cel(ws, f"W{i}") + "|" + cel(ws, f"X{i}") in rule_Ds.keys():
            for x in ["C", "D", "E", "F", "G", "H", "I", "J", "K", "L", "M", "N"]:
                ws[f"A{x}{i}"] = rule_Ds[cel(ws, f"W{i}") + "|" + cel(ws, f"X{i}")][x]
        else:
            ds = [x for x in rule_Ds.keys() if cel(ws, f"W{i}") == x.split("|")[0]][0]
            for x in ["D", "E", "F", "G", "H", "K", "L", "M", "N"]:
                ws[f"A{x}{i}"] = rule_Ds[ds][x]
            cells(ws, f"AI{i}", "离退码表库中该岗位未对应此工资核算范围，请联系组长补充离退码表库", RED)
            cells(ws, f"AJ{i}", "离退码表库中该岗位未对应此工资核算范围，请联系组长补充离退码表库", RED)

        # 规则 12.3.7  A-序号
        ws["A%s" % str(i)] = str(num + 1)

        # 规则 12.4.1  D-离退休时间
        try:
            time.strptime(str(ws["D%s" % str(i)].value), '%Y%m%d')
            current_date = time.strftime("%d", time.localtime(time.time()))
            current_month = time.strftime("%Y%m01", time.localtime(time.time()))
            next_month = time.strftime("%Y%m01",
                                       time.localtime(time.time() + (32 - int(current_date)) * 24 * 60 * 60))
            if str(ws["D%s" % str(i)].value) not in [current_month, next_month]:
                cells(ws, "D%s" % str(i), "事件日期需核对", RED)
            if num != 0 and ws["D%s" % str(num + 6)].value != ws["D%s" % str(i)].value:
                cells(ws, "D%s" % str(i), "事件日期需核对", RED)
        except Exception:
            cells(ws, "D%s" % str(i), "事件日期需核对", RED)

        # 12.4.2.1  L-企业统计标识
        ws[f"L{i}"] = "X 是" if "是" in values_103[key][11] else "  否"

        # 规则 12.4.3  A-序列号
        if values_103[key][12] not in ["None", None, ""]:
            cells(ws, f"A{i}", "请注意该人员该月已做过事件！", RED)

        # 规则 12.4.4  C-人员姓名
        if values_103[key][13] in rule_AZ[8:15]:
            cells(ws, f"C{i}", "请核对该人员的岗位状态是否应做内退事件！", RED)

        # 12.4.5
        if cel(ws, f"E{i}") not in rule_P:
            cells(ws, f"E{i}", "事件原因非码值！", RED)

        # 12.5.1	当【内退模板-【AC-对应编码】】不为空时，下载1072
        ag = cel(ws, f"AG{i}").lstrip("0")
        if cel(ws, f"AC{i}"):
            if not os.path.exists(FILE_PATH + "/模板_1072.xlsx"):
                logging.info(f"内退模板AC列有值，下载1072表")
                export_1072(None, gang_wei_hao, date).save_to(FILE_PATH)
                ws_ = load_workbook(FILE_PATH + "/模板_1072.xlsx").active
                for x in range(2, len(ws_["A"]) + 1):
                    t = [("G", x), ("AM", x), ("P", x), ("Q", x), ("R", x), ("P", x + 1), ("Q", x + 1), ("R", x + 1)]
                    if cel(ws_, f"B{x}") == "S":
                        value_1072[cel(ws_, f"A{x}").lstrip('0')] = [cel(ws_, f"{y}{z}") for y, z in t]
            if ag in value_1072.keys():
                if value_1072[ag][0] != cel(ws, f"AH{i}"):
                    cells(ws, f"AH{i}", "岗位名称与离退码表库不同！", RED)
                if value_1072[ag][1] != "是":
                    cells(ws, f"AG{i}", "未勾选虚岗位标识！", RED)
            else:
                cells(ws, f"AG{i}", "未在系统中查找到该岗位编号！", RED)

        # 12.5.2	逻辑关系校验-人事范围、人事子范围
        if cel(ws, f"AC{i}") and ag in value_1072.keys():
            if not (value_1072[ag][2] or value_1072[ag][3]):
                if not (value_1072[ag][5] or value_1072[ag][6]):
                    cells(ws, f"AE{i}", "岗位及所在机构的财务科目设置的人事范围均为空！", BLUE)  # 10
                elif value_1072[ag][5] != cel(ws, f"AE{i}"):
                    cells(ws, f"AE{i}", "岗位所在机构的财务科目设置的人事范围与模板不一致！", RED)  # 7
                else:
                    if value_1072[ag][6] + " " + value_1072[ag][7] == cel(ws, f"AF{i}"):
                        cells(ws, f"AE{i}", "岗位所在机构的财务科目设置的人事范围、人事子范围与模板一致！", BLUE)  # 8
                    else:
                        cells(ws, f"AE{i}", "岗位所在机构的财务科目设置的人事子范围与模板不一致！", RED)  # 9
            elif not value_1072[ag][2]:
                if value_1072[ag][3] + " " + value_1072[ag][4] == cel(ws, f"AF{i}"):
                    cells(ws, f"AE{i}", "岗位财务科目设置有值，人事范围继承自机构、人事子范围设置在岗位上！", BLUE)  # 1
                else:
                    cells(ws, f"AE{i}", "岗位财务科目设置有值，人事范围继承自机构、人事子范围设置在岗位上但与模板不同！", RED)  # 2
            else:
                if value_1072[ag][2] == cel(ws, f"AE{i}"):
                    if not value_1072[ag][3]:
                        cells(ws, f"AE{i}", "岗位财务科目设置有值，人事范围有值、但人事子范围为空或继承自机构！", BLUE)  # 3
                    elif value_1072[ag][3] + " " + value_1072[ag][4] == cel(ws, f"AF{i}"):
                        cells(ws, f"AE{i}", "岗位财务科目设置有值，人事范围、人事子范围均设置在岗位上且与模板一致！", BLUE)  # 4
                    else:
                        cells(ws, f"AE{i}", "岗位财务科目设置有值，人事范围、人事子范围均设置在岗位上，但人事子范围与模板不一致！", RED)  # 5
                else:
                    cells(ws, f"AE{i}", "岗位财务科目设置有值，但人事范围与模板不一致！", RED)  # 6

        #  12.5.3
        if cel(ws, f"E{i}") not in rule_P[:2] and cel(ws, f"E{i}") != cel(ws, f"AK{i}"):
            cells(ws, f"AK{i}", "表单填写原因与离退码表库不同！", RED)
        if cel(ws, f"E{i}") in rule_P[2:4]:
            cells(ws, f"E{i}", "请核实内退原因！", RED)

        #  12.5.4
        if not ws[f"E{i}"].comment:
            if cel(ws, f"D{i}") == values_103[15]:
                cells(ws, f"D{i}", "人事调配屏本月已有事件！", BLUE)
            if cel(ws, f"D{i}") == values_103[16]:
                cells(ws, f"D{i}", "组织分配屏本月已有事件！", BLUE)
    serial_id = datetime.now().strftime("%Y-%m-%d-%H-%M-%S-%f")
    wb.properties.description = serial_id
    wb.save(FILE_PATH + '/tmp-内退.xlsx')
    # 12.3.1	生成内退模板-2
    check_zhrpy280(FILE_PATH + '/tmp-内退.xlsx')
    local = create_dir(file, file_str)
    sr, code, worker = get_info(file, file_str)
    get_grade(f"{sr}-{code}-{worker}", value_dict, "内退", serial_id)
    shutil.move(FILE_PATH + "/C22_内退.xlsx", local + f"/103_内退事件_{os.path.basename(file)}")
    shutil.move(FILE_PATH + '/tmp-内退.xlsx', local + f"/{sr}-{code}-内退-{worker}.xlsx")
    if os.path.exists(FILE_PATH + "/模板_1072.xlsx"):
        shutil.move(FILE_PATH + "/模板_1072.xlsx", local + f"/1072_内退事件_{os.path.basename(file)}")
