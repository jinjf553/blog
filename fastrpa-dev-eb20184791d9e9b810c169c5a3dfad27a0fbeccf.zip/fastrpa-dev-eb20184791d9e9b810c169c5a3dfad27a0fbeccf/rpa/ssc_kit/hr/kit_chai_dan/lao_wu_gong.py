#!/usr/bin/env python
# -*- coding: utf-8 -*-
# @File    : lao_wu_gong.py
# @Author  : jinjianfeng
# @Contact : 553041800@qq.com
# @Link    : https://github.com/jinjf553
# @software: PyCharm
# @Date    : 2019/7/20 14:03
# @Version : ??
import logging
import os
import shutil
import time
from collections import defaultdict
from datetime import datetime

from openpyxl import load_workbook
from rpa.fastrpa.adtable import RED
from rpa.public.config import FILE_PATH, templates
from rpa.public.tools import cel, cells
from rpa.ssc.hr.sap.export_other_103 import export_103_lao_wu_gong
from rpa.ssc_kit.hr.kit_chai_dan.check_280 import (check_zhrpy280, create_dir,
                                                   get_date, get_grade)


def rulebase_15(file, file_str):
    wb = load_workbook(file)
    ws = wb.active
    # 规则 15.1.1  提取“人员离退表”的“事件类型”为“劳务工退回”的事件
    value_dict, li = defaultdict(list), []
    for i in range(7, len(ws["B"]) + 1):
        if ws["B%s" % str(i)].value and '劳务工退回' in str(ws["D%s" % str(i)].value):
            if cel(ws, f"B{i}") in li:
                cells(ws, "B%s" % str(i), "人员编号有重复项", RED)
            li.append(cel(ws, f"B{i}"))
            value_dict[cel(ws, f"B{i}")] = [str(j.value).strip() for j in ws["B%s:P%s" % (str(i), str(i))][0]]
    wb.save(file)
    if not li:
        logging.info("人员离退表中没有劳务工退回事件。")
        return
    date = get_date(value_dict)
    if not date or len(date) != 8:
        return
    export_103_lao_wu_gong(None, li, date).save_to(FILE_PATH)

    wb_103 = load_workbook(FILE_PATH + "/C23_离职.xlsx")
    ws_103 = wb_103.active
    values_103 = defaultdict(list)
    for i in range(2, len(ws_103["A"]) + 1):
        for col in ["G", "BK", "BL", "A"]:
            values_103[str(ws_103["A%s" % str(i)].value).lstrip('0')].append(str(ws_103["%s%s" % (col, str(i))].value))

    wb_template = load_workbook(os.path.join(templates, "劳务工退回模板表.xlsx"))
    ws_template = wb_template.active

    wb_tmp = load_workbook(os.path.join(templates, "其他用工信息定界.xlsx"))
    wb_tmp.save(os.path.join(FILE_PATH, "tmp-其他用工.xlsx"))

    for num, (key, value) in enumerate(list(value_dict.items())):
        logging.info(f"正在校验劳务工退回模板第{num + 1}条数据...")
        if key.lstrip('0') not in values_103.keys():
            cells(ws_template, "B%s" % str(num + 7), "103表中没有该人员编号，请核对", RED)
            continue

        # 规则 15.2.1 - 15.2.3  B-D
        for count, col in {0: "B", 1: "C", 4: "D", 14: "G"}.items():
            ws_template["%s%s" % (col, str(num + 7))] = value[count]

        # 规则 15.2.4  G-事件类型
        if values_103[key.lstrip('0')][0] != "None":
            cells(ws_template, "C%s" % str(num + 7), "请注意该人员该月已做过事件", RED)

        # 规则 15.3.1  生成其他用工信息定界模板（LSMW）
        if values_103[key.lstrip('0')][1] != "None" and values_103[key.lstrip('0')][2] == '9999.12.31':
            wb_tmp = load_workbook(os.path.join(FILE_PATH, "tmp-其他用工.xlsx"))
            ws_tmp = wb_tmp.active
            rows = str(len(ws_tmp["A"]) + 1)
            ws_tmp["A%s" % rows] = values_103[key.lstrip('0')][3]
            ws_tmp["B%s" % rows] = values_103[key.lstrip('0')][1]
            try:
                time_stamp = time.mktime(time.strptime(str(ws_template["D%s" % str(num + 7)].value), "%Y%m%d"))
                yesterday = time.strftime("%Y%m%d", time.localtime(int(time_stamp) - 24 * 60 * 60))
                ws_tmp["C%s" % rows] = yesterday
            except Exception:
                cells(ws_tmp, "C%s" % rows, "务工退回模板中【D-退回日期】不是常规日期", RED)
            wb_tmp.save(os.path.join(FILE_PATH, "tmp-其他用工.xlsx"))

        # 规则 15.3.2  A-序号
        ws_template["A%s" % str(num + 7)] = str(num + 1)
    serial_id = datetime.now().strftime("%Y-%m-%d-%H-%M-%S-%f")
    wb_template.properties.description = serial_id
    wb_template.save(FILE_PATH + '/tmp-劳务.xlsx')
    check_zhrpy280(FILE_PATH + '/tmp-劳务.xlsx')
    local = create_dir(file, file_str)
    get_grade(f"{os.path.basename(file).split('-')[0][:10]}-XX-XX", value_dict, "劳务工退回", serial_id)
    shutil.move(FILE_PATH + "/C23_离职.xlsx", local + f"/103_劳务工退回_{os.path.basename(file)}")
    shutil.move(FILE_PATH + '/tmp-劳务.xlsx', local + f"/{os.path.basename(file)[:10]}_劳务工退回模板.xlsx")
    shutil.move(FILE_PATH + '/tmp-其他用工.xlsx', local + f"/其他用工信息定界_{os.path.basename(file)}")
