#!/usr/bin/env python
# -*- coding: utf-8 -*-
# @File    : no_job_change.py
# @Author  : jinjianfeng
import time
import traceback

from rpa.fastrpa.log import config
from rpa.public.run_sap import close_sap
# from rpa.public.alert import show_message, show_state
from rpa.ssc_kit.hr.kit_chai_dan.download import download
from rpa.ssc_kit.hr.kit_chai_dan.run_A import (run_kit_shou_dong_chai_dan,
                                               upload_file)
from rpa.ssc_kit.hr.kit_chai_dan.send_on import send, send_on


def run_chai_dan(x=1):
    while True:
        xpath = "C13_W42_V43" if x == 1 else "C14_W42_V43"
        try:
            # 抓单
            file_list, file_str = download(xpath=xpath)  # 我的待办：C13_W42_V43  操作待办：C14_W42_V43
            # 机器人A
            for file in file_list:
                run_kit_shou_dong_chai_dan(filename=file, file_str=file_str)
            # 上载、转寄
            upload_file("", file_str)
            send()
            # if show_message(10): break
            if not file_str and x == 1:
                x = 0
            elif not file_str and x == 0:
                time_ = int(time.strftime("%H%M%S", time.localtime(time.time())))
                if time_ > 190000 or time_ < 70000:
                    time.sleep(3600)
                    # info = show_message(3600)
                else:
                    send_on("", "")
                    time.sleep(20)
                    # info = show_message(20)
                # if info: break
                x = 1
        except Exception:
            datetime = time.strftime("%Y%m%d %H:%M:%S\n", time.localtime(time.time()))
            with open(f"{datetime[:8]}error.log", "a+", encoding="utf-8") as f:
                f.write(datetime)
                f.write(traceback.format_exc() + "\n\n")
            close_sap()
            time.sleep(10)


if __name__ == '__main__':
    config()
