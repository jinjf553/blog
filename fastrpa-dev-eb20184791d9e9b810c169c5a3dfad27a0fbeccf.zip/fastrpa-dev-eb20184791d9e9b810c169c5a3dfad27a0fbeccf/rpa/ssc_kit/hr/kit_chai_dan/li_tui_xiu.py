#!/usr/bin/env python
# -*- coding: utf-8 -*-
# @File    : li_tui_xiu.py
# @Author  : jinjianfeng
# @Contact : 553041800@qq.com
# @Link    : https://github.com/jinjf553
# @software: PyCharm
# @Date    : 2019/6/15 15:46
# @Version : ??
import logging
import os
import shutil
import time
from collections import defaultdict
from datetime import datetime

from openpyxl import load_workbook
from rpa.fastrpa.adtable import RED
from rpa.fastrpa.sap.session import close_sap
from rpa.public.config import FILE_PATH, templates
from rpa.public.tools import cel, cells
from rpa.ssc.hr.orm.orm_ope import Query
from rpa.ssc.hr.orm.td_hr_li_tui_code_rulebase import LiTui
from rpa.ssc.hr.sap.export_other_103 import export_103_li_tui_xiu
from rpa.ssc_kit.hr.kit_chai_dan.check_280 import (check_zhrpy280, create_dir,
                                                   get_date, get_grade)


def rulebase_11(file, file_str):
    wb = load_workbook(file)
    ws = wb.active
    # 规则 11.1.1  提取“人员离退表”的“事件类型”为“离退休”的事件
    value_dict, li = defaultdict(list), []
    for i in range(7, len(ws["B"]) + 1):
        if ws["B%s" % str(i)].value and '离退休' == str(ws["D%s" % str(i)].value):
            if cel(ws, f"B{i}") in li:
                cells(ws, "B%s" % str(i), "人员编号有重复项", RED)
            li.append(cel(ws, f"B{i}"))
            value_dict[cel(ws, f"B{i}")] = [str(j.value).strip() for j in ws["B%s:Q%s" % (str(i), str(i))][0]]
    wb.save(file)
    if not li:
        logging.info("人员离退表中没有离退休事件。")
        return

    date = get_date(value_dict)
    if not date or len(date) != 8:
        return
    if not str(date).isdigit():
        days = time.strftime("%d", time.localtime(time.time()))
        date = time.strftime("%Y%m01", time.localtime(time.time() + (31 - int(days)) * 24 * 60 % 60))
    try:
        export_103_li_tui_xiu(None, li, date).save_to(FILE_PATH)
    except Exception:
        return
    close_sap()
    wb_103 = load_workbook(os.path.join(FILE_PATH + "/C20_离退休.xlsx"))
    ws_103 = wb_103.active
    values_103 = defaultdict(list)
    for i in range(2, len(ws_103["A"]) + 1):
        for col in ["AE", "AF", "AG", "AH", "AJ", "AI", "P", "Q", "R", "V", "W", "T", "U", "AQ", "BE", "CL", "CJ", "BZ",
                    "CG", "H", "J", "BF"]:
            values_103[str(ws_103["A%s" % str(i)].value).lstrip('0')].append(str(ws_103["%s%s" % (col, str(i))].value))

    rule_B = [res.rule_B for res in Query(table=LiTui) if res.rule_B]
    rule_C = [res.rule_C for res in Query(table=LiTui) if res.rule_C]
    rule_D = [res.rule_D for res in Query(table=LiTui) if res.rule_D]
    rule_R = {res.rule_R: [res.rule_S, res.rule_T, res.rule_U, res.rule_V, res.rule_X,
                           res.rule_Y] for res in Query(table=LiTui) if res.rule_R}
    rule_AV = {res.rule_AV[:4]: res.rule_AV for res in Query(table=LiTui) if res.rule_AV}
    rule_AA = {res.rule_AA: res.rule_AB for res in Query(table=LiTui) if res.rule_AA}
    rule_A_B, rule_A_C, rule_A_D = defaultdict(list), defaultdict(list), defaultdict(list)
    _ = (rule_A_B[res.rule_A].append(res.rule_B) for res in Query(table=LiTui) if res.rule_A)
    _ = (rule_A_C[res.rule_A].append(res.rule_C) for res in Query(table=LiTui) if res.rule_A)
    _ = (rule_A_D[res.rule_A].append(res.rule_D) for res in Query(table=LiTui) if res.rule_A)
    rule_O = [res.rule_O for res in Query(table=LiTui) if res.rule_O]
    rule_P = {res.rule_P.split()[1]: res.rule_P for res in Query(table=LiTui) if res.rule_P}
    rule_AX = [res.rule_AX for res in Query(table=LiTui) if res.rule_AX]

    wb_template = load_workbook(os.path.join(templates, "离退休模板表.xlsx"))
    ws_template = wb_template.active

    for num, (key, value) in enumerate(list(value_dict.items())):
        j = str(num + 7)
        if key.lstrip('0') not in values_103.keys():
            cells(ws_template, "B%s" % j, "103表中没有该人员编号，请核对", RED)
            continue

        # 规则 11.2.2 - 11.2.6 & 11.2.10  B-AR
        for count, col in {0: "B", 1: "C", 3: "E", 4: "D", 5: "AZ", 6: "BA", 10: "AR", 14: "BK"}.items():
            ws_template["%s%s" % (col, str(num + 7))] = value[count] if value[count] != "None" else None

        # 规则 11.2.7  L-企业自定义分类
        if value[7] == "不变" and values_103[key.lstrip('0')][1] != "None":
            ws_template["L%s" % j] = values_103[key.lstrip('0')][0] + " " + values_103[key.lstrip('0')][1]
        elif value[7] and value[7] != "不变" and value[7] not in rule_B + [None, "None"]:
            cells(ws_template, "L%s" % j, "企业自定义分类1非码值", RED)

        # 规则 11.2.8  AX-调动后企业自定义分类2
        if value[8] in [None, "None"]:
            ws_template["AX%s" % j] = "清空"
        elif value[8] == "不变" and values_103[key.lstrip('0')][3] != "None":
            ws_template["AX%s" % j] = values_103[key.lstrip('0')][2] + " " + values_103[key.lstrip('0')][3]
        elif value[8] and value[8] != "不变" and value[8] not in rule_C:
            cells(ws_template, "AX%s" % j, "企业自定义分类2非码值", RED)

        # 规则 11.2.9  AY-调动后企业自定义分类3
        if value[9] in [None, "None"]:
            ws_template["AY%s" % j] = "清空"
        elif value[9] == "不变" and values_103[key.lstrip('0')][5] != "None":
            ws_template["AY%s" % j] = values_103[key.lstrip('0')][4] + " " + values_103[key.lstrip('0')][5]
        elif value[9] and value[9] != "不变" and value[9] not in rule_D:
            cells(ws_template, "AY%s" % j, "企业自定义分类3非码值", RED)

        # 规则 11.2.11  G,H,F,J,AM,AN,BA
        if value[5] in rule_R.keys():
            for A, B in {"G": 0, "H": 1, "F": 2, "J": 3, "AM": 4, "AN": 5}.items():
                ws_template["%s%s" % (A, str(num + 7))] = rule_R[value[5]][B]
        else:
            cells(ws_template, "F%s" % j, "调动后机构岗位非码值", RED)
        if ws_template["J%s" % j].value != ws_template["BA%s" % j].value:
            cells(ws_template, "J%s" % j, "工资核算范围与企业表单不同", RED)

        # 规则 11.3.2  BB-调动前人事范围
        if values_103[key.lstrip('0')][6] in rule_AV.keys():
            ws_template["BB%s" % j] = rule_AV[values_103[key.lstrip('0')][6]]

        # 规则 11.3.3  BC-调动前人事子范围
        ws_template["BC%s" % j] = ' '.join(values_103[key.lstrip('0')][7:9])

        # 规则 11.3.4  BD-年龄
        ws_template["BD%s" % j] = values_103[key.lstrip('0')][9]

        # 规则 11.3.5  BE-性别
        ws_template["BE%s" % j] = values_103[key.lstrip('0')][10]

        # 规则 11.3.6  BF-调动前人员子组
        ws_template["BF%s" % j] = ' '.join(values_103[key.lstrip('0')][11:13])

        # 规则 11.3.7  I-人员子组
        if str(ws_template["E%s" % j].value).rstrip() in rule_AA.keys():
            ws_template["I%s" % j] = rule_AA[str(ws_template["E%s" % j].value).rstrip()]
        else:
            cells(ws_template, "E%s" % j, "事件原因非码值", RED)

        # 规则 11.3.8  L-企业自定义分类
        if ws_template["L%s" % j].value and ws_template["L%s" % j].comment is None:
            if ws_template["G%s" % j].value in rule_A_B.keys():
                if ws_template["L%s" % j].value not in rule_A_B[ws_template["G%s" % j].value]:
                    cells(ws_template, "L%s" % j, "企业自定义分类1与人事范围不匹配", RED)

        # 规则 11.3.9  AX-企业自定义分类2
        if ws_template["AX%s" % j].value and ws_template["AX%s" % j].comment is None:
            if ws_template["G%s" % j].value in rule_A_C.keys():
                if ws_template["AX%s" % j].value not in rule_A_C[ws_template["G%s" % j].value]:
                    cells(ws_template, "AX%s" % j, "企业自定义分类2与人事范围不匹配", RED)

        # 规则 11.3.10  AY-企业自定义分类3
        if ws_template["AY%s" % j].value and ws_template["AY%s" % j].comment is None:
            if ws_template["G%s" % j].value in rule_A_D.keys():
                if ws_template["AY%s" % j].value not in rule_A_D[ws_template["G%s" % j].value]:
                    cells(ws_template, "AY%s" % j, "企业自定义分类3与人事范围不匹配", RED)

        # 规则 11.3.11  AR-领取企业年金人员标识
        if ws_template["AR%s" % j].value != rule_O[0]:
            cells(ws_template, "AR%s" % j, "领取企业年金人员标识需核对", RED)

        # 规则 11.3.12  M-企业统计标识
        if [i for i in rule_O if values_103[key.lstrip('0')][13] in i]:
            ws_template["M%s" % j] = [i for i in rule_O if values_103[key.lstrip('0')][13] in i][0]

        # 规则 11.3.14  AF-合同生效日期 & AG-合同解除/终止日期
        ws_template["AF%s" % j] = str(values_103[key.lstrip('0')][14]).replace(".", "")
        try:
            timeStamp = int(
                time.mktime(time.strptime(ws_template["D%s" % j].value, "%Y%m%d"))) - 24 * 60 * 60
            ws_template["AG%s" % j] = time.strftime("%Y%m%d", time.localtime(timeStamp))
        except Exception:
            pass

        # 规则 11.3.15  AH-解除/终止类型
        ws_template["AH%s" % j] = "3 合同终止"

        # 规则 11.3.16  AI-解除/终止原因
        ws_template["AI%s" % j] = "离退休"

        # 规则 11.3.17  AL-离（退）休后享受待遇级别 & BJ-退休前行政党派职位级别
        if values_103[key.lstrip('0')][15] != "None" and values_103[key.lstrip('0')][15].replace(" ",
                                                                                                 "") in rule_P.keys():
            ws_template["AL%s" % j] = rule_P[values_103[key.lstrip('0')][15].replace(" ", "")]
            ws_template["BJ%s" % j] = rule_P[values_103[key.lstrip('0')][15].replace(" ", "")]

        # 规则 11.3.18 - 11.3.20  BI-行政党派定界 & BG-内退定界 & BH-改制预留费定界
        for A, B in {16: "BI", 17: "BG", 18: "BH"}.items():
            if values_103[key.lstrip('0')][A] != "9999.12.31":
                ws_template["%s%s" % (B, str(num + 7))] = "是"

        # 规则 11.3.21  A-序号
        ws_template["A%s" % j] = str(num + 1)

        # 规则 11.4.1  D-离退休时间
        try:
            time.strptime(str(ws_template["D%s" % j].value), '%Y%m%d')
            current_date = time.strftime("%d", time.localtime(time.time()))
            current_month = time.strftime("%Y%m01", time.localtime(time.time()))
            next_month = time.strftime("%Y%m01",
                                       time.localtime(time.time() + (32 - int(current_date)) * 24 * 60 * 60))
            if str(ws_template["D%s" % j].value) not in [current_month, next_month]:
                cells(ws_template, "D%s" % j, "事件日期需核对", RED)
            if num != 0 and ws_template["D%s" % str(num + 6)].value != ws_template["D%s" % j].value:
                cells(ws_template, "D%s" % j, "事件日期需核对", RED)
        except Exception:
            cells(ws_template, "D%s" % j, "事件日期需核对", RED)

        # 规则 11.4.2  A-序列号
        if values_103[key.lstrip('0')][19] != "None":
            cells(ws_template, "A%s" % j, "请注意该人员该月已做过事件", RED)

        # 规则 11.4.3  C-人员姓名
        if values_103[key.lstrip('0')][20] in rule_AX[9:15]:
            cells(ws_template, "C%s" % j, "请核对该人员的岗位状态是否应做离退休事件", RED)

        # 规则 11.4.4  AF-合同生效日期
        if values_103[key.lstrip('0')][21] not in ["None", "9999.12.31", "0000.00.00"]:
            date = int(time.mktime(time.strptime(values_103[key.lstrip('0')][21], "%Y.%m.%d"))) + 24 * 60 * 60
            if int(time.strftime("%Y%m%d", time.localtime(date))) == int(ws_template["D%s" % j].value):
                ws_template["AF%s" % j] = values_103[key.lstrip('0')][14]
                ws_template["AG%s" % j] = values_103[key.lstrip('0')][21]
                ws_template["AH%s" % j] = "3 合同终止"
                ws_template["AG%s" % j] = "离退休"
            if int(time.strftime("%Y%m%d", time.localtime(date))) < int(ws_template["D%s" % j].value):
                ws_template["AF%s" % j] = values_103[key.lstrip('0')][14]
                ws_template["AG%s" % j] = values_103[key.lstrip('0')][21]
                cells(ws_template, "AG%s" % j, "请检验该人员劳动合同结束日期！", RED)
                cells(ws_template, "AF%s" % j, "请检验该人员劳动合同结束日期！", RED)

        # 规则 11.4.5  AF-合同生效日期
        if not ws_template["AF%s" % j].value:
            cells(ws_template, "AG%s" % j, "该人员劳动合同为空！", RED)
            cells(ws_template, "AF%s" % j, "该人员劳动合同为空！", RED)
    serial_id = datetime.now().strftime("%Y-%m-%d-%H-%M-%S-%f")
    wb_template.properties.description = serial_id
    wb_template.save(FILE_PATH + '/tmp-离退.xlsx')
    check_zhrpy280(FILE_PATH + '/tmp-离退.xlsx')
    local = create_dir(file, file_str)
    get_grade(f"{os.path.basename(file).split('-')[0][:10]}-XX-XX", value_dict, "人员退休", serial_id)
    shutil.move(FILE_PATH + '/C20_离退休.xlsx', local + f"/103_离退休事件_{os.path.basename(file)}")
    shutil.move(FILE_PATH + '/tmp-离退.xlsx', local + f"/{os.path.basename(file)[:10]}_离退休事件模板.xlsx")
