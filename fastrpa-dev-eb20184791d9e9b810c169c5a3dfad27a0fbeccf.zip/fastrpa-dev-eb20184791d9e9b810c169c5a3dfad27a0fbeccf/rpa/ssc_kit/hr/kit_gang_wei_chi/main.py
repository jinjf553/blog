"""循环补充销售建岗岗位池"""
from rpa.ssc_rpa.hr.rpa_jian_gang.main import main_4_1_01

if __name__ == '__main__':
    main_4_1_01()
