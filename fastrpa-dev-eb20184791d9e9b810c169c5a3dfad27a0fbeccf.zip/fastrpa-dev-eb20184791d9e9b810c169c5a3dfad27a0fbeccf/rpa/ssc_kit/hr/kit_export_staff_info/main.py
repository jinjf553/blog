from rpa.fastrpa.log import config


def main(filename: str):
    pass


if __name__ == '__main__':
    config('export_staff_info')
    filename = r''
    main(filename)
