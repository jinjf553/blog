"""事务码 /n KS02
   pyinstaller --clean -F -c --noupx --add-binary='./rpa/fastrpa/third_party/encrypt;./rpa/fastrpa/third_party/encrypt' --key=PBmmQGUYL3xF4kbD -n ks02 ./rpa/ssc_kit/hr/ks02/main.py
"""
import datetime
import logging
import sys

from rpa.fastrpa.adtable import AdTable, load_from_xlsx_file
from rpa.fastrpa.log import config, logfn
from rpa.fastrpa.sap.session import SapClose
from rpa.ssc.hr.sap.export_ks02 import _export_ks02


@logfn
def main(filename: str):
    lt_ks02: AdTable = load_from_xlsx_file(filename)  # 加载KS02数据提取模板
    lt_ks02.del_blank_rows_by_column('A')  # 根据A列删除空行
    lt_ks02['A'][1].value = '主成本中心'
    lt_ks02['B'][1].value = '名称'
    lt_ks02['C'][1].value = '描述'
    lt_ks02['D'][1].value = '负责的用户'
    lt_ks02['E'][1].value = '负责人'
    lt_ks02['F'][1].value = '部门'
    lt_ks02['G'][1].value = '成本中心类型'
    lt_ks02['H'][1].value = '层次结构范围'
    lt_ks02['I'][1].value = '公司代码'
    lt_ks02['J'][1].value = '业务范围'
    lt_ks02['K'][1].value = '功能范围'
    lt_ks02['L'][1].value = '货币'
    lt_ks02['M'][1].value = '利润中心'
    lt_ks02['N'][1].value = '错误提示'
    with SapClose():
        _export_ks02(lt_ks02)
    lt_ks02.filename
    lt_ks02.save(filename)
    logging.info(f'保存文件至{filename}')


if __name__ == '__main__':
    now = datetime.datetime.now().strftime(r'%Y%m%d%H%M%S')
    config('KS02.log')
    if len(sys.argv) >= 2:
        filename = sys.argv[1]
        if filename[-5:].lower() == '.xlsx':
            main(filename)
            logging.info('程序执行完毕')
        else:
            logging.info(f'文件不是xlsx格式，文件名：{filename}')
    else:
        # main('x:/32650000-KS02.xlsx')
        logging.info('请拖动主成本中心模板到程序上执行。')
    input()
