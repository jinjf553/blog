import datetime
import logging
import traceback
from pathlib import Path
from time import sleep
from typing import Any, Dict, List

import pandas as pd
import pyperclip
import pythoncom
import rpa.config
from pandas import DataFrame
from rpa.fastrpa.adtable import AdTable
from rpa.fastrpa.log import config
from rpa.fastrpa.sap.session import attach_sap
from rpa.fastrpa.tempdir import gentempdir
from rpa.fastrpa.utils.peek_encoding import peek_file_encoding
from rpa.ssc.hr.orm.dims_utils import load_tb_dim_hr_diao_pei
from rpa.ssc.sap.query import parse_query_string


def pass_sap_plan_window(session: Any):
    """关闭选择计划版本窗口(第一次时弹出，后续不弹出)"""
    try:
        session = session if session else attach_sap('share')
        sap_title = session.findById("wnd[1]").Text
        if '选择计划版本' in sap_title:
            session.findById("wnd[1]/tbar[0]/btn[0]").press()  # 点击[继续]
    except pythoncom.com_error:  # pylint: disable=fixme, no-member
        pass


def pass_sap_info_window(session: Any):
    """关闭SAP信息窗口（一般为查询结果无数据或机构编码不存在）"""
    session = session if session else attach_sap('share')
    try:
        sap_title = session.findById("wnd[1]").Text
        if '信息' in sap_title:
            info_text = session.findById("wnd[1]/usr/txtMESSTXT1").text
            session.findById("wnd[1]/tbar[0]/btn[0]").press()  # 点击[继续]
            raise Exception(info_text)
        else:
            session.findById("wnd[1]/tbar[0]/btn[0]").press()  # 点击[继续]
    except pythoncom.com_error:  # pylint: disable=fixme, no-member
        pass


def export_guitree(session: Any) -> DataFrame:
    session = session if session else attach_sap('share')
    sap_gui_tree = session.findById("wnd[0]/usr/cntlCUSTOM_CONTROL/shellcont/shell/shellcont[1]/shell[1]")
    key = sap_gui_tree.GetAllNodeKeys()[0]
    while True:
        try:
            is_expandable = sap_gui_tree.IsFolderExpandable(key)
            is_expand = sap_gui_tree.IsFolderExpanded(key)
            if is_expandable is True and is_expand is False:
                sap_gui_tree.expandNode(key)
            key = sap_gui_tree.GetNextNodeKey(key)
        except Exception:
            break
    sap_gui_tree_column_names = list(sap_gui_tree.GetColumnNames())
    headers = ['层级']
    for col, name in enumerate(sap_gui_tree_column_names, start=2):
        header = sap_gui_tree.GetColumnTitleFromName(name)  # 标题
        headers.append(header)
    tmp_table = []
    for rn, key in enumerate(sap_gui_tree.GetAllNodeKeys(), start=2):
        hierarchy = sap_gui_tree.GetHierarchyLevel(key)  # 层级
        tmp_line = [hierarchy]
        for col, name in enumerate(sap_gui_tree_column_names, start=2):
            text = sap_gui_tree.GetItemText(key, name)  # 文本
            tmp_line.append(text)
        tmp_table.append(tmp_line)
    df = DataFrame(tmp_table)
    df.columns = headers
    return df


def export_guitable(session: Any) -> DataFrame:
    session = session if session else attach_sap('share')
    session.findById("wnd[0]/tbar[1]/btn[9]").press()
    # session.findById("wnd[1]/usr/subSUBSCREEN_STEPLOOP:SAPLSPO5:0150/sub:SAPLSPO5:0150/radSPOPLI-SELFLAG[4,0]").select()  # 勾选[保存到剪切板]
    # session.findById("wnd[1]/tbar[0]/btn[0]").press()  # 确定
    # query_string = pyperclip.paste()
    session.findById("wnd[1]/usr/subSUBSCREEN_STEPLOOP:SAPLSPO5:0150/sub:SAPLSPO5:0150/radSPOPLI-SELFLAG[0,0]").select()  # 勾选[未转换的]
    session.findById("wnd[1]/tbar[0]/btn[0]").press()  # 保存到本地文件
    output_dir = gentempdir()
    query_string_filename = Path(output_dir).joinpath('query_string.txt').as_posix()
    session.findById("wnd[1]/usr/ctxtDY_PATH").text = output_dir  # 目录
    session.findById("wnd[1]/usr/ctxtDY_FILENAME").text = "query_string.txt"  # 文件名（ANSI编码）
    session.findById("wnd[1]/usr/ctxtDY_FILENAME").caretPosition = 16
    if Path(query_string_filename).exists() is True:
        session.findById("wnd[1]/tbar[0]/btn[11]").press()  # 覆盖
    else:
        session.findById("wnd[1]/tbar[0]/btn[0]").press()  # 生成
    for _ in range(60):  # 1分钟，等待文件写完
        sap_status = session.findById("wnd[0]/sbar/pane[0]").text
        if '字节已传输，代码页为' in sap_status:
            break
        else:
            sleep(1)
    # WARN GUI安全性窗口已禁止弹出
    query_string_encoding = peek_file_encoding(Path(output_dir).joinpath('query_string.txt').as_posix())
    query_string = Path(output_dir).joinpath('query_string.txt').read_text(encoding=query_string_encoding)
    headers, table = parse_query_string(query_string)
    df = DataFrame(table)
    df.columns = headers
    return df


def export_info(keycode: str, org_ids: List[str], key_date: str, begin_date='', end_date='', depth='0') -> DataFrame:
    """
    """
    session = attach_sap()
    session.findById("wnd[0]/tbar[0]/okcd").text = keycode  # 填入[事务码]
    session.findById("wnd[0]").sendVKey(0)  # 按下[回车]
    session.findById("wnd[0]/usr/ctxtPCHOBJID-LOW").text = "12345678"  # 机构编码先填充占位字符，再清空，否则会报错“警告：将编辑对象类型的所有对象类型”
    session.findById("wnd[0]/usr/btn%_PCHOBJID_%_APP_%-VALU_PUSH").press()  # 点击[多项选择]
    pass_sap_plan_window(session)
    session.findById("wnd[1]/tbar[0]/btn[16]").press()  # 点击[清空]
    pyperclip.copy('\r\n'.join(org_ids))  # 复制机构编码到剪切板
    session.findById("wnd[1]/tbar[0]/btn[24]").press()  # 点击[粘贴]
    session.findById("wnd[1]/tbar[0]/btn[8]").press()  # 点击[确认]
    pass_sap_info_window(session)
    if keycode in ('S_AHR_61016493', 'S_AHR_61016494', 'S_AHR_61016495'):
        session.findById("wnd[0]/usr/btn$PS$ZTST").press()  # 点击[执行]
        pass_sap_plan_window(session)
        if key_date:
            session.findById("wnd[0]/usr/ctxtPCHOBEG").text = key_date  # 填入[关键日期]
        else:
            try:
                session.findById("wnd[0]/usr/btn$PS$PZTR").press()  # 期间
            except pythoncom.com_error:  # pylint: disable=fixme, no-member
                pass
            session.findById("wnd[0]/usr/btn$PS$ZTRZ").press()  # 其他期间
            session.findById("wnd[0]/usr/ctxtPCHOBEG").text = begin_date  # 开始日期
            session.findById("wnd[0]/usr/ctxtPCHOEND").text = end_date  # 结束日期
        if depth != '0':
            session.findById("wnd[0]/usr/chkSEL_BOX").selected = -1  # 勾选[标准选择屏幕]选择框
            session.findById("wnd[0]/tbar[1]/btn[8]").press()  # 点击[执行]
            session.findById("wnd[0]/usr/ctxtPCHWEGID").text = 'ORGEH'  # 评估路径
            session.findById("wnd[0]/usr/txtPCHDEPTH").text = depth  # 显示深度
        session.findById("wnd[0]/tbar[1]/btn[8]").press()  # 执行
        pass_sap_info_window(session)
        sap_title = session.findById("wnd[0]").Text
        if '运行时间错误' in sap_title:  # SAP窗口标题
            raise TimeoutError  # 导出超时
        sap_status = session.findById("wnd[0]/sbar/pane[0]").text  # SAP状态栏文本
        if '不允许评估路径' in sap_status or '没有找到输入值的数据' in sap_status:
            raise Exception(sap_status)
        session.findById("wnd[0]/usr/cntlCUSTOM_CONTROL/shellcont/shell/shellcont[1]/shell[0]").pressButton("&LOAD")  # 选择布局格式
        session.findById("wnd[1]/tbar[0]/btn[71]").press()  # 搜索
        session.findById("wnd[2]/usr/txtGS_SEARCH-VALUE").text = "/CS"  # 检索项
        session.findById("wnd[2]/usr/cmbGS_SEARCH-SEARCH_ORDER").key = "0"  # 搜索方向:由表格开头向下
        session.findById("wnd[2]/usr/chkGS_SEARCH-EXACT_WORD").selected = -1  # 仅查找整个词或值
        session.findById("wnd[2]/tbar[0]/btn[0]").press()  # 确定
        try:
            session.findById("wnd[2]/tbar[0]/btn[12]").press()  # 取消(此时定位到第一个匹配项，点击取消，停止搜索)
        except Exception:  # nosec 在特定机器上需要点击取消按钮
            pass
        session.findById("wnd[1]/usr/cntlGRID/shellcont/shell").clickCurrentCell()  # 双击匹配项
        df = export_guitree(session)  # 导出层级表
    elif keycode == 'S_AHR_61016503':
        session.findById("wnd[0]/usr/ctxtPCHOBEG").text = key_date  # 填入[关键日期]
        if depth != '0':
            session.findById("wnd[0]/usr/chkSEL_BOX").selected = -1  # 勾选[标准选择屏幕]选择框
            session.findById("wnd[0]/tbar[1]/btn[8]").press()  # 点击[执行]
            session.findById("wnd[0]/usr/ctxtPCHWEGID").text = 'ORGEH'  # 评估路径
            session.findById("wnd[0]/usr/txtPCHDEPTH").text = depth  # 显示深度
        session.findById("wnd[0]/tbar[1]/btn[8]").press()  # 执行
        pass_sap_plan_window(session)
        pass_sap_info_window(session)
        sap_title = session.findById("wnd[0]").Text
        if '运行时间错误' in sap_title:  # SAP窗口标题
            raise TimeoutError  # 导出超时
        sap_status = session.findById("wnd[0]/sbar/pane[0]").text  # SAP状态栏文本
        if '不允许评估路径' in sap_status or '没有找到输入值的数据' in sap_status:
            raise Exception(sap_status)
        session.findById("wnd[0]/tbar[1]/btn[33]").press()  # 选择
        session.findById("wnd[1]/usr/ssubD0500_SUBSCREEN:SAPLSLVC_DIALOG:0501/cntlG51_CONTAINER/shellcont/shell").contextMenu()  # 右键菜单
        session.findById("wnd[1]/usr/ssubD0500_SUBSCREEN:SAPLSLVC_DIALOG:0501/cntlG51_CONTAINER/shellcont/shell").selectContextMenuItem("&FIND")  # 查找
        session.findById("wnd[2]/usr/txtGS_SEARCH-VALUE").text = "/CS"  # 检索项
        session.findById("wnd[2]/usr/cmbGS_SEARCH-SEARCH_ORDER").key = "0"  # 搜索方向:由表格开头向下
        session.findById("wnd[2]/usr/chkGS_SEARCH-EXACT_WORD").selected = -1  # 仅查找整个词或值
        session.findById("wnd[2]/tbar[0]/btn[0]").press()  # 确定
        try:
            # 在特定机器上需要点击取消按钮
            session.findById("wnd[2]/tbar[0]/btn[12]").press()  # 取消(此时定位到第一个匹配项，点击取消，停止搜索)
        except pythoncom.com_error:  # pylint: disable=fixme, no-member
            pass
        session.findById("wnd[1]/usr/ssubD0500_SUBSCREEN:SAPLSLVC_DIALOG:0501/cntlG51_CONTAINER/shellcont/shell").clickCurrentCell()  # 双击匹配项
        df = export_guitable(session)
    else:
        raise Exception('事务码非码值')
    return df


# 历史超时节点
TIMEOUT: Dict[str, bool] = {'S_AHR_61016494#10010060': True,  # 46367
                            'S_AHR_61016494#32850000': True,
                            'S_AHR_61016494#15570000': True,  # 255168
                            'S_AHR_61016494#15570036': True,
                            'S_AHR_61016494#15570037': True,
                            'S_AHR_61016494#15570045': True,
                            'S_AHR_61016494#10010004': True,  # 31848
                            'S_AHR_61016494#10010065': True,  # 32211
                            'S_AHR_61016494#33250000': True,  # 60125
                            'S_AHR_61016494#33100000': True,
                            'S_AHR_61016495#15570000': True,
                            'S_AHR_61016495#10010004': True,
                            }


def export_info2(keycode: str, org_ids: List[str], key_date: str, begin_date='', end_date='', depth='0', base_level=0) -> DataFrame:
    """导出机构、岗位、人员信息，超时时先导出子一级内容，再尝试导出子一级下全部内容"""
    key = keycode + '#' + org_ids[0]
    indent_prefix = '>>' * base_level
    try:
        logging.info(f'{indent_prefix} 准备导出: {keycode}，org_ids: {org_ids}，key_date: {key_date}，depth: {depth}')
        # 历史超时判断，如果超时，则直接进入超时处理步骤
        # TODO 增加break判断，避免循环
        if key in TIMEOUT.keys() and TIMEOUT[key] is True and depth == '0':
            raise TimeoutError()
        _df = export_info(keycode, org_ids, key_date, depth=depth)
        logging.info(f'{indent_prefix} 导出成功，数据量: {len(_df)}')
        _df['层级'] = _df['层级'].apply(lambda h: base_level + h)
        return _df
    except TimeoutError:
        TIMEOUT[keycode + '#' + org_ids[0]] = True
        logging.error(f'{indent_prefix} 导出超时: {keycode}，org_ids: {org_ids}，key_date: {key_date}，depth: {depth}')
        # logging.info(f'{indent_prefix} 导出子一级: {keycode}，org_ids: {org_ids}，key_date: {key_date}，depth: {2}')
        df = export_info2(keycode, org_ids, key_date, depth='2', base_level=base_level)  # 先导出子一级
        # logging.info(f'{indent_prefix} 导出成功: {len(df)}')
        _dfs = [df[0:1]]
        for idx, row in df[1:].iterrows():
            _dfs.append(df[idx:idx + 1])
            if row['对象类型'] == 'O':
                _org_ids = [row['扩展对象 ID']]
                if org_ids == ['15570000'] and _org_ids != ['14400000']:  # 15570000下只导出14400000
                    logging.info(f'特殊处理：炼化企业15570000跳过导出子一级机构：{_org_ids}')
                    continue
                logging.info(f'{indent_prefix} 导出子一级机构下所有机构：keycode: {keycode}，org_ids: {_org_ids}，key_date: {key_date}')
                _df = export_info2(keycode, _org_ids, key_date, base_level=1 + base_level)
                logging.info(f'{indent_prefix} 导出成功，数据量: {len(_df)}')
                if isinstance(_df, DataFrame) and _df.empty is False:
                    _dfs.append(_df[1:])
        if len(_dfs) >= 1:
            return pd.concat(_dfs).reset_index()
        else:
            return DataFrame()
    except Exception as e:
        logging.error(e)
        logging.error(f"异常原因: {traceback.format_exc()}")
        return DataFrame()


def export_info3(keycode: str, org_ids: List[str], key_date: str, staff_group_name: str, begin_date='', end_date='', depth='0', base_level=0) -> DataFrame:
    """增加路径、父节点、对应业务组名称，是否有子节点"""
    df = export_info2(keycode, org_ids, key_date, begin_date, end_date, depth, base_level)
    if keycode in ['S_AHR_61016493', 'S_AHR_61016494', 'S_AHR_61016495']:
        df['id'] = ''
        df['路径'] = ''
        df['父节点'] = ''
        df['业务组'] = staff_group_name
        df['是否有子节点'] = ''
        rn_path = []
        parent_id = 'OFFFFFFFF'
        parent_id_path = []
        max_rn = max(df.index)
        for rn in df.index:
            df['id'][rn] = df['对象类型'][rn] + df['扩展对象 ID'][rn]
            if df['层级'][rn] == 0:
                rn_path = [rn]
                parent_id = 'OFFFFFFFF'
                parent_id_path = [parent_id]
            elif df['层级'][rn] > df['层级'][rn_path[-1]]:
                parent_id = df['id'][rn_path[-1]]
                rn_path.append(rn)
                parent_id_path.append(parent_id)
            else:
                pop_count = df['层级'][rn_path[-1]] - df['层级'][rn]
                for _ in range(pop_count):
                    rn_path.pop()
                    parent_id_path.pop()
                rn_path.pop()
                rn_path.append(rn)
                parent_id = parent_id_path[-1]
            if rn < max_rn and df['层级'][rn] < df['层级'][rn + 1]:
                has_children = '1'
            else:
                has_children = '0'
            df.loc[rn, '路径'] = '>'.join(parent_id_path)
            df.loc[rn, '父节点'] = parent_id
            df.loc[rn, '是否有子节点'] = has_children
    return df


def main():
    lt_dims: AdTable = load_tb_dim_hr_diao_pei()  # 加载码表
    df_dims: DataFrame = lt_dims.to_dataframe()  # 转换为DataFrame
    df_tmp = df_dims[['BB', 'BL']].drop_duplicates(subset=['BB', 'BL'], keep='first', inplace=False)  # 根据机构编码、组别去重
    df_tmp = df_tmp = df_tmp[df_tmp['BB'] != ''].copy()  # 去除空行
    key_date = datetime.datetime.now().strftime(r'%Y%m01')  # yyyymm01
    keycodes = ['S_AHR_61016493', 'S_AHR_61016494', 'S_AHR_61016495']
    for keycode in keycodes:
        for org_id, staff_group_name in df_tmp.values:
            # 这些代码-机构在导出时，比其它代码-机构多一列，因此需要筛选出相同的列再保存，否则设置列名会报错
            # ['S_AHR_61016494#15570000',
            #  'S_AHR_61016494#10010004',
            #  'S_AHR_61016494#10010065',
            #  'S_AHR_61016494#33250000',
            #  'S_AHR_61016494#10010060',
            #  'S_AHR_61016495#15570000',
            #  'S_AHR_61016495#10010004']
            try:
                df = export_info3(keycode, [org_id], key_date, staff_group_name)
                df = df[['层级', '对象描述', '简称', '对象类型', '扩展对象 ID', '状态 (对象)', '起始日期 (对象)', '结束日期 (对象)',
                         '状态 (关系)', '开始日期 (关系)', '结束日期 (关系)', '百分比', '路径', '父节点', '业务组', '是否有子节点']]
                df.columns = ['obj_level', 'description', 'short_name', 'obj_type', 'obj_id', 'obj_state', 'obj_begin_date', 'obj_end_date',
                              'rel_state', 'rel_begin_date', 'rel_end_date', 'ratio', 'obj_path', 'parent_id', 'group_name', 'has_children']
                df.to_csv(f'{rpa.config.D_RPA}/{keycode}#{org_id}.csv', index=False, encoding='utf-8')
            except Exception as e:
                logging.error(f'{keycode}#{org_id} 导出遇到错误：{e}')


if __name__ == '__main__':
    config('export_job_info_full.log')
    main()
    logging.info(f'TIMEOUT: {TIMEOUT.keys()}')
