#!/usr/bin/env python
# -*- coding: utf-8 -*-
# @File    : main.py
# @Author  : jinjianfeng
import time
from datetime import datetime

from rpa.public.tools import click_able, get_attr
from rpa.ssc.hr.orm.orm_ope import Query
from rpa.ssc.hr.orm.session import DbSession
from rpa.ssc.hr.orm.tb_dim_hr_staff import TB_DIM_HR_STAFF
from rpa.ssc.hr.orm.tb_hr_sr import SR
from rpa.ssc.hr.orm.tb_hr_whole_process_tracking import FlowTrack
from rpa.ssc_kit.hr.kit_chai_dan.upload import login
from selenium.webdriver.support.wait import WebDriverWait


def flow_tracking(browser, sr, sr_id, workers):
    # browser = login(chrome="chrome_flow_tracking")
    wait = WebDriverWait(browser, 10)
    # wait.until(lambda x: x.find_element_by_xpath('//*[@id="C4_W17_V18_ZSRV-SCH"]')).click()
    click_able(browser, '//*[@id="C4_W17_V18_ZSRV-SCH"]')
    wait.until(lambda x: x.find_element_by_xpath('//*[@id="C16_W51_V52_V53_search_parameters[3].VALUE1"]')).clear()
    wait.until(lambda x: x.find_element_by_xpath('//*[@id="C16_W51_V52_V53_search_parameters[3].VALUE1"]')).send_keys(sr)
    # wait.until(lambda x: x.find_element_by_xpath('//*[@id="C16_W51_V52_Searchbtn"]')).click()
    click_able(browser, '//*[@id="C16_W51_V52_Searchbtn"]')
    time.sleep(0.5)
    result = wait.until(lambda x: x.find_element_by_xpath('//*[@class="th-sf-rs-title-table"]')).text
    if "1" in result:
        worker = wait.until(lambda x: x.find_element_by_xpath('//*[@id="C16_W51_V52_V54_searchresult_table[1].person_resp_list"]')).text
        worker = str(worker).split()[0]
        wait.until(lambda x: x.find_element_by_xpath('//*[@id="C16_W51_V52_V54_searchresult_table[1].object_id"]')).click()
        state = wait.until(lambda x: x.find_element_by_xpath('//*[@id="C18_W59_V61_V64_thtmlb_textView_16"]')).text
    else:
        return
    click_able(browser, '//*[text()="流程检查清单"]')
    count = len(wait.until(lambda x: x.find_elements_by_xpath('//*[@id="C23_W74_V75_V77_ChecklistStepEL_TableHeader"]/tbody/tr')))
    for i in range(1, count + 1):
        step_state = wait.until(lambda x: x.find_element_by_xpath(f'//*[@class="th-clr-tbody"]/tr[{i}]/td[5]')).text
        start_date = wait.until(lambda x: x.find_element_by_xpath(f'//*[@class="th-clr-tbody"]/tr[{i}]/td[6]')).text
        end_date = wait.until(lambda x: x.find_element_by_xpath(f'//*[@class="th-clr-tbody"]/tr[{i}]/td[9]')).text
        worker_ = wait.until(lambda x: x.find_element_by_xpath(f'//*[@class="th-clr-tbody"]/tr[{i}]/td[4]')).text
        # worker, flag = (worker_.strip().split()[0], True) if worker_.strip().split()[0] in workers else (worker, False)
        worker = worker_.strip().split()[0]
        if "结束" in step_state and (start_date.strip() or end_date.strip()):
            step = wait.until(lambda x: x.find_element_by_xpath(f'//*[@class="th-clr-tbody"]/tr[{i}]/td[2]')).text
            start_time = wait.until(lambda x: x.find_element_by_xpath(f'//*[@class="th-clr-tbody"]/tr[{i}]/td[7]')).text
            end_time = wait.until(lambda x: x.find_element_by_xpath(f'//*[@class="th-clr-tbody"]/tr[{i}]/td[10]')).text
            start, end = (start_date + start_time).strip(), (end_date + end_time).strip()
            with DbSession() as s:
                s.add(FlowTrack(step=step, worker=worker, sr_id=sr_id,
                                start_time=datetime.strptime(start, '%Y.%m.%d%H:%M') if start else None,
                                end_time=datetime.strptime(end, '%Y.%m.%d%H:%M')) if end else None)

    click_able(browser, '//*[text()="日期"]')
    click_able(browser, '//*[@id="C24_W88_V89_DatesTable_pag_exp"]')
    get_attr(browser, '//*[@id="C24_W88_V89_DatesTable_pag_exp"]/img', "title", "折叠")
    count = len(wait.until(lambda x: x.find_elements_by_xpath('//*[@id="C24_W88_V89_DatesTable_TableHeader"]/tbody/tr')))
    for i in range(1, count + 1):
        start_date = wait.until(lambda x: x.find_element_by_xpath(f'//*[@class="th-clr-tbody"]/tr[{i}]/td[2]')).text
        if not str(start_date).strip():
            continue
        step = wait.until(lambda x: x.find_element_by_xpath(f'//*[@class="th-clr-tbody"]/tr[{i}]/td[1]')).text
        start_time = wait.until(lambda x: x.find_element_by_xpath(f'//*[@class="th-clr-tbody"]/tr[{i}]/td[3]')).text
        with DbSession() as s:
            s.add(FlowTrack(step=step, worker=worker, sr_id=sr_id,
                            start_time=datetime.strptime(start_date + start_time, '%Y.%m.%d%H:%M:%S')))

    click_able(browser, '//*[text()="转寄日志记录表"]')
    count = wait.until(lambda x: x.find_elements_by_xpath('//*[@id="C25_W90_V91_TABLE_TableHeader"]/tbody/tr'))
    for i in range(1, len(count) + 1):
        if "未找到结果" in count[i - 1].text:
            continue
        step = wait.until(lambda x: x.find_element_by_xpath(f'//*[@class="th-clr-tbody"]/tr[{i}]/td[4]')).text
        worker = wait.until(lambda x: x.find_element_by_xpath(f'//*[@class="th-clr-tbody"]/tr[{i}]/td[3]')).text
        start_date = wait.until(lambda x: x.find_element_by_xpath(f'//*[@class="th-clr-tbody"]/tr[{i}]/td[5]')).text
        start_time = wait.until(lambda x: x.find_element_by_xpath(f'//*[@class="th-clr-tbody"]/tr[{i}]/td[6]')).text
        with DbSession() as s:
            s.add(FlowTrack(step=f"转寄{i}:{step}", worker=worker, sr_id=sr_id,
                            start_time=datetime.strptime(start_date + start_time, '%Y.%m.%d%H:%M')))
    with DbSession() as sess:
        sess.query(SR).filter(SR.sr == sr).update({"state": state})


def main():
    browser = login(chrome="chrome_flow_tracking")
    workers = [res.staff_name.strip() for res in Query(TB_DIM_HR_STAFF) if res.staff_name]
    try:
        with DbSession() as sess:
            res = sess.query(SR).filter(SR.state != "已完成").all()
            for r in res:
                sr_id, sr = r.id, r.sr
                print(sr)
                flow_tracking(browser, sr, sr_id, workers)
    except Exception as e:
        raise e
        main()


if __name__ == '__main__':
    main()
