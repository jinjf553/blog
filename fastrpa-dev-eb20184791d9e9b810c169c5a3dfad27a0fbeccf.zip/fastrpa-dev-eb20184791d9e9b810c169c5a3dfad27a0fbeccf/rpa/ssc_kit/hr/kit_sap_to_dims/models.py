from contextlib import contextmanager

from rpa.ssc.hr.orm.base_model_hr import hr
from sqlalchemy import Column, DateTime, ForeignKey, Integer, String, Text
from sqlalchemy.orm import relationship


class Name(hr):
    __tablename__ = 'name_manager'
    id = Column(Integer, primary_key=True)
    name = Column(String(100), comment="管理器名称")
    scope = Column(String(40), comment="范围")
    create_time = Column(DateTime, comment="创建时间")
    update_time = Column(DateTime, comment="上次更新时间")
    info = Column(Text, comment="更新记录")
    sta = Column(Integer, comment="是否有效:0无效(表示已被删除),1有效")

    def __repr__(self) -> str:
        return f"{self.id} | {self.name}" \
               f" | {self.scope} | {self.create_time} | {self.update_time} | {self.info} | {self.sta}"

    def __str__(self) -> str:
        return super().__str__()


class Value(hr):
    __tablename__ = "name_manager_value"
    id = Column(Integer, primary_key=True)
    name_id1 = Column(Integer, comment="name_manager.id1")
    name_id2 = Column(Integer, comment="name_manager.id2")
    cell = Column(String(20), comment="单元格")
    value = Column(String(255), comment="码值")
    create_time = Column(DateTime, comment="创建时间")
    update_time = Column(DateTime, comment="上次更新时间")
    info = Column(Text, comment="更新记录")
    sta = Column(Integer, comment="是否有效:0无效(表示已被删除),1有效")
    to_value = relationship("Name", secondary="name_manager_relationship", backref="to_name")

    def __repr__(self) -> str:
        return f"{self.id} | {self.name_id1} | {self.name_id2} | {self.cell} | {self.value} | {self.create_time} | " \
               f"{self.update_time} | {self.info}"


class Rel(hr):
    __tablename__ = "name_manager_relationship"
    id = Column(Integer, primary_key=True)
    name_id = Column(Integer, ForeignKey("name_manager.id"), comment="name_manager.id")
    value_id = Column(Integer, ForeignKey("name_manager_value.id"), comment="name_manager_value.id")

    def __repr__(self) -> str:
        return f"{self.id} | {self.name_id} | {self.value_id}"


class Test(hr):
    __tablename__ = "test_jinjianfeng"
    id = Column(Integer, primary_key=True, autoincrement=True)
    name = Column(String(10), primary_key=True, unique=True)
