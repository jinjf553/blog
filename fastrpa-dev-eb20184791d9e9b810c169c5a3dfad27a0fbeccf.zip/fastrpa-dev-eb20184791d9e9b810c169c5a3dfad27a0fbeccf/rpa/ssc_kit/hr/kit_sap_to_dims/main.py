import logging
import re
from collections import defaultdict

from openpyxl import load_workbook
from rpa.ssc.hr.orm.session import DbSession
from rpa.ssc_kit.hr.kit_sap_to_dims.models import Name

mb_filename = r"x:\Users\lenovo\Documents\SAP\SAP GUI\ZBI0006.xlsx"


def check_mb_data(file):  # 检查参数指定的SAP模板文件中数据符合模板码表要求 result验证条件 check_result 单元格码表库
    # wb_gx = load_workbook(os.path.join(os.path.dirname(bd_file), mb_filename))  ## '9019_HR_BI_9019岗位分类信息.xlsx'))
    wb_gx = load_workbook(file, data_only=True)
    sht_gx = wb_gx.active  # ['9019_岗位分类信息']

    # logging.info(a, len(b))
    # logging.info(wb_gx.defined_names)
    valid = sht_gx.data_validations.dataValidation
    dic = defaultdict(list)
    for x in valid:
        val = re.findall('"(NM_..*?)"', f'"{str(x.formula1)}"')
        dic[str(x.sqref).split(":")[0]] = [str(x.formula1), val[0] if val else ""]
        # logging.info(str(x.sqref).split(":")[0], str(x.formula1))

    dic2 = defaultdict(list)
    for x in valid:
        key = re.findall('"(NM_..*?)"', f'"{str(x.formula1)}"')
        if not key:
            continue
        val_str = "".join([y[:10] for y in str(x.formula1).split("&LEFT")[1:]])
        val = list(set(re.findall(r"\((.*?\d+),(\d+)\)", val_str)))
        for i in range(len(val)):
            if val[i][0] in dic.keys() and len(dic[val[i][0]][0]) < 30:
                dic2[key[0]].append(dic[val[i][0]][0] + f"#{val[i][1]}#1")
                # logging.info(key, dic[val[i][0]][0] + f"#{val[i][1]}")
            else:
                dic2[key[0]].append(dic[val[i][0]][1] + f"#{val[i][1]}#2")
                # logging.info(dic[val[i][0]][1], dic[val[i][0]][0])
                pass
    with DbSession() as s:
        for k, v in dic2.items():
            # tmp_dic = defaultdict(str)
            for x in v:
                res = s.query(Name).with_for_update().filter(Name.name == x.split("#")[0]).first()
                logging.info(res.to_name)
    return

    # names = wb_gx.defined_names.localnames(None)
    # dic = {x: wb_gx.defined_names[x].attr_text for x in names}

    # # 更新名称管理器
    # start = time.time()
    # with Session() as s:
    #     res_dic = {res.name: [res.scope, res.info, res.sta] for res in s.query(Name).with_for_update().all()}
    #     for k, v in dic.items():
    #         logging.info(k)
    #         scope = "".join(v.split("$")[1:]) if ":" in v else ":".join(["".join(v.split("$")[1:])] * 2)
    #         if k not in res_dic.keys():
    #             s.add(Name(name=k, scope=scope, create_time=dt.now(), sta=1))
    #         elif res_dic[k][0] != scope or res_dic[k][2] != 1:
    #             sql = s.query(Name).with_for_update().filter(Name.name == k)
    #             sql.update({"scope": scope, "update_time": dt.now(), "sta": 1,
    #                         "info": f"{res_dic[k][1]}| {dt.now()} update scope: {res_dic[k][0]}"})

    # with Session() as s:
    #     results = s.query(Name).with_for_update().filter(Name.sta == 1).all()
    #     if len(results) != len(dic.keys()):
    #         for res in results:
    #             if res.name not in dic.keys():
    #                 r = s.query(Name).with_for_update().filter(Name.name == res.name)
    #                 r.update({"update_time": dt.now(), "info": f"{res.info}| {dt.now()} delete", "sta": 0})
    # use_time = time.time() - start
    # logging.info(use_time)

    # # 更新码值
    # start = time.time()
    # ws = wb_gx["码表"]
    # dic = defaultdict(str)
    # max_row, max_col = ws.max_row, ws.max_column
    # for j in range(1, max_col + 1):
    #     logging.info(j)
    #     letter = get_column_letter(j)
    #     for i in range(1, max_row + 1):
    #         cell = letter + str(i)
    #         if ws[cell].value:
    #             dic[cell] = ws[cell].value

    # with Session() as s:
    #     results = s.query(Value).with_for_update(of=Value).all()
    #     res_dic = {res.cell: [res.name_id1, res.name_id2, res.value, res.sta, res.info] for res in results}
    #     for k, v in dic.items():
    #         logging.info(k)
    #         if k not in res_dic.keys():
    #             s.add(Value(cell=k, value=v, create_time=dt.now(), sta=1))
    #         elif res_dic[k][2] != v or res_dic[k][3] != 1:
    #             sql = s.query(Value).with_for_update().filter(Value.cell == k)
    #             sql.update({"value": v, "update_time": dt.now(), "sta": 1,
    #                         "info": f"{res_dic[k][4]}| {dt.now()} update value: {res_dic[k][2]}"})

    # with Session() as s:
    #     results = s.query(Value).with_for_update().filter(Value.sta == 1).all()
    #     if len(results) != len(dic.keys()):
    #         for res in results:
    #             if res.cell not in dic.keys():
    #                 r = s.query(Value).with_for_update().filter(Value.cell == res.cell)
    #                 r.update({"update_time": dt.now(), "info": f"{res.info}| {dt.now()} delete", "sta": 0})
    # use_time = time.time() - start
    # logging.info(use_time)

    # with Session() as s:
    #     res = s.query(Name).with_for_update(read=True)
    #     for x in res:
    #         logging.info(f'{x.id}, {x.scope}')
    #         rng = re.findall(r"\d+", str(x.scope))
    #         string = str(x.scope).split(":")[0]
    #         flt = str(x.scope)[:len(string) - len(rng[0])]
    #         count = int(rng[1]) + 1 - int(rng[0])
    #         r = s.query(Name).with_for_update().filter(Name.id == x.id).first()
    #         if count == len(r.to_name) and list(r.to_name)[0].cell == string:
    #             continue
    #         else:
    #             logging.info(x.id)
    #             s.query(Rel).with_for_update().filter(Rel.name_id == x.id).delete()
    #         for j in range(int(rng[0]), int(rng[1]) + 1):
    #             value = s.query(Value).with_for_update(read=True).filter(Value.cell == flt + str(j)).first()
    #             if not value:
    #                 continue
    #             rel = s.query(Rel).with_for_update().filter(and_(Rel.name_id == x.id, Rel.value_id == value.id))
    #             if not rel.first():
    #                 s.add(Rel(name_id=x.id, value_id=value.id))
    # logging.info(str(x.scope)[:len(string) - len(rng[0])])
    # values = [x[0].value for x in ws[scope]]
    # val = k.split("_") + [""] * (6 - len(k.split("_"))) + ["".join(v.split("$")[1:]), dt.now(), dt.now(), ""]
    # obj = Name(**dict(zip(key, val)))
    # obj.to_name = [Value(create_time=dt.now(), update_time=dt.now(), value=x) for x in values]
    # with Session() as s:
    #     s.add(obj)


if __name__ == "__main__":
    check_mb_data(mb_filename)
    # with Session() as s:
    #     res = s.query(Name).all()
    #     for x in res:
    #         for i in x.to_name:
    #             logging.info(i)
    # logging.info([""] * 3)
    # name = Name(name1="test")
    # value = Value(value="test_value")
    # # name.value_name.append(Value(value="test_value"))
    # name.value_name = [Value(value="test_value")]
    # logging.info(name.value_name)
    # with Session() as s:
    #     s.add(name)
