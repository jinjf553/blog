#!/usr/bin/env python
# -*- coding: utf-8 -*-
# @File    : no_job_change.py
# @Author  : jinjianfeng
# @Contact : 553041800@qq.com
# @Link    : https://github.com/jinjf553
# @software: PyCharm
# @Date    : 2019/12/3 12:16
# @Version : ??
import logging
import os
import time

import wx
import wx.xrc
from openpyxl import load_workbook
from rpa.public.myftp import MYFTP

remote_daiban = "/HR人事/待办/"


class MyFrame1(wx.Frame):

    def __init__(self, parent):
        self.radio1_value = 0
        self.radio2_value = 0
        self.file_path = ""
        wx.Frame.__init__(self, parent, id=wx.ID_ANY, title=u"HR_RPA文件上传工具", pos=wx.DefaultPosition,
                          size=wx.Size(670, 400), style=wx.DEFAULT_FRAME_STYLE | wx.TAB_TRAVERSAL)

        self.SetBackgroundColour(wx.SystemSettings.GetColour(wx.SYS_COLOUR_INACTIVECAPTION))

        # self.m_menubar1 = wx.MenuBar(0)
        # self.m_menubar1.SetExtraStyle(wx.WS_EX_BLOCK_EVENTS)
        # self.m_menubar1.SetForegroundColour(wx.SystemSettings.GetColour(wx.SYS_COLOUR_WINDOWFRAME))
        # self.m_menubar1.SetBackgroundColour(wx.SystemSettings.GetColour(wx.SYS_COLOUR_WINDOW))

        # self.nmenu_1 = wx.Menu()
        # self.nmenu_2 = wx.MenuItem(self.nmenu_1, wx.ID_ANY, u"修改密码", wx.EmptyString, wx.ITEM_NORMAL)
        # self.nmenu_3 = wx.Menu()
        # self.m_menubar1.Append(self.nmenu_1, u"菜单")
        # self.nmenu_1.Append(self.nmenu_2)
        #
        # self.SetMenuBar(self.m_menubar1)

        bSizer6 = wx.BoxSizer(wx.VERTICAL)

        bSizer1 = wx.BoxSizer(wx.VERTICAL)

        bSizer2 = wx.BoxSizer(wx.HORIZONTAL)

        bSizer4 = wx.BoxSizer(wx.VERTICAL)

        sbSizer1 = wx.StaticBoxSizer(wx.StaticBox(self, wx.ID_ANY, u" 选择操作类型 "), wx.VERTICAL)

        bSizer51 = wx.BoxSizer(wx.HORIZONTAL)

        self.m_staticText1 = wx.StaticText(sbSizer1.GetStaticBox(), wx.ID_ANY, wx.EmptyString, wx.DefaultPosition,
                                           wx.Size(30, -1), 0)
        self.m_staticText1.Wrap(-1)
        bSizer51.Add(self.m_staticText1, 0, wx.ALL | wx.EXPAND, 5)
        self.m_radioBtn1 = wx.RadioButton(sbSizer1.GetStaticBox(), wx.ID_ANY, u" 事件待办", wx.DefaultPosition,
                                          wx.DefaultSize, 0)
        # self.m_radioBtn1.SetValue(True)
        bSizer51.Add(self.m_radioBtn1, 1, wx.ALIGN_CENTER_HORIZONTAL | wx.ALL, 5)

        self.m_radioBtn2 = wx.RadioButton(sbSizer1.GetStaticBox(), wx.ID_ANY, u"  手动拆单", wx.DefaultPosition,
                                          wx.DefaultSize, 0)
        bSizer51.Add(self.m_radioBtn2, 1, wx.ALL, 5)
        sbSizer1.Add(bSizer51, 1, wx.EXPAND, 5)

        self.m_filePicker1 = wx.FilePickerCtrl(sbSizer1.GetStaticBox(), wx.ID_ANY, wx.EmptyString, u"打开文件",
                                               u"*.*", wx.DefaultPosition, wx.DefaultSize, wx.FLP_DEFAULT_STYLE)
        dropTarget = FileDropTarget(self.m_filePicker1)
        self.SetDropTarget(dropTarget)
        self.m_filePicker1.SetPath(dropTarget.window.GetPath())
        sbSizer1.Add(self.m_filePicker1, 0, wx.ALL | wx.EXPAND, 5)

        bSizer4.Add(sbSizer1, 1, wx.EXPAND, 5)

        bSizer2.Add(bSizer4, 1, 0, 5)

        self.m_button1 = wx.Button(self, wx.ID_ANY, u"上传文件至FTP", wx.DefaultPosition, wx.Size(150, 80), 0)
        self.m_button1.SetFont(wx.Font(wx.NORMAL_FONT.GetPointSize(), 70, 90, 92, False, "微软雅黑"))
        self.m_button1.SetBackgroundColour(wx.SystemSettings.GetColour(wx.SYS_COLOUR_WINDOW))

        bSizer2.Add(self.m_button1, 0, wx.ALIGN_CENTER_VERTICAL | wx.RIGHT | wx.LEFT, 10)

        bSizer1.Add(bSizer2, 0, wx.EXPAND, 5)

        bSizer5 = wx.BoxSizer(wx.VERTICAL)

        bSizer5.SetMinSize(wx.Size(-1, 100))
        self.m_genericDirCtrl1 = wx.GenericDirCtrl(self, wx.ID_ANY, u"10.133.8.165", wx.DefaultPosition,
                                                   wx.Size(-1, 100),
                                                   wx.DIRCTRL_3D_INTERNAL | wx.DIRCTRL_SHOW_FILTERS | wx.SUNKEN_BORDER,
                                                   "All files (*.*)|*.*|Excel files (*.xlsx)|*.xlsx", 1)

        self.m_genericDirCtrl1.ShowHidden(False)
        self.m_genericDirCtrl1.SetMinSize(wx.Size(-1, 80))

        bSizer5.Add(self.m_genericDirCtrl1, 1, wx.EXPAND | wx.ALL, 5)

        bSizer1.Add(bSizer5, 1, wx.EXPAND, 5)

        bSizer6.Add(bSizer1, 1, wx.EXPAND, 5)

        self.SetSizer(bSizer6)
        self.Layout()
        self.m_statusBar1 = self.CreateStatusBar(2, 0, wx.ID_ANY)
        self.SetStatusWidths([-2, 140])
        self.SetStatusText("  请选择或拖动上传文件到窗口后执行...", 0)
        self.SetStatusText(time.strftime("%Y-%m-%d   %I:%M:%S", time.localtime(time.time())), 1)
        self.Centre(wx.BOTH)

        # Connect Events
        self.m_radioBtn2.Bind(wx.EVT_RADIOBUTTON, self.radio_手动拆单)
        self.m_radioBtn1.Bind(wx.EVT_RADIOBUTTON, self.radio_事件待办)
        self.m_filePicker1.Bind(wx.EVT_FILEPICKER_CHANGED, self.file_浏览)
        self.m_button1.Bind(wx.EVT_BUTTON, self.ftp_执行)
        self.tree = self.m_genericDirCtrl1.GetTreeCtrl()
        self.Bind(wx.EVT_TREE_SEL_CHANGED, self.file_选择文件, id=self.tree.GetId())
        self.file_选择文件(1)

    def __del__(self):
        pass

    def radio_事件待办(self, event):
        self.radio2_value = event.SetInt(1)
        self.radio1_value = event.GetInt()
        logging.info(f'{self.radio1_value}, {self.radio2_value}')

    def radio_手动拆单(self, event):
        self.radio1_value = event.SetInt(1)
        self.radio2_value = event.GetInt()
        logging.info(f'{self.radio1_value}, {self.radio2_value}')

    def file_浏览(self, event):
        event.Skip()

    def file_选择文件(self, event):
        abd = self.m_genericDirCtrl1.GetFilePath()
        self.m_filePicker1.SetPath(abd)

    def ftp_执行(self, event):
        self.file_path = self.m_filePicker1.GetPath()
        file_name = os.path.basename(self.file_path).split("-")
        logging.info(file_name)
        if len(file_name) != 4 or not file_name[0].isdigit() or len(
                file_name[1]) != 4 or file_name[2] not in ["员工入职", "岗位变动", "拆单", "二调直调", "不在岗", "劳务工",
                                                           "离岗", "离退休", "离退休减册", "在职减册", "内退", "转正"]:
            self.showinfo(message='所选文件命名格式有误。\r\n形如：1000118888-X000-事件类型-王某某.xlsx'
                                  '\r\n         将“事件类型”替换为其中一个：员工入职，岗位变动， 拆单， 二调直调， 不在岗，'
                                  '\r\n         劳务工，离岗，离退休，离退休减册，在职减册，内退，转正。')
            return True

        try:
            wb = load_workbook(self.file_path)
            ws = wb.active
            if str(ws["A2"].value) in ["人员调配表单", "人员离退表单"]:
                flag = "文件拆单" if self.radio2_value else self.showinfo(message="所选文件可能是待拆单文件，请勾选“手动拆单”后上传！")
            elif "新员工入职" in str(ws["A1"].value) or "新员工入职" in str(ws["A2"].value):
                flag = "目录拆单" if self.radio2_value else self.showinfo(message="所选文件可能是待拆单文件，请勾选“手动拆单”后上传！")
            elif str(ws["A1"].value) == "中文名称" or file_name[2] in ["离退休减册", "在职减册", "内退"]:
                flag = file_name[2] if self.radio1_value else self.showinfo(message="所选文件可能是事件模板文件，请勾选“事件待办”后上传！")
            else:
                flag = None if False else self.showinfo(message="所选文件可能不是符合要求的文件，请重新选择要上传的文件！")
        except Exception:
            self.showinfo("所选文件格式可能有误，请重新选择！")
            return

        if flag not in ["文件拆单", "目录拆单", file_name[2]]:
            return
        if file_name[2] == "员工入职" or flag == "目录拆单":
            file_dir = os.path.dirname(self.file_path)
            string = []
            for x in ["家庭成员及社会关系模板.xlsx", "学历学位模板.xlsx", "工作经历模板.xlsx", "照片"]:
                if not os.path.exists(os.path.join(file_dir, x)):
                    string.append(x)
            if string and flag != "目录拆单":
                self.showinfo(message=f"请确保员工入职模板所在目录中包含以下文件和目录：\r\n{str(string)}")
            else:
                remote = remote_daiban + f"{file_name[2]}/{os.path.basename(file_dir)}/"
                with MYFTP() as ftp:
                    ftp.upload_file_tree(file_dir, remote)
                self.showinfo(message=f"待处理文件已上传至共享文件夹！\r\n位置：{remote}")
        elif file_name[2] in ["岗位变动", "二调直调", "不在岗", "劳务工", "离岗", "离退休", "离退休减册", "在职减册",
                              "内退", "转正"] or flag == "文件拆单":
            remote = remote_daiban + f"{file_name[2]}/{os.path.basename(self.file_path)}"
            if file_name[2] in ["在职减册", "离退休减册"]:
                date = time.strftime("%Y%m%d", time.localtime(time.time()))
                remote = remote_daiban + f"{file_name[2]}/{date}/{os.path.basename(self.file_path)}"
            with MYFTP() as ftp:
                ftp.upload_file(self.file_path, remote)
            self.showinfo(message=f"待处理文件已上传至共享文件夹！\r\n位置：{remote}")
        else:
            self.showinfo(message=f"上传出现未知异常，请检查文件是否符合要求！")

    def showinfo(self, title="提示", message=""):
        dlg = wx.MessageDialog(self, message, title, wx.OK | wx.ICON_INFORMATION)
        dlg.ShowModal()
        dlg.Destroy()


class FileDropTarget(wx.FileDropTarget):
    def __init__(self, window):
        wx.FileDropTarget.__init__(self)
        self.window = window

    def OnDropFiles(self, x, y, fileName):
        self.window.SetPath(fileName[0])
        return True


class mainApp(wx.App):
    def OnInit(self):
        self.SetAppName("基本框架")
        self.Frame = MyFrame1(None)
        self.Frame.Show()
        return True


if __name__ == "__main__":
    app = mainApp()  # redirect=True, filename="debug.txt")
    app.MainLoop()
