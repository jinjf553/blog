"""拆分文件（保留批注）
   pyinstaller --clean -F --noconfirm --noupx --key=PBmmQGUYL3xF4kbD -n split_file ./rpa/ssc_kit/hr/split_file/main.py
"""


import logging
import sys
from pathlib import Path

import pandas as pd
from rpa.fastrpa.adtable import AdTable, load_from_xlsx_file
from rpa.fastrpa.log import config


def main(filename: str):
    filedir = Path(filename).parent
    save_dir = filedir.joinpath(Path(filename).name[:-5])
    logging.info(f'输出路径：{save_dir}')
    save_dir.mkdir(parents=True, exist_ok=True)
    logging.info('正在打开源文件')
    df = pd.read_excel(filename, dtype=str)
    df = df.iloc[:, :2]
    lt = load_from_xlsx_file(filename)
    logging.info('正在进行拆分')
    for idx, row in df[df.columns[[0, 1]]].drop_duplicates().iterrows():
        _a = row[0]
        _b = row[1]
        _a_column_nm = df.columns[0]
        _b_column_nm = df.columns[1]
        _df_tmp = df[(df[_a_column_nm] == _a) & (df[_b_column_nm] == _b)]
        _rows = [1] + list(_df_tmp.index + 2)
        _lt_new = AdTable(_a + '-' + _b)
        for rn, _row in enumerate(_rows, start=1):
            for column in range(1, 1 + lt.max_column):
                _lt_new[column][rn].value = lt[column][_row].value
                if lt[column][_row].cell.comment is not None:
                    _lt_new[column][rn].cmt('red', lt[column][_row].cell.comment.text, True)
        _filename = _lt_new.save_to(save_dir.as_posix())
        logging.info(f'保存拆分数据，文件名：{_filename}，记录数：{len(_df_tmp)}')


if __name__ == '__main__':
    config('split_file.log')
    logging.info('提示：请拖动文件到程序上执行，执行结束后，会在文件同目录下生成同名文件夹。')
    # input('按回车继续，或关闭窗口重新操作')
    if len(sys.argv) >= 2:
        filename = sys.argv[1]
        if filename[-5:].lower() == '.xlsx':
            main(filename)
            input('程序执行完毕')
        else:
            input(f'文件不是xlsx格式，文件名：{filename}')
    else:
        # main('x:/___T62-汇总.xlsx')
        input('请拖动【组合逻辑查询处理模板】到程序上执行')
