"""批量导出组合逻辑查询103、107至excel文件(从剪切板导出)
    pyinstaller --clean -F --noconfirm --noupx --add-binary='./rpa/fastrpa/third_party/encrypt;./rpa/fastrpa/third_party/encrypt' -n export_103_107_v2 ./rpa/ssc_kit/hr/export_103_107/main2.py
"""
import logging
import traceback
from re import split

import pyperclip
from pandas import DataFrame
from rpa.fastrpa.log import config
from rpa.ssc.sap.query import parse_query_string
from rpa.ssc_kit.hr.kit_export_103_107.main import save_file


def main() -> bool:
    """批量导出组合逻辑查询103、107至excel文件"""
    logging.info('读取剪切板文本')
    query_string = pyperclip.paste()
    try:
        logging.info('解析剪切板文本')
        header_names, contents = parse_query_string(query_string)  # 先尝试用剪切板方式解析导出序列，如失败则逐行逐单元格读取
        logging.info('解析成功')
        _table = DataFrame(contents, columns=header_names)
        save_file(_table, '103名称', '日期', False)
    except Exception as e:
        logging.info(f'执行报错，错误信息：{e}')
        logging.error(f"异常原因: {traceback.format_exc()}")
        return False
    return True


if __name__ == '__main__':
    config('export_103_107.log')
    input('读取剪切板中的组合逻辑查询文本，并保存为xlsx文件')
    result = main()
    input('执行结束，请检查结果')
