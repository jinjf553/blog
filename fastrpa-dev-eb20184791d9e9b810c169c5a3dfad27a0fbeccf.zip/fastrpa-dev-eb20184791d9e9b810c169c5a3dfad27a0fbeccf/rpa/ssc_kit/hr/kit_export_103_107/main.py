"""批量导出组合逻辑查询103、107至excel文件
   打包语句：pyinstaller --clean -F --noconfirm --noupx --add-binary='./rpa/fastrpa/third_party/encrypt;./rpa/fastrpa/third_party/encrypt' -n export_103_107 ./rpa/ssc_kit/hr/export_103_107/main.py
"""
import datetime
import logging
import os
import pathlib
import sys
from pathlib import Path
from typing import Any, List

import pyperclip
import rpa.config
from pandas import DataFrame
from rpa.fastrpa.adtable import AdTable, AdTableRow, load_from_xlsx_file
from rpa.fastrpa.date_funcs import valid_date
from rpa.fastrpa.log import config, logfn
from rpa.fastrpa.sap.grid_view_ctrl import GridViewCtrl
from rpa.fastrpa.sap.session import SapClose, attach_sap
from rpa.ssc.hr.orm.dims_utils import load_tb_dim_hr_diao_pei
from rpa.ssc.hr.sap.export_103 import enter_103
from rpa.ssc.hr.sap.export_1071 import enter_1071
from rpa.ssc.sap.query import export_query_to_dataframe, load_query_selection


@logfn
def load_querys_file(filename: str) -> AdTable:
    """加载【组合逻辑查询结果处理】模板"""
    _t = load_from_xlsx_file(filename)
    _t.del_blank_rows_by_column('B')
    return _t


@logfn
def chk_00(_t: AdTable) -> bool:
    """判断【组合逻辑查询结果处理】模板是否正确"""
    is_check_passed = True
    if _t['A'][1].value != '方式':
        _t['A'][1].cmt('red', '应为【方式】')
        is_check_passed = False
    if _t['B'][1].value != '变式名称':
        _t['B'][1].cmt('red', '应为【变式名称】')
        is_check_passed = False
    if _t['C'][1].value != '人事范围':
        _t['C'][1].cmt('red', '应为【人事范围】')
        is_check_passed = False
    if _t['D'][1].value != '对象标识':
        _t['D'][1].cmt('red', '应为【对象标识】')
        is_check_passed = False
    if _t['E'][1].value != '关键日期':
        _t['E'][1].cmt('red', '应为【关键日期】')
        is_check_passed = False
    if _t['F'][1].value != '开始日期':
        _t['F'][1].cmt('red', '应为【开始日期】')
        is_check_passed = False
    if _t['G'][1].value != '结束日期':
        _t['G'][1].cmt('red', '应为【结束日期】')
        is_check_passed = False
    if _t['H'][1].value != '是否拆分':
        _t['H'][1].cmt('red', '应为【是否拆分】')
        is_check_passed = False
    return is_check_passed


@logfn
def chk_01a(_r: AdTableRow) -> bool:
    """检验【A-方式】是否是103、107之一"""
    if _r['A'].value in ('103', '107'):
        return True
    else:
        _r['A'].cmt('red', '方式只支持103、107')
        return False


@logfn
def chk_01(_r: AdTableRow, dims: AdTable) -> bool:
    """检验人事范围编码是否是码表值，与码表库比对；人事范围可能有多个，以【、】作为分隔符；
       考虑中英文顿号问题"""
    if '103' in _r['A'].value:
        if _r['C'].value == '':
            _r['C'].cmt('red', "人事范围应非空")
            return False
        staff_rngs = [staff_rng.strip(' \t\r\n') for staff_rng in _r['C'].value.split('、')]
        err_staff_rngs = [staff_rng for staff_rng in staff_rngs if staff_rng not in dims['D'].values]

        if len(err_staff_rngs) > 0:
            _r['C'].cmt('red', f"人事范围非码值{'、'.join(err_staff_rngs)}")
            return False
        else:
            return True
    else:
        if _r['D'].value == '':
            _r['D'].cmt('red', '对象标识应非空')
            return False
        else:
            return True


@logfn
def chk_02(_r: AdTableRow) -> bool:
    """当关键日期有值时，开始日期，结束日期无效；
       当关键日期为空时，检验开始日期，结束日期是否都不为空；
       检验日期格式是否为8位数字，符合常识；"""
    if valid_date(_r['E'].value) is True:
        if _r['F'].value == '' and _r['G'].value == '':
            return True
        else:
            _r['F'].cmt('red', '关键日期有值，开始日期、结束日期应为空')
            _r['G'].cmt('red', '关键日期有值，开始日期、结束日期应为空')
            return False
    elif _r['E'].value == '':
        if valid_date(_r['F'].value) is True and valid_date(_r['G'].value) is True:
            return True
        else:
            _r['F'].cmt('red', '关键日期为空，开始日期、结束日期应有值')
            _r['G'].cmt('red', '关键日期为空，开始日期、结束日期应有值')
            return False
    else:
        _r['E'].cmt('red', '请检查关键日期/开始日期、结束日期')
        _r['F'].cmt('red', '请检查关键日期/开始日期、结束日期')
        _r['G'].cmt('red', '请检查关键日期/开始日期、结束日期')
        return False


@logfn
def chk_03(_r: AdTableRow) -> bool:
    """检验是否拆分列值是否为“是”、“否”之一"""
    if _r['H'].value not in ('是', '否'):
        _r['H'].cmt('red', '是否拆分值应为“是”或“否”')
        return False
    else:
        return True


@logfn
def before_chk(_t: AdTable, dims: AdTable) -> bool:
    """前置校验"""
    is_check_passed = []
    for row in _t.rows:
        is_check_passed.append(chk_01a(row))  # 校验【A-方式】是否为103、107之一
        is_check_passed.append(chk_01(row, dims))  # 校验人事范围是否为码值
        is_check_passed.append(chk_02(row))  # 校验关键日期/开始日期、结束日期是否符合条件
        is_check_passed.append(chk_03(row))  # 检验是否拆分列值是否为“是”、“否”之一
    return all(is_check_passed) is True


now = datetime.datetime.now().strftime(r'%Y%m%d_%H%M%S')


@logfn
def save_file(_df: DataFrame, query_selection_name: str, date_name: str, split=True):
    """query_name: 变式名称 """
    global now
    save_dir = Path(f'{rpa.config.D_RPA}/HR人事/组合逻辑查询/{now}/{date_name}-{query_selection_name}')
    save_dir.mkdir(parents=True, exist_ok=True)
    # 保存汇总
    filename = save_dir.joinpath(query_selection_name + '-汇总.xlsx').as_posix()
    logging.info(f'保存汇总数据，文件名：{filename}，记录数：{len(_df)}')
    _df.to_excel(filename, index=False)
    # 保存分类项，相同A、B列值数据保存到同一文件，并以“A-B”命名
    if split is True:
        for idx, row in _df[_df.columns[[0, 1]]].drop_duplicates().iterrows():
            _a = row[0]
            _b = row[1]
            filename = save_dir.joinpath(_a + '-' + _b + '.xlsx').as_posix()
            _a_column_nm = _df.columns[0]
            _b_column_nm = _df.columns[1]
            _df_tmp = _df[(_df[_a_column_nm] == _a) & (_df[_b_column_nm] == _b)]
            logging.info(f'保存拆分数据，文件名：{filename}，记录数：{len(_df_tmp)}')
            _df_tmp.to_excel(filename, index=False)


@logfn
def fill_103(session: Any, staff_rngs: List[str], key_date: str, begin_date='', end_date=''):
    """填充103"""
    session.findById("wnd[0]/usr/subSUB_MAIN:SAPLAQ_ADHOC:0210/subSUB_APPLICATION:SAPLHR_QUERY_APPL_AREA:0122/subSUB:SAPLHR_QUERY_APPL_AREA:0121/btnDYNP121-EVALUATION_PERIOD_TEXT").press()  # 点击报告时间
    if key_date != '':
        session.findById("wnd[0]/usr/subSUB_MAIN:SAPLAQ_ADHOC:0210/subSUB_APPLICATION:SAPLHR_QUERY_APPL_AREA:0122/subSUB:SAPLHR_QUERY_APPL_AREA:0120/cmbDD_DATE").key = "7"  # 选择关键日期
        session.findById("wnd[0]/usr/subSUB_MAIN:SAPLAQ_ADHOC:0210/subSUB_APPLICATION:SAPLHR_QUERY_APPL_AREA:0122/subSUB:SAPLHR_QUERY_APPL_AREA:0120/ctxtG_APPL_AREA-BEGDA").text = key_date  # 填充关键日期
    else:
        session.findById("wnd[0]/usr/subSUB_MAIN:SAPLAQ_ADHOC:0210/subSUB_APPLICATION:SAPLHR_QUERY_APPL_AREA:0122/subSUB:SAPLHR_QUERY_APPL_AREA:0120/cmbDD_DATE").key = "8"  # 其他期间
        session.findById("wnd[0]/usr/subSUB_MAIN:SAPLAQ_ADHOC:0210/subSUB_APPLICATION:SAPLHR_QUERY_APPL_AREA:0122/subSUB:SAPLHR_QUERY_APPL_AREA:0120/ctxtG_APPL_AREA-BEGDA").text = begin_date  # 开始日期
        session.findById("wnd[0]/usr/subSUB_MAIN:SAPLAQ_ADHOC:0210/subSUB_APPLICATION:SAPLHR_QUERY_APPL_AREA:0122/subSUB:SAPLHR_QUERY_APPL_AREA:0120/ctxtG_APPL_AREA-ENDDA").text = end_date  # 结束日期
    grid_view_ctrl_id = 'wnd[0]/usr/subSUB_MAIN:SAPLAQ_ADHOC:0210/subSUB_SELECTION:SAPLAQ_ADHOC:0310/cntlSEL_DEF_CONTAINER/shellcont/shell'
    grid_view_ctrl = GridViewCtrl(session, grid_view_ctrl_id)
    grid_view_ctrl['字段名称'].find('人事范围').same_line('更多值 ').press_button()
    session.findById("wnd[1]/tbar[0]/btn[16]").press()  # 清空
    pyperclip.copy('\r\n'.join(staff_rngs))  # 复制
    session.findById("wnd[1]/tbar[0]/btn[24]").press()  # 粘贴
    session.findById("wnd[1]/tbar[0]/btn[8]").press()  # 确认
    session.findById("wnd[0]/tbar[1]/btn[8]").press()  # 输出


@logfn
def do_103(session: Any, _t: AdTable) -> bool:
    for row in _t.rows:
        query_selection_name = row['B'].value  # 103勾选名称
        staff_rngs = [staff_rng.strip(' \t\r\n') for staff_rng in row['C'].value.split('、')]  # 人事范围
        key_date = row['E'].value  # 关键日期
        begin_date = row['F'].value  # 开始日期
        end_date = row['G'].value  # 结束日期
        err_msg = ''
        sap_status = ''
        try:
            if row['A'].value == '103':
                logging.info('进入SAP 103信息集查询界面')
                enter_103(session)
                logging.info(f'加载103信息集勾选（名称：{query_selection_name}）')
                if load_query_selection(session, query_selection_name) is False:
                    row['E'].value = f'加载103信息集勾选（名称：{query_selection_name}）失败，请检查信息集查询名称是否正确'
                    logging.info(f'加载103信息集勾选（名称：{query_selection_name}）失败，请检查信息集查询名称是否正确')
                    return False
                logging.info(f'填充103信息，人事范围：{staff_rngs}，关键日期：{key_date}，开始日期：{begin_date}，结束日期：{end_date}')
                fill_103(session, staff_rngs, key_date, begin_date, end_date)  # 填充103信息
                logging.info('正在导出信息集查询结果（如记录数较多，可能花费较长时间，1w条记录约7分钟）')
                _df: DataFrame = export_query_to_dataframe(session, "wnd[0]/usr/cntlGRID1/shellcont/shell")
                logging.info('信息集导出成功')
                date_name = key_date if key_date != '' else begin_date + '-' + end_date
                split = True if '是' in row['H'].value else False
                save_file(_df, query_selection_name + '_' + staff_rngs[0], date_name, split)
        except Exception as e:
            err_msg = str(e)
            try:
                sap_status = session.findById("wnd[0]/sbar/pane[0]").text
            except Exception:  # nosec
                pass
            row['K'].value = sap_status
            row['K'].cmt('red', err_msg)
    return True


@logfn
def fill_107(session: Any, object_ids: List[str], key_date: str, begin_date='', end_date=''):
    session.findById("wnd[0]/usr/subSUB_MAIN:SAPLAQ_ADHOC:0212/subSUB_APPLICATION:SAPLHR_QUERY_APPL_AREA:0122/subSUB:SAPLHR_QUERY_APPL_AREA:0121/btnDYNP121-EVALUATION_PERIOD_TEXT").press()  # 点击报告时间
    if key_date != '':
        session.findById("wnd[0]/usr/subSUB_MAIN:SAPLAQ_ADHOC:0212/subSUB_APPLICATION:SAPLHR_QUERY_APPL_AREA:0122/subSUB:SAPLHR_QUERY_APPL_AREA:0120/cmbDD_DATE").key = "7"  # 选择关键日期
        session.findById("wnd[0]/usr/subSUB_MAIN:SAPLAQ_ADHOC:0212/subSUB_APPLICATION:SAPLHR_QUERY_APPL_AREA:0122/subSUB:SAPLHR_QUERY_APPL_AREA:0120/ctxtG_APPL_AREA-BEGDA").text = key_date  # 填充关键日期
    else:
        session.findById("wnd[0]/usr/subSUB_MAIN:SAPLAQ_ADHOC:0212/subSUB_APPLICATION:SAPLHR_QUERY_APPL_AREA:0122/subSUB:SAPLHR_QUERY_APPL_AREA:0120/cmbDD_DATE").key = "8"  # 其他期间
        session.findById("wnd[0]/usr/subSUB_MAIN:SAPLAQ_ADHOC:0212/subSUB_APPLICATION:SAPLHR_QUERY_APPL_AREA:0122/subSUB:SAPLHR_QUERY_APPL_AREA:0120/ctxtG_APPL_AREA-BEGDA").text = begin_date  # 开始日期
        session.findById("wnd[0]/usr/subSUB_MAIN:SAPLAQ_ADHOC:0212/subSUB_APPLICATION:SAPLHR_QUERY_APPL_AREA:0122/subSUB:SAPLHR_QUERY_APPL_AREA:0120/ctxtG_APPL_AREA-ENDDA").text = end_date  # 结束日期
    grid_view_ctrl_id = 'wnd[0]/usr/subSUB_MAIN:SAPLAQ_ADHOC:0212/subSUB_SELECTION:SAPLAQ_ADHOC:0310/cntlSEL_DEF_CONTAINER/shellcont/shell'
    grid_view_ctrl = GridViewCtrl(session, grid_view_ctrl_id)
    grid_view_ctrl['字段名称'].find('对象标识').same_line('更多值 ').press_button()
    session.findById("wnd[1]/tbar[0]/btn[16]").press()  # 清空
    pyperclip.copy('\r\n'.join(object_ids))  # 复制
    session.findById("wnd[1]/tbar[0]/btn[24]").press()  # 粘贴
    session.findById("wnd[1]/tbar[0]/btn[8]").press()  # 确认
    session.findById("wnd[0]/tbar[1]/btn[8]").press()  # 输出


def do_107(session: Any, _t: AdTable) -> bool:
    for row in _t.rows:
        query_selection_name = row['B'].value  # 107勾选名称
        object_ids = [object_id.strip(' \t\r\n') for object_id in row['D'].value.split('、')]  # 对象标识
        key_date = row['E'].value  # 关键日期
        begin_date = row['F'].value  # 开始日期
        end_date = row['G'].value  # 结束日期
        err_msg = ''
        sap_status = ''
        try:
            if row['A'].value == '107':
                logging.info('进入SAP 107信息集查询界面')
                enter_1071(session)
                logging.info(f'加载107信息集勾选（名称：{query_selection_name}）')
                if load_query_selection(session, query_selection_name) is False:
                    row['E'].value = f'加载107信息集勾选（名称：{query_selection_name}）失败，请检查信息集查询名称是否正确'
                    logging.info(f'加载107信息集勾选（名称：{query_selection_name}）失败，请检查信息集查询名称是否正确')
                    return False
                logging.info(f'填充103信息，对象标识：{object_ids}，关键日期：{key_date}，开始日期：{begin_date}，结束日期：{end_date}')
                fill_107(session, object_ids, key_date, begin_date, end_date)  # 填充103信息
                logging.info('正在导出信息集查询结果（如记录数较多，可能花费较长时间，1w条记录约7分钟）')
                _df: DataFrame = export_query_to_dataframe(session, "wnd[0]/usr/cntlGRID1/shellcont/shell")
                logging.info('信息集导出成功')
                date_name = key_date if key_date != '' else begin_date + '-' + end_date
                split = True if '是' in row['H'].value else False
                save_file(_df, query_selection_name + '_' + object_ids[0], date_name, split)
        except Exception as e:
            err_msg = str(e)
            try:
                sap_status = session.findById("wnd[0]/sbar/pane[0]").text
            except Exception:  # nosec
                pass
            row['K'].value = sap_status
            row['K'].cmt('red', err_msg)
    return True


@logfn
def main(filename: str) -> bool:
    """批量导出组合逻辑查询103、107至excel文件"""
    global now
    logging.info(f'正在处理文件：{filename}')
    _t: AdTable = load_querys_file(filename)
    logging.info('开始从数据库读取码表')
    dims: AdTable = load_tb_dim_hr_diao_pei()
    logging.info('结束从数据库读取码表')
    dirname = pathlib.Path(f'{rpa.config.D_RPA}/HR人事/组合逻辑查询').joinpath(now).as_posix()
    with SapClose():
        if before_chk(_t, dims) is False:
            _t.save_to(dirname)
            logging.error(f'前置校验失败，文件保存至【{dirname}】目录下')
            return False
        session = attach_sap()
        do_103(session, _t)
        do_107(session, _t)
        _t.save_to(dirname)
        logging.info(f'导出完毕，文件保存至【{dirname}】目录下')
        return True


if __name__ == '__main__':
    config('export_103_107.log')
    logging.info('重要：程序执行后，会将数据写入运行目录下【组合逻辑查询】中，如该目录已有历史数据，请先备份至其他位置。')
    # input('按回车继续，或关闭窗口重新操作')
    if len(sys.argv) >= 2:
        filename = sys.argv[1]
        if filename[-5:].lower() == '.xlsx':
            os.chdir(pathlib.Path(filename).parent.as_posix())
            main(filename)
            input('程序执行完毕')
        else:
            input(f'文件不是xlsx格式，文件名：{filename}')
    else:
        main('x:/鉴定空岗虚岗(1).xlsx')
        input('请拖动【组合逻辑查询处理模板】到程序上执行')
