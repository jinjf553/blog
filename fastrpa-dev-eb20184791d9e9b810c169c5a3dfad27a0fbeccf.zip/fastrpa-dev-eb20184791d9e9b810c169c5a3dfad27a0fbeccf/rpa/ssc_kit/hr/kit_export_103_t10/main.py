from rpa.ssc.hr.sap.export_103_t10 import export_103_t10_all

if __name__ == '__main__':
    while True:
        export_103_t10_all()
