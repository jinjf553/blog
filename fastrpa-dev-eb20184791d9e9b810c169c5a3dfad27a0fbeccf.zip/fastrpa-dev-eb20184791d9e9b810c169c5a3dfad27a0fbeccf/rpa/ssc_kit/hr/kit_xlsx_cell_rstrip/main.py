"""程序功能：清除xlsx文件当前sheet页所有单元格末尾空白字符
   打包语句：pyinstaller --clean -F -c --noupx --key=PBmmQGUYL3xF4kbD -n 清除xlsx单元格末尾空白 ./rpa/ssc_kit/hr/xlsx_rstrip/main.py
"""
import logging
import sys
from pathlib import Path

from rpa.fastrpa.adtable import load_from_xlsx_file
from rpa.fastrpa.log import config


def main(filename: str) -> None:
    lt = load_from_xlsx_file(filename, skip_header=0, data_only=False)
    dir_name = Path(filename).parent.as_posix()
    for cell in lt.cells:
        if isinstance(cell.cell.value, str):
            cell.value = cell.value.rstrip(' ')
    lt.filename += '_修改后'
    new_filename = lt.save_to(dir_name)
    return new_filename


if __name__ == '__main__':
    config('xlsx_rstrip.log')
    logging.info('------------------------------------------')
    logging.info('功能：清除xlsx文件当前sheet页所有单元格末尾空白字符')
    logging.info('------------------------------------------')
    if len(sys.argv) >= 2:
        filename = sys.argv[1]
        if filename[-5:].lower() == '.xlsx':
            new_filename = main(filename)
            logging.info(f'程序执行完毕，修改后文件名：{new_filename}')
        else:
            logging.error('文件扩展名必须是.xlsx')
    else:
        logging.info('-----------请拖动文件到程序上执行-----------')
    input('按任意键退出')
