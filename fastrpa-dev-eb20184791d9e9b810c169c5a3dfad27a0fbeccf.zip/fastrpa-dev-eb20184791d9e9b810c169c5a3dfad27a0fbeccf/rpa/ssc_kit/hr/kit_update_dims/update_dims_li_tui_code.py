"""人事离退码表库更新工具
    pyinstaller -F -c --noupx --add-binary='./rpa/fastrpa/third_party/encrypt;./rpa/fastrpa/third_party/encrypt' --key=PBmmQGUYL3xF4kbD -n update_dims_li_tui_code ./rpa/ssc_kit/hr/update_dims_li_tui_code/main.py
"""
import datetime
import logging
import sys

import openpyxl
import pandas as pd
from rpa.fastrpa.log import config
from rpa.ssc.hr.orm.session import Engine
from rpa.ssc.hr.orm.td_hr_li_tui_code_rulebase import LiTui
from sqlalchemy import DateTime, Integer, String


def update_dims(filename: str) -> str:
    with Engine() as engine:
        logging.info('解析码表xlsx文件')
        df_dims = pd.read_excel(filename, sheet_name='码表库')
        column_names = ['db_' + openpyxl.utils.get_column_letter(i) for i in range(1, 1 + len(df_dims.columns))]
        types = [str] * len(df_dims.columns)
        dtypes = dict(zip(column_names, types))
        df_dims = pd.read_excel(filename, sheet_name='码表库', names=column_names, types=dtypes)
        df_dims = df_dims.fillna('')  # 将空转化为空字符串
        df_dims = df_dims.applymap(str)  # 将所有单元格转化为字符串
        df_dims = df_dims.applymap(lambda v: v.rstrip(' \t\r\n'))  # 数据清洗
        df_dims = df_dims[1:]  # 去除标题行
        dtype = dict(zip(df_dims.columns, [String(4 + 4 * max(df_dims[column_name].apply(len))) for column_name in df_dims.columns]))
        df_dims.insert(0, 'id', df_dims.index + 2)  # 插入id列（实际是excel行号）
        df_dims['create_time'] = datetime.datetime.now().strftime(r'%Y-%m-%d %H:%M:%S')
        df_dims['update_time'] = datetime.datetime.now().strftime(r'%Y-%m-%d %H:%M:%S')
        dtype['id'] = Integer
        dtype['create_time'] = DateTime
        dtype['update_time'] = DateTime
        # yyyymmdd = datetime.datetime.now().strftime(r'%Y%m%d')
        tb_name = LiTui.__tablename__
        df_dims = df_dims.copy(deep=True)
        pd.io.sql.to_sql(df_dims, tb_name, con=engine, index=False, dtype=dtype, if_exists='replace')
        with engine.connect() as con:
            con.execute(f'ALTER TABLE {tb_name} MODIFY create_time DATETIME DEFAULT CURRENT_TIMESTAMP COMMENT "创建时间";')
            con.execute(f'ALTER TABLE {tb_name} MODIFY update_time DATETIME DEFAULT CURRENT_TIMESTAMP COMMENT "更新时间";')
            con.execute(f'ALTER TABLE {tb_name} ADD PRIMARY KEY (id);')  # 将ID列置为主键
            con.execute(f'ALTER TABLE {tb_name} MODIFY id INT NOT NULL AUTO_INCREMENT;')
        return tb_name


def main(filename: str):
    logging.info('【创建码表库RPA】')
    tb_name = update_dims(filename)
    logging.info(f'更新成功！码表名为:{tb_name}')


if __name__ == '__main__':
    config()
    if len(sys.argv) >= 2:
        filename = sys.argv[1]
        if filename[-5:].lower() == '.xlsx':
            try:
                main(filename)
            except Exception as e:
                logging.info(e)
            logging.info('程序执行完毕')
        else:
            logging.info(f'文件不是xlsx格式，文件名：{filename}')
    else:
        main('e:/离退码表库-20210129.xlsx')
        logging.info('请拖动【离退码表库.xlsx】到程序图标上执行。')
    input()
