"""
   功能说明：
       更新码表时，对应码表目录下载至本地临时目录，并用公共或各组的文件替换对应的文件，合并为一个完整的码表文件，进行校验，校验通过后更新至码表。
       公用码表的列是全的，各组的码表列只包含各组需要维护的部分。生成完整码表时，要将各组的码表追加到公共码表里，列映射关系为 HEADER_MAP。

   FTP 码表命名规范：
   ----------------------
   /HR码表库/调配码表库/公用.xlsx
   /HR码表库/调配码表库/薪酬一组.xlsx
   /HR码表库/调配码表库/薪酬二组.xlsx
   /HR码表库/调配码表库/薪酬三组.xlsx
   /HR码表库/调配码表库/薪酬四组.xlsx
   /HR码表库/调配码表库/薪酬五组.xlsx
   /HR码表库/调配码表库/薪酬六组.xlsx
   /HR码表库/调配码表库/人事一组.xlsx
   /HR码表库/调配码表库/人事二组.xlsx
   /HR码表库/调配码表库/人事三组.xlsx
   /HR码表库/调配码表库/人事四组.xlsx
   /HR码表库/调配码表库/人事五组.xlsx
   /HR码表库/调配码表库/人事六组.xlsx
   /HR码表库/调配码表库/RPA团队.xlsx
   ----------------------
   /HR码表库/离退码表库/公用.xlsx
   /HR码表库/调配码表库/薪酬一组.xlsx
   /HR码表库/调配码表库/薪酬二组.xlsx
   /HR码表库/调配码表库/薪酬三组.xlsx
   /HR码表库/调配码表库/薪酬四组.xlsx
   /HR码表库/调配码表库/薪酬五组.xlsx
   /HR码表库/调配码表库/薪酬六组.xlsx
   /HR码表库/离退码表库/人事一组.xlsx
   /HR码表库/离退码表库/人事二组.xlsx
   /HR码表库/离退码表库/人事三组.xlsx
   /HR码表库/离退码表库/人事四组.xlsx
   /HR码表库/离退码表库/人事五组.xlsx
   /HR码表库/离退码表库/人事六组.xlsx
   /HR码表库/离退码表库/RPA团队.xlsx
   ----------------------
"""
import datetime
import logging
import re
import shutil
from collections import Counter
from pathlib import Path
from typing import Dict, List

from pandas import DataFrame
from redis.lock import LockError  # type: ignore
from rpa.fastrpa.adtable import AdTable, load_from_xlsx_file
from rpa.fastrpa.log import logfn
from rpa.fastrpa.myredis import MyRedis
from rpa.fastrpa.tempdir import gentempdir
from rpa.public.myftp import MYFTP
from rpa.ssc.hr.orm.dims_utils import load_tb_dim_hr_diao_pei
from rpa.ssc.hr.orm.td_hr_gang_wei_diao_pei_rulebase import Event
from rpa.ssc.hr.orm.td_hr_li_tui_code_rulebase import LiTui
from rpa.ssc_kit.hr.kit_update_dims.update_dims_diao_pei import \
    main as upload_dims_diao_pei
from rpa.ssc_kit.hr.kit_update_dims.update_dims_li_tui_code import \
    main as upload_dims_li_tui

TB_NAMES: Dict[str, str] = {'调配码表库': Event.__tablename__,
                            '离退码表库': LiTui.__tablename__}

HEADER_NAMES = {'调配码表库A': '岗位变动事件人事子范围会发生变化的人事范围',
                '调配码表库B': '二级单位调动事件人事子范围不发生变化的人事范围',
                '调配码表库C': '',
                '调配码表库D': '人事范围代码1',
                '调配码表库E': '人事子范围1',
                '调配码表库F': '企业自定义分类1对应的人事范围代码',  # 20210325 新增列【F-企业自定义分类1对应的人事范围代码】其余列顺延
                '调配码表库G': '企业自定义分类1',
                '调配码表库H': '企业自定义分类2对应的人事范围代码',  # 20210325 新增列【H-企业自定义分类2对应的人事范围代码】其余列顺延
                '调配码表库I': '企业自定义分类2',
                '调配码表库J': '企业自定义分类3对应的人事范围代码',  # 20210325 新增列【J-企业自定义分类3对应的人事范围代码】其余列顺延
                '调配码表库K': '企业自定义分类3',
                '调配码表库L': '',
                '调配码表库M': '人事范围代码3',
                '调配码表库N': '人事子范围3',
                '调配码表库O': '人员组3',
                '调配码表库P': '人员子组3',
                '调配码表库Q': '工资范围简码3',
                '调配码表库R': '工资总额控制范围简码3',
                '调配码表库S': '工资范围3',
                '调配码表库T': '工资总额控制范围3',
                '调配码表库U': '',
                '调配码表库V': '企业类型4',
                '调配码表库W': '合并机构代码4',
                '调配码表库X': '直属单位代码4',
                '调配码表库Y': '人事范围4',
                '调配码表库Z': '集团/股份4',
                '调配码表库AA': '职务岗位码',
                '调配码表库AB': '公司代码5',
                '调配码表库AC': '人事范围代码5',
                '调配码表库AD': '人事范围5',
                '调配码表库AE': '组别5',
                '调配码表库AF': '是否不转寄表单5',
                '离退码表库A': '编码',
                '离退码表库B': '表单码表值',
                '离退码表库C': '人事范围',
                '离退码表库D': '人事子范围',
                '离退码表库E': '岗位编号',
                '离退码表库F': '岗位名称',
                '离退码表库G': '工资核算范围',
                '离退码表库H': '工资总额控制范围',
                '离退码表库I': '原因',
                '离退码表库J': '备注',
                '离退码表库K': '功能范围',
                '离退码表库L': '业务范围'}

# {公共: 各组}
HEADER_MAP = {'调配码表库B': 'A',
              '调配码表库C': 'B',
              '调配码表库D': 'D',
              '调配码表库E': 'E',
              '调配码表库F': 'G',
              '调配码表库G': 'I',
              '调配码表库H': 'K',
              '调配码表库AA': 'M',
              '调配码表库AB': 'N',
              '调配码表库AC': 'O',
              '调配码表库AD': 'P',
              '调配码表库AE': 'Q',
              '调配码表库AF': 'R',
              '调配码表库AG': 'S',
              '调配码表库AH': 'T',
              '调配码表库BA': 'V',
              '调配码表库BB': 'W',
              '调配码表库BC': 'X',
              '调配码表库BD': 'Y',
              '调配码表库BE': 'Z',
              '调配码表库BG': 'AA',
              '调配码表库BI': 'AB',
              '调配码表库BJ': 'AC',
              '调配码表库BK': 'AD',
              '调配码表库BL': 'AE',
              '调配码表库BM': 'AF',
              '调配码表库EY': 'F',  # 新插入的F、H、J三列，放在合并后码表的EY、EZ、FA列
              '调配码表库EZ': 'H',
              '调配码表库FA': 'J',
              '离退码表库C': 'A',
              '离退码表库D': 'B',
              '离退码表库E': 'C',
              '离退码表库F': 'D',
              '离退码表库G': 'E',
              '离退码表库H': 'F',
              '离退码表库I': 'G',
              '离退码表库J': 'H',
              '离退码表库K': 'I',
              '离退码表库L': 'J',
              '离退码表库M': 'K',
              '离退码表库N': 'L',
              }

ALIGN_COLUMNS = {'调配码表库N': 'M',
                 '调配码表库O': 'M',
                 '调配码表库P': 'M',
                 '调配码表库Q': 'M',
                 '调配码表库R': 'M',
                 '调配码表库S': 'M',
                 '调配码表库T': 'M',
                 '离退码表库H': 'C',
                 '离退码表库I': 'C', }  # K..I列可能为空，行数要对齐到J..C列

GROUP_NAMES = ['薪酬一组', '薪酬二组', '薪酬三组', '薪酬四组', '薪酬五组', '薪酬六组', '人事一组', '人事二组', '人事三组', '人事四组', '人事五组', '人事六组', 'RPA团队']

NAMES = ['公用'] + GROUP_NAMES


@logfn
def chk_null(lt: AdTable, df: DataFrame) -> bool:
    """检查是否存在【#N/A】，如存在，报错"""
    logging.info('检查是否存在【#N/A】，如存在，报错')
    is_check_passed = True
    for column_letter in df.columns:
        for rn in df.index:
            if df[column_letter][rn] == '#N/A':
                is_check_passed = False
                lt[column_letter][rn].cmt('red', '任何单元格值不能为【#N/A】')
    return is_check_passed


@logfn
def chk_file_header(lt: AdTable, df: DataFrame, group_name: str) -> bool:
    is_check_passed = True
    for column_letter in df.columns:
        if f'{group_name}{column_letter}' in HEADER_NAMES.keys():
            header_name = HEADER_NAMES[f'{group_name}{column_letter}']
            if lt[column_letter][2].value != header_name:
                is_check_passed = False
                lt[column_letter][2].cmt('red', f'表头应为{header_name}')
    return is_check_passed


@logfn
def chk_lt_a(lt: AdTable, df: DataFrame) -> bool:
    """字长=17，格式为：AAAA（必为四位）-BB（必为  NT  或  TX  之一）-CCCC（必为四位数字）-DDDD（必为四位数字），且不重复"""
    logging.info('[校验A列]字长=17，格式为：AAAA（必为四位）-BB（必为  NT  或  TX  之一）-CCCC（必为四位数字）-DDDD（必为四位数字），且不重复')
    is_check_passed = True
    skip_blank_line_flag = True
    values: List[str] = df['A'].values
    repeat_a = [k for k, v in Counter(values).items() if k != '' and v > 1]
    for rn in reversed(df.index):
        _a = df['A'][rn]
        if skip_blank_line_flag is True and _a == '':  # 跳过末尾空白行
            continue
        else:
            skip_blank_line_flag = False
            if re.match(r'^[a-zA-Z0-9]{4}-(NT|TX)-\d{4}-\d{4}$', _a) is None:
                is_check_passed = False
                lt['A'][rn].cmt('red', '字长=17，格式为：AAAA（必为四位）-BB（必为  NT  或  TX  之一）-CCCC（必为四位数字）-DDDD（必为四位数字）')
            if _a in repeat_a:
                is_check_passed = False
                lt['A'][rn].cmt('red', '值与本组的A列重复')
    return is_check_passed


@logfn
def chk_lt_b(lt: AdTable, df: DataFrame) -> bool:
    """格式为：AAAA（必为四位）B（一位空格） CCCC（必为四位数字）-D（一位空格）-E（文本，无限制）-F（一位空格）-FFFFFFF（六位、七位数字或八位数字）"""
    logging.info('[校验B列]格式为：AAAA（必为四位）B（一位空格） CCCC（必为四位数字）-D（一位空格）-E（文本，无限制）-F（一位空格）-FFFFFFF（六位、七位数字或八位数字）')
    is_check_passed = True
    skip_blank_line_flag = True
    for rn in reversed(df.index):
        _b = df['B'][rn]
        if skip_blank_line_flag is True and _b == '':  # 跳过末尾空白行
            continue
        else:
            skip_blank_line_flag = False
            if re.match(r'^\w{4} \d{4} .+ \d{6,8}$', _b) is None:
                is_check_passed = False
                lt['B'][rn].cmt('red', '格式为：AAAA（必为四位）B（一位空格） CCCC（必为四位数字）-D（一位空格）-E（文本，无限制）-F（一位空格）-FFFFFFF（六位、七位数字或八位数字）')
    return is_check_passed


@logfn
def chk_lt_c(lt: AdTable, df: DataFrame) -> bool:
    """字长=4"""
    logging.info('[校验C列]字长=4')
    is_check_passed = True
    skip_blank_line_flag = True
    for rn in reversed(df.index):
        _c = df['C'][rn]
        if skip_blank_line_flag is True and _c == '':  # 跳过末尾空白行
            continue
        else:
            skip_blank_line_flag = False
            if len(_c) != 4:
                is_check_passed = False
                lt['C'][rn].cmt('red', '字长=4')
    return is_check_passed


@logfn
def chk_lt_d(lt: AdTable, df: DataFrame) -> bool:
    """格式为：AAAA（必为四位）B（一位空格） C（文本，无限制）"""
    logging.info('[校验D列]格式为：AAAA（必为四位）B（一位空格） C（文本，无限制）')
    is_check_passed = True
    skip_blank_line_flag = True
    for rn in reversed(df.index):
        _d = df['D'][rn]
        if skip_blank_line_flag is True and _d == '':  # 跳过末尾空白行
            continue
        else:
            skip_blank_line_flag = False
            if re.match(r'^\w{4} .+$', _d) is None:
                is_check_passed = False
                lt['D'][rn].cmt('red', '格式为：AAAA（必为四位）B（一位空格） C（文本，无限制）')
    return is_check_passed


@logfn
def chk_lt_e(lt: AdTable, df: DataFrame) -> bool:
    """六位、七位数字或八位数字"""
    logging.info('[校验E列]六位、七位数字或八位数字')
    is_check_passed = True
    skip_blank_line_flag = True
    for rn in reversed(df.index):
        _e = df['E'][rn]
        if skip_blank_line_flag is True and _e == '':  # 跳过末尾空白行
            continue
        else:
            skip_blank_line_flag = False
            if re.match(r'^\d{6,8}$', _e) is None:
                is_check_passed = False
                lt['E'][rn].cmt('red', '六位、七位数字或八位数字')
    return is_check_passed


@logfn
def chk_lt_g(lt: AdTable, df: DataFrame) -> bool:
    """格式为：AA（必为两位）B（一位空格） C（文本，无限制）"""
    logging.info('[校验G列]格式为：AA（必为两位）B（一位空格） C（文本，无限制）')
    is_check_passed = True
    skip_blank_line_flag = True
    for rn in reversed(df.index):
        _g = df['G'][rn]
        if skip_blank_line_flag is True and _g == '':  # 跳过末尾空白行
            continue
        else:
            skip_blank_line_flag = False
            if re.match('^.{2} .+$', _g) is None:
                is_check_passed = False
                lt['G'][rn].cmt('red', '格式为：AA（必为两位）B（一位空格） C（文本，无限制）')
    return is_check_passed


@logfn
def chk_lt_h(lt: AdTable, df: DataFrame) -> bool:
    """当同一行G两位字符为00时必为空，除此以外，格式为：AA（必为两位）B（一位空格） C（文本，无限制），必不为空"""
    logging.info('[校验H列]当同一行G两位字符为00时必为空，除此以外，格式为：AA（必为两位）B（一位空格） C（文本，无限制），必不为空')
    is_check_passed = True
    skip_blank_line_flag = True
    for rn in reversed(df.index):
        _g = df['G'][rn]
        _h = df['H'][rn]
        if skip_blank_line_flag is True and _g == '' and _h == '':  # 跳过末尾空白行
            continue
        else:
            skip_blank_line_flag = False
            if _g.startswith('00') and _h == '':
                continue
            elif _g.startswith('宜7') and _h == '':
                continue
            elif re.match('.{2} .+', _h) is not None:
                continue
            else:
                is_check_passed = False
                lt['H'][rn].cmt('red', '当同一行G两位字符为00或宜7时必为空，除此以外，格式为：AA（必为两位）B（一位空格） C（文本，无限制），必不为空')
    return is_check_passed


@logfn
def chk_lt_i(lt: AdTable, df: DataFrame) -> bool:
    """值只能为：上市内退、非上市内退、上市退休、非上市退休四者之一"""
    logging.info('[校验I列]值只能为：上市内退、非上市内退、上市退休、非上市退休四者之一')
    is_check_passed = True
    skip_blank_line_flag = True
    for rn in reversed(df.index):
        _i = df['I'][rn]
        if skip_blank_line_flag is True and _i == '':  # 跳过末尾空白行
            continue
        else:
            skip_blank_line_flag = False
            if _i not in ('上市内退', '非上市内退', '上市退休', '非上市退休'):
                is_check_passed = False
                lt['I'][rn].cmt('red', '值只能为：上市内退、非上市内退、上市退休、非上市退休四者之一')
    return is_check_passed


@logfn
def chk_lt_a_b_c_d_e_g_h_i(lt: AdTable, df: DataFrame) -> bool:
    """同一行必然同时有值"""
    logging.info('[校验A、B、C、D、E、F、G、I列]同一行必然同时有值')
    is_check_passed = True
    for rn in df.index:
        _a = df['A'][rn]
        _b = df['B'][rn]
        _c = df['C'][rn]
        _d = df['D'][rn]
        _e = df['E'][rn]
        _f = df['F'][rn]
        _g = df['G'][rn]
        _i = df['I'][rn]
        if ''.join([_a, _b, _c, _d, _e, _f, _g, _i]) == '':  # 全为空
            continue
        if '' not in [_a, _b, _c, _d, _e, _f, _g, _i]:  # 全不为空
            continue
        is_check_passed = False
        lt['A'][rn].cmt('red', 'A、B、C、D、E、F、G、I列同一行必然同时有值')
    return is_check_passed


@logfn
def chk_lt_d2(lt: AdTable, df: DataFrame, df_dims: DataFrame) -> bool:
    """检验【本组-D】的值是否存在于 “【调配码表库E】”"""
    logging.info('[校验D列]值是否存在于 “【调配码表库E】”')
    is_check_passed = True
    _e = df_dims['E'].values.tolist()
    for rn in df.index:
        _d = df['D'][rn]
        if _d != '' and _d not in _e:
            is_check_passed = False
            lt['D'][rn].cmt('red', '检验【本组-D】的值是否存在于 “【调配码表库E】')
    return is_check_passed


@logfn
def chk_lt_c_d(lt: AdTable, df: DataFrame) -> bool:
    """其值必在A中"""
    logging.info('[校验C、D列]其值必在A中')
    is_check_passed = True
    skip_blank_line_flag = True
    for rn in reversed(df.index):
        _a = df['A'][rn]
        _c = df['C'][rn]
        _d = df['D'][rn]
        if skip_blank_line_flag is True and _c == '' and _d == '':  # 跳过末尾空白行
            continue
        else:
            skip_blank_line_flag = False
            if _c[:4] != _a[:4]:
                is_check_passed = False
                lt['C'][rn].cmt('red', 'C列前4位不等于A列前4位')
            if _d[:4] != _a[8:12]:
                is_check_passed = False
                lt['D'][rn].cmt('red', 'D列前4位不等于A列8至12位')
    return is_check_passed


@logfn
def chk_lt_group(filename: str, group_name: str) -> bool:
    logging.info('【校验分组码表库】')
    lt = load_from_xlsx_file(filename, skip_header=2)
    lt.clear_comment_and_fgcolor()
    df = lt.to_dataframe()
    lt_dims = load_tb_dim_hr_diao_pei()
    df_dims = lt_dims.to_dataframe()
    is_check_passed = []
    is_check_passed.append(chk_file_header(lt, df, group_name))
    is_check_passed.append(chk_null(lt, df))
    is_check_passed.append(chk_lt_a(lt, df))
    is_check_passed.append(chk_lt_b(lt, df))
    is_check_passed.append(chk_lt_c(lt, df))
    is_check_passed.append(chk_lt_d(lt, df))
    is_check_passed.append(chk_lt_e(lt, df))
    is_check_passed.append(chk_lt_g(lt, df))
    is_check_passed.append(chk_lt_h(lt, df))
    is_check_passed.append(chk_lt_i(lt, df))
    is_check_passed.append(chk_lt_a_b_c_d_e_g_h_i(lt, df))
    is_check_passed.append(chk_lt_d2(lt, df, df_dims))
    is_check_passed.append(chk_lt_c_d(lt, df))
    lt.save(filename)
    return all(is_check_passed) is True


@logfn
def chk_lt_c1(lt: AdTable, df: DataFrame, df_dims: DataFrame, group_name: str) -> bool:
    """检验【本组-C】的值是否存在于 “本组【调配码表库BJ】，若不存在，报错"""
    logging.info('[校验C列]检验【本组-C】的值是否存在于 “本组【调配码表库BJ】，若不存在，报错')
    is_check_passed = True
    _bj = [k for k in df_dims[df_dims['BL'] == group_name]['BJ'].values if k != '']
    for rn in df.index:
        _c = df['C'][rn]
        if _c != '' and _c not in _bj:
            is_check_passed = False
            lt['C'][rn].cmt('red', '值不存在于本组码表BJ列中')
    return is_check_passed


@logfn
def chk_lt_c2(lt: AdTable, df: DataFrame, df_dims: DataFrame, group_name: str) -> bool:
    """检验【本组-C】的值是否存在于 “其他组【调配码表库BJ】，若存在，报错"""
    logging.info('[校验C列]检验【本组-C】的值是否存在于 “其他组【调配码表库BJ】，若存在，报错')
    is_check_passed = True
    _bj = [k for k in df_dims[df_dims['BL'] != group_name]['BJ'].values if k != '']
    for rn in df.index:
        _c = df['C'][rn]
        if _c != '' and _c in _bj:
            is_check_passed = False
            lt['C'][rn].cmt('red', '【本组-C】的值存在于 “其他组【调配码表库BJ】')
    return is_check_passed


@logfn
def chk_lt_a2(lt: AdTable, df: DataFrame, df_merged: DataFrame) -> bool:
    """检验【本组-A】的值是否存在于 “其他组【A】（对应合并后C列），若存在，报错"""
    logging.info('[校验A列]检验【本组-A】的值是否存在于 “其他组【A】（对应合并后C列），若存在，报错')
    # 前置校验通过已经确保本组A列自身不重复，合并后校验如重复，说明与其他组A列重复
    is_check_passed = True
    skip_blank_line_flag = True
    values: List[str] = df_merged['C'].values
    repeat_a = [k for k, v in Counter(values).items() if k != '' and v > 1]
    for rn in reversed(df.index):
        _a = df['A'][rn]
        if skip_blank_line_flag is True and _a == '':  # 跳过末尾空白行
            continue
        else:
            skip_blank_line_flag = False
            if _a in repeat_a:
                is_check_passed = False
                lt['A'][rn].cmt('red', '本组的A列与其他组A列重复')
    return is_check_passed


@logfn
def chk_lt_merged(filename: str, merged_filename: str, group_name: str) -> bool:
    """校验合并后离退码表库"""
    logging.info('校验合并后离退码表库')
    lt = load_from_xlsx_file(filename, skip_header=2)
    lt.clear_comment_and_fgcolor()
    df = lt.to_dataframe()
    lt_merged = load_from_xlsx_file(merged_filename, skip_header=2)
    df_merged = lt_merged.to_dataframe()
    lt_dims = load_tb_dim_hr_diao_pei()
    df_dims = lt_dims.to_dataframe()
    is_check_passed = []
    is_check_passed.append(chk_lt_c1(lt, df, df_dims, group_name))
    is_check_passed.append(chk_lt_c2(lt, df, df_dims, group_name))
    is_check_passed.append(chk_lt_a2(lt, df, df_merged))
    lt.save(filename)
    return all(is_check_passed) is True


@logfn
def chk_dp_a_b(lt: AdTable, df: DataFrame) -> bool:
    """字长=4，可以为空"""
    logging.info('[校验A、B列]字长=4，可以为空')
    is_check_passed = True
    for rn in df.index:
        if df['A'][rn] != '' and len(df['A'][rn]) != 4:
            lt['A'][rn].cmt('red', '字段长度必须为4')
            is_check_passed = False
        if df['B'][rn] != '' and len(df['B'][rn]) != 4:
            lt['B'][rn].cmt('red', '字段长度必须为4')
            is_check_passed = False
    return is_check_passed


@logfn
def chk_dp_d_m_y_ac(lt: AdTable, df: DataFrame) -> bool:
    """字长=4，必不为空"""
    logging.info('[校验D、M、Y、AC列]字长=4，必不为空')
    is_check_passed = True
    for column_letter in ('D', 'M', 'Y', 'AC'):
        skip_blank_line_flag = True
        for rn in reversed(df.index):
            _value = df[column_letter][rn]
            if skip_blank_line_flag is True and _value == '':  # 跳过末尾空白行
                continue
            else:
                skip_blank_line_flag = False
                if _value != '' and len(_value) == 4:
                    continue
                else:
                    is_check_passed = False
                    lt[column_letter][rn].cmt('red', '该字段不能为空，且长度必须为4')
    return is_check_passed


@logfn
def chk_dp_e_n(lt: AdTable, df: DataFrame) -> bool:
    """前四位必为数字，无其他字符，必不为空"""
    logging.info('[校验E、N列]前四位必为数字，无其他字符，必不为空')
    is_check_passed = True
    for column_letter in ('E', 'N'):
        skip_blank_line_flag = True
        for rn in reversed(df.index):
            _value = df[column_letter][rn]
            if skip_blank_line_flag is True and _value == '':  # 跳过末尾空白行
                continue
            else:
                skip_blank_line_flag = False
                if len(_value) >= 4 and _value[:4].isdigit() is True:
                    continue
                else:
                    is_check_passed = False
                    lt[column_letter][rn].cmt('red', '前四位必为数字，无其他字符，必不为空')
    return is_check_passed


@logfn
def chk_dp_ab_ad(lt: AdTable, df: DataFrame) -> bool:
    """前四位必为数字或英文，无其他字符，必不为空"""
    logging.info('[校验AB、AD列]前四位必为数字或英文，无其他字符，必不为空')
    is_check_passed = True
    for column_letter in ('AB', 'AD'):
        skip_blank_line_flag = True
        for rn in reversed(df.index):
            _value = df[column_letter][rn]
            if skip_blank_line_flag is True and _value == '':  # 跳过末尾空白行
                continue
            else:
                skip_blank_line_flag = False
                if len(_value) >= 4 and re.match('[0-9a-zA-Z]+', _value[:4]) is not None:
                    continue
                else:
                    is_check_passed = False
                    lt[column_letter][rn].cmt('red', '前四位必为数字，无其他字符，必不为空')
    return is_check_passed


@logfn
def chk_dp_o(lt: AdTable, df: DataFrame, df_diao_pei) -> bool:
    """必在码表库J的第一个字母的范围内，必不为空"""
    logging.info('[校验O列]必在码表库J的第一个字母的范围内，必不为空')
    is_check_passed = True
    diao_pei_j = [v[:1] for v in df_diao_pei['J'].values if v != '']
    for column_letter in ('O'):
        skip_blank_line_flag = True
        for rn in reversed(df.index):
            _value = df[column_letter][rn]
            if skip_blank_line_flag is True and _value == '':  # 跳过末尾空白行
                continue
            else:
                skip_blank_line_flag = False
                for _v in _value.split('/'):
                    if _v not in diao_pei_j:
                        is_check_passed = False
                        lt[column_letter][rn].cmt('red', '必在公共码表库J的第一个字母的范围内，必不为空')
    return is_check_passed


@logfn
def chk_dp_q(lt: AdTable, df: DataFrame) -> bool:
    """字长=2，必不为空"""
    logging.info('[校验Q列]字长=2，必不为空')
    is_check_passed = True
    skip_blank_line_flag = True
    for rn in reversed(df.index):
        _value = df['Q'][rn]
        if skip_blank_line_flag is True and _value == '':  # 跳过末尾空白行
            continue
        else:
            skip_blank_line_flag = False
            if _value != '' and len(_value) == 2:
                continue
            else:
                is_check_passed = False
                lt['Q'][rn].cmt('red', '该字段不能为空，且长度必须为2')
    return is_check_passed


@logfn
def chk_dp_r(lt: AdTable, df: DataFrame) -> bool:
    """当同一行N为00时必为空，除此以外，字长=2，必不为空
       ----------------
       例外：
       当【M列】人事范围：X63Z，【Q列】工资范围：辽三  时，【R列】工资总额控制范围长度为3位，【T列】前三位与同一行O相同。
       当【M列】人事范围：2530  或  6750，【Q列】工资范围：宜7  或  宜8  时，【R列】和【T列】工资总额控制范围为空。
    """
    logging.info('[校验R列]当同一行N为00时必为空，除此以外，字长=2，必不为空')
    is_check_passed = True
    skip_blank_line_flag = True
    for rn in reversed(df.index):
        _m = df['M'][rn]
        _q = df['Q'][rn]
        _r = df['R'][rn]
        # _q = df['Q'][rn]
        if skip_blank_line_flag is True and _q == '' and _r == '':  # 跳过末尾空白行
            continue
        else:
            skip_blank_line_flag = False
            if _q == '00':
                if _r == '':
                    continue
            elif _m == 'X63Z' and _q == '辽三':
                if len(_r) == 3:  # 【Q列】前三位与同一行O相同，在Q列校验规则实现
                    continue
            elif _m in ('2530', '6750') and _q in ('宜7', '宜8'):
                if _r == '':  # 【Q列】为空，校验规则在Q列实现
                    continue
            elif _r == '辽10':
                continue
            elif len(_r) == 2:
                continue
            is_check_passed = False
            lt['R'][rn].cmt('red', '当同一行N为00时必为空，除此以外，字长=2，必不为空。例外：\n' +
                            '当【M列】人事范围：X63Z，【Q列】工资范围：辽三  时，【R列】工资总额控制范围长度为3位，【T列】前三位与同一行O相同。\n' +
                            '当【M列】人事范围：2530  或  6750，【Q列】工资范围：宜7  或  宜8  时，【R列】和【T列】工资总额控制范围为空。')
    return is_check_passed


@logfn
def chk_dp_v_1(lt: AdTable, df: DataFrame) -> bool:
    """前两位与同一行N相同，必不为空"""
    logging.info('[校验P列]前两位与同一行Q相同，必不为空')
    is_check_passed = True
    skip_blank_line_flag = True
    for rn in reversed(df.index):
        _q = df['Q'][rn]
        _s = df['S'][rn]
        if skip_blank_line_flag is True and _s == '' and _q == '':  # 跳过末尾空白行
            continue
        else:
            skip_blank_line_flag = False
            if _s != '' and _q != '' and _s.startswith(_q):
                continue
            else:
                is_check_passed = False
                lt['S'][rn].cmt('red', '前两位与同一行Q相同，必不为空')
    return is_check_passed


@logfn
def chk_dp_t(lt: AdTable, df: DataFrame) -> bool:
    """当同一行Q为00时必为空，除此以外，前两位与同一行R相同
       ----------------
       例外：
       当【M列】人事范围：X63Z，【Q列】工资范围：辽三  时，【R列】工资总额控制范围长度为3位，【T列】前三位与同一行O相同。
       当【M列】人事范围：2530  或  6750，【Q列】工资范围：宜7  或  宜8  时，【R列】和【T列】工资总额控制范围为空。
    """
    logging.info('[校验S列]当同一行N为00时必为空，除此以外，前两位与同一行O相同')
    is_check_passed = True
    skip_blank_line_flag = True
    for rn in reversed(df.index):
        _m = df['M'][rn]
        _q = df['Q'][rn]
        _r = df['R'][rn]
        _t = df['T'][rn]
        if skip_blank_line_flag is True and _q == '' and _t == '':  # 跳过末尾空白行
            continue
        else:
            skip_blank_line_flag = False
            if _q == '00':
                if _r == '':
                    continue
            elif _m == 'X63Z' and _q == '辽三':
                if _t.startswith(_r):  # 【O列】长度为3，在O列校验规则实现
                    continue
            elif _m in ('2530', '6750') and _q in ('宜7', '宜8'):
                if _t == '':  # 【O列】为空，校验规则在O列实现
                    continue
            elif _t.startswith(_r):
                continue
            is_check_passed = False
            lt['Q'][rn].cmt('red', '当同一行N为00时必为空，除此以外，字长=2，必不为空。例外：\n' +
                            '当【M列】人事范围：X63Z，【Q列】工资范围：辽三  时，【R列】工资总额控制范围长度为3位，【T列】前三位与同一行O相同。\n' +
                            '当【M列】人事范围：2530  或  6750，【Q列】工资范围：宜7  或  宜8  时，【R列】和【T列】工资总额控制范围为空。')
    return is_check_passed


@logfn
def chk_dp_v_2(lt: AdTable, df: DataFrame) -> bool:
    """字长=4，必不为空，值只能为：销售企业  或  炼化企业"""
    logging.info('[校验V列]字长=4，必不为空，值只能为：销售企业  或  炼化企业')
    is_check_passed = True
    skip_blank_line_flag = True
    for rn in reversed(df.index):
        _v = df['V'][rn]
        _w = df['W'][rn]
        _x = df['X'][rn]
        _y = df['Y'][rn]
        _z = df['Z'][rn]
        if skip_blank_line_flag is True and _v == '':  # 跳过末尾空白行
            continue
        else:
            skip_blank_line_flag = False
            if _w == '36400000' and _x == '36400000' and _y == '1070' and _z == '上市':
                if _v == '其他单位':
                    continue
            elif _w == '13350042' and _x == '13350042' and _y == '9620' and _z == '非上市':
                if _v == '其他单位':
                    continue
            elif _v in ['销售企业', '炼化企业']:
                continue
            else:
                is_check_passed = False
                lt['V'][rn].cmt('red', '值只能为：销售企业、炼化企业、其他单位')
    return is_check_passed


@logfn
def chk_dp_w_x(lt: AdTable, df: DataFrame) -> bool:
    """字长=8，必不为空"""
    logging.info('[校验W、X列]字长=8，必不为空')
    is_check_passed = True
    for column_letter in ['W', 'X']:
        skip_blank_line_flag = True
        for rn in reversed(df.index):
            _value = df[column_letter][rn]
            if skip_blank_line_flag is True and _value == '':  # 跳过末尾空白行
                continue
            else:
                skip_blank_line_flag = False
                if len(_value) == 8:
                    continue
                else:
                    is_check_passed = False
                    lt[column_letter][rn].cmt('red', '字长=8，必不为空')
    return is_check_passed


@logfn
def chk_dp_z(lt: AdTable, df: DataFrame) -> bool:
    """值只能为：上市  或  非上市"""
    logging.info('[校验Z列]值只能为：上市  或  非上市')
    is_check_passed = True
    skip_blank_line_flag = True
    for rn in reversed(df.index):
        _z = df['Z'][rn]
        if skip_blank_line_flag is True and _z == '':  # 跳过末尾空白行
            continue
        else:
            skip_blank_line_flag = False
            if _z in ['上市', '非上市']:
                continue
            else:
                is_check_passed = False
                lt['Z'][rn].cmt('red', '值只能为：上市  或  非上市')
    return is_check_passed


@logfn
def chk_dp_aa(lt: AdTable, df: DataFrame) -> bool:
    """值只能为：是  或  否"""
    logging.info('[校验AA列]值只能为：是  或  否')
    is_check_passed = True
    skip_blank_line_flag = True
    for rn in reversed(df.index):
        _aa = df['AA'][rn]
        if skip_blank_line_flag is True and _aa == '':  # 跳过末尾空白行
            continue
        else:
            skip_blank_line_flag = False
            if _aa in ['是', '否']:
                continue
            else:
                is_check_passed = False
                lt['AA'][rn].cmt('red', '值只能为：是  或  否')
    return is_check_passed


@logfn
def chk_dp_ae(lt: AdTable, df: DataFrame, group_name: str) -> bool:
    """值只能为：业务【一、二、三、四、五、六】组"""
    logging.info('[校验AE列]值只能为：业务【一、二、三、四、五、六】组')
    is_check_passed = True
    skip_blank_line_flag = True
    for rn in reversed(df.index):
        _ae = df['AE'][rn]
        if skip_blank_line_flag is True and _ae == '':  # 跳过末尾空白行
            continue
        else:
            skip_blank_line_flag = False
            if _ae == group_name:
                continue
            else:
                is_check_passed = False
                lt['AE'][rn].cmt('red', '值只能为：业务【一、二、三、四、五、六】组')
    return is_check_passed


@logfn
def chk_dp_af(lt: AdTable, df: DataFrame) -> bool:
    """当不为空时，值只能为：1"""
    logging.info('[校验AF列]当不为空时，值只能为：1')
    is_check_passed = True
    skip_blank_line_flag = True
    for rn in reversed(df.index):
        _af = df['AF'][rn]
        if skip_blank_line_flag is True and _af == '':  # 跳过末尾空白行
            continue
        else:
            skip_blank_line_flag = False
            if _af == '' or _af == '1':
                continue
            else:
                is_check_passed = False
                lt['AF'][rn].cmt('red', '值只能为：1')
    return is_check_passed


@logfn
def chk_dp_d_e(lt: AdTable, df: DataFrame) -> bool:
    """同一行D、E必然同时有值"""
    logging.info('[校验D、E列]同一行D、E必然同时有值')
    is_check_passed = True
    for rn in df.index:
        _d = df['D'][rn]
        _e = df['E'][rn]
        if ''.join([_d, _e]) == '':  # 全为空
            continue
        elif '' not in [_d, _e]:  # 全不为空
            continue
        else:
            is_check_passed = False
            lt['D'][rn].cmt('red', '同一行D、E必然同时有值')
            lt['E'][rn].cmt('red', '同一行D、E必然同时有值')
    return is_check_passed


@logfn
def chk_dp_m_o_p_q_s(lt: AdTable, df: DataFrame) -> bool:
    """同一行M、O、P、Q、S必然同时有值"""
    logging.info('[校验M、O、P、Q、S列]同一行M、O、P、Q、S必然同时有值')
    is_check_passed = True
    for rn in df.index:
        _m = df['M'][rn]
        _o = df['O'][rn]
        _p = df['P'][rn]
        _q = df['Q'][rn]
        _s = df['S'][rn]
        if ''.join([_m, _o, _p, _q, _s]) == '':  # 全为空
            continue
        elif '' not in [_m, _o, _p, _q, _s]:  # 全不为空
            continue
        else:
            is_check_passed = False
            lt['M'][rn].cmt('red', '同一行M、O、P、Q、S必然同时有值')
    return is_check_passed


@logfn
def chk_dp_v_w_x_y_z_aa_ab_ac_ad_ae(lt: AdTable, df: DataFrame) -> bool:
    """同一行V、W、X、Y、Z、AA、AB、AC、AD、AE必然同时有值"""
    logging.info('[校验V、W、X、Y、Z、AA、AB、AC、AD、AE列]同一行V、W、X、Y、Z、AA、AB、AC、AD、AE必然同时有值')
    is_check_passed = True
    for rn in df.index:
        _v = df['V'][rn]
        _w = df['W'][rn]
        _x = df['X'][rn]
        _y = df['Y'][rn]
        _z = df['Z'][rn]
        _aa = df['AA'][rn]
        _ab = df['AB'][rn]
        _ac = df['AC'][rn]
        _ad = df['AD'][rn]
        _ae = df['AE'][rn]
        if ''.join([_v, _w, _x, _y, _z, _aa, _ab, _ac, _ad, _ae]) == '':  # 全为空
            continue
        elif '' not in [_v, _w, _x, _y, _z, _aa, _ab, _ac, _ad, _ae]:  # 全不为空
            continue
        else:
            is_check_passed = False
            lt['V'][rn].cmt('red', '同一行V、W、X、Y、Z、AA、AB、AC、AD、AE必然同时有值')
    return is_check_passed


@logfn
def chk_dp_a_b_logic(lt: AdTable, df: DataFrame) -> bool:
    """A、B当不为空时，其值必在AD中"""
    logging.info('[校验A、B列]同一行A、B当不为空时，其值必在AD中')
    is_check_passed = True
    _aa = [v[:4] for v in df['AD'].values if v != '']
    for rn in df.index:
        _a = df['A'][rn]
        _b = df['B'][rn]
        if _a != '' and _a not in _aa:
            is_check_passed = False
            lt['A'][rn].cmt('red', '不为空时，其值必在AD中')
        if _b != '' and _b not in _aa:
            is_check_passed = False
            lt['B'][rn].cmt('red', '不为空时，其值必在AD中')
    return is_check_passed


@logfn
def chk_dp_d_m(lt: AdTable, df: DataFrame) -> bool:
    """D、M其值必在AD中"""
    logging.info('[校验D、M列]D、M其值必在AD中')
    is_check_passed = True
    _aa = [v[:4] for v in df['AD'].values if len(v) >= 4]
    for column_letter in ['D', 'M']:
        skip_blank_line_flag = True
        for rn in reversed(df.index):
            if skip_blank_line_flag is True and df[column_letter][rn] == '':
                continue
            else:
                skip_blank_line_flag = False
                if df[column_letter][rn] not in _aa:
                    is_check_passed = False
                    lt[column_letter][rn].cmt('red', '值必在AD中')
    return is_check_passed


@logfn
def chk_dp_y_ac_ad(lt: AdTable, df: DataFrame) -> bool:
    """V、Z、AA前四个字符必然相同"""
    logging.info('[校验Y、AC、AD列]Y、AC、AD前四个字符必然相同')
    is_check_passed = True
    for rn in df.index:
        _y = df['Y'][rn]
        _ac = df['AC'][rn]
        _ad = df['AD'][rn]
        if ''.join([_y, _ac, _ad]) != '':
            try:
                if _y[:4] == _ac[:4] and _ac[:4] == _ad[:4]:  # 前4个字符相同
                    continue
                else:
                    is_check_passed = False
                    lt['V'][rn].cmt('red', 'Y、AC、AD前四个字符必然相同')
            except Exception:
                is_check_passed = False
                lt['V'][rn].cmt('red', 'Y、AC、AD前四个字符必然相同')
    return is_check_passed


@logfn
def chk_dp_ac(lt: AdTable, df: DataFrame, df_merged: DataFrame, group_name: str) -> bool:
    """检验【本组-AC】的值是否存在于 “其他组【调配码表库BO】”的【调配码表库-BM】若存在，报错"""
    logging.info('[校验AC列]检验【本组-AC】的值是否存在于 “其他组【调配码表库BO】”的【调配码表库-BM】若存在，报错')
    _bm = [k for k in df_merged[df_merged['BL'] != group_name]['BJ'].values if k != '']
    is_check_passed = True
    for rn in df.index:
        if df['AC'][rn] != '' and df['AC'][rn] in _bm:
            is_check_passed = False
            lt['AC'][rn].cmt('red', '【本组AC】的值存在于其他组【调配码表库-BM】列')
    return is_check_passed


@logfn
def chk_dp_ad(lt: AdTable, df: DataFrame, df_merged: DataFrame, group_name: str) -> bool:
    """检验【本组-AD】的值是否存在于 “所有组【调配码表库BL】”的【调配码表库-AS】若不存在，报错"""
    logging.info('[校验AD列]检验【本组-AD】的值是否存在于 “所有组【调配码表库BL】”的【调配码表库-AS】若不存在，报错')
    _as = [k for k in df_merged['AS'].values if k != '']
    is_check_passed = True
    for rn in df.index:
        if df['AD'][rn] != '' and df['AD'][rn] not in _as:
            is_check_passed = False
            lt['AD'][rn].cmt('red', '【本组AD】的值不存在于所有组【调配码表库-AS】列')
    return is_check_passed


@logfn
def chk_dp_group(filename: str, group_name: str) -> bool:
    logging.info('【校验分组码表库】')
    lt = load_from_xlsx_file(filename, skip_header=2)
    lt.clear_comment_and_fgcolor()
    df = lt.to_dataframe()
    lt_dims = load_tb_dim_hr_diao_pei()
    df_dims = lt_dims.to_dataframe()
    is_check_passed = []
    is_check_passed.append(chk_file_header(lt, df, group_name))
    is_check_passed.append(chk_null(lt, df))
    is_check_passed.append(chk_dp_a_b(lt, df))
    is_check_passed.append(chk_dp_d_m_y_ac(lt, df))
    is_check_passed.append(chk_dp_e_n(lt, df))
    is_check_passed.append(chk_dp_ab_ad(lt, df))
    is_check_passed.append(chk_dp_o(lt, df, df_dims))
    is_check_passed.append(chk_dp_q(lt, df))
    is_check_passed.append(chk_dp_r(lt, df))
    is_check_passed.append(chk_dp_v_1(lt, df))
    is_check_passed.append(chk_dp_t(lt, df))
    is_check_passed.append(chk_dp_v_2(lt, df))
    is_check_passed.append(chk_dp_w_x(lt, df))
    is_check_passed.append(chk_dp_z(lt, df))
    is_check_passed.append(chk_dp_aa(lt, df))
    is_check_passed.append(chk_dp_ae(lt, df, group_name))
    is_check_passed.append(chk_dp_af(lt, df))
    is_check_passed.append(chk_dp_d_e(lt, df))
    is_check_passed.append(chk_dp_m_o_p_q_s(lt, df))
    is_check_passed.append(chk_dp_v_w_x_y_z_aa_ab_ac_ad_ae(lt, df))
    is_check_passed.append(chk_dp_a_b_logic(lt, df))
    is_check_passed.append(chk_dp_d_m(lt, df))
    is_check_passed.append(chk_dp_y_ac_ad(lt, df))
    lt.save(filename)
    return all(is_check_passed) is True


@logfn
def chk_dp_merged(filename: str, merged_filename: str, group_name) -> bool:
    logging.info('【校验合并后码表库】')
    lt = load_from_xlsx_file(filename, skip_header=2)
    df = lt.to_dataframe()
    lt_merged = load_from_xlsx_file(merged_filename, skip_header=2)
    df_merged = lt_merged.to_dataframe()
    is_check_passed = []
    is_check_passed.append(chk_dp_ac(lt, df, df_merged, group_name))
    is_check_passed.append(chk_dp_ad(lt, df, df_merged, group_name))
    lt.save(filename)
    return all(is_check_passed) is True


@logfn
def update_full_dims(dims_name: str, filename: str):
    """上传整个码表"""
    logging.info(f'更新码表库：{dims_name}')
    if dims_name == '调配码表库':
        upload_dims_diao_pei(filename)
    elif dims_name == '离退码表库':
        upload_dims_li_tui(filename)


@logfn
def column_values(df: DataFrame, dims_name: str, column_letter: str) -> List[str]:
    """"获取DataFrame某一列的值，过滤列末尾空行"""
    if column_letter in df.columns:
        align_column_letter = column_letter
        if f'{dims_name}{align_column_letter}' in ALIGN_COLUMNS.keys():
            align_column_letter = ALIGN_COLUMNS[f'{dims_name}{align_column_letter}']
        end_idx = 2
        for idx in reversed(df.index):
            end_idx = idx
            if df[align_column_letter][idx].rstrip() != '':
                break
        values = df[column_letter][:end_idx - 2].values.tolist()
        return [v.rstrip() for v in values]
    else:
        return []


@logfn
def merge_column(df_public: DataFrame, df_groups: List[DataFrame], dims_name: str, public_column_letter: str) -> List[str]:
    """合并公用.xlsx与各组xlsx某列的值"""
    result = column_values(df_public, dims_name, public_column_letter)  # 公共部分
    if f'{dims_name}{public_column_letter}' in HEADER_MAP.keys():
        for df in df_groups:
            # 在组与组之间插入空行进行区分
            result = result + ['', '', ''] + column_values(df, dims_name, HEADER_MAP[f'{dims_name}{public_column_letter}'])
    return [v.rstrip() for v in result]


@logfn
def merge_dims(dims_name: str, dirname: str) -> str:
    """合并(公共、各组)码表库，返回合并后文件路径"""
    logging.info('合并码表库')
    logging.info('加载码表库公用部分')
    lt_public = load_from_xlsx_file(Path(dirname).joinpath(f'{dims_name}/公用.xlsx').as_posix(), skip_header=2)
    df_public = lt_public.to_dataframe()  # 公用码表值
    lt_public.delete_all_contents()
    df_groups = []
    for name in GROUP_NAMES:  # 加载各组码表
        logging.info(f'加载码表库{name}部分')
        _p = Path(dirname).joinpath(f'{dims_name}/{name}.xlsx')
        if _p.exists() is False:
            logging.warning(f'FTP上不存在{name}码表文件，跳过合并该组码表')
            continue
        lt_group = load_from_xlsx_file(_p.as_posix(), skip_header=2)
        df_group = lt_group.to_dataframe()
        df_groups.append(df_group)  # 各组的码表值
    logging.info('合并' + '、'.join(df_public.columns) + '列')
    for public_column_letter in df_public.columns:
        values = merge_column(df_public, df_groups, dims_name, public_column_letter)
        for rn, v in enumerate(values, start=3):
            lt_public[public_column_letter][rn].value = v
    logging.info('生成合并后文件')
    merged_filename = Path(dirname).joinpath(f'{dims_name}-合并.xlsx').as_posix()
    lt_public.save(merged_filename)
    logging.info(f'合并后文件：{merged_filename}')
    return merged_filename


@logfn
def download_dims(dims_name: str, group_name: str, filename: str):
    """下载码表"""
    if group_name not in GROUP_NAMES + ['公用', '全部']:
        raise Exception('不是有效的组名')
    if dims_name in ['调配码表库', '离退码表库']:
        if group_name != '全部':
            with MYFTP() as myftp:
                myftp.download_file(filename, f'/HR码表库/{dims_name}/{group_name}.xlsx')
                logging.info('下载码表成功')
        else:
            tempdir = gentempdir()
            with MYFTP() as myftp:
                myftp.download_file_tree(tempdir, f'/HR码表库/{dims_name}/')
                merged_filename = merge_dims(dims_name, tempdir)
                shutil.copyfile(merged_filename, filename)
    else:
        raise Exception('只支持【调配码表库】和【离退码表库】')


@logfn
def update_dims(dims_name: str, group_name: str, filename: str, staff_group: str = '', staff_name: str = ''):
    """上传公共码表部分"""
    logging.info(f'【{dims_name}-{group_name}】{filename}')
    if dims_name not in TB_NAMES.keys():
        raise Exception(f'【{dims_name}】不是有效的码表库名称')
    if group_name not in GROUP_NAMES + ['公用', '全部']:
        raise Exception(f'【{group_name}】不是有效的组名')
    if Path(filename).exists() is False:
        raise Exception(f'码表文件不存在：{filename}')
    with MyRedis() as r:
        try:
            logging.info('正在检查是否有正在进行的码表库更新任务')
            with r.lock(f'更新码表库-{dims_name}', timeout=10 * 60, blocking_timeout=20) as _:
                if group_name in GROUP_NAMES:
                    is_check_passed = False
                    if dims_name == '调配码表库':
                        is_check_passed = chk_dp_group(filename, group_name)
                    elif dims_name == '离退码表库':
                        is_check_passed = chk_lt_group(filename, group_name)
                    if is_check_passed is not True:
                        logging.error(f'前置校验未通过，请检查文件批注：{filename}')
                        return
                    else:
                        logging.info('校验通过')
                tempdir = gentempdir()
                with MYFTP() as myftp:
                    myftp.download_file_tree(tempdir, f'/HR码表库/{dims_name}/')
                dst_filename = Path(tempdir).joinpath(f'{dims_name}/{group_name}.xlsx').as_posix()
                shutil.copyfile(filename, dst_filename)
                lt = load_from_xlsx_file(filename)
                current_time = datetime.datetime.now().strftime(r'%Y-%m-%d %H:%M:%S')
                lt.wb.properties.description = current_time  # 更新码表文件中的日期
                lt.save(dst_filename)
                merged_filename = merge_dims(dims_name, tempdir)
                if group_name in GROUP_NAMES:
                    is_check_passed = False
                    if dims_name == '调配码表库':
                        is_check_passed = chk_dp_merged(filename, merged_filename, group_name)
                    if dims_name == '离退码表库':
                        is_check_passed = chk_lt_merged(filename, merged_filename, group_name)
                    if is_check_passed is not True:
                        logging.error(f'合并校验未通过，请检查文件批注：{filename}')
                        return
                    else:
                        logging.info('校验通过')
                logging.info('备份码表库')
                with MYFTP() as myftp:
                    now = datetime.datetime.now()
                    daytime = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
                    yyyymmdd = now.strftime(r'%Y%m%d')
                    hhmmss = now.strftime(r'%H%M%S')
                    myftp.upload_file_tree(Path(tempdir).joinpath(dims_name).as_posix(), f'/HR码表库/备份/{dims_name}/{yyyymmdd}/{hhmmss}/')
                logging.info('更新码表库')
                update_full_dims(dims_name, merged_filename)
                with MYFTP() as myftp:
                    myftp.upload_file(filename, f'/HR码表库/{dims_name}/{group_name}.xlsx')
                logging.info('更新码表成功')
                with MyRedis() as r:
                    r.lpush('码表库-更新记录', f'{daytime} {staff_group}-{staff_name} 更新了 {dims_name}-{group_name}')
                    r.ltrim('码表库-更新记录', 0, 300)  # 只保留近60次更新记录
        except LockError:
            raise Exception('其他组正在更新码表库，无法重复执行，请稍后尝试')


@logfn
def dims_update_history(group_name: str = '') -> List[str]:
    """获取码表库更新历史"""
    history: List[str] = []
    try:
        with MyRedis() as r:
            history = r.lrange('码表库-更新记录', 0, 300)
    except Exception:  # nosec
        pass
    return [h for h in history if isinstance(h, str) and h.endswith(group_name)]


if __name__ == '__main__':
    from rpa.fastrpa.log import config
    config('update_dims.log')
    # update_dims('调配码表库', '人事一组', r"E:\HR码表库\调配码表库\人事一组.xlsx")
    # update_dims('调配码表库', '人事二组', r"E:\HR码表库\调配码表库\人事二组.xlsx")
    # update_dims('调配码表库', '人事三组', r"E:\HR码表库\调配码表库\人事三组.xlsx")
    # update_dims('调配码表库', '人事四组', r"E:\HR码表库\调配码表库\人事四组.xlsx")
    # update_dims('调配码表库', '人事五组', r"E:\HR码表库\调配码表库\人事五组.xlsx")
    # update_dims('调配码表库', '人事六组', r"E:\HR码表库\调配码表库\人事六组.xlsx")
    # update_dims('离退码表库', '人事一组', r"E:\HR码表库\离退码表库\人事一组.xlsx")
    # update_dims('离退码表库', '人事二组', r"E:\HR码表库\离退码表库\人事二组.xlsx")
    # update_dims('离退码表库', '人事三组', r"E:\HR码表库\离退码表库\人事三组.xlsx")
    # update_dims('离退码表库', '人事四组', r"E:\HR码表库\离退码表库\人事四组.xlsx")
    # update_dims('离退码表库', '人事五组', r"E:\HR码表库\离退码表库\人事五组.xlsx")
    # update_dims('离退码表库', '人事六组', r"E:\HR码表库\离退码表库\人事六组.xlsx")
