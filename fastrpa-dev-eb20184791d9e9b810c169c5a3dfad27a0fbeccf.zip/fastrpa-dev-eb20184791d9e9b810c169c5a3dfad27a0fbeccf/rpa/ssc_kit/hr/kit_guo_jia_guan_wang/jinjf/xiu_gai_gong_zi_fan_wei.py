#!/usr/bin/env python
# -*- coding: utf-8 -*-
# @File    : xiu_gai_gong_zi_fan_wei.py
# @Author  : jinjianfeng
import logging
import os
import pprint
import time

import pyperclip
from openpyxl import load_workbook
from rpa.fastrpa.sap.session import attach_sap
from rpa.public.tools import cel


def xiu_function():
    session = attach_sap()
    for dirs, _, files in os.walk(rf"{os.path.expanduser('~')}\Desktop\工资范围"):
        for f in files:
            file = os.path.join(dirs, f)
            wb = load_workbook(file)
            ws = wb.active
            print(len(ws[f"A"]), file)
            for i in range(9, len(ws[f"A"]) + 1):
                logging.info(f"正在执行离职事件第{i - 9}条数据...")
                if cel(ws, f"AH{i}") == "记录已更改":
                    continue
                # ws[f"P{i}"], ws[f"Q{i}"] = "", ""
                try:
                    def tmp_enter(sess, strings):
                        try:
                            sess.findById("wnd[1]").sendVKey(0)
                        except Exception:
                            pass
                        for _ in range(5):
                            text = session.findById("wnd[0]/sbar").text
                            if "请保存" not in text:
                                session.findById("wnd[0]").sendVKey(0)
                            else:
                                return
                        else:
                            logging.info(strings + str(session.findById("wnd[0]/sbar").text))
                            strings = strings + str(session.findById("wnd[0]/sbar").text)
                            return strings if strings else "出现错误"

                    #  人事调配事件
                    session.findById("wnd[0]/tbar[0]/okcd").text = "/n PA30"
                    session.findById("wnd[0]").sendVKey(0)
                    session.findById("wnd[0]/usr/ctxtRP50G-PERNR").text = cel(ws, f"E{i}")
                    session.findById("wnd[0]/usr/tabsMENU_TABSTRIP/tabpTAB03").select()
                    session.findById(
                        "wnd[0]/usr/tabsMENU_TABSTRIP/tabpTAB03/ssubSUBSCR_MENU:SAPMP50A:0400/subSUBSCR_ITMENU:SAPMP50A:0310/tblSAPMP50ATC_MENU").getAbsoluteRow(
                        0).selected = -1
                    session.findById("wnd[0]/tbar[1]/btn[20]").press()

                    for j in range(3):
                        date = session.findById(f"wnd[0]/usr/tblMP000100TC3000/txtP0001-BEGDA[0,{j}]").text
                        if date not in ["2020.10.02", "2020.10.03"]:
                            continue
                        session.findById("wnd[0]/usr/tblMP000100TC3000").getAbsoluteRow(j).selected = -1
                        session.findById("wnd[0]/tbar[1]/btn[6]").press()
                        gz = session.findById("wnd[0]/usr/ctxtP0001-ABKRS").text
                        session.findById("wnd[0]/usr/ctxtP0001-ABKRS").text = cel(ws, f"Q{i}")[:2]
                        hgz = session.findById("wnd[0]/usr/ctxtP0001-ABKRS").text
                        yze = session.findById("wnd[0]/usr/subSUBSCREEN_T582C:ZP000100:0200/ctxtP0001-ZZ_ZEFW").text
                        if yze != cel(ws, f"AF{i}")[:2]:
                            try:
                                session.findById("wnd[0]/usr/subSUBSCREEN_T582C:ZP000100:0200/ctxtP0001-ZZ_ZEFW").text = \
                                    cel(ws, f"AF{i}")[:2]
                            except Exception:
                                pass
                        session.findById("wnd[0]").sendVKey(0)
                        session.findById("wnd[0]").sendVKey(0)
                        hze = session.findById("wnd[0]/usr/subSUBSCREEN_T582C:ZP000100:0200/ctxtP0001-ZZ_ZEFW").text
                        print(cel(ws, f"E{i}"), gz, hgz, hze)
                        session.findById("wnd[0]/tbar[0]/btn[11]").press()
                        if not session.findById("wnd[0]/sbar/pane[0]").text:
                            ws[f"AH{i}"] = "成功"
                        else:
                            ws[f"AH{i}"] = session.findById("wnd[0]/sbar/pane[0]").text
                except Exception:
                    ws[f"AH{i}"] = "未知错误"
                wb.save(file)


if __name__ == '__main__':
    xiu_function()
