#!/usr/bin/env python
# -*- coding: utf-8 -*-
# @File    : li_zhi.py
# @Author  : jinjianfeng
# @Contact : 553041800@qq.com
# @Link    : https://github.com/jinjf553
# @software: PyCharm
# @Date    : 2019/7/16 14:46
# @Version : ??
import logging
import os
import time

import rpa.config
from openpyxl import load_workbook
from rpa.fastrpa.log import config
from rpa.fastrpa.sap.session import attach_sap
from rpa.public.config import templates
from rpa.public.tools import cel

config()


def rulebase_14(file):
    wb_ = load_workbook(file)
    ws_ = wb_.active
    wb = load_workbook(os.path.join(templates, "离职事件模板表.xlsx"))
    ws = wb.active
    for i in range(9, len(ws_["A"]) + 1):
        logging.info(f"正在生成离职模板第{i-8}条数据...")
        ws[f"A{i-2}"] = str(i - 8)
        ws[f"B{i-2}"] = cel(ws_, f"E{i}")
        ws[f"C{i-2}"] = cel(ws_, f"B{i}")
        ws[f"D{i-2}"] = "20201001"
        ws[f"E{i-2}"] = "E0 成建制转出-转往中国石化系统外其他单位 "
    os.makedirs(f"{rpa.config.D_RPA}/离职模板/{time.strftime('%Y%m%d')}/", exist_ok=True)
    s_file = f"{rpa.config.D_RPA}/离职模板/{time.strftime('%Y%m%d')}/{time.strftime('%H%M%S')}_离职模板.xlsx"
    wb.save(s_file)
    return s_file


def li_zhi_tmp(r_file):
    logging.info("开始执行离职事件...")
    session = attach_sap("reuse")
    wb = load_workbook(r_file)
    ws = wb.active
    for i in range(7, len(ws["A"]) + 1):
        logging.info(f"正在执行离职事件第{i - 6}条数据...")
        if cel(ws, f"N{i}") == "成功":
            continue
        # ws[f"P{i}"], ws[f"Q{i}"] = "", ""
        try:
            def tmp_enter(sess, strings):
                try:
                    sess.findById("wnd[1]").sendVKey(0)
                except Exception:  # nosec
                    pass
                for _ in range(5):
                    text = session.findById("wnd[0]/sbar").text
                    if "请保存" not in text:
                        session.findById("wnd[0]").sendVKey(0)
                    else:
                        return
                else:
                    logging.info(strings + str(session.findById("wnd[0]/sbar").text))
                    strings = strings + str(session.findById("wnd[0]/sbar").text)
                    return strings if strings else "出现错误"

            #  人事调配事件
            session.findById("wnd[0]/tbar[0]/okcd").text = "/n ZPA40_13"
            session.findById("wnd[0]").sendVKey(0)
            session.findById("wnd[0]/usr/ctxtRP50G-PERNR").text = cel(ws, f"B{i}")
            session.findById("wnd[0]/usr/ctxtRP50G-EINDA").text = cel(ws, f"D{i}")
            session.findById("wnd[0]/usr/tblSAPMP50ATC_MENU_EVENT").getAbsoluteRow(3).selected = -1
            session.findById("wnd[0]/tbar[1]/btn[8]").press()
            session.findById("wnd[0]/usr/ctxtPSPAR-WERKS").text = "ZZGD"
            session.findById("wnd[0]/usr/ctxtP0000-MASSG").text = "10"
            string = tmp_enter(session, "")
            if string:
                ws[f"N{i}"] = "人事调配屏错误！"
                ws[f"O{i}"] = string
                wb.save(r_file)
                logging.info(f"    人事调配屏错误，SAP返回信息：{string}")
                continue
            session.findById("wnd[0]/tbar[0]/btn[11]").press()
            session.findById("wnd[0]").sendVKey(0)
            #  组织分配屏
            session.findById("wnd[0]/usr/ctxtP0001-PLANS").text = "4695276"
            string = tmp_enter(session, "")
            if string:
                ws[f"N{i}"] = "组织分配屏错误！"
                ws[f"O{i}"] = string
                wb.save(r_file)
                logging.info(f"    组织分配屏错误，SAP返回信息：{string}")
                continue
            session.findById("wnd[0]/tbar[0]/btn[11]").press()
            session.findById("wnd[0]").sendVKey(0)
            ws[f"N{i}"] = "成功"
        except Exception as e:
            raise e
            string = session.findById("wnd[0]/sbar").text
            ws[f"N{i}"] = "未知错误！"
            ws[f"O{i}"] = string if string else f"未知异常:{e}"
        wb.save(r_file)


def function1(file):
    logging.info("开始执行离职事件...")
    session = attach_sap("reuse")
    wb = load_workbook(r_file)
    ws = wb.active
    for i in range(7, len(ws["A"]) + 1):
        logging.info(f"正在执行离职事件第{i - 6}条数据...")
        if cel(ws, f"N{i}") == "成功":
            continue
        # ws[f"P{i}"], ws[f"Q{i}"] = "", ""
        try:
            def tmp_enter(sess, strings):
                try:
                    sess.findById("wnd[1]").sendVKey(0)
                except Exception:  # nosec
                    pass
                for _ in range(5):
                    text = session.findById("wnd[0]/sbar").text
                    if "请保存" not in text:
                        session.findById("wnd[0]").sendVKey(0)
                    else:
                        return
                else:
                    logging.info(strings + str(session.findById("wnd[0]/sbar").text))
                    strings = strings + str(session.findById("wnd[0]/sbar").text)
                    return strings if strings else "出现错误"

            #  人事调配事件
            session.findById("wnd[0]/tbar[0]/okcd").text = "/n PA30"
            session.findById("wnd[0]").sendVKey(0)
            session.findById("wnd[0]/usr/ctxtRP50G-PERNR").text = cel(ws, f"B{i}")
            session.findById("wnd[0]/usr/tabsMENU_TABSTRIP/tabpTAB03").select()
            session.findById(
                "wnd[0]/usr/tabsMENU_TABSTRIP/tabpTAB03/ssubSUBSCR_MENU:SAPMP50A:0400/subSUBSCR_ITMENU:SAPMP50A:0310/tblSAPMP50ATC_MENU").getAbsoluteRow(
                0).selected = -1
            session.findById("wnd[0]/tbar[1]/btn[20]").press()
            text = session.findById("wnd[0]/usr/tblMP000100TC3000/txtP0001-BEGDA[0,1]").text
            if text != "2020.10.01":
                print(cel(ws, f"B{i}"))
                continue
            session.findById("wnd[0]/usr/tblMP000100TC3000").getAbsoluteRow(1).selected = -1
            session.findById("wnd[0]/tbar[1]/btn[6]").press()
            session.findById("wnd[0]/usr/ctxtP0001-ENDDA").text = "99991231"
            session.findById("wnd[0]/usr/ctxtP0001-ENDDA").setFocus()
            session.findById("wnd[0]/usr/ctxtP0001-ENDDA").caretPosition = 8
            session.findById("wnd[0]").sendVKey(0)
            session.findById("wnd[0]").sendVKey(0)
            session.findById("wnd[0]/tbar[0]/btn[11]").press()
            ws[f"N{i}"] = "成功"
        except Exception as e:
            raise e
            string = session.findById("wnd[0]/sbar").text
            ws[f"N{i}"] = "未知错误！"
            ws[f"O{i}"] = string if string else f"未知异常:{e}"
        wb.save(r_file)


if __name__ == '__main__':
    # r_file = rulebase_14(r"x:\Users\lenovo\Desktop\重新录用-销售华东-在岗.xlsx")
    r_file = r"x:\Users\lenovo\Desktop\离退休人员-管道储运错误人员更正.xlsx"
    # li_zhi_tmp(r_file)
    function1(r_file)
