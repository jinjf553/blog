#!/usr/bin/env python
# -*- coding: utf-8 -*-
# @File    : delete_tmp.py
# @Author  : jinjianfeng
import logging

from openpyxl import load_workbook
from rpa.fastrpa.log import config
from rpa.fastrpa.sap.session import attach_sap
from rpa.public.tools import cel

config()


def delete_chong_xin_lu_yong(file):
    session = attach_sap()
    wb = load_workbook(file)
    ws = wb.active
    ws["O1"], ws["P1"] = "人事调配屏", "组织分配屏"
    for i in range(2, len(ws["A"]) + 1):
        logging.info(f"正在删除第{i-1}条数据")
        if cel(ws, f"P{i}") == "成功":
            continue
        session.findById("wnd[0]/tbar[0]/okcd").text = '/n pa30'
        session.findById("wnd[0]").sendVKey(0)
        session.findById("wnd[0]/usr/ctxtRP50G-PERNR").text = cel(ws, f"A{i}")
        session.findById("wnd[0]").sendVKey(0)
        session.findById("wnd[0]/usr/tabsMENU_TABSTRIP/tabpTAB01").select()
        session.findById("wnd[0]/usr/tabsMENU_TABSTRIP/tabpTAB01/ssubSUBSCR_MENU:SAPMP50A:0400/subSUBSCR_ITMENU:SAPMP50A:0310/tblSAPMP50ATC_MENU").getAbsoluteRow(0).selected = -1
        session.findById("wnd[0]/tbar[1]/btn[14]").press()
        date = session.findById("wnd[0]/usr/ctxtP0000-BEGDA").text
        text = session.findById("wnd[0]/usr/cmbP0000-MASSN").text
        if date == "2020.11.01" and "重新录用" in text:
            session.findById("wnd[0]/tbar[1]/btn[14]").press()
            session.findById("wnd[0]").sendVKey(0)
        else:
            ws[f"O{i}"] = "成功"
        if "记录已删除" in session.findById("wnd[0]/sbar/pane[0]").text:
            ws[f"O{i}"] = "成功"
        session.findById("wnd[0]/tbar[0]/btn[3]").press()
        try:
            session.findById("wnd[1]/usr/btnSPOP-OPTION1").press()
        except Exception:  # nosec
            pass
        session.findById("wnd[0]/usr/tabsMENU_TABSTRIP/tabpTAB03").select()
        session.findById("wnd[0]/usr/tabsMENU_TABSTRIP/tabpTAB03/ssubSUBSCR_MENU:SAPMP50A:0400/subSUBSCR_ITMENU:SAPMP50A:0310/tblSAPMP50ATC_MENU").getAbsoluteRow(0).selected = -1
        session.findById("wnd[0]/tbar[1]/btn[14]").press()
        if session.findById("wnd[0]/usr/ctxtP0001-BEGDA").text == "2020.11.01":
            session.findById("wnd[0]/tbar[1]/btn[14]").press()
            session.findById("wnd[0]").sendVKey(0)
        if "记录已删除" in session.findById("wnd[0]/sbar/pane[0]").text:
            ws[f"P{i}"] = "成功"
        if i % 20 == 0:
            wb.save(file)


def delete_lao_wu_gong(file):
    session = attach_sap()
    wb = load_workbook(file)
    ws = wb.active
    ws["O1"], ws["P1"] = "人事调配屏", "组织分配屏"
    for i in range(2, len(ws["A"]) + 1):
        logging.info(f"正在删除第{i-1}条数据")
        if cel(ws, f"P{i}") == "成功":
            continue
        session.findById("wnd[0]/tbar[0]/okcd").text = '/n pa30'
        session.findById("wnd[0]").sendVKey(0)
        session.findById("wnd[0]/usr/ctxtRP50G-PERNR").text = cel(ws, f"A{i}")
        session.findById("wnd[0]").sendVKey(0)
        session.findById("wnd[0]/usr/tabsMENU_TABSTRIP/tabpTAB01").select()
        session.findById("wnd[0]/usr/tabsMENU_TABSTRIP/tabpTAB01/ssubSUBSCR_MENU:SAPMP50A:0400/subSUBSCR_ITMENU:SAPMP50A:0310/tblSAPMP50ATC_MENU").getAbsoluteRow(0).selected = -1
        session.findById("wnd[0]/tbar[1]/btn[14]").press()
        try:
            date = session.findById("wnd[0]/usr/ctxtP0000-BEGDA").text
        except Exception:
            print(cel(ws, f"A{i}") + "  被占用")
            continue
        text = session.findById("wnd[0]/usr/cmbP0000-MASSN").text
        if date == "2020.10.31" and "劳务派遣工退回" in text:
            session.findById("wnd[0]/tbar[1]/btn[14]").press()
            session.findById("wnd[0]").sendVKey(0)
        else:
            ws[f"O{i}"] = "成功"
        if "记录已删除" in session.findById("wnd[0]/sbar/pane[0]").text:
            ws[f"O{i}"] = "成功"
        session.findById("wnd[0]/tbar[0]/btn[3]").press()
        try:
            session.findById("wnd[1]/usr/btnSPOP-OPTION1").press()
        except Exception:  # nosec
            pass
        # session.findById("wnd[0]/usr/tabsMENU_TABSTRIP/tabpTAB03").select()
        # session.findById("wnd[0]/usr/tabsMENU_TABSTRIP/tabpTAB03/ssubSUBSCR_MENU:SAPMP50A:0400/subSUBSCR_ITMENU:SAPMP50A:0310/tblSAPMP50ATC_MENU").getAbsoluteRow(0).selected = -1
        # session.findById("wnd[0]/tbar[1]/btn[14]").press()
        # if session.findById("wnd[0]/usr/ctxtP0001-BEGDA").text == "2020.10.31":
        #     session.findById("wnd[0]/tbar[1]/btn[14]").press()
        #     session.findById("wnd[0]").sendVKey(0)
        # if "记录已删除" in session.findById("wnd[0]/sbar/pane[0]").text:
        #     ws[f"P{i}"] = "成功"
        if i % 20 == 0:
            wb.save(file)
    wb.save(file)


if __name__ == '__main__':
    s_file = r"x:\Users\jinjf\Downloads\删除不成功432条 - 副本.xlsx"
    delete_lao_wu_gong(s_file)
