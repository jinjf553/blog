#!/usr/bin/env python
# -*- coding: utf-8 -*-
# @File    : nei_tui_tmp.py
# @Author  : jinjianfeng
from rpa.fastrpa.log import config
from rpa.fastrpa.path import to_windows_path_format
from rpa.public.config import remote_nt
from rpa.public.db import update_db
from rpa.public.event_public import clear_all_colour_and_comment
from rpa.ssc_kit.hr.kit_chai_dan.check_280 import check_zhrpy280
from rpa.ssc_rpa.hr.rpa_nei_tui.nei_tui_shi_jian import (nei_tui_operate,
                                                         nei_tui_post_check)

config()


def run_nei_tui(filename):
    file = to_windows_path_format(filename)
    update_db(file, "开始执行")
    # 模板批导前校验
    clear_all_colour_and_comment(file, "内退事件批导", remote_nt)
    check_zhrpy280(file)
    # nei_tui_pre_check(file)
    # if send_email(file):
    #     upload_ftp(file)
    #     return
    # 模板批导
    nei_tui_operate(filename)
    nei_tui_post_check(filename)


if __name__ == '__main__':
    file = r"x:\Users\lenovo\Desktop\0000000000-0000-员工入职-佚名\9000000460-ZZGD-内退-常金兰.xlsx"
    run_nei_tui(file)
