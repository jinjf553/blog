#!/usr/bin/env python
# -*- coding: utf-8 -*-
# @File    : chong_lu_tmp.py
# @Author  : jinjianfeng
import logging
import os
import re
import shutil
import time
from collections import defaultdict
from datetime import datetime

import pyperclip
from openpyxl import load_workbook
from openpyxl.utils import get_column_letter
from rpa.fastrpa.adtable import BLUE, RED
from rpa.fastrpa.log import config
from rpa.fastrpa.sap.session import attach_sap
from rpa.fastrpa.xlsx import connect_to_excel
from rpa.public.config import FILE_PATH, templates
from rpa.public.db import update_db
from rpa.public.tools import cel, cells
from rpa.ssc.hr.orm.orm_ope import DbSession, Query
from rpa.ssc.hr.orm.tb_hr_ruzhi_log_detail import RZLog_detail
from rpa.ssc.hr.orm.td_hr_gang_wei_diao_pei_rulebase import Event
from rpa.ssc_kit.hr.kit_chai_dan.check_280 import check_zhrpy280, get_grade
from rpa.ssc_rpa.hr.rpa_chong_xin_lu_yong.chong_xin_lu_yong_shi_jian import (
    cxly_check_103, export_verification_table, get_gwxx_info)
from rpa.ssc_rpa.hr.rpa_ru_zhi.ru_zhi_check import export_1071_1072

config()


def rulebase_16_2_dev(file, file_str):
    wb = load_workbook(file)
    ws_ = wb.active
    value_dict = defaultdict(list)
    for i in range(9, len(ws_["AB"]) + 1):
        c_v = cel(ws_, f"E{i}") if "重新录用" in cel(ws_, f"E{4}") else cel(ws_, f"AB{i}")
        if c_v and c_v.replace(" ", '').isdigit():
            value_dict[c_v.replace(" ", '')] = [str(j.value).strip().strip("None") for j in ws_[f"B{i}:AG{i}"][0]]

    rule_uvw = {res.db_U: [res.db_V, res.db_W] for res in Query(table=Event) if
                res.db_U and res.db_V and res.db_W}  # 17 职位序列、职位层级、职位级别
    rule_lm = {res.db_L: res.db_M for res in Query(table=Event) if res.db_L and res.db_M}  # 17 人员子组、职位序列
    tdt = {8: "BN", 6: "AS", 7: "E", 9: "J", 10: "L", 11: "BO", 12: "AG", 13: "BP", 14: "Y", 15: "F", 18: "AH", 19: "R",
           20: "BQ", 21: "V", 22: "W", 23: "U", 25: "R", 26: "V", 27: "W", 28: "U", 31: "R", 32: "R", 33: "R",
           34: "R", 36: "CW", 37: "R", 38: "R", 44: "DA", 45: "DB", 46: "DC", 47: "DD", 48: "DE", 49: "CZ",
           50: "DF", 52: "DG"}
    rule_dict = defaultdict(list)
    for r in Query(Event):
        for k, v in tdt.items():
            if eval("r.db_" + v):
                rule_dict[k].append(eval("r.db_" + v).replace(" ", ""))
    date = [ws_[f"C{x}"].value for x in range(9, len(ws_["C"]) + 1) if ws_[f"C{x}"].value and str(ws_[f"C{x}"].value).isdigit()]
    if not date:
        logging.info("入职时间错误")
        return
    get_gwxx_info(value_dict, os.path.dirname(file), date[0])

    wb_temp = load_workbook(os.path.join(templates, "ZBI0037_重新录用模板.xlsx"))
    ws = wb_temp.active
    logging.info("开始生成并校验重新录用模板数据...")
    for num, (k, v) in enumerate(list(value_dict.items())):
        # 规则 4.2.2 - 4.2.9 & 4.2.12 - 4.2.14  B-AN
        logging.info(f"    正在生成重新录用第{num + 1}条数据...")
        if "重新录用" in cel(ws_, "E4"):
            v[3], v[4] = v[4], v[5]

        ws[f"A{num+7}"] = num + 1
        ws[f"B{num+7}"] = k
        ws[f"C{num+7}"] = v[0] if v[0] != "None" else None
        ws[f"D{num+7}"] = v[1] if v[1] != "None" else None
        ws[f"H{num+7}"] = v[2].replace("重新录用-", "") if v[2] != "重新录用" else "   重新录用"
        ws[f"I{num+7}"] = v[13] if v[13] != "None" else None
        ws[f"J{num+7}"] = v[14] if v[14] != "None" else None
        ws[f"L{num+7}"] = v[15] if v[15] != "None" else None
        ws[f"O{num+7}"] = v[19] if v[19] != "None" else None
        ws[f"S{num+7}"] = "  " + v[17] if v[17] == "否" else v[17].strip("None")
        ws[f"T{num+7}"] = v[18] if v[18] != "None" else None
        db_U = [(r.db_V, r.db_W) for r in Query(table=Event, db_U=v[16].strip())]
        if db_U:
            db_V, db_W = db_U[0][0], db_U[0][1]
        else:
            db_V, db_W = '', ''
        ws["U%s" % str(num + 7)] = db_V
        ws["V%s" % str(num + 7)] = db_W
        ws["W%s" % str(num + 7)] = v[16] if v[16] != "None" else None
        ws["E%s" % str(num + 7)] = v[4].split()[0].strip("None")
        ws["F%s" % str(num + 7)] = v[28].strip("None")
        ws["G%s" % str(num + 7)] = v[29].strip("None")
        ws["R%s" % str(num + 7)] = v[30].strip("None")
        ws["BA%s" % str(num + 7)] = v[26].strip("None")
        ws["X%s" % str(num + 7)] = v[4].split()[-1].strip("None")
        ws["P%s" % str(num + 7)] = v[20] if v[20] != "None" else None
        ws["Q%s" % str(num + 7)] = v[21] if v[21] != "None" else None
        ws["AQ%s" % str(num + 7)] = v[3] if v[3] != "None" else None
        ws["AR%s" % str(num + 7)] = v[7] if v[7] != "None" else None
        ws["AS%s" % str(num + 7)] = v[8] if v[8] != "None" else None
        ws["AT%s" % str(num + 7)] = v[9] if v[9] != "None" else None
        ws["AU%s" % str(num + 7)] = v[10] if v[10] != "None" else None
        ws["AV%s" % str(num + 7)] = v[11] if v[11] != "None" else None
        ws["AW%s" % str(num + 7)] = v[22] if v[22] != "None" else None
        ws["AX%s" % str(num + 7)] = v[23] if v[23] != "None" else None
        ws["AY%s" % str(num + 7)] = v[24] if v[24] != "None" else None
        ws["AZ%s" % str(num + 7)] = v[25] if v[25] != "None" else None
        #  校验部分
        if not ws[f"E{num + 7}"].value:
            cells(ws, f"E{num + 7}", "岗位编号不能为空", RED)

        if not ws[f"F{num + 7}"].value:
            cells(ws, f"F{num + 7}", "人事范围不能为空", RED)

        if not ws[f"G{num + 7}"].value:
            cells(ws, f"G{num + 7}", "人事子范围不能为空", RED)

        # 16  检查模板有长度要求的字段符合要求
        if len(str(ws[f"AC{num + 7}"].value).strip()) > 40:
            cells(ws, f"AC{num + 7}", "请检查数据长度超长", RED)

        # 13  检验重新录用所有相关模板中必填项内容不为空
        for j in [get_column_letter(x) for x in range(1, 53)]:
            if "X" in str(ws[j + "3"].value) and ws[f"{j}{num + 7}"].value is None:
                cells(ws, f"{j}{num + 7}", "此单元格为必填项", RED)

        # 15  检验重新录用模板【B】列人员岗位状态
        # tmpb = str(ws[f"B{num + 7}"].value).lstrip("0")
        # if tmpb in values_103.keys():
        #     if values_103[tmpb][0] != "None":
        #         if "在岗" == values_103[tmpb][3] or "减册人员" != values_103[tmpb][-1]:
        #             cells(ws, f"B{num + 7}", "系统中此人员已为在岗状态，请注意检查", RED)

        # 15  检验重新录用时间是否符合要求
        tmpd = str(ws[f"D{num + 7}"].value).strip()[:8]
        try:
            time.strptime(tmpd, '%Y%m%d')
            current_date = time.strftime("%d", time.localtime(time.time()))
            current_month = time.strftime("%Y%m01", time.localtime(time.time()))
            next_month = time.strftime("%Y%m01",
                                       time.localtime(time.time() + (32 - int(current_date)) * 24 * 60 * 60))
            if tmpd not in [current_month, next_month]:
                cells(ws, f"D{num + 7}", "请核查此数值是否为有效重新录用时间", RED)
            if num + 7 != 7 and str(ws[f"D{num + 6}"].value).strip() != str(ws[f"D{num + 7}"].value).strip():
                cells(ws, f"D{num + 7}", "请核查此数值是否为有效重新录用时间", RED)
        except Exception:
            cells(ws, f"D{num + 7}", "请核查此数值是否为有效重新录用时间", RED)

        # 12  检验重新录用所有相关模板有码表的均符合码表规则
        for key, val in rule_dict.items():
            if not ws.cell(num + 7, key).value:
                continue
            if str(ws.cell(num + 7, key).value).replace(" ", "") not in val:
                cells(ws, (num + 7, key), "单元格数据不是码值", BLUE if key == 50 else RED)

        # 24  检查人员组与人员子组是否匹配
        tmpi, tmpj = str(ws[f"I{num + 7}"].value).strip().split()[0], str(ws[f"J{num + 7}"].value).strip().split()[0]
        if (tmpi == "B" and tmpj not in ["12", "13", "14", "15", "16", "17", "21", "22"]) or \
                (tmpi == "M" and tmpj not in ["61", "62", "63"]):
            cells(ws, f"I{num + 7}", "请检查人员组与人员子组是否匹配", RED)

        tmpj, tmpw, tmpu, tmpv = [str(ws[f"{x}{num + 7}"].value).strip() for x in ["J", "W", "U", "V"]]
        if tmpw not in rule_uvw.keys() or rule_uvw[tmpw][0] != tmpu or rule_uvw[tmpw][
                1] != tmpv or tmpj not in rule_lm.keys() or tmpu != rule_lm[tmpj]:
            cells(ws, f"J{num + 7}", "请检查人员子组和职位序列信息", RED)
    serial_id = datetime.now().strftime("%Y-%m-%d-%H-%M-%S-%f")
    wb_temp.properties.description = serial_id
    wb_temp.save(FILE_PATH + '/tmp-重新录用模板.xlsx')  # nosec
    if os.path.exists(FILE_PATH + '/tmp-重新录用模板.xlsx'):  # nosec
        check_zhrpy280(FILE_PATH + '/tmp-重新录用模板.xlsx')  # nosec
        file_str = file_str if file_str else os.path.basename(file)
        get_grade(f"{file_str.split('-')[0][:10]}-XX-XX", value_dict, "重新录用", serial_id)


def shi_qian_check_excel(dir_path, string="员工入职"):
    logging.info("开始进行重新录用模板事前检查......")
    sr, code = "", ""
    for _file, dir, files in os.walk(dir_path):
        for f in files:
            if string in f:
                sr, code, event, worker = f.split("-")[:4]
                break
        else:
            continue
        break
    else:
        return False, "", code, sr
    old_file = dir_path + "/重新录用模板.xlsx"
    new_file = dir_path + f"/{sr}-{code}-重新录用-{worker}"
    if os.path.exists(old_file):
        shutil.move(old_file, new_file)
    if not os.path.exists(new_file):
        logging.info("完成重新录用模板事前检查...")
        logging.info("检查结果: 无重新录用模板")
        return False, "", "", ""
    # wb = load_workbook(new_file)
    # ws = wb.active
    #
    # if len(ws["A"]) > 107:
    #     wb_ = load_workbook(TEMPLATE_DIR + "/ZBI0037_重新录用模板.xlsx")
    #     ws_ = wb_.active
    #     for x in range(7, len(ws["A"]) + 1):
    #         for y in range(1, ws.max_column + 1):
    #             ws_.cell((x - 7) % 50 + 7, y).value = ws.cell(x, y).value
    #         if (x - 6) % 50 == 0:
    #             logging.info((x - 6) / 50)
    #             wb_.save(new_file[:-5] + f"-{int((x - 6) / 50)}.xlsx")
    #             dirs = os.path.dirname(new_file)
    #             shutil.copytree(dirs, os.path.dirname(dirs) + f"/{os.path.basename(dirs)}-{int((x - 6) / 50)}")
    #             os.remove(
    #                 os.path.dirname(dirs) + f"/{os.path.basename(dirs)}-{int((x - 6) / 50)}/{os.path.basename(new_file)}")
    #             os.remove(new_file[:-5] + f"-{int((x - 6) / 50)}.xlsx")
    #     logging.info("文件人数大于100人，已分文件，返回看上级目录。")
    #     return

    rule_U_V_W = {res.db_U: [res.db_V, res.db_W] for res in Query(table=Event) if
                  res.db_U and res.db_V and res.db_W}  # 17 职位序列、职位层级、职位级别
    # rule_L_M = {res.db_L: res.db_M for res in Query(table=Event) if res.db_L and res.db_M}  # 17 人员子组、职位序列
    rule_AA_AH = {res.db_AA + res.db_AB[:4] + res.db_AE: res.db_AH for res in Query(table=Event) if
                  res.db_AA and res.db_AB and res.db_AE}  # 11 工资总额控制范围
    tdt = {9: "J", 10: "L", 13: "BP", 14: "Y", 15: "F", 19: "R",
           20: "BQ", 21: "V", 22: "W", 23: "U", 25: "R", 26: "V", 27: "W", 28: "U", 31: "R", 32: "R", 33: "R",
           34: "R", 36: "CW", 37: "R", 38: "R", 44: "DA", 45: "DB", 46: "DC", 47: "DD", 48: "DE", 49: "CZ",
           50: "DF", 52: "DG"}
    rule_dic = defaultdict(list)
    for r in Query(Event):
        for k, v in tdt.items():
            if eval("r.db_" + v):
                rule_dic[k].append(eval("r.db_" + v).replace(" ", ""))
    check_zhrpy280(new_file)
    # xl = Dispatch("Excel.Application")
    xl = connect_to_excel()  # 20210113 用通用连接Excel方法替换直连，连接失败时kill Excel并重试
    xl.Visible = True
    xl.DisplayAlerts = False
    wb = xl.Workbooks.Open(new_file)
    try:
        ws = wb.ActiveSheet
        rows = ws.Range("B%s" % str(ws.Rows.Count)).End(-4162).Row
        ws.Range("A7:CZ%s" % str(ws.Rows.Count)).ClearComments()
        ws.Range("A7:CZ%s" % str(ws.Rows.Count)).Interior.ColorIndex = -4142
        if rows < 7:
            logging.info("检查结果: 重新录用模板中无数据，跳过校验")
            return False, "", "", ""
        name_dict = {str(i[3]).replace(".0", ""): i[0] for i in ws.Range("B7:E%s" % str(rows)).Value if
                     str(i[3]) != 'None'}
        card_dict = {str(int(ws.Range("B%s" % str(x)).Value)): ws.Range("C%s" % str(x)).Value for x in
                     range(7, rows + 7) if ws.Range("C%s" % str(x)).Value}
        logging.info(f'{name_dict}, {card_dict}')
        date = ws.Range("D7").Value
        values_1071, values_1072 = export_1071_1072(name_dict, date, os.path.dirname(new_file))
        shutil.move(os.path.join(dir_path, "1071.xlsx"), os.path.join(dir_path, "重新录用_1071.xlsx"))
        shutil.move(os.path.join(dir_path, "1072.xlsx"), os.path.join(dir_path, "重新录用_1072.xlsx"))
        get_gwxx_info(card_dict, os.path.dirname(new_file), date)
        for i in range(7, rows + 1):
            i = str(i)
            logging.info(f"开始校验重新录用模板第{int(i) - 6}行数据...")

            # 9  填写人事范围、人事子范围
            if not ws.Range("E" + i).Value:
                cells(ws, "E" + i, "岗位编号不能为空", 3)
                continue
            if ws.Range(f"AM{i}").Value:
                continue
            tmpe = str(int(ws.Range("E" + i).Value)).lstrip("0")
            tmp_list = [x.lstrip("0") for x in values_1072.keys()]
            if tmpe in tmp_list:
                if not ws.Cells(int(i), 6).Value:
                    ws.Cells(int(i), 6).Value = values_1072[tmpe][0]
                # elif str(ws.Cells(int(i), 6).Value).strip() != values_1072[tmpe][0]:
                #     cells(ws, "F" + i, "人事范围与岗位信息不匹配", 3)
                if not ws.Cells(int(i), 7).Value:
                    ws.Cells(int(i), 7).Value = values_1072[tmpe][1]
                if not ws.Cells(int(i), 11).Value:
                    ws.Cells(int(i), 11).Value = values_1072[tmpe][2]

            # 18  检验重新录用模板中人职位序列、薪酬标杆岗位类别、岗位分类序列符合逻辑
            if tmpe not in [x.lstrip("0") for x in values_1071.keys()]:
                # cells(ws, "E" + i, "1071不存在该岗位编号，请检查", 3)
                continue
            _, tmpu = values_1071[tmpe], str(ws.Range("U" + i).Value)[:1]
            # if not ((tmp107[0] == tmp107[1][:1] == tmpu) or (tmp107[0] == tmpu == "3" and tmp107[1][:1] == "4")):
            #     cells(ws, "E" + i, "请检查岗位分类序列和薪酬标杆信息", 3)

            # 17  检验重新录用模板中人员子组、职位序列、层级符合逻辑
            tmpj = str(ws.Range("J" + i).Value).strip()
            tmpw = str(ws.Range("W" + i).Value).strip()
            tmpu = str(ws.Range("U" + i).Value).strip()
            tmpv = str(ws.Range("V" + i).Value).strip()
            if tmpw not in rule_U_V_W.keys() or rule_U_V_W[tmpw][0] != tmpu or rule_U_V_W[tmpw][
                    1] != tmpv:  # or tmpj not in rule_L_M.keys() or tmpu != rule_L_M[tmpj]:
                cells(ws, "J" + i, "请检查人员子组和职位序列信息", 3)

            # 16  检查模板有长度要求的字段符合要求
            if len(str(ws.Range("AC" + i).Value).strip()) > 40:
                cells(ws, "AC" + i, "请检查数据长度超长", 3)

            # 15  检验重新录用时间是否符合要求
            tmpd = str(ws.Range("D" + i).Value).strip()[:8]
            try:
                time.strptime(tmpd, '%Y%m%d')
                current_date = time.strftime("%d", time.localtime(time.time()))
                current_month = time.strftime("%Y%m", time.localtime(time.time()))
                next_month = time.strftime("%Y%m",
                                           time.localtime(time.time() + (32 - int(current_date)) * 24 * 60 * 60))
                if tmpd[:-2] not in [current_month, next_month]:
                    cells(ws, "D" + i, "请核查此数值是否为有效重新录用时间", 3)
                if i != "7" and str(ws.Range("D" + str(int(i) - 1)).Value).strip() != str(
                        ws.Range("D" + i).Value).strip():
                    cells(ws, "D" + i, "请核查此数值是否为有效重新录用时间", 3)
            except Exception:
                cells(ws, "D" + i, "请核查此数值是否为有效重新录用时间", 3)

            # 13  检验重新录用所有相关模板中必填项内容不为空
            for j in [chr(x // 26 + 64) + chr(x % 26 + 65) if x > 25 else chr(x + 65) for x in range(79)]:
                if "X" in str(ws.Range(j + "3").Value) and ws.Range(j + i).Value is None:
                    cells(ws, j + i, "此单元格为必填项", 3)

            # 12  检验重新录用所有相关模板有码表的均符合码表规则
            for key, value in rule_dic.items():
                if not ws.Cells(int(i), key).Value:
                    continue
                if str(ws.Cells(int(i), key).Value).replace(" ", "") not in value:
                    if key == 50:
                        cells(ws, (int(i), key), "单元格数据不是码值", 41)
                    else:
                        cells(ws, (int(i), key), "单元格数据不是码值", 3)

            # 10  检验模板中人事范围、人事子范围、工资核算范围是否匹配
            # 11  填写工资总额控制范围
            tmp_var = str(ws.Range("F" + i).Value)[:4] + str(ws.Range("G" + i).Value)[:4] + str(
                ws.Range("L" + i).Value)[:2]
            if tmp_var in rule_AA_AH.keys():
                ws.Range("R" + i).Value = rule_AA_AH[tmp_var].strip()
            elif "00" == str(ws.Range("L" + i).Value)[:2]:
                pass
            # else:
            #     cells(ws, "L" + i, "工资核算范围与人事范围、人事子范围不匹配，请核实", 3)
            #     cells(ws, "R" + i, "工资总额控制范围无匹配，请检查", 3)
            tmpv, tmpu = str(ws.Range("V" + i).Value).strip(), str(ws.Range("U" + i).Value).strip()
            # if tmpv == "30 中层管理" or (tmpv[:2].isdigit() and int(tmpv[:2]) < 50 and tmpu == "2 专业技术人员"):
            #     cells(ws, "R" + i, "请注意检查中层及专家人员的工资总额控制范围", 41)

            # 15  检验重新录用模板【B】列人员岗位状态
            tmpb = str(ws.Range("B" + i).Value).lstrip("0")
            # if tmpb in values_103.keys():
            #     if values_103[tmpb][0] != "None":
            #         if "在岗" == values_103[tmpb][3] or "减册人员" != values_103[tmpb][-1]:
            #             cells(ws, "B" + i, "系统中此人员已为在岗状态，请注意检查", 3)

            # 20  检查岗位编号下是否已经分配有人员
            if "P" in values_1071[tmpe][2] and str(tmpb).lstrip("0") != values_1071[tmpe][5]:
                cells(ws, "E" + i, "此岗位已经分配有人员，请检查", 3)

            # 21  检查岗位信息是否完整
            # if values_1071[tmpe][3]:
            #     cells(ws, "E" + i, "此岗位信息不完整，请检查", 3)

            # 22  检查事件原因、人员组和岗位信息逻辑关系
            _, tmpi = str(ws.Range("H" + i).Value).strip(), str(ws.Range("I" + i).Value).strip()
            # if not values_1071[tmpe][4]:
            #     cells(ws, f"E{i}", "岗位类别不能为空，岗位未分配", 3)
            # if ((tmpi == "B 合同制员工" and values_1071[tmpe][4][:1] != "C") or
            #         (tmph == "C 派遣制员工" and values_1071[tmpe][4] not in ["B2", "C2"])):
            #     cells(ws, "I" + i, "人员组与岗位信息不匹配", 3)
            # if (tmpi[0] != "B" and tmph[:2] == "39") or (tmpi[0] == "B" and tmph[:2] != "  "):
            #     cells(ws, "I" + i, "该事件原因只允许人员组为B合同制员工", 3)

            # 23  检查机构名称
            if tmpe in values_1072.keys() and values_1072[tmpe][3] not in str(ws.Range("AQ" + i).Value).strip():
                cells(ws, "AQ" + i, "请核实重新录用机构名称", 41)

            # 24  检查人员组与人员子组是否匹配
            tmpi = str(ws.Range("I" + i).Value).strip().split()[0]
            tmpj = str(ws.Range("J" + i).Value).strip().split()[0]
            if (tmpi == "B" and tmpj not in ["12", "13", "14", "15", "16", "17", "21", "22"]) or \
                    (tmpi == "M" and tmpj not in ["61", "62", "63"]):
                cells(ws, "I" + i, "请检查人员组与人员子组是否匹配", 3)

            # 25  提取机构全称
            if tmpe in values_1072.keys():
                ws.Range("BA" + i).Value = values_1072[tmpe][4]
        wb.Save()
        ws = wb.ActiveSheet
        rows = ws.Range("B%s" % str(ws.Rows.Count)).End(-4162).Row
        tt = ["重" + str(c.Address).replace('$', '') for c in ws.Range(f"B7:AZ{rows + 1}") if c.Interior.ColorIndex == 3]
        flag = False if not tt else True
        logging.info("完成重新录用模板事前检查...")
        logging.info("检查结果: 通过,可执行事件..." if not flag else f"检查结果: 未通过,问题单元格为{tt}")
    except Exception as e:
        raise e
    finally:
        if wb:
            wb.Close()
        if xl:
            xl.Quit()
    return flag, new_file, code, sr


def function(file):
    logging.info("开始执行重新录用事件...")
    update_db(file, "重新录用事件")
    sr = os.path.basename(file)[:10]
    wb = load_workbook(file)
    ws = wb.active
    values = [[str(x).strip().replace("None", "") for x in value[:53]] for value in ws.values if value[1]][5:]
    name_dict = {value[2].strip(): [value[1], value[20][:1], value[3], "", "", "", "", "", value[46]] for value in
                 values}
    session = attach_sap("reopen")
    for value in values:
        logging.info(f"正在执行重新录用事件第{values.index(value) + 1}条数据...")
        try:
            # 启动重新录用界面
            if value[38] in ["PA30信息维护异常"]:
                try:
                    code = "0" * (8 - len(value[1])) + value[1]
                    with DbSession() as sess:
                        res = sess.query(RZLog_detail).filter(RZLog_detail.sr == sr, RZLog_detail.code == code)
                        if res:
                            res.update(
                                {"times": res.first().times + 1, "update_time": datetime.now()})
                    chong_xin_lu_yong_pa30(value, session)
                    ws["AM%s" % str(values.index(value) + 7)] = "成功"
                    ws["AN%s" % str(values.index(value) + 7)] = ""
                    wb.save(file)
                except Exception as e:
                    ws["AN%s" % str(values.index(value) + 7)] = f"异常原因：{e}"
                    ws["AM%s" % str(values.index(value) + 7)] = "PA30信息维护异常"
                    wb.save(file)
                continue
            elif value[38] == "成功":
                continue

            session.findById("wnd[0]/tbar[0]/okcd").text = "/n ZPA40_10"
            session.findById("wnd[0]").sendVKey(0)
            session.findById("wnd[0]/usr/ctxtRP50G-EINDA").text = value[3]  # 事件时间
            session.findById("wnd[0]/usr/ctxtRP50G-PERNR").text = value[1]  # 人员编号
            session.findById("wnd[0]").sendVKey(0)
            session.findById("wnd[0]/usr/tblSAPMP50ATC_MENU_EVENT").getAbsoluteRow(2).selected = -1
            session.findById("wnd[0]/tbar[1]/btn[8]").press()

            # 人事调配屏
            session.findById("wnd[0]/usr/ctxtP0000-BEGDA").text = value[3]
            session.findById("wnd[0]/usr/ctxtP0000-MASSG").text = value[7][:2] if value[7] != "重新录用" else "  "
            session.findById("wnd[0]/usr/ctxtPSPAR-PLANS").text = value[4]
            session.findById("wnd[0]/usr/ctxtPSPAR-WERKS").text = value[5][:4]
            session.findById("wnd[0]/usr/ctxtPSPAR-PERSG").text = value[8][:1]
            session.findById("wnd[0]/usr/ctxtPSPAR-PERSK").text = value[9][:2]

            def tmp_enter(s):
                try:
                    s.findById("wnd[1]/tbar[0]/btn[0]").press()
                except Exception:  # nosec
                    pass
                for i in range(10):
                    if "请保存你的输入" not in session.findById("wnd[0]/sbar").text:
                        session.findById("wnd[0]").sendVKey(0)
                    else:
                        break

            session.findById("wnd[0]").sendVKey(0)
            tmp_enter(session)
            session.findById("wnd[0]/tbar[0]/btn[11]").press()
            tmp_enter(session)

            # 组织分配屏
            session.findById("wnd[0]/usr/ctxtP0001-BEGDA").text = value[3]
            session.findById("wnd[0]/usr/ctxtP0001-BTRTL").text = value[6][:4]  # 人事子范围
            # session.findById("wnd[0]/usr/ctxtP0001-ABKRS").text = value[11][:2]  # 工资范围
            # session.findById("wnd[0]/usr/cmbP0001-ANSVH").key = value[13][:2] if value[13] else " "
            # session.findById("wnd[0]/usr/subSUBSCREEN_T582C:ZP000100:0200/ctxtP0001-ZZ_QYZDYYGFL").text = \
            #     value[14].split()[0] if value[14] else ""
            # session.findById("wnd[0]/usr/subSUBSCREEN_T582C:ZP000100:0200/ctxtP0001-ZZ_QYZDYYGFL1").text = \
            #     value[15].split()[0] if value[15] else ""
            # session.findById("wnd[0]/usr/subSUBSCREEN_T582C:ZP000100:0200/ctxtP0001-ZZ_QYZDYYGFL2").text = \
            #     value[16].split()[0] if value[16] else ""
            # if "X" in value[18]:
            #     session.findById(
            #         "wnd[0]/usr/subSUBSCREEN_T582C:ZP000100:0200/chkP0001-ZZ_QYTJBS1").selected = -1
            # session.findById("wnd[0]/usr/subSUBSCREEN_T582C:ZP000100:0200/cmbP0001-ZZ_ZBTJWYBZ").key = value[19][:2]
            session.findById("wnd[0]").sendVKey(0)
            try:  # 工资总额控制范围处理
                tmp_text = session.findById(
                    "wnd[0]/usr/subSUBSCREEN_T582C:ZP000100:0200/txtZHR_PYZEKZFWT-ZZ_ZEFW_TXT").text
                if not tmp_text and value[16]:
                    session.findById("wnd[0]/usr/subSUBSCREEN_T582C:ZP000100:0200/ctxtP0001-ZZ_ZEFW").text = \
                        value[14].split()[0]
            except Exception:
                print(value[14])
            tmp_enter(session)
            session.findById("wnd[0]/tbar[0]/btn[11]").press()
            tmp_enter(session)

            #  岗位聘任补充信息屏
            session.findById("wnd[0]/usr/ctxtP9209-BEGDA").text = value[3]
            session.findById("wnd[0]/usr/ctxtP9209-ZZ_ZWCJXL1").text = value[20][:1]
            session.findById("wnd[0]/usr/ctxtP9209-ZZ_ZWCJXL2").text = value[21][:2]
            session.findById("wnd[0]/usr/ctxtP9209-ZZ_ZWCJXL3").text = value[22][:2]
            session.findById("wnd[0]/usr/txtP9209-ZZ_ZWMC_RC").text = value[23]
            session.findById("wnd[0]/usr/txtP9209-ZZ_PRWH").text = value[28] if value[28] else ""
            session.findById("wnd[0]").sendVKey(0)
            session.findById("wnd[0]/tbar[0]/btn[11]").press()
            try:
                chong_xin_lu_yong_pa30(value, session)
                ws["AM%s" % str(values.index(value) + 7)] = "成功"
                wb.save(file)
            except Exception as e:
                ws["AN%s" % str(values.index(value) + 7)] = f"异常原因：{e}"
                ws["AM%s" % str(values.index(value) + 7)] = "PA30信息维护异常"
                wb.save(file)
        except Exception as e:
            raise e
            text = session.findById("wnd[0]/sbar").text
            ws["AM%s" % str(values.index(value) + 7)] = text if text else "失败，原因未知"
            wb.save(file)
    return name_dict


def chong_xin_lu_yong_pa30(value, session):
    def tmp_enter(s):
        try:
            s.findById("wnd[1]/tbar[0]/btn[0]").press()
        except Exception:  # nosec
            pass
        for i in range(10):
            if "请保存你的输入" not in session.findById("wnd[0]/sbar").text:
                session.findById("wnd[0]").sendVKey(0)
            else:
                break

    def tmp_func(session, value, col, row):
        session.findById("wnd[0]/tbar[0]/okcd").text = '/n pa30'
        session.findById("wnd[0]").sendVKey(0)
        session.findById("wnd[0]/usr/ctxtRP50G-PERNR").text = value[1]
        session.findById("wnd[0]").sendVKey(0)
        session.findById(f"wnd[0]/usr/tabsMENU_TABSTRIP/tabpTAB0{col}").select()
        session.findById(
            f"wnd[0]/usr/tabsMENU_TABSTRIP/tabpTAB0{col}/ssubSUBSCR_MENU:SAPMP50A:0400/subSUBSCR_ITMENU:SAPMP50A:0310/tblSAPMP50ATC_MENU").verticalScrollbar.position = row
        text = session.findById(
            f"wnd[0]/usr/tabsMENU_TABSTRIP/tabpTAB0{col}/ssubSUBSCR_MENU:SAPMP50A:0400/subSUBSCR_ITMENU:SAPMP50A:0310/tblSAPMP50ATC_MENU/lblINF_EX[1,0]").toolTip
        session.findById(
            f"wnd[0]/usr/tabsMENU_TABSTRIP/tabpTAB0{col}/ssubSUBSCR_MENU:SAPMP50A:0400/subSUBSCR_ITMENU:SAPMP50A:0310/tblSAPMP50ATC_MENU").getAbsoluteRow(
            row).selected = -1
        btn = "6" if text == "存在" else "5"
        session.findById(f"wnd[0]/tbar[1]/btn[{btn}]").press()
        return btn

    # 工作经历
    tmp_func(session, value, 1, 4)
    date = "".join(re.findall(r"\d", str(session.findById("wnd[0]/usr/ctxtP0023-BEGDA").text)))
    if date != value[3]:
        session.findById("wnd[0]/tbar[0]/btn[3]").press()
        session.findById("wnd[0]/tbar[1]/btn[5]").press()
        session.findById("wnd[0]/usr/ctxtP0023-BEGDA").text = value[3]
        session.findById(
            "wnd[0]/usr/subSUBSCREEN_T582C:ZP002300:0200/txtP0023-ZZ_SZDWJBMMC").text = value[52] if value[52] else \
            value[42]
        session.findById("wnd[0]/usr/subSUBSCREEN_T582C:ZP002300:0200/txtP0023-ZZ_CSGZ1").text = value[23]
        session.findById("wnd[0]").sendVKey(0)
        session.findById("wnd[0]/tbar[0]/btn[11]").press()

    # 其他用工信息
    # btn = tmp_func(session, value, 2, 0)
    # if value[48] and value[8][0] == "C":
    #     date = "".join(
    #         re.findall("\d", str(session.findById("wnd[0]/usr/ctxtP9241-BEGDA").text)))  # wnd[0]/usr/ctxtP0023-BEGDA
    #     if date != value[3]:
    #         try:
    #             session.findById("wnd[0]/tbar[0]/btn[3]").press()
    #             session.findById("wnd[0]/tbar[1]/btn[5]").press()
    #             session.findById("wnd[0]/usr/ctxtP9241-BEGDA").text = value[3]
    #             session.findById("wnd[0]/usr/cmbP9241-ZZ_QTYGLY").key = value[48][:2]
    #             session.findById("wnd[0]/usr/cmbP9241-ZZ_LWPQDW").key = value[49][:4] if value[49] else " "
    #             session.findById("wnd[0]/usr/txtP9241-ZZ_LWPQDWMC").text = value[50] if value[50] else ""
    #             session.findById("wnd[0]/usr/cmbP9241-ZZ_LWPQDWLB").key = value[51][:1] if value[
    #                 51] else " "
    #         except Exception:
    #             pass
    #         session.findById("wnd[0]").sendVKey(0)
    #         session.findById("wnd[0]/tbar[0]/btn[11]").press()
    #         tmp_enter(session)
    # elif value[8][0] == "B" and btn == "6":
    #     current_date = time.mktime(time.strptime(value[3], "%Y%m%d"))
    #     yesterday = time.strftime("%Y%m%d", time.localtime(current_date - 24 * 60 * 60))
    #     end_date = session.findById("wnd[0]/usr/ctxtP9241-ENDDA").text
    #     if str(end_date) == "9999.12.31":
    #         session.findById("wnd[0]/usr/ctxtP9241-ENDDA").text = yesterday
    #         session.findById("wnd[0]/tbar[0]/btn[11]").press()
    #         tmp_enter(session)

    # 从事职业工种  todo
    # if value[9][:2] == "16":
    #     tmp_func(session, value, 3, 2)
    #     date = "".join(re.findall("\d", str(session.findById("wnd[0]/usr/ctxtP9243-BEGDA").text)))
    #     if date != value[3]:
    #         session.findById("wnd[0]/tbar[0]/btn[3]").press()
    #         session.findById("wnd[0]/tbar[1]/btn[5]").press()
    #         session.findById("wnd[0]/usr/ctxtP9243-BEGDA").text = value[3]
    #         session.findById("wnd[0]/usr/chkP9243-ZZ_SFSZYJNJDFW").selected = -1
    #     session.findById("wnd[0]").sendVKey(0)
    #     session.findById("wnd[0]").sendVKey(0)
    #     session.findById("wnd[0]/tbar[0]/btn[11]").press()


def jian_li(r_file):
    logging.info("重新带出从事职业工种信息 & 最高等级工种鉴定标识 & 生成简历")
    wb = load_workbook(r_file)
    ws = wb.active
    session = attach_sap("reopen")
    text = '\r\n'.join([cel(ws, f"B{x}") for x in range(7, len(ws["B"]) + 1)])
    pyperclip.copy(text)
    # session.findById("wnd[0]/tbar[0]/okcd").text = "/n zhrpa175"
    # session.findById("wnd[0]").sendVKey(0)
    # session.findById("wnd[0]/usr/ctxtPNPWERKS-LOW").text = os.path.basename(r_file).split("-")[1]
    # session.findById("wnd[0]/usr/ctxtPNPWERKS-LOW").setFocus()
    # session.findById("wnd[0]/usr/ctxtPNPWERKS-LOW").caretPosition = 4
    # session.findById("wnd[0]/usr/btn%_PNPPERNR_%_APP_%-VALU_PUSH").press()
    # session.findById("wnd[1]/tbar[0]/btn[16]").press()
    # session.findById("wnd[1]/tbar[0]/btn[24]").press()
    # session.findById("wnd[1]/tbar[0]/btn[8]").press()
    # session.findById("wnd[0]/tbar[1]/btn[8]").press()
    # session.findById("wnd[0]/tbar[1]/btn[14]").press()
    # session.findById("wnd[0]/tbar[1]/btn[23]").press()
    session.findById("wnd[0]/tbar[0]/okcd").text = "/nex"
    session.findById("wnd[0]").sendVKey(0)


def function1(file):
    # file = r"x:\Users\lenovo\Desktop\重新录用-华北\0000000000-0000-员工入职-佚名\9000000382-ZZHB-员工入职-管道.xlsx"
    flag, new_file, _, _ = shi_qian_check_excel(os.path.dirname(file))
    if not flag:
        function(new_file)
        jian_li(new_file)
        dir_path = os.path.dirname(new_file)
        export_verification_table(new_file)
        cxly_check_103(new_file, FILE_PATH + "/模板_103_RZ.xlsx", dir_path + "/重新录用_1071.xlsx", dir_path + "/重新录用_1072.xlsx")
        shutil.move(f"{FILE_PATH}/模板_103_RZ.xlsx", dir_path + "/校验后_重新录用103表.xlsx")


if __name__ == '__main__':
    r_file = r"x:\Users\lenovo\Desktop\0000000000-0000-员工入职-佚名 - 副本 (2)\9000000460-ZZGD-员工入职-常金兰.xlsx"
    function1(r_file)
