import logging
from pathlib import Path
from time import sleep

import rpa.config
from rpa.fastrpa.adtable import load_from_xlsx_file
from rpa.fastrpa.log import config
from rpa.fastrpa.obs.obs import OBS_REC
from rpa.fastrpa.sap.session import attach_sap

# 机构基本信息标签页 ID
SAP_TAB_ID = 'wnd[0]/usr/subMAINSCREEN:SAPLOM_NAVFRAMEWORK_OO_OBJ:1200/subWORKSPACE:SAPLOM_NAVFRAMEWORK_OO_OBJ:0200/subDETAIL:SAPLRHOMDETAILMANAGER:0100/tabsSTRIP_OMDETAIL/tabpDETLTAB01'


def enter_ppome(session, begin_date: str):
    logging.info('进入PPOME')
    session.findById("wnd[0]").maximize()
    session.findById("wnd[0]/tbar[0]/okcd").text = "/n ppome"
    session.findById("wnd[0]").sendVKey(0)
    # 指定日期和预览期间
    session.findById("wnd[0]/usr/subCONTROLSTRIP:SAPLOM_NAVFRAMEWORK_OO_OBJ:0010/subTIME_OBJECT_OVERVIEW_STRIP:SAPLOM_STANDARD_TIME_OBJ:0040/subICON:SAPLOM_STANDARD_TIME_OBJ:0045/btnDATE").press()
    logging.info(f'输入开始日期: {begin_date}')
    session.findById("wnd[1]/usr/subPERIODCHANGE:SAPLOM_STANDARD_TIME_OBJ:6020/ctxtOMFRAMEWRK-SEL_DATE").text = begin_date  # 开始日期
    session.findById("wnd[1]/tbar[0]/btn[8]").press()  # 执行
    session.findById("wnd[0]/shellcont/shell/shellcont[0]/shell/shellcont[1]/shell[1]").expandNode("          1")  # 展开【组织机构】


def change_ppome(session, org_id: str, org_short_nm: str, org_full_nm: str):
    """PPOME 修改机构简称、全称"""
    session.findById("wnd[0]/shellcont/shell/shellcont[0]/shell/shellcont[1]/shell[1]").clickLink("          2", "&Hierarchy")  # 点击【组织机构>检索项】
    session.findById("wnd[1]/usr/subSEARCH_FUNCTION_SUBSCREEN:SAPLOM_SEARCHTOOL_ORGPLAN:0160/txtSEARCH_FUNCTION-SEARK").text = org_id  # 输入机构编码
    session.findById("wnd[1]/tbar[0]/btn[0]").press()  # 点击搜索
    session.findById("wnd[0]/shellcont/shell/shellcont[1]/shell").selectedRows = "0"  # 选中【命中清单】第一项
    session.findById("wnd[0]/shellcont/shell/shellcont[1]/shell").doubleClickCurrentCell()  # 双击
    session.findById(SAP_TAB_ID).select()  # 选择机构基本信息
    try:
        session.findById(f"{SAP_TAB_ID}/ssubSUB_OMDETAIL:SAPLRHOMDETAIL_BASE:0200/txtP1000-SHORT").text = org_short_nm  # 输入组织机构简称
        session.findById(f"{SAP_TAB_ID}/ssubSUB_OMDETAIL:SAPLRHOMDETAIL_BASE:0200/txtP1000-STEXT").text = org_full_nm  # 输入组织机构全称
    except AttributeError:
        sap_status = session.findById("wnd[0]/sbar/pane[0]").text
        sleep(1.5)
        session.findById('wnd[0]').HardCopy(f'{rpa.config.D_RPA}\\ppome\\{org_id}_ERROR.bmp')
        raise Exception(sap_status)  # 机构被锁定时无法修改
    session.findById("wnd[0]/tbar[0]/btn[11]").press()  # 点击保存
    sap_status = session.findById("wnd[0]/sbar/pane[0]").text
    sleep(1.5)
    if '数据已保存' in sap_status:
        logging.info(f'SAP状态信息：{sap_status}')
        session.findById('wnd[0]').HardCopy(f'{rpa.config.D_RPA}\\ppome\\{org_id}.bmp')
    else:
        session.findById('wnd[0]').HardCopy(f'{rpa.config.D_RPA}\\ppome\\{org_id}_ERROR.bmp')
        raise Exception(sap_status)


def main(filename: str):
    lt = load_from_xlsx_file(filename, skip_header=7)
    df = lt.to_dataframe()
    session = attach_sap()
    enter_ppome(session, '2020.11.01')
    cnt = len(df)
    Path(f'{rpa.config.D_RPA}/ppome').mkdir(parents=True, exist_ok=True)  # 屏幕截图文件夹
    for rn in df.index:
        org_id = df['C'][rn]
        org_short_nm = df['D'][rn]
        org_full_nm = df['E'][rn]
        logging.info(f'[{rn}/{cnt}]修改PPOME，机构编码：{org_id}，机构简称：{org_short_nm}，机构全称：{org_full_nm}')
        try:
            change_ppome(session, org_id, org_short_nm, org_full_nm)
        except Exception as e:
            err_text = str(e)
            logging.error(err_text)
            lt['C'][rn].cmt('red', err_text)
    lt.filename = '执行后_' + lt.filename
    lt.save_to(rpa.config.D_RPA)


if __name__ == '__main__':
    config('guo_jia_guan_wang_update_ppome.log')
    with OBS_REC('无单号-国家管网-组织机构维护-常金兰'):
        main('x:/无单号-国家管网-组织机构维护-常金兰.xlsx')
        logging.info('执行完毕')
