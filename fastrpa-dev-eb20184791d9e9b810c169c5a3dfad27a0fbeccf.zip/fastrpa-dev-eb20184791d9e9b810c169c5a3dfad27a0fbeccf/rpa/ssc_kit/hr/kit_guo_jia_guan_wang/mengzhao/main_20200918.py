import datetime
import logging
from pathlib import Path

import rpa.config
from rpa.config import WORKING_DIR
from rpa.fastrpa.adtable import AdTable, load_from_xlsx_file
from rpa.fastrpa.log import config
from rpa.fastrpa.sap.session import SapClose
from rpa.ssc.hr.sap.export_107_t60 import export_107_t60
from rpa.ssc.sap.utils import init_sap_id


def load_file(filename: str) -> AdTable:
    lt = load_from_xlsx_file(filename)
    lt['B'].apply(init_sap_id)  # 人员编号
    lt['Y'].apply(init_sap_id)  # 组织机构
    lt['AA'].apply(init_sap_id)  # 岗位编码
    return lt


def update1(lt: AdTable, lt_107_t60: AdTable, lt1: AdTable):
    df = lt.to_dataframe()
    df_107_t60 = lt_107_t60.to_dataframe()
    lt1.delete_all_contents()
    df_107_t60_uniq = df_107_t60.drop_duplicates(subset=['A'], inplace=False).copy()
    lt1['K'][6].value = 'Q=O 相关对象的标识'
    for idx, rn in enumerate(df_107_t60_uniq.index, start=1):
        row = lt1.add_row()
        row['A'].value = str(idx)  # 序列号
        row['B'].value = df_107_t60_uniq['A'][rn]  # 岗位编码
        row['D'].value = '20200901'
        row['E'].value = '99991231'
        row['F'].value = df_107_t60_uniq['H'][rn]
        row['G'].value = df_107_t60_uniq['I'][rn]
        job_id = df_107_t60_uniq['A'][rn]
        df_tmp = df[df['AA'] == job_id]
        row['I'].value = df_tmp['B'].values[0]
        row['J'].value = df_tmp['C'].values[0]
        df_tmp2 = df_107_t60[(df_107_t60['A'] == job_id) & (df_107_t60['Q'] == 'O')]
        if df_tmp2.empty is False:
            row['K'].value = df_tmp2['R'].values[0]


def update2(lt: AdTable, lt_107_t60: AdTable, lt2: AdTable):
    df_107_t60 = lt_107_t60.to_dataframe()
    lt2.delete_all_contents()
    df_107_t60_uniq = df_107_t60.drop_duplicates(subset=['A'], inplace=False).copy()
    for idx, rn in enumerate(df_107_t60_uniq.index, start=1):
        row = lt2.add_row()
        row['A'].value = str(idx)
        row['B'].value = df_107_t60_uniq['A'][rn]  # 岗位编码
        row['D'].value = '20200901'
        row['E'].value = '99991231'
        job_id = df_107_t60_uniq['A'][rn]
        df_tmp = df_107_t60[(df_107_t60['A'] == job_id) & (df_107_t60['Q'] == 'C')]
        if df_tmp.empty is False:
            row['F'].value = df_tmp['R'].values[0]
        else:
            row['F'].value = ''


def update4(lt: AdTable, lt_107_t60: AdTable, lt4: AdTable):
    df = lt.to_dataframe()
    df_107_t60 = lt_107_t60.to_dataframe()
    lt4.delete_all_contents()
    df_107_t60_uniq = df_107_t60.drop_duplicates(subset=['A'], inplace=False).copy()
    for idx, rn in enumerate(df_107_t60_uniq.index, start=1):
        row = lt4.add_row()
        row['A'].value = str(idx)
        row['B'].value = df_107_t60_uniq['A'][rn]  # 岗位编码
        row['D'].value = '20200901'
        row['E'].value = '99991231'
        job_id = df_107_t60_uniq['A'][rn]
        _f = df[df['AA'] == job_id]['BE'].values[0]
        if _f in ('管理序列', '专业技术序列', '技能操作序列'):
            row['F'].value = {'管理序列': '1 管理序列',
                              '专业技术序列': '2 专业技术序列',
                              '技能操作序列': '3 技能操作序列'}[_f]
        if df_107_t60_uniq['AA'][rn] != '':
            row['G'].value = df_107_t60_uniq['AA'][rn] + ' ' + df_107_t60_uniq['AB'][rn]  # 所属专业类别
            row['H'].value = df_107_t60_uniq['AC'][rn] + ' ' + df_107_t60_uniq['AD'][rn]  # 所属专业名称
        else:
            row['J'].value = df_107_t60_uniq['AE'][rn] + ' ' + df_107_t60_uniq['AF'][rn]  # 所属工种类别
            row['K'].value = df_107_t60_uniq['AG'][rn] + ' ' + df_107_t60_uniq['AH'][rn]  # 所属工种
            row['L'].value = df_107_t60_uniq['AI'][rn]  # 工种名称
        row['M'].value = df_107_t60_uniq['AJ'][rn] + ' ' + df_107_t60_uniq['AK'][rn]  # 薪酬标杆岗位类别
        _q = df_107_t60_uniq['AM'][rn]
        if _q in ('标准工时制', '综合计算工时制', '不定时工作制'):
            row['Q'].value = {'标准工时制': '1 标准工时制',
                              '综合计算工时制': '2 综合计算工时制',
                              '不定时工作制': '3 不定时工作制'}[_q]  # 岗位工时制
        row['V'].value = 'X' if df_107_t60_uniq['AN'][rn] == '是' else ''  # 班组长标识
        row['W'].value = 'X' if df_107_t60_uniq['AP'][rn] == '是' else ''  # 虚岗位标识
        row['X'].value = 'X' if df_107_t60_uniq['AO'][rn] == '是' else ''  # 油品销售企业定员标准未覆盖标识


def update6(lt: AdTable, lt_107_t60: AdTable, lt6: AdTable):
    # df = lt.to_dataframe()
    df_107_t60 = lt_107_t60.to_dataframe()
    lt6.delete_all_contents()
    df_107_t60_uniq = df_107_t60.drop_duplicates(subset=['A'], inplace=False).copy()
    for idx, rn in enumerate(df_107_t60_uniq.index, start=1):
        row = lt6.add_row()
        row['A'].value = str(idx)
        row['B'].value = df_107_t60_uniq['A'][rn]  # 岗位编码
        row['D'].value = '20200901'
        row['E'].value = '99991231'
        job_id = df_107_t60_uniq['A'][rn]
        df_tmp = df_107_t60[(df_107_t60['A'] == job_id) & (df_107_t60['Q'] == '03')]
        if df_tmp.empty is False:
            row['F'].value = df_tmp['R'].values[0]
        else:
            row['F'].value = ''


def update8(lt: AdTable, lt_107_t60: AdTable, lt8: AdTable):
    df = lt.to_dataframe()
    df_107_t60 = lt_107_t60.to_dataframe()
    lt8.delete_all_contents()
    df_107_t60_uniq = df_107_t60.drop_duplicates(subset=['A'], inplace=False).copy()
    for idx, rn in enumerate(df_107_t60_uniq.index, start=1):
        row = lt8.add_row()
        row['A'].value = str(idx)
        row['B'].value = df_107_t60_uniq['A'][rn]  # 岗位编码
        row['D'].value = '20200901'
        row['E'].value = '99991231'
        job_id = df_107_t60_uniq['A'][rn]
        row['F'].value = df[df['AA'] == job_id]['A'].values[0]


def main(filename: str, key_date: str):
    yyyymm = datetime.datetime.now().strftime(r'%Y%m')
    yyyymmdd = datetime.datetime.now().strftime(r'%Y%m%d')
    hhmmss = datetime.datetime.now().strftime(r'%H%M%S')
    output_dir = f'{rpa.config.D_RPA}/HR人事/国家管网/{yyyymm}/{yyyymmdd}/{hhmmss}_{Path(filename).name[:-5]}'
    Path(output_dir).mkdir(parents=True, exist_ok=True)
    filename1 = f'{WORKING_DIR}/resources/templates/国家管网/mengzhao/20200918/1.1000_HR_BI_1000S--人员导入--创建（职务）岗位具体名称（S）.xlsx'
    filename2 = f'{WORKING_DIR}/resources/templates/国家管网/mengzhao/20200918/2.1001_HR_BI_B007SC--人员导入--关系_S_C_B007.xlsx'
    filename4 = f'{WORKING_DIR}/resources/templates/国家管网/mengzhao/20200918/4.9019_HR_BI_9019--人员导入--岗位分类信息-10010060.xlsx'
    filename6 = f'{WORKING_DIR}/resources/templates/国家管网/mengzhao/20200918/6.1001_HR_BI_B007S3--人员导入--创建关系_S_03_B007.xlsx'
    filename8 = f'{WORKING_DIR}/resources/templates/国家管网/mengzhao/20200918/8.1001_HR_BI_A003SO--人员导入--指定岗位的隶属机构.xlsx'
    lt = load_file(filename)
    job_ids = lt['AA'].values  # 岗位编号
    # 导出107（或者从本地文件加载）
    logging.info('导出组合逻辑查询107')
    with SapClose():
        lt_107_t60 = export_107_t60(None, job_ids, key_date)
    # lt_107_t60 = load_from_xlsx_file('x:/20200918-国家管网/107_T60.xlsx')
    lt1 = load_from_xlsx_file(filename1, skip_header=6)
    lt2 = load_from_xlsx_file(filename2, skip_header=6)
    lt4 = load_from_xlsx_file(filename4, skip_header=6)
    lt6 = load_from_xlsx_file(filename6, skip_header=6)
    lt8 = load_from_xlsx_file(filename8, skip_header=6)
    # 生成结果
    logging.info('生成结果文件1')
    update1(lt, lt_107_t60, lt1)
    logging.info('生成结果文件2')
    update2(lt, lt_107_t60, lt2)
    logging.info('生成结果文件4')
    update4(lt, lt_107_t60, lt4)
    logging.info('生成结果文件6')
    update6(lt, lt_107_t60, lt6)
    logging.info('生成结果文件8')
    update8(lt, lt_107_t60, lt8)
    # 保存结果
    logging.info('保存文件到结果目录')
    lt.filename = key_date + '_' + lt.filename
    lt.save_to(output_dir)
    lt_107_t60.filename = key_date + '_' + lt_107_t60.filename
    lt_107_t60.save_to(output_dir)
    lt1.filename = key_date + '_' + lt1.filename
    lt1.save_to(output_dir)
    lt2.filename = key_date + '_' + lt2.filename
    lt2.save_to(output_dir)
    lt4.filename = key_date + '_' + lt4.filename
    lt4.save_to(output_dir)
    lt6.filename = key_date + '_' + lt6.filename
    lt6.save_to(output_dir)
    lt8.filename = key_date + '_' + lt8.filename
    lt8.save_to(output_dir)
    logging.info(f'请打开文件夹【{output_dir}】查看结果文件')


if __name__ == '__main__':
    config('国家管网')
    logging.info('开始执行')
    key_date = '20200901'  # 关键日期
    filename = r"x:/销售华北人员信息.xlsx"  # 文件名
    main(filename, key_date)
    logging.info('结束执行')
