import datetime
import logging
from pathlib import Path

import rpa.config
from pandas import DataFrame
from rpa.config import WORKING_DIR
from rpa.fastrpa.adtable import AdTable, load_from_xlsx_file
from rpa.fastrpa.log import config
from rpa.fastrpa.obs.obs import OBS_REC
from rpa.fastrpa.sap.session import SapWithoutClose
from rpa.ssc.hr.sap.export_103_c20 import export_103_c20
from rpa.ssc.hr.sap.export_103_c20_1 import export_103_c20_1
from rpa.ssc.hr.sap.export_s_ahr_61016503 import export_s_ahr_6106503
from rpa.ssc.hr.sap.import_xlsx import import_multi, import_single
from rpa.ssc.sap.utils import init_sap_id


def update_1(lt_1: AdTable, df_lt_0: DataFrame, df_103_c20: DataFrame):
    for rn, idx in enumerate(df_lt_0.index, start=1):
        row = lt_1.add_row()
        row['A'].value = str(rn)  # 序列号
        job_id = df_lt_0['E'][idx].strip(' ').split(' ')[0]
        row['B'].value = init_sap_id(job_id)  # 岗位编码
        # row['C'].value = # 组织机构简称
        row['D'].value = df_lt_0['D'][idx]  # 开始日期
        row['E'].value = '99991231'  # 结束日期
        row['F'].value = df_lt_0['B'][idx]  # 人员编号


def update_2(lt_2: AdTable, df_lt_0: DataFrame, df_103_c20: DataFrame):
    for rn, idx in enumerate(df_lt_0.index, start=1):
        row = lt_2.add_row()
        row['A'].value = str(rn)  # 序列号
        row['B'].value = df_lt_0['B'][idx]  # 人员编号
        row['C'].value = df_lt_0['C'][idx]  # 人员姓名
        row['D'].value = '20201001'  # 岗位变化时间
        row['E'].value = '10 因公司代码调整的岗位变化'  # 岗位变化原因
        row['F'].value = df_lt_0['H'][idx]  # 人事范围
        row['G'].value = df_lt_0['I'][idx]  # 人事子范围
        row['H'].value = df_lt_0['F'][idx]  # 工资核算范围
        staff_id = df_lt_0['B'][idx]
        df_tmp = df_103_c20[df_103_c20['A'] == staff_id]
        if df_tmp.empty is False:
            row['I'].value = df_tmp['AM'].values[0] + ' ' + df_tmp['AN'].values[0]


def check_1(lt_1: AdTable, lt_s_ahr_6106503: AdTable) -> bool:
    df_1 = lt_1.to_dataframe()
    df_s_ahr_6106503 = lt_s_ahr_6106503.to_dataframe()
    is_check_passed = True
    for rn in df_1.index:
        staff_id = df_1['F'][rn]
        job_id = df_1['B'][rn]
        df_tmp = df_s_ahr_6106503[(df_s_ahr_6106503['G'] == staff_id) & (df_s_ahr_6106503['D'] == job_id)]
        if df_tmp.empty is True:
            is_check_passed = False
            lt_1['B'][rn].cmt('red', '模板1批导后人员编号与岗位编号未更新')
    return is_check_passed


def check_2(lt_2: AdTable, lt_103_c20_1: AdTable) -> bool:
    df_2 = lt_2.to_dataframe()
    df_103_c20_1 = lt_103_c20_1.to_dataframe()
    is_check_passed = True
    for rn in df_2.index:
        staff_id = df_2['B'][rn]
        df_tmp = df_103_c20_1[(df_103_c20_1['A'] == staff_id) & (df_103_c20_1['C'] == '2020.10.01')]
        if len(df_tmp) > 1:
            lt_2['A'][rn].cmt('blue', '一人多行103-C20-1')
        if df_tmp.empty is True:
            is_check_passed = False
            lt_2['B'][rn].cmt('red', '模板2批导后开始日期未更新')
        else:
            event_id = df_tmp['H'].values[0]
            event_text = df_tmp['I'].values[0]
            if event_id + ' ' + event_text != '10 因公司代码调整的岗位变化':
                is_check_passed = False
                lt_2['E'][rn].cmt('red', '模板2批导后事件原因未更新')
    return is_check_passed


def _import_file_1(filename: str) -> bool:
    return import_single('1001->HR_BI_A008', filename)


def _import_file_2(filename: str) -> bool:
    return import_multi('因公司代码调整的岗位变化', filename)


def main(filename: str, key_date: str):
    yyyymm = datetime.datetime.now().strftime(r'%Y%m')
    yyyymmdd = datetime.datetime.now().strftime(r'%Y%m%d')
    hhmmss = datetime.datetime.now().strftime(r'%H%M%S')
    output_dir = f'{rpa.config.D_RPA}/HR人事/国家管网/{yyyymm}/{yyyymmdd}/{hhmmss}_{Path(filename).name[:-5]}'
    Path(output_dir).mkdir(parents=True, exist_ok=True)
    filename1 = f'{WORKING_DIR}/resources/templates/国家管网/mengzhao/20200923/1001_HR_BI_A008--人员导入--指定岗位与人员的对应关系.xlsx'
    filename2 = f'{WORKING_DIR}/resources/templates/国家管网/mengzhao/20200923/ZBI0036-因公司代码调整的岗位变化.xlsx'
    logging.info('加载模板')
    lt_0 = load_from_xlsx_file(filename, skip_header=6)
    lt_0.del_blank_rows_by_column('C')
    lt_0['B'].apply(init_sap_id)
    lt_1 = load_from_xlsx_file(filename1, skip_header=6)
    lt_2 = load_from_xlsx_file(filename2, skip_header=6)
    lt_1.delete_all_contents()  # 清空模板
    lt_2.delete_all_contents()  # 清空模板
    logging.info('导出事前103')
    staff_ids = lt_0['B'].values  # 人员编号
    with SapWithoutClose() as session:
        lt_103_c20 = export_103_c20(session, staff_ids, key_date)
        lt_103_c20.filename = '103_C20_事前'
        lt_103_c20.save_to(output_dir)
    df_lt0 = lt_0.to_dataframe()
    df_103_c20 = lt_103_c20.to_dataframe()
    logging.info('生成结果文件')
    update_1(lt_1, df_lt0, df_103_c20)
    update_2(lt_2, df_lt0, df_103_c20)
    # 保存结果
    logging.info('保存文件到结果目录')
    lt_0.save_to(output_dir)
    filename1 = lt_1.save_to(output_dir)
    filename2 = lt_2.save_to(output_dir)

    logging.info('批导模板1')
    _import_file_1(filename1)
    with SapWithoutClose() as session:
        lt_103_c20_1_1 = export_103_c20_1(session, staff_ids, key_date)
        lt_103_c20_1_1.filename = '103_C20-1_模板1批导后'
        lt_103_c20_1_1.save_to(output_dir)
    lt_1 = load_from_xlsx_file(filename1, skip_header=6)
    logging.info('导出 S_AHR_61016503/人员配备情况 信息')
    org_ids = list(set(lt_103_c20_1_1['X'].values))
    lt_s_ahr_6106503 = export_s_ahr_6106503(org_ids, key_date)
    lt_s_ahr_6106503.save_to(output_dir)
    if check_1(lt_1, lt_s_ahr_6106503) is False:
        logging.error('模板1批导后校验未通过')
        lt_1.save_to(output_dir)
        logging.info(f'请打开文件夹【{output_dir}】查看结果文件')
        return False
    else:
        logging.info('模板1批导后校验通过')

    logging.info('批导模板2')
    _import_file_2(filename2)
    logging.info('导出103')
    with SapWithoutClose() as session:
        lt_103_c20_1_2 = export_103_c20_1(session, staff_ids, key_date)
        lt_103_c20_1_2.filename = '103_C20-1_模板2批导后'
        lt_103_c20_1_2.save_to(output_dir)
    lt_2 = load_from_xlsx_file(filename2, skip_header=6)
    if check_2(lt_2, lt_103_c20_1_2) is False:
        logging.error('模板2批导后校验未通过')
        lt_2.save_to(output_dir)
        logging.info(f'请打开文件夹【{output_dir}】查看结果文件')
        return False
    else:
        logging.info('模板2批导后校验通过')

    logging.info(f'请打开文件夹【{output_dir}】查看结果文件')
    return True


if __name__ == '__main__':
    config()
    key_date = '20201001'
    filename = "x:/20200925/3离退休人员-管道储运-20200924-2_from_958.xlsx"
    with OBS_REC(filename):
        main(filename, key_date)
