import datetime
import logging
import os
import re
import shutil
import time
from collections import defaultdict
from threading import Thread

import pyperclip
from openpyxl import load_workbook
from openpyxl.comments import Comment
from openpyxl.styles import PatternFill
from rpa.config import STAFF_NAME
from rpa.fastrpa.adtable import BLUE, RED, load_from_xlsx_file
from rpa.fastrpa.log import config
from rpa.fastrpa.mail import sendmail
from rpa.fastrpa.path import to_windows_path_format
from rpa.fastrpa.sap.session import attach_sap, close_sap
from rpa.fastrpa.utils.window import fill_upload_file_window
from rpa.fastrpa.xlsx import fix_excel
from rpa.public.config import FILE_PATH, remote_path, templates
from rpa.public.create_work_experience import new_work_experience_modify
from rpa.public.db import update_db
from rpa.public.event_public import (clear_all_colour_and_comment, send_email,
                                     update_database)
from rpa.public.myftp import MYFTP
from rpa.public.tools import cel, cells, click_continue, find_window, move_file
from rpa.ssc.hr.orm.orm import rpa_work_amount
from rpa.ssc.hr.orm.orm_ope import Query
from rpa.ssc.hr.orm.td_hr_gang_wei_diao_pei_rulebase import Event
from rpa.ssc.hr.rpa_dir import get_rpa_dir
from rpa.ssc.hr.sap.export_103 import export_103
from rpa.ssc.hr.sap.export_103_bk import export_103_bk
from rpa.ssc.hr.sap.export_1071 import export_1071
from rpa.ssc.hr.sap.export_1072 import export_1072
from rpa.ssc.sap.utils import init_sap_id
from rpa.ssc_kit.hr.kit_chai_dan.check_280 import check_zhrpy280


def post_change_pre_check(filename):
    logging.info("开始批导前校验...")
    wb = load_workbook(filename)
    ws = wb.active

    # 1.1.1.1	校验文件名格式
    li = os.path.basename(filename).split("-")
    # if len(li) < 4 or not (li[0].isdigit() or li[0] != "无单号") or len(li[1]) != 4 or li[2] != "岗位变动":  # 逻辑有问题，用以下逻辑替代
    if not (len(li) >= 4 and (li[0].isdigit() or li[0] == "无单号") and len(li[1]) == 4 or li[2] == "岗位变动"):
        cells(ws, "A7", "文件名称错误，应为:单号-人事范围代码-岗位变动-业务人员姓名或无单号-人事范围代码-岗位变动-业务人员姓名", RED)

    logging.info("提取校验过程中需要使用到的码值...")
    rule_s = [str(res.db_S).strip() for res in Query(Event) if res.db_S]  # 岗位变动事件原因
    rule_e = [str(res.db_E).strip() for res in Query(Event) if res.db_E]  # 人事子范围
    rule_ed = dict([(str(res.db_E).strip(), str(res.db_D).strip()) for res in Query(Event) if res.db_E])  # 人事范围&人事子范围
    rule_bd_ba = {res.db_BD: res.db_BA for res in Query(Event) if res.db_BD}  # 人事范围, 企业类型
    rule_l = [res.db_L for res in Query(Event) if res.db_L]  # 人员子组
    rule_j_k = {res.db_J: res.db_K for res in Query(Event) if res.db_J}  # 人员组、人员组涵盖的人员子组
    rule_u_v_w = {res.db_U: [res.db_V, res.db_W] for res in Query(Event) if res.db_U}  # 职位级别、职位序列、职位层次
    rule_y = [str(res.db_Y).strip() for res in Query(Event) if res.db_Y]  # 工作合同
    rule_r = [str(res.db_R).strip() for res in Query(Event) if res.db_R]  # 人员标识
    rule_f = {str(res.db_F).replace(" ", ""): str(res.db_F).strip() for res in Query(Event) if res.db_F}  # 企业自定义分类1
    rule_g = {str(res.db_G).replace(" ", ""): str(res.db_G).strip() for res in Query(Event) if res.db_G}  # 企业自定义分类2
    rule_h = {str(res.db_H).replace(" ", ""): str(res.db_H).strip() for res in Query(Event) if res.db_H}  # 企业自定义分类3

    # 1.1.1.3  导出组合逻辑查询1072
    lis = [cel(ws, f"E{x}") for x in range(7, len(ws["A"]) + 1) if cel(ws, f"E{x}")]
    lis1 = [cel(ws, f"B{x}") for x in range(7, len(ws["A"]) + 1) if cel(ws, f"B{x}")]
    date = [cel(ws, f"D{x}") for x in range(7, len(ws["A"]) + 1) if cel(ws, f"D{x}")][0]
    if not lis:
        return
    logging.info("提取校验所需要的103数据...")
    export_103_bk(None, lis1, date).save_to(FILE_PATH)
    shutil.move(FILE_PATH + "/模板_103.xlsx", FILE_PATH + "/事前备份_103.xlsx")
    file_103 = FILE_PATH + "/事前备份_103.xlsx"
    lt_103 = load_from_xlsx_file(file_103)
    df_103 = lt_103.to_dataframe()

    logging.info("提取校验所需要的1071数据...")
    export_1071(None, lis, date).save_to(FILE_PATH)
    shutil.move(FILE_PATH + "/模板_1071.xlsx", FILE_PATH + "/事前_1071.xlsx")
    wb_1071 = load_workbook(FILE_PATH + "/事前_1071.xlsx")
    ws_1071 = wb_1071.active
    dict_1071 = {cel(ws_1071, f"A{x}").lstrip("0"): [[cel(ws_1071, (x, y)) for y in range(1, 51)],
                                                     [cel(ws_1071, (x + 1, y)) for y in range(1, 51)]]
                 for x in range(1, len(ws_1071["A"]) + 1) if "S" in cel(ws_1071, f"B{x}")}

    logging.info("提取校验所需要的1072数据...")
    export_1072(None, lis, date).save_to(FILE_PATH)
    shutil.move(FILE_PATH + "/模板_1072.xlsx", FILE_PATH + "/事前_1072.xlsx")
    wb_1072 = load_workbook(FILE_PATH + "/事前_1072.xlsx")
    ws_1072 = wb_1072.active
    dict_1072 = {cel(ws_1072, f"A{x}").lstrip("0"): [[cel(ws_1072, (x, y)) for y in range(1, 41)],
                                                     [cel(ws_1072, (x + 1, y)) for y in range(1, 41)]]
                 for x in range(1, len(ws_1072["A"]) + 1) if "S" in cel(ws_1072, f"B{x}")}
    for i in range(7, len(ws["A"]) + 1):
        # 1.1.1.2  校验人员编号
        logging.info(f"开始校验第{i - 6}行数据...")
        ws[f"B{i}"] = "".join(re.findall(r"\d", str(ws[f"B{i}"].value)))
        ws[f"E{i}"] = "".join(re.findall(r"\d", str(ws[f"E{i}"].value)))
        if len(cel(ws, f"B{i}")) > 8:
            cells(ws, f"B{i}", "人员编号有误", RED)

        # 1.1.2.1  校验岗位编号
        if len(cel(ws, f"E{i}")) > 8:
            cells(ws, f"E{i}", "岗位编号有误", RED)

        # 1.1.2.2  校验岗位变动事件原因
        if str(ws[f"F{i}"].value).strip() not in rule_s:
            cells(ws, f"F{i}", "事件原因非码值", RED)

        # 1.1.2.3   校验人事子范围 & 人事范围
        if str(ws[f"G{i}"].value).strip() not in rule_e:
            cells(ws, f"G{i}", "人事子范围非码值", RED)
        else:
            staff_subrng = str(ws[f"G{i}"].value).strip()  # 人事子范围
            staff_rng = rule_ed[staff_subrng]
            if staff_rng not in li:
                cells(ws, f"G{i}", "人事范围与人事子范围不对应", RED)

        # 1.1.2.4  校验 H-人员组
        tmp_dict = {"W 合资公司合同制员工": ["A 原正式职工", "B 合同制员工"], "B 合同制员工": ["W 合资公司合同制员工"],
                    "C 派遣制员工": ["U 国内劳务派遣到海外人员"], "U 国内劳务派遣到海外人员": ["C 派遣制员工"]}
        # if len(li) > 2 and str(ws[f"AV{i}"].value).strip() != li[1]:      #20210608规则修改-常
        if cel(ws, f"H{i}") != cel(ws, f"AR{i}"):  # 当【岗位变动模板-【H-人员组】与【AR-调动前人员组】】不同时，执行下述规则：20210621更新规则
            if li[1] in rule_bd_ba.keys():
                if str(rule_bd_ba[li[1]]).strip() == "销售企业":
                    if '职业雇员' in cel(ws, f"H{i}") and cel(ws, f"H{i}") != cel(ws, f"AR{i}"):
                        cells(ws, f"H{i}", "人员组更变为H 职业雇员！", BLUE)
                    elif '职业雇员' not in cel(ws, f"H{i}") and cel(ws, f"H{i}") != cel(ws, f"AR{i}"):
                        cells(ws, f"H{i}", "人员组发生变化的情形不在规定范围内1！", RED)
                else:
                    if not (cel(ws, f"H{i}") in tmp_dict.keys() and cel(ws, f"AR{i}") in tmp_dict[cel(ws, f"H{i}")]):
                        cells(ws, f"H{i}", "人员组发生变化的情形不在规定范围内2!", RED)
                    if not ('职业雇员' in cel(ws, f"H{i}") and cel(ws, f"H{i}") != cel(ws, f"AR{i}")):
                        cells(ws, f"H{i}", "人员组发生变化的情形不在规定范围内2!", RED)

        # 1.1.2.5 20210623 add by mengzhao
        staff_id = init_sap_id(str(cel(ws, f"B{i}")))  # 人员编号
        df_tmp = df_103[df_103['A'] == staff_id]
        if df_tmp.empty is False:
            for _g in df_tmp['G'].values:
                if str(_g).strip() not in ['暂停/恢复发薪', '岗位变动', '']:
                    cells(ws, f"D{i}", "当月已有事件！", RED)  # 校验当月是否已有事件

        # 1.1.3.1  校验I-人员子组
        if str(ws[f"I{i}"].value).strip() not in rule_l:
            cells(ws, f"I{i}", "人员子组非码值", RED)

        # 1.1.3.2  校验I-人员子组与H-人员组的码值是否匹配
        if not (cel(ws, f"H{i}") in rule_j_k.keys() and cel(ws, f"I{i}")[:2] in rule_j_k[cel(ws, f"H{i}")]):
            cells(ws, f"H{i}", "人员组与人员子组不对应", RED)

        # 1.1.3.3  校验P-职位级别、N-职位序列、O-职位层次是否为码值
        if cel(ws, f"P{i}") in rule_u_v_w.keys():
            if cel(ws, f"N{i}") != rule_u_v_w[cel(ws, f"P{i}")][0]:
                cells(ws, f"N{i}", "职位序列有误", RED)
            if cel(ws, f"O{i}") != rule_u_v_w[cel(ws, f"P{i}")][1]:
                cells(ws, f"O{i}", "职位层次有误", RED)
        else:
            cells(ws, f"P{i}", "职位级别非码值", RED)

        # 1.1.3.4  校验人员子组与职位序列是否对应
        if cel(ws, f"I{i}") in rule_l[:5] and cel(ws, f"P{i}") in rule_u_v_w.keys():
            pass

        # 1.1.3.5  校验K-工作合同是否为码值
        if cel(ws, f"K{i}") and cel(ws, f"K{i}") not in rule_y:
            cells(ws, f"K{i}", "工作合同非码值", RED)

        # 1.1.3.6  校验M-企业统计标识是否为码值
        if cel(ws, f"M{i}") not in rule_r:
            cells(ws, f"M{i}", "企业统计标识非码值", RED)
        ws[f"M{i}"] = cel(ws, f"M{i}") if "是" in cel(ws, f"M{i}") else "  否"

        # 1.1.3.7  校验岗位编号是否为正确值
        if cel(ws, f"E{i}").lstrip("0") in dict_1072.keys():
            p_q = dict_1072[cel(ws, f"E{i}").lstrip("0")][0][15:17]
            o_pq = dict_1072[cel(ws, f"E{i}").lstrip("0")][1][15:17]
            if p_q[0] and p_q[1]:
                if (len(li) > 2 and p_q[0] != li[1]) or p_q[1] != cel(ws, f"G{i}")[:4]:
                    cells(ws, f"A{i}", "岗位财务科目设置有值，但其人事范围、人事子范围与模板信息不一致", RED)
            elif p_q[0] or p_q[1]:
                cells(ws, f"A{i}", "岗位财务科目设置有值，但人事范围、人事子范围信息不完整", RED)
            elif o_pq[0] and o_pq[1]:
                if (len(li) > 2 and o_pq[0] != li[1]) or o_pq[1] != cel(ws, f"G{i}")[:4]:
                    cells(ws, f"A{i}", "岗位所在机构的财务科目设置的人事范围、人事子范围与岗位变动模板不一致", RED)
            elif o_pq[0] or o_pq[1]:
                cells(ws, f"A{i}", "岗位所在机构的财务科目设置有值，但人事范围、人事子范围信息不完整", RED)
            else:
                cells(ws, f"A{i}", "岗位所在机构的财务科目设置的人事范围、人事子范围为空", BLUE)
        else:
            print(cel(ws, f"E{i}").lstrip("0"), dict_1072.keys())
            cells(ws, f"E{i}", "岗位编号有误", RED)

        # 1.1.3.8  校验岗位分类信息是否正确
        if cel(ws, f"E{i}").lstrip("0") in dict_1072.keys():
            s_ = dict_1072[cel(ws, f"E{i}").lstrip("0")][0]
            s_aa, s_w, s_ag, s_ah, s_y = s_[26] + " ", s_[22], s_[32], s_[33], s_[24]
            # print(s_aa[0], s_w ,s_ag ,s_ah)
            flag = False
            if s_aa[0] in ["1", "2"] and s_w and not s_ag and not s_ah:
                if s_w[:2] in ["20", "21", "22", "24", "43", "46"] and s_y == '':
                    flag = True
                elif s_w[:2] not in ["20", "21", "22", "24", "43", "46"] and s_y != '':
                    flag = True
            elif s_aa[0] in ["3", "4"] and s_ag != '' and s_ah != '' and s_w == '' and s_y == '':
                flag = True
            if flag is False:
                cells(ws, f"E{i}", "岗位分类信息有误", RED)
            # 1.1.3.9  校验薪酬标杆与职位序列是否对应
            dic = {"1": "1 管理序列", "2": "2 专业技术序列", "3": "3 技能操作序列", "4": "3 技能操作序列"}
            if not set({s_aa[0]: cel(ws, f"N{i}")}.items()).issubset(dic.items()):
                cells(ws, f"N{i}", "薪酬标杆与职位序列不对应", RED)

        # 1.1.3.10  校验兼任职位信息是否正确填写（20201015规则更新, update by mengzhao）
        _s_t_u = [bool(j.value) for j in ws["S%s:U%s" % (str(i), str(i))][0]]  # [Bool, Bool, Bool]
        _r = cel(ws, f"R{i}")
        if '是' in _r and all(_s_t_u) is True:
            pass
        elif ('否' in _r or _r == '') and all(_s_t_u) is False:
            pass
        else:
            cells(ws, "R%s" % str(i), "兼任职位信息不能为空！", RED)
        # if cel(ws, f"R{i}") or cel(ws, f"S{i}") or cel(ws, f"T{i}") or cel(ws, f"U{i}"):
        #     for x in ["R", "S", "T", "U"]:
        #         if not cel(ws, f"{x}{i}"):
        #             cells(ws, f"{x}{i}", "兼任职位信息不能为空！", RED)

        # 1.1.3.11  校验S,T,U是否是匹配数据
        if cel(ws, f"U{i}"):
            if cel(ws, f"U{i}") not in rule_u_v_w.keys():
                cells(ws, f"U{i}", "职位级别非码值!", RED)
            else:
                if cel(ws, f"S{i}") != rule_u_v_w[cel(ws, f"U{i}")][0]:
                    cells(ws, f"S{i}", "职位序列有误!", RED)
                if cel(ws, f"T{i}") != rule_u_v_w[cel(ws, f"U{i}")][1]:
                    cells(ws, f"T{i}", "职位层次有误!", RED)

        # 1.1.3.12  校验S,N数据是否冲突
        if cel(ws, f"S{i}") and cel(ws, f"S{i}") == cel(ws, f"N{i}"):
            cells(ws, f"U{i}", "兼任职位不能与主要职位处于同一序列！", RED)
        elif cel(ws, f"S{i}") == "1 管理序列":
            cells(ws, f"U{i}", "兼任职位序列不能为管理序列，管理序列必为主要职位序列！", RED)

        # 1.1.3.13  校验X-班组长标识是否正确
        if cel(ws, f"E{i}") in dict_1072.keys():
            if dict_1072[cel(ws, f"E{i}")][0][38] == "是":
                ws[f"AL{i}"] = "X"
            else:
                ws[f"AL{i}"] = ""

        # 1.1.3.14 检验【岗位变动模板-【I-人员子组】】的值是否为【调配码表库-【L9】】，若是，见1；若不是，见2。
        # 1.在【岗位变动模板-【I-人员子组】】单元格填充红色并插入批注“人员子组有误”，继续检验下一人员。
        # 2.为“相同”，继续比较下一人员。
        # 20210624 add by mengzhao
        if cel(ws, f"I{i}") == '22 其他不在岗人员' or '其他不在岗人员' in cel(ws, f"I{i}"):
            cells(ws, f"I{i}", "人员子组有误", RED)

        # 1.1.4.1, 1.1.5.1, 1.1.6.1  校验L、AM、AN-企业自定义员工分类是否为码值
        for k, v in {"L": rule_f, "AM": rule_g, "AN": rule_h}.items():
            if cel(ws, f"{k}{i}") in ["", "清空"]:
                ws[f"{k}{i}"] = ""
            elif cel(ws, f"{k}{i}").replace(" ", "") in v.keys():
                ws[f"{k}{i}"] = v[cel(ws, f"{k}{i}").replace(" ", "")]
            else:
                cells(ws, f"L{i}", "企业自定义分类非码值", RED)

        # 1.1.12  校验Q-职位名称是否超长
        ws[f"Q{i}"] = cel(ws, f"Q{i}")
        if len(cel(ws, f"Q{i}")) > 20:
            cells(ws, f"Q{i}", "职位名称超长", RED)

        # 1.1.13  岗位分类序列与薪酬标杆是否对应
        if cel(ws, f"E{i}").lstrip("0") in dict_1071.keys():
            v_p, v_z = dict_1071[cel(ws, f"E{i}").lstrip("0")][0][15], dict_1071[cel(ws, f"E{i}").lstrip("0")][0][25]
            if dict_1071[cel(ws, f"E{i}").lstrip("0")][0][10]:
                if not (v_p[:1] == v_z[:1] or (v_p[:1] == "3" and v_z[:1] == "4")):
                    cells(ws, f"E{i}", "岗位分类序列与薪酬标杆不对应", RED)
            else:
                cells(ws, f"E{i}", "没有分配岗位类别", RED)

        # 1.1.14  校验V-聘任文号是否超长
        ws[f"V{i}"] = cel(ws, f"V{i}")
        if len(cel(ws, f"V{i}")) > 40:
            cells(ws, f"V{i}", "聘任文号超长", RED)

    logging.info("岗位变动批导前校验完成...")
    wb.save(filename)


# 规则1.1.5 至 1.1.10：校验 AM & AN & AO & D & AR & AS 列的值
def check_am_an_ao(file):
    """
        检验【岗位变动模板-【AM】】是否为空值，若是空值，跳转下一人继续执行，若不是空值，检验其值是否为“清空”，
    若是，保留其值并跳转下一人继续执行；若不是，检验其值是否为【码表库-【G-企业自定义分类2】】的值。
        检验【岗位变动模板-【AN】】是否为空值，若是空值，跳转下一人继续执行，若不是空值，检验其值是否为“清空”，
    若是，保留其值并跳转下一人继续执行；若不是，检验其值是否为【码表库-【H-企业自定义分类3】】的值。
        检验【岗位变动模板-【AO】】的值是否为符合常识的日期（8位数字）。
    :return:
    """

    rule_list = [[], [], []]
    for res in Query(table=Event):
        if res.db_G:
            rule_list[0].append(res.db_G.replace(' ', ''))
        if res.db_H:
            rule_list[1].append(res.db_H.replace(' ', ''))

    wb = load_workbook(file)
    ws = wb.active
    flag = ''
    db_j = [res.db_J.replace(' ', '') for res in Query(table=Event) if res.db_J]
    db_e = [res.db_E.replace(' ', '') for res in Query(table=Event) if res.db_E]
    for i in range(7, len(ws["A"]) + 1):
        if ws["AM%s" % str(i)].value and ws["AM%s" % str(i)].value.replace(' ', '') != "清空" and ws[
                "AM%s" % str(i)].value.replace(' ', '') not in rule_list[0]:
            cells(ws, "AM%s" % str(i), "企业自定义分类2非码值", RED)
        if ws["AN%s" % str(i)].value and ws["AN%s" % str(i)].value.replace(' ', '') != "清空" and ws[
                "AN%s" % str(i)].value.replace(' ', '') not in rule_list[1]:
            cells(ws, "AN%s" % str(i), "企业自定义分类3非码值", RED)
        try:
            time.strptime(str(ws["AO%s" % str(i)].value), '%Y%m%d')
        except Exception:
            cells(ws, "AO%s" % str(i), "开始日期非正确值", RED)  # 1.1.7
        try:
            time.strptime(str(ws["D%s" % str(i)].value), '%Y%m%d')
            if flag == '' and str(ws["D%s" % str(i)].value)[-2:] == '01':
                flag = str(ws["D%s" % str(i)].value)
            elif str(ws["D%s" % str(i)].value) != flag:
                ws["D%s" % str(i)].fill = PatternFill("solid", RED)
                ws["D%s" % str(i)].comment = Comment("岗位变动日期非正确值", "robotB")  # 1.1.8
        except Exception:
            ws["D%s" % str(i)].fill = PatternFill("solid", RED)
            ws["D%s" % str(i)].comment = Comment("岗位变动日期非正确值", "robotB")
        if ws["AR%s" % str(i)].value and ws["AR%s" % str(i)].value.replace(' ', '') not in db_j:
            ws["AR%s" % str(i)].fill = PatternFill("solid", RED)
            ws["AR%s" % str(i)].comment = Comment("人员组非码值", "robotB")  # 1.1.9
        if ws["AS%s" % str(i)].value and ws["AS%s" % str(i)].value.replace(' ', '') not in db_e:
            ws["AS%s" % str(i)].fill = PatternFill("solid", RED)
            ws["AS%s" % str(i)].comment = Comment("人事子范围非码值", "robotB")  # 1.1.10
    wb.save(file)


# 规则1.2.1：zhrbi0013批导模板表
def batch_import(count, file) -> bool:
    from rpa.ssc.hr.sap.refresh_user_data import refresh_user_data
    wb = load_workbook(file)
    ws = wb.active
    job_ids = [cel(ws, f"E{x}") for x in range(7, len(ws["A"]) + 1) if cel(ws, f"E{x}")]
    key_date = [cel(ws, f"D{x}") for x in range(7, len(ws["A"]) + 1) if cel(ws, f"D{x}")][0]
    refresh_user_data(job_ids=job_ids, key_date=key_date)  # 结构化刷新
    session = attach_sap("login_tx")
    logging.info("开始批导岗位变动模板表")
    session.findById("wnd[0]/tbar[0]/okcd").text = "/n zhrbi0013"
    session.findById("wnd[0]").sendVKey(0)
    session.findById("wnd[0]/usr/radRB_M").setFocus()
    session.findById("wnd[0]/usr/radRB_M").select()
    session.findById("wnd[0]/usr/radRB_M_ZI").setFocus()
    session.findById("wnd[0]/usr/radRB_M_ZI").select()
    session.findById("wnd[0]/tbar[1]/btn[8]").press()
    session.findById("wnd[0]/usr/ctxtP_WERKS").text = os.path.basename(file).split("-")[1]
    session.findById("wnd[0]/usr/radRB_UP").setFocus()
    session.findById("wnd[0]/usr/radRB_UP").select()
    fix_excel(file)
    t = Thread(target=fill_upload_file_window, args=(file, '#32770', u'选择上传文件'))
    t.setDaemon(True)
    t.start()
    session.findById("wnd[0]/tbar[1]/btn[8]").press()
    panetext = session.findById("wnd[0]/sbar/pane[0]").text
    logging.info(f"panetext: {panetext}")
    if "上载的模板中没有数据或数据错误" in session.findById("wnd[0]/sbar/pane[0]").text:
        if 10 < count:
            dir_path = get_rpa_dir('岗位变动', os.path.basename(file), False)
            with MYFTP() as my_ftp:
                hhmmss = datetime.datetime.now().strftime(r'%H%M%S')  # 上传的目录前面加时分秒前缀，避免同一天一个单子，第二次做覆盖上一次的文件
                remote = remote_path + f"失败/{hhmmss}_" + file.split('\\')[-1].split(".")[0] + "/"
                my_ftp.upload_file(file, remote + file.split('\\')[-1].split(".")[0] + "_模板错误.xlsx")
                for _file in os.listdir(FILE_PATH):
                    my_ftp.upload_file(os.path.join(FILE_PATH, _file), f'{remote}/{_file}')
                    shutil.copyfile(os.path.join(FILE_PATH, _file), f'{dir_path}/{_file}')
            shutil.copyfile(file, f"{dir_path}/{os.path.basename(file)}")
            if os.path.exists(FILE_PATH + "/模板_103.xlsx"):
                shutil.copyfile(FILE_PATH + "/模板_103.xlsx", f"{dir_path}/103.xlsx")
            session.findById("wnd[0]/tbar[0]/okcd").text = "/nex"
            session.findById("wnd[0]").sendVKey(0)
            return True
        count += 1
        time.sleep(10)
        return batch_import(count, file)  # 失败重试
    try:
        tb = session.findById("wnd[1]/usr/cntlG_GRID/shellcont/shell")
        wb = load_workbook(file)
        ws = wb.active
        for i in range(tb.rowCount):
            cells(ws, f"A{int(tb.getCellValue(i, 'ZZ_XH')) + 6}",
                  f'{tb.getCellValue(i, "FIELD")}:{tb.getCellValue(i, "MSG")}', RED)
        wb.save(file)
    except Exception:  # nosec
        pass  # SAP情形不存在，跳过执行
    try:
        result = session.findById("wnd[1]/usr/txtSPOP-TEXTLINE2").text
        session.findById("wnd[1]/usr/btnSPOP-OPTION1").press()
    except Exception as e:
        result = f'{session.findById("wnd[0]/sbar/pane[0]").text}\n\n\n{e}'
    close_sap()
    if "失败0" not in result:
        with MYFTP() as my_ftp:
            hhmmss = datetime.datetime.now().strftime(r'%H%M%S')  # 上传的目录前面加时分秒前缀，避免同一天一个单子，第二次做覆盖上一次的文件
            remote = remote_path + f"失败/{hhmmss}_" + file.split('\\')[-1].split(".")[0] + "/"
            my_ftp.upload_file(file, remote + file.split('\\')[-1].split(".")[0] + "_批导失败.xlsx")
            for _file in os.listdir(FILE_PATH):
                my_ftp.upload_file(os.path.join(FILE_PATH, _file), f'{remote}/{_file}')
        dir_path = get_rpa_dir('岗位变动', os.path.basename(file), False)
        shutil.copyfile(file, f"{dir_path}/{os.path.basename(file)}")
        if os.path.exists(FILE_PATH + "/模板_103.xlsx"):
            shutil.copyfile(FILE_PATH + "/模板_103.xlsx", f"{dir_path}/103.xlsx")
        sendmail(receivers='6886908@qq.com', subject="模板表《" + file.split('\\')[-1] + "》批导失败，请检查。", body=result)
        update_database(file, f"批导结束，{result}")
        logging.info(result)
        logging.error('zhrbi0013批导模板表批导失败, 程序结束运行')
        return False
    return True


# 规则1.3.1: 批导成功，导出组合逻辑查询103
def export_combinational_logic_queries_103(filename):
    wb = load_workbook(filename)
    ws = wb.active

    date_time, li = '', []
    for x in range(7, len(list(ws["B"])) + 1):
        date_time = str(ws["D%s" % str(x)].value) if not date_time and str(ws["D%s" % str(x)].value) else date_time
        li.append(str(ws["B%s" % str(x)].value).split('.')[0].replace(" ", ''))
    export_103(None, li, date_time).save_to(FILE_PATH)


# 规则2.1.6 & 2.1.7  检验12、13、15类人员是否需要定界“从事职业工种信息” & 检验工资总额控制范围
def check_batch_result(file):
    wb_103 = load_workbook(FILE_PATH + "/模板_103.xlsx")
    ws_103 = wb_103.active
    flag, tmp_dict = False, defaultdict(str)
    for i in range(2, len(list(ws_103["G"])) + 1):
        tmp_dict[cel(ws_103, f'A{i}').lstrip('0')] = cel(ws_103, f'W{i}')  # 记录事件后的组织机构名称
        if not ws_103["G%s" % str(i)].value:
            cells(ws_103, "G%s" % str(i), "岗位变动模板批导不成功", RED)
            flag = True
    wb_103.save(FILE_PATH + "/模板_103.xlsx")
    logging.info('正在将调动后机构的规范名称写入模板...')
    wb = load_workbook(file)
    ws = wb.active
    for i in range(7, len(ws['B']) + 1):
        key = cel(ws, f'B{i}').lstrip('0')
        if key and key in tmp_dict:
            ws[f'AP{i}'] = tmp_dict[key]
    wb.save(file)
    wb.close()
    if flag:
        with MYFTP() as my_ftp:
            hhmmss = datetime.datetime.now().strftime(r'%H%M%S')  # 上传的目录前面加时分秒前缀，避免同一天一个单子，第二次做覆盖上一次的文件
            remote = remote_path + f"失败/{hhmmss}_" + file.split('\\')[-1].split(".")[0] + "/"
            my_ftp.upload_file(file, remote + file.split('\\')[-1])
            my_ftp.upload_file(FILE_PATH + "/模板_103.xlsx", remote + "103.xlsx")
            for _file in os.listdir(FILE_PATH):
                my_ftp.upload_file(os.path.join(FILE_PATH, _file), f'{remote}/{_file}')
        dir_path = get_rpa_dir('岗位变动', os.path.basename(file), False)
        shutil.copyfile(file, f"{dir_path}/{os.path.basename(file)}")
        shutil.copyfile(FILE_PATH + "/模板_103.xlsx", f"{dir_path}/103.xlsx")
        logging.info(f"岗位变动模板批导失败，失败原因请查看文件【{FILE_PATH}/模板_103.xlsx】")
        return True


# 规则1.4.1 & 1.4.2:生成“新增工作经历”模板
def create_add_work_experience_template(filename):
    """
        先拷贝【岗位变动模板-【B-人员编号】【C-人员姓名】【AO】【AP】【AQ】】的值粘贴进【新增工作经历-【B-人员编号】【C-人员姓
    名】【D-开始日期】【F-所在单位及部门名称】【G-从事工作及担任职务】】中，【新增工作经历-【E-结束日期】】的码值始终为【999912
    31】，再检查【新增工作经历-【D-开始日期】】为空的值，将【岗位变动模板-【D-岗位变动日期】】粘贴至其中，自动生成序号。
    :return:
    """
    replace_dict = defaultdict(str)
    for res in Query(table=Event):
        if res.db_AP:
            replace_dict[res.db_AP] = res.db_AQ

    tmwb = load_workbook(os.path.join(templates, "模板_0023_HR_BI_0023_工作经历.xlsx"))
    tmws = tmwb.get_sheet_by_name("0023_工作经历")
    mbwb = load_workbook(filename)
    mbws = mbwb.active
    tmp103_wb = load_workbook(FILE_PATH + "/模板_103.xlsx")
    tmp103_ws = tmp103_wb.active
    a = defaultdict(str)
    for i in range(1, len(list(tmp103_ws["A"])) + 1):
        text = tmp103_ws["W%s" % str(i)].value
        c = list(replace_dict.keys())
        c.sort(key=lambda x: len(x), reverse=True)
        for key in c:
            if key and key in text and replace_dict[key]:
                text = text.replace(key, replace_dict[key].replace("替换为空", ""))
        a[tmp103_ws["A%s" % str(i)].value.lstrip('0')] = text

    start_row = len(list(tmws.rows)) + 1
    end_row = len(list(mbws.rows)) + 1
    for i in range(start_row, end_row):
        tmws["A%s" % str(i)] = str(i - start_row + 1)
        tmws["B%s" % str(i)] = mbws["B%s" % str(i)].value
        tmws["C%s" % str(i)] = mbws["C%s" % str(i)].value
        if mbws["AO%s" % str(i)].value:
            tmws["D%s" % str(i)] = mbws["AO%s" % str(i)].value
        else:
            tmws["D%s" % str(i)] = mbws["D%s" % str(i)].value
        tmws["E%s" % str(i)] = "99991231"
        tmws["F%s" % str(i)] = a[str(mbws["B%s" % str(i)].value).lstrip('0')]
        tmws["G%s" % str(i)] = mbws["AQ%s" % str(i)].value
    tmwb.save(os.path.join(FILE_PATH, "tmp-新增工作经历.xlsx"))
    update_database(filename, "生成工作经历模板")


# 规则1.4.3:生成“新增从事职业工种信息”模板
def create_adding_information_on_job_types_template(filename):  # 1.4.3.1
    """
        提取【岗位变动模板-【I-人员子组】】的值为【码表库-【L6】】或【码表库-【L7】】的人员，将其【岗位变动模板-【B-人员编号】
    【C-人员姓名】【D-开始日期】】的值粘贴进分别粘贴进【新增从事职业工种信息-【B-人员编号】【C-人员姓名】【D-开始日期】】中，
    【新增从事职业工种信息-【结束日期】】的码值始终为【99991231】，【新增从事职业工种信息-【职业技能鉴定范围标识】】的码值始终
    为【X】，自动生成序号。
    :return:
    """
    tmwb = load_workbook(os.path.join(templates, "模板_9243_HR_BI_9243-从事职业（工种）情况.xlsx"))
    tmws = tmwb.get_sheet_by_name("9243_从事职业（工种）情况")
    mbwb = load_workbook(filename)
    mbws = mbwb.active

    start_row = len(list(tmws.rows)) + 1
    end_row = len(list(mbws.rows)) + 1
    row_count = start_row
    li = os.path.basename(filename).split("-")
    for i in range(start_row, end_row):
        if mbws[f"N{i}"].value.replace(' ', '') == '3技能操作序列':
            tmws["A%s" % str(row_count)] = str(row_count - start_row + 1)
            tmws["B%s" % str(row_count)] = mbws["B%s" % str(i)].value
            tmws["C%s" % str(row_count)] = mbws["C%s" % str(i)].value
            tmws["D%s" % str(row_count)] = mbws["D%s" % str(i)].value
            if len(li) > 2 and li[1] == "1680" and 'X' in cel(mbws, f'AL{i}'):  # 1680高桥石化模板AL列有毒有害标识(X手工填写)
                tmws["E%s" % str(row_count)] = "99991230"
            else:
                tmws["E%s" % str(row_count)] = "99991231"
            tmws["F%s" % str(row_count)] = "X"
            row_count += 1
    tmwb.save(os.path.join(FILE_PATH, "tmp-新增从事职业工种信息.xlsx"))
    update_database(filename, "生成从事职业工种模板")


# 规则1.4.4  批导工作经历和从事职业工种信息表
def batch_import_tow_excel(file):
    session = attach_sap("login_tx")
    logging.info("开始批导新增从事职业工种信息表")
    session.findById("wnd[0]").maximize()
    for i in [  # ["0023->HR_BI_0023", os.path.join(file_path, "tmp-新增工作经历.xlsx")],
            ["9243->HR_BI_9243", os.path.join(FILE_PATH, "tmp-新增从事职业工种信息.xlsx")]]:
        logging.info(f"开始批导模板：{os.path.basename(i[1])}")
        if not os.path.exists(i[1]):
            logging.info(f"    模板不存在：{i[1]}")
            continue
        wb = load_workbook(i[1])
        ws = wb.active
        if len(ws["A"]) == 6:
            continue
        for _ in range(10):
            session.findById("wnd[0]/tbar[0]/okcd").text = "/n zhrbi0013"
            session.findById("wnd[0]").sendVKey(0)
            session.findById("wnd[0]/tbar[1]/btn[8]").press()
            session.findById("wnd[0]/usr/ctxtP_SRTFD").text = i[0]
            session.findById("wnd[0]/usr/radRB_UP").setFocus()
            session.findById("wnd[0]/usr/radRB_UP").select()
            try:
                session.findById("wnd[1]/usr/btnSPOP-OPTION1").press()
            except Exception:  # nosec
                pass
            # fix_excel(os.path.abspath(i[1]))
            t = Thread(target=click_continue)
            t.setDaemon(True)
            t.start()
            t1 = Thread(target=find_window, args=(os.path.abspath(i[1]), None, u'选择上传文件'))
            t1.setDaemon(True)
            t1.start()
            session.findById("wnd[0]/tbar[1]/btn[8]").press()
            if session.findById("wnd[0]/sbar/pane[0]").text == "记录已创建":
                result = session.findById("wnd[1]/usr/txtSPOP-TEXTLINE2").text
                logging.info(f"批导结果: {result}")
                session.findById("wnd[1]/usr/btnSPOP-OPTION1").press()
                if "失败0" not in result:
                    with MYFTP() as my_ftp:
                        hhmmss = datetime.datetime.now().strftime(r'%H%M%S')  # 上传的目录前面加时分秒前缀，避免同一天一个单子，第二次做覆盖上一次的文件
                        remote = remote_path + f"失败/{hhmmss}_" + file.split('\\')[-1].split(".")[0] + "/"
                        my_ftp.upload_file(file, remote + file.split('\\')[-1])
                        my_ftp.upload_file(i[1], remote + i[1].split("tmp-")[1][0:-5] + "_批导失败.xlsx")
                        my_ftp.upload_file(FILE_PATH + "/模板_103.xlsx", remote + "103.xlsx")
                        for _file in os.listdir(FILE_PATH):
                            my_ftp.upload_file(os.path.join(FILE_PATH, _file), f'{remote}/{_file}')
                    dir_path = get_rpa_dir('岗位变动', os.path.basename(i[1]), False)
                    shutil.copyfile(i[1], f"{dir_path}/{os.path.basename(i[1]).strip('tmp-')}")
                    shutil.copyfile(file, f"{dir_path}/{os.path.basename(file)}")
                    shutil.copyfile(FILE_PATH + "/模板_103.xlsx", f"{dir_path}/103.xlsx")
                    session.findById("wnd[0]/tbar[0]/okcd").text = "/nex"
                    session.findById("wnd[0]").sendVKey(0)
                    raise Exception(f'模板表《{i[1]}》批导失败')
                break
            elif session.findById("wnd[0]/sbar/pane[0]").text in ["没有需要处理的数据或数据错误", "文件不符合要求"]:
                logging.info(session.findById("wnd[0]/sbar/pane[0]").text)
                logging.info("等待10秒后重新批导")
                time.sleep(10)
                continue
            else:
                logging.info(session.findById("wnd[0]/sbar/pane[0]").text)
                break
        else:
            with MYFTP() as my_ftp:
                hhmmss = datetime.datetime.now().strftime(r'%H%M%S')  # 上传的目录前面加时分秒前缀，避免同一天一个单子，第二次做覆盖上一次的文件
                remote = remote_path + f"失败/{hhmmss}_" + file.split('\\')[-1].split(".")[0] + "/"
                my_ftp.upload_file(i[1], remote + i[1].split("tmp-")[1][0:-5] + "_批导模板错误.xlsx")
                for _file in os.listdir(FILE_PATH):
                    my_ftp.upload_file(os.path.join(FILE_PATH, _file), f'{remote}/{_file}')
            dir_path = get_rpa_dir('岗位变动', os.path.basename(i[1]), False)
            shutil.copyfile(i[1], f"{dir_path}/{os.path.basename(i[1])}")
    session.findById("wnd[0]/tbar[0]/okcd").text = "/nex"
    session.findById("wnd[0]").sendVKey(0)
    update_database(file, "批导两个模板")


# 规则2.1.1 & 2.1.2  修改本次岗位变动的企业自定义分类2 & 修改本次岗位变动的企业自定义分类3
def modification_enterprise_custom_classification_two_and_three(file):
    wb = load_workbook(file)
    ws = wb.active
    session = attach_sap("login_tx")
    logging.info("修改岗位变动的企业自定义分类2和3")

    for i in range(7, len(list(ws["AM"])) + 1):
        if (ws["AM%s" % str(i)].comment is None and ws["AM%s" % str(i)].value is not None) or \
                (ws["AN%s" % str(i)].comment is None and ws["AN%s" % str(i)].value is not None):
            session.findById("wnd[0]/tbar[0]/okcd").text = "/N PA30"
            session.findById("wnd[0]").sendVKey(0)
            session.findById("wnd[0]/shellcont/shell/shellcont[0]/shell/shellcont[1]/shell[1]").topNode = "          1"
            session.findById("wnd[0]/usr/ctxtRP50G-PERNR").text = cel(ws, f"B{i}")
            session.findById("wnd[0]/usr/tabsMENU_TABSTRIP/tabpTAB03").select()
            session.findById(
                "wnd[0]/usr/tabsMENU_TABSTRIP/tabpTAB03/ssubSUBSCR_MENU:SAPMP50A:0400/subSUBSCR_ITMENU:SAPMP50A:0310/tblSAPMP50ATC_MENU").getAbsoluteRow(
                0).selected = -1
            session.findById("wnd[0]/tbar[1]/btn[20]").press()
            session.findById("wnd[0]/usr/tblMP000100TC3000").getAbsoluteRow(0).selected = -1
            session.findById("wnd[0]/usr/tblMP000100TC3000/txtP0001-BEGDA[0,0]").setFocus()
            session.findById("wnd[0]/usr/tblMP000100TC3000/txtP0001-BEGDA[0,0]").caretPosition = 0
            session.findById("wnd[0]/tbar[1]/btn[6]").press()
            if ws["AM%s" % str(i)].comment is None and ws["AM%s" % str(i)].value is not None and \
                    str(ws["AM%s" % str(i)].value).replace(' ', '') == "清空":
                session.findById("wnd[0]/usr/subSUBSCREEN_T582C:ZP000100:0200/ctxtP0001-ZZ_QYZDYYGFL1").text = ""
            elif ws["AM%s" % str(i)].comment is None and ws["AM%s" % str(i)].value is not None:
                session.findById("wnd[0]/usr/subSUBSCREEN_T582C:ZP000100:0200/ctxtP0001-ZZ_QYZDYYGFL1").text = \
                    str(ws["AM%s" % str(i)].value).split()[0]

            if ws["AN%s" % str(i)].comment is None and ws["AN%s" % str(i)].value is not None and \
                    str(ws["AN%s" % str(i)].value).replace(' ', '') == "清空":
                session.findById("wnd[0]/usr/subSUBSCREEN_T582C:ZP000100:0200/ctxtP0001-ZZ_QYZDYYGFL2").text = ""
            elif ws["AN%s" % str(i)].comment is None and ws["AN%s" % str(i)].value is not None:
                session.findById("wnd[0]/usr/subSUBSCREEN_T582C:ZP000100:0200/ctxtP0001-ZZ_QYZDYYGFL2").text = \
                    str(ws["AN%s" % str(i)].value).split()[0]
            session.findById("wnd[0]/tbar[0]/btn[11]").press()
            session.findById("wnd[0]/tbar[0]/btn[11]").press()
    session.findById("wnd[0]/tbar[0]/okcd").text = "/nex"
    session.findById("wnd[0]").sendVKey(0)


# 规则2.1.3 & 2.1.4 & 2.1.5  重新带出从事职业工种信息 & 最高等级工种鉴定标识 & 生成简历
def work_types_identification(file):
    wb = load_workbook(file)
    ws = wb.active

    session = attach_sap("login_tx")
    logging.info("重新带出从事职业工种信息 & 最高等级工种鉴定标识 & 生成简历")
    text = ''
    for x in range(7, len(list(ws["B"])) + 1):
        text = text + str(ws["B%s" % str(x)].value).split('.')[0].replace(" ", '') + '\r\n'
    pyperclip.copy(text)
    session.findById("wnd[0]/tbar[0]/okcd").text = "/n zhrconv073"
    session.findById("wnd[0]").sendVKey(0)
    session.findById("wnd[0]/usr/cmbPNPTIMED").key = "I"  # 其他期间
    session.findById("wnd[0]/usr/ctxtPNPBEGDA").text = datetime.datetime.now().strftime(r'%Y%m%d')  # 事件执行日期
    session.findById("wnd[0]/usr/ctxtPNPENDDA").text = "99991231"
    session.findById("wnd[0]/usr/btn%_PNPPERNR_%_APP_%-VALU_PUSH").press()
    session.findById("wnd[1]/tbar[0]/btn[16]").press()
    session.findById("wnd[1]/tbar[0]/btn[24]").press()
    session.findById("wnd[1]/tbar[0]/btn[8]").press()
    session.findById("wnd[0]/tbar[1]/btn[8]").press()  # 确认
    info_wb = load_workbook(os.path.join(FILE_PATH, "tmp-新增从事职业工种信息.xlsx"))
    info_ws = info_wb.active
    for x in range(7, len(list(info_ws["B"])) + 1):
        session.findById("wnd[0]/tbar[0]/okcd").text = "/n PA30"
        session.findById("wnd[0]").sendVKey(0)
        session.findById("wnd[0]/shellcont/shell/shellcont[0]/shell/shellcont[1]/shell[1]").topNode = "          1"
        session.findById("wnd[0]/usr/ctxtRP50G-PERNR").text = info_ws["B%s" % str(x)].value
        session.findById("wnd[0]/usr/ctxtRP50G-PERNR").caretPosition = 7
        session.findById("wnd[0]").sendVKey(0)
        session.findById("wnd[0]/usr/tabsMENU_TABSTRIP/tabpTAB03").select()
        session.findById(
            "wnd[0]/usr/tabsMENU_TABSTRIP/tabpTAB03/ssubSUBSCR_MENU:SAPMP50A:0400/subSUBSCR_ITMENU:SAPMP50A:0310/tblSAPMP50ATC_MENU").getAbsoluteRow(
            2).selected = -1
        session.findById("wnd[0]/tbar[1]/btn[20]").press()
        session.findById("wnd[0]/usr/tblMP924300TC3000").getAbsoluteRow(0).selected = -1
        session.findById("wnd[0]/usr/tblMP924300TC3000/txtP9243-BEGDA[0,0]").setFocus()
        session.findById("wnd[0]/usr/tblMP924300TC3000/txtP9243-BEGDA[0,0]").caretPosition = 0
        session.findById("wnd[0]/tbar[1]/btn[6]").press()
        session.findById("wnd[0]").sendVKey(0)
        session.findById("wnd[0]").sendVKey(0)
        session.findById("wnd[0]/tbar[0]/btn[11]").press()


def create_experience(file):
    wb = load_workbook(file)
    ws = wb.active

    # logging.info("重新带出从事职业工种信息 & 最高等级工种鉴定标识 & 生成简历")
    # staff_ids = [cel(ws, f"B{x}") for x in range(7, len(list(ws["B"])) + 1)]
    # key_date, area_codes = cel(ws, "D7"), [os.path.basename(file).split("-")[1]]
    # _, file_before, file_after = download_work_experience_template(staff_ids, key_date, area_codes)
    # shutil.move(file_before, f"{FILE_PATH}/{os.path.basename(file_before)}")
    # shutil.move(file_after, f"{FILE_PATH}/{os.path.basename(file_after)}")
    ep_dict = defaultdict(list)
    logging.info("正在修改生成简历信息...")
    for i in range(7, len(ws['B']) + 1):
        key = cel(ws, f'B{i}').lstrip('0')
        if key:
            ep_dict[key] = [cel(ws, f'{x}{i}') for x in ['AO', 'AP', 'AQ']]
    wb.close()
    new_work_experience_modify(ep_dict)
    update_database(file, "生成简历")
    rpa_work_amount(list(ep_dict.keys()))


def check_payroll_control_range(session, code, control_range):
    session.findById("wnd[0]/tbar[0]/okcd").text = "/n PA30"
    session.findById("wnd[0]").sendVKey(0)
    session.findById(
        "wnd[0]/shellcont/shell/shellcont[0]/shell/shellcont[1]/shell[1]").topNode = "          1"
    session.findById("wnd[0]/usr/ctxtRP50G-PERNR").text = code
    session.findById("wnd[0]/usr/ctxtRP50G-PERNR").caretPosition = 7
    session.findById("wnd[0]").sendVKey(0)
    session.findById("wnd[0]/usr/tabsMENU_TABSTRIP/tabpTAB03").select()
    session.findById(
        "wnd[0]/usr/tabsMENU_TABSTRIP/tabpTAB03/ssubSUBSCR_MENU:SAPMP50A:0400/subSUBSCR_ITMENU:SAPMP50A:0310/tblSAPMP50ATC_MENU").getAbsoluteRow(
        0).selected = -1
    session.findById("wnd[0]/tbar[1]/btn[20]").press()
    session.findById("wnd[0]/usr/tblMP000100TC3000").getAbsoluteRow(0).selected = -1
    session.findById("wnd[0]/usr/tblMP000100TC3000/txtP0001-BEGDA[0,0]").setFocus()
    session.findById("wnd[0]/usr/tblMP000100TC3000/txtP0001-BEGDA[0,0]").caretPosition = 0
    session.findById("wnd[0]/tbar[1]/btn[6]").press()
    try:
        session.findById("wnd[0]/usr/subSUBSCREEN_T582C:ZP000100:0200/ctxtP0001-ZZ_ZEFW").text = control_range
        session.findById("wnd[0]/usr/subSUBSCREEN_T582C:ZP000100:0200/ctxtP0001-ZZ_ZEFW").setFocus()
        session.findById(
            "wnd[0]/usr/subSUBSCREEN_T582C:ZP000100:0200/ctxtP0001-ZZ_ZEFW").caretPosition = 2
    except Exception:
        logging.warning('工资总额控制范围已带出，无需修改')
        time.sleep(1)
        session.findById("wnd[0]").sendVKey(0)
        session.findById("wnd[0]").sendVKey(0)
    session.findById("wnd[0]/tbar[0]/btn[11]").press()


# 规则2.1.6 & 2.1.7  检验12、13、15类人员是否需要定界“从事职业工种信息” & 检验工资总额控制范围
def first_check_103(file):
    wb_103 = load_workbook(FILE_PATH + "/模板_103.xlsx")
    ws_103 = wb_103.active

    # 2.1.7 所需码表【AA】、【AB】、【AC】、【AD】、【AE】的数据
    database_value = defaultdict(list)
    for res in Query(table=Event):
        if None not in [res.db_AA, res.db_AB, res.db_AC, res.db_AD, res.db_AG, res.db_AH]:
            database_value[res.db_AA].append([res.db_AB, res.db_AC, res.db_AD, res.db_AG, res.db_AH])

    session = attach_sap("login_tx")
    logging.info("校验并修改岗位变动工资总额控制范围")
    for i in range(2, len(list(ws_103["A"])) + 1):
        logging.info("开始校验103表第 %s 行数据..." % str(i))
        # 2.1.6  检验12、13、15类人员是否需要定界“从事职业工种信息”
        if cel(ws_103, f"AV{i}") in ["管理序列", "专业技术序列"] and cel(ws_103, f"BU{i}") != "0000.00.00":
            session.findById("wnd[0]").maximize()
            session.findById("wnd[0]/tbar[0]/okcd").text = "/n PA30"
            session.findById("wnd[0]").sendVKey(0)
            session.findById(
                "wnd[0]/shellcont/shell/shellcont[0]/shell/shellcont[1]/shell[1]").topNode = "          1"
            session.findById("wnd[0]/usr/ctxtRP50G-PERNR").text = str(ws_103["A%s" % str(i)].value)
            session.findById("wnd[0]/usr/ctxtRP50G-PERNR").caretPosition = 7
            session.findById("wnd[0]").sendVKey(0)
            session.findById("wnd[0]/usr/tabsMENU_TABSTRIP/tabpTAB03").select()
            session.findById(
                "wnd[0]/usr/tabsMENU_TABSTRIP/tabpTAB03/ssubSUBSCR_MENU:SAPMP50A:0400/subSUBSCR_ITMENU:SAPMP50A:0310/tblSAPMP50ATC_MENU").getAbsoluteRow(
                2).selected = -1
            if '不存在' in session.findById(
                    "wnd[0]/usr/tabsMENU_TABSTRIP/tabpTAB03/ssubSUBSCR_MENU:SAPMP50A:0400/subSUBSCR_ITMENU:SAPMP50A:0310/tblSAPMP50ATC_MENU/lblINF_EX[1,2]").text:
                continue
            session.findById("wnd[0]/tbar[1]/btn[20]").press()
            session.findById("wnd[0]/usr/tblMP924300TC3000").getAbsoluteRow(0).selected = -1
            session.findById("wnd[0]/usr/tblMP924300TC3000/txtP9243-BEGDA[0,0]").setFocus()
            session.findById("wnd[0]/usr/tblMP924300TC3000/txtP9243-BEGDA[0,0]").caretPosition = 0
            session.findById("wnd[0]/tbar[1]/btn[6]").press()
            time_stamp = time.mktime(time.strptime(str(ws_103["C%s" % str(i)].value), "%Y.%m.%d"))
            yesterday = time.strftime("%Y%m%d", time.localtime(int(time_stamp) - 24 * 60 * 60))
            session.findById("wnd[0]/usr/ctxtP9243-ENDDA").text = yesterday
            session.findById("wnd[0]/usr/ctxtP9243-ENDDA").setFocus()
            session.findById("wnd[0]/usr/ctxtP9243-ENDDA").caretPosition = 8
            session.findById("wnd[0]").sendVKey(0)
            session.findById("wnd[0]/tbar[0]/btn[11]").press()

        # 2.1.7  检验工资总额控制范围
        if str(ws_103["P%s" % str(i)].value) in database_value.keys():
            for j in database_value[str(ws_103["P%s" % str(i)].value)]:
                if str(ws_103["R%s" % str(i)].value) in j[0] and str(ws_103["Z%s" % str(i)].value)[:2] == j[3][:2] \
                        and str(ws_103["AB%s" % str(i)].value)[:2] != j[4][:2]:
                    check_payroll_control_range(session, str(ws_103["A%s" % str(i)].value), j[4][:2])
                    break
                if str(ws_103["Z%s" % str(i)].value)[:2] == "00":  # 2.1.8
                    check_payroll_control_range(session, str(ws_103["A%s" % str(i)].value), "")
                    break
    session.findById("wnd[0]/tbar[0]/okcd").text = "/nex"
    session.findById("wnd[0]").sendVKey(0)
    update_database(file, "批导后校验")


# 规则3.1.1  导出组合逻辑查询103、1071、1072
def export_103_and_1071_and_1072(s_file):
    wb = load_workbook(s_file)
    ws = wb.active

    # 103组合逻辑查询表
    export_combinational_logic_queries_103(s_file)

    # 1071组合逻辑查询表
    date_time, li = '', []
    for x in range(7, len(list(ws["E"])) + 1):
        date_time = str(ws["D%s" % str(x)].value) if not date_time and str(ws["D%s" % str(x)].value) else date_time
        li.append(str(ws["E%s" % str(x)].value).split('.')[0].replace(" ", ''))
    export_1071("reuse", li, date_time).save_to(FILE_PATH)

    # 1072组合逻辑查询表
    li = []
    for x in range(7, len(list(ws["E"])) + 1):
        li.append(str(ws["E%s" % str(x)].value).split('.')[0].replace(" ", ''))
    export_1072("reuse", li, date_time).save_to(FILE_PATH)
    close_sap()


# 规则3.1.2 至 3.1.15 ...
def check_103(s_file):
    wb_103 = load_workbook(FILE_PATH + "/模板_103.xlsx")
    ws_103 = wb_103.active

    # 3.1.3 & 3.1.12 所需模板表中的数据
    wb = load_workbook(s_file)
    ws = wb.active
    wb_value = defaultdict(list)
    wb_value_as = defaultdict(list)
    for i in range(7, len(list(ws["A"])) + 1):
        wb_value[cel(ws, f"B{i}").lstrip('0')] = [cel(ws, f"D{i}"), cel(ws, f"AR{i}"), cel(ws, f"AW{i}"),
                                                  cel(ws, f"H{i}"), cel(ws, f"AO{i}")]
        wb_value_as[cel(ws, f"E{i}").lstrip("0").lstrip('0')] = [cel(ws, f"{x}{i}") for x in ["AS", "AV", "AY"]]

    # 3.1.3 & 3.1.10 & 3.1.14 & 3.1.15 所需1071表中的数据
    wb_1071 = load_workbook(FILE_PATH + "/模板_1071.xlsx")
    ws_1071 = wb_1071.active
    wb_1071_value = defaultdict(list)
    vl_1071 = []
    v_1071 = defaultdict(list)

    for i in range(2, len(list(ws_1071["A"])) + 1):
        if ws_1071["B%s" % str(i)].value == ws_1071["B%s" % str(i + 1)].value == "P":
            vl_1071.append(ws_1071["A%s" % str(i - 1)].value)
        wb_1071_value[str(ws_1071["A%s" % str(i)].value)].append(
            {str(ws_1071["B%s" % str(i)].value): str(ws_1071["W%s" % str(i)].value)})
        if ws_1071["B%s" % str(i)].value == "S":
            v_1071[cel(ws_1071, f"A{i}").lstrip("0")] = [cel(ws_1071, f"{x}{i}") for x in ["W", "P", "K", "AE"]]

    # 3.1.11 所需1072表【P-PA】、【R-人事子范围】的数据
    wb_1072 = load_workbook(FILE_PATH + "/模板_1072.xlsx")
    ws_1072 = wb_1072.active
    v_1072 = defaultdict(list)
    for i in range(2, len(list(ws_1072["A"])) + 1):
        if ws_1072["B%s" % str(i)].value == "S" and ws_1072["B%s" % str(i + 1)].value == "O":
            v_1072[cel(ws_1072, f"A{i}").lstrip('0')] = [[cel(ws_1072, f"{x}{i}") for x in ["P", "R", "Q"]],
                                                         [cel(ws_1072, f"{x}{i + 1}") for x in ["P", "R", "Q"]]]

    # 3.1.4 & 3.1.5 所需码表【AA】、【AB】、【AC】、【AD】、【AE】的数据
    database_value = defaultdict(list)
    for res in Query(table=Event):
        if None not in [res.db_AA, res.db_AB, res.db_AC, res.db_AD, res.db_AE, res.db_AF]:
            database_value[res.db_AA].append([res.db_AB, res.db_AC, res.db_AD, res.db_AE, res.db_AF])

    #  码表库码值
    rule_bd_bg = {str(res.db_BD).strip(): str(res.db_BG).strip() for res in Query(Event) if res.db_BD}  # 人事范围, 职务岗位码
    rule_bd_ba = {str(res.db_BD).strip(): str(res.db_BA).strip() for res in Query(Event) if res.db_BD}  # 人事范围, 企业类型
    rule_v = {str(res.db_V).strip().split()[1]: str(res.db_V).strip() for res in Query(Event) if
              " " in str(res.db_V).strip()}  # 人事范围, 企业类型
    rule_b = [str(res.db_B).strip() for res in Query(Event) if res.db_B]  # 岗位变动事件人事子范围会发生变化的人事范围

    # 获取简历修改是否成功的标志
    jl_info = ''
    if os.path.exists(FILE_PATH + "/简历模板_事后.xlsx"):
        wb = load_workbook(FILE_PATH + "/简历模板_事后.xlsx")
        jl_info = wb.properties.description
        jl_info = jl_info[6:] + '。' if "False" in jl_info else ''

    for i in range(2, len(list(ws_103["A"])) + 1):
        logging.info(f"开始事后校验103表第 {i - 1} 行数据...")
        # 3.1.2.1  检验12、13、15类人员是否需要定界“从事职业工种信息”
        if cel(ws_103, f"AV{i}") in ["管理序列", "专业技术序列"] and cel(ws_103, f"BU{i}") != "0000.00.00":
            cells(ws_103, f"BU{i}", "从事职业工种信息结束日期需定界", RED)

        # 3.1.3.1 检验“从事职业工种信息”是否正确维护
        if cel(ws_103, f"AV{i}") == "技能操作序列" and cel(ws_103, f"A{i}").lstrip('0') in wb_value.keys():
            if cel(ws_103, f"BT{i}").replace(".", '') != wb_value[cel(ws_103, f"A{i}").lstrip('0')][0]:
                cells(ws_103, f"BT{i}", "从事职业工种信息开始日期需核对", RED)
            if cel(ws_103, f"BU{i}") != "9999.12.31":
                cells(ws_103, f"BU{i}", "从事职业工种信息结束日期需核对", RED)
            if cel(ws_103, f"X{i}") in wb_1071_value.keys():
                if {"S": cel(ws_103, f"BX{i}")} not in wb_1071_value[cel(ws_103, f"X{i}")]:
                    cells(ws_103, f"BX{i}", "从事职业工种信息所属工种需核对", RED)

        # 3.1.4 & 3.1.5  检验工资核算范围 & 检验工资总额控制范围
        if str(ws_103["P%s" % str(i)].value) in database_value.keys():
            def a(b, c, d):
                return str(b["%s%s" % (c, str(d))].value).replace(" ", "")

            d_v = database_value[str(ws_103["P%s" % str(i)].value)]
            if a(ws_103, "R", i) in d_v[0][0] and a(ws_103, "S", i) in d_v[0][1] and \
                    a(ws_103, "T", i) in d_v[0][2]:
                if a(ws_103, "Z", i)[:2] != d_v[0][3][:2]:
                    cells(ws_103, f"Z{i}", "工资核算范围非码表库默认值（第一行），请确认", BLUE)
            else:
                for x in range(1, len(d_v)):
                    if a(ws_103, "R", i) in d_v[x][0] and a(ws_103, "S", i) in d_v[x][1] and \
                            a(ws_103, "T", i) in d_v[x][2] and a(ws_103, "Z", i)[:2] == d_v[x][3][:2]:
                        break
                else:
                    cells(ws_103, f"Z{i}", "工资核算范围不在码表库中，请联系组长补充码表库", RED)
            if cel(ws_103, f"Z{i}") == "00" and (cel(ws_103, f"AB{i}") or cel(ws_103, f"AC{i}")):
                cells(ws_103, f"AB{i}", f"工资总额控制范围应为空(注：单元格AB{i}和AC{i}都应为空)", RED)
            elif cel(ws_103, f"R{i}") in d_v[0][0] and cel(ws_103, f"Z{i}")[:2] == d_v[0][3][:2]:
                if cel(ws_103, f"AB{i}")[:2] != d_v[0][4][:2]:
                    cells(ws_103, f"AB{i}", "工资总额控制范围需核对", RED)
            else:
                for x in range(1, len(d_v)):
                    if cel(ws_103, f"R{i}") in d_v[x][0] and cel(ws_103, f"Z{i}")[:2] == d_v[x][3][:2]:
                        if cel(ws_103, f"AB{i}")[:2] == d_v[x][4][:2]:
                            break
                        elif x == len(d_v) - 1:
                            cells(ws_103, f"AB{i}", "工资总额控制范围需核对", RED)
                            break
                    if x == len(d_v) - 1:
                        cells(ws_103, f"AB{i}", "未在调配码表库中找到相同的工资核算范围", RED)

        # 3.1.6  检验过往工作经历未定界
        if str(ws_103["A%s" % str(i)].value) == str(ws_103["A%s" % str(i + 1)].value):
            cells(ws_103, "A%s" % str(i), "该人员信息大于等于两行，请核对该人员信息", RED)
            ws_103["A%s" % str(i + 1)].fill = PatternFill("solid", RED)

        # 3.1.7  检验薪酬标杆
        dic = {"1": "管理序列", "2": "专业技术序列", "3": "技能操作序列", "4": "技能操作序列"}
        if not set({cel(ws_103, f"BH{i}")[:1]: cel(ws_103, f"AV{i}")}.items()).issubset(dic.items()):
            cells(ws_103, f"BH{i}", "薪酬标杆与人员子组不对应", RED)

        # 3.1.8.1  检验开始日期
        # if cel(ws_103, f"BS{i}") != time.strftime("%Y.%m.%d", time.localtime(time.time())):
        #     cells(ws_103, f"BS{i}", "简历信息需核对", RED)
        if cel(ws_103, f"AV{i}") in ["管理序列", "专业技术序列", "技能操作序列"]:
            for k, v in {"L": "C", "AR": "C"}.items():
                if cel(ws_103, f"{k}{i}") != cel(ws_103, f"{v}{i}"):
                    cells(ws_103, f"{k}{i}", "开始日期需核对", RED)
            per_code = cel(ws_103, f"A{i}").lstrip("0")
            if per_code in wb_value.keys() and cel(ws_103, f"BL{i}").replace(".", "") != wb_value[per_code][4]:
                cells(ws_103, f"BL{i}", "开始日期需核对", RED)
        if cel(ws_103, f"AV{i}") == "技能操作序列":
            if cel(ws_103, f"BT{i}") != cel(ws_103, f"C{i}"):
                cells(ws_103, f"BT{i}", "开始日期需核对", RED)

        # 3.1.9.1  检验结束日期
        if cel(ws_103, f"AV{i}") in ["管理序列", "专业技术序列", "技能操作序列"]:
            for k, v in {"M": "D", "AS": "D", "BM": "D"}.items():
                if cel(ws_103, f"{k}{i}") != cel(ws_103, f"{v}{i}"):
                    cells(ws_103, f"{k}{i}", "结束日期需核对", RED)
        if cel(ws_103, f"AV{i}") == "技能操作序列":
            if cel(ws_103, f"BU{i}") != cel(ws_103, f"D{i}"):
                cells(ws_103, f"BU{i}", "结束日期需核对", RED)

        # 3.1.9.2  校验人员子组是否发生变更
        if cel(ws_103, f"A{i}").lstrip('0') in wb_value.keys():
            if cel(ws_103, f"T{i}") != wb_value[cel(ws_103, f"A{i}").lstrip('0')][2]:
                cells(ws_103, f"T{i}", "调动前后人员子组发生变化", BLUE)

        # 3.1.10  检验兼任职务序列
        if ws_103["BA%s" % str(i)].value is not None and "职位序列" not in ws_103["AV%s" % str(i)].value:
            if str(ws_103["AV%s" % str(i)].value) == str(ws_103["BA%s" % str(i)].value):
                cells(ws_103, f"AV{i}", "兼任职位序列不能职位序列相同", RED)

        # 3.1.11  检验兼任职务信息（20201015规则更新, update by mengzhao）
        _103_ba_bb_bc = [bool(j.value) for j in ws_103["BA%s:BC%s" % (str(i), str(i))][0]]  # [Bool, Bool, Bool]
        _az = ws_103["AZ%s" % str(i)].value
        if '是' in _az and all(_103_ba_bb_bc) is True:
            pass
        elif ('否' in _az or _az == '') and all(_103_ba_bb_bc) is False:
            pass
        else:
            cells(ws_103, "AZ%s" % str(i), "兼任职位信息不全", RED)
        # if "是" in ws_103["AZ%s" % str(i)].value:
        #     if [bool(j.value) for j in ws_103["BA%s:BC%s" % (str(i), str(i))][0]] != [True, True, True]:
        #         cells(ws_103, "AZ%s" % str(i), "兼任职位信息不全", RED)
        # if "否" in ws_103["AZ%s" % str(i)].value:
        #     if [bool(j.value) for j in ws_103["BA%s:BC%s" % (str(i), str(i))][0]] != [False, False, False]:
        #         cells(ws_103, "AZ%s" % str(i), "兼任职位信息不全", RED)

        # 3.1.12  检验职务（岗位）码
        if cel(ws_103, f"P{i}") in rule_bd_bg.keys():
            for k, v in {"AJ": "职务（岗位）码不应为空", "AK": "工作合同不应为空"}.items():
                if not cel(ws_103, f"{k}{i}") and rule_bd_bg[cel(ws_103, f"P{i}")] != "否":
                    cells(ws_103, f"{k}{i}", v, RED)
                elif cel(ws_103, f"{k}{i}") and rule_bd_bg[cel(ws_103, f"P{i}")] != "是":
                    cells(ws_103, f"{k}{i}", v.replace("不", ""), RED)
        else:
            cells(ws_103, f"P{i}", "码表库中没有该人事范围，请检查", RED)

        # 3.1.13  检验原中层转聘其他岗位标识
        if ["原中层转聘其他岗位" in str(ws_103["I%s" % str(i)].value), "是" in str(ws_103["BK%s" % str(i)].value)] in \
                [[True, False], [False, True]]:
            cells(ws_103, "H%s" % str(i), "中层转聘其他岗位：事件原因/人员子组/标识需核对", BLUE)
        if "原中层转聘其他岗位" in str(ws_103["I%s" % str(i)].value) and "是" in str(ws_103["BK%s" % str(i)].value):
            if str(ws_103["T%s" % str(i)].value).replace(" ", '') != "15":
                cells(ws_103, "H%s" % str(i), "中层转聘其他岗位：事件原因/人员子组/标识需核对", BLUE)

        # 3.1.14  检验是否存在一岗多人
        if ws_103["X%s" % str(i)].value in vl_1071:
            cells(ws_103, "X%s" % str(i), "存在一岗多人", RED)

        # 3.1.15 & 3.1.20  检验人事范围、人事子范围是否维护正确
        if ws_103["X%s" % str(i)].value in v_1072.keys():
            if v_1072[cel(ws_103, f"X{i}")][1][0] == ws_103["P%s" % str(i)].value == \
                    s_file.split('\\')[-1].split('-')[1]:
                pass
            elif not v_1072[cel(ws_103, f"X{i}")][1][0]:
                cells(ws_103, "P%s" % str(i), "末级机构人事范围信息未维护", BLUE)
            else:
                cells(ws_103, "P%s" % str(i), "人事范围发生变化", RED)
            if v_1072[cel(ws_103, f"X{i}")][1][1] != ws_103["R%s" % str(i)].value:
                if not v_1072[cel(ws_103, f"X{i}")][1][1]:
                    cells(ws_103, "R%s" % str(i), "末级机构人事子范围信息未维护", BLUE)
                else:
                    cells(ws_103, "R%s" % str(i), "人事子范围与财务科目设置不同", RED)
                    if v_1072[cel(ws_103, f"X{i}")][1][0] in [res.db_B for res in Query(table=Event)]:
                        cells(ws_103, "Q%s" % str(i), "人事子范围需核对", RED)

        # 3.1.16  检验人员组
        per_code = cel(ws_103, f"A{i}").lstrip('0')
        if per_code in wb_value.keys():
            if not (cel(ws_103, f"S{i}")[:1] == wb_value[per_code][1][:1] == wb_value[per_code][3][:1]):
                if cel(ws_103, f"P{i}") in rule_bd_ba.keys() and rule_bd_ba[cel(ws_103, f"P{i}")] != "销售企业":
                    dic = {"A 原正式职工": "W", "B 合同制员工": "W", "W 合资公司合同制用工": "B",
                           "U 国内劳务派遣到海外人员": "C", "C 派遣制员工": "U"}
                    if {wb_value[per_code][1]: cel(ws_103, f"S{i}")} not in dic:
                        cells(ws_103, f"S{i}", "人员组发生变化的情形不在规定范围内", RED)
                    elif cel(ws_103, f"S{i}") != wb_value[per_code][3][0]:
                        cells(ws_103, f"S{i}", "人员组未按照模板所填信息进行变更", RED)
                else:
                    cells(ws_103, f"S{i}", "销售企业人员的人员组发生了变更", RED)

        # 3.1.17  检验“调整用工形式”的人员组
        if ws_103["H%s" % str(i)].value == "调整用工形式（派遣制员工转为合同制员工）" and ws_103["S%s" % str(i)].value != "B":
            cells(ws_103, "S%s" % str(i), "人员组与事件原因不对应", RED)

        # 3.1.18  检验岗位分类序列
        v_x, v_av = cel(ws_103, f"X{i}").lstrip("0"), cel(ws_103, f"AV{i}")
        if v_x in v_1071.keys():
            if v_av in rule_v.keys() and rule_v[v_av][0] != v_1071[v_x][1]:
                cells(ws_103, f"AV{i}", "岗位分类序列与职位序列不对应", RED)

        # 3.1.19  检验事件是否批导成功
        if not ws_103["G%s" % str(i)].value:
            cells(ws_103, "G%s" % str(i), "岗位变动模板批导不成功", RED)

        # 3.1.20.1  检验财务科目设置设立在机构上还是岗位上，同时判断人事范围、人事子范围是否一致
        if v_x in v_1072.keys():
            if v_1072[v_x][0][0] and v_1072[v_x][0][0] != cel(ws_103, f"P{i}"):
                cells(ws_103, f"P{i}", "岗位财务科目设置有值，但财务科目设置上的人事范围与调动后的人事范围不同", RED)
            elif v_1072[v_x][0][1] and "".join(v_1072[v_x][0][1:3]) == cel(ws_103, f"R{i}") + cel(ws_103, f"Q{i}"):
                cells(ws_103, f"P{i}", "岗位财务科目设置有值，且财务科目设置上的人事范围、人事子范围与调动后的人事范围、人事子范围相同", RED)
            elif v_1072[v_x][0][1] and "".join(v_1072[v_x][0][1:3]) != cel(ws_103, f"R{i}") + cel(ws_103, f"Q{i}"):
                cells(ws_103, f"P{i}", "岗位财务科目设置有值，财务科目设置上的人事范围与调动后的人事范围相同，但人事子范围不同", RED)
            elif v_1072[v_x][1][0] and v_1072[v_x][1][0] != cel(ws_103, f"P{i}"):
                cells(ws_103, f"P{i}", "机构财务科目设置有值，但财务科目设置上的人事范围与调动后的人事范围不同", RED)
            elif v_1072[v_x][1][1] and "".join(v_1072[v_x][1][1:3]) != cel(ws_103, f"R{i}") + cel(ws_103, f"Q{i}"):
                cells(ws_103, f"P{i}", "机构财务科目设置有值，财务科目设置上的人事范围与调动后的人事范围相同，但人事子范围不同", RED)
            elif not v_1072[v_x][1][1]:
                cells(ws_103, f"P{i}", "人事范围、人事子范围并未设置在机构财务科目上", RED)
        # 3.1.20.2  检验人事范围、人事子范围是否发生变化
        if v_x in wb_value_as.keys():
            if cel(ws_103, f"P{i}") == wb_value_as[v_x][1]:
                if cel(ws_103, f"Q{i}") + cel(ws_103, f"R{i}") != wb_value_as[v_x][0].replace(" ", ""):
                    if cel(ws_103, f"P{i}") not in rule_b:
                        cells(ws_103, f"R{i}", "调动前后人事子范围发生变化", RED)
                    else:
                        cells(ws_103, f"R{i}", "调动前后人事子范围发生变化，但这是本组针对企业的个性化设置", BLUE)
            elif cel(ws_103, f"S{i}") == "M":
                cells(ws_103, f"P{i}", "人员组为“M 系统外人员”，且人事范围发生变化", BLUE)
            else:
                cells(ws_103, f"P{i}", "人事范围发生变化", RED)
        else:
            cells(ws_103, f"X{i}", f"岗位变动模板中没有该岗位编号{v_x}", RED)

        # 3.1.21  检验成本中心
        if [bool(j.value) for j in ws_103["CI%s:CL%s" % (str(i), str(i))][0]] == [False, False, False, False]:
            cells(ws_103, "CI%s" % str(i), "机构和岗位的财务科目设置及PA30成本分配的成本中心全部为空", RED)

        # 3.1.21.1  检验成本中心是否与表单提报一致
        if v_x in wb_value_as.keys() and wb_value_as[v_x][2]:
            # if len(wb_value_as[v_x][2]) != 10 or not wb_value_as[v_x][2].isalnum():
            if len(wb_value_as[v_x][2]) != 10 or not (any([x.isdigit() for x in wb_value_as[v_x][2]]) and any(
                    [x.isalpha() for x in wb_value_as[v_x][2]])):
                cells(ws_103, f"CI{i}", "企业所填设立在岗位财科上的成本中心，不是10位英文+数字！", BLUE)
            elif wb_value_as[v_x][2] != cel(ws_103, f"CI{i}"):
                cells(ws_103, f"CI{i}", "成本中心与调配表所填设立在岗位财科上的成本中心不同", RED)

        # 3.1.21.2  检验岗位类别
        if v_x in v_1071.keys():
            if not v_1071[v_x][2]:
                cells(ws_103, f"X{i}", "岗位类别为空", RED)
            if not v_1071[v_x][3]:
                cells(ws_103, f"Y{i}", "该岗位勾选了虚岗位标识", RED)
        else:
            cells(ws_103, f"X{i}", f"1071表中没有该岗位编号{v_x}", RED)  # 3.1.21.3

        # 校验简历是否修改成功
        if jl_info:
            cells(ws_103, f"BP{i}", f"简历修改不成功，SAP报错信息：{jl_info}", RED)

    wb_103.save(FILE_PATH + "/模板_103.xlsx")
    dir_path = get_rpa_dir('岗位变动', os.path.basename(s_file), True) + "/"
    move_file("copy", s_file, dir_path + os.path.basename(s_file))
    move_file("copy", FILE_PATH + "/模板_1072.xlsx", dir_path + "1072.xlsx")
    move_file("copy", FILE_PATH + "/模板_1071.xlsx", dir_path + "1071.xlsx")
    move_file("copy", FILE_PATH + "/tmp-新增工作经历.xlsx", dir_path + "工作经历.xlsx")  # nosec
    move_file("copy", FILE_PATH + "/tmp-新增从事职业工种信息.xlsx", dir_path + "从事职业工种信息.xlsx")  # nosec
    move_file("copy", FILE_PATH + "/模板_103.xlsx", dir_path + "103.xlsx")
    move_file("copy", FILE_PATH + "/事前备份_103.xlsx", dir_path + "事前备份_103.xlsx")
    move_file("copy", FILE_PATH + "/简历模板_事前.xlsx", dir_path + "简历模板_事前.xlsx")
    move_file("copy", FILE_PATH + "/简历模板_事后.xlsx", dir_path + "简历模板_事后.xlsx")
    with MYFTP() as my_ftp:
        hhmmss = datetime.datetime.now().strftime(r'%H%M%S')  # 上传的目录前面加时分秒前缀，避免同一天一个单子，第二次做覆盖上一次的文件
        remote = remote_path + f"成功/{hhmmss}_{os.path.basename(s_file)[:-5]}/"
        move_file("upload", s_file, remote + os.path.basename(s_file), my_ftp)
        move_file("upload", FILE_PATH + "/模板_1072.xlsx", remote + "1072.xlsx", my_ftp)
        move_file("upload", FILE_PATH + "/模板_1071.xlsx", remote + "1071.xlsx", my_ftp)
        move_file("upload", FILE_PATH + "/tmp-新增工作经历.xlsx", remote + "工作经历.xlsx", my_ftp)  # nosec
        move_file("upload", FILE_PATH + "/tmp-新增从事职业工种信息.xlsx", remote + "从事职业工种信息.xlsx", my_ftp)  # nosec
        move_file("upload", FILE_PATH + "/模板_103.xlsx", remote + "103.xlsx", my_ftp)
        move_file("upload", FILE_PATH + "/事前备份_103.xlsx", remote + "事前备份_103.xlsx", my_ftp)
        move_file("upload", FILE_PATH + "/简历模板_事前.xlsx", remote + "简历模板_事前.xlsx", my_ftp)
        move_file("upload", FILE_PATH + "/简历模板_事后.xlsx", remote + "简历模板_事后.xlsx", my_ftp)
        for _file in os.listdir(FILE_PATH):
            my_ftp.upload_file(os.path.join(FILE_PATH, _file), f'{remote}/{_file}')
    for x in ["模板_1071", "模板_1072", "tmp-新增工作经历", "tmp-新增从事职业工种信息", "模板_103", "事前备份_103"]:
        if os.path.exists(FILE_PATH + f"/{x}.xlsx"):
            os.remove(FILE_PATH + f"/{x}.xlsx")
    update_database(s_file, "执行结束")


def upload_gwbd_files_to_ftp(filename):
    dir_path = get_rpa_dir('岗位变动', os.path.basename(filename), False)
    shutil.copyfile(filename, f"{dir_path}/{os.path.basename(filename)}")
    shutil.copyfile(FILE_PATH + "/事前_1072.xlsx", f"{dir_path}/事前-1072.xlsx")
    shutil.copyfile(FILE_PATH + "/事前_1071.xlsx", f"{dir_path}/事前-1071.xlsx")
    shutil.copyfile(FILE_PATH + "/事前备份_103.xlsx", f"{dir_path}/事前备份-103.xlsx")
    with MYFTP() as my_ftp:
        hhmmss = datetime.datetime.now().strftime(r'%H%M%S')  # 上传的目录前面加时分秒前缀，避免同一天一个单子，第二次做覆盖上一次的文件
        remote = f'{remote_path}失败/{hhmmss}_{os.path.basename(filename)[:-5]}/'
        my_ftp.upload_file(f"{dir_path}/事前-1072.xlsx", f"{remote}事前-1072.xlsx")
        my_ftp.upload_file(f"{dir_path}/模板-1071.xlsx", f"{remote}事前-1071.xlsx")
        my_ftp.upload_file(filename, f"{remote}{os.path.basename(filename)}")
        my_ftp.upload_file(FILE_PATH + "/事前备份_103.xlsx", f"{remote}事前备份-103.xlsx")
        for _file in os.listdir(FILE_PATH):
            my_ftp.upload_file(os.path.join(FILE_PATH, _file), f'{remote}/{_file}')


def rpa_gang_bian(filename):
    """岗位变动"""
    file = to_windows_path_format(filename)
    update_db(file, "开始执行")
    # 模板批导前校验
    clear_all_colour_and_comment(file, "岗位变动模板表", remote_path)  # 1.1.1
    logging.info(f"当前事件操作业务员:{STAFF_NAME}")
    try:
        check_zhrpy280(file)  # 1.1.2
        # check_staff_subgroup()
        post_change_pre_check(file)
        check_am_an_ao(file)
    except Exception as e:
        upload_gwbd_files_to_ftp(file)
        raise e
    if send_email(file):  # 检查是否有批注
        upload_gwbd_files_to_ftp(file)
        return
    # 模板批导
    try:
        if batch_import(count=1, file=file) is False:  # 批导失败
            upload_gwbd_files_to_ftp(file)
            return
    except Exception:
        upload_gwbd_files_to_ftp(file)
    # 导出组合逻辑查询103表
    export_combinational_logic_queries_103(file)  # 1.3.1
    if check_batch_result(file):
        upload_gwbd_files_to_ftp(file)
        return
    # create_add_work_experience_template(file)
    create_adding_information_on_job_types_template(file)

    # 批导工作经历模板和从事职业工种模板
    batch_import_tow_excel(file)

    # 零星修改及后续校验
    modification_enterprise_custom_classification_two_and_three(file)
    work_types_identification(file)
    create_experience(file)
    first_check_103(file)
    export_103_and_1071_and_1072(file)
    check_103(file)


if __name__ == "__main__":
    # file = r"x:\rpa\tmp\202106\20210602\081230\1000293429-6500-岗位变动-王叶青.xlsx"
    file = r"x:\dk\新建文件夹\1\1000301942-X941-岗位变动-丁洁.xlsx"
    import rpa

    config('test')
    rpa.config.FSO_USERNAME = 'dingj2321'
    rpa.config.SAP_FUNJ = 'FUNJ0056'
    # create_experience(file)
    rpa_gang_bian(file)
    # first_check_103(file)
    # export_103_and_1071_and_1072(file)
    # first_check_103(file)
