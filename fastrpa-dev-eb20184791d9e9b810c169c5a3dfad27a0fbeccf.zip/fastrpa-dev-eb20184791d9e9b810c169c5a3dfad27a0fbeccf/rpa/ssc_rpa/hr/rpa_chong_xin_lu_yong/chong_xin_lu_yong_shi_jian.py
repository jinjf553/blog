#!/usr/bin/env python
# -*- coding: utf-8 -*-
# @File    : chong_xin_lu_yong_shi_jian.py
# @Author  : jinjianfeng
# @Contact : 553041800@qq.com
# @Link    : https://github.com/jinjf553
# @software: PyCharm
# @Date    : 2019/12/25 20:12
# @Version : ??
import logging
import os
import re
import shutil
import time
from collections import defaultdict
from datetime import datetime

import pyperclip
from openpyxl import load_workbook
from openpyxl.styles import PatternFill
from rpa.fastrpa.adtable import BLUE, RED
from rpa.fastrpa.sap.session import attach_sap
from rpa.fastrpa.xlsx import connect_to_excel
from rpa.public.check_card import more_icon
from rpa.public.config import FILE_PATH, templates, user_name
from rpa.public.db import update_db
from rpa.public.tools import cells
from rpa.public.validate_103 import add_color_comment
from rpa.ssc.hr.orm.orm_ope import DbSession, Query
from rpa.ssc.hr.orm.tb_hr_ruzhi_log_detail import RZLog_detail
from rpa.ssc.hr.orm.td_hr_gang_wei_diao_pei_rulebase import Event
from rpa.ssc.hr.sap.export_103rz import export_103rz
from rpa.ssc_kit.hr.kit_chai_dan.check_280 import check_zhrpy280
from rpa.ssc_rpa.hr.rpa_ru_zhi.ru_zhi_check import export_1071_1072
from rpa.ssc_rpa.hr.rpa_ru_zhi.ru_zhi_shi_jian import (
    Organization_distribution, batch_import, create_work_type,
    work_types_identification)


def ChongXin_LuYong(c_file):
    if not c_file:
        return
    name_dict = cxly_event_processing(c_file)
    cxly_end_check(c_file, name_dict)


def shi_qian_check_excel(dir_path, string="员工入职"):
    logging.info("开始进行重新录用模板事前检查......")
    sr, code = "", ""
    for _file, dir, files in os.walk(dir_path):
        for f in files:
            if string in f:
                sr, code, event, worker = f.split("-")[:4]
                break
        else:
            continue
        break
    else:
        return False, "", code, sr
    old_file = dir_path + "/重新录用模板.xlsx"
    new_file = dir_path + f"/{sr}-{code}-重新录用-{worker}"
    if os.path.exists(old_file):
        shutil.move(old_file, new_file)
    if not os.path.exists(new_file):
        logging.info("完成重新录用模板事前检查...")
        logging.info("检查结果: 无重新录用模板")
        return False, "", "", ""
    rule_U_V_W = {res.db_U: [res.db_V, res.db_W] for res in Query(table=Event) if
                  res.db_U and res.db_V and res.db_W}  # 17 职位序列、职位层级、职位级别
    # rule_L_M = {res.db_L: res.db_M for res in Query(table=Event) if res.db_L and res.db_M}  # 17 人员子组、职位序列
    rule_AA_AH = {res.db_AA + res.db_AB[:4] + res.db_AE: res.db_AH for res in Query(table=Event) if
                  res.db_AA and res.db_AB and res.db_AE}  # 11 工资总额控制范围
    tdt = {8: "BN", 6: "AS", 7: "E", 9: "J", 10: "L", 11: "BO", 12: "AG", 13: "BP", 14: "Y", 15: "F", 18: "AH", 19: "R",
           20: "BQ", 21: "V", 22: "W", 23: "U", 25: "R", 26: "V", 27: "W", 28: "U", 31: "R", 32: "R", 33: "R",
           34: "R", 36: "CW", 37: "R", 38: "R", 44: "DA", 45: "DB", 46: "DC", 47: "DD", 48: "DE", 49: "CZ",
           50: "DF", 52: "DG"}
    rule_dic = defaultdict(list)
    for r in Query(Event):
        for k, v in tdt.items():
            if eval("r.db_" + v):
                rule_dic[k].append(eval("r.db_" + v).replace(" ", ""))
    check_zhrpy280(new_file)
    # xl = win32.Dispatch("Excel.Application")
    xl = connect_to_excel()  # 20210113 用通用连接Excel方法替换直连，连接失败时kill Excel并重试
    # xl.Visible = True
    xl.DisplayAlerts = False
    wb = xl.Workbooks.Open(new_file)
    try:
        ws = wb.ActiveSheet
        rows = ws.Range("B%s" % str(ws.Rows.Count)).End(-4162).Row
        ws.Range("A7:CZ%s" % str(ws.Rows.Count)).ClearComments()
        ws.Range("A7:CZ%s" % str(ws.Rows.Count)).Interior.ColorIndex = -4142
        if rows < 7:
            logging.info("检查结果: 重新录用模板中无数据，跳过校验")
            return False, "", "", ""
        name_dict = {str(i[3]).replace(".0", ""): i[0] for i in ws.Range("B7:E%s" % str(rows)).Value if
                     str(i[3]) != 'None'}
        card_dict = {str(int(ws.Range("B%s" % str(x)).Value)): ws.Range("C%s" % str(x)).Value for x in
                     range(7, rows + 7) if ws.Range("C%s" % str(x)).Value}
        logging.info(f'{name_dict}, {card_dict}')
        date = ws.Range("D7").Value
        values_1071, values_1072 = export_1071_1072(name_dict, date, os.path.dirname(new_file))
        shutil.move(os.path.join(dir_path, "1071.xlsx"), os.path.join(dir_path, "重新录用_1071.xlsx"))
        shutil.move(os.path.join(dir_path, "1072.xlsx"), os.path.join(dir_path, "重新录用_1072.xlsx"))
        values_103 = get_gwxx_info(card_dict, os.path.dirname(new_file), date)
        for i in range(7, rows + 1):
            i = str(i)
            logging.info(f"开始校验重新录用模板第{int(i) - 6}行数据...")

            # 9  填写人事范围、人事子范围
            if not ws.Range("E" + i).Value:
                cells(ws, "E" + i, "岗位编号不能为空", 3)
                continue
            if ws.Range(f"AM{i}").Value:
                continue
            tmpe = str(int(ws.Range("E" + i).Value)).lstrip("0")
            tmp_list = [x.lstrip("0") for x in values_1072.keys()]
            if tmpe in tmp_list:
                if not ws.Cells(int(i), 6).Value:
                    ws.Cells(int(i), 6).Value = values_1072[tmpe][0]
                elif str(ws.Cells(int(i), 6).Value).strip() != values_1072[tmpe][0]:
                    cells(ws, "F" + i, "人事范围与岗位信息不匹配", 3)
                if not ws.Cells(int(i), 7).Value:
                    ws.Cells(int(i), 7).Value = values_1072[tmpe][1]
                if not ws.Cells(int(i), 11).Value:
                    ws.Cells(int(i), 11).Value = values_1072[tmpe][2]

            # 18  检验重新录用模板中人职位序列、薪酬标杆岗位类别、岗位分类序列符合逻辑
            if tmpe not in [x.lstrip("0") for x in values_1071.keys()]:
                cells(ws, "E" + i, "1071不存在该岗位编号，请检查", 3)
                continue
            tmp107, tmpu = values_1071[tmpe], str(ws.Range("U" + i).Value)[:1]
            if not ((tmp107[0] == tmp107[1][:1] == tmpu) or (tmp107[0] == tmpu == "3" and tmp107[1][:1] == "4")):
                cells(ws, "E" + i, "请检查岗位分类序列和薪酬标杆信息", 3)

            # 17  检验重新录用模板中人员子组、职位序列、层级符合逻辑
            tmpj = str(ws.Range("J" + i).Value).strip()
            tmpw = str(ws.Range("W" + i).Value).strip()
            tmpu = str(ws.Range("U" + i).Value).strip()
            tmpv = str(ws.Range("V" + i).Value).strip()
            if tmpw not in rule_U_V_W.keys() or rule_U_V_W[tmpw][0] != tmpu or rule_U_V_W[tmpw][
                    1] != tmpv:  # or tmpj not in rule_L_M.keys() or tmpu != rule_L_M[tmpj]:
                cells(ws, "J" + i, "请检查人员子组和职位序列信息", 3)

            # 16  检查模板有长度要求的字段符合要求
            if len(str(ws.Range("AC" + i).Value).strip()) > 40:
                cells(ws, "AC" + i, "请检查数据长度超长", 3)

            # 15  检验重新录用时间是否符合要求
            tmpd = str(ws.Range("D" + i).Value).strip()[:8]
            try:
                time.strptime(tmpd, '%Y%m%d')
                current_date = time.strftime("%d", time.localtime(time.time()))
                current_month = time.strftime("%Y%m", time.localtime(time.time()))
                next_month = time.strftime("%Y%m",
                                           time.localtime(time.time() + (32 - int(current_date)) * 24 * 60 * 60))
                if tmpd[:-2] not in [current_month, next_month]:
                    cells(ws, "D" + i, "请核查此数值是否为有效重新录用时间", 3)
                if i != "7" and str(ws.Range("D" + str(int(i) - 1)).Value).strip() != str(
                        ws.Range("D" + i).Value).strip():
                    cells(ws, "D" + i, "请核查此数值是否为有效重新录用时间", 3)
            except Exception:
                cells(ws, "D" + i, "请核查此数值是否为有效重新录用时间", 3)

            # 13  检验重新录用所有相关模板中必填项内容不为空
            for j in [chr(x // 26 + 64) + chr(x % 26 + 65) if x > 25 else chr(x + 65) for x in range(79)]:
                if "X" in str(ws.Range(j + "3").Value) and ws.Range(j + i).Value is None:
                    cells(ws, j + i, "此单元格为必填项", 3)

            # 12  检验重新录用所有相关模板有码表的均符合码表规则
            for key, value in rule_dic.items():
                if not ws.Cells(int(i), key).Value:
                    continue
                if str(ws.Cells(int(i), key).Value).replace(" ", "") not in value:
                    if key == 50:
                        cells(ws, (int(i), key), "单元格数据不是码值", 41)
                    else:
                        cells(ws, (int(i), key), "单元格数据不是码值", 3)

            # 10  检验模板中人事范围、人事子范围、工资核算范围是否匹配
            # 11  填写工资总额控制范围
            tmp_var = str(ws.Range("F" + i).Value)[:4] + str(ws.Range("G" + i).Value)[:4] + str(
                ws.Range("L" + i).Value)[:2]
            if tmp_var in rule_AA_AH.keys():
                ws.Range("R" + i).Value = rule_AA_AH[tmp_var].strip()
            elif "00" == str(ws.Range("L" + i).Value)[:2]:
                pass
            else:
                cells(ws, "L" + i, "工资核算范围与人事范围、人事子范围不匹配，请核实", 3)
                cells(ws, "R" + i, "工资总额控制范围无匹配，请检查", 3)
            tmpv, tmpu = str(ws.Range("V" + i).Value).strip(), str(ws.Range("U" + i).Value).strip()
            if tmpv == "30 中层管理" or (tmpv[:2].isdigit() and int(tmpv[:2]) < 50 and tmpu == "2 专业技术人员"):
                cells(ws, "R" + i, "请注意检查中层及专家人员的工资总额控制范围", 41)

            # 15  检验重新录用模板【B】列人员岗位状态
            tmpb = str(ws.Range("B" + i).Value).lstrip("0")
            if tmpb in values_103.keys():
                if values_103[tmpb][0] != "None":
                    if "在岗" == values_103[tmpb][3] or "减册人员" != values_103[tmpb][-1]:
                        cells(ws, "B" + i, "系统中此人员已为在岗状态，请注意检查", 3)

            # 20  检查岗位编号下是否已经分配有人员
            if "P" in values_1071[tmpe][2] and str(tmpb).lstrip("0") != values_1071[tmpe][5]:
                cells(ws, "E" + i, "此岗位已经分配有人员，请检查", 3)

            # 21  检查岗位信息是否完整
            if values_1071[tmpe][3]:
                cells(ws, "E" + i, "此岗位信息不完整，请检查", 3)

            # 22  检查事件原因、人员组和岗位信息逻辑关系
            tmph, tmpi = str(ws.Range("H" + i).Value).strip(), str(ws.Range("I" + i).Value).strip()
            if ((tmpi == "B 合同制员工" and values_1071[tmpe][4][:1] != "C") or (tmph == "C 派遣制员工" and values_1071[tmpe][4] not in ["B2", "C2"])):
                cells(ws, "I" + i, "人员组与岗位信息不匹配", 3)
            if (tmpi[0] != "B" and tmph[:2] == "39") or (tmpi[0] == "B" and tmph[:2] != "39"):
                cells(ws, "I" + i, "该事件原因只允许人员组为B合同制员工", 3)

            # 23  检查机构名称
            if tmpe in values_1072.keys() and values_1072[tmpe][3] not in str(ws.Range("AQ" + i).Value).strip():
                cells(ws, "AQ" + i, "请核实重新录用机构名称", 41)

            # 24  检查人员组与人员子组是否匹配
            tmpi = str(ws.Range("I" + i).Value).strip().split()[0]
            tmpj = str(ws.Range("J" + i).Value).strip().split()[0]
            if (tmpi == "B" and tmpj not in ["12", "13", "14", "15", "16", "17", "21", "22"]) or \
                    (tmpi == "M" and tmpj not in ["61", "62", "63"]):
                cells(ws, "I" + i, "请检查人员组与人员子组是否匹配", 3)

            # 25  提取机构全称
            if tmpe in values_1072.keys():
                ws.Range("BA" + i).Value = values_1072[tmpe][4]
        wb.Save()
        ws = wb.ActiveSheet
        rows = ws.Range("B%s" % str(ws.Rows.Count)).End(-4162).Row
        tt = ["重" + str(c.Address).replace('$', '') for c in ws.Range(f"B7:AZ{rows + 1}") if c.Interior.ColorIndex == 3]
        flag = False if not tt else True
        logging.info("完成重新录用模板事前检查...")
        logging.info("检查结果: 通过,可执行事件..." if not flag else f"检查结果: 未通过,问题单元格为{tt}")
    except Exception as e:
        raise e
    finally:
        if wb:
            wb.Close()
        if xl:
            xl.Quit()
    return flag, new_file, code, sr


def get_gwxx_info(card_dict, dir_path, date):
    string = "\r\n".join([str(value) for value in card_dict.keys() if value])
    if string:
        export_gwxx_info(string, date)
        if os.path.exists(os.path.join(FILE_PATH, "tmp-card.xlsx")):
            shutil.move(os.path.join(FILE_PATH, "tmp-card.xlsx"), os.path.join(dir_path, "103.xlsx"))

    if not os.path.exists(dir_path + "/103.xlsx"):
        return {}
    wb_103 = load_workbook(os.path.join(dir_path, "103.xlsx"))
    ws_103 = wb_103.active
    values_103 = defaultdict(list)
    for i in range(2, len(ws_103["A"]) + 1):
        tmp_list = [str(ws_103["%s%s" % (x, str(i))].value) for x in [chr(y) for y in range(65, 78)]]
        values_103[str(ws_103["A%s" % str(i)].value).lstrip("0")] = tmp_list
    return values_103


def export_gwxx_info(text, date):
    # logging.info(text)
    session = attach_sap("reopen")
    _C103_2card(session, date)
    session.findById("wnd[1]/tbar[0]/btn[16]").press()
    pyperclip.copy(text)
    session.findById("wnd[1]/tbar[0]/btn[24]").press()
    session.findById("wnd[1]/tbar[0]/btn[8]").press()
    try:
        session.findById("wnd[2]/tbar[0]/btn[0]").press()
    except Exception:  # nosec
        pass
    session.findById("wnd[0]/tbar[1]/btn[8]").press()
    if session.findById("wnd[0]/sbar/pane[0]").text in ['未选取数据', '系统不能读取任何数据']:
        time.sleep(3)
        session.findById("wnd[0]/tbar[0]/okcd").text = "/nex"
        session.findById("wnd[0]").sendVKey(0)
        return False
    try:
        session.findById("wnd[0]/tbar[1]/btn[8]").press()
    except Exception:  # nosec
        pass

    table = session.findById("wnd[0]/usr/cntlGRID1/shellcont/shell")
    from rpa.public.config import FILE_PATH
    tmp103_wb = load_workbook(os.path.join(templates, "身份证信息.xlsx"))
    tmp103_ws = tmp103_wb["Sheet1"]
    for j in range(table.columnCount):
        tmp103_ws.cell(1, j + 1).value = table.getCellValue(-1, table.columnOrder(j))

    for i in range(table.rowCount):
        session.findById("wnd[0]/usr/cntlGRID1/shellcont/shell").firstVisibleRow = i
        table = session.findById("wnd[0]/usr/cntlGRID1/shellcont/shell")
        for j in range(table.columnCount):
            tmp103_ws.cell(i + 2, j + 1).value = table.getCellValue(i, table.columnOrder(j))
            if i + 2 > table.rowCount:
                tmp103_ws.cell(i + 3, j + 1).fill = PatternFill("solid", RED)
    tmp103_wb.save(os.path.join(FILE_PATH, "tmp-card.xlsx"))
    session.findById("wnd[0]/tbar[0]/okcd").text = "/nex"
    session.findById("wnd[0]").sendVKey(0)


def _C103_2card(session, date):
    session.findById("wnd[0]/tbar[0]/okcd").text = "/n S_PH0_48000513"
    session.findById("wnd[0]").sendVKey(0)
    session.findById("wnd[1]/usr/cmbDYNP4100-DD_WORKSPACE").key = "2"
    session.findById("wnd[1]/usr/cmbDYNP4100-DD_USERGROUP").key = "103"
    session.findById("wnd[1]/usr/tblSAPLAQ_INT_FUNCTIONSTCH_FUNCAREAS").getAbsoluteRow(1).selected = -1
    session.findById("wnd[1]/tbar[0]/btn[0]").press()
    temp = "wnd[0]/shellcont[1]/shell/shellcont[0]/shell/shellcont[1]/shell[1]"
    session.findById(temp).expandNode("          2")
    session.findById(temp).itemContextMenu("          3", "C          4")
    session.findById(temp).selectContextMenuItem("OUTPUT_BOTH")
    session.findById(temp).changeCheckbox("          3", "C          3", -1)
    session.findById(temp).expandNode("          4")
    session.findById(temp).itemContextMenu("         12", "C          4")
    session.findById(temp).selectContextMenuItem("OUTPUT_BOTH")
    session.findById(temp).expandNode("         19")
    session.findById(temp).itemContextMenu("         28", "C          4")
    session.findById(temp).selectContextMenuItem("OUTPUT_BOTH")
    session.findById(temp).itemContextMenu("         29", "C          4")
    session.findById(temp).selectContextMenuItem("OUTPUT_BOTH")
    session.findById(temp).itemContextMenu("         32", "C          4")
    session.findById(temp).selectContextMenuItem("OUTPUT_BOTH")
    session.findById(temp).expandNode("        160")
    session.findById(temp).itemContextMenu("        166", "C          4")
    session.findById(temp).selectContextMenuItem("OUTPUT_ONLYVALUE")
    session.findById(temp).itemContextMenu("         31", "C          4")
    session.findById(temp).selectContextMenuItem("OUTPUT_BOTH")
    more_icon(session, date)
    session.findById("wnd[1]/tbar[0]/btn[16]").press()


def chong_xin_lu_yong_pa30(value, session):
    def tmp_enter(s):
        try:
            s.findById("wnd[1]/tbar[0]/btn[0]").press()
        except Exception:  # nosec
            pass
        for i in range(10):
            if "请保存你的输入" not in session.findById("wnd[0]/sbar").text:
                session.findById("wnd[0]").sendVKey(0)
            else:
                break

    def tmp_func(session, value, col, row):
        session.findById("wnd[0]/tbar[0]/okcd").text = '/n pa30'
        session.findById("wnd[0]").sendVKey(0)
        session.findById("wnd[0]/usr/ctxtRP50G-PERNR").text = value[1]
        session.findById("wnd[0]").sendVKey(0)
        session.findById(f"wnd[0]/usr/tabsMENU_TABSTRIP/tabpTAB0{col}").select()
        session.findById(
            f"wnd[0]/usr/tabsMENU_TABSTRIP/tabpTAB0{col}/ssubSUBSCR_MENU:SAPMP50A:0400/subSUBSCR_ITMENU:SAPMP50A:0310/tblSAPMP50ATC_MENU").verticalScrollbar.position = row
        text = session.findById(
            f"wnd[0]/usr/tabsMENU_TABSTRIP/tabpTAB0{col}/ssubSUBSCR_MENU:SAPMP50A:0400/subSUBSCR_ITMENU:SAPMP50A:0310/tblSAPMP50ATC_MENU/lblINF_EX[1,0]").toolTip
        session.findById(
            f"wnd[0]/usr/tabsMENU_TABSTRIP/tabpTAB0{col}/ssubSUBSCR_MENU:SAPMP50A:0400/subSUBSCR_ITMENU:SAPMP50A:0310/tblSAPMP50ATC_MENU").getAbsoluteRow(
            row).selected = -1
        btn = "6" if text == "存在" else "5"
        session.findById(f"wnd[0]/tbar[1]/btn[{btn}]").press()
        return btn

    # 工作经历
    tmp_func(session, value, 1, 4)
    date = "".join(re.findall(r"\d", str(session.findById("wnd[0]/usr/ctxtP0023-BEGDA").text)))
    if date != value[3]:
        session.findById("wnd[0]/tbar[0]/btn[3]").press()
        session.findById("wnd[0]/tbar[1]/btn[5]").press()
        session.findById("wnd[0]/usr/ctxtP0023-BEGDA").text = value[3]
        session.findById(
            "wnd[0]/usr/subSUBSCREEN_T582C:ZP002300:0200/txtP0023-ZZ_SZDWJBMMC").text = value[52] if value[52] else \
            value[42]
        session.findById("wnd[0]/usr/subSUBSCREEN_T582C:ZP002300:0200/txtP0023-ZZ_CSGZ1").text = value[23]
        session.findById("wnd[0]").sendVKey(0)
        session.findById("wnd[0]/tbar[0]/btn[11]").press()

    # 其他用工信息
    btn = tmp_func(session, value, 2, 0)
    if value[48] and value[8][0] == "C":
        date = "".join(
            re.findall(r"\d", str(session.findById("wnd[0]/usr/ctxtP9241-BEGDA").text)))  # wnd[0]/usr/ctxtP0023-BEGDA
        if date != value[3]:
            try:
                session.findById("wnd[0]/tbar[0]/btn[3]").press()
                session.findById("wnd[0]/tbar[1]/btn[5]").press()
                session.findById("wnd[0]/usr/ctxtP9241-BEGDA").text = value[3]
                session.findById("wnd[0]/usr/cmbP9241-ZZ_QTYGLY").key = value[48][:2]
                session.findById("wnd[0]/usr/cmbP9241-ZZ_LWPQDW").key = value[49][:4] if value[49] else " "
                session.findById("wnd[0]/usr/txtP9241-ZZ_LWPQDWMC").text = value[50] if value[50] else ""
                session.findById("wnd[0]/usr/cmbP9241-ZZ_LWPQDWLB").key = value[51][:1] if value[
                    51] else " "
            except Exception:  # nosec
                pass
            session.findById("wnd[0]").sendVKey(0)
            session.findById("wnd[0]/tbar[0]/btn[11]").press()
            tmp_enter(session)
    elif value[8][0] == "B" and btn == "6":
        current_date = time.mktime(time.strptime(value[3], "%Y%m%d"))
        yesterday = time.strftime("%Y%m%d", time.localtime(current_date - 24 * 60 * 60))
        end_date = session.findById("wnd[0]/usr/ctxtP9241-ENDDA").text
        if str(end_date) == "9999.12.31":
            session.findById("wnd[0]/usr/ctxtP9241-ENDDA").text = yesterday
            session.findById("wnd[0]/tbar[0]/btn[11]").press()
            tmp_enter(session)

    # 从事职业工种
    if value[9][:2] == "16":
        tmp_func(session, value, 3, 2)
        date = "".join(re.findall(r"\d", str(session.findById("wnd[0]/usr/ctxtP9243-BEGDA").text)))
        if date != value[3]:
            session.findById("wnd[0]/tbar[0]/btn[3]").press()
            session.findById("wnd[0]/tbar[1]/btn[5]").press()
            session.findById("wnd[0]/usr/ctxtP9243-BEGDA").text = value[3]
            session.findById("wnd[0]/usr/chkP9243-ZZ_SFSZYJNJDFW").selected = -1
        session.findById("wnd[0]").sendVKey(0)
        session.findById("wnd[0]").sendVKey(0)
        session.findById("wnd[0]/tbar[0]/btn[11]").press()


def cxly_event_processing(file):
    logging.info("开始执行重新录用事件...")
    update_db(file, "重新录用事件")
    sr = os.path.basename(file)[:10]
    wb = load_workbook(file)
    ws = wb.active
    values = [[str(x).strip().replace("None", "") for x in value[:53]] for value in ws.values if value[1]][5:]
    name_dict = {value[2].strip(): [value[1], value[20][:1], value[3], "", "", "", "", "", value[46]] for value in
                 values}
    session = attach_sap("login_tx")
    for value in values:
        logging.info(f"正在执行重新录用事件第{values.index(value) + 1}条数据...")
        try:
            # 启动重新录用界面
            if value[38] in ["PA30信息维护异常"]:
                try:
                    code = "0" * (8 - len(value[1])) + value[1]
                    with DbSession() as sess:
                        res = sess.query(RZLog_detail).filter(RZLog_detail.sr == sr, RZLog_detail.code == code)
                        if res:
                            res.update(
                                {"times": res.first().times + 1, "update_time": datetime.now()})
                    chong_xin_lu_yong_pa30(value, session)
                    ws["AM%s" % str(values.index(value) + 7)] = "成功"
                    ws["AN%s" % str(values.index(value) + 7)] = ""
                    wb.save(file)
                except Exception as e:
                    ws["AN%s" % str(values.index(value) + 7)] = f"异常原因：{e}"
                    ws["AM%s" % str(values.index(value) + 7)] = "PA30信息维护异常"
                    wb.save(file)
                continue
            elif value[38] == "成功":
                continue

            session.findById("wnd[0]/tbar[0]/okcd").text = "/n ZPA40_10"
            session.findById("wnd[0]").sendVKey(0)
            session.findById("wnd[0]/usr/ctxtRP50G-EINDA").text = value[3]  # 事件时间
            session.findById("wnd[0]/usr/ctxtRP50G-PERNR").text = value[1]  # 人员编号
            session.findById("wnd[0]").sendVKey(0)
            session.findById("wnd[0]/usr/tblSAPMP50ATC_MENU_EVENT").getAbsoluteRow(2).selected = -1
            session.findById("wnd[0]/tbar[1]/btn[8]").press()

            # 人事调配屏
            session.findById("wnd[0]/usr/ctxtP0000-BEGDA").text = value[3]
            session.findById("wnd[0]/usr/ctxtP0000-MASSG").text = value[7][:2] if value[7] != "重新录用" else "  "
            session.findById("wnd[0]/usr/ctxtPSPAR-PLANS").text = value[4]
            session.findById("wnd[0]/usr/ctxtPSPAR-WERKS").text = value[5][:4]
            session.findById("wnd[0]/usr/ctxtPSPAR-PERSG").text = value[8][:1]
            session.findById("wnd[0]/usr/ctxtPSPAR-PERSK").text = value[9][:2]

            def tmp_enter(s):
                try:
                    s.findById("wnd[1]/tbar[0]/btn[0]").press()
                except Exception:  # nosec
                    pass
                for i in range(10):
                    if "请保存你的输入" not in session.findById("wnd[0]/sbar").text:
                        session.findById("wnd[0]").sendVKey(0)
                    else:
                        break

            session.findById("wnd[0]").sendVKey(0)
            tmp_enter(session)
            session.findById("wnd[0]/tbar[0]/btn[11]").press()
            tmp_enter(session)

            # 组织分配屏
            session.findById("wnd[0]/usr/ctxtP0001-BEGDA").text = value[3]
            session.findById("wnd[0]/usr/ctxtP0001-BTRTL").text = value[6][:4]  # 人事子范围
            session.findById("wnd[0]/usr/ctxtP0001-ABKRS").text = value[11][:2]  # 工资范围
            session.findById("wnd[0]/usr/cmbP0001-ANSVH").key = value[13][:2] if value[13] else " "
            session.findById("wnd[0]/usr/subSUBSCREEN_T582C:ZP000100:0200/ctxtP0001-ZZ_QYZDYYGFL").text = \
                value[14].split()[0] if value[14] else ""
            session.findById("wnd[0]/usr/subSUBSCREEN_T582C:ZP000100:0200/ctxtP0001-ZZ_QYZDYYGFL1").text = \
                value[15].split()[0] if value[15] else ""
            session.findById("wnd[0]/usr/subSUBSCREEN_T582C:ZP000100:0200/ctxtP0001-ZZ_QYZDYYGFL2").text = \
                value[16].split()[0] if value[16] else ""
            if "X" in value[18]:
                session.findById(
                    "wnd[0]/usr/subSUBSCREEN_T582C:ZP000100:0200/chkP0001-ZZ_QYTJBS1").selected = -1
            session.findById("wnd[0]/usr/subSUBSCREEN_T582C:ZP000100:0200/cmbP0001-ZZ_ZBTJWYBZ").key = value[19][:2]
            session.findById("wnd[0]").sendVKey(0)
            try:  # 工资总额控制范围处理
                tmp_text = session.findById(
                    "wnd[0]/usr/subSUBSCREEN_T582C:ZP000100:0200/txtZHR_PYZEKZFWT-ZZ_ZEFW_TXT").text
                if not tmp_text and value[16]:
                    session.findById("wnd[0]/usr/subSUBSCREEN_T582C:ZP000100:0200/ctxtP0001-ZZ_ZEFW").text = \
                        value[14].split()[0]
            except Exception:  # nosec
                pass
            session.findById("wnd[0]/tbar[0]/btn[11]").press()
            tmp_enter(session)

            #  岗位聘任补充信息屏
            session.findById("wnd[0]/usr/ctxtP9209-BEGDA").text = value[3]
            session.findById("wnd[0]/usr/ctxtP9209-ZZ_ZWCJXL1").text = value[20][:1]
            session.findById("wnd[0]/usr/ctxtP9209-ZZ_ZWCJXL2").text = value[21][:2]
            session.findById("wnd[0]/usr/ctxtP9209-ZZ_ZWCJXL3").text = value[22][:2]
            session.findById("wnd[0]/usr/txtP9209-ZZ_ZWMC_RC").text = value[23]
            session.findById("wnd[0]/usr/txtP9209-ZZ_PRWH").text = value[28] if value[28] else ""
            session.findById("wnd[0]").sendVKey(0)
            session.findById("wnd[0]/tbar[0]/btn[11]").press()
            try:
                chong_xin_lu_yong_pa30(value, session)
                ws["AM%s" % str(values.index(value) + 7)] = "成功"
                wb.save(file)
            except Exception as e:
                ws["AN%s" % str(values.index(value) + 7)] = f"异常原因：{e}"
                ws["AM%s" % str(values.index(value) + 7)] = "PA30信息维护异常"
                wb.save(file)
        except Exception:
            text = session.findById("wnd[0]/sbar").text
            ws["AM%s" % str(values.index(value) + 7)] = text if text else "失败，原因未知"
            wb.save(file)
    return name_dict


def cxly_check_103(file, file_103, file_1071, file_1072):
    logging.info("正在进行重新录用事后检查......")
    sr = os.path.basename(file)[:10]
    username, password = user_name()
    wb_mb = load_workbook(file)
    ws_mb = wb_mb.active
    lis = ["AQ", "AU", "AS", "O", "P", "Q"]
    dict_mb = {str(ws_mb[f"E{x}"].value).lstrip("0"): {y: str(ws_mb[f"{y}{x}"].value).strip() for y in lis}
               for x in range(7, len(ws_mb["B"]) + 1)}
    wb_mb.close()

    wb_103 = load_workbook(file_103)
    ws_103 = wb_103.active

    wb_1071 = load_workbook(file_1071)
    ws_1071 = wb_1071.active
    dict_1071 = {str(ws_1071[f"A{x}"].value).lstrip("0") + str(ws_1071[f"B{x}"].value).strip():
                 {"P": str(ws_1071[f"P{x}"].value).strip(), "Z": str(ws_1071[f"Z{x}"].value).strip()}
                 for x in range(2, len(ws_1071["A"]) + 1)}

    wb_1072 = load_workbook(file_1072)
    ws_1072 = wb_1072.active
    dict_1072 = {str(ws_1072[f"A{x}"].value).lstrip("0"): {"G": str(ws_1072[f"G{x + 1}"].value).strip(),
                                                           "H": str(ws_1072[f"H{x}"].value).strip()}
                 for x in range(1, len(ws_1072["A"])) if "S" in ws_1072[f"B{x}"].value}
    wb_1072.close()

    result = defaultdict(list)
    for i in range(2, len(ws_103["A"]) + 1):
        i, personnel_code = str(i), "0" * (8 - len(str(ws_103[f"A{i}"].value))) + str(ws_103[f"A{i}"].value)
        # 1.事件是否执行成功
        if ws_103[f"F{i}"].value is None or ws_103[f"G{i}"].value is None:
            add_color_comment(ws_103[f"F{i}"], RED, "请检查此人员重新录用是否成功！", result[personnel_code])

        # 2. 人员组
        if ws_103[f"S{i}"].value not in ('A', 'B', 'C'):
            add_color_comment(ws_103[f"S{i}"], BLUE, "请核对人员组！", result[personnel_code])
        if ws_103[f"S{i}"].value in ('K', 'N', 'S'):
            add_color_comment(ws_103[f"S{i}"], RED, "请核对人员组！", result[personnel_code])

        # 3.人员子组
        t, av, s1, s2, s3 = ws_103[f"T{i}"].value, ws_103[f"AV{i}"].value, '管理序列', '专业技术序列', '技能操作序列'
        if (t in ('12', '13') and s1 not in av) or (t == '15' and s2 not in av) or (t in ('16', '17') and s3 not in av):
            add_color_comment(ws_103[f"T{i}"], RED, "人员子组和职位序列不匹配！", result[personnel_code])

        # 4.工资核算范围
        if None in [x.value for x in ws_103[f"P{i}:T{i}"][0]] + [ws_103[f"Z{i}"].value]:
            add_color_comment(ws_103[f"Z{i}"], RED, "请检查工资核算范围！", result[personnel_code])
        elif "00" in ws_103[f"Z{i}"].value:
            add_color_comment(ws_103[f"Z{i}"], BLUE, "请检查工资核算范围！", result[personnel_code])
        else:
            with DbSession() as sess:
                res = sess.query(Event).filter(Event.db_AA == ws_103[f"P{i}"].value,
                                               Event.db_AB == (str(ws_103[f"Q{i}"].value) + ' ' + str(
                                                   ws_103[f"R{i}"].value)).strip(),
                                               Event.db_AC.like(f'%{ws_103[f"S{i}"].value}%'),
                                               Event.db_AD.like(f'%{ws_103[f"T{i}"].value}%'),
                                               Event.db_AE == ws_103[f"Z{i}"].value).first()
                if not res:
                    add_color_comment(ws_103[f"Z{i}"], RED, "请检查工资核算范围！", result[personnel_code])

        # 5 从事职业（工种）信息
        if '技能操作序列' in str(ws_103[f"AV{i}"].value) and not (
                ws_103[f"BT{i}"].value == ws_103[f"C{i}"].value and str(ws_103[f"BU{i}"].value) == '9999.12.31'):
            add_color_comment(ws_103[f"BU{i}"], RED, "请检查职业工种信息！", result[personnel_code])
        if '技能操作序列' not in str(ws_103[f"AV{i}"].value) and str(ws_103[f"BU{i}"].value) == '9999.12.31':
            add_color_comment(ws_103[f"BU{i}"], RED, "请检查职业工种信息！", result[personnel_code])

        # 6.入职时间
        for k, v in {"L": "M", "AR": "AS", "CB": "CC", "BT": "BU"}.items():
            if ws_103[f"C{i}"].value != ws_103[f"{k}{i}"].value:
                add_color_comment(ws_103[f"{k}{i}"], RED, "请检查事件开始日期！", result[personnel_code])
            if ws_103[f"D{i}"].value != ws_103[f"{v}{i}"].value:
                add_color_comment(ws_103[f"{v}{i}"], RED, "请检查事件结束日期！", result[personnel_code])

        # 7.兼任职务标识
        if "是" in str(ws_103[f"AZ{i}"].value) and None in [x.value for x in ws_103[f"BA{i}:BC{i}"][0]]:
            add_color_comment(ws_103[f"BA{i}"], RED, "请检查兼任职务信息！", result[personnel_code])
        if "否" in str(ws_103[f"AZ{i}"].value) and None not in [x.value for x in ws_103[f"BA{i}:BC{i}"][0]]:
            add_color_comment(ws_103[f"BA{i}"], RED, "请检查兼任职务信息！", result[personnel_code])

        # 8.机构名称
        code = str(ws_103[f"X{i}"].value).lstrip("0")
        if code in dict_1072.keys() and code in dict_mb.keys() and (dict_1072[code]["G"] not in dict_mb[code][
                "AQ"] and str(dict_mb[code]["AQ"]).strip() not in str(ws_103[f"W{i}"].value)):
            add_color_comment(ws_103[f"W{i}"], RED, f'"模板信息："{dict_mb[code]["AQ"]},{dict_1072[code]["G"]}',
                              result[personnel_code])

        # 9.岗位名称
        if code in dict_1072.keys() and dict_1072[code]["H"] != str(ws_103[f"Y{i}"].value).strip():
            add_color_comment(ws_103[f"Y{i}"], RED, f'\"岗位信息：\"{dict_1072[code]["H"]}', result[personnel_code])

        # 10.工种
        if code in dict_mb.keys() and dict_mb[code]["AU"] == "None":
            add_color_comment(ws_103[f"BY{i}"], BLUE, '模板信息为空', result[personnel_code])
        elif code in dict_mb.keys() and dict_mb[code]["AU"] != str(ws_103[f"BY{i}"].value).strip():
            add_color_comment(ws_103[f"BY{i}"], RED, f'"模板信息："{dict_mb[code]["AU"]}', result[personnel_code])

        # 11.从事专业类别名称
        if code in dict_mb.keys() and dict_mb[code]["AS"] == "None":
            add_color_comment(ws_103[f"BF{i}"], BLUE, '模板信息为空', result[personnel_code])
        elif code in dict_mb.keys() and dict_mb[code]["AS"] != str(ws_103[f"BF{i}"].value).strip():
            add_color_comment(ws_103[f"BF{i}"], RED, f'"模板信息："{dict_mb[code]["AS"]}', result[personnel_code])

        #  12.岗位分类序列
        if code + "S" in dict_1071.keys() and not (dict_1071[code + "S"]["P"][0] == dict_1071[code + "S"]["Z"][0] or (
                dict_1071[code + "S"]["P"][0] == "3" and dict_1071[code + "S"]["Z"][0] == "4")):
            add_color_comment(ws_103[f"X{i}"], RED, "岗位分类序列和薪酬标杆类别不匹配！", result[personnel_code])
        # wb_103.save(file_103)

        # 13.企业统计标识
        if "否" in str(ws_103[f"AP{i}"].value):
            add_color_comment(ws_103[f"AP{i}"], BLUE, "请核对企业统计标识！", result[personnel_code])

        # 14.总部统计唯一标识
        if "None" in str(ws_103[f"AQ{i}"].value):
            add_color_comment(ws_103[f"AQ{i}"], RED, "请核对总部统计唯一标识！", result[personnel_code])

        # 15.企业自定义分类
        for k, (x, y) in {"O": ("AD", "AE"), "P": ("AF", "AG"), "Q": ("AH", "AI")}.items():
            value = (str(ws_103[f"{x}{i}"].value) + str(ws_103[f"{y}{i}"].value)).replace(" ", "").replace("None", "")
            if code in dict_mb.keys() and value != dict_mb[code][k].replace(" ", "").replace("None", ""):
                add_color_comment(ws_103[f"{x}{i}"], RED, f'模板信息：{dict_mb[code][k]}', result[personnel_code])

        # 16.薪酬标杆类别
        for x, y in {("12", "13"): ("1",), ("15",): ("2",), ("16", "17"): ("3", "4")}.items():
            if ws_103[f"T{i}"].value in x and str(ws_103[f"BH{i}"].value)[0] not in y:
                add_color_comment(ws_103[f"BH{i}"], RED, "人员子组与薪酬标杆类别不一致！", result[personnel_code])

        # 17.成本中心
        ci, cj, ck, cl = ws_103[f"CI{i}"].value, ws_103[f"CJ{i}"].value, ws_103[f"CK{i}"].value, ws_103[f"CL{i}"].value
        if [ci, cj, ck, cl] == [None] * 4:
            add_color_comment(ws_103[f"CI{i}"], RED, "请检查机构和岗位成本中心设置！", result[personnel_code])
        if (ci is not None and ck is not None) or (ci is not None and cl is not None):
            add_color_comment(ws_103[f"CK{i}"], BLUE, "请检查岗位成本中心设置！", result[personnel_code])

        # 18.业务范围
        if ws_103[f"AL{i}"].value is None or ws_103[f"AM{i}"].value is None:
            add_color_comment(ws_103[f"AL{i}"], RED, "请检查业务范围！", result[personnel_code])

        # 19.工资总额控制范围
        if ws_103[f"AB{i}"].value is None and str(ws_103[f"Z{i}"].value).strip() != "00":
            add_color_comment(ws_103[f"AB{i}"], RED, "请核对工资总额控制范围！", result[personnel_code])

        # 20.职务岗位码
        if ws_103[f"AJ{i}"].value is None:
            add_color_comment(ws_103[f"AJ{i}"], RED, "职务岗位码需核对！", result[personnel_code])

        # 21.工作经历
        for k, v in {"BL": "BM"}.items():
            if ws_103[f"C{i}"].value != ws_103[f"{k}{i}"].value:
                add_color_comment(ws_103[f"{k}{i}"], RED, "请核对工作经历信息！", result[personnel_code])
            if ws_103[f"D{i}"].value != ws_103[f"{v}{i}"].value:
                add_color_comment(ws_103[f"{v}{i}"], RED, "请核对工作经历信息！", result[personnel_code])

        # 22.简历
        if ws_103[f"F{i}"].value != ws_103[f"BS{i}"].value or ws_103[f"BR{i}"].value != username.upper():
            add_color_comment(ws_103[f"BS{i}"], RED, "请检查简历是否生成！", result[personnel_code])

        #  23 在107-1表中检查是否存在一岗多人的情况（【B】列连续出现两个“P”）
        if code + "S" in dict_1071.keys():
            index, lis = list(dict_1071.keys()).index(code + "S"), list(dict_1071.keys())
            if len(lis) >= index + 3 and lis[index + 1][-1] == lis[index + 2][-1] == "P":
                add_color_comment(ws_103[f"X{i}"], RED, "请检查存在一岗多人情况！", result[personnel_code])
    wb_103.save(file_103)

    with DbSession() as sess:
        for key, value in result.items():
            sess.query(RZLog_detail).filter(RZLog_detail.sr == sr, RZLog_detail.code == key).update(
                {RZLog_detail.shjcjg: str(value)[:250]})


def cxly_In_Decrease(file):
    logging.info("    修改人员增减信息...")
    wb = load_workbook(file)
    ws = wb.active
    Start_date = str(ws["D7"].value).strip()
    Personnel_numbers = [str(ws[f"B{x}"].value).replace(" ", '') for x in range(7, len(list(ws["B"])) + 1) if
                         ws[f"B{x}"].value]
    session = attach_sap("login_tx")
    session.findById("wnd[0]/tbar[0]/okcd").text = "/n pa30"
    session.findById("wnd[0]").sendVKey(0)
    session.findById("wnd[0]/usr/tabsMENU_TABSTRIP/tabpTAB03").select()
    for Per_number in Personnel_numbers:
        session.findById("wnd[0]/usr/ctxtRP50G-PERNR").text = Per_number
        session.findById("wnd[0]").sendVKey(0)
        session.findById(
            "wnd[0]/usr/tabsMENU_TABSTRIP/tabpTAB03/ssubSUBSCR_MENU:SAPMP50A:0400/subSUBSCR_ITMENU:SAPMP50A:0310/tblSAPMP50ATC_MENU").getAbsoluteRow(
            7).selected = -1
        temp = session.findById(
            "wnd[0]/usr/tabsMENU_TABSTRIP/tabpTAB03/ssubSUBSCR_MENU:SAPMP50A:0400/subSUBSCR_ITMENU:SAPMP50A:0310/tblSAPMP50ATC_MENU/lblINF_EX[1,7]").ToolTip
        if "不存在" in temp:
            session.findById("wnd[0]/tbar[1]/btn[5]").press()
        else:
            session.findById(
                "wnd[0]/usr/tabsMENU_TABSTRIP/tabpTAB03/ssubSUBSCR_MENU:SAPMP50A:0400/subSUBSCR_TIME:SAPMP50A:0330/radRP50G-TIMRD").select()
            session.findById("wnd[0]/tbar[1]/btn[6]").press()
        session.findById("wnd[0]/usr/ctxtP9253-BEGDA").text = Start_date
        session.findById("wnd[0]/usr/ctxtP9253-ZZ_ZJLB").text = "19000"
        temp_v = session.findById(
            "wnd[0]/usr/subSUBSCREEN_HEADER:/1PAPAXX/HDR_80001A:0100/txt$_DG07_800A01_DTX_P0001_BTRTL").text
        session.findById("wnd[0]/usr/txtP9253-ZZ_DRCBM").text = temp_v[:12]
        session.findById("wnd[0]").sendVKey(0)
        session.findById("wnd[0]/tbar[0]/btn[11]").press()
        while "维护人力资源主数据" not in session.findById("wnd[0]/titl").text:
            session.findById("wnd[0]/tbar[0]/btn[3]").press()
    session.findById("wnd[0]/tbar[0]/btn[15]").press()
    return "ok!"


def export_verification_table(file):
    wb = load_workbook(file)
    ws = wb.active
    personnel_code = [str(ws[f"B{x}"].value).split('.')[0].replace(" ", '') for x
                      in range(7, len(list(ws["B"])) + 1) if ws[f"B{x}"].value]
    position_code = [str(ws[f"E{x}"].value).split('.')[0].replace(" ", '') for x
                     in range(7, len(list(ws["B"])) + 1) if ws[f"E{x}"].value]
    date_time = ([str(ws[f"D{x}"].value) for x in range(7, len(list(ws["B"])) + 1) if
                  len(str(ws[f"D{x}"].value)) == 8 and str(ws[f"D{x}"].value).isdigit()] + [""])[0]

    if not date_time or not personnel_code or not position_code:
        return False
    #  导出组合逻辑查询103表
    export_103rz(None, personnel_code, date_time).save_to(FILE_PATH)


def cxly_end_check(file, name_dict):
    logging.info("正在进行重新录用相关信息修改...")
    dir_path = os.path.dirname(file)
    create_work_type(file, name_dict)
    file_name = dir_path + "/重新录用_从事职业工种信息模板.xlsx"
    if os.path.exists(dir_path + "/从事职业工种信息模板.xlsx"):
        shutil.move(dir_path + "/从事职业工种信息模板.xlsx", file_name)
        batch_import(file_name, "9243->HR_BI_9243", 1)
    cxly_In_Decrease(file)
    work_types_identification(file, "B", "D")
    Organization_distribution(file)
    export_verification_table(file)
    cxly_check_103(file, FILE_PATH + "/模板_103_RZ.xlsx", dir_path + "/重新录用_1071.xlsx", dir_path + "/重新录用_1072.xlsx")
    shutil.move(f"{FILE_PATH}/模板_103_RZ.xlsx", dir_path + "/校验后_重新录用103表.xlsx")
    # upload_ftp(file, result="成功")


if __name__ == '__main__':
    file = r"x:\Users\lenovo\Desktop\1000124567-X670-员工入职-邵冬梅"
    ChongXin_LuYong(file)
