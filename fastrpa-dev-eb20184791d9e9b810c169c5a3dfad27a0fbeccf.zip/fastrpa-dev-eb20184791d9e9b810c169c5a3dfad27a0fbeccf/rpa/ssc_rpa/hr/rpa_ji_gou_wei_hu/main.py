import logging
import os
from pathlib import Path

import rpa
from rpa.fastrpa.adtable import load_from_xlsx_file
from rpa.fastrpa.xlsx import convert_xls_to_xlsx
from rpa.ssc.hr.rpa_dir import get_rpa_dir
from rpa.ssc_rpa.hr.rpa_ji_gou_wei_hu.checker.before_check import before_check
from rpa.ssc_rpa.hr.rpa_ji_gou_wei_hu.checker.FILE_HEADERS import \
    JGWHXXB_HEADER
from rpa.ssc_rpa.hr.rpa_ji_gou_wei_hu.ftp_control import (
    reset_global_file_path, reset_save_path_and_ftp_path)
from rpa.ssc_rpa.hr.rpa_ji_gou_wei_hu.sap.org_dispose import \
    update_org_name_and_resume
from rpa.ssc_rpa.hr.rpa_ji_gou_wei_hu.sap.sap_import import sap_import
from rpa.ssc_rpa.hr.rpa_ji_gou_wei_hu.tools.excel_tool import WbTool


def cutmove(working_dir, special_file, targetpath):
    if os.path.isfile(targetpath + "/" + special_file):
        os.remove(targetpath + "/" + special_file)
    os.rename(working_dir + "/" + special_file, targetpath + "/" + special_file)


def scan_files(directory, targetpath, postfix=None):
    path = directory
    for file, _, files in os.walk(path):
        for special_file in files:
            if postfix:
                if special_file.endswith(postfix):
                    cutmove(file, special_file, targetpath)
            else:
                cutmove(file, special_file, targetpath)
    os.rmdir(path)


# 剪切文件夹
def move_files(path, targetpath):
    '''
    剪切文件夹到指定路径
    path: 要剪切的路径
    targetpath: 剪切到哪个路径，此路径不存在则创建
    '''
    if not os.path.isdir(targetpath):
        os.mkdir(targetpath)
    scan_files(path, targetpath)


# 判断是否是非中层的业务单据
def is_non_middle_template(file: str) -> bool:
    import logging

    import pandas as pd
    """判断文件是否是非中层模板，是返回True，不是返回False"""
    if '组织机构维护' in Path(file).name:
        jgwhxxb_df = pd.read_excel(file, header=None, keep_default_na=False)
        A2 = jgwhxxb_df.iloc[[1], [0]].values[0][0]
        if A2 != JGWHXXB_HEADER:
            logging.info('==== A2单元格不是【机构维护信息表】，此表单不是标准表单')
            return False
        return True
    else:
        # logging.info('==== 表单名称不包含【组织机构维护】，此表单不是【非中层组织机构维护表单】！')
        return False


def normalize_template(filename: str):
    """清除单元格两边的空白，并从末尾删除B单元格为空白的行"""
    logging.info('清除单元格两边的空白，并从末尾删除B单元格为空白的行')
    lt = load_from_xlsx_file(filename, skip_header=7)
    lt.apply(lambda v: v.strip(' '))
    lt.del_blank_rows_by_column('B')
    lt.wb.save(filename)


def main(filename: str) -> bool:
    """非中层全流程，filename是非中层文件名，执行成功返回True，失败返回False"""
    reset_global_file_path()  # 重新设置全局变量SAVE_PATH保存路径, FTP_BACK_PATH ftp上传路径的值
    dir_name = Path(filename).name[:-5]  # 文件名（不包含扩展名）作为目录名称

    # 因启动方式改变，没有了下载步骤，下载步骤中初始化保存附件的目录与ftp回传目录，因此需要一个函数初始化目录。使其与ftp摘单流程一致
    local_dir, _ = reset_save_path_and_ftp_path(dir_name)

    filename = convert_xls_to_xlsx(filename)  # 检查附件是否是xls 与 清除cell的左右空格
    lt = load_from_xlsx_file(filename)
    lt.save(filename)  # 清除文件锁
    ctool = WbTool(filename)
    ctool.strip_cell_spaces()
    ctool.wb.save(local_dir + f'/{dir_name}.xlsx')
    filename = local_dir + f'/{dir_name}.xlsx'  # 把新保存在x:\rpa\files\非中层组织机构维护 下的附件表作为处理附件

    normalize_template(filename)  # 清除单元格两边的空白，并从末尾删除B单元格为空白的行

    is_check_passed = before_check(filename)  # 前置校验
    if is_check_passed is False:
        ctool = WbTool(filename)
        ctool.replace_value('AQ7', '节点提示')
        ctool.save()
        resave_path = get_rpa_dir('非中层机构维护', dir_name, is_check_passed)
        move_files(local_dir, resave_path)  # 将文件转移至标准目录
        logging.error(f'前置校验未通过，请打开目录{resave_path}，查看模板批注信息')
        return is_check_passed
    logging.info('批导前校验通过')
    sap_import(filename)  # 生成模板+批导

    is_succ = update_org_name_and_resume(filename)  # 写入双跨机构、更名、更新简历功能，返回事后校验成功或失败
    ctool = WbTool(filename)
    ctool.replace_value('AQ7', '节点提示')
    ctool.save()
    resave_path = get_rpa_dir('非中层机构维护', dir_name, is_succ)  # 将保存文件，剪切到标准路径下
    move_files(local_dir, resave_path)  # 将文件转移至标准目录
    logging.info(f'执行成功，请打开目录{resave_path}，查看模板批注信息')
    return is_succ


if __name__ == '__main__':
    from rpa.fastrpa.log import config

    filename = r"x:\dk\新建文件夹\1111\1000283496-新疆石油-组织机构维护-常金兰.xlsx"  # 当模板内容全为机构新增时，可以重复执行
    config(Path(filename).name)
    rpa.config.FSO_USERNAME = 'changjl.ssc'
    rpa.config.SAP_FUNJ = 'FUNJ0015'
    main(filename)
