import logging
import os
import time
from typing import List, Optional

import pandas
from rpa.fastrpa.adtable import load_from_xlsx_file
from rpa.fastrpa.sap.session import SapWithoutClose, close_sap
from rpa.ssc.hr.orm.dims_utils import load_tb_dim_hr_diao_pei
from rpa.ssc.hr.orm.session import DbSession
from rpa.ssc.hr.orm.td_hr_gang_wei_diao_pei_rulebase import Event
from rpa.ssc.hr.sap.export_1073 import export_1073
from rpa.ssc_rpa.hr.rpa_ji_gou_wei_hu.checker.check_must_fill import (
    DICT_COLUMN_NAMES, upload_to_ftp)
from rpa.ssc_rpa.hr.rpa_ji_gou_wei_hu.create.generate_org_info import (
    get_org_and_time, load_org_info)
from rpa.ssc_rpa.hr.rpa_ji_gou_wei_hu.ftp_control import SAVE_PATH
from rpa.ssc_rpa.hr.rpa_ji_gou_wei_hu.tools.excel_tool import WbTool

HEADER_1073_list = ['对象标识', '开始日期', '结束日期', '更改账号', '更改日期', '撤销在 ', '机构简称 ', '机构全称', '开始日期', '结束日期', '用户名', '更改日期',
                    '单位简化全称 ',
                    '开始日期 ', '结束日期', '更改账号', '更改日期', '相关对象的标识 ', '开始日期 ', '结束日期', '更改账号', '更改日期', '业务范围', '公司', 'PA',
                    'PSubarea',
                    '人事子范围 ', '开始日期 ', '结束日期', '更改账号', '更改日期', '集团/股份标识', '单位板块', '事业部类别 ', '机构层次', '单位级别', '单位业务类别',
                    '单位业务大类',
                    '单位业务分布', '机关部门管理职能分类', '分流单位类型', '单列管理单位标识', '企业规模类型', '虚机构标识 ', '开始日期 ', '结束日期', '更改账号', '更改日期',
                    '领导班子管理层级',
                    '开始日期', '结束日期', '更改账号', '更改日期', '成本中心', '订单', 'WBS元素', '开始日期 ', '结束日期', '更改账号', '更改日期', '基层机构类别大类',
                    '基层机构类别小类',
                    '开始日期', '结束日期', '更改账号', '更改日期', '油品销售企业行政属性', '油品销售企业管理层级 ', '油品销售企业业务属性 ', '开始日期 ', '结束日期', '更改账号',
                    '更改日期',
                    '加油站类型', '加油站属性', '加油站地理属性 ', '星级', '加油站营业状态', '加油站日均营业时间 ', '日开始营业时间 ', '日结束营业时间 ', '设便利店标识',
                    '设售卡网点标识 ',
                    '加油站规模', '开始日期', '结束日期', '更改日期', '用户名', '海外机构(项目)名称', '海外机构(项目)类型', '海外机构执行外派薪酬分类', '海外机构业务类别',
                    '开始日期 ', '结束日期',
                    '对应的双跨机构 ', '对应的双跨机构 ', '双跨机构属性 ', '省(自治区、直辖市)']
HEADER_1073 = list(map(lambda x: x.strip(), HEADER_1073_list))


# 生成1073
def export_1073_by_condition(filename: str, filter_column_letter: str, col: str, key_list: Optional[List[str]] = None, save_name: Optional[str] = None) -> Optional[str]:
    """根据模板（filename），以及选定的列，过滤特定值，并导出1073
       对应SAP口令: /n S_PH0_48000513

    Args:
        filename (str): 模板文件名（全路径）
        filter_column_letter (str): 过滤字段名，如：组织机构编码
        col (str): 待校验字段名，如：组织机构编码
        key_list ([type], optional): 过滤值的列表. Defaults to None.
        save_name ([type], optional): 1073文件名（短名）. Defaults to None.

    Returns:
        Optional[str]: 导出成功则返回1073文件名（全路径），否则返回None

    出错时抛出异常raise Exception('未选取数据')
    """
    clean_df = load_org_info(filename)
    if key_list:
        filter_df = clean_df[clean_df[f'{filter_column_letter}'].isin(key_list)].copy()  # 取过滤字段为关键字的
    else:
        filter_df = clean_df[~clean_df[f'{filter_column_letter}'].isin([''])].copy()  # 取过滤字段不为空的
    indexes = filter_df['序号'].to_list()

    if indexes:  # 如果过滤之后有数据
        job_ids = filter_df[f'{col}'].to_list()
        key_date = filter_df['开始日期'].to_list()[0]
        WbTool(filename)
        lt_1073 = export_1073(None, job_ids, key_date)
        if not save_name:  # 下载sap中的表格
            file_1073_name = f'组合逻辑查询{col}校验1073'  # file_1073 = SAVE_PATH + '/' + f'组合逻辑查询{col}校验1073.xlsx'
        else:
            file_1073_name = f'{save_name}'
        lt_1073.filename = file_1073_name
        _1073_filename = lt_1073.save_to(SAVE_PATH)
        logging.info('===== 【1073表 下载成功】 =====')
        logging.info(f'文件名为：{_1073_filename}')
        return _1073_filename
    return None  # 过滤后没有对应数据，不需要导出1073，不需要执行校验


def check_1073_logic(filename: str, filter_column_letter: str, col: str, key_list=None, save_name=None):
    """
    TODO: 这个函数抽象不合理，既导出数据，又做校验，后续导出数据功能逐步迁移至export_1073_by_condition，
          校验部分逻辑转移至各规则函数内执行，待所有调用迁移后，该函数废弃。
    :param filename:附件
    :param filter_column_letter:过滤字段
    :param col: 校验字段
    :param key_list:过滤值的列表
    :return:
    """
    _1073_filename = export_1073_by_condition(filename, filter_column_letter, col, key_list, save_name)
    if isinstance(_1073_filename, str) is True:
        clean_df = load_org_info(filename)
        if key_list:
            filter_df = clean_df[clean_df[f'{filter_column_letter}'].isin(key_list)].copy()  # 取过滤字段为关键字的
        else:
            filter_df = clean_df[~clean_df[f'{filter_column_letter}'].isin([''])].copy()  # 取过滤字段不为空的
        indexes = filter_df['序号'].to_list()
        job_ids = filter_df[f'{col}'].to_list()
        # key_date = filter_df['开始日期'].to_list()[0]
        wt_file = WbTool(filename)
        # 删除重复的对象标识列
        df_1073 = pandas.read_excel(_1073_filename, converters={'PSubarea': str, '领导班子管理层级': str})
        obj_ids = df_1073['对象标识'].to_list()  # 获取1073表中的【对象标识列】

        # 校验1073 中对象标识 与 附件表中的查询字段 是否对应
        for i in range(len(job_ids)):
            if int(job_ids[i]) not in obj_ids:
                wt_file.set_comment(f'{DICT_COLUMN_NAMES[col]}{int(indexes[i]) + 7}', f'{col}有误！')
                logging.info(f'     {DICT_COLUMN_NAMES[col]}{int(indexes[i]) + 7}{col}有误！')
                wt_file.set_red_comment_type1(f'AN{int(indexes[i]) + 7}')
                wt_file.concat_value(f'AO{int(indexes[i]) + 7}', f'{DICT_COLUMN_NAMES[col]}、')
        wt_file.save()
        close_sap()
        return True
    else:
        logging.warning(f'【{filter_column_letter}】字段没有过滤出数据，不需要生成1073表！')


# 检查是否出错。
def check_error(filename: str):
    df_org_info = load_org_info(filename)
    is_success = df_org_info['是否成功'].to_list()
    if any(['批导前校验出错' in s for s in is_success]) is True:
        xuhao = df_org_info['序号'].to_list()
        error_msg = df_org_info['是否成功'].to_list()
        upload_to_ftp(filename, '失败', '逻辑性校验未通过', xuhao, error_msg)
        logging.info('【逻辑性校验】失败')
        logging.info('=========== 【逻辑性校验】失败，流程中断！ ===========')
        raise Exception('=========== 【逻辑性校验】失败，流程中断！ ===========')


# 1.3.1 逻辑性校验-检验【机构维护信息表-【B-机构维护类型】】的值为【机构新增】的行，组织机构编码是否存在于MDM中
"""
锁定【机构维护信息表-【B-机构维护类型】】的值为【码表库-【DR3-机构新增】】的行，进入SAP，输入口令“/n zhrom023_1”，回车，
先在【有效性】字段里输入【机构维护信息表-【I-开始日期】】和“99991231”，再在【对象标识】字段里按序输入【机构维护信息表-【C-组织机构编码】】，
回车，判断是否有红色报错提示，若有，见1；若没有，见2。

1.若有红色报错提示，则将报错内容填入【机构维护信息表-【C-组织机构编码】】批注中，执行下一规则；
2.跳转执行下一规则。
"""


def chk_1_3_1(filename: str):
    logging.info('1.3.1 逻辑性校验-检验【机构维护信息表-【B-机构维护类型】】的值为【机构新增】的行，组织机构编码是否存在于MDM中')
    org_list, start_time_list, xh = get_org_and_time(filename)
    if len(org_list) == 0:
        logging.warning('机构维护类型为【机构新增】的数据不存在，不执行此流程')
        return
    with SapWithoutClose() as session:
        session.findById("wnd[0]").maximize()
        session.findById("wnd[0]").sendVKey(0)
        session.findById("wnd[0]/tbar[0]/okcd").text = "/n zhrom023_1"
        session.findById("wnd[0]/tbar[0]/btn[0]").press()
        error_index = []
        footer_error_list = []
        for i in range(len(org_list)):
            start_time = str(start_time_list[i][:4]) + '.' + str(start_time_list[i][4:6]) + '.' + str(
                start_time_list[i][6:])
            session.findById("wnd[0]/usr/ctxtPM0D1-SEARK").text = str(org_list[i])
            session.findById("wnd[0]/usr/ctxtPPHDR-BEGDA").text = start_time
            session.findById("wnd[0]/usr/ctxtPM0D1-SEARK").caretPosition = 8
            session.findById("wnd[0]").sendVKey(0)
            time.sleep(1)
            footer_error = session.findById("wnd[0]/sbar/pane[0]").text
            if footer_error:
                footer_error_list.append(footer_error)
                error_index.append(i + 1)
                session.findById("wnd[0]/tbar[0]/okcd").text = "/n zhrom023_1"
                session.findById("wnd[0]/usr/ctxtPM0D1-SEARK").caretPosition = 12
                session.findById("wnd[0]/tbar[0]/btn[0]").press()
        close_sap()
        if error_index:
            error_xh = []  # 校验失败数据的序号列表
            for i in error_index:
                error_xh.append(int(xh[i - 1]))
            ctool = WbTool(filename)
            for i in range(len(error_xh)):
                ctool.set_comment(f'{DICT_COLUMN_NAMES["组织机构编码"]}{error_xh[i] + 7}', f'{footer_error_list[i]}')
                logging.info(f'     {DICT_COLUMN_NAMES["组织机构编码"]}{error_xh[i] + 7}{footer_error_list[i]}')
                ctool.set_red_comment_type1(f'AN{error_xh[i] + 7}')
                ctool.concat_value(f'AO{error_xh[i] + 7}', f'{DICT_COLUMN_NAMES["组织机构编码"]}、')
            ctool.save()
        # 检查是否出错
        # check_error(filename)


# 1.3.1.2 机构新增-组织机构编码-逻辑性校验
"""
锁定【机构维护信息表-【B-机构维护类型】】的值为【码表库-【DR4 和 DR5】】的行，进入SAP，输入口令“/n S_PH0_48000513”，回车，【操作部分现场演示】，先在【对象标识】字段里输入【机构维护信息表-【C-组织机构编码】】，再在【报告期间】字段里选择【其他期间】，依次输入【机构维护信息表-【I-开始日期】】和“99991231”，回车，判断是否有提示“未选取数据”：
1.未提示“未选取数据”，则下载数据，先在【机构维护信息表-【C-组织机构编码】】中匹配与【1073-【A-对象标识】】相同的机构编码，若匹配不成功，继续匹配下一机构编码，直至所有机构编码匹配完成；若匹配成功，
          检验【1073-【E-更改日期】】是否在事件执行日期之前，若是，见1；
2.提示“未选取数据”，执行下一规则。
---------------------------
1.若“匹配不成功”，则在【机构维护信息表-【C-组织机构编码】】插入批注“组织机构编码事件执行日期之前已存在于系统中，RPA不予操作！”，执行下一规则。
"""


def chk_1_3_1_2(filename: str):
    logging.info('1.3.1.2 逻辑性校验-检验【机构维护信息表-【B-机构维护类型】】的值为【机构更名】和【机构调整】的行，组织机构编码是否存在于系统中')
    # TODO
    lt = load_from_xlsx_file(filename, skip_header=7)
    df = lt.to_dataframe()
    df_tmp = df[df['B'].isin(['机构更名', '机构调整'])]
    if df_tmp.empty is True:
        return
    with SapWithoutClose() as session:
        session.findById("wnd[0]/tbar[0]/okcd").text = "/n S_PH0_48000513"
        session.findById("wnd[0]").sendVKey(0)
        # TODO 待演示

        # IF NOT MATCH
        # lt['C'][0].cmt('red', '组织机构编码事件执行日期之前已存在于系统中，RPA不予操作！')


# 1.3.2 逻辑性校验-检验【机构维护信息表-【B-机构维护类型】】的值为【机构更名】和【机构调整】的行，组织机构编码是否存在于系统中
"""
"锁定【机构维护信息表-【B-机构维护类型】】的值为【码表库-【DR4 和 DR5】】的行，进入SAP，输入口令“/n S_PH0_48000513”，回车，【操作部分现场演示】，
先在【对象标识】字段里输入【机构维护信息表-【C-组织机构编码】】，再在【报告期间】字段里选择【其他期间】，
依次输入【机构维护信息表-【I-开始日期】】和“99991231”，回车，判断是否有提示“未选取数据”：
1.未提示“未选取数据”，则下载数据，先在【机构维护信息表-【C-组织机构编码】】中匹配与【1073-【A-对象标识】】相同的机构编码，若匹配不成功，见1；
    若匹配成功，则提取1073的【AW领导班子管理层级】判断其值是否为码表库【ET3至ET6】的数据，如果不是见2；如果是见4；
    再提取同一个【机构维护信息表-【C-组织机构编码】】的【1073-【C-结束日期】】，检验其是否存在99991231（若同一个机构编码有多行，只要任一行存在99991231即可），
    若不存在，见5；若存在，见2；
2.提示“未选取数据”，见3。
-------------------------------------------------------
1.若“匹配不成功”，则在【机构维护信息表-【C-组织机构编码】】插入批注“组织机构编码有误！”，执行下一规则；
2.跳转执行下一规则；
3.若提示“未选取数据”，则在【机构维护信息表-【C-组织机构编码】】插入批注“组织机构编码有误！”，执行下一规则。
4.【机构维护信息表-【C-组织机构编码】】插入批注“不维护中层及以上机构”，执行下一规则。
5.若“不存在”，则在【机构维护信息表-【C-组织机构编码】】插入批注“该机构已被定界！”，执行下一规则。
"""


def chk_1_3_2(filename: str):
    is_check_passed = True
    logging.info('1.3.2 逻辑性校验-检验【机构维护信息表-【B-机构维护类型】】的值为【机构更名】和【机构调整】的行，组织机构编码是否存在于系统中')
    with DbSession() as db_session:
        # 数据库获取规则  # 机构更名、机构调整
        DR4_DR5 = [list(i)[0] for i in db_session.query(Event.db_DR).all() if list(i)[0] != ''][1:3]  # pylint: disable=fixme, no-member
        ET3_to_ET6 = [k[2:] for k in [list(i)[0] for i in db_session.query(Event.db_ET).all()][0:4]]  # pylint: disable=fixme, no-member
        logging.info(f'ET3到ET6的值：{ET3_to_ET6}')
        flag = check_1073_logic(filename, '机构维护类型', '组织机构编码', DR4_DR5)  # flag = True:生产1073了
        if flag:
            _1073_filename = os.path.join(SAVE_PATH, '组合逻辑查询组织机构编码校验1073.xlsx')
            lt_1073 = load_from_xlsx_file(_1073_filename)
            df_1073 = lt_1073.to_dataframe()
            lt_org_info = load_from_xlsx_file(filename, skip_header=7)
            df_org_info = lt_org_info.to_dataframe()
            df_org_info = df_org_info[df_org_info['B'].isin(DR4_DR5)].copy()
            is_match = False
            for rn in df_org_info.index:
                _c = df_org_info['C'][rn]
                if _c in df_1073['A'].values:
                    is_match = True
                    df_tmp = df_1073[df_1073['A'] == _c]
                    if df_tmp.empty is False:
                        if df_tmp['AW'].values[0] != '':
                            if df_tmp['AW'].values[0] not in ET3_to_ET6:
                                continue  # 2.
                            else:
                                is_check_passed = False
                                lt_org_info['C'][rn].cmt('red', '不维护中层及以上机构')  # 4.
                                lt_org_info['AN'][rn].value = '批导前校验出错'
                        if '9999.12.31' not in df_tmp['C'].values and '99991231' not in df_tmp['C'].values:
                            is_check_passed = False
                            lt_org_info['C'][rn].cmt('red', '该机构已被定界！')  # 5.
                            lt_org_info['AN'][rn].value = '批导前校验出错'
                        else:
                            continue  # 2.
                    elif is_match is False:
                        is_check_passed = False
                        lt_org_info['C'][rn].cmt('red', '组织机构编码有误！')  # 1.
                        lt_org_info['AN'][rn].value = '批导前校验出错'
            lt_org_info.save(filename)
        return is_check_passed


# 1.3.3逻辑性校验-检验【机构维护信息表-【G-上级机构编码】】的值是否存在于系统中
"""
"锁定【机构维护信息表-【G-上级机构编码】】不为空的单元格，进入SAP，输入口令“/n S_PH0_48000513”，回车，【操作部分现场演示】，
先在【对象标识】字段里输入【机构维护信息表-【G-上级机构编码】】，再在【报告期间】字段里选择【其他期间】，
依次输入【机构维护信息表-【I-开始日期】】和“99991231”，回车，判断是否有提示“未选取数据”：
1.未提示“未选取数据”，则下载数据，先在【机构维护信息表-【G-上级机构编码】】中匹配与【1073-【A-对象标识】】相同的机构编码，若匹配不成功，见1；若匹配成功，见2；
若匹配成功，则提取同一个【机构维护信息表-【C-组织机构编码】】的【1073-【C-结束日期】】，检验其是否存在99991231（若同一个机构编码有多行，只要任一行存在99991231即可），若不存在，见4；若存在，见2；
2.提示“未选取数据”，见3。"

1.若“匹配不成功”，则在【机构维护信息表-【G-上级机构编码】】插入批注“上级机构编码有误！”，执行下一规则；
2.跳转执行下一规则；
3.若提示“未选取数据”，则在【机构维护信息表-【G-上级机构编码】】插入批注“上级机构编码有误！”，执行下一规则
"""


def chk_1_3_3(filename: str) -> bool:
    logging.info('1.3.3 逻辑性校验-检验【机构维护信息表-【G-上级机构编码】】的值是否存在于系统中')
    lt_org_info = load_from_xlsx_file(filename, skip_header=7)
    df_org_info = lt_org_info.to_dataframe()
    is_check_passed = True
    try:
        _1073_filename = export_1073_by_condition(filename, '上级机构编码', '上级机构编码')
    except Exception as e:
        if str(e) == '未选取数据':
            for row in lt_org_info.rows:
                row['G'].cmt('red', '上级机构编码有误！')  # 3.
                row['AN'].value = '批导前校验出错'
            is_check_passed = False
            return is_check_passed
        else:
            logging.error(f'规则1.3.3导出1073遇到问题，错误：{e}')  # 其他原因：SAP导出1073遇到错误
            is_check_passed = False
            return is_check_passed
    if _1073_filename is not None:
        lt_1073 = load_from_xlsx_file(_1073_filename)
        df_1073 = lt_1073.to_dataframe()
        _1073_obj_ids = list(df_1073['A'].values)
        for rn in df_org_info.index:
            if df_org_info['G'][rn] not in _1073_obj_ids:
                is_check_passed = False
                lt_org_info['G'][rn].cmt('red', '上级机构编码有误！')  # 1.
                lt_org_info['AN'][rn].value = '批导前校验出错'
            else:
                _c = df_org_info['C'][rn]
                df_tmp = df_1073[df_1073['A'] == _c]
                if df_tmp.empty is False:
                    if '9999.12.31' not in df_tmp['C'].values and '99991231' not in df_tmp['C'].values:
                        lt_org_info['G'][rn].cmt('red', '该机构已被定界！')  # 4.
                        lt_org_info['AN'][rn].value = '批导前校验出错'
                    else:
                        continue  # 2.
    else:
        logging.info('规则1.3.3【G-上级机构编码】字段没有过滤出数据，不需要生成1073表！')
    return is_check_passed


def chk_1_3_3_2(filename: str):  # 机构更名/调整-隶属机构调整需求确认-逻辑性校验
    """逻辑性校验-确认是否是调整隶属机构的需求
       ------------------------------------
       先锁定【机构维护信息表-【B-机构维护类型】】的值为【码表库-【DR4 和 DR5】】的行，检验【机构维护信息表-【AQ-节点提示】】的值是否下述二者之一：
       “需要调整隶属机构” 或 为空，若不是，见1；若是，见2；
       再锁定【机构维护信息表-【B-机构维护类型】】的值为【码表库-【DR3 和 DR6】】的行，检验【机构维护信息表-【AQ-节点提示】】是否为空，若不为空，见3。
       ------------------------------------
       1.若“不是”，则在【机构维护信息表-【AQ-节点提示】】插入批注“此处码值仅能为下述二者之一：“需要调整隶属机构” 或 为空！”，执行下一规则；
       2.跳转执行下一规则；
       3.若不为空，则在【机构维护信息表-【AQ-节点提示】】插入批注“机构新增和撤销不需填写，请清空！”，执行下一规则。
    """
    logging.info('1.3.3.2 机构更名/调整-隶属机构调整需求确认-逻辑性校验')
    dims = load_tb_dim_hr_diao_pei()
    dr3 = dims['DR'][3].value
    dr4 = dims['DR'][4].value
    dr5 = dims['DR'][5].value
    dr6 = dims['DR'][6].value
    lt = load_from_xlsx_file(filename, skip_header=7)
    df = lt.to_dataframe()
    for rn in df.index:
        if df['B'][rn] in (dr4, dr5):
            if df['AQ'][rn] not in ('需要调整隶属机构', ''):
                lt['AQ'][rn].cmt('red', '此处码值仅能为下述二者之一：“需要调整隶属机构” 或 为空！', False)
        elif df['B'][rn] in (dr3, dr6):
            if df['AQ'][rn] != '':
                lt['AQ'][rn].cmt('red', '机构新增和撤销不需填写，请清空！', False)
    lt.wb.save(filename)


def chk_1_3_3_3(filename: str):  # 机构更名/调整-确认隶属机构是否发生变化
    """逻辑性校验-检验【机构维护信息表-【G-上级机构编码】】的值是否与表单一致，确认隶属机构是否发生变化
       ------------------------------------
       1. 当【机构维护信息表-【B-机构维护类型】】的值为【码表库-【DR4】】时，锁定相同的【机构维护信息表-【C-组织机构编码】】与
         【1073-【A-对象标识】】的行，提取【1073-【R-相关对象的标识】-长度为8位】单元格，与【机构维护信息表-【G-上级机构编码】】比较是否相同，若不同，见1；
       2. 当锁定【机构维护信息表-【B-机构维护类型】】的值为【码表库-【DR5】】时，锁定相同的【机构维护信息表-【C-组织机构编码】】与【1073-【A-对象标识】】的行，
          提取【1073-【R-相关对象的标识】-长度为8位】单元格，与【机构维护信息表-【G-上级机构编码】】比较是否相同：
          若不同，检验【机构维护信息表-【AQ-节点提示】】的值是否为“需要调整隶属机构”，若不是，见3；若是，见2。
          若相同，检验【机构维护信息表-【AQ-节点提示】】的值是否为空，若不是，见4；若是，见2。
       ------------------------------------
       1.若“不同”，则在【机构维护信息表-【G-上级机构编码】】插入批注“隶属机构发生变化，机构更名不允许调整隶属机构！”，执行下一规则；
       2.跳转执行下一规则；
       3.若“不是”，则在【机构维护信息表-【G-上级机构编码】】插入批注“隶属机构发生变化，但确认标识不为“需要调整隶属机构”，请核实！”，执行下一规则；
       4.若“不是”，则在【机构维护信息表-【G-上级机构编码】】插入批注“隶属机构无变化，但确认标识为“需要调整隶属机构”，请核实！”，执行下一规则。
    """
    logging.info('1.3.3.3 机构更名/调整-确认隶属机构是否发生变化')
    from rpa.ssc_rpa.hr.rpa_ji_gou_wei_hu.ftp_control import SAVE_PATH
    dims = load_tb_dim_hr_diao_pei()
    try:
        _1073_filename = os.path.join(SAVE_PATH, '组合逻辑查询组织机构编码校验1073.xlsx')
        lt_1073 = load_from_xlsx_file(_1073_filename)
    except FileNotFoundError:
        logging.info('机构新增不需要执行规则1.3.3.3')  # 全是机构新增时，前面不会导出1073，此处判断无1073文件则跳过
        return
    df_1073 = lt_1073.to_dataframe()
    df_1073['filter'] = df_1073.apply(lambda row: len(row['R']) == 8, axis=1)
    df_1073 = df_1073[df_1073['filter'] == True]  # noqa: E712
    dr4 = dims['DR'][4].value
    dr5 = dims['DR'][5].value
    lt = load_from_xlsx_file(filename, skip_header=7)
    df = lt.to_dataframe()
    for rn in df.index:
        if df['B'][rn] == dr4:
            _c = df['C'][rn]
            _g = df['G'][rn]
            df_tmp = df_1073[df_1073['A'] == _c]
            if df_tmp.empty is False:
                if df_tmp['R'].values[0] != _g:  # 1 - 1
                    lt['G'][rn].cmt('red', '隶属机构发生变化，机构更名不允许调整隶属机构！', False)
                    if lt['AQ'][rn].value == '':
                        lt['AQ'][rn].value = 'G'
                    else:
                        lt['AQ'][rn].value = lt['AQ'][rn].value + '、G'
                    lt['AN'][rn].value = '批导前校验出错'
                    lt['AN'][rn].set_fgcolor('red')
        elif df['B'][rn] == dr5:
            _c = df['C'][rn]
            _g = df['G'][rn]
            df_tmp = df_1073[df_1073['A'] == _c]
            if df_tmp.empty is False:
                if df_tmp['R'].values[0] != _g:
                    if df['AQ'][rn] != '需要调整隶属机构':  # 2-3
                        lt['G'][rn].cmt('red', '隶属机构发生变化，但确认标识不为“需要调整隶属机构”，请核实！', False)
                        if lt['AQ'][rn].value == '':
                            lt['AQ'][rn].value = 'G'
                        else:
                            lt['AQ'][rn].value = lt['AQ'][rn].value + '、G'
                        lt['AN'][rn].value = '批导前校验出错'
                        lt['AN'][rn].set_fgcolor('red')
                    else:  # 2-2
                        continue
                elif df['AQ'][rn] != '':  # 2-4
                    lt['G'][rn].cmt('red', '隶属机构无变化，但确认标识为“需要调整隶属机构”，请核实！', False)
                    if lt['AQ'][rn].value == '':
                        lt['AQ'][rn].value = 'G'
                    else:
                        lt['AQ'][rn].value = lt['AQ'][rn].value + '、G'
                    lt['AN'][rn].value = '批导前校验出错'
                    lt['AN'][rn].set_fgcolor('red')
                else:  # 2-2
                    continue
    lt.wb.save(filename)


# 1.3.4 逻辑性校验-检验【机构维护信息表-【V-主成本中心】】的值是否已在系统中建立
"""
"锁定【机构维护信息表-【V-主成本中心】】不为空的单元格，进入SAP，输入口令“/n ks02”，回车，
在弹出的【设置成本控制范围-【控制范围】】字段输入“SINO”，点击【确认】，将【机构维护信息表-【V-主成本中心】】输入，点击【主数据】，判断是否有提示“成本中心“编码”不存在”：
1.未提示“成本中心“编码”不存在”，则先比较【基本数据-【公司代码】】与【机构维护信息表-【AR-人事范围】】的值是否相同，若相同，见1；

若不相同，见2；再比较【基本数据-【业务范围】】与【机构维护信息表-【AV-业务范围】（前四位字段-数字与英文）】的值是否相同，若相同，见1；若不相同，见3；
2.提示“成本中心“编码”不存在”，见4。"

1.继续下一成本中心继续检查，所有成本中心检查完毕后跳转执行下一规则；
2.若“不相同”，则在【机构维护信息表-【AR-人事范围】】插入批注“人事范围与成本中心关联的公司代码不一致：“关联的公司代码”！”，执行下一规则；
3.若“不相同”，则在【机构维护信息表-【AV-业务范围】】插入批注“人事范围与成本中心关联的业务范围不一致：“关联的业务范围”！”，执行下一规则；
4.若提示““成本中心“编码”不存在””，则在【机构维护信息表-【V-主成本中心】】插入批注“主成本中心尚未在系统中建立！”，执行下一规则。
"""


def chk_1_3_4(filename: str):
    logging.info('1.3.4 逻辑性校验-检验【机构维护信息表-【V-主成本中心】】的值是否已在系统中建立')
    clean_df = load_org_info(filename)
    filter_df = clean_df[~clean_df['主成本中心'].isin([''])].copy()
    xh = filter_df['序号'].to_list()
    cbzx = filter_df['主成本中心'].to_list()
    rsfw = filter_df['人事范围'].to_list()
    fujianywfw = filter_df['业务范围'].to_list()
    if len(cbzx) == 0:
        logging.info('模板主成本中心均为空，跳过修改KS02')
        return
    # sap
    with SapWithoutClose() as session:
        session.findById("wnd[0]").maximize()
        session.findById("wnd[0]").sendVKey(0)
        session.findById("wnd[0]/tbar[0]/okcd").text = "/n ks02"
        session.findById("wnd[0]/tbar[0]/btn[0]").press()
        logging.warning('20201224 SAP系统调整，不需要输入SINO直接可以输入成本中心')
        try:
            session.findById("wnd[1]/usr/sub:SAPLSPO4:0300/ctxtSVALD-VALUE[0,21]").text = "SINO"
            session.findById("wnd[1]/usr/sub:SAPLSPO4:0300/ctxtSVALD-VALUE[0,21]").caretPosition = 4
            session.findById("wnd[1]/tbar[0]/btn[0]").press()
        except Exception:  # nosec
            pass  # 20201224 SAP系统调整，不需要输入SINO直接可以输入成本中心
        ctool = WbTool(filename)
        for i in range(len(cbzx)):
            flag = True
            session.findById("wnd[0]/usr/ctxtCSKSZ-KOSTL").text = cbzx[i]
            session.findById("wnd[0]/tbar[1]/btn[5]").press()
            time.sleep(1)
            footer_error = session.findById("wnd[0]/sbar/pane[0]").text
            if '不存在' in footer_error:  # 如果底部信息包含’不存在‘
                ctool.set_comment(f'{DICT_COLUMN_NAMES["主成本中心"]}{int(xh[i]) + 7}', '主成本中心尚未在系统中建立！')
                logging.info(f'     {DICT_COLUMN_NAMES["主成本中心"]}{int(xh[i]) + 7}主成本中心尚未在系统中建立！')
                ctool.set_red_comment_type1(f'AN{int(xh[i]) + 7}')
                ctool.concat_value(f'AO{int(xh[i]) + 7}', f'{DICT_COLUMN_NAMES["主成本中心"]}、')
                ctool.save()
                flag = False
            else:
                # 获取公司代码
                gsdm = session.findById(
                    "wnd[0]/usr/tabsTABSTRIP_EINZEL/tabpGRUN/ssubSUBSCREEN_EINZEL:SAPLKMA1:0300/ctxtCSKSZ-BUKRS").text
                # 获取业务范围
                ywfw = session.findById(
                    "wnd[0]/usr/tabsTABSTRIP_EINZEL/tabpGRUN/ssubSUBSCREEN_EINZEL:SAPLKMA1:0300/ctxtCSKSZ-GSBER").text
                if gsdm != '' and gsdm != rsfw[i]:
                    ctool.set_comment(f'{DICT_COLUMN_NAMES["人事范围"]}{int(xh[i]) + 7}', '人事范围与成本中心关联的公司代码不一致：“关联的公司代码”！')
                    logging.info(f'     {DICT_COLUMN_NAMES["人事范围"]}{int(xh[i]) + 7}人事范围与成本中心关联的公司代码不一致：“关联的公司代码”！')
                    ctool.set_red_comment_type1(f'AN{int(xh[i]) + 7}')
                    ctool.concat_value(f'AO{int(xh[i]) + 7}', f'{DICT_COLUMN_NAMES["人事范围"]}')
                if ywfw != '' and ywfw != fujianywfw[i][0:4]:
                    ctool.set_comment(f'{DICT_COLUMN_NAMES["业务范围"]}{int(xh[i]) + 7}', '人事范围与成本中心关联的业务范围不一致：“关联的业务范围”！')
                    logging.info(f'     {DICT_COLUMN_NAMES["业务范围"]}{int(xh[i]) + 7}人事范围与成本中心关联的业务范围不一致：“关联的业务范围”！')
                    ctool.set_red_comment_type1(f'AN{int(xh[i]) + 7}')
                    ctool.concat_value(f'AO{int(xh[i]) + 7}', f'{DICT_COLUMN_NAMES["业务范围"]}')
            if flag:
                session.findById("wnd[0]/tbar[0]/btn[3]").press()
        ctool.save()
        close_sap()


# 1.3.5 逻辑性校验-检验【机构维护信息表-【AK-对应的主体机构编码】】的值是否存在于系统中
"""
"锁定【机构维护信息表-【AK-对应的主体机构编码】】不为空的单元格，进入SAP，输入口令“/n S_PH0_48000513”，回车，
【操作部分现场演示】，先在【对象标识】字段里输入【机构维护信息表-【AK-对应的主体机构编码】】，再在【报告期间】字段里选择【其他期间】，
依次输入【机构维护信息表-【I-开始日期】】和“99991231”，回车，判断是否有提示“未选取数据”：
1.未提示“未选取数据”，则下载数据，先在【机构维护信息表-【AK-对应的主体机构编码】】中匹配与【1073-【A-对象标识】】相同的机构编码，若匹配不成功，见1；若匹配成功，见2；
2.提示“未选取数据”，见3。"

"1.若“匹配不成功”，则在【机构维护信息表-【AK-对应的主体机构编码】】插入批注“对应的主体机构编码有误！”，执行下一规则；
2.跳转执行下一规则；
3.若提示“未选取数据”，则在【机构维护信息表-【AK-对应的主体机构编码】】插入批注“对应的主体机构编码有误！”，执行下一规则。"

"""


def chk_1_3_5(filename: str):
    logging.info('1.3.5 逻辑性校验-检验【机构维护信息表-【AK-对应的主体机构编码】】的值是否存在于系统中')
    return check_1073_logic(filename, '对应的主体机构编码', '对应的主体机构编码')


# 1.3.6 逻辑性校验-检验【机构维护信息表-【AL-对应的映射机构编码】】的值是否存在于系统中
"""
"锁定【机构维护信息表-【AL-对应的映射机构编码】】不为空的单元格，进入SAP，输入口令“/n S_PH0_48000513”，回车，【操作部分现场演示】，先在【对象标识】字段里输入【机构维护信息表-【AL-对应的映射机构编码】】，再在【报告期间】字段里选择【其他期间】，依次输入【机构维护信息表-【I-开始日期】】和“99991231”，回车，判断是否有提示“未选取数据”：
1.未提示“未选取数据”，则下载数据，先在【机构维护信息表-【AL-对应的映射机构编码】】中匹配与【1073-【A-对象标识】】相同的机构编码，若匹配不成功，见1；若匹配成功，见2；
2.提示“未选取数据”，见3。"


"1.若“匹配不成功”，则在【机构维护信息表-【AL-对应的映射机构编码】】插入批注“对应的映射机构编码有误！”，执行下一规则；
2.跳转执行下一规则；
3.若提示“未选取数据”，则在【机构维护信息表-【AL-对应的映射机构编码】】插入批注“对应的映射机构编码有误！”，执行下一规则。"


"""


def chk_1_3_6(filename: str):
    logging.info('1.3.6 逻辑性校验-检验【机构维护信息表-【AL-对应的映射机构编码】】的值是否存在于系统中')
    return check_1073_logic(filename, '对应的映射机构编码', '对应的映射机构编码')


# 逻辑性校验
def check_is_logic_correct(filename: str) -> bool:
    """逻辑校验"""
    logging.info('进行【逻辑性校验】')
    chk_1_3_1(filename)
    chk_1_3_2(filename)
    chk_1_3_3(filename)
    chk_1_3_3_2(filename)
    chk_1_3_3_3(filename)
    chk_1_3_4(filename)
    chk_1_3_5(filename)
    chk_1_3_6(filename)

    # 查看校验之后的结果
    jgwhxxb = load_org_info(filename)
    is_success = jgwhxxb['是否成功'].to_list()
    if '否' in is_success:
        xuhao = jgwhxxb['序号'].to_list()
        error_msg = jgwhxxb['是否成功'].to_list()
        upload_to_ftp(filename, '失败', '逻辑性校验未通过', xuhao, error_msg)
        logging.error('【逻辑性校验】失败')
        return False
    else:
        logging.info('【逻辑性校验】通过')
        return True


if __name__ == '__main__':
    file = r"x:\Users\Administrator\Desktop\非中层待办\无单号1-X540-组织机构维护-汪建.xlsx"
    chk_1_3_2(file)
