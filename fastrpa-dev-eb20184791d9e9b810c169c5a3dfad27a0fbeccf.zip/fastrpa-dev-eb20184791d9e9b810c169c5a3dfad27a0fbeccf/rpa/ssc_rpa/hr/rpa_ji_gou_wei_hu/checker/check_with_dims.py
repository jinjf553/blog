import logging
import re

import pandas as pd
from rpa.ssc.hr.orm.td_hr_gang_wei_diao_pei_rulebase import Event
from rpa.ssc_rpa.hr.rpa_ji_gou_wei_hu.checker.check_must_fill import (
    DICT_COLUMN_NAMES, cols_find_null, get_value_of_cols, upload_to_ftp)
from rpa.ssc_rpa.hr.rpa_ji_gou_wei_hu.create.generate_org_info import \
    load_org_info
from rpa.ssc_rpa.hr.rpa_ji_gou_wei_hu.orm.orm_ope import DbSession
from rpa.ssc_rpa.hr.rpa_ji_gou_wei_hu.tools.excel_tool import WbTool


# 数据库校验码值
def check_dims_code(file, col, db_list, comment_msg, xh=None):
    clean_df = load_org_info(file)
    if not xh:
        dwywfb_df = clean_df[~clean_df[f'{col}'].isin([''])].copy()
    else:
        dwywfb_df = clean_df[clean_df['序号'].isin(xh)].copy()
    dwywfb = dwywfb_df[f'{col}'].to_list()
    xh = dwywfb_df['序号'].to_list()
    db_dwywfb = db_list
    ctool = WbTool(file)
    for i in range(len(dwywfb)):
        if dwywfb[i] not in db_dwywfb:
            # ctool = WbTool(file)
            ctool.set_comment(f'{DICT_COLUMN_NAMES[col]}{int(xh[i]) + 7}', comment_msg)
            logging.info(f'     {DICT_COLUMN_NAMES[col]}{int(xh[i]) + 7}{comment_msg}')
            ctool.set_red_comment_type1(f'AN{int(xh[i]) + 7}')
            ctool.concat_value(f'AO{int(xh[i]) + 7}', f'{DICT_COLUMN_NAMES[col]}')
            # ctool.save()
    ctool.save()


# 校验长度
def check_len(file, col, max_len, comment_msg, xh=None):
    clean_df = load_org_info(file)
    if not xh:
        filter_df = clean_df[~clean_df[f'{col}'].isin([''])].copy()
    else:
        filter_df = clean_df[clean_df['序号'].isin(xh)].copy()
    filter_data = filter_df[f'{col}'].to_list()
    xh = filter_df['序号'].to_list()
    ctool = WbTool(file)
    for i in range(len(filter_data)):
        if len(str(filter_data[i])) > max_len:
            ctool.set_comment(f'{DICT_COLUMN_NAMES[col]}{int(xh[i]) + 7}', comment_msg)
            logging.info(f'     {DICT_COLUMN_NAMES[col]}{int(xh[i]) + 7}{comment_msg}')
            ctool.set_red_comment_type1(f'AN{int(xh[i]) + 7}')
            ctool.concat_value(f'AO{int(xh[i]) + 7}', f'{DICT_COLUMN_NAMES[col]}')
    ctool.save()


# 校验值为：是|否
def check_yes_or_no(file, col, error_msg, xh=None):
    clean_df = load_org_info(file)
    ctool = WbTool(file)
    if not xh:
        filter_df = clean_df[~clean_df[f'{col}'].isin(['是', '否'])].copy()  # 找出不是【是否】的行
    else:
        filter_df = clean_df[~clean_df[f'{col}'].isin(['是', '否']) & clean_df['序号'].isin(xh)].copy()  # 找出不是【是否】的行
    xh = filter_df['序号'].to_list()
    for i in xh:
        ctool.set_comment(f'{DICT_COLUMN_NAMES[col]}{int(i) + 7}', error_msg)
        logging.info(f'     {DICT_COLUMN_NAMES[col]}{int(i) + 7}{error_msg}')
        ctool.set_red_comment_type1(f'AN{int(i) + 7}')
        ctool.concat_value(f'AO{int(i) + 7}', f'{DICT_COLUMN_NAMES[col]}、')
    ctool.save()


# 1.4.1 组织机构简称-码值性校验
"""
锁定【机构维护信息表-【D-组织机构简称】】不为空的单元格，检验其长度是否小于等于12，若是，见1；若不是，见2。

1.跳转执行下一规则
2.若为“不是”，则在【机构维护信息表-【D-组织机构简称】】插入批注“组织机构简称长度超过12位！”，执行下一规则
"""


def chk_1_4_1(file):
    logging.info('1.4.1 组织机构简称-码值性校验')
    check_len(file, '组织机构简称', 12, '组织机构简称长度超过12位！')


# 1.4.2 组织机构全称-码值性校验
"""
锁定【机构维护信息表-【E-组织机构全称】】不为空的单元格，检验其长度是否小于等于40，若是，见1；若不是，见2。

1.跳转执行下一规则；
2.若为“不是”，则在【机构维护信息表-【E-组织机构全称】】插入批注“组织机构全称长度超过40位！”，执行下一规则

"""


def chk_1_4_2(file):
    logging.info('1.4.2 组织机构全称-码值性校验')
    check_len(file, '组织机构全称', 40, '组织机构全称长度超过40位！')


# 1.4.3 单位简化全称-码值性校验
"""
锁定【机构维护信息表-【F-单位简化全称】】不为空的单元格，检验其长度是否小于等于40，若是，见1；若不是，见2。

1.跳转执行下一规则；
2.若为“不是”，则在【机构维护信息表-【F-单位简化全称】】插入批注“单位简化全称长度超过40位！”，执行下一规则
"""


def chk_1_4_3(file):
    logging.info('1.4.3 单位简化全称-码值性校验')
    check_len(file, '单位简化全称', 40, '单位简化全称长度超过40位！')


# 1.4.4 机构审批文号-码值性校验
"""
锁定【机构维护信息表-【H-机构审批文号】】不为空的单元格，检验其长度是否小于等于20，若是，见1；若不是，见2。

1.跳转执行下一规则；
2.若为“不是”，则在【机构维护信息表-【H-机构审批文号】】插入批注“机构审批文号长度超过20位！”，执行下一规则
"""


def chk_1_4_4(file):
    logging.info('1.4.4 机构审批文号-码值性校验')
    check_len(file, '机构审批文号', 20, '机构审批文号长度超过20位！')


# 1.4.5 集团/股份标识-码值性校验
"""
锁定【机构维护信息表-【J-集团/股份标识】】不为空的单元格，检验其值是否为【码表库-【DT-集团/股份标识】】的值，若是，见1；若不是，见2。

1.跳转执行下一规则；
2.若为“不是”，则在【机构维护信息表-【J-集团/股份标识】】插入批注“集团/股份标识非码值！”，执行下一规则。
"""


def chk_1_4_5(file):
    logging.info('1.4.5 集团/股份标识-码值性校验')
    with DbSession() as session:
        db_list = [list(i)[0] for i in session.query(Event.db_DT).all() if list(i)[0] != '']  # pylint: disable=fixme, no-member
        check_dims_code(file, '集团/股份标识', db_list, '集团/股份标识非码值！')


# 1.4.6 单位板块-码值性校验
"""
锁定【机构维护信息表-【K-单位板块】】不为空的单元格，检验其值是否为【码表库-【DU-单位板块】】的值，若是，见1；若不是，见2。

"1.跳转执行下一规则；
2.若为“不是”，则在【机构维护信息表-【K-单位板块】】插入批注“单位板块非码值！”，执行下一规则。"
"""


def chk_1_4_6(file):
    logging.info('1.4.6 单位板块-码值性校验')
    with DbSession() as session:
        db_list = [list(i)[0] for i in session.query(Event.db_DU).all() if list(i)[0] != '']  # pylint: disable=fixme, no-member
        check_dims_code(file, '单位板块', db_list, '单位板块非码值！')


# 1.4.7 事业部类别-码值性校验
"""
锁定【机构维护信息表-【L-事业部类别】】不为空的单元格，检验其值是否为【码表库-【DV-事业部类别】】的值，若是，见1；若不是，见2。

"1.跳转执行下一规则；
2.若为“不是”，则在【机构维护信息表-【L-事业部类别】】插入批注“事业部类别非码值！”，执行下一规则。"
"""


def chk_1_4_7(file):
    logging.info('1.4.7 事业部类别-码值性校验')
    with DbSession() as session:
        db_list = [list(i)[0] for i in session.query(Event.db_DV).all() if list(i)[0] != '']  # pylint: disable=fixme, no-member
        check_dims_code(file, '事业部类别', db_list, '事业部类别非码值！')


# 1.4.8 机构层次-码值性校验
"""
锁定【机构维护信息表-【M-机构层次】】不为空的单元格，检验其值是否为【码表库-【DW-机构层次】】的值，若是，见1；若不是，见2。

"1.跳转执行下一规则；
1.若为“不是”，则在【机构维护信息表-【M-机构层次】】插入批注“机构层次非码值！”，执行下一规则。"
"""


def chk_1_4_8(file):
    logging.info('1.4.8 机构层次-码值性校验')
    with DbSession() as session:
        db_list = [list(i)[0] for i in session.query(Event.db_DW).all() if list(i)[0] != '']  # pylint: disable=fixme, no-member
        check_dims_code(file, '机构层次', db_list, '机构层次非码值！')


# 1.4.9 单位级别-码值性校验
"""
锁定【机构维护信息表-【N-单位级别】】不为空的单元格，检验其值是否为【码表库-【DX-机构层次】】的值，若是，见1；若不是，见2。

1.跳转执行下一规则；
2.若为“不是”，则在【机构维护信息表-【N-单位级别】】插入批注“单位级别非码值！”，执行下一规则
"""


def chk_1_4_9(file):
    logging.info('1.4.9 单位级别-码值性校验')
    with DbSession() as session:
        db_list = [list(i)[0] for i in session.query(Event.db_DX).all() if list(i)[0] != '']  # pylint: disable=fixme, no-member
        check_dims_code(file, '单位级别', db_list, '单位级别非码值！')


# 1.4.10 单位业务类别-码值性校验
"""
锁定【机构维护信息表-【O-单位业务类别】】不为空的单元格，检验其值是否为【码表库-【DY-单位业务类别】】的值，若是，见1；若不是，见2。

1.跳转执行下一规则；
2.若为“不是”，则在【机构维护信息表-【O-单位业务类别】】插入批注“单位业务类别非码值！”，执行下一规则。
"""


def chk_1_4_10(file):
    logging.info('1.4.10 单位业务类别-码值性校验')
    with DbSession() as session:
        db_list = [list(i)[0] for i in session.query(Event.db_DY).all() if list(i)[0] != '']  # pylint: disable=fixme, no-member
        check_dims_code(file, '单位业务类别', db_list, '单位业务类别非码值！')


# 1.4.11 单位业务分布-码值性校验
"""
锁定【机构维护信息表-【P-单位业务分布】】不为空的单元格，检验其值是否为【码表库-【DZ-单位业务分布】】的值，若是，见1；若不是，见2。

1.跳转执行下一规则；
2.若为“不是”，则在【机构维护信息表-【P-单位业务分布】】插入批注“单位业务分布非码值！”，执行下一规则

"""


def chk_1_4_11(file):
    logging.info('1.4.11 单位业务分布-码值性校验')
    with DbSession() as session:
        db_dwywfb = [list(i)[0] for i in session.query(Event.db_DZ).all() if list(i)[0] != '']  # pylint: disable=fixme, no-member
        check_dims_code(file, '单位业务分布', db_dwywfb, '单位业务分布非码值！')


# 1.4.12 机关部门管理职能分类-码值性校验
"""
锁定【机构维护信息表-【Q-机关部门管理职能分类】】不为空的单元格，检验其值是否为【码表库-【EA-机关部门管理职能分类】】的值，若是，见1；若不是，见2。

"1.跳转执行下一规则；
2.若为“不是”，则在【机构维护信息表-【Q-机关部门管理职能分类】】插入批注“机关部门管理职能分类非码值！”，执行下一规则。"
"""


def chk_1_4_12(file):
    logging.info('1.4.12 机关部门管理职能分类-码值性校验')
    with DbSession() as session:
        db_list = [list(i)[0] for i in session.query(Event.db_EA).all() if list(i)[0] != '']  # pylint: disable=fixme, no-member
        check_dims_code(file, '机关部门管理职能分类', db_list, '机关部门管理职能分类非码值！')


# 1.4.13 分流单位类型-码值性校验
"""
锁定【机构维护信息表-【R-分流单位类型】】不为空的单元格，检验其值是否为【码表库-【EB-分流单位类型】】的值，若是，见1；若不是，见2。

1.跳转执行下一规则；
2.若为“不是”，则在【机构维护信息表-【R-分流单位类型】】插入批注“分流单位类型非码值！”，执行下一规则
"""


def chk_1_4_13(file):
    logging.info('1.4.13 分流单位类型-码值性校验')
    with DbSession() as session:
        db_list = [list(i)[0] for i in session.query(Event.db_EB).all() if list(i)[0] != '']  # pylint: disable=fixme, no-member
        check_dims_code(file, '分流单位类型', db_list, '分流单位类型非码值！')


# 1.4.14 虚机构标识-码值性校验
"""
锁定【机构维护信息表-【S-虚机构标识】】不为空的单元格，检验其值是否为“是”或“否”，若是，见1；若不是，见2。

1.跳转执行下一规则；
2.若为“不是”，则在【机构维护信息表-【S-虚机构标识】】插入批注“虚机构标识非码值！”，执行下一规则
"""


def chk_1_4_14(file):
    logging.info('1.4.14 虚机构标识-码值性校验')
    db_list = ['是', '否']
    check_dims_code(file, '虚机构标识', db_list, '虚机构标识非码值！')


# 1.5.1 基层单位特有属性-码值性校验
"""
"检验【机构维护信息表-【T-基层机构类别大类】和【U-基层机构类别小类】】的值是否都为空，若是，见1，若不是：
1.继续检验【机构维护信息表-【T-基层机构类别大类】】的值是否为【码表库-【EF81】--- 9 其他
        若是，则检验【机构维护信息表-【U-基层机构类别小类】】的值是否为空，若为空，见1；若不为空，见2；
        若不是：
2.继续检验【机构维护信息表-【U-基层机构类别小类】】其值是否为【码表库-【EG-基层机构类别小类】】的值，若不是，见3；若是：
3.锁定【码表库-【EG对应的EF的值】】，检验【机构维护信息表-【T-基层机构类别大类】】的值是否与【码表库-【EF】】相同，若不相同，见4，若相同，见1。"

"1.跳转执行下一规则；
2.若“不为空”，则在【机构维护信息表-【U-基层机构类别小类】】插入批注“基层机构类别小类应为空！”，执行下一规则；
3.若为“不是”，则在【机构维护信息表-【U-基层机构类别小类】】插入批注“基层机构类别小类非码值！”，执行下一规则；
4.若为“不是”，则在【机构维护信息表-【T-基层机构类别大类】】插入批注“基层机构类别大类与基层机构类别小类不对应！”，执行下一规则。"
"""


def chk_1_5_1(file):
    logging.info('1.5.1 基层单位特有属性-码值性校验')
    jgwhxxb = load_org_info(file)
    filter_df = jgwhxxb[~jgwhxxb['基层机构类别大类'].isin(['']) | ~jgwhxxb['基层机构类别小类'].isin([''])].copy()  # 基层大类小类有一个不为空的df
    dalei = filter_df['基层机构类别大类'].to_list()
    xiaolei = filter_df['基层机构类别小类'].to_list()
    xh = filter_df['序号'].to_list()

    # 读取数据库
    with DbSession() as session:
        db_dl = [list(i)[0] for i in session.query(Event.db_EF).all() if list(i)[0] != '']  # pylint: disable=fixme, no-member
        db_xl = [list(i)[0] for i in session.query(Event.db_EG).all() if list(i)[0] != '']  # pylint: disable=fixme, no-member
    db_xl.append('')
    rule = list(zip(db_dl, db_xl))

    # 校验
    ctool = WbTool(file)
    for i in range(len(dalei)):
        if (dalei[i], xiaolei[i]) not in rule:
            if dalei[i] == '9 其他':
                ctool.set_comment(f'{DICT_COLUMN_NAMES["基层机构类别小类"]}{int(xh[i]) + 7}', '基层机构类别小类应为空！')
                logging.info(f'     {DICT_COLUMN_NAMES["基层机构类别小类"]}{int(xh[i]) + 7}基层机构类别小类应为空！')
                ctool.set_red_comment_type1(f'AN{int(xh[i]) + 7}')
                ctool.concat_value(f'AO{int(xh[i]) + 7}', f'{DICT_COLUMN_NAMES["基层机构类别小类"]}、')
            elif xiaolei[i] not in db_xl:
                ctool.set_comment(f'{DICT_COLUMN_NAMES["基层机构类别小类"]}{int(xh[i]) + 7}', '基层机构类别小类非码值！')
                logging.info(f'     {DICT_COLUMN_NAMES["基层机构类别小类"]}{int(xh[i]) + 7}基层机构类别小类非码值！')
                ctool.set_red_comment_type1(f'AN{int(xh[i]) + 7}')
                ctool.concat_value(f'AO{int(xh[i]) + 7}', f'{DICT_COLUMN_NAMES["基层机构类别小类"]}、')
            else:
                ctool.set_comment(f'{DICT_COLUMN_NAMES["基层机构类别大类"]}{int(xh[i]) + 7}', '基层机构类别大类与基层机构类别小类不对应！')
                logging.info(f'     {DICT_COLUMN_NAMES["基层机构类别大类"]}{int(xh[i]) + 7}基层机构类别大类与基层机构类别小类不对应！')
                ctool.set_red_comment_type1(f'AN{int(xh[i]) + 7}')
                ctool.concat_value(f'AO{int(xh[i]) + 7}', f'{DICT_COLUMN_NAMES["基层机构类别大类"]}、')
    ctool.save()


# 1.5.2 码值性校验-选填项校验-销售企业单位属性
"""
检验【机构维护信息表-【W-油品销售企业行政属性】、【X-油品销售企业管理层级】和【Y-油品销售企业业务属性】】的值是否都为空：
        若是，见1；
        若不是：
1.继续检验【机构维护信息表-【W-油品销售企业行政属性】】的值是否为【码表库-【EI-油品销售企业行政属性】】的值，若是，向下继续校验；若不是，见2；
2.继续检验【机构维护信息表-【X-油品销售企业管理层级】】的值是否为【码表库-【EJ-油品销售企业管理层级】】的值，若是，向下继续校验；若不是，见3；
3.继续检验【机构维护信息表-【Y-油品销售企业业务属性】】的值是否为【码表库-【EK-油品销售企业业务属性】】的值，若是，见1；若不是，见4

1.跳转执行下一规则；
2.若为“不是”，则在【机构维护信息表-【W-油品销售企业行政属性】】插入批注“油品销售企业行政属性非码值！”，执行下一规则；
3.若为“不是”，则在【机构维护信息表-【X-油品销售企业管理层级】】插入批注“油品销售企业管理层级非码值！”，执行下一规则；
4.若为“不是”，则在【机构维护信息表-【Y-油品销售企业业务属性】】插入批注“油品销售企业业务属性非码值！”，执行下一规则
"""


def chk_1_5_2(file):
    logging.info('1.5.2 码值性校验-选填项校验-销售企业单位属性')
    with DbSession() as session:
        db_list_xzsx = [list(i)[0] for i in session.query(Event.db_EI).all() if list(i)[0] != '']  # pylint: disable=fixme, no-member
        db_list_glcj = [list(i)[0] for i in session.query(Event.db_EJ).all() if list(i)[0] != '']  # pylint: disable=fixme, no-member
        db_list_ywsx = [list(i)[0] for i in session.query(Event.db_EK).all() if list(i)[0] != '']  # pylint: disable=fixme, no-member

    check_dims_code(file, '油品销售企业行政属性', db_list_xzsx, '油品销售企业行政属性非码值！')
    check_dims_code(file, '油品销售企业管理层级', db_list_glcj, '油品销售企业管理层级非码值！')
    check_dims_code(file, '油品销售企业业务属性', db_list_ywsx, '油品销售企业业务属性非码值！')


# 1.5.3 码值性校验-选填项校验-加油站信息
"""
码值性校验-选填项校验-加油站信息

"检验【机构维护信息表-【Z-加油站类型】、【AA-加油站属性】、【AB-加油站地理属性】、【AC-星级】、【AD-加油站营业状态】、【AE-加油站日均营业时间】、【AF-日开始营业时间】、【AG-日结束营业时间】、【AH-设便利店标识】、【AI-设售卡网点标识】和【AJ-加油站规模】】的值是否都为空：
        若是，见1；
        若不是：
1.继续检验【机构维护信息表-【Z-加油站类型】】的值是否为【码表库-【EM】】的值，若是，向下继续校验；若不是，见2；
2.继续检验【机构维护信息表-【AA-加油站属性】】的值是否为【码表库-【EN】】的值，若是，向下继续校验；若不是，见3；
3.继续检验【机构维护信息表-【AB-加油站地理属性】】的值是否为【码表库-【EO】】的值，若是，向下继续校验；若不是，见4;
4.继续检验【机构维护信息表-【AC-星级】】的值是否为【码表库-【EP】】的值，若是，向下继续校验；若不是，见5；
5.继续检验【机构维护信息表-【AD-加油站营业状态】】的值是否为【码表库-【EQ】】的值，若是，向下继续校验；若不是，见6；
6.继续检验【机构维护信息表-【AE-加油站日均营业时间】】的值是否为【码表库-【ER】】的值，若是，向下继续校验；若不是，见7；
7.提取【机构维护信息表-【AF-日开始营业时间】和【AG-日结束营业时间】】值的数字部分，若任一没有数字，见8；若有，将不足4位的数字在前面补零以满足4位，
    前两位数字和后两位数字以符号“:”分割，将生成的值反写到【机构维护信息表-【AF-日开始营业时间】和【AG-日结束营业时间】】中。
    再检验补零后的【AG-日结束营业时间】前两位数字减去【AF-日开始营业时间】的前两位数字是否等于【AE-加油站日均营业时间】的前两位数字，
    若是，向下继续校验；若不是，见9；
8.继续检验【机构维护信息表-【AH-设便利店标识】】的值是否为“是”或者“否”，若是，向下继续校验；若不是，见10；
9.继续检验【机构维护信息表-【AI-设售卡网点标识】】的值是否为“是”或者“否”，若是，向下继续校验；若不是，见11；
10.继续检验【机构维护信息表-【AJ-加油站规模】】值的长度是否小于等于50，若是，见1；若不是，见12。"

1.跳转执行下一规则；
2.若为“不是”，则在【机构维护信息表-【Z-加油站类型】】插入批注“加油站类型非码值！”，执行下一规则；
3.若为“不是”，则在【机构维护信息表-【AA-加油站属性】】插入批注“加油站属性非码值！”，执行下一规则；
4.若为“不是”，则在【机构维护信息表-【AB-加油站地理属性】】插入批注“加油站地理属性非码值！”，执行下一规则；
5.若为“不是”，则在【机构维护信息表-【AC-星级】】插入批注“星级非码值！”，执行下一规则；
6.若为“不是”，则在【机构维护信息表-【AD-加油站营业状态】】插入批注“加油站营业状态非码值！”，执行下一规则；
7.若为“不是”，则在【机构维护信息表-【AE-加油站日均营业时间】】插入批注“加油站日均营业时间非码值！”，执行下一规则；

8.若为“无数字”，则在相应的【机构维护信息表-【AF-日开始营业时间】和【AG-日结束营业时间】】插入批注“日结束营业时间与日开始营业时间之差与加油站日均营业时间码值有误！”，执行下一规则；
9.若为“不是”，则在【机构维护信息表-【AF-日开始营业时间】和【AG-日结束营业时间】】插入批注“日结束营业时间与日开始营业时间之差与加油站日均营业时间不符！”，执行下一规则；
10.若为“不是”，则在【机构维护信息表-【AH-设便利店标识】】插入批注“设便利店标识非码值！”，执行下一规则；
11.若为“不是”，则在【机构维护信息表-【AI-设售卡网点标识】】插入批注“设售卡网点标识非码值！”，执行下一规则；
12.若为“不是”，则在【机构维护信息表-【【AJ-加油站规模】】】插入批注“加油站规模长度超过50位！”，执行下一规则。
"""


def chk_1_5_3(file):
    logging.info('1.5.3 码值性校验-选填项校验-加油站信息')
    with DbSession() as session:
        # 数据库获取规则
        db_list_jyzlx = [list(i)[0] for i in session.query(Event.db_EM).all() if list(i)[0] != '']  # pylint: disable=fixme, no-member  # 加油站类型
        db_list_jyzsx = [list(i)[0] for i in session.query(Event.db_EN).all() if list(i)[0] != '']  # pylint: disable=fixme, no-member  # 加油站属性
        db_list_jyzdlsx = [list(i)[0] for i in session.query(Event.db_EO).all() if list(i)[0] != '']  # pylint: disable=fixme, no-member  # 加油站地理属性
        db_list_xingji = [list(i)[0] for i in session.query(Event.db_EP).all() if list(i)[0] != '']  # pylint: disable=fixme, no-member  # 星级
        db_list_jyzyyzt = [list(i)[0] for i in session.query(Event.db_EQ).all() if list(i)[0] != '']  # pylint: disable=fixme, no-member  # 加油站营业状态
        db_list_jyzrjyysj = [list(i)[0] for i in session.query(Event.db_ER).all() if list(i)[0] != '']  # pylint: disable=fixme, no-member  # 加油站日均营业时间
    judge_list = ['加油站类型', '加油站属性', '加油站地理属性', '星级', '加油站营业状态', '加油站日均营业时间', '日开始营业时间',
                  '日结束营业时间', '设便利店标识', '设售卡网点标识', '加油站规模']

    # 提取需要校验的行号 组成列表,如果没有符合的记录 返回空列表
    judge_xh = get_value_of_cols(file, judge_list)

    if not judge_xh:
        logging.info('涉及加油站信息数据，全部为空。跳过此校验')
        return

    # 码值校验
    check_dims_code(file, '加油站类型', db_list_jyzlx, '加油站类型非码值！', xh=judge_xh)
    check_dims_code(file, '加油站属性', db_list_jyzsx, '加油站属性非码值！', xh=judge_xh)
    check_dims_code(file, '加油站地理属性', db_list_jyzdlsx, '加油站地理属性非码值！', xh=judge_xh)
    check_dims_code(file, '星级', db_list_xingji, '星级非码值！', xh=judge_xh)
    check_dims_code(file, '加油站营业状态', db_list_jyzyyzt, '加油站营业状态非码值！', xh=judge_xh)
    check_dims_code(file, '加油站日均营业时间', db_list_jyzrjyysj, '加油站日均营业时间非码值！', xh=judge_xh)

    # 【设便利店标识】是/否校验
    check_yes_or_no(file, '设便利店标识', '设便利店标识非码值！', xh=judge_xh)
    check_yes_or_no(file, '设售卡网点标识', '设售卡网点标识非码值！', xh=judge_xh)

    # 长度校验
    check_len(file, '加油站规模', 50, '加油站规模长度超过50位！', xh=judge_xh)

    # 校验时间
    cols_find_null(file, ['日开始营业时间', '日结束营业时间'], '日结束营业时间与日开始营业时间之差与加油站日均营业时间码值有误！', xh=judge_xh)
    ctool = WbTool(file)
    clean_df = load_org_info(file)
    # 开始时间
    start_df = clean_df[~clean_df['日开始营业时间'].isin([''])].copy()
    start_xh = start_df['序号'].to_list()
    start_time = [re.sub(r'\D', '', i) for i in start_df['日开始营业时间'].to_list()]
    # 结束时间
    end_df = clean_df[~clean_df['日结束营业时间'].isin([''])].copy()
    end_time = [re.sub(r'\D', '', i) for i in end_df['日结束营业时间'].to_list()]
    end_xh = end_df['序号'].to_list()

    # 判断长度并补0
    for i in range(len(start_time)):
        if not start_time[i]:
            ctool.set_comment(f'{DICT_COLUMN_NAMES["日开始营业时间"]}{int(start_xh[i]) + 7}', '日结束营业时间与日开始营业时间之差与加油站日均营业时间码值有误！')
            logging.info(f'     {DICT_COLUMN_NAMES["日开始营业时间"]}{int(start_xh[i]) + 7}日结束营业时间与日开始营业时间之差与加油站日均营业时间码值有误！')
            ctool.set_red_comment_type1(f'AN{int(start_xh[i]) + 7}')
            ctool.concat_value(f'AO{int(start_xh[i]) + 7}', f'{DICT_COLUMN_NAMES["日开始营业时间"]}、')
        elif len(start_time[i]) < 4:
            start_time[i] = '0' * (4 - len(start_time[i])) + start_time[i]
            ctool.replace_value(f"{DICT_COLUMN_NAMES['日开始营业时间']}{int(start_xh[i]) + 7}",
                                start_time[i][:2] + ':' + start_time[i][2:])
    for i in range(len(end_time)):
        if not end_time[i]:
            ctool.set_comment(f'{DICT_COLUMN_NAMES["日结束营业时间"]}{int(end_xh[i]) + 7}', '日结束营业时间与日开始营业时间之差与加油站日均营业时间码值有误！')
            logging.info(f'     {DICT_COLUMN_NAMES["日结束营业时间"]}{int(end_xh[i]) + 7}日结束营业时间与日开始营业时间之差与加油站日均营业时间码值有误！')
            ctool.set_red_comment_type1(f'AN{int(end_xh[i]) + 7}')
            ctool.concat_value(f'AO{int(end_xh[i]) + 7}', f'{DICT_COLUMN_NAMES["日结束营业时间"]}、')
        elif len(end_time[i]) < 4:
            end_time[i] = '0' * (4 - len(end_time[i])) + end_time[i]
            ctool.replace_value(f"{DICT_COLUMN_NAMES['日结束营业时间']}{int(end_xh[i]) + 7}", end_time[i][:2] + ':' + end_time[i][2:])

    # 校验时间相减 是否 等于营业时间

    clean_df = load_org_info(file)
    start_df = clean_df[~clean_df['日开始营业时间'].isin(['']) & ~clean_df['日结束营业时间'].isin([''])].copy()
    start_time = start_df['日开始营业时间'].to_list()
    end_time = start_df['日结束营业时间'].to_list()
    yingye_time = start_df['加油站日均营业时间'].to_list()
    xh = start_df['序号'].to_list()
    for i in range(len(start_time)):
        if end_time[i][:2].isdigit() and start_time[i][:2].isdigit() and yingye_time[i][:2].isdigit():
            if int(end_time[i][:2]) - int(start_time[i][:2]) != int(yingye_time[i][:2]):
                ctool.set_comment(f'{DICT_COLUMN_NAMES["日开始营业时间"]}{int(xh[i]) + 7}', '日结束营业时间与日开始营业时间之差与加油站日均营业时间不符！')
                logging.info(f'     {DICT_COLUMN_NAMES["日开始营业时间"]}{int(xh[i]) + 7}日结束营业时间与日开始营业时间之差与加油站日均营业时间不符！')
                ctool.set_red_comment_type1(f'AN{int(xh[i]) + 7}')
                ctool.concat_value(f'AO{int(xh[i]) + 7}', f'{DICT_COLUMN_NAMES["日开始营业时间"]}、')
                ctool.set_comment(f'{DICT_COLUMN_NAMES["日结束营业时间"]}{int(xh[i]) + 7}', '日结束营业时间与日开始营业时间之差与加油站日均营业时间不符！')
                logging.info(f'     {DICT_COLUMN_NAMES["日结束营业时间"]}{int(xh[i]) + 7}日结束营业时间与日开始营业时间之差与加油站日均营业时间不符！')
                ctool.set_red_comment_type1(f'AN{int(xh[i]) + 7}')
                ctool.concat_value(f'AO{int(xh[i]) + 7}', f'{DICT_COLUMN_NAMES["日结束营业时间"]}、')
    ctool.save()


# 1.5.4 我是我校验-折中妥协
"""
锁定1.3.3下载到的1073表，先在【机构维护信息表-【G-上级机构编码】】中匹配与【1073-【A-对象标识】】相同的机构编码，
提取【1073-【Y-PA】】，若为空，见2；若不为空，经【码表库-【BD-BB】】对应，若未匹配成功，见4，
若匹配成功，得到合并机构代码-1，再提取【机构维护信息表-【AR-人事范围】】，经【码表库-【BD-BB】】对应，若未匹配成功，见5，
若匹配成功，得到合并机构代码-2，比较“合并机构代码-1”与“合并机构代码-2”是否相同 ，若相同，见1；若不相同，见3。


1.跳转执行下一规则；
2.若为“空”，则在【机构维护信息表-【AR-人事范围】】插入批注“上级机构的财务科目设置中人事范围为空，未进行我是我校验！”，执行下一规则；
3.若为“不同”，则在【机构维护信息表-【AR-人事范围】】插入批注“！”，执行下一规则；
4.若为“未匹配成功”，则在【机构维护信息表-【AR-人事范围】插入批注“上级机构编码有误！”，执行下一规则；
5.若为“未匹配成功”，则在【机构维护信息表-【AR-人事范围】插入批注“人事范围有误！”，执行下一规则。
"""


def chk_1_5_4(filename: str):
    from rpa.ssc_rpa.hr.rpa_ji_gou_wei_hu.ftp_control import SAVE_PATH
    file_1073 = SAVE_PATH + '/组合逻辑查询上级机构编码校验1073.xlsx'
    df_1073 = pd.read_excel(file_1073, dtype=str)
    df_1073['相关对象的标识'] = df_1073['相关对象的标识'].astype(str)
    df_1073['filter'] = df_1073.apply(lambda row: len(row['相关对象的标识']) == 8, axis=1)
    df_1073 = df_1073[df_1073['filter'] == True]  # noqa: E712
    df_org_info = load_org_info(filename)
    df_filter = df_org_info[~df_org_info['上级机构编码'].isin([''])]
    parent_org_ids = df_filter['上级机构编码'].to_list()
    indexes = df_filter['序号'].to_list()
    staff_rngs = df_filter['人事范围'].to_list()
    wt_file = WbTool(filename)
    for i in range(len(parent_org_ids)):
        validate_df = df_1073[df_1073['对象标识'].isin([f'{parent_org_ids[i]}'])].copy()  # 过滤1073 对象标识 = 上级机构编码的 数据
        PA = str(validate_df['PA'].to_list()[0])
        if PA == 'nan':  # 校验PA是否有值
            wt_file.set_comment(f'{DICT_COLUMN_NAMES["人事范围"]}{int(indexes[i]) + 7}', '上级机构的财务科目设置中人事范围为空，未进行我是我校验！')
            logging.error(f'{DICT_COLUMN_NAMES["人事范围"]}{int(indexes[i]) + 7}上级机构的财务科目设置中人事范围为空，未进行我是我校验！')
            wt_file.set_red_comment_type1(f'AN{int(indexes[i]) + 7}')
            wt_file.concat_value(f'AO{int(indexes[i]) + 7}', f'{DICT_COLUMN_NAMES["人事范围"]}')
        else:
            # 校验合并机构代码
            # queryset = [i for i in QueryFirst(table='Dim', db_BD=PA)][0]
            # queryset_rsfw = [i for i in QueryFirst(table='Dim', db_BD=staff_rngs[i])][0]
            with DbSession() as session:
                queryset = session.query(Event).filter(Event.db_BD == PA).first()
                queryset_rsfw = session.query(Event).filter(Event.db_BD == staff_rngs[i]).first()
                if not queryset:  # 数据库不存在此记录
                    wt_file.set_comment(f'{DICT_COLUMN_NAMES["人事范围"]}{int(indexes[i]) + 7}', '上级机构编码有误！')
                    logging.info(f'     {DICT_COLUMN_NAMES["人事范围"]}{int(indexes[i]) + 7}上级机构编码有误！')
                    wt_file.set_red_comment_type1(f'AN{int(indexes[i]) + 7}')
                    wt_file.concat_value(f'AO{int(indexes[i]) + 7}', f'{DICT_COLUMN_NAMES["人事范围"]}')

                elif not queryset_rsfw:  # 数据库不存在此记录
                    wt_file.set_comment(f'{DICT_COLUMN_NAMES["人事范围"]}{int(indexes[i]) + 7}', '人事范围有误！')
                    logging.info(f'     {DICT_COLUMN_NAMES["人事范围"]}{int(indexes[i]) + 7}人事范围有误！')
                    wt_file.set_red_comment_type1(f'AN{int(indexes[i]) + 7}')
                    wt_file.concat_value(f'AO{int(indexes[i]) + 7}', f'{DICT_COLUMN_NAMES["人事范围"]}')

                else:
                    BB_1073 = queryset.db_BB
                    BB_fujian = queryset_rsfw.db_BB
                    if BB_1073 != BB_fujian:
                        wt_file.set_comment(f'{DICT_COLUMN_NAMES["人事范围"]}{int(indexes[i]) + 7}', '上级机构与本机构对应的合并机构代码不同！')
                        logging.info(f'     {DICT_COLUMN_NAMES["人事范围"]}{int(indexes[i]) + 7}上级机构与本机构对应的合并机构代码不同！')
                        wt_file.set_red_comment_type1(f'AN{int(indexes[i]) + 7}')
                        wt_file.concat_value(f'AO{int(indexes[i]) + 7}', f'{DICT_COLUMN_NAMES["人事范围"]}')

    wt_file.save()


# 码值校验
def check_with_dims(file) -> bool:
    """码值校验"""
    logging.info('进行【码值性校验】')
    chk_1_4_1(file)
    chk_1_4_2(file)
    chk_1_4_3(file)
    chk_1_4_4(file)
    chk_1_4_5(file)
    chk_1_4_6(file)
    chk_1_4_7(file)
    chk_1_4_8(file)
    chk_1_4_9(file)
    chk_1_4_10(file)
    chk_1_4_11(file)
    chk_1_4_12(file)
    chk_1_4_13(file)
    chk_1_4_14(file)
    chk_1_5_1(file)
    chk_1_5_2(file)
    chk_1_5_3(file)
    chk_1_5_4(file)

    # 查看校验之后的结果
    df_org_info = load_org_info(file)
    is_success = df_org_info['是否成功'].to_list()
    if any(['批导前校验出错' in s for s in is_success]) is True:
        indexes = df_org_info['序号'].to_list()
        error_msg = df_org_info['是否成功'].to_list()
        upload_to_ftp(file, '失败', '码值校验未通过', indexes, error_msg)
        logging.error('【码值性校验】失败')
        return False
    else:
        logging.info('【码值性校验】通过')
        return True


if __name__ == '__main__':
    filename = r"x:\Users\Administrator\Desktop\ceshi.xlsx"
    chk_1_5_4(filename)
