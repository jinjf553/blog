import logging
import os

from rpa.ssc.hr.orm.td_hr_gang_wei_diao_pei_rulebase import Event
from rpa.ssc_rpa.hr.rpa_ji_gou_wei_hu.checker.check_must_fill import (
    DICT_COLUMN_NAMES, DICT_LETTERS, find_no_null_by_filter,
    find_null_by_filter, upload_to_ftp)
from rpa.ssc_rpa.hr.rpa_ji_gou_wei_hu.create.generate_org_info import \
    load_org_info
from rpa.ssc_rpa.hr.rpa_ji_gou_wei_hu.orm.orm_ope import DbSession
from rpa.ssc_rpa.hr.rpa_ji_gou_wei_hu.tools.excel_tool import WbTool

# 1.7.1 集团/股份标识与事业部类别-勾稽关系校验
"""
当【机构维护信息表-【J-集团/股份标识】】的值为【码表库-【DT4-2000 集团公司非上市】】时，检验【机构维护信息表-【L-事业部类别】】的值是否为空，若为空，见1；若不为空，见2；
当【机构维护信息表-【J-集团/股份标识】】的值为【码表库-【DT3-1000 中国石化股份公司】】时，检验【机构维护信息表-【L-事业部类别】】的值是否为空，若为空，见3；若不为空，见1。"

1.跳转执行下一规则；
2.若不为“空”，则在【机构维护信息表-【L-事业部类别】】插入批注“非上市公司不应填写事业部类别！”，执行下一规则；
3.若为“空”，则在【机构维护信息表-【L-事业部类别】】插入批注“上市公司应填写事业部类别！”，执行下一规则。
"""


def chk_1_7_1(filename: str):
    logging.info('1.7.1 集团/股份标识与事业部类别-勾稽关系校验')
    with DbSession() as session:
        fss = [list(i)[0] for i in session.query(Event.db_DT).all() if list(i)[0] != ''][1]  # 2000 集团公司非上市
        zshgf = [list(i)[0] for i in session.query(Event.db_DT).all() if list(i)[0] != ''][0]  # 1000 中国石化股份公司

    find_no_null_by_filter(filename, '集团/股份标识', fss, ['事业部类别'], '非上市公司不应填写事业部类别！')
    find_null_by_filter(filename, '集团/股份标识', zshgf, ['事业部类别'], '上市公司应填写事业部类别！')


# 1.7.2 单位板块与事业部类别-勾稽关系校验
"""
"当【机构维护信息表-【J-集团/股份标识】】的值为【码表库-【DT3-1000 中国石化股份公司】】时，
1.若【机构维护信息表-【K-单位板块】】的值为【码表库-【DU3-油田企业】】时，检验【机构维护信息表-【L-事业部类别】】的值是否为【码表库-【DV3】】，若是，见1；若不是，见2；
2.若【机构维护信息表-【K-单位板块】】的值为【码表库-【DU4-炼化企业】】时，检验【机构维护信息表-【L-事业部类别】】的值是否为【码表库-【DV4 或 DV5】】，若是，见1；若不是，见2；
3.若【机构维护信息表-【K-单位板块】】的值为【码表库-【DU5-销售企业】】时，检验【机构维护信息表-【L-事业部类别】】的值是否为【码表库-【DV6】】，若是，见1；若不是，见2；
4.若【机构维护信息表-【K-单位板块】】的值为【码表库-【DU7-科研单位】】时，检验【机构维护信息表-【L-事业部类别】】的值是否为【码表库-【DV7】】，若是，见1；若不是，见2。"


"1.跳转执行下一规则；
2.若为“不是”，则在【机构维护信息表-【K-单位板块】】插入批注“单位板块与事业部类别不对应！”，执行下一规则。"

"""


def chk_1_7_2(filename: str):
    logging.info('1.7.2 单位板块与事业部类别-勾稽关系校验')
    with DbSession() as session:
        zshgf = [list(i)[0] for i in session.query(Event.db_DT).all() if list(i)[0] != ''][0]  # 1000 中国石化股份公司
        DU3 = [list(i)[0] for i in session.query(Event.db_DU).all() if list(i)[0] != ''][0]  # DU3-01 油田企业
        DU4 = [list(i)[0] for i in session.query(Event.db_DU).all() if list(i)[0] != ''][1]  # DU4-02 炼化企业
        DU5 = [list(i)[0] for i in session.query(Event.db_DU).all() if list(i)[0] != ''][2]  # DU5-03 销售企业
        DU7 = [list(i)[0] for i in session.query(Event.db_DU).all() if list(i)[0] != ''][4]  # DU7-04 科研单位

        DV3 = [list(i)[0] for i in session.query(Event.db_DV).all() if list(i)[0] != ''][0]  # DV3-1 油田勘探开发事业部
        DV4 = [list(i)[0] for i in session.query(Event.db_DV).all() if list(i)[0] != ''][1]  # DV4-2 炼油事业部
        DV5 = [list(i)[0] for i in session.query(Event.db_DV).all() if list(i)[0] != ''][2]  # DV5-3 化工事业部
        DV6 = [list(i)[0] for i in session.query(Event.db_DV).all() if list(i)[0] != ''][3]  # DV6-4 油品销售事业部
        DV7 = [list(i)[0] for i in session.query(Event.db_DV).all() if list(i)[0] != ''][4]  # DV7-5 科研单位

    df_org_info = load_org_info(filename)
    df_filter = df_org_info[df_org_info['集团/股份标识'].isin([f'{zshgf}'])].copy()
    indexes = df_filter['序号'].to_list()
    jtgf = df_filter['集团/股份标识'].to_list()
    syblb = df_filter['事业部类别'].to_list()
    dwbk = df_filter['单位板块'].to_list()
    ctool = WbTool(filename)
    for i in range(len(jtgf)):
        if dwbk[i] == DU3 and syblb[i] != DV3:
            ctool.set_comment(f'{DICT_COLUMN_NAMES["单位板块"]}{int(indexes[i]) + 7}', '单位板块与事业部类别不对应！')
            logging.info(f'     {DICT_COLUMN_NAMES["单位板块"]}{int(indexes[i]) + 7}单位板块与事业部类别不对应')
            ctool.set_red_comment_type1(f'AN{int(indexes[i]) + 7}')
            ctool.concat_value(f'AO{int(indexes[i]) + 7}', f'{DICT_COLUMN_NAMES["单位板块"]}')
        if dwbk[i] == DU4 and syblb[i] not in [DV4, DV5]:
            ctool.set_comment(f'{DICT_COLUMN_NAMES["单位板块"]}{int(indexes[i]) + 7}', '单位板块与事业部类别不对应！')
            logging.info(f'     {DICT_COLUMN_NAMES["单位板块"]}{int(indexes[i]) + 7}单位板块与事业部类别不对应！')
            ctool.set_red_comment_type1(f'AN{int(indexes[i]) + 7}')
            ctool.concat_value(f'AO{int(indexes[i]) + 7}', f'{DICT_COLUMN_NAMES["单位板块"]}')
        if dwbk[i] == DU5 and syblb[i] != DV6:
            ctool.set_comment(f'{DICT_COLUMN_NAMES["单位板块"]}{int(indexes[i]) + 7}', '单位板块与事业部类别不对应！')
            logging.info(f'     {DICT_COLUMN_NAMES["单位板块"]}{int(indexes[i]) + 7}单位板块与事业部类别不对应！')
            ctool.set_red_comment_type1(f'AN{int(indexes[i]) + 7}')
            ctool.concat_value(f'AO{int(indexes[i]) + 7}', f'{DICT_COLUMN_NAMES["单位板块"]}')
        if dwbk[i] == DU7 and syblb[i] != DV7:
            ctool.set_comment(f'{DICT_COLUMN_NAMES["单位板块"]}{int(indexes[i]) + 7}', '单位板块与事业部类别不对应！')
            logging.info(f'     {DICT_COLUMN_NAMES["单位板块"]}{int(indexes[i]) + 7}单位板块与事业部类别不对应！')
            ctool.set_red_comment_type1(f'AN{int(indexes[i]) + 7}')
            ctool.concat_value(f'AO{int(indexes[i]) + 7}', f'{DICT_COLUMN_NAMES["单位板块"]}')
    ctool.save()


# 1.7.3 单位板块与销售企业特有属性-勾稽关系校验
"""
当【机构维护信息表-【K-单位板块】】的值为【码表库-【DU5-销售企业】】时，检验【机构维护信息表-【T 和 U】】的值是否不为空，若是，见1；若不是，见2；

"1.跳转执行下一规则；
2.若为“不是”，则在【机构维护信息表-【K-单位板块】】插入批注“销售企业特有属性必填！”，执行下一规则。"
"""


def chk_1_7_3(filename: str):
    logging.info('1.7.3 单位板块与销售企业特有属性-勾稽关系校验')
    with DbSession() as session:
        DU5 = [list(i)[0] for i in session.query(Event.db_DU).all() if list(i)[0] != ''][2]  # DU5-03 销售企业

    df_org_info = load_org_info(filename)
    df_filter = df_org_info[df_org_info['单位板块'].isin([f'{DU5}']) & df_org_info['机构维护类型'].isin(['机构新增'])].copy()
    xh = df_filter['序号'].to_list()
    T = df_filter[DICT_LETTERS['T']].to_list()
    U = df_filter[DICT_LETTERS['U']].to_list()
    ctool = WbTool(filename)
    for i in range(len(xh)):
        if not T[i] or not U[i]:
            ctool.set_comment(f'{DICT_COLUMN_NAMES["单位板块"]}{int(xh[i]) + 7}', '销售企业特有属性必填！')
            logging.info(f'     {DICT_COLUMN_NAMES["单位板块"]}{int(xh[i]) + 7}销售企业特有属性必填！')
            ctool.set_red_comment_type1(f'AN{int(xh[i]) + 7}')
            ctool.concat_value(f'AO{int(xh[i]) + 7}', f'{DICT_COLUMN_NAMES["单位板块"]}')
    ctool.save()


# 1.7.4 机构层次与单位业务类别、单位业务分布-勾稽关系校验-1
"""
当【机构维护信息表-【M-机构层次】】的值为【码表库-【DW9 或 DW10 或 DW11 或 DW12 或 DW26 或 DW 27】】时，
先检验【机构维护信息表-【O-单位业务类别】】的值是否为【码表库-【DY3-100 直属单位管理机关】】，若是，见1；若不是，见2；
再检验【机构维护信息表-【P-单位业务分布】】的值是否为【码表库-【DZ3-100 管理机关】】，若是，见1；若不是，见3。

"1.跳转执行下一规则；
2.若为“不是”，则在【机构维护信息表-【O-单位业务类别】】插入批注“单位业务类别应为：100 直属单位管理机关！”，执行下一规则；
3.若为“不是”，则在【机构维护信息表-【P-单位业务分布】】插入批注“单位业务分布应为：100 管理机关！”，执行下一规则。"
"""


def chk_1_7_4(filename: str):
    logging.info('1.7.4 机构层次与单位业务类别、单位业务分布-勾稽关系校验-1')
    with DbSession() as session:
        rule1 = [list(i)[0] for i in session.query(Event.db_DW).all() if list(i)[0] != ''][6:10]
        rule2 = [list(i)[0] for i in session.query(Event.db_DW).all() if list(i)[0] != ''][23:25]
        rule1.extend(rule2)  # 31 32 33 34 A0 A1
        DY3 = [list(i)[0] for i in session.query(Event.db_DY).all() if list(i)[0] != ''][0]  # 100 直属单位管理机关
        DZ3 = [list(i)[0] for i in session.query(Event.db_DZ).all() if list(i)[0] != ''][0]  # 100 管理机关

    clean_df = load_org_info(filename)
    filter_df = clean_df[clean_df['机构层次'].isin(rule1)].copy()
    xh = filter_df['序号'].to_list()
    busi_types = filter_df['单位业务类别'].to_list()
    busi_areas = filter_df['单位业务分布'].to_list()

    ctool = WbTool(filename)
    for i in range(len(xh)):
        if busi_types[i] != DY3:
            ctool.set_comment(f'{DICT_COLUMN_NAMES["单位业务类别"]}{int(xh[i]) + 7}', '单位业务类别应为：100 直属单位管理机关！')
            logging.info(f'     {DICT_COLUMN_NAMES["单位业务类别"]}{int(xh[i]) + 7}单位业务类别应为：100 直属单位管理机关！')
            ctool.set_red_comment_type1(f'AN{int(xh[i]) + 7}')
            ctool.concat_value(f'AO{int(xh[i]) + 7}', f'{DICT_COLUMN_NAMES["单位业务类别"]}')
        if busi_areas[i] != DZ3:
            ctool.set_comment(f'{DICT_COLUMN_NAMES["单位业务分布"]}{int(xh[i]) + 7}', '单位业务分布应为：100 管理机关！')
            logging.info(f'     {DICT_COLUMN_NAMES["单位业务分布"]}{int(xh[i]) + 7}单位业务分布应为：100 管理机关！')
            ctool.set_red_comment_type1(f'AN{int(xh[i]) + 7}')
            ctool.concat_value(f'AO{int(xh[i]) + 7}', f'{DICT_COLUMN_NAMES["单位业务分布"]}')
    ctool.save()


# 1.7.5 机构层次与单位业务类别、单位业务分布-勾稽关系校验-2
"""
当【机构维护信息表-【M-机构层次】】的值为【码表库-【DW15 或 DW16 或 DW31 或 DW32 或 DW33 或 DW 34】】时，
先检验【机构维护信息表-【O-单位业务类别】】的值是否不为【码表库-【DY3 或 DY4】】，若是，见1；若不是，见2；
再检验【机构维护信息表-【P-单位业务分布】】的值是否为【码表库-【DZ3-100 管理机关】】，若是，见1；若不是，见3。

1.跳转执行下一规则；
2.若为“不是”，则在【机构维护信息表-【O-单位业务类别】】插入批注“单位业务类别有误-2！”，执行下一规则；
3.若为“不是”，则在【机构维护信息表-【P-单位业务分布】】插入批注“单位业务分布应为：100 管理机关！”，执行下一规则
"""


def chk_1_7_5(filename: str):
    logging.info('1.7.5 机构层次与单位业务类别、单位业务分布-勾稽关系校验-2')
    with DbSession() as session:
        rule1 = [list(i)[0] for i in session.query(Event.db_DW).all() if list(i)[0] != ''][12:14]
        rule2 = [list(i)[0] for i in session.query(Event.db_DW).all() if list(i)[0] != ''][28:32]
        rule1.extend(rule2)  # 41  42  B0  B1  B2  B3
        DY3 = [list(i)[0] for i in session.query(Event.db_DY).all() if list(i)[0] != ''][0:2]  # 100 直属单位管理机关 110 直属单位直属机构
        DZ3 = [list(i)[0] for i in session.query(Event.db_DZ).all() if list(i)[0] != ''][0]  # 100 管理机关

    df_org_info = load_org_info(filename)
    df_filter = df_org_info[df_org_info['机构层次'].isin(rule1)].copy()
    xh = df_filter['序号'].to_list()
    busi_types = df_filter['单位业务类别'].to_list()
    busi_areas = df_filter['单位业务分布'].to_list()

    ctool = WbTool(filename)
    for i in range(len(xh)):
        if busi_types[i] in DY3:
            ctool.set_comment(f'{DICT_COLUMN_NAMES["单位业务类别"]}{int(xh[i]) + 7}', '单位业务类别有误-2！')
            logging.info(f'     {DICT_COLUMN_NAMES["单位业务类别"]}{int(xh[i]) + 7}单位业务类别有误-2！')
            ctool.set_red_comment_type1(f'AN{int(xh[i]) + 7}')
            ctool.concat_value(f'AO{int(xh[i]) + 7}', f'{DICT_COLUMN_NAMES["单位业务类别"]}')
        if busi_areas[i] != DZ3:
            ctool.set_comment(f'{DICT_COLUMN_NAMES["单位业务分布"]}{int(xh[i]) + 7}', '单位业务分布应为：100 管理机关！')
            logging.info(f'     {DICT_COLUMN_NAMES["单位业务分布"]}{int(xh[i]) + 7}单位业务分布应为：100 管理机关！')
            ctool.set_red_comment_type1(f'AN{int(xh[i]) + 7}')
            ctool.concat_value(f'AO{int(xh[i]) + 7}', f'{DICT_COLUMN_NAMES["单位业务分布"]}')
    ctool.save()


# 1.7.6 机构层次与单位业务类别、单位业务分布-勾稽关系校验-3
"""
当【机构维护信息表-【M-机构层次】】的值为【码表库-【DW12-34 直属单位直属机构】】且【机构维护信息表-【O-单位业务类别】】的值为【码表库-【DY3-100 直属单位管理机关】】时，
检验【机构维护信息表-【P-单位业务分布】】的值是否为【码表库-【DZ3-100 管理机关】】，若是，见1；若不是，见2。

"1.跳转执行下一规则；
2.若为“不是”，则在【机构维护信息表-【P-单位业务分布】】插入批注“单位业务分布应为：100 管理机关！”，执行下一规则。"
"""


def chk_1_7_6(filename: str):
    logging.info('1.7.6 机构层次与单位业务类别、单位业务分布-勾稽关系校验-3')
    with DbSession() as session:
        DW = [list(i)[0] for i in session.query(Event.db_DW).all() if list(i)[0] != ''][9]  # 34 直属单位直属机构
        DY3 = [list(i)[0] for i in session.query(Event.db_DY).all() if list(i)[0] != ''][0]  # 100 直属单位管理机关
        DZ3 = [list(i)[0] for i in session.query(Event.db_DZ).all() if list(i)[0] != ''][0]  # 100 管理机关

    clean_df = load_org_info(filename)
    filter_df = clean_df[clean_df['机构层次'].isin([DW]) & clean_df['单位业务类别'].isin([DY3])].copy()
    xh = filter_df['序号'].to_list()
    busi_areas = filter_df['单位业务分布'].to_list()
    ctool = WbTool(filename)
    for i in range(len(xh)):
        if busi_areas[i] != [DZ3]:
            ctool.set_comment(f'{DICT_COLUMN_NAMES["单位业务分布"]}{int(xh[i]) + 7}', '单位业务分布应为：100 管理机关！')
            logging.info(f'     {DICT_COLUMN_NAMES["单位业务分布"]}{int(xh[i]) + 7}单位业务分布应为：100 管理机关！')
            ctool.set_red_comment_type1(f'AN{int(xh[i]) + 7}')
            ctool.concat_value(f'AO{int(xh[i]) + 7}', f'{DICT_COLUMN_NAMES["单位业务分布"]}')
    ctool.save()


# 1.7.7 机构层次与单位业务类别、单位业务分布-勾稽关系校验-4
"""
当【机构维护信息表-【M-机构层次】】的值为【码表库-【DW12-34 直属单位直属机构】】且【机构维护信息表-【O-单位业务类别】】的值为【码表库-【DY4-110 直属单位直属机构】】时，
检验【机构维护信息表-【P-单位业务分布】】的值是否为【码表库-【DZ4 或 DZ5】】，若是，见1；若不是，见2。

1.跳转执行下一规则；
2.若为“不是”，则在【机构维护信息表-【P-单位业务分布】】插入批注“单位业务分布有误-4！”，执行下一规则
"""


def chk_1_7_7(filename: str):
    logging.info('1.7.7 机构层次与单位业务类别、单位业务分布-勾稽关系校验-4')
    with DbSession() as session:
        DW = [list(i)[0] for i in session.query(Event.db_DW).all() if list(i)[0] != ''][9:10]
        DY = [list(i)[0] for i in session.query(Event.db_DY).all() if list(i)[0] != ''][1:2]
        DZ = [list(i)[0] for i in session.query(Event.db_DZ).all() if list(i)[0] != ''][1:3]

    df_org_info = load_org_info(filename)
    df_filter = df_org_info[df_org_info['机构层次'].isin(DW) & df_org_info['单位业务类别'].isin(DY)].copy()
    xh = df_filter['序号'].to_list()
    busi_areas = df_filter['单位业务分布'].to_list()

    ctool = WbTool(filename)
    for i in range(len(xh)):
        if busi_areas[i] not in DZ:
            ctool.set_comment(f'{DICT_COLUMN_NAMES["单位业务分布"]}{int(xh[i]) + 7}', '单位业务分布有误-4！')
            logging.info(f'     {DICT_COLUMN_NAMES["单位业务分布"]}{int(xh[i]) + 7}单位业务分布有误-4！')
            ctool.set_red_comment_type1(f'AN{int(xh[i]) + 7}')
            ctool.concat_value(f'AO{int(xh[i]) + 7}', f'{DICT_COLUMN_NAMES["单位业务分布"]}')
    ctool.save()


# 1.7.8 机构层次与单位业务类别、单位业务分布-勾稽关系校验-5
"""
当【机构维护信息表-【M-机构层次】】的值为【码表库-【DW12-34 直属单位直属机构】】且【机构维护信息表-【O-单位业务类别】】的值不为【码表库-【DY3 或 DY4】】时，
检验【机构维护信息表-【P-单位业务分布】】的值是否不为【码表库-【DZ3 或 DZ4 或 DZ5】】，若是，见1；若不是，见2。

1.跳转执行下一规则
2.若为“不是”，则在【机构维护信息表-【P-单位业务分布】】插入批注“单位业务分布有误-5！”，执行下一规则
"""


def chk_1_7_8(filename: str):
    logging.info('1.7.8 机构层次与单位业务类别、单位业务分布-勾稽关系校验-5')
    with DbSession() as session:
        DW = [list(i)[0] for i in session.query(Event.db_DW).all() if list(i)[0] != ''][9:10]
        DY = [list(i)[0] for i in session.query(Event.db_DY).all() if list(i)[0] != ''][0:2]
        DZ = [list(i)[0] for i in session.query(Event.db_DZ).all() if list(i)[0] != ''][0:3]

    df_org_info = load_org_info(filename)
    df_filter = df_org_info[df_org_info['机构层次'].isin(DW) & ~df_org_info['单位业务类别'].isin(DY)].copy()
    indexes = df_filter['序号'].to_list()
    busi_areas = df_filter['单位业务分布'].to_list()

    ctool = WbTool(filename)
    for i in range(len(indexes)):
        if busi_areas[i] in DZ:
            ctool.set_comment(f'{DICT_COLUMN_NAMES["单位业务分布"]}{int(indexes[i]) + 7}', '单位业务分布有误-5！')
            logging.info(f'     {DICT_COLUMN_NAMES["单位业务分布"]}{int(indexes[i]) + 7}单位业务分布有误-5！')
            ctool.set_red_comment_type1(f'AN{int(indexes[i]) + 7}')
            ctool.concat_value(f'AO{int(indexes[i]) + 7}', f'{DICT_COLUMN_NAMES["单位业务分布"]}')
    ctool.save()


# 1.7.9 机构层次与单位业务类别、单位业务分布-勾稽关系校验-6
"""
当【机构维护信息表-【M-机构层次】】的值为【码表库-【DW13-35 直属单位直属机构内设机关部门】】时，检验是否满足下述条件：
【机构维护信息表-【O-单位业务类别】】的值不为【码表库-【DY3-100 直属单位管理机关】】且【机构维护信息表-【P-单位业务分布】】的值不为【码表库-【DZ3 或 DZ4 或 DZ5】】，
若是，见1；若不是，见2。

1.跳转执行下一规则；
2.若为“不是”，则在【机构维护信息表-【P-单位业务分布】】插入批注“单位业务类别或单位业务分布有误-6！”，执行下一规则
"""


def chk_1_7_9(filename: str):
    logging.info('1.7.9 机构层次与单位业务类别、单位业务分布-勾稽关系校验-6')
    with DbSession() as session:
        DW = [list(i)[0] for i in session.query(Event.db_DW).all() if list(i)[0] != ''][10:11]
        DY = [list(i)[0] for i in session.query(Event.db_DY).all() if list(i)[0] != ''][0:1]
        DZ = [list(i)[0] for i in session.query(Event.db_DZ).all() if list(i)[0] != ''][0:3]
    df_org_info = load_org_info(filename)
    filter_df = df_org_info[df_org_info['机构层次'].isin(DW) & ~df_org_info['单位业务类别'].isin(DY) & ~df_org_info['单位业务分布'].isin(DZ)].copy()
    xh = filter_df['序号'].to_list()
    ctool = WbTool(filename)
    for i in range(len(xh)):
        ctool.set_comment(f'{DICT_COLUMN_NAMES["单位业务分布"]}{int(xh[i]) + 7}', '单位业务类别或单位业务分布有误-6！')
        logging.info(f'     {DICT_COLUMN_NAMES["单位业务分布"]}{int(xh[i]) + 7}单位业务类别或单位业务分布有误-6！')
        ctool.set_red_comment_type1(f'AN{int(xh[i]) + 7}')
        ctool.concat_value(f'AO{int(xh[i]) + 7}', f'{DICT_COLUMN_NAMES["单位业务分布"]}')
    ctool.save()


# 1.7.10 机构层次与单位业务类别、单位业务分布-勾稽关系校验-7
"""
当【机构维护信息表-【M-机构层次】】的值不为【码表库-【DW3 至 DW13】】时，
先检验【机构维护信息表-【O-单位业务类别】】的值是否不为【码表库-【DY3 或 DY4】】，若是，见1；若不是，见2；
再检验【机构维护信息表-【P-单位业务分布】】的值是否不为【码表库-【DZ3 或 DZ4 或 DZ5】】，若是，见1；若不是，见3。--- 此规则已删除

1.跳转执行下一规则；
2.若为“不是”，则在【机构维护信息表-【O-单位业务类别】】插入批注“单位业务类别有误-7！”，执行下一规则；
3.若为“不是”，则在【机构维护信息表-【P-单位业务分布】】插入批注“单位业务分布有误-7！”，执行下一规则。--- 此规则已删除
"""


def chk_1_7_10(filename: str):
    logging.info('1.7.10 机构层次与单位业务类别、单位业务分布-勾稽关系校验-7')
    with DbSession() as session:
        DW = [list(i)[0] for i in session.query(Event.db_DW).all() if list(i)[0] != ''][0:11]
        DY = [list(i)[0] for i in session.query(Event.db_DY).all() if list(i)[0] != ''][0:2]
        # DZ = [list(i)[0] for i in session.query(Dim.db_DZ).all() if list(i)[0] != ''][0:3]

    clean_df = load_org_info(filename)
    filter_df = clean_df[~clean_df['机构层次'].isin(DW)].copy()
    xh = filter_df['序号'].to_list()
    busi_types = filter_df['单位业务类别'].to_list()
    # busi_areas = filter_df['单位业务分布'].to_list()
    ctool = WbTool(filename)
    for i in range(len(xh)):
        if busi_types[i] in DY:
            ctool.set_comment(f'{DICT_COLUMN_NAMES["单位业务类别"]}{int(xh[i]) + 7}', '单位业务类别有误-7！')
            logging.info(f'     {DICT_COLUMN_NAMES["单位业务类别"]}{int(xh[i]) + 7}单位业务类别有误-7！')
            ctool.set_red_comment_type1(f'AN{int(xh[i]) + 7}')
            ctool.concat_value(f'AO{int(xh[i]) + 7}', f'{DICT_COLUMN_NAMES["单位业务类别"]}、')
        # if dwywfb[i] in DZ:
        #     ctool.set_comment(f'{MAP_COL["单位业务分布"]}{int(xh[i])+7}', '单位业务分布有误-7！')
        #     logging.info(f'     {MAP_COL["单位业务分布"]}{int(xh[i])+7}单位业务分布有误-7！')
        #     ctool.set_pdqcc(f'AN{int(xh[i]) + 7}')
        #     ctool.concat_value(f'AO{int(xh[i]) + 7}', f'{MAP_COL["单位业务分布"]}')
    ctool.save()


# 1.7.11 机构层次与机关部门管理职能分类-勾稽关系校验
"""
当【机构维护信息表-【M-机构层次】】的值为【码表库-【DW12 或 DW14 或 DW16 或 DW17 或 DW21】】时，
检验【机构维护信息表-【Q-机关部门管理职能分类】】的值不为空值，若是，见1；若不是，见2。

"1.跳转执行下一规则；
2.若为“不是”，则在【机构维护信息表-【Q-机关部门管理职能分类】】插入批注“机关部门管理职能分类不能为空！”，执行下一规则。"
"""


def chk_1_7_11(filename: str):
    logging.info('1.7.11 机构层次与机关部门管理职能分类-勾稽关系校验')
    with DbSession() as session:
        DW12 = [list(i)[0] for i in session.query(Event.db_DW).all() if list(i)[0] != ''][9]
        DW14 = [list(i)[0] for i in session.query(Event.db_DW).all() if list(i)[0] != ''][11]
        DW16 = [list(i)[0] for i in session.query(Event.db_DW).all() if list(i)[0] != ''][13:15]
        DW21 = [list(i)[0] for i in session.query(Event.db_DW).all() if list(i)[0] != ''][18]
        DW = [DW12]
        DW.append(DW14)
        DW.extend(DW16)
        DW.append(DW21)  # 34 40 42 43 52
    df_org_info = load_org_info(filename)
    df_filter = df_org_info[df_org_info['机构层次'].isin(DW) & df_org_info['机关部门管理职能分类'].isin([''])].copy()
    indexes = df_filter['序号'].to_list()
    ctool = WbTool(filename)
    for i in range(len(indexes)):
        ctool.set_comment(f'{DICT_COLUMN_NAMES["机关部门管理职能分类"]}{int(indexes[i]) + 7}', '机关部门管理职能分类不能为空！')
        logging.info(f'     {DICT_COLUMN_NAMES["机关部门管理职能分类"]}{int(indexes[i]) + 7}机关部门管理职能分类不能为空！')
        ctool.set_red_comment_type1(f'AN{int(indexes[i]) + 7}')
        ctool.concat_value(f'AO{int(indexes[i]) + 7}', f'{DICT_COLUMN_NAMES["机关部门管理职能分类"]}')
    ctool.save()


# 1.7.12 机构层次与虚机构标识-勾稽关系校验
"""
当【机构维护信息表-【M-机构层次】】的值为【码表库-【DW9 或 DW15 或 DW20】】时，
检验【机构维护信息表-【S-虚机构标识】】的值是否为“是”，若是，见1；若不是，见2。

1.跳转执行下一规则；
2.若为“不是”，则在【机构维护信息表-【S-虚机构标识】】插入批注“虚机构标识有误！”，执行下一规则
"""


def chk_1_7_12(filename: str):
    logging.info('1.7.12 机构层次与虚机构标识-勾稽关系校验')
    with DbSession() as session:
        DW9 = [list(i)[0] for i in session.query(Event.db_DW).all() if list(i)[0] != ''][6]
        DW15 = [list(i)[0] for i in session.query(Event.db_DW).all() if list(i)[0] != ''][12]
        DW20 = [list(i)[0] for i in session.query(Event.db_DW).all() if list(i)[0] != ''][17]
        DW = [DW9]
        DW.append(DW15)
        DW.append(DW20)
    df_org_info = load_org_info(filename)
    df_filter = df_org_info[df_org_info['机构层次'].isin(DW) & ~df_org_info['虚机构标识'].isin(['是'])].copy()
    xh = df_filter['序号'].to_list()
    ctool = WbTool(filename)
    for i in range(len(xh)):
        ctool.set_comment(f'{DICT_COLUMN_NAMES["虚机构标识"]}{int(xh[i]) + 7}', '虚机构标识有误！')
        logging.info(f'     {DICT_COLUMN_NAMES["虚机构标识"]}{int(xh[i]) + 7}虚机构标识有误！')
        ctool.set_red_comment_type1(f'AN{int(xh[i]) + 7}')
        ctool.concat_value(f'AO{int(xh[i]) + 7}', f'{DICT_COLUMN_NAMES["虚机构标识"]}、')
    ctool.save()


# 1.7.13 机构层次与领导班子管理层级-勾稽关系校验
"""
当【机构维护信息表-【M-机构层次】】的值为【码表库-【DW3 或 DW8 或 DW14】】时，
检验【机构维护信息表-【N-单位级别】】的值是否不为“空”，若是，见1；若不是，见2。

1.跳转执行下一规则；
2.若为“不是”，则在【机构维护信息表-【N-单位级别】】插入批注“单位级别有误！”，执行下一规则
"""


def chk_1_7_13(filename: str):
    logging.info('1.7.13 机构层次与领导班子管理层级-勾稽关系校验')
    with DbSession() as session:
        DW3 = [list(i)[0] for i in session.query(Event.db_DW).all() if list(i)[0] != ''][0]
        DW8 = [list(i)[0] for i in session.query(Event.db_DW).all() if list(i)[0] != ''][5]
        DW14 = [list(i)[0] for i in session.query(Event.db_DW).all() if list(i)[0] != ''][11]
        DW = [DW3]
        DW.append(DW8)
        DW.append(DW14)
    df_org_info = load_org_info(filename)
    df_filter = df_org_info[df_org_info['机构层次'].isin(DW) & df_org_info['单位级别'].isin([''])].copy()
    indexes = df_filter['序号'].to_list()
    ctool = WbTool(filename)
    for i in range(len(indexes)):
        ctool.set_comment(f'{DICT_COLUMN_NAMES["单位级别"]}{int(indexes[i]) + 7}', '单位级别有误！')
        logging.info(f'     {DICT_COLUMN_NAMES["单位级别"]}{int(indexes[i]) + 7}单位级别有误！')
        ctool.set_red_comment_type1(f'AN{int(indexes[i]) + 7}')
        ctool.concat_value(f'AO{int(indexes[i]) + 7}', f'{DICT_COLUMN_NAMES["单位级别"]}、')
    ctool.save()


# 1.7.14 基层机构类别小类与加油站信息-勾稽关系校验
"""
锁定【机构维护信息表-【B-机构维护类型】】的值为【码表库-【DR3-机构新增】】的行
当【机构维护信息表-【U-基层机构类别小类】】的值为【码表库-【EG45-010 加油站】】时，
检验【机构维护信息表-【Z-加油站类型】、【AA-加油站属性】、【AB-加油站地理属性】、【AC-星级】、【AD-加油站营业状态】、
【AE-加油站日均营业时间】、【AF-日开始营业时间】、【AG-日结束营业时间】、【AH-设便利店标识】、【AI-设售卡网点标识】和【AJ-加油站规模】】的值是否都不为“空”，
若是，见1；若不是，见2。

1.跳转执行下一规则；
2.若为“不是”，则在相应为空的【机构维护信息表-【Z-加油站类型】、【AA-加油站属性】、【AB-加油站地理属性】、【AC-星级】、
【AD-加油站营业状态】、【AE-加油站日均营业时间】、【AF-日开始营业时间】、【AG-日结束营业时间】、【AH-设便利店标识】、
【AI-设售卡网点标识】和【AJ-加油站规模】】插入批注“加油站信息不能为空！”，执行下一规则
"""


def chk_1_7_14(filename: str):
    logging.info('1.7.14 基层机构类别小类与加油站信息-勾稽关系校验')
    with DbSession() as session:
        EG45 = [list(i)[0] for i in session.query(Event.db_EG).all() if list(i)[0] != ''][42]  # 010 加油站
    dr3 = '机构新增'
    df_org_info = load_org_info(filename)
    df_org_info = df_org_info[df_org_info['机构维护类型'] == dr3]
    df_filter = df_org_info[df_org_info['基层机构类别小类'].isin([EG45])].copy()
    xh = df_filter['序号'].to_list()

    base = ['加油站类型', '加油站属性', '加油站地理属性', '星级', '加油站营业状态', '加油站日均营业时间', '日开始营业时间', '日结束营业时间',
            '设便利店标识', '设售卡网点标识', '加油站规模']
    ctool = WbTool(filename)
    for i in range(len(xh)):
        for k in base:
            if df_filter[f'{k}'].to_list()[i] == '':
                ctool.set_comment(f'{DICT_COLUMN_NAMES[k]}{int(xh[i]) + 7}', '加油站信息不能为空！')
                logging.info(f'     {DICT_COLUMN_NAMES[k]}{int(xh[i]) + 7}加油站信息不能为空！')
                ctool.set_red_comment_type1(f'AN{int(xh[i]) + 7}')
                ctool.concat_value(f'AO{int(xh[i]) + 7}', f'{DICT_COLUMN_NAMES[k]}')
    ctool.save()


# 1.7.16 勾稽关系校验 检验【机构维护信息表-【B-机构维护类型】】的值为【机构更名】和【机构调整】的行，逻辑关系校验
"""
锁定【机构维护信息表-【B-机构维护类型】】的值为【码表库-【DR4 和 DR5】】的【机构维护信息表-【C-组织机构编码】】，
与【1073-【A-对象标识】】匹配相同的机构编码，锁定【1073-【A-对象标识】】的最末一行：
1.检验【机构维护信息表-【D-组织机构简称】】与【1073-【G-机构简称】】是否相同，若相同，见1；若不相同，见2；
2.检验【机构维护信息表-【E-组织机构全称】】与【1073-【H-机构全称】】是否相同，若相同，见1；若不相同，见3；
3.检验【机构维护信息表-【F-单位简化全称】】与【1073-【M-单位简化全称】】是否相同，若相同，见1；若不相同，见4`

"1.若为“相同”，则在【机构维护信息表-【AP】】批注“机构简称 / 机构全称 / 单位简化全称”未发生变化，不予修改！”，执行下一规则，执行下一规则；
2.若为“不同”，则在【机构维护信息表-【AP】】输入“D”，执行下一规则；
3.若为“不同”，则在【机构维护信息表-【AP】】输入“E”，执行下一规则；
4.若为“不同”，则在【机构维护信息表-【AP】】输入“F”，执行下一规则。"

"""


def chk_1_7_16(filename: str):
    from rpa.ssc_rpa.hr.rpa_ji_gou_wei_hu.ftp_control import SAVE_PATH
    logging.info('1.7.15 勾稽关系校验 检验【机构维护信息表-【B-机构维护类型】】的值为【机构更名】和【机构调整】的行，逻辑关系校验')
    save_path_list = os.listdir(SAVE_PATH)
    if '组合逻辑查询组织机构编码校验1073.xlsx' not in save_path_list:
        logging.info('=======  1.3.2 逻辑性校验，附件表没有【机构更名和机构调整】数据，没有生成【组合逻辑查询组织机构编码校验1073.xlsx】表，此流程不需要执行！')
        return

    _1073_filename = SAVE_PATH + '/' + '组合逻辑查询组织机构编码校验1073.xlsx'
    with DbSession() as session:
        DR = [list(i)[0] for i in session.query(Event.db_DR).all() if list(i)[0] != ''][1:3]
    clean_df = load_org_info(filename)
    import pandas as pd
    df_1073 = pd.read_excel(_1073_filename, dtype=str)
    df_1073['filter'] = df_1073.apply(lambda row: len(row['相关对象的标识']) == 8, axis=1)
    df_1073 = df_1073[df_1073['filter'] == True]  # noqa: E712
    fujian_df = clean_df[clean_df['机构维护类型'].isin(DR)].copy()
    org_ids = fujian_df['组织机构编码'].to_list()

    # 如果组织机构编码有符合的值--> 找出1073 符合的数据
    if org_ids:
        org_short_names = fujian_df['组织机构简称'].to_list()
        org_full_names = fujian_df['组织机构全称'].to_list()
        unit_short_names = fujian_df['单位简化全称'].to_list()
        indexes = fujian_df['序号'].to_list()
        ctool = WbTool(filename)
        for i in range(len(org_ids)):
            df_1073_lite = df_1073[df_1073['对象标识'].isin([org_ids[i]])].copy()
            org_short_names_1073 = df_1073_lite['机构简称'].to_list()
            if not org_short_names_1073:
                continue
            org_full_names_1073 = df_1073_lite['机构全称'].to_list()
            unit_short_names_1073 = df_1073_lite['单位简化全称'].to_list()

            if org_short_names[i] == org_short_names_1073[0]:
                ctool.set_comment(f'AP{int(indexes[i]) + 7}', '“机构简称”未发生变化，不予修改！')
            else:
                ctool.concat_value(f'{DICT_COLUMN_NAMES["节点定位"]}{int(indexes[i]) + 7}', 'D')

            if org_full_names[i] != org_full_names_1073[0]:
                ctool.concat_value(f'{DICT_COLUMN_NAMES["节点定位"]}{int(indexes[i]) + 7}', 'E')
            else:
                ctool.set_comment(f'AP{int(indexes[i]) + 7}', '“机构全称”未发生变化，不予修改！')

            if unit_short_names[i] != unit_short_names_1073[0]:
                ctool.concat_value(f'{DICT_COLUMN_NAMES["节点定位"]}{int(indexes[i]) + 7}', 'F')
            else:
                ctool.set_comment(f'AP{int(indexes[i]) + 7}', '“单位简化全称”未发生变化，不予修改！')
        ctool.save()


def check_is_rel_correct(filename: str) -> bool:
    """勾稽关系校验"""
    logging.info('进行【勾稽关系校验】')
    chk_1_7_1(filename)
    chk_1_7_2(filename)
    chk_1_7_3(filename)
    chk_1_7_4(filename)
    chk_1_7_5(filename)
    chk_1_7_6(filename)
    chk_1_7_7(filename)
    chk_1_7_8(filename)
    chk_1_7_9(filename)
    chk_1_7_10(filename)
    chk_1_7_11(filename)
    chk_1_7_12(filename)
    chk_1_7_13(filename)
    chk_1_7_14(filename)
    # TODO chk_1_7_15
    chk_1_7_16(filename)
    # 查看校验之后的结果
    df_org_info = load_org_info(filename)
    is_success = df_org_info['是否成功'].to_list()
    if any(['批导前校验出错' in s for s in is_success]) is True:
        indexes = df_org_info['序号'].to_list()
        error_msg = df_org_info['是否成功'].to_list()
        upload_to_ftp(filename, '失败', '勾稽关系校验未通过', indexes, error_msg)
        logging.error('【勾稽关系校验】失败')
        return False
    else:
        logging.info('【勾稽关系校验】通过')
        return True


if __name__ == '__main__':
    file = r"x:\Users\Administrator\Desktop\test.xlsx"
    chk_1_7_12(file)
