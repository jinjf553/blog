import logging
import re
import time
from datetime import datetime
from functools import reduce
from pathlib import Path
from typing import List

import arrow
import numpy as np
import pandas as pd
from rpa.fastrpa.adtable import AdTableRow, load_from_xlsx_file
from rpa.public.myftp import MYFTP
from rpa.ssc.hr.orm.dims_utils import load_tb_dim_hr_diao_pei
from rpa.ssc.hr.orm.tb_hr_non_mid import TB_HR_NON_MID
from rpa.ssc.hr.orm.tb_hr_non_mid_detail import TB_HR_NON_MID_DETAIL
from rpa.ssc.hr.orm.td_hr_gang_wei_diao_pei_rulebase import Event
from rpa.ssc.sap.utils import init_sap_id
from rpa.ssc_rpa.hr.rpa_ji_gou_wei_hu.checker.FILE_HEADERS import (
    JGWHXXB_A7, JGWHXXB_HEADER, JGWHXXB_ROW3, JGWHXXB_ROW4)
from rpa.ssc_rpa.hr.rpa_ji_gou_wei_hu.create.generate_org_info import \
    load_org_info
from rpa.ssc_rpa.hr.rpa_ji_gou_wei_hu.orm.orm_ope import (DbSession, Insert,
                                                          Insert_all,
                                                          QueryFirst)
from rpa.ssc_rpa.hr.rpa_ji_gou_wei_hu.tools.excel_tool import (
    WbTool, remove_comment_and_fgcolor)
from sqlalchemy import and_

col_list = ['序号', '机构维护类型', '组织机构编码', '组织机构简称', '组织机构全称', '单位简化全称', '上级机构编码', '机构审批文号', '开始日期', '集团/股份标识', '单位板块',
            '事业部类别',
            '机构层次', '单位级别', '单位业务类别', '单位业务分布', '机关部门管理职能分类', '分流单位类型', '虚机构标识', '基层机构类别大类', '基层机构类别小类', '主成本中心',
            '油品销售企业行政属性',
            '油品销售企业管理层级', '油品销售企业业务属性', '加油站类型', '加油站属性', '加油站地理属性', '星级', '加油站营业状态', '加油站日均营业时间', '日开始营业时间', '日结束营业时间',
            '设便利店标识',
            '设售卡网点标识', '加油站规模', '对应的主体机构编码', '对应的映射机构编码', '备注', '是否成功', '错误描述', '节点定位', '人事范围', '人事子范围', '国籍', '省份',
            '业务范围']
letters_a_to_z = [chr(i) for i in np.arange(65, 91)]
letters_aa_to_zz = [i + k for i in letters_a_to_z for k in letters_a_to_z]
letters_aa_to_zz.remove('AQ')

# 生成列名与字母的对应关系 {'序号':'A'.....}
DICT_COLUMN_NAMES = {}
for i in range(len(col_list)):
    if i < 26:
        DICT_COLUMN_NAMES[col_list[i]] = letters_a_to_z[i]
    else:
        DICT_COLUMN_NAMES[col_list[i]] = letters_aa_to_zz[i - 26]

DICT_LETTERS = {value: key for key, value in DICT_COLUMN_NAMES.items()}  # {'A':'序号'}


def check_is_file_changed(filename: str) -> bool:
    """非标准表单校验"""
    # 因开发完项目后，企业附件的模板发生了改变，增加了AQ7 单元格设置了【节点提示】当作表头。
    # 而程序在校验的时候会根据之前的表头把附件的数据重新组合为一个规则的DF（第一行是表头），删除AQ7
    ctool = WbTool(filename)
    ctool.replace_value('AQ7', '')
    ctool.save()
    now_time = time.strftime('%Y-%m-%d %H:%M:%S', time.localtime(time.time()))
    logging.info(f'{now_time}：进行【非标准表单校验】')
    # 清除批注 与 背景色 与 校验失败后的描述
    remove_comment_and_fgcolor(filename)
    # 校验文件名
    chk_1_1_1(filename)
    # 校验表头
    chk_1_1_3(filename)
    ctool = WbTool(filename)
    # 判断是否校验失败。如果失败返回ftp 如果没有失败,执行【刚性校验】
    AN8 = ctool.sheetname['AN8'].value
    if AN8 == '非标准表单' or ctool.sheetname['AO8'].comment:
        upload_to_ftp(filename, '失败', '非标准表单')
        logging.error('【非标准表单校验】失败')
        return False
    else:
        logging.info('【非标准表单校验】通过')
        return True


def check_must_fill(filename: str) -> bool:
    """刚性校验"""
    logging.info('进行【刚性校验】')
    chk_1_2_1(filename)
    chk_1_2_2(filename)
    chk_1_2_3(filename)
    chk_1_2_4(filename)
    chk_1_2_5(filename)
    chk_1_2_6(filename)
    chk_1_2_7(filename)
    chk_1_2_8(filename)
    chk_1_2_9(filename)
    chk_1_2_10(filename)
    chk_1_2_11(filename)
    chk_1_2_12(filename)
    chk_1_2_13(filename)
    chk_1_2_14(filename)
    chk_1_2_15(filename)
    chk_1_2_16(filename)
    chk_1_2_17(filename)
    chk_1_2_18(filename)
    chk_1_2_19(filename)
    chk_1_2_20(filename)
    chk_1_2_21(filename)
    # 查看校验之后的结果
    df_org_info = load_org_info(filename)
    is_success = df_org_info['是否成功'].to_list()
    if any(['批导前校验出错' in s for s in is_success]) is True:
        indexes = df_org_info['序号'].to_list()
        error_msg = df_org_info['是否成功'].to_list()
        upload_to_ftp(filename, '失败', '刚性校验未通过', indexes, error_msg)
        logging.error('【刚性校验】失败')
        return False
    else:
        logging.info('【刚性校验】通过')
        return True


# 过滤行数据，并找出同行中指定列为空的单元格，设置批注
def find_null_by_filter(filename: str, column_letter: str, filter_text: str, is_null_list, comment: str, xh_list=None):
    """
    过滤行数据，并找出同行中指定列为空的单元格，设置批注
    :param filename: 附件表路径
    :param column_letter: 过滤哪一列
    :param filter_text: 过滤什么值
    :param is_null_list: 在同行中那些列进行找空
    :param comment: 批注信息
    :param xh_list: col, value（按条件过滤）|xh_list 幸福二选一， xh_list指定过滤的序号行（按行过滤）
    :return: True 找到空  False没找到空
    """
    df_org_info = load_org_info(filename)
    if xh_list:
        df_org_info_lite = df_org_info[df_org_info['序号'].isin(xh_list)].copy()
    else:
        df_org_info_lite = df_org_info[df_org_info[f'{column_letter}'].isin([f'{filter_text}'])].copy()
    flag = False
    ctool = WbTool(filename)
    for i in is_null_list:
        xh = df_org_info_lite[df_org_info_lite[f'{i}'].isin([''])].copy()['序号'].to_list()
        if xh:
            # ctool = WbTool(filename)
            for index in xh:
                ctool.set_comment(f'{DICT_COLUMN_NAMES[i]}{int(index) + 7}', comment)
                logging.info(f'     {DICT_COLUMN_NAMES[i]}{int(index) + 7}{comment}')
                ctool.set_red_comment_type1(f'AN{int(index) + 7}')
                ctool.concat_value(f'AO{int(index) + 7}', f'{DICT_COLUMN_NAMES[i]}')
            # ctool.save()
            flag = True
    ctool.save()
    return flag


# 过滤行数据，并找出同行中指定列不为空的单元格，给不为空的单元格设置批注
def find_no_null_by_filter(filename: str, column_letter: str, filter_text: str, is_null_list, comment: str,
                           flag_append_comment=True, indexes=None):
    """
    过滤行数据，并找出同行中指定列不为空的单元格，设置批注
    :param filename: 附件表路径
    :param column_letter: 过滤哪一列
    :param filter_text: 过滤什么值
    :param is_null_list: 找同行中那些列进行找空
    :param comment: 批注信息
    :param flag_append_comment :是否添加批注
    :return: True 找到空  False没找到空
    """
    df_org_info = load_org_info(filename)
    if indexes is not None:
        df_org_info_lite = df_org_info[df_org_info['序号'].isin(indexes)].copy()
    else:
        df_org_info_lite = df_org_info[df_org_info[f'{column_letter}'].isin([f'{filter_text}'])].copy()
    flag = False
    ctool = WbTool(filename)
    for i in is_null_list:
        indexes = df_org_info_lite[~df_org_info_lite[f'{i}'].isin([''])].copy()['序号'].to_list()
        if indexes and flag_append_comment:
            # ctool = WbTool(filename)
            for index in indexes:
                ctool.set_comment(f'{DICT_COLUMN_NAMES[i]}{int(index) + 7}', comment)
                logging.info(f'     {DICT_COLUMN_NAMES[i]}{int(index) + 7}{comment}')
                ctool.set_red_comment_type1(f'AN{int(index) + 7}')
                ctool.concat_value(f'AO{int(index) + 7}', f'{DICT_COLUMN_NAMES[i]}、')
            # ctool.save()
        flag = True
    ctool.save()
    return flag


# 取出指定多个列中其中一个列不为空的行序号列表
def get_value_of_cols(file, col_list):
    df_org_info = load_org_info(file)
    # 取出需要比对的列没有值的序号
    null_list = []
    for col in col_list:
        null_list.append(df_org_info[~df_org_info[f'{col}'].isin([''])].copy()['序号'].to_list())
    result = [set(i) for i in null_list]
    if result:
        intersection = reduce(lambda x, y: x | y, result)
        return list(intersection)


# 多个列 要么都为空  要么都有值，否则设置批注
def is_all_column_empty(filename: str, column_letters: List[str], comment=None, df_filter=None):
    if df_filter is None:
        df_org_info = load_org_info(filename)
    else:
        df_org_info = df_filter

    # 取出需要比对的列没有值的序号
    null_list = []
    for column_letter in column_letters:
        null_list.append(df_org_info[df_org_info[f'{column_letter}'].isin([''])].copy()['序号'].to_list())
    result = [set(i) for i in null_list]
    flag = True  # 多列数据中 要么都是空 要么都有数据
    if result:
        intersection = reduce(lambda x, y: x & y, result)
        complement = reduce(lambda x, y: x | y, result)
        diff = intersection ^ complement
        ctool = WbTool(filename)
        for i in diff:
            flag = False
            if comment:
                for column_letter in column_letters:
                    if i in df_org_info[df_org_info[f'{column_letter}'].isin([''])].copy()['序号'].to_list():
                        ctool.set_comment(f'{DICT_COLUMN_NAMES[column_letter]}{int(i) + 7}', comment, height=100,
                                          width=200)
                        logging.info(f'     {DICT_COLUMN_NAMES[column_letter]}{int(i) + 7}{comment}')
                        ctool.set_red_comment_type1(f'AN{int(i) + 7}')
                        ctool.concat_value(f'AO{int(i) + 7}', f'{DICT_COLUMN_NAMES[column_letter]}')
        ctool.save()
    return flag


# 指定列中 有一个为空就设置批注
def cols_find_null(file, col_list, comment_msg=None, xh=None):
    df_org_info = load_org_info(file)

    # 取出需要比对的列没有值的序号
    null_list = []
    for col in col_list:
        if not xh:
            null_list.append(df_org_info[df_org_info[f'{col}'].isin([''])].copy()['序号'].to_list())
        else:
            null_list.append(
                df_org_info[df_org_info[f'{col}'].isin(['']) & df_org_info['序号'].isin(xh)].copy()['序号'].to_list())
    result = [set(i) for i in null_list]
    flag = True  # 多列数据中 要么都是空 要么都有数据
    if result:
        complement = reduce(lambda x, y: x | y, result)
        ctool = WbTool(file)
        for i in complement:
            flag = False
            if comment_msg:
                for col in col_list:
                    if i in df_org_info[df_org_info[f'{col}'].isin([''])].copy()['序号'].to_list():
                        ctool.set_comment(f'{DICT_COLUMN_NAMES[col]}{int(i) + 7}', comment_msg, height=100, width=200)
                        logging.info(f'     {DICT_COLUMN_NAMES[col]}{int(i) + 7}{comment_msg}')
                        ctool.set_red_comment_type1(f'AN{int(i) + 7}')
                        ctool.concat_value(f'AO{int(i) + 7}', f'{DICT_COLUMN_NAMES[col]}、')
        ctool.save()
    return flag


# 过滤出指定列全有值的行序号
def filter_together_value(file, col_list):
    """
    过滤出指定列全不为空的行
    :param file:
    :param col_list:
    :param filter_df:
    :return: 符合过滤条件的数据的序号列表
    """
    df_org_info = load_org_info(file)
    # 取出需要比对的列没有值的序号
    null_list = []
    for col in col_list:
        null_list.append(df_org_info[~df_org_info[f'{col}'].isin([''])].copy()['序号'].to_list())
    result = [set(i) for i in null_list]  # 把找出来的每一列不为空的行的序号转为集合 [{1,2,3},{2,4}]
    if result:
        intersection = reduce(lambda x, y: x & y, result)  # 交集
        return list(intersection)


# 给多个列中都有值的设置批注
def is_same_value(filename, column_letters: List[str], comment_msg=None):
    df_org_info = load_org_info(filename)
    # 取出需要比对的列有值的序号
    value_list = []
    flag = True
    for col in column_letters:
        value_list.append(df_org_info[~df_org_info[f'{col}'].isin([''])].copy()['序号'].to_list())
    result = [set(i) for i in value_list]
    if result:
        intersection = reduce(lambda x, y: x & y, result)
        ctool = WbTool(filename)
        for i in intersection:
            flag = False
            if comment_msg:
                for col in column_letters:
                    if i in df_org_info[~df_org_info[f'{col}'].isin([''])].copy()['序号'].to_list():
                        ctool.set_comment(f'{DICT_COLUMN_NAMES[col]}{int(i) + 7}', comment_msg)
                        logging.info(f'     {DICT_COLUMN_NAMES[col]}{int(i) + 7}{comment_msg}')
                        ctool.set_red_comment_type1(f'AN{int(i) + 7}')
                        ctool.concat_value(f'AO{int(i) + 7}', f'{DICT_COLUMN_NAMES[col]}、')
        ctool.save()
    return flag


# 1.1.1 校验表名
"""
sr(10位)-人事范围-业务类型-人员
无单号1-人事范围-业务类型-人员
"""


def chk_1_1_1(filename: str):
    logging.info('校验企业附件excel名称是否合法：')
    file_name = Path(filename).name[:-5]  # 20200302-sr(10位)-名字-xxxx  sr(10位)-人事范围-业务类型-人员 | 无单号1-人事范围-业务类型-人员
    logging.info(f'------>附件名为："{file_name}"')
    neirong = file_name.split('-')
    if len(neirong) < 4:
        # 表名出错
        ctool = WbTool(filename)
        ctool.set_comment('AO8', '企业表单应按规范命名，如【sr(10位)-人事范围-业务类型-人员.xlsx 】或【无单号1-人事范围-业务类型-人员.xlsx】',
                          height=250, width=360)
        ctool.save()
        logging.info('------> 表名出错')
        return
    else:
        # 获取附件表所含有的 日期，sr，名字，与附加信息
        sr, personnel_area, business_type, name = Path(filename).name[:-5].split('-')[:4]
        if len(sr) == 10 or sr.startswith('无单号'):
            result = re.match("[0-9]{10}|无单号", sr)
            if not result:
                # 表名出错
                ctool = WbTool(filename)
                ctool.set_comment('AO8', '企业表单应按规范命名，如【sr(10位)-人事范围-业务类型-人员.xlsx 】或【无单号-人事范围-业务类型-人员.xlsx】',
                                  height=250, width=360)
                ctool.save()
                logging.error('------> 表名出错，企业表单应按规范命名，如【sr(10位)-人事范围-业务类型-人员.xlsx 】或【无单号-人事范围-业务类型-人员.xlsx】')
                return
            else:  # 表名校验通过 还需判断数据库是否正在做
                query = [qu for qu in QueryFirst(sr=sr, remaker=None)][0]
                if not query:
                    # 数据库没有指定sr号并且remaker为空的记录，log表插入一条记录
                    Insert(sr=sr, tab_name=file_name, name=name)
                else:
                    logging.info(f'------> 数据库中已存在【{file_name}】，正在执行流程')
                    # raise Exception(f'------> 数据库中已存在【{file_name}】，正在执行流程')
        else:
            # 表名出错
            ctool = WbTool(filename)
            ctool.set_comment('AO8', '企业表单应按规范命名，如：【sr(10位)-人事范围-业务类型-人员.xlsx 】或【无单号1-人事范围-业务类型-人员.xlsx】',
                              height=250, width=360)
            ctool.save()
            logging.info('------> 表名出错')
            return
    logging.info('------> 表名合法')


# 1.1.3检验“机构维护信息表”是否为标准表单
"""
校验A1 是否为：机构维护信息表(JGWHXXB_HEADER)
第三行：是否为JGWHXXB_ROW3
第四行：是否为JGWHXXB_ROW4
A7：是否为JGWHXXB_A7
"""


def chk_1_1_3(filename: str):
    logging.info('校验附件表头：')
    flag = True
    error_msg = ''
    df_file = pd.read_excel(filename, header=None, keep_default_na=False)
    A2 = df_file.iloc[[1], [0]].values[0][0]
    row3: List[str] = list(filter(None, np.array(df_file.iloc[2:3]).tolist()[0]))
    row4: List[str] = list(filter(None, np.array(df_file.iloc[3:4]).tolist()[0]))
    A7 = ''.join(df_file.iloc[6:7][0])
    diff_row3 = set(row3) ^ set(JGWHXXB_ROW3)
    diff_row4 = set(row4) ^ set(JGWHXXB_ROW4)
    if A2 != JGWHXXB_HEADER:
        flag = False
        error_msg = f'表头信息不正确:表头不是【{JGWHXXB_HEADER}】'
    elif diff_row3:
        flag = False
        error_msg = f'第三行信息不正确，请检查【{diff_row3}】字段'
    elif diff_row4:
        flag = False
        error_msg = f'第四行信息不正确，请检查【{diff_row4}】字段'
    elif JGWHXXB_A7 != A7:
        flag = False
        error_msg = f'表头信息不正确,A7单元格内容不是【{JGWHXXB_A7}】'
    if not flag:
        logging.error(f'表头不合法：{error_msg}')
        ctool = WbTool(filename)
        ctool.set_comment('AN8', error_msg, height=150, width=260)
        ctool.set_red("AN8")
        ctool.replace_value('AN8', '非标准表单')
        ctool.save()
    else:
        # 将附件表中的每一条数据，插入到desc详情表
        sr, staff_rngs, business_type, name = Path(filename).name[:-5].split('-')[:4]
        # res = [querytset for querytset in QueryFirst(sr=sr, remaker=None)][0]
        with DbSession() as s:
            res = s.query(TB_HR_NON_MID).filter(and_(TB_HR_NON_MID.sr == sr, TB_HR_NON_MID.remaker is None)).first()
            if res:
                sr_id = res.id
                ctool = WbTool(filename)
                ctool.reset_column_a_index()  # 重新排列序号
                # 获取序号与机构维护类型
                df_org_info = load_org_info(filename)
                indexes = df_org_info['序号'].to_list()
                org_types = df_org_info['机构维护类型'].to_list()
                org_ids = df_org_info['组织机构编码'].to_list()
                staff_rngs = df_org_info['人事范围'].to_list()
                objs = [TB_HR_NON_MID_DETAIL(sr_id=sr_id, sr=sr, no=str(indexes[i]), org_class=org_types[i], org_no=org_ids[i],
                                             personnel_area=staff_rngs[i]) for i in range(len(indexes))]
                Insert_all(objs)
                logging.info('表头合法')


# 1.2.1 刚性校验-必填项校验-机构维护类型
"""
检验【机构维护信息表-【B-机构维护类型】】的值是否为空，若是，见1；若不是检验其是否是【码表库-【DR-机构维护类型】】的值，若不是，见2；若是，见3。

1.若值为“空”，则检验【机构维护信息表-【A 至 AV】】是否有值，只要任一单元格有值，则在相应为空的【机构维护信息表-【B-机构维护类型】】插入批注“机构维护类型未填”，执行下一规则；
2.若值为“不是”，在【机构维护信息表-【B-机构维护类型】】插入批注“机构维护类型非码值！”，执行下一规则；
3.若值为“是”，执行下一规则。
"""


def chk_1_2_1(filename: str):
    logging.info('1.2.1 刚性校验-必填项校验-机构维护类型')
    df_org_info = load_org_info(filename)
    org_types = df_org_info['机构维护类型'].to_list()
    with DbSession() as session:
        dims_org_types = [queryset.db_DR for queryset in session.query(Event).filter(Event.db_DR.like('机构%')).all()]  # pylint: disable=fixme, no-member
        ctool = WbTool(filename)
        for index in range(len(org_types)):
            if not org_types[index]:  # 为空的情况
                row = np.array(df_org_info[index:index + 1]).tolist()  # 取出 机构维护类型空值的行的 一行数据
                if row:
                    # ctool = WbTool(filename)
                    ctool.set_comment(f'B{index + 8}', '机构维护类型未填', height=150, width=260)
                    logging.info(f'     B{index + 8}机构维护类型未填')
                    ctool.set_red_comment_type1(f'AN{index + 8}')
                    ctool.concat_value(f'AO{index + 8}', 'B、')
                    # ctool.save()
            else:
                if org_types[index] not in dims_org_types:
                    # ctool = WbTool(filename)
                    ctool.set_comment(f'B{index + 8}', '机构维护类型非码值！', height=150, width=260)
                    logging.info(f'     B{index + 8}机构维护类型非码值！')
                    ctool.set_red_comment_type1(f'AN{index + 8}')
                    ctool.concat_value(f'AO{index + 8}', 'B、')
                    # ctool.save()
        ctool.save()


# 1.2.2 刚性校验-必填项校验-机构新增
"""
锁定【机构维护信息表-【B-机构维护类型】】的值为【码表库-【DR3-机构新增】】的行，
检验【机构维护信息表-【A至B、D至G、I至K、M、O至P、AR至AV】】是否存在任意一单元格为空，若存在，见1；若不存在，见2。

"1.若为“是”，则在相应为空的【机构维护信息表-【A至B、D至G、I至K、M、O至P、AR至AV】】插入批注“机构新增时必填！”，执行下一规则；
2.跳转执行下一规则。"
"""


def chk_1_2_2(filename: str):
    logging.info('1.2.2 刚性校验-必填项校验-机构新增')
    is_null_list = ['A', 'B', 'D', 'E', 'F', 'G', 'I', 'J', 'K', 'M', 'O', 'P', 'AR', 'AS', 'AT', 'AU', 'AV']
    is_null_list_col = [DICT_LETTERS[i] for i in is_null_list]
    find_null_by_filter(filename, '机构维护类型', '机构新增', is_null_list_col, '机构新增时必填！')


# 1.2.3 刚性校验-必填项校验-机构更名
"""
锁定【机构维护信息表-【B-机构维护类型】】的值为【码表库-【DR4-机构更名】】的行，
检验【机构维护信息表-【A至G、I、AR】】是否存在任意一单元格为空，若是，见1；若不是，检验【机构维护信息表-【J至AL】】是否全部为空，若是，见2；若不是，见3。

1.若为“是”，则在相应为空的【机构维护信息表-【A至G、I AR】】插入批注“机构更名时必填！”，执行下一规则；
2.跳转执行下一规则；
3.若为“不是”，则在相应有值的【机构维护信息表-【J至AL】】插入批注“机构更名时不填！”，执行下一规则
"""


def chk_1_2_3(filename: str):
    logging.info('1.2.3 刚性校验-必填项校验-机构更名')
    is_null_list = ['A', 'B', 'C', 'D', 'E', 'F', 'G', 'I', 'AR']
    is_null_list_col = [DICT_LETTERS[i] for i in is_null_list]
    flag = find_null_by_filter(filename, '机构维护类型', '机构更名', is_null_list_col, '机构更名时必填！')

    # 找出【A至G、I AR】都有值的序号列表
    # xh_list = filter_together_value(file, is_null_list_col)
    if not flag:
        # jgwhxxb = new_jgwhxxb(file)
        # filter_df = jgwhxxb[jgwhxxb['序号'].isin(xh_list)].copy()
        # filter_df = filter_df[filter_df['机构维护类型'].isin(['机构更名'])].copy()  # 找出【A至G、I】都有值的序号列表，且B是机构更名
        # xh = filter_df['序号'].to_list()
        judge_list = ['J', 'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z', 'AA', 'AB',
                      'AC', 'AD', 'AE', 'AF', 'AG', 'AH', 'AI', 'AJ', 'AK', 'AL']
        judge_list_col = [DICT_LETTERS[i] for i in judge_list]
        # find_no_null_by_filter(file, '机构维护类型', '机构更名', judge_list_col, '机构更名时不填！', xh_list=xh)
        find_no_null_by_filter(filename, '机构维护类型', '机构更名', judge_list_col, '机构更名时不填！')


# 1.2.4 刚性校验-必填项校验-机构调整
"""

"锁定【机构维护信息表-【B-机构维护类型】】的值为【码表库-【DR5-机构调整】】的行：
先检验【机构维护信息表-【A至G、I、AR】】是否存在任意一单元格为空，若不是，见3；若是，见1；
再检验【机构维护信息表-【J至K、M、O至P】】是否存在任一单元格不为空，若不存在，见3；若存在，则检验【机构维护信息表-【J至K、M、O至P】】所有单元格是否均不为空，若不是，见2；若是，见3。"


"1.若为“是”，则在相应为空的【机构维护信息表-【A至G、I、AR】】插入批注“机构调整时必填！”，执行下一规则；
2.若为“是”，则在相应为空的【机构维护信息表-【J至K、M、O至P】】插入批注“机构调整时关联信息必填！”，执行下一规则；
3.跳转执行下一规则。"

"""


def chk_1_2_4(filename: str):  # 20200715新增规则
    """1.2.4 刚性校验-必填项校验-机构调整
       锁定【机构维护信息表-【B-机构维护类型】】的值为【码表库-【DR5-机构调整】】的行：
       先检验【机构维护信息表-【A至G、I、AR】】是否存在任意一单元格为空，若是，见1；
       若不是，再进行如下校验：
       1.检验【机构维护信息表-【J至R】】是否全部为空，若全部为空，执行第2条规则；
         若任一单元格不为空，再检验【机构维护信息表-【J至K、M、O至P】】是否全部不为空，若为“全部不为空”，执行第2条规则；
         若为“【机构维护信息表-【J至K、M、O至P】】任一单元格有空”，见2；
       2.检验【机构维护信息表-【T至U】】是否全部为空，若全部为空，执行第3条规则；若任一单元格不为空，再检验是否全部不为空，若不是，见2；
       3.检验【机构维护信息表-【W至Y】】是否全部为空，若全部为空，执行第4条规则；若任一单元格不为空，再检验是否全部不为空，若不是，见2；
       4.检验【机构维护信息表-【Z至AJ】】是否全部为空，若全部为空，执行第5条规则；若任一单元格不为空，再检验是否全部不为空，若不是，见2；
       5.检验【机构维护信息表-【AK至AL】】是否全部为空，若全部为空，见3；若任一单元格不为空，再检验是否全部不为空，若不是，见2。
       -------------------
       1.若为“是”，则在相应为空的【机构维护信息表-【A至G、I、AR】】插入批注“机构调整时必填！”，执行下一规则；
       2.若为“是”，则在相应为空的【机构维护信息表-【J至K、M、O至P】】插入批注“机构调整时关联信息必填！”，执行下一规则；
       3.跳转执行下一规则。
    """
    def _rule2(row: AdTableRow):
        for column_letter in ('J', 'K', 'M', 'O', 'P'):
            if row[column_letter].value == '':
                row['AN'].value = '批导前校验出错'
                row['AN'].set_fgcolor('red')
                row[column_letter].cmt('red', '机构调整时关联信息必填！')
                if lt['AO'][rn].value == '':
                    lt['AO'][rn].value = column_letter
                else:
                    lt['AO'][rn].value += f'、{column_letter}'
    lt = load_from_xlsx_file(filename, skip_header=7, data_only=False)
    dims = load_tb_dim_hr_diao_pei()
    dr5 = dims['DR'][5].value  # '机构调整'
    df = lt.to_dataframe()
    _df = df[df['B'] == dr5]
    for rn in _df.index:
        any_empty = False
        for column_letter in ('A', 'B', 'C', 'D', 'E', 'F', "G", 'I', 'AR'):
            if _df[column_letter][rn] == '':
                lt['AN'][rn].value = '批导前校验出错'
                lt['AN'][rn].set_fgcolor('red')
                lt[column_letter][rn].cmt('red', '机构调整时必填！')
                if lt['AO'][rn].value == '':
                    lt['AO'][rn].value = column_letter
                else:
                    lt['AO'][rn].value += f'、{column_letter}'
                any_empty = True
        if any_empty is True:
            continue
        all_empty = _df[['J', 'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R']].loc[rn].values.flatten().tolist() == ['', '', '', '', '', '', '', '', '']
        # 1.
        if all_empty is True:  # 全为空
            pass
        elif '' in _df[['J', 'K', 'M', 'N', 'O', 'P', 'Q', 'R']].loc[rn].values.flatten().tolist():  # 不全为空
            _rule2(lt.row_at(rn))
            continue
        # 全部不为空
        # 2.
        if _df[['T', 'U']].loc[rn].values.flatten().tolist() == ['', '']:
            pass
        elif '' in _df[['T', 'U']].loc[rn:].values.flatten().tolist():
            _rule2(lt.row_at(rn))
            continue
        # 3.
        if _df[['W', 'X', 'Y']].loc[rn].values.flatten().tolist() == ['', '', '']:
            pass
        elif '' in _df[['W', 'X', 'Y']].loc[rn].values.flatten().tolist():
            _rule2(lt.row_at(rn))
            continue
        # 4.
        if _df[['Z', 'AA', 'AB', 'AC', 'AD', 'AE', 'AF', 'AG', 'AH', 'AI', 'AJ']].loc[rn].values.flatten().tolist() == ['', '', '', '', '', '', '', '', '', '', '']:
            pass
        elif '' in _df[['Z', 'AA', 'AB', 'AC', 'AD', 'AE', 'AF', 'AG', 'AH', 'AI', 'AJ']].loc[rn].values.flatten().tolist():
            _rule2(lt.row_at(rn))
            continue
        # 5.
        if _df[['AK', 'AL']].loc[rn].values.flatten().tolist() == ['', '']:
            pass
        elif '' in _df[['AK', 'AL']].loc[rn].values.flatten().tolist():
            _rule2(lt.row_at(rn))
            continue
    lt.wb.save(filename)


def chk_1_2_5(filename: str):  # 1.2.5 刚性校验-排他性校验-机构撤销
    """
    检验【机构维护信息表-【B-机构维护类型】】的值是否为【码表库-【DR6-机构撤销】】的值，若是，见1；若不是，见2。

    1.若为“是”，则在【机构维护信息表-【B-机构维护类型】】插入批注“机构撤销不进行RPA操作！”，执行下一规则；
    2.跳转执行下一规则。"

    """
    logging.info('1.2.5 刚性校验-排他性校验-机构撤销')
    jgwhxxb = load_org_info(filename)
    xuhao = jgwhxxb[jgwhxxb['机构维护类型'].isin(['机构撤销'])].copy()['序号'].to_list()
    if xuhao:
        ctool = WbTool(filename)
        for i in xuhao:
            ctool.set_comment(f'B{int(i) + 7}', '机构撤销不进行RPA操作！')
            logging.info(f'     B{int(i) + 7}机构撤销不进行RPA操作！')
            ctool.set_red_comment_type1(f'AN{int(i) + 7}')
            ctool.concat_value(f'AO{int(i) + 7}', 'B')
        ctool.save()


# 1.2.6 刚性校验-完整性校验-基层单位特有属性
"""
检验【机构维护信息表-【T-基层机构类别大类】和【U-基层机构类别小类】】的值是否都为空，若是，见1，若不是，继续检验二者是否都有值，若是，见1，若不是，见2。

1.跳转执行下一规则
2.若存在任意一值为“空”，则在为空的【机构维护信息表-【T / U】】插入批注“基层单位特有属性不全！”，执行下一规则
"""


def chk_1_2_6(filename: str):
    logging.info('1.2.6 刚性校验-完整性校验-基层单位特有属性')
    is_all_column_empty(filename, ['基层机构类别大类', '基层机构类别小类'], '基层单位特有属性不全！')


# 1.2.7 刚性校验-完整性校验-销售企业单位属性
"""
检验【机构维护信息表-【W-油品销售企业行政属性】、【X-油品销售企业管理层级】和【Y-油品销售企业业务属性】】的值是否都为空，若是，见1；
若不是，继续检验三者的值是否都不为空，若是，见1；若不是，见2。

1.跳转执行下一规则；
2.若“存在空值”，则在相应为空的【机构维护信息表-【W / X / Y】】插入批注“销售企业单位属性不全！”，执行下一规则。
"""


def chk_1_2_7(filename: str):
    logging.info('1.2.7 刚性校验-完整性校验-销售企业单位属性')
    col_list = [DICT_LETTERS[i] for i in ['W', 'X', 'Y']]
    is_all_column_empty(filename, col_list, '销售企业单位属性不全！')


# 1.2.8 刚性校验-完整性校验-加油站信息
"""
检验【机构维护信息表-【Z-加油站类型】、【AA-加油站属性】、【AB-加油站地理属性】、【AC-星级】、【AD-加油站营业状态】、【AE-加油站日均营业时间】、
【AF-日开始营业时间】、【AG-日结束营业时间】、【AH-设便利店标识】、【AI-设售卡网点标识】和【AJ-加油站规模】】的值是否都为空，若是，见1；
若不是，继续检验这11个单元格的值是否都不为空，若是，见1；若不是，见2。


1.跳转执行下一规则；
2.若“存在空值”，则在相应为空的【机构维护信息表-【Z/ AA / AB / AC / AD / AE / AF / AG / AH / AI / AJ】】插入批注“加油站信息不全！”，执行下一规则
"""


def chk_1_2_8(filename: str):
    logging.info('1.2.8 刚性校验-完整性校验-加油站信息')
    col_list = [DICT_LETTERS[i] for i in ['Z', 'AA', 'AB', 'AC', 'AD', 'AE', 'AF', 'AG', 'AH', 'AI', 'AJ']]
    is_all_column_empty(filename, col_list, '加油站信息不全！')


# 1.2.9 刚性校验-必填项校验-组织机构编码
"""
提取【机构维护信息表-【C-组织机构编码】】中纯数字的部分（含义为删除空格等字符）检验其是否为8位，再回写到【机构维护信息表-【C-组织机构编码】】中，若是，见1；若不是，见2。

1.跳转执行下一规则；
2.若为“不是”，则在【机构维护信息表-【C-组织机构编码】】插入批注“组织机构编码长度不是8位！”，执行下一规则。
"""


def chk_1_2_9(filename: str):
    logging.info('1.2.9 刚性校验-必填项校验-组织机构编码')
    lt = load_from_xlsx_file(filename, skip_header=7)
    lt['C'].apply(init_sap_id)
    df = lt.to_dataframe()
    for rn in df.index:
        _c = ''.join([c for c in str(df['C'][rn]) if c.isdigit()])
        if len(_c) != 8:
            lt['C'][rn].cmt('red', '组织机构编码长度不是8位！')
            lt['AN'][rn].set_fgcolor('red')
            lt['AN'][rn].value = '批导前校验出错'
            if lt['AO'][rn].value == '':
                lt['AO'][rn].value = 'G'
            else:
                lt['AO'][rn].value += '、G'
    lt.save(filename)


# 1.2.10
"""
锁定【机构维护信息表-【G-上级机构编码】】不为空的单元格，提取其值中纯数字的部分（含义为删除空格等字符），
检验其是否为8位，再回写到【机构维护信息表-【G-上级机构编码】】中，若是，见1；若不是，见2。

1.跳转执行下一规则；
2.若为“不是”，则在【机构维护信息表-【G-上级机构编码】】插入批注“组织机构编码长度不是8位！”，执行下一规则
"""


def chk_1_2_10(filename: str):
    logging.info('1.2.10 刚性校验-必填项校验-上级机构编码')
    lt = load_from_xlsx_file(filename, skip_header=7)
    lt['G'].apply(init_sap_id)
    df = lt.to_dataframe()
    for rn in df.index:
        _g = ''.join([c for c in str(df['G'][rn]) if c.isdigit()])
        if len(_g) != 8:
            lt['G'][rn].cmt('red', '上级机构编码长度不是8位！')
            lt['AN'][rn].set_fgcolor('red')
            lt['AN'][rn].value = '批导前校验出错'
            if lt['AO'][rn].value == '':
                lt['AO'][rn].value = 'G'
            else:
                lt['AO'][rn].value += '、G'
    lt.save(filename)


# 1.2.11 刚性校验-必填项校验-开始日期
"""
检验【机构维护信息表-【I-开始日期】】的值是否为空，若是，见1，若不是，检验其是否为符合常识的日期（8位数字）且最后两位数字为“01”，若是，见1；若不是，见3。

1.若为“是”，则在【机构维护信息表-【I-开始日期】】插入批注“开始日期不能为空！”，执行下一规则
2.跳转执行下一规则
3.若为“不是”，则在【机构维护信息表-【I-开始日期】】插入批注“开始日期有误！”执行下一规则
"""


def chk_1_2_11(filename: str):
    logging.info('1.2.11 刚性校验-必填项校验-开始日期')
    df_org_info = load_org_info(filename)
    # 找空
    df_org_info_lite = df_org_info[df_org_info['开始日期'].isin([''])].copy()
    xh = df_org_info_lite['序号'].to_list()
    ctool = WbTool(filename)
    if xh:
        for i in xh:
            ctool.set_comment(f'{DICT_COLUMN_NAMES["开始日期"]}{int(i) + 7}', '开始日期不能为空！')
            ctool.set_red_comment_type1(f'AN{int(i) + 7}')
            ctool.concat_value(f'AO{int(i) + 7}', f'{DICT_COLUMN_NAMES["开始日期"]}、')

    df_begin_date = df_org_info[~df_org_info['开始日期'].isin([''])].copy()
    indexes = df_begin_date['序号'].to_list()
    begin_dates = [str(i) for i in df_begin_date['开始日期'].to_list()]

    # 当月或者下个月的月份
    arrow_date = arrow.now()
    month = arrow_date.shift(months=0).format('MM')
    next_month = arrow_date.shift(months=1).format('MM')
    compare_month = [month, next_month]
    compare_year = arrow_date.shift(months=0).format('YYYY')

    # 校验开始日期是否全部相同
    if len(set(begin_dates)) > 1:
        for i in range(len(begin_dates)):
            ctool.set_comment(f'{DICT_COLUMN_NAMES["开始日期"]}{int(indexes[i]) + 7}', '开始必须相同！')
            logging.info(f'     {DICT_COLUMN_NAMES["开始日期"]}{int(indexes[i]) + 7}开始日期有误！')
            ctool.set_red_comment_type1(f'AN{int(indexes[i]) + 7}')
            ctool.concat_value(f'AO{int(indexes[i]) + 7}', f'{DICT_COLUMN_NAMES["开始日期"]}')

    # 找日期不是八位且末尾不是01的
    for i in range(len(begin_dates)):
        if len(str(begin_dates[i])) != 8 or not str(begin_dates[i]).isdigit() or not str(begin_dates[i]).endswith('01'):
            ctool.set_comment(f'{DICT_COLUMN_NAMES["开始日期"]}{int(indexes[i]) + 7}', '开始日期有误！')
            logging.info(f'     {DICT_COLUMN_NAMES["开始日期"]}{int(indexes[i]) + 7}开始日期有误！')
            ctool.set_red_comment_type1(f'AN{int(indexes[i]) + 7}')
            ctool.concat_value(f'AO{int(indexes[i]) + 7}', f'{DICT_COLUMN_NAMES["开始日期"]}')
        # 判断日期是否是合法日期
        if not is_yyyymmdd(begin_dates[i]):
            ctool.set_comment(f'{DICT_COLUMN_NAMES["开始日期"]}{int(indexes[i]) + 7}', '开始日期不合法！')
            logging.info(f'     {DICT_COLUMN_NAMES["开始日期"]}{int(indexes[i]) + 7}开始日期不合法！')
            ctool.set_red_comment_type1(f'AN{int(indexes[i]) + 7}')
            ctool.concat_value(f'AO{int(indexes[i]) + 7}', f'{DICT_COLUMN_NAMES["开始日期"]}')
        # 判断月份是否为当月或者下月的月份
        if begin_dates[i][4:6] not in compare_month or begin_dates[i][:4] != compare_year:
            logging.info(compare_month)
            ctool.set_comment(f'{DICT_COLUMN_NAMES["开始日期"]}{int(indexes[i]) + 7}', '开始日期有误！')
            logging.info(f'     {DICT_COLUMN_NAMES["开始日期"]}{int(indexes[i]) + 7}开始日期有误！')
            ctool.set_red_comment_type1(f'AN{int(indexes[i]) + 7}')
            ctool.concat_value(f'AO{int(indexes[i]) + 7}', f'{DICT_COLUMN_NAMES["开始日期"]}')

    ctool.save()


# 1.2.12 刚性校验-选填项校验-主成本中心
"""
锁定【机构维护信息表-【V-主成本中心】】不为空的单元格，先提取其【数字和英文】的部分（含义为删除空格等字符），
再回写到【机构维护信息表-【V-主成本中心】】中，继续检验其是否为10位，且必含有数字和英文，若是，见1；若不是，见2。

1.跳转执行下一规则；
2.若为“不是”，则在【机构维护信息表-【V-主成本中心】】插入批注“主成本中心有误！”，执行下一规则
"""


def chk_1_2_12(filename: str):
    logging.info('1.2.12 刚性校验-选填项校验-主成本中心')
    df_org_info = load_org_info(filename)
    # 找不是空的
    df_org_info_lite = df_org_info[~df_org_info['主成本中心'].isin([''])].copy()
    xh = df_org_info_lite['序号'].to_list()
    cost_center_ids = df_org_info_lite['主成本中心'].to_list()
    cost_center_ids = [str(i).replace(' ', '') for i in cost_center_ids]
    cost_center_ids = [i.replace('"', '') for i in cost_center_ids]
    cost_center_ids = [i.replace('“', '') for i in cost_center_ids]
    cost_center_ids = [i.replace('”', '') for i in cost_center_ids]
    ctool = WbTool(filename)
    for i in range(len(cost_center_ids)):
        ctool.sheetname[f'{DICT_COLUMN_NAMES["主成本中心"]}{int(xh[i]) + 7}'].value = cost_center_ids[i]

    # 校验英文和数据，长度为10
    for i in range(len(cost_center_ids)):
        result = re.search('[0-9|a-z|A-Z]{10}', cost_center_ids[i])
        alpha = re.search('[a-z|A-Z]{10}', cost_center_ids[i])
        dig = re.search('[0-9]{10}', cost_center_ids[i])
        if not result or len(cost_center_ids[i]) != 10 or alpha or dig:
            ctool.set_comment(f'{DICT_COLUMN_NAMES["主成本中心"]}{int(xh[i]) + 7}', '主成本中心有误！')
            logging.info(f'     {DICT_COLUMN_NAMES["主成本中心"]}{int(xh[i]) + 7}主成本中心有误！')
            ctool.set_red_comment_type1(f'AN{int(xh[i]) + 7}')
            ctool.concat_value(f'AO{int(xh[i]) + 7}', f'{DICT_COLUMN_NAMES["主成本中心"]}')
    ctool.save()


# 1.2.13 刚性校验-选填项校验-双跨机构
"""
锁定【机构维护信息表-【AK-对应的主体机构编码】】不为空的单元格，提取其值中纯数字的部分（含义为删除空格等字符），检验其是否为8位，
再回写到【机构维护信息表-【AK-对应的主体机构编码】】中，若是，见1；若不是，见2。

1.跳转执行下一规则；
2.若为“不是”，则在【机构维护信息表-【AK-对应的主体机构编码】】插入批注“对应的主体机构编码长度不是8位，执行下一规则
"""


def chk_1_2_13(filename: str):
    logging.info('1.2.13 刚性校验-选填项校验-双跨机构')
    df_org_info = load_org_info(filename)
    # 找不是空的
    df_org_info_lite = df_org_info[~df_org_info['对应的主体机构编码'].isin([''])].copy()
    indexes = df_org_info_lite['序号'].to_list()
    org_ids = df_org_info_lite['对应的主体机构编码'].to_list()
    org_ids = [str(i).replace(' ', '') for i in org_ids]
    org_ids = [i.replace('"', '') for i in org_ids]
    org_ids = [i.replace('“', '') for i in org_ids]
    org_ids = [i.replace('”', '') for i in org_ids]
    ctool = WbTool(filename)
    for i in range(len(org_ids)):
        ctool.sheetname[f'{DICT_COLUMN_NAMES["对应的主体机构编码"]}{int(indexes[i]) + 7}'].value = org_ids[i]

        # 校验长度为8
    for i in range(len(org_ids)):
        result = re.search('[0-9]{8}', org_ids[i])
        if not result or len(org_ids[i]) != 8:
            ctool.set_comment(f'{DICT_COLUMN_NAMES["对应的主体机构编码"]}{int(indexes[i]) + 7}', '对应的主体机构编码长度不是8位！')
            logging.info(f'     {DICT_COLUMN_NAMES["对应的主体机构编码"]}{int(indexes[i]) + 7}对应的主体机构编码长度不是8位！')
            ctool.set_red_comment_type1(f'AN{int(indexes[i]) + 7}')
            ctool.concat_value(f'AO{int(indexes[i]) + 7}', f'{DICT_COLUMN_NAMES["对应的主体机构编码"]}、')
    ctool.save()


# 1.2.14 校验 组织机构编码 与 主体机构编码是否相同
"""
锁定【机构维护信息表-【AK-对应的主体机构编码】】不为空的单元格，检验其值是否与【机构维护信息表-【C-组织机构编码】】不同，若不同，见1；若相同，见2。

1.跳转执行下一规则；
2.若为“相同”，则在【机构维护信息表-【AK-对应的主体机构编码】】插入批注“对应的主体机构编码与组织机构编码相同！”，执行下一规则。
"""


def chk_1_2_14(filename: str):
    logging.info('1.2.14 校验 组织机构编码 与 主体机构编码是否相同')
    df_org_info = load_org_info(filename)
    # 找不是空的
    df_org_info_lite = df_org_info[~df_org_info['对应的主体机构编码'].isin([''])].copy()
    xh = df_org_info_lite['序号'].to_list()
    org_ids = df_org_info_lite['对应的主体机构编码'].to_list()
    org_ids2 = df_org_info_lite['组织机构编码'].to_list()
    ctool = WbTool(filename)
    for i in range(len(org_ids)):
        if org_ids[i] == org_ids2[i]:
            ctool.set_comment(f'{DICT_COLUMN_NAMES["对应的主体机构编码"]}{int(xh[i]) + 7}', '对应的主体机构编码与组织机构编码相同！')
            logging.info(f'     {DICT_COLUMN_NAMES["对应的主体机构编码"]}{int(xh[i]) + 7}对应的主体机构编码与组织机构编码相同！')
            ctool.set_red_comment_type1(f'AN{int(xh[i]) + 7}')
            ctool.concat_value(f'AO{int(xh[i]) + 7}', f'{DICT_COLUMN_NAMES["对应的主体机构编码"]}、')
    ctool.save()


# 1.2.15 校验 映射机构编码 是否有效
"""
锁定【机构维护信息表-【AL-对应的映射机构编码】】不为空的单元格，提取其值中纯数字的部分（含义为删除空格等字符），
检验其是否为8位，再回写到【机构维护信息表-【AL-对应的映射机构编码】】中，若是，见1；若不是，见2。

1.跳转执行下一规则；
2.若为“不是”，则在【机构维护信息表-【AL-对应的映射机构编码】】插入批注“对应的映射机构编码长度不是8位！”，执行下一规则。
"""


def chk_1_2_15(filename: str):
    logging.info('1.2.15 校验 映射机构编码 是否有效')
    df_org_info = load_org_info(filename)
    # 找不是空的
    df_org_info_lite = df_org_info[~df_org_info['对应的映射机构编码'].isin([''])].copy()
    indexes = df_org_info_lite['序号'].to_list()
    org_ids = df_org_info_lite['对应的映射机构编码'].to_list()
    org_ids = [str(i).replace(' ', '') for i in org_ids]
    org_ids = [i.replace('"', '') for i in org_ids]
    org_ids = [i.replace('“', '') for i in org_ids]
    org_ids = [i.replace('”', '') for i in org_ids]
    ctool = WbTool(filename)
    for i in range(len(org_ids)):
        ctool.sheetname[f'{DICT_COLUMN_NAMES["对应的映射机构编码"]}{int(indexes[i]) + 7}'].value = org_ids[i]
    # 校验长度为8
    for i in range(len(org_ids)):
        result = re.search('[0-9]{8}', org_ids[i])
        if not result or len(org_ids[i]) != 8:
            ctool.set_comment(f'{DICT_COLUMN_NAMES["对应的映射机构编码"]}{int(indexes[i]) + 7}', '对应的映射机构编码长度不是8位！')
            logging.info(f'     {DICT_COLUMN_NAMES["对应的映射机构编码"]}{int(indexes[i]) + 7}对应的映射机构编码长度不是8位！')
            ctool.set_red_comment_type1(f'AN{int(indexes[i]) + 7}')
            ctool.concat_value(f'AO{int(indexes[i]) + 7}', f'{DICT_COLUMN_NAMES["对应的映射机构编码"]}、')
    ctool.save()


# 1.2.16 校验 组织机构编码 与 映射机构编码 是否相同
"""
锁定【机构维护信息表-【AL-对应的映射机构编码】】不为空的单元格，检验其值是否与【机构维护信息表-【C-组织机构编码】】不同，若不同，见1；若相同，见2。
1.跳转执行下一规则；
2.若为“相同”，则在【机构维护信息表-【AL-对应的映射机构编码】】插入批注“对应的映射机构编码与组织机构编码相同！”，执行下一规则

"""


def chk_1_2_16(filename: str):
    logging.info('1.2.16 校验 组织机构编码 与 映射机构编码 是否相同')
    df_org_info = load_org_info(filename)
    # 找不是空的
    df_org_info_lite = df_org_info[~df_org_info['对应的映射机构编码'].isin([''])].copy()
    indexes = df_org_info_lite['序号'].to_list()
    org_ids = df_org_info_lite['对应的映射机构编码'].to_list()
    org_ids2 = df_org_info_lite['组织机构编码'].to_list()
    ctool = WbTool(filename)
    for i in range(len(org_ids)):
        if org_ids[i] == org_ids2[i]:
            ctool.set_comment(f'{DICT_COLUMN_NAMES["对应的映射机构编码"]}{int(indexes[i]) + 7}', '对应的映射机构编码与组织机构编码相同！')
            logging.info(f'     {DICT_COLUMN_NAMES["对应的映射机构编码"]}{int(indexes[i]) + 7}对应的映射机构编码与组织机构编码相同！')
            ctool.set_red_comment_type1(f'AN{int(indexes[i]) + 7}')
            ctool.concat_value(f'AO{int(indexes[i]) + 7}', f'{DICT_COLUMN_NAMES["对应的映射机构编码"]}、')
    ctool.save()


# 1.2.17
"""
检验【机构维护信息表-【AK-对应的主体机构编码】和【AL-对应的映射机构编码】】是否都有值，若是，见1；若不是，见2。

1.若为“都有值”，则在【机构维护信息表-【AK-对应的主体机构编码】和【AL-对应的映射机构编码】】插入批注“主体机构编码和映射机构编码只能填其中一项”，执行下一规则；
2.若为“不是都有值”，跳转执行下一规则。

"""


def chk_1_2_17(file):
    logging.info('1.2.16 校验 【AK-对应的主体机构编码】和【AL-对应的映射机构编码】】是否都有值')
    is_same_value(file, ['对应的主体机构编码', '对应的映射机构编码'], '主体机构编码和映射机构编码只能填其中一项')


# 1.2.18 刚性校验-增补项校验-人事范围/人事子范围
"""
检验【机构维护信息表-【AR-人事范围】的值是否为空，若是，见1，若不是，检验【机构维护信息表-【AR-人事范围】】是否是【码表库-【D-人事范围代码】】的值，若不是，见3；若是：
1.当【机构维护信息表-【B-维护类型】】的值为【码表库-【DR3-机构新增】】时，继续检验【机构维护信息表-【AS-人事子范围】】是否为空，若是，见2；
  若不是，在【码表库-【D-人事范围代码】】锁定与【机构维护信息表-【AR-人事范围】】相同的值，
  检验【机构维护信息表-【AS-人事子范围】】的值是否在限定范围的【码表库-【E-人事子范围】】中，若在，见5；若不在，见4；
2.当【机构维护信息表-【B-维护类型】】的值为【码表库-【DR4 或 DR5】】时，继续检验【机构维护信息表-【AS-人事子范围】】是否为空，若是，见5；
  若不是，在【码表库-【D-人事范围代码】】锁定与【机构维护信息表-【AR-人事范围】】相同的值，
  检验【机构维护信息表-【AS-人事子范围】】的值是否在限定范围的【码表库-【E-人事子范围】】中，若在，见5；若不在，见4。

1.若为“空”，则在【机构维护信息表-【AR-人事范围】】插入批注“人事范围必填！”，执行下一规则；
2.若为“空”，则在【机构维护信息表-【AS-人事子范围】】插入批注“人事子范围必填！”，执行下一规则；
3.若为“不是”，则在【机构维护信息表-【AR-人事范围】】插入批注“人事范围代码有误！”，执行下一规则；
4.若为“不是”，则在【机构维护信息表-【AS-人事子范围】】插入批注“人事子范围与人事范围不对应！”，执行下一规则
5.跳转执行下一规则；。
"""


def chk_1_2_18(filename: str):
    logging.info('1.2.18 刚性校验-增补项校验-人事范围/人事子范围')

    # 判断人事范围是否为空---》则在【机构维护信息表-【AR-人事范围】】插入批注“人事范围必填！”，执行下一规则
    if not cols_find_null(filename, ['人事范围'], '人事范围必填!'):
        return

    # 检验【机构维护信息表-【AR-人事范围】】是否是【码表库-【D-人事范围代码】】的值--->则在【机构维护信息表-【AR-人事范围】】插入批注“人事范围代码有误！”，执行下一规则

    df_org_info = load_org_info(filename)
    staff_rngs = df_org_info['人事范围'].to_list()
    indexes = df_org_info['序号'].to_list()

    ctool = WbTool(filename)
    rsfw_flag = True
    for i in range(len(staff_rngs)):
        queryset = [i for i in QueryFirst(table='Dim', db_D=staff_rngs[i])][0]
        if not queryset:
            ctool.set_comment(f'{DICT_COLUMN_NAMES["人事范围"]}{int(indexes[i]) + 7}', '人事范围代码有误！')
            logging.info(f'     {DICT_COLUMN_NAMES["人事范围"]}{int(indexes[i]) + 7}人事范围代码有误！')
            ctool.set_red_comment_type1(f'AN{int(indexes[i]) + 7}')
            ctool.concat_value(f'AO{int(indexes[i]) + 7}', f'{DICT_COLUMN_NAMES["人事范围"]}、')
            rsfw_flag = False
    ctool.save()
    if not rsfw_flag:
        return
    # --------------------------- 以上是人事范围总体判断（不为空，必须为码表库的值）------------------------------
    # 针对于【机构维护类型】为机构新增的情况

    # 当【机构维护信息表-【B-维护类型】】的值为【码表库-【DR3-机构新增】】时，继续检验【机构维护信息表-【AS-人事子范围】】是否为空，若是，
    if find_null_by_filter(filename, '机构维护类型', '机构新增', ['人事子范围'], '人事子范围必填！'):
        return

    # 校验人事范围与人事子范围是否对应
    jgxz_df = df_org_info[df_org_info['机构维护类型'].isin(['机构新增'])].copy()
    indexes = jgxz_df['序号'].to_list()
    staff_rngs = jgxz_df['人事范围'].to_list()
    staff_sub_rngs = jgxz_df['人事子范围'].to_list()
    flag_jgxz = True
    for i in range(len(staff_rngs)):
        queryset = [i for i in QueryFirst(table='Dim', db_D=staff_rngs[i], db_E=staff_sub_rngs[i])][0]
        if not queryset:
            ctool.set_comment(f'{DICT_COLUMN_NAMES["人事子范围"]}{int(indexes[i]) + 7}', '人事范围与人事子范围不对应！')
            logging.info(f'     {DICT_COLUMN_NAMES["人事子范围"]}{int(indexes[i]) + 7}人事范围与人事子范围不对应！')
            ctool.set_red_comment_type1(f'AN{int(indexes[i]) + 7}')
            ctool.concat_value(f'AO{int(indexes[i]) + 7}', f'{DICT_COLUMN_NAMES["人事子范围"]}、')
            flag_jgxz = False
    ctool.save()
    if not flag_jgxz:
        return

    # 针对于 【机构更名】与【机构调整】
    jgtz_df = df_org_info[df_org_info['机构维护类型'].isin(['机构更名', '机构调整']) & ~df_org_info['人事子范围'].isin([''])].copy()
    jgtz_rsfw = jgtz_df['人事范围'].to_list()
    jgtz_rszfw = jgtz_df['人事子范围'].to_list()
    jgtz_xh = jgtz_df['序号'].to_list()
    if jgtz_xh:
        for i in range(len(jgtz_rsfw)):
            queryset = [i for i in QueryFirst(table='Dim', db_D=jgtz_rsfw[i], db_E=jgtz_rszfw[i])][0]
            if not queryset:
                ctool.set_comment(f'{DICT_COLUMN_NAMES["人事子范围"]}{int(jgtz_xh[i]) + 7}', '人事范围与人事子范围不对应！')
                logging.info(f'     {DICT_COLUMN_NAMES["人事子范围"]}{int(jgtz_xh[i]) + 7}人事范围与人事子范围不对应！')
                ctool.set_red_comment_type1(f'AN{int(jgtz_xh[i]) + 7}')
                ctool.concat_value(f'AO{int(jgtz_xh[i]) + 7}', f'{DICT_COLUMN_NAMES["人事子范围"]}、')
        ctool.save()


# 1.2.19 刚性校验-增补项校验-国籍/省份
"""
"检验【机构维护信息表-【AT-国籍】和【AU-省份】】的值是否都为空，若是，见1；若不是:
1.继续检验【机构维护信息表-【AT-国籍】】的值是否为空值，若是，见2；若不是：
2.继续检验【机构维护信息表-【AT-国籍】】的值是否为【码表库-【EV48】】的值，若不是，见3；若是：
3.继续检验【机构维护信息表-【AU-省份】】的值是否为空，
        若为空值，见4；
        若不为空值，检验【机构维护信息表-【AU-省份】】是否是【码表库-【EW-省（自治区、直辖市）】】的值，若是，见1；若不是，见5。"


1.跳转执行下一规则；
2.若为“是”，则在【机构维护信息表-【AT-国籍】】插入批注“国籍不能为空！”，执行下一规则；
3.若为“不是”，则在【机构维护信息表-【AT-国籍】】插入批注“请勿填写【CN  中国】以外的国籍！”，执行下一规则；
4.若为“空值”，则在【机构维护信息表-【AU-省份】】插入批注“省份不能为空！”，执行下一规则；
5.若为“不是”，则在【机构维护信息表-【AU-省份】】插入批注“省份非码值！”，执行下一规则。
"""


def chk_1_2_19(filename: str):
    logging.info('1.2.19 刚性校验-增补项校验-国籍/省份')
    ctool = WbTool(filename)
    df_org_info = load_org_info(filename)

    # 国籍不为空，省份为空的数据
    df_empty_prov_name = df_org_info[~df_org_info['国籍'].isin(['']) & df_org_info['省份'].isin([''])].copy()
    prov_names = df_empty_prov_name['省份'].to_list()
    if prov_names:
        sheng_xh = df_empty_prov_name['序号'].to_list()
        for i in range(len(sheng_xh)):
            ctool.set_comment(f'{DICT_COLUMN_NAMES["省份"]}{int(sheng_xh[i]) + 7}', '省份不能为空！')
            logging.info(f'     {DICT_COLUMN_NAMES["省份"]}{int(sheng_xh[i]) + 7}省份不能为空！')
            ctool.set_red_comment_type1(f'AN{int(sheng_xh[i]) + 7}')
            ctool.concat_value(f'AO{int(sheng_xh[i]) + 7}', f'{DICT_COLUMN_NAMES["省份"]}、')

    # 省份不为空  国籍为空的数据
    df_empty_nation_name = df_org_info[~df_org_info['省份'].isin(['']) & df_org_info['国籍'].isin([''])].copy()
    prov_names = df_empty_nation_name['省份'].to_list()
    if prov_names:
        guo_xh = df_empty_nation_name['序号'].to_list()
        for i in range(len(guo_xh)):
            ctool.set_comment(f'{DICT_COLUMN_NAMES["国籍"]}{int(guo_xh[i]) + 7}', '国籍不能为空！')
            logging.info(f'     {DICT_COLUMN_NAMES["国籍"]}{int(guo_xh[i]) + 7}国籍不能为空！')
            ctool.set_red_comment_type1(f'AN{int(guo_xh[i]) + 7}')
            ctool.concat_value(f'AO{int(guo_xh[i]) + 7}', f'{DICT_COLUMN_NAMES["国籍"]}、')

    # 校验省份码值
    sheng_all = df_org_info[~df_org_info['省份'].isin([''])].copy()
    sheng_list = sheng_all['省份'].to_list()
    sxh = sheng_all['序号'].to_list()

    for i in range(len(sheng_list)):
        queryset = [i for i in QueryFirst(table='Dim', db_EW=sheng_list[i])][0]
        if not queryset:
            ctool.set_comment(f'{DICT_COLUMN_NAMES["省份"]}{int(sxh[i]) + 7}', '省份非码值！')
            logging.info(f'     {DICT_COLUMN_NAMES["省份"]}{int(sxh[i]) + 7}省份非码值！')
            ctool.set_red_comment_type1(f'AN{int(sxh[i]) + 7}')
            ctool.concat_value(f'AO{int(sxh[i]) + 7}', f'{DICT_COLUMN_NAMES["省份"]}、')
    # 校验国籍码值
    guo_all = df_org_info[~df_org_info['国籍'].isin([''])].copy()
    guo_list = guo_all['国籍'].to_list()
    gxh = guo_all['序号'].to_list()

    for i in range(len(guo_list)):
        if guo_list[i] != 'CN  中国':
            ctool.set_comment(f'{DICT_COLUMN_NAMES["国籍"]}{int(gxh[i]) + 7}', '请勿填写【CN  中国】以外的国籍！')
            logging.info(f'     {DICT_COLUMN_NAMES["国籍"]}{int(gxh[i]) + 7}请勿填写【CN  中国】以外的国籍！')
            ctool.set_red_comment_type1(f'AN{int(gxh[i]) + 7}')
            ctool.concat_value(f'AO{int(gxh[i]) + 7}', f'{DICT_COLUMN_NAMES["国籍"]}、')
    ctool.save()


# 1.2.20 刚性校验-增补项校验-业务范围
"""
锁定【机构维护信息表-【AV-业务范围】】不为空的单元格，检验其值是否为【码表库-【BO-业务范围】】的值，若是，见1；若不是，见5。

1.跳转执行下一规则；
2.若为“不是”，则在【机构维护信息表-【AV-业务范围】】插入批注“业务范围非码值！”，执行下一规则

"""


def chk_1_2_20(filename: str):
    logging.info('1.2.20 刚性校验-增补项校验-业务范围')
    ctool = WbTool(filename)
    jgwhxxb = load_org_info(filename)
    filter_ywfw = jgwhxxb[~jgwhxxb['业务范围'].isin([''])].copy()
    ywfw = filter_ywfw['业务范围'].to_list()
    ywfw_xh = filter_ywfw['序号'].to_list()
    if ywfw:
        for i in range(len(ywfw)):
            queryset = [i for i in QueryFirst(table='Dim', db_BO=ywfw[i])][0]
            if not queryset:
                ctool.set_comment(f'{DICT_COLUMN_NAMES["业务范围"]}{int(ywfw_xh[i]) + 7}', '业务范围非码值！')
                logging.info(f'     {DICT_COLUMN_NAMES["业务范围"]}{int(ywfw_xh[i]) + 7}业务范围非码值！')
                ctool.set_red_comment_type1(f'AN{int(ywfw_xh[i]) + 7}')
                ctool.concat_value(f'AO{int(ywfw_xh[i]) + 7}', f'{DICT_COLUMN_NAMES["业务范围"]}、')
    ctool.save()


# 1.2.21 刚性校验-弥补性校验-单位级别
"""
锁定【机构维护信息表-【N-单位级别】】不为空的单元格，检验其值是否存在于【码表库-【DX3至DX8】】，若是，见1；若不是，见2。

1.若为“是”，则在【机构维护信息表-【N-单位级别】】插入批注“非中层RPA不操作副局级以上的机构！”，执行下一规则；
2.若为“不是”，跳转执行下一规则

"""


def chk_1_2_21(filename: str):
    logging.info('1.2.21 刚性校验-弥补性校验-单位级别')
    with DbSession() as session:
        dims_unit_levels = [list(i)[0] for i in session.query(Event.db_DX).all() if list(i)[0] != ''][:6]  # pylint: disable=fixme, no-member
        ctool = WbTool(filename)
        df_org_info = load_org_info(filename)
        filter_dwjb = df_org_info[~df_org_info['单位级别'].isin([''])].copy()
        unit_levels = filter_dwjb['单位级别'].to_list()
        indexes = filter_dwjb['序号'].to_list()
        if unit_levels:
            for i in range(len(unit_levels)):
                if unit_levels[i] in dims_unit_levels:
                    ctool.set_comment(f'{DICT_COLUMN_NAMES["单位级别"]}{int(indexes[i]) + 7}', '非中层RPA不操作副处级以上的机构！')
                    logging.info(f'     {DICT_COLUMN_NAMES["单位级别"]}{int(indexes[i]) + 7}非中层RPA不操作副处级以上的机构！')
                    ctool.set_red_comment_type1(f'AN{int(indexes[i]) + 7}')
                    ctool.concat_value(f'AO{int(indexes[i]) + 7}', f'{DICT_COLUMN_NAMES["单位级别"]}、')
        ctool.save()


# 回传ftp 与写库
def upload_to_ftp(filename: str, state: str, desc: str, indexes: List[str] = [], error_msg=None):
    from pathlib import Path

    from rpa.ssc_rpa.hr.rpa_ji_gou_wei_hu.ftp_control import (FTP_PATH,
                                                              SAVE_PATH)
    dir_name = Path(filename).name[:-5]

    # 上传ftp
    with MYFTP() as ftp:
        ftp_save_path = FTP_PATH + f'/{state}/' + dir_name
        ftp.upload_file_tree(SAVE_PATH, ftp_save_path)

    # FIXME: 更新PRA执行结果
    # if state in ('成功', '失败'):
    #     is_succ = True if state == '成功' else False
    #     lt = load_from_xlsx_file(filename, skip_header=7)
    #     result = []
    #     for row in lt.rows:
    #         staff_rng = row['AR'].value  # 人事范围
    #         org_id = row['C'].value  # 组织机构编码
    #         result.append({'人事范围': staff_rng,
    #                        '对象ID': org_id,
    #                        '执行结果': is_succ})
    #     rpa_result(result)

    # 写入数据库log表，结束时间，耗时 描述 结果；详情表：序号 机构维护类型  组织机构编码  人事范围  详情
    # 20210207 更新：
    # sr = dir_name.split('-')[0]
    # with Session() as session:
    #     res = session.query(TB_HR_NON_MID).filter_by(sr=sr, remaker=None).first()  # pylint: disable=fixme, no-member
    #     if res:
    #         start_time = res.start_time
    #         primary_id = res.id
    #         end_time = time.strftime('%Y-%m-%d %H:%M:%S', time.localtime())
    #         use_time = datetime.strptime(end_time, '%Y-%m-%d %H:%M:%S') - start_time
    #         # 更新log表
    #         session.query(TB_HR_NON_MID).filter_by(sr=sr, remaker=None).update(  # pylint: disable=fixme, no-member
    #             {'remaker': f'{state}', 'desc': desc, 'end_time': end_time, 'use_time': use_time})
    #         # logging.info(indexes)
    #         # logging.info(error_msg)
    #         # 附件标准格式校验不需要更新详情表
    #         if indexes and error_msg:
    #             # 更新详情表
    #             for i in range(len(indexes)):
    #                 session.query(TB_HR_NON_MID_DETAIL).filter_by(sr_id=primary_id, desc=None, no=indexes[i]).update({'desc': f'{error_msg[i]}'})  # pylint: disable=fixme, no-member
    #         session.commit()  # pylint: disable=fixme, no-member


# 校验日期合法性
def is_yyyymmdd(yyyymmdd: str):
    try:
        datetime.strptime(str(yyyymmdd), '%Y%m%d')
        return True
    except ValueError:
        return False


if __name__ == '__main__':
    filename = r"x:\非中层\1000181728-江苏石油-组织机构维护-常金兰-1.xlsx"
    chk_1_2_4(filename)
