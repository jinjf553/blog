from typing import List

from rpa.ssc_rpa.hr.rpa_ji_gou_wei_hu.checker.check_is_logic_correct import \
    check_is_logic_correct
from rpa.ssc_rpa.hr.rpa_ji_gou_wei_hu.checker.check_must_fill import (
    check_is_file_changed, check_must_fill)
from rpa.ssc_rpa.hr.rpa_ji_gou_wei_hu.checker.check_relation import \
    check_is_rel_correct
from rpa.ssc_rpa.hr.rpa_ji_gou_wei_hu.checker.check_with_dims import \
    check_with_dims


# 校验
def before_check(filename: str) -> bool:
    is_check_passed: List[bool] = []
    is_check_passed.append(check_is_file_changed(filename))  # 非标准表单校验
    is_check_passed.append(check_must_fill(filename))  # 刚性校验
    is_check_passed.append(check_is_logic_correct(filename))  # 逻辑校验
    is_check_passed.append(check_with_dims(filename))  # 码值校验
    is_check_passed.append(check_is_rel_correct(filename))  # 勾稽关系校验
    return all(is_check_passed) is True
