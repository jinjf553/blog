import pandas as pd


def load_org_info(filename: str) -> pd.DataFrame:
    """机构维护信息表（删除AQ列的版本）"""
    column_names = ['序号', '机构维护类型', '组织机构编码', '组织机构简称', '组织机构全称', '单位简化全称',
                    '上级机构编码', '机构审批文号', '开始日期', '集团/股份标识', '单位板块', '事业部类别',
                    '机构层次', '单位级别', '单位业务类别', '单位业务分布', '机关部门管理职能分类', '分流单位类型',
                    '虚机构标识', '基层机构类别大类', '基层机构类别小类', '主成本中心', '油品销售企业行政属性',
                    '油品销售企业管理层级', '油品销售企业业务属性', '加油站类型', '加油站属性', '加油站地理属性',
                    '星级', '加油站营业状态', '加油站日均营业时间', '日开始营业时间', '日结束营业时间', '设便利店标识',
                    '设售卡网点标识', '加油站规模', '对应的主体机构编码', '对应的映射机构编码', '备注', '是否成功',
                    '错误描述', '节点定位', '节点提示', '人事范围', '人事子范围', '国籍', '省份', '业务范围']
    df_org_info = pd.read_excel(filename, header=None, keep_default_na=False, skiprows=range(7), names=column_names)
    df_org_info_lite = df_org_info.drop(columns=['节点提示'])  # 由于规则中定位列是按照序号来的，[AQ-节点提示]列影响规则处理，故删除（开发前不存在，开发后才存在）
    df_org_info_lite['人事范围'] = df_org_info_lite['人事范围'].apply(lambda v: str(v))
    df_org_info_lite['组织机构编码'] = df_org_info_lite['组织机构编码'].apply(lambda v: str(v))
    df_org_info_lite['上级机构编码'] = df_org_info_lite['上级机构编码'].apply(lambda v: str(v))
    df_org_info_lite['开始日期'] = df_org_info_lite['开始日期'].apply(lambda v: str(v))
    return df_org_info_lite


def load_org_info2(filename: str) -> pd.DataFrame:
    """机构维护信息表（不删除AQ列的版本）"""
    column_names = ['序号', '机构维护类型', '组织机构编码', '组织机构简称', '组织机构全称', '单位简化全称',
                    '上级机构编码', '机构审批文号', '开始日期', '集团/股份标识', '单位板块', '事业部类别',
                    '机构层次', '单位级别', '单位业务类别', '单位业务分布', '机关部门管理职能分类', '分流单位类型',
                    '虚机构标识', '基层机构类别大类', '基层机构类别小类', '主成本中心', '油品销售企业行政属性',
                    '油品销售企业管理层级', '油品销售企业业务属性', '加油站类型', '加油站属性', '加油站地理属性',
                    '星级', '加油站营业状态', '加油站日均营业时间', '日开始营业时间', '日结束营业时间', '设便利店标识',
                    '设售卡网点标识', '加油站规模', '对应的主体机构编码', '对应的映射机构编码', '备注', '是否成功',
                    '错误描述', '节点定位', '节点提示', '人事范围', '人事子范围', '国籍', '省份', '业务范围']
    df_org_info = pd.read_excel(filename, header=None, keep_default_na=False, skiprows=range(7), names=column_names)
    df_org_info_lite = df_org_info
    df_org_info_lite['人事范围'] = df_org_info_lite['人事范围'].apply(lambda v: str(v))
    df_org_info_lite['组织机构编码'] = df_org_info_lite['组织机构编码'].apply(lambda v: str(v))
    df_org_info_lite['上级机构编码'] = df_org_info_lite['上级机构编码'].apply(lambda v: str(v))
    df_org_info_lite['开始日期'] = df_org_info_lite['开始日期'].apply(lambda v: str(v))
    return df_org_info_lite


# 获取 组织机构编码  和 开始时间
def get_org_and_time(filename: str):
    clean_df = load_org_info(filename)
    df_org = clean_df[clean_df['机构维护类型'].isin(['机构新增'])].copy()
    org_ids = df_org['组织机构编码'].to_list()
    start_times = df_org['开始日期'].to_list()
    indexes = df_org['序号'].to_list()
    return org_ids, start_times, indexes


# 获取附件表中的 序号  组织机构简称
def get_no_org(file):
    desc_df = load_org_info(file)
    xuhao = desc_df['序号'].tolist()
    short_org = desc_df['组织机构简称'].tolist()
    return xuhao, short_org


if __name__ == '__main__':
    df_org_info = load_org_info(
        r"x:\rpa\files\非中层组织机构维护\1000182071-西南石油局-组织机构维护-常金兰(2)\1000182071-西南石油局-组织机构维护-常金兰(2).xlsx")
    clean_jgwhxxb_df_filter = df_org_info[
        df_org_info['机构维护类型'].isin(['机构新增', '机构调整']) & df_org_info['人事范围'].isin([int('5647')])].copy()
    print(clean_jgwhxxb_df_filter)
