import logging
from typing import Optional

import pandas as pd
from rpa.ssc_rpa.hr.rpa_ji_gou_wei_hu.create.generate_org_info import (
    load_org_info, load_org_info2)
from rpa.ssc_rpa.hr.rpa_ji_gou_wei_hu.ftp_control import SAVE_PATH
from rpa.ssc_rpa.hr.rpa_ji_gou_wei_hu.orm.orm_ope import (
    query_dims_corp_ids, query_dims_staff_rngs)
from rpa.ssc_rpa.hr.rpa_ji_gou_wei_hu.tools.excel_tool import WbCreateTool

MAX_END_DATE = '99991231'


def generate_other_template(filename: str):
    """
    创建所有非主要模板
    :param filename: 附件路径
    :return:None
    """
    generate_9010(filename)
    generate_9068(filename)
    generate_1008(filename)
    generate_9004(filename)
    generate_9007(filename)
    generate_9014(filename)
    generate_9022(filename)
    generate_9064(filename)
    generate_1001(filename)


# 创建1000_HR_BI_1000O--人员导入--创建组织机构.xlsx 模板----yc
def generate_1000_o_template(filename: str) -> Optional[str]:
    df_org_info = load_org_info(filename)
    df_org_info_lite = df_org_info[df_org_info['机构维护类型'].isin(['机构新增'])].copy()
    row_num = df_org_info_lite.shape[0]
    if row_num:
        df_org_info_lite['序号'] = [str(i + 1) for i in range(row_num)]  # 先改变序号
        wct_1000_o = WbCreateTool('1000_HR_BI_1000O--人员导入--创建组织机构.xlsx')
        wct_1000_o.set_col_range_value('中文名称', 7, df_org_info_lite['序号'].to_list())
        wct_1000_o.set_col_range_value('组织机构编码', 7, df_org_info_lite['组织机构编码'].to_list())
        wct_1000_o.set_col_range_value('开始日期', 7, df_org_info_lite['开始日期'].to_list())
        wct_1000_o.rep_col_range_value('结束日期', 7, df_org_info_lite.shape[0], MAX_END_DATE)
        wct_1000_o.set_col_range_value('简称', 7, df_org_info_lite['组织机构简称'].to_list())
        wct_1000_o.set_col_range_value('全称', 7, df_org_info_lite['组织机构全称'].to_list())
        wct_1000_o.save()
        return SAVE_PATH + r'/1000_HR_BI_1000O--人员导入--创建组织机构.xlsx'
    return None

# 创建 1001_HR_BI_A002OO--人员导入--指定机构的直接上级机构.xlsx 模板----yc


def generate_a00_2oo_template(filename: str) -> Optional[str]:
    """锁定【机构维护信息表-【B-机构维护类型】】的值为【码表库-【DR3-机构新增】和【DR5-机构调整】且【AQ-节点提示】的值为“需要调整隶属机构” 】的行：
       1.提取【机构维护信息表-【C、I、G】】的值，复制到【1001_HR_BI_A002OO·····指定机构的直接上级机构-【B、D、F】】；
       2.在【1001_HR_BI_A002OO·····指定机构的直接上级机构-【E-结束日期】】输入“99991231”；
       3.在【1001_HR_BI_A002OO·····指定机构的直接上级机构-【A-结束日期】】填补序号。'
    """
    df_org_info = load_org_info2(filename)
    df_org_info_lite_tmp1 = df_org_info[df_org_info['机构维护类型'] == '机构新增'].copy()
    df_org_info_lite_tmp2 = df_org_info[(df_org_info['机构维护类型'] == '机构调整') & (df_org_info['节点提示'] == '需要调整隶属机构')].copy()
    df_org_info_lite = df_org_info_lite_tmp1.append(df_org_info_lite_tmp2).copy()
    row_num = df_org_info_lite.shape[0]
    if row_num:
        df_org_info_lite['序号'] = [str(i + 1) for i in range(row_num)]  # 先改变序号
        wct_1001 = WbCreateTool('1001_HR_BI_A002OO--人员导入--指定机构的直接上级机构.xlsx')
        wct_1001.set_col_range_value('中文名称', 7, df_org_info_lite['序号'].to_list())
        wct_1001.set_col_range_value('组织机构编码', 7, df_org_info_lite['组织机构编码'].to_list())
        wct_1001.set_col_range_value('开始日期', 7, df_org_info_lite['开始日期'].to_list())
        wct_1001.rep_col_range_value('结束日期', 7, df_org_info_lite.shape[0], MAX_END_DATE)
        wct_1001.set_col_range_value('上级机构编码', 7, df_org_info_lite['上级机构编码'].to_list())
        wct_1001.save()
        return SAVE_PATH + '/1001_HR_BI_A002OO--人员导入--指定机构的直接上级机构.xlsx'
    return None
# 9005_HR_BI_9005-10010060--人员导入--机构分类属性.xlsx----yc


def generate_9005_template(filename: str) -> Optional[str]:
    df_org_info = load_org_info(filename)
    df_org_info_2 = df_org_info[df_org_info['机构维护类型'].isin(['机构新增', '机构调整'])].copy()
    df_org_info_2 = df_org_info_2[~df_org_info_2['集团/股份标识'].isin(['']) |
                                  ~df_org_info_2['单位板块'].isin(['']) |
                                  ~df_org_info_2['机构层次'].isin(['']) |
                                  ~df_org_info_2['单位业务类别'].isin(['']) |
                                  ~df_org_info_2['单位业务分布'].isin([''])].copy()
    staff_rngs = set(df_org_info_2['人事范围'].tolist())
    if len(staff_rngs) > 0:
        for i in staff_rngs:
            df_org_info_3 = df_org_info_2[df_org_info_2['人事范围'].isin([i])].copy()
            logging.info(df_org_info_3)
            df_org_info_3['序号'] = [str(i + 1) for i in range(df_org_info_3.shape[0])]  # 先改变序号
            wct_9005 = WbCreateTool('9005_HR_BI_9005-10010060--人员导入--机构分类属性.xlsx')
            wct_9005.set_col_range_value('中文名称', 7, df_org_info_3['序号'].to_list())
            wct_9005.set_col_range_value('组织机构编码', 7, df_org_info_3['组织机构编码'].to_list())
            wct_9005.set_col_range_value('开始日期', 7, df_org_info_3['开始日期'].to_list())
            wct_9005.rep_col_range_value('结束日期', 7, df_org_info_3.shape[0], MAX_END_DATE)
            wct_9005.set_col_range_value('集团/股份标识', 7, df_org_info_3['集团/股份标识'].to_list())
            wct_9005.set_col_range_value('单位板块', 7, df_org_info_3['单位板块'].to_list())
            wct_9005.set_col_range_value('事业部类别', 7, df_org_info_3['事业部类别'].to_list())
            wct_9005.set_col_range_value('机构层次', 7, df_org_info_3['机构层次'].to_list())
            wct_9005.set_col_range_value('单位级别', 7, df_org_info_3['单位级别'].to_list())
            wct_9005.set_col_range_value('单位业务类别', 7, df_org_info_3['单位业务类别'].to_list())
            wct_9005.set_col_range_value('单位业务分布', 7, df_org_info_3['单位业务分布'].to_list())

            wct_9005.set_col_range_value('机关部门管理职能分类', 7, df_org_info_3['机关部门管理职能分类'].to_list())
            wct_9005.set_col_range_value('分流单位类型', 7, df_org_info_3['分流单位类型'].to_list())
            wct_9005.save(file_name=f'9005_HR_BI_9005-10010060--人员导入--机构分类属性{i}.xlsx')
        return SAVE_PATH + '/9005_HR_BI_9005-10010060--人员导入--机构分类属性.xlsx'
    return None

# 9010_HR_BI_9010--人员导入--通讯地址.xlsx


def generate_9010(filename: str) -> Optional[str]:
    df_org_info = load_org_info(filename)
    df_org_info_2 = df_org_info[df_org_info['机构维护类型'].isin(['机构调整']) & ~df_org_info['国籍'].isin([''])].copy()
    df_tmp = df_org_info[df_org_info['机构维护类型'].isin(['机构新增'])].copy()
    df_org_info_3 = pd.concat([df_org_info_2, df_tmp], axis=0, ignore_index=True)
    row_num = df_org_info_3.shape[0]
    if row_num:
        df_org_info_3['序号'] = [str(i + 1) for i in range(row_num)]  # 先改变序号
        wct_9010 = WbCreateTool('9010_HR_BI_9010--人员导入--通讯地址.xlsx')
        wct_9010.set_col_range_value('中文名称', 7, df_org_info_3['序号'].to_list())
        wct_9010.set_col_range_value('组织机构编码', 7, df_org_info_3['组织机构编码'].to_list())
        wct_9010.set_col_range_value('开始日期', 7, df_org_info_3['开始日期'].to_list())
        wct_9010.rep_col_range_value('结束日期', 7, df_org_info_3.shape[0], MAX_END_DATE)
        wct_9010.set_col_range_value('国家（地区）', 7, df_org_info_3['国籍'].to_list())
        wct_9010.set_col_range_value('省（自治区、直辖市）', 7, df_org_info_3['省份'].to_list())
        wct_9010.save()
        return SAVE_PATH + '/9010_HR_BI_9010--人员导入--通讯地址.xlsx'
    return None

# 9068_HR_BI_9068--人员导入--单位简化全称.xlsx----yc


def generate_9068(filename: str) -> Optional[str]:
    df_org_info = load_org_info(filename)
    df_org_info_2 = df_org_info[
        df_org_info['机构维护类型'].isin(['机构新增']) | df_org_info['节点定位'].str.contains('F')].copy()
    row_num = df_org_info_2.shape[0]
    if row_num:
        df_org_info_2['序号'] = [str(i + 1) for i in range(row_num)]  # 先改变序号
        wct_9068 = WbCreateTool('9068_HR_BI_9068--人员导入--单位简化全称.xlsx')
        wct_9068.set_col_range_value('中文名称', 7, df_org_info_2['序号'].to_list())
        wct_9068.set_col_range_value('组织机构编码', 7, df_org_info_2['组织机构编码'].to_list())
        wct_9068.set_col_range_value('开始日期', 7, df_org_info_2['开始日期'].to_list())
        wct_9068.rep_col_range_value('结束日期', 7, df_org_info_2.shape[0], MAX_END_DATE)
        wct_9068.set_col_range_value('单位简化全称', 7, df_org_info_2['单位简化全称'].to_list())
        wct_9068.save()
        return SAVE_PATH + '/9068_HR_BI_9068--人员导入--单位简化全称.xlsx'
    return None

# 1008_HR_BI_1008--人员导入--财务科目设置.xlsx--yc


def generate_1008(filename: str) -> Optional[str]:
    df_org_info = load_org_info(filename)
    df_org_info_2 = df_org_info[
        df_org_info['机构维护类型'].isin(['机构调整']) & ~df_org_info['人事子范围'].isin([''])].copy()
    df_tmp = df_org_info[df_org_info['机构维护类型'].isin(['机构新增'])].copy()
    df_org_info_3 = pd.concat([df_org_info_2, df_tmp], axis=0, ignore_index=True)
    row_num = df_org_info_3.shape[0]
    if row_num:
        df_org_info_3['序号'] = [str(i + 1) for i in range(row_num)]  # 先改变序号
        wct_1008 = WbCreateTool('1008_HR_BI_1008--人员导入--财务科目设置.xlsx')
        wct_1008.set_col_range_value('中文名称', 7, df_org_info_3['序号'].to_list())
        wct_1008.set_col_range_value('机构编码', 7, df_org_info_3['组织机构编码'].to_list())
        wct_1008.set_col_range_value('开始日期', 7, df_org_info_3['开始日期'].to_list())
        wct_1008.rep_col_range_value('结束日期', 7, df_org_info_3.shape[0], MAX_END_DATE)
        wct_1008.set_col_range_value('人事子范围', 7, df_org_info_3['人事子范围'].to_list())
        wct_1008.set_col_range_value('业务范围', 7, df_org_info_3['业务范围'].to_list())
        # 码表库查找公司代码
        dims_corp_ids = map(lambda x: query_dims_corp_ids(x) if x else '',
                            df_org_info_3['人事范围'].to_list())
        wct_1008.set_col_range_value('公司代码', 7, list(dims_corp_ids))
        # 码表库查找人事范围
        dims_staff_rngs = map(lambda x: query_dims_staff_rngs(x) if x else '', df_org_info_3['人事范围'].to_list())
        wct_1008.set_col_range_value('人事范围', 7, list(dims_staff_rngs))
        wct_1008.save()
        return SAVE_PATH + '/1008_HR_BI_1008--人员导入--财务科目设置.xlsx'
    return None

# 9004_HR_BI_9004--人员导入--注册登记信息.xlsx --yc


def generate_9004(filename: str) -> Optional[str]:
    df_org_info = load_org_info(filename)
    df_org_info_2 = df_org_info[df_org_info['机构维护类型'].isin(['机构新增', '机构调整'])].copy()

    # 抓取机构审批文号不为空 与 虚机构标识不为否的数据
    df_org_info_2_lit = df_org_info_2[~df_org_info_2['机构审批文号'].isin(['']) | df_org_info_2['虚机构标识'].isin(['是'])].copy()
    row_num = df_org_info_2_lit.shape[0]
    if row_num:
        df_org_info_2_lit['序号'] = [str(i + 1) for i in range(row_num)]  # 先改变序号
        wct_9004 = WbCreateTool('9004_HR_BI_9004--人员导入--注册登记信息.xlsx')
        wct_9004.set_col_range_value('中文名称', 7, df_org_info_2_lit['序号'].to_list())
        wct_9004.set_col_range_value('组织机构编码', 7, df_org_info_2_lit['组织机构编码'].to_list())
        wct_9004.set_col_range_value('开始日期', 7, df_org_info_2_lit['开始日期'].to_list())
        wct_9004.rep_col_range_value('结束日期', 7, df_org_info_2_lit.shape[0], MAX_END_DATE)
        wct_9004.set_col_range_value('批准文号', 7, df_org_info_2_lit['机构审批文号'].to_list())
        wct_9004.set_col_range_value('虚机构标识', 7, ['X' if x else '' for x in df_org_info_2_lit['虚机构标识'].to_list()])
        wct_9004.save()
        return SAVE_PATH + '/9004_HR_BI_9004--人员导入--注册登记信息.xlsx'
    else:
        logging.info('不需要创建【9004-注册登记信息模板】')
    return None

# 9007_HR_BI_9007--人员导入--基层单位特有属性.xlsx -- yc


def generate_9007(filename: str) -> Optional[str]:
    df_org_info = load_org_info(filename)
    df_org_info_2 = df_org_info[df_org_info['机构维护类型'].isin(['机构新增', '机构调整'])].copy()

    # 抓取基层机构类别大类不为空
    df_org_info_2_lite = df_org_info_2[~df_org_info_2['基层机构类别大类'].isin([''])].copy()
    row_num = df_org_info_2_lite.shape[0]
    if row_num:
        df_org_info_2_lite['序号'] = [str(i + 1) for i in range(row_num)]  # 先改变序号
        wct_9007 = WbCreateTool('9007_HR_BI_9007--人员导入--基层单位特有属性.xlsx')
        wct_9007.set_col_range_value('中文名称', 7, df_org_info_2_lite['序号'].to_list())
        wct_9007.set_col_range_value('组织机构编码', 7, df_org_info_2_lite['组织机构编码'].to_list())
        wct_9007.set_col_range_value('开始日期', 7, df_org_info_2_lite['开始日期'].to_list())
        wct_9007.rep_col_range_value('结束日期', 7, df_org_info_2_lite.shape[0], MAX_END_DATE)
        wct_9007.set_col_range_value('基层机构类别大类', 7, df_org_info_2_lite['基层机构类别大类'].to_list())
        wct_9007.set_col_range_value('基层机构类别小类', 7, df_org_info_2_lite['基层机构类别小类'].to_list())
        wct_9007.save()
        return SAVE_PATH + '/9007_HR_BI_9007--人员导入--基层单位特有属性.xlsx'
    else:
        logging.info('不需要创建【9007-基层单位特有属性模板】')
    return None

# 9014_HR_BI_9014--人员导入--加油站信息.xlsx -- yc


def generate_9014(filename: str) -> Optional[str]:
    df_org_info = load_org_info(filename)
    df_org_info_2 = df_org_info[df_org_info['机构维护类型'].isin(['机构新增', '机构调整'])].copy()
    # 抓取加油站类型不为空
    df_org_info_2_lite = df_org_info_2[~df_org_info_2['加油站类型'].isin([''])].copy()
    row_num = df_org_info_2_lite.shape[0]
    if row_num:
        df_org_info_2_lite['序号'] = [str(i + 1) for i in range(row_num)]  # 先改变序号
        wct_9014 = WbCreateTool('9014_HR_BI_9014--人员导入--加油站信息.xlsx')
        wct_9014.set_col_range_value('中文名称', 7, df_org_info_2_lite['序号'].to_list())
        wct_9014.set_col_range_value('组织机构编码', 7, df_org_info_2_lite['组织机构编码'].to_list())
        wct_9014.set_col_range_value('开始日期', 7, df_org_info_2_lite['开始日期'].to_list())
        wct_9014.rep_col_range_value('结束日期', 7, df_org_info_2_lite.shape[0], MAX_END_DATE)
        wct_9014.set_col_range_value('加油站类型', 7, df_org_info_2_lite['加油站类型'].to_list())
        wct_9014.set_col_range_value('加油站属性', 7, df_org_info_2_lite['加油站属性'].to_list())
        wct_9014.set_col_range_value('加油站地理属性', 7, df_org_info_2_lite['加油站地理属性'].to_list())
        wct_9014.set_col_range_value('星级', 7, df_org_info_2_lite['星级'].to_list())
        wct_9014.set_col_range_value('加油站营业状态', 7, df_org_info_2_lite['加油站营业状态'].to_list())
        wct_9014.set_col_range_value('加油站日均营业时间', 7, df_org_info_2_lite['加油站日均营业时间'].to_list())
        wct_9014.set_col_range_value('日开始营业时间', 7,
                                     [x.replace('：', ':') for x in df_org_info_2_lite['日开始营业时间'].to_list()])
        wct_9014.set_col_range_value('日结束营业时间', 7,
                                     [x.replace('：', ':') for x in df_org_info_2_lite['日结束营业时间'].to_list()])
        wct_9014.set_col_range_value('设便利店标识', 7,
                                     ['X' if i == '是' else '' for i in df_org_info_2_lite['设便利店标识'].to_list()])
        wct_9014.set_col_range_value('设售卡网点标识', 7,
                                     ['X' if i == '是' else '' for i in df_org_info_2_lite['设售卡网点标识'].to_list()])
        wct_9014.set_col_range_value('加油站规模', 7, df_org_info_2_lite['加油站规模'].to_list())
        wct_9014.save()
        return SAVE_PATH + '/9014_HR_BI_9014--人员导入--加油站信息.xlsx'
    else:
        logging.info('不需要创建【9014-加油站信息模板】')
        return None

# 9022_HR_BI_9022--人员导入--销售企业单位属性.xlsx --yc


def generate_9022(filename: str) -> Optional[str]:
    df_org_info = load_org_info(filename)
    df_org_info_2 = df_org_info[df_org_info['机构维护类型'].isin(['机构新增', '机构调整'])].copy()

    # 抓取油品销售企业行政属性不为空的数据
    df_org_info_2_lite = df_org_info_2[~df_org_info_2['油品销售企业行政属性'].isin([''])].copy()
    row_num = df_org_info_2_lite.shape[0]
    if row_num:
        df_org_info_2_lite['序号'] = [str(i + 1) for i in range(row_num)]  # 先改变序号
        wct_9022 = WbCreateTool('9022_HR_BI_9022--人员导入--销售企业单位属性.xlsx')
        wct_9022.set_col_range_value('中文名称', 7, df_org_info_2_lite['序号'].to_list())
        wct_9022.set_col_range_value('组织机构编码', 7, df_org_info_2_lite['组织机构编码'].to_list())
        wct_9022.set_col_range_value('开始日期', 7, df_org_info_2_lite['开始日期'].to_list())
        wct_9022.rep_col_range_value('结束日期', 7, df_org_info_2_lite.shape[0], MAX_END_DATE)
        wct_9022.set_col_range_value('油品销售企业行政属性', 7, df_org_info_2_lite['油品销售企业行政属性'].to_list())
        wct_9022.set_col_range_value('油品销售企业管理层级', 7, df_org_info_2_lite['油品销售企业管理层级'].to_list())
        wct_9022.set_col_range_value('油品销售企业业务属性', 7, df_org_info_2_lite['油品销售企业业务属性'].to_list())
        wct_9022.save()
        return SAVE_PATH + '/9022_HR_BI_9022--人员导入--销售企业单位属性.xlsx'
    else:
        logging.info('不需要创建【9022-销售企业单位属性模板】')
    return None

# 9064_HR_BI_9064--人员导入--领导班子信息.xlsx -- yc


def generate_9064(filename: str) -> Optional[str]:
    df_org_info = load_org_info(filename)
    df_org_info_2 = df_org_info[df_org_info['机构维护类型'].isin(['机构新增', '机构调整'])].copy()

    df_org_info_2_lite = df_org_info_2[~df_org_info_2['单位级别'].isin(['', '其他级'])].copy()
    row_num = df_org_info_2_lite.shape[0]
    if row_num:
        df_org_info_2_lite['序号'] = [str(i + 1) for i in range(row_num)]  # 先改变序号
        wct_9064 = WbCreateTool('9064_HR_BI_9064--人员导入--领导班子信息.xlsx')
        wct_9064.set_col_range_value('中文名称', 7, df_org_info_2_lite['序号'].to_list())
        wct_9064.set_col_range_value('组织机构编码', 7, df_org_info_2_lite['组织机构编码'].to_list())
        wct_9064.set_col_range_value('开始日期', 7, df_org_info_2_lite['开始日期'].to_list())
        wct_9064.rep_col_range_value('结束日期', 7, row_num, MAX_END_DATE)
        wct_9064.rep_col_range_value('领导班子管理层级', 7, row_num, '5 二级单位管理(基层)')
        wct_9064.save()
        return SAVE_PATH + '/9064_HR_BI_9064--人员导入--领导班子信息.xlsx'
    else:
        logging.info('不需要创建【9064-领导班子信息模板】')
    return None

# 1001_HR_BI_A011OK--人员导入--关系_O_K_A011.xlsx


def generate_1001(filename: str) -> Optional[str]:
    df_org_info = load_org_info(filename)
    df_org_info_2 = df_org_info[
        ~df_org_info['主成本中心'].isin(['']) & df_org_info['机构维护类型'].isin(['机构新增', '机构调整'])].copy()
    row_num = df_org_info_2.shape[0]
    if row_num:
        df_org_info_2['序号'] = [str(i + 1) for i in range(row_num)]  # 先改变序号
        wct_1001 = WbCreateTool('1001_HR_BI_A011OK--人员导入--关系_O_K_A011.xlsx')
        wct_1001.set_col_range_value('中文名称', 7, df_org_info_2['序号'].to_list())
        wct_1001.set_col_range_value('组织机构编码', 7, df_org_info_2['组织机构编码'].to_list())
        wct_1001.set_col_range_value('开始日期', 7, df_org_info_2['开始日期'].to_list())
        wct_1001.rep_col_range_value('结束日期', 7, row_num, MAX_END_DATE)
        wct_1001.set_col_range_value('成本中心编码', 7, [x + 'SINO' for x in df_org_info_2['主成本中心'].to_list()])
        wct_1001.save()
        return SAVE_PATH + '/1001_HR_BI_A011OK--人员导入--关系_O_K_A011.xlsx'
    else:
        logging.info('不需要创建【1001-关系_O_K_A011模板】')
    return None


if __name__ == '__main__':
    from rpa.fastrpa.log import config

    config()
    filename = r'x:\Users\Administrator\Desktop\非中层待办\1000182071-西南石油局-组织机构维护-常金兰(2)---未完成.xlsx'
    generate_1008(filename)
