import datetime
import logging
import re
import time
import traceback
from threading import Thread
from typing import List

import chardet
import pandas as pd
import pyperclip
from openpyxl import load_workbook
from openpyxl.utils import get_column_letter
from pythoncom import com_error  # pylint: disable=fixme, no-name-in-module
from rpa.config import TEMPLATE_DIR
from rpa.fastrpa.adtable import load_from_xlsx_file
from rpa.fastrpa.sap.session import SapWithoutClose, close_sap
from rpa.public.tools import click_continue
from rpa.ssc.hr.sap.export_103 import export_103
from rpa.ssc_rpa.hr.rpa_ji_gou_wei_hu.checker.check_is_logic_correct import \
    check_1073_logic
from rpa.ssc_rpa.hr.rpa_ji_gou_wei_hu.checker.check_must_fill import \
    upload_to_ftp
from rpa.ssc_rpa.hr.rpa_ji_gou_wei_hu.create.generate_org_info import \
    load_org_info
from rpa.ssc_rpa.hr.rpa_ji_gou_wei_hu.ftp_control import SAVE_PATH
from rpa.ssc_rpa.hr.rpa_ji_gou_wei_hu.sap.import_template import WbToolEx
from rpa.ssc_rpa.hr.rpa_ji_gou_wei_hu.tools.excel_tool import WbTool
from rpa.ssc_rpa.hr.rpa_ji_gou_wei_hu.tools.tools import up_file

# 机构处理 （写入双跨机构、更名、更新简历功能）


def update_org_name_and_resume(filename: str) -> bool:
    chk_2_3_1(filename)  # 2.3.1 机构新增、调整，双跨机构设置
    try:
        chk_2_3_2_to_2_3_4(filename)  # 2.3.2-2.3.4 机构更名、调整-组织机构简称、全称处理
    except Exception as e:
        logging.error('规则2.3.2-2.3.4执行报错（20201208更新，执行报错直接跳转至事后校验）')
        logging.error(e)
        logging.error(traceback.format_exc())
    after_check(filename)  # 3.1.1 事后校验
    close_sap()
    return up_ftp(filename)  # 扫描AN 并上传ftp


# 2.3.1 机构新增、调整，双跨机构设置
r"""
"先锁定【机构维护信息表-【B-机构维护类型】】的值为【码表库-【DR3-机构新增\机构调整】对应的主体机构编码不为空，对应的映射机构编码不为空】的行并且：
1)进入SAP，输入口令“/n PPOME”，回车；
2)点击“组织机构”，依序在弹出窗口的【带名称】里输入二次锁定后的【机构维护信息表-【C-组织机构编码】】，点击“查找”；
3)双击，选中【双跨机构属性选项卡】，在【对应的双跨机构】中填入【机构维护信息表-【AK-对应的主体机构编码】和【AL-对应的映射机构编码】】中不为空的那个值，
并在【双跨机构属性】中，依据【【AK-对应的主体机构编码】对应 “01 主体机构” 和【AL-对应的映射机构编码】对应 “02 映射机构” 】的原则，下拉选择；
4)将【机构维护信息表-【I-开始日期】】填入【有效日从】，将“99991231”填入【至】
5)保存，执行下一机构。"

【机构维护信息表-【AN】】填充红色并输入“双跨机构设置失败！”，跳转执行4.1.1；
"""


def chk_2_3_1(filename: str):
    logging.info('sap系统执行-------------->>>【2.3.1 机构新增、调整，双跨机构设置】')
    logging.info('sap系统执行-------------->>>过滤新增、调整业务且【对应的主体机构编码】【对应的映射机构编码】有一个不为空的数据')
    df_org_info = load_org_info(filename)
    df_filter = df_org_info[df_org_info['机构维护类型'].isin(['机构新增', '机构调整']) & ~df_org_info['对应的主体机构编码'].isin(['']) | ~df_org_info['对应的映射机构编码'].isin([''])].copy()
    logging.info(df_filter)
    org_no = df_filter['组织机构编码'].to_list()
    if not org_no:
        logging.info('===== 未找到符合条件的数据，不执行机构新增、调整，双跨机构设置！')
        return
    main_org_ids = df_filter['对应的主体机构编码'].to_list()
    map_org_ids = df_filter['对应的映射机构编码'].to_list()
    indexes = df_filter['序号'].to_list()
    begin_date = [i[0:4] + '.' + i[4:6] + '.' + i[6:] for i in df_filter['开始日期'].to_list()]

    # 进入PPOME
    with SapWithoutClose('login_tx') as session:
        session.findById("wnd[0]").maximize()
        session.findById("wnd[0]").sendVKey(0)
        session.findById("wnd[0]/tbar[0]/okcd").text = "/n PPOME"
        session.findById("wnd[0]/tbar[0]/btn[0]").press()

        # 输入开始时间与结束时间
        session.findById(
            "wnd[0]/usr/subCONTROLSTRIP:SAPLOM_NAVFRAMEWORK_OO_OBJ:0010/subTIME_OBJECT_OVERVIEW_STRIP:SAPLOM_STANDARD_TIME_OBJ:0040/subICON:SAPLOM_STANDARD_TIME_OBJ:0045/btnDATE").press()
        session.findById("wnd[1]/usr/subPERIODCHANGE:SAPLOM_STANDARD_TIME_OBJ:6020/ctxtOMFRAMEWRK-SEL_DATE").text = \
            begin_date[0]
        session.findById("wnd[1]/usr/subPERIODCHANGE:SAPLOM_STANDARD_TIME_OBJ:6020/radABSOLUT").setFocus()
        session.findById("wnd[1]/usr/subPERIODCHANGE:SAPLOM_STANDARD_TIME_OBJ:6020/radABSOLUT").select()
        session.findById("wnd[1]/usr/subPERIODCHANGE:SAPLOM_STANDARD_TIME_OBJ:6020/ctxtENDE_DAT").text = "99991231"
        session.findById("wnd[1]/usr/subPERIODCHANGE:SAPLOM_STANDARD_TIME_OBJ:6020/ctxtENDE_DAT").setFocus()
        session.findById("wnd[1]/usr/subPERIODCHANGE:SAPLOM_STANDARD_TIME_OBJ:6020/ctxtENDE_DAT").caretPosition = 8
        session.findById("wnd[1]/tbar[0]/btn[8]").press()

        lt = load_from_xlsx_file(filename, skip_header=7)
        df = lt.to_dataframe()
        for i in range(len(org_no)):
            df_tmp = df[df['C'] == org_no[i]]
            if df_tmp.empty is False and df_tmp['AK'].values[0] == '' and df_tmp['AL'].values[0] == '':
                logging.info(f'文件行号：{df_tmp.index[0]}，机构编码：{org_no[i]}，对应AK、AL列全为空，跳过修改双跨机构')
                continue  # （20200820更新：当双跨机构为空时，跳过修改双跨机构）
            # 点击组织机构
            session.findById("wnd[0]/shellcont/shell/shellcont[0]/shell/shellcont[1]/shell[1]").clickLink("          1",
                                                                                                          "&Hierarchy")
            session.findById(
                "wnd[1]/usr/subSEARCH_FUNCTION_SUBSCREEN:SAPLOM_SEARCHTOOL_ORGPLAN:0160/txtSEARCH_FUNCTION-SEARK").text = \
                org_no[
                    i]  # 输入组织机构编码
            session.findById(
                "wnd[1]/usr/subSEARCH_FUNCTION_SUBSCREEN:SAPLOM_SEARCHTOOL_ORGPLAN:0160/txtSEARCH_FUNCTION-SEARK").caretPosition = 7
            session.findById("wnd[1]/tbar[0]/btn[0]").press()
            # 双击名称
            session.findById("wnd[0]/shellcont/shell/shellcont[1]/shell").doubleClickCurrentCell()

            # 判断底部是否有提示,
            footer_error = session.findById("wnd[0]/sbar/pane[0]").text
            if footer_error:
                ctool = WbTool(filename)
                for j in range(len(indexes)):
                    ctool.set_red_comment_type2(f'AN{int(indexes[j]) + 7}', 'PPOME修改双跨机构出错')
                    ctool.set_red_comment_type2(f'AO{int(indexes[j]) + 7}', '双跨机构未修改成功')
                ctool.save()
                close_sap()
                # 写库
                error_msg = ['PPOME修改双跨机构出错' for _ in range(len(indexes))]
                upload_to_ftp(filename, '失败', 'PPOME修改双跨机构出错', indexes, error_msg)
                logging.info('===========  PPOME修改双跨机构出错，流程中断！ ===========')
                raise Exception('===========  PPOME修改双跨机构出错，流程中断！ ===========')

            # 选择双跨机构
            session.findById(
                "wnd[0]/usr/subMAINSCREEN:SAPLOM_NAVFRAMEWORK_OO_OBJ:1200/subWORKSPACE:SAPLOM_NAVFRAMEWORK_OO_OBJ:0200/"
                "subDETAIL:SAPLRHOMDETAILMANAGER:0100/tabsSTRIP_OMDETAIL/tabpDETLTAB19").select()
            # 点击创建
            session.findById(
                "wnd[0]/usr/subMAINSCREEN:SAPLOM_NAVFRAMEWORK_OO_OBJ:1200/subWORKSPACE:SAPLOM_NAVFRAMEWORK_OO_OBJ:0200/"
                "subDETAIL:SAPLRHOMDETAILMANAGER:0100/tabsSTRIP_OMDETAIL/tabpDETLTAB19/ssubSUB_OMDETAIL:SAPLRHOMDETAIL_PP01:"
                "0600/ssubSUB_INFTY:SAPLRHOMDETAIL_PP01:0610/btn%#AUTOTEXT013").press()

            # 判断主体机构|映射机构哪个有值
            no_and_class = [main_org_ids[i], '01'] if main_org_ids[i] else [map_org_ids[i], '02']

            # 输入机构编码
            session.findById(
                "wnd[0]/usr/subMAINSCREEN:SAPLOM_NAVFRAMEWORK_OO_OBJ:1200/subWORKSPACE:SAPLOM_NAVFRAMEWORK_OO_OBJ:0200/"
                "subDETAIL:SAPLRHOMDETAILMANAGER:0100/tabsSTRIP_OMDETAIL/tabpDETLTAB19/ssubSUB_OMDETAIL:SAPLRHOMDETAIL_PP01:0600/"
                "ssubSUB_INFTY:SAPLRHOMDETAIL_PP01:0610/ssubSUB_INFTY:MP907400:7000/ctxtP9074-ZZ_SKJG").text = no_and_class[
                0]
            # 选择跨机构属性
            session.findById(
                "wnd[0]/usr/subMAINSCREEN:SAPLOM_NAVFRAMEWORK_OO_OBJ:1200/subWORKSPACE:SAPLOM_NAVFRAMEWORK_OO_OBJ:0200/"
                "subDETAIL:SAPLRHOMDETAILMANAGER:0100/tabsSTRIP_OMDETAIL/tabpDETLTAB19/ssubSUB_OMDETAIL:SAPLRHOMDETAIL_PP01:0600/"
                "ssubSUB_INFTY:SAPLRHOMDETAIL_PP01:0610/ssubSUB_INFTY:MP907400:7000/cmbP9074-ZZ_SKJGSX").key = no_and_class[
                1]
            session.findById(
                "wnd[0]/usr/subMAINSCREEN:SAPLOM_NAVFRAMEWORK_OO_OBJ:1200/subWORKSPACE:SAPLOM_NAVFRAMEWORK_OO_OBJ:0200/"
                "subDETAIL:SAPLRHOMDETAILMANAGER:0100/tabsSTRIP_OMDETAIL/tabpDETLTAB19/ssubSUB_OMDETAIL:SAPLRHOMDETAIL_PP01:0600/"
                "ssubSUB_INFTY:SAPLRHOMDETAIL_PP01:0610/ssubSUB_INFTY:MP907400:7000/cmbP9074-ZZ_SKJGSX").setFocus()
            # 点击保存
            session.findById("wnd[0]/tbar[0]/btn[11]").press()
        close_sap()
        logging.info('sap系统执行-------------->>>【2.3.1 机构新增、调整，双跨机构设置】完毕！')


# 2.3.2 机构更名、调整-组织机构简称、全称处理
"""
"锁定【机构维护信息表-【AP】的值包含“D”或“E”】的行，检验总行数是否超过360：
若超过360：
        1)进入SAP，输入口令“/n S_AHR_61016493”，回车，【操作部分现场演示】，先在【组织机构】字段里输入二次锁定后的【机构维护信息表-【C-组织机构编码】】，
        再点击【关键日期】字段里选择【关键日期】，若弹出【计划版本】，则选择【01 当前计划版本】，点击确认；若未弹出，则直接调跳往下一屏，
        输入【机构维护信息表-【I-开始日期】】，回车，执行，下载【机构显示】表样；
        2)先提取二次锁定后的【机构维护信息表-【C、D、E、I】】，复制到【修改组织机构简称全称模板-【A、F、G、D】】；
        3)在【修改组织机构简称全称模板-【E-修改后的结束日期】】输入“99991231”；
        4)依序匹配二次锁定后的【机构维护信息表-【C-组织机构编码】】与【机构显示-【扩展对象ID】】，
        提取匹配后的【机构显示-【起始日期（对象）、结束日期（对象）】】，复制到【修改组织机构简称全称模板-【B、C】】，另存为文件：YYYYMMDD-单号-修改组织机构简称全称；
        5)跳转执行规则3.1.1。

若未超过360：
        a)进入SAP，输入口令“/n PPOME”，回车；
        b)点击“组织机构”，依序在弹出窗口的【带名称】里输入二次锁定后的【机构维护信息表-【C-组织机构编码】】，点击“查找”；
        c)双击，依序将【机构维护信息表-【D、E】】输入【组织机构简称】和【组织机构全称】，回车，保存，若提示失败，见1；若提示成功，执行d；
        d)重复【a至d】直至二次锁定后的【机构维护信息表-【C-组织机构编码】】全部修改完毕；
        e)输入口令“/n OOHQ”，回车，点击【组织机构】，在弹出窗口中点击【搜索按钮】；
        f)依序输入二次锁定后的【机构维护信息表-【C-组织机构编码】】，确认，勾选后打上标记；
        g)重复【f】直至二次锁定后的【机构维护信息表-【C-组织机构编码】】全部勾选完毕；
        h)在【其他期间】内依次输入【机构维护信息表-【I-开始日期】】和”99991231“，取消勾选【仅打开人员号】，
        取消勾选【测试】，在【开始日期】输入【机构维护信息表-【I-开始日期】】，点击执行；
        i)在弹出窗口中，检验【从OM处取得组织分配的人员】是否为”0“，若是，见2；若不是，见3。"

"1.在相应的【机构维护信息表-【AN】】填充红色并输入“机构更名失败！”，跳转执行4.1.1；
2.若为“是”，提取人员编号，跳转执行下一规则；
3.若为“不是”，提取人员编号，输入口令“/n sm35”，在
                      a）【创建者】查找【FUNJ0016】且
                      b）【日期】为【执行本次RPA的日期】且
                      c）【事务】与【从OM处取得组织分配的人员】的数字相同的行，
若查找成功，勾选本行，点击【Process】，在弹出窗口点击【仅显示错误】，再点击【Process】，等待程序结束后，执行下一规则；
若未查找成功，在相应的【机构维护信息表-【AN】】填充红色并输入“SM35失败！”，跳转执行4.1.1。"

"""


def chk_2_3_2_above_360(org_no: List[str], begin_date: str, org_short_names: List[str], org_full_names: List[str]):
    """规则2.3.2 超过360人时"""
    logging.info('--------------》节点定位包含 D E 的数据超过360条,创建【修改组织机构简称全称模板】')
    with SapWithoutClose('login_tx') as session:
        session.findById("wnd[0]").maximize()
        session.findById("wnd[0]").sendVKey(0)
        session.findById("wnd[0]/tbar[0]/okcd").text = "/n S_AHR_61016493"
        session.findById("wnd[0]/tbar[0]/btn[0]").press()
        session.findById("wnd[0]/usr/btn%_PCHOBJID_%_APP_%-VALU_PUSH").press()  # 多项选择
        try:
            # 点击计划版本
            session.findById("wnd[1]/tbar[0]/btn[0]").press()
        except com_error:
            pass
        session.findById("wnd[1]/tbar[0]/btn[16]").press()  # 清空
        # 将组织机构编码加入剪切板
        text = "\r\n".join([x for x in org_no if x])
        pyperclip.copy(text)
        session.findById("wnd[1]/tbar[0]/btn[24]").press()  # 复制剪切板内容
        session.findById("wnd[1]/tbar[0]/btn[8]").press()  # 点击对号
        session.findById("wnd[0]/usr/btn$PS$ZTST").press()  # 点击关键日期
        session.findById("wnd[0]/usr/ctxtPCHOBEG").text = begin_date[0]
        session.findById("wnd[0]/usr/chkSEL_BOX").selected = -1
        session.findById("wnd[0]/usr/chkSEL_BOX").setFocus()
        session.findById("wnd[0]/tbar[1]/btn[8]").press()
        session.findById("wnd[0]/usr/txtPCHDEPTH").text = "1"  # 显示深度设置为1
        session.findById("wnd[0]/usr/txtPCHDEPTH").setFocus()
        session.findById("wnd[0]/usr/txtPCHDEPTH").caretPosition = 6
        session.findById("wnd[0]/tbar[1]/btn[8]").press()  # 点击对号
        session.findById("wnd[0]/usr/cntlCUSTOM_CONTROL/shellcont/shell/shellcont[1]/shell[0]").pressButton("&LOAD")  # 选择布局
        session.findById("wnd[1]/usr/cntlGRID/shellcont/shell").currentCellRow = 2
        session.findById("wnd[1]/usr/cntlGRID/shellcont/shell").selectedRows = "2"
        session.findById("wnd[1]/usr/cntlGRID/shellcont/shell").clickCurrentCell()
        # 表格
        row = list(
            session.findById("wnd[0]/usr/cntlCUSTOM_CONTROL/shellcont/shell/shellcont[1]/shell[1]").GetAllNodeKeys())
        table = session.findById("wnd[0]/usr/cntlCUSTOM_CONTROL/shellcont/shell/shellcont[1]/shell[1]")
        dic = {}  # {'31450001': ['1998.07.01', '9999.12.31'], '31450002': ['1976.04.05', '9999.12.31'], '31450003': ['1999.12.01', '9999.12.31']}
        for i in range(len(row)):
            _id = table.GetItemText(row[i], 'C          3')
            start = table.GetItemText(row[i], 'C         10')
            end = table.GetItemText(row[i], 'C          5')
            dic[_id] = [start, end]
        logging.info('------------》 创建【修改组织机构简称全称模板】')
        save_path = f'{SAVE_PATH}/修改组织机构简称全称模板.xlsx'
        wb = load_workbook(f'{TEMPLATE_DIR}/修改组织机构简称全称模板.xlsx')
        ws = wb.active
        logging.info('------------》【修改组织机构简称全称模板】写入数据... ...')
        for i in range(len(org_no)):
            ws.cell(row=i + 2, column=1).value = org_no[i]  # 编码
            ws.cell(row=i + 2, column=6).value = org_short_names[i]  # 修改后简称
            ws.cell(row=i + 2, column=7).value = org_full_names[i]  # 修改后全称
            ws.cell(row=i + 2, column=4).value = begin_date[i]  # 修改后开始日期
            ws.cell(row=i + 2, column=5).value = '99991231'  # 修改后结束日期
            ws.cell(row=i + 2, column=2).value = dic[org_no[i]][0]  # 开始日期
            ws.cell(row=i + 2, column=3).value = dic[org_no[i]][1]  # 结束日期
        wb.save(save_path)
        logging.info('=================【修改组织机构简称全称模板】创建完毕！模板数据展示： =====================')
        df = pd.read_excel(f'{TEMPLATE_DIR}/修改组织机构简称全称模板.xlsx')
        logging.info(df)


def chk_2_3_2_below_360_a_d(filename: str, org_no: List[str], begin_date: str, indexes: List[str], org_short_names: List[str], org_full_names: List[str]):
    # a
    logging.info('--------------》节点定位包含 D E 的数据小于360条，进入PPOME 修改【组织机构简称、全称】')
    with SapWithoutClose('login_tx') as session:
        session.findById("wnd[0]").maximize()
        session.findById("wnd[0]").sendVKey(0)
        session.findById("wnd[0]/tbar[0]/okcd").text = "/n PPOME"
        session.findById("wnd[0]/tbar[0]/btn[0]").press()
        # b
        # 输入开始日期
        session.findById("wnd[0]/usr/subCONTROLSTRIP:SAPLOM_NAVFRAMEWORK_OO_OBJ:0010/subTIME_OBJECT_OVERVIEW_STRIP:SAPLOM_STANDARD_TIME_OBJ:0040/subICON:SAPLOM_STANDARD_TIME_OBJ:0045/btnDATE").press()
        session.findById("wnd[1]/usr/subPERIODCHANGE:SAPLOM_STANDARD_TIME_OBJ:6020/ctxtOMFRAMEWRK-SEL_DATE").text = begin_date[0]
        session.findById("wnd[1]/usr/subPERIODCHANGE:SAPLOM_STANDARD_TIME_OBJ:6020/radABSOLUT").setFocus()
        session.findById("wnd[1]/usr/subPERIODCHANGE:SAPLOM_STANDARD_TIME_OBJ:6020/radABSOLUT").select()
        session.findById("wnd[1]/usr/subPERIODCHANGE:SAPLOM_STANDARD_TIME_OBJ:6020/ctxtENDE_DAT").text = "99991231"
        session.findById("wnd[1]/usr/subPERIODCHANGE:SAPLOM_STANDARD_TIME_OBJ:6020/ctxtENDE_DAT").setFocus()
        session.findById("wnd[1]/usr/subPERIODCHANGE:SAPLOM_STANDARD_TIME_OBJ:6020/ctxtENDE_DAT").caretPosition = 8
        session.findById("wnd[1]/tbar[0]/btn[8]").press()

        # /n PPOME 修改简称、全称（20200820更新：当节点定位不包含D或E时，跳过修改简称、全称）
        lt = load_from_xlsx_file(filename, skip_header=7)
        df = lt.to_dataframe()
        for i in range(len(org_no)):
            df_tmp = df[df['C'] == org_no[i]]
            if df_tmp.empty is False and 'D' not in df_tmp['AP'].values[0] and 'E' not in df_tmp['AP'].values[0]:
                logging.info(f'文件行号：{df_tmp.index[0]}，机构编码：{org_no[i]}，对应AP列不含D、E，跳过修改简称、全称')
                continue  # 20200820更新：当节点定位不包含D或E时，跳过修改简称、全称
            session.findById("wnd[0]/shellcont/shell/shellcont[0]/shell/shellcont[1]/shell[1]").clickLink("          1",
                                                                                                          "&Hierarchy")
            session.findById(
                "wnd[1]/usr/subSEARCH_FUNCTION_SUBSCREEN:SAPLOM_SEARCHTOOL_ORGPLAN:0160/txtSEARCH_FUNCTION-SEARK").text = \
                org_no[
                    i]
            session.findById(
                "wnd[1]/usr/subSEARCH_FUNCTION_SUBSCREEN:SAPLOM_SEARCHTOOL_ORGPLAN:0160/txtSEARCH_FUNCTION-SEARK").caretPosition = 7
            session.findById("wnd[1]/tbar[0]/btn[0]").press()
            # 双击名称
            session.findById("wnd[0]/shellcont/shell/shellcont[1]/shell").doubleClickCurrentCell()

            # 判断底部是否有提示
            footer_error = session.findById("wnd[0]/sbar/pane[0]").text
            if footer_error:
                ctool = WbTool(filename)
                for j in range(len(indexes)):  # 有一条失败的，全部标为失败
                    ctool.set_red_comment_type2(f'AN{int(indexes[j]) + 7}', 'PPOME修改双跨机构出错')
                    ctool.set_red_comment_type2(f'AO{int(indexes[j]) + 7}', '双跨机构未修改成功')
                ctool.save()
                close_sap()
                # 写库
                error_msg = ['PPOME修改双跨机构出错' for _ in range(len(indexes))]
                upload_to_ftp(filename, '失败', 'PPOME修改双跨机构出错', indexes, error_msg)
                logging.info('===========  PPOME事务码被占用，流程中断！ ===========')
                raise Exception('===========  PPOME事务码被占用，流程中断！ ===========')
            logging.info(f'======= 输入组织机构简称：{org_short_names[i]}')
            # 输入简称
            session.findById(
                "wnd[0]/usr/subMAINSCREEN:SAPLOM_NAVFRAMEWORK_OO_OBJ:1200/subWORKSPACE:SAPLOM_NAVFRAMEWORK_OO_OBJ:0200/subDETAIL:SAPLRHOMDETAILMANAGER:0100/tabsSTRIP_OMDETAIL/tabpDETLTAB01/ssubSUB_OMDETAIL:SAPLRHOMDETAIL_BASE:0200/txtP1000-SHORT").text = \
                org_short_names[i]
            # 输入全称
            logging.info(f'======= 输入组织机构全称：{org_full_names[i]}')
            session.findById(
                "wnd[0]/usr/subMAINSCREEN:SAPLOM_NAVFRAMEWORK_OO_OBJ:1200/subWORKSPACE:SAPLOM_NAVFRAMEWORK_OO_OBJ:0200/subDETAIL:SAPLRHOMDETAILMANAGER:0100/tabsSTRIP_OMDETAIL/tabpDETLTAB01/ssubSUB_OMDETAIL:SAPLRHOMDETAIL_BASE:0200/txtP1000-STEXT").text = \
                org_full_names[i]
            # 点击保存
            session.findById("wnd[0]/tbar[0]/btn[11]").press()

            # 获取底部提示信息
            footer_error = session.findById("wnd[0]/sbar/pane[0]").text
            if '失败' in footer_error:
                ctool = WbTool(filename)
                for j in range(len(indexes)):
                    ctool.set_red_comment_type2(f'AN{int(indexes[j]) + 7}', '机构更名失败')
                ctool.save()
                close_sap()
                return
        logging.info('========  PPOME 事务码 修改【组织机构简称、全称】完成！ ==========')


def chk_2_3_2_below_360_e_i(filename: str, org_no: List[str], begin_date: str, indexes: List[str]):
    # e
    # /n OOHQ 提取人员编号
    logging.info('========  进入OOHQ 提取人员编号  ==========')
    with SapWithoutClose('login_tx') as session:
        session.findById("wnd[0]/tbar[0]/okcd").text = "/n OOHQ"
        session.findById("wnd[0]/tbar[0]/btn[0]").press()
        if len(org_no) > 0:
            session.findById("wnd[0]/usr/btnPNPS$ORG").press()  # 点击组织机构按钮
            session.findById("wnd[1]/tbar[0]/btn[71]").press()  # 点击查找
            # 输入第一个组织机构编码作为占位符
            session.findById("wnd[2]/usr/tabsG_SELONETABSTRIP/tabpTAB001").select()  # 切换至【S:查找条件】选项页
            session.findById("wnd[2]/usr/tabsG_SELONETABSTRIP/tabpTAB001/ssubSUBSCR_PRESEL:SAPLSDH4:0220/sub:SAPLSDH4:0220/txtG_SELFLD_TAB-LOW[0,24]").text = org_no[0]
            session.findById("wnd[2]/usr/tabsG_SELONETABSTRIP/tabpTAB001/ssubSUBSCR_PRESEL:SAPLSDH4:0220/sub:SAPLSDH4:0220/txtG_SELFLD_TAB-LOW[0,24]").caretPosition = 8
            session.findById("wnd[2]/tbar[0]/btn[0]").press()  # 点击对勾
            session.findById("wnd[2]/usr/chk[1,3]").selected = -1
            session.findById("wnd[2]/usr/chk[1,3]").setFocus()
            session.findById("wnd[2]/tbar[0]/btn[0]").press()
            table = session.findById('wnd[1]/usr/subSUB_SEARCH:SAPLRHWH:0300/cntlSEARCH_TREE/shellcont/shell')
            for org_id in org_no:
                session.findById("wnd[1]/tbar[0]/btn[71]").press()  # 点击搜索
                session.findById("wnd[2]/usr/tabsG_SELONETABSTRIP/tabpTAB001").select()  # 切换至【S:查找条件】选项页
                session.findById("wnd[2]/usr/tabsG_SELONETABSTRIP/tabpTAB001/ssubSUBSCR_PRESEL:SAPLSDH4:0220/sub:SAPLSDH4:0220/txtG_SELFLD_TAB-LOW[0,24]").text = org_id
                session.findById("wnd[2]/tbar[0]/btn[0]").press()  # 点击对勾
                session.findById("wnd[2]/usr/chk[1,3]").selected = -1  # 选中第一项
                session.findById("wnd[2]/tbar[0]/btn[0]").press()  # 点击对勾
                table.changeCheckbox(table.GetFocusedNodeKey(), "SEAR_CHECKBX", -1)  # 选中当前处于焦点的机构
            session.findById("wnd[1]/tbar[0]/btn[0]").press()
        # 其他期间  输入开始日期  结束日期
        session.findById("wnd[0]/usr/ctxtPNPBEGDA").text = begin_date[0]
        session.findById("wnd[0]/usr/ctxtPNPENDDA").text = "99991231"
        session.findById("wnd[0]/usr/ctxtBEGDA").text = begin_date[0]
        session.findById("wnd[0]/usr/chkOPEN").selected = 0  # 取消仅开发人员
        session.findById("wnd[0]/usr/chkTEST").selected = 0  # 取消测试
        session.findById("wnd[0]/tbar[1]/btn[8]").press()  # 点击执行
        exe_time = time.strftime('%H:%M:%S', time.localtime(time.time()))
        # 判断sap是否可以查找出表，判断信息是否是：对已输入的参数尚未找到人员编号

        # 检验【从OM处取得组织分配的人员】是否为”0“
        # 将表格复制到剪切板
        try:
            session.findById("wnd[0]/tbar[1]/btn[45]").press()
            session.findById(
                "wnd[1]/usr/subSUBSCREEN_STEPLOOP:SAPLSPO5:0150/sub:SAPLSPO5:0150/radSPOPLI-SELFLAG[4,0]").select()
            session.findById(
                "wnd[1]/usr/subSUBSCREEN_STEPLOOP:SAPLSPO5:0150/sub:SAPLSPO5:0150/radSPOPLI-SELFLAG[4,0]").setFocus()
            session.findById("wnd[1]/tbar[0]/btn[0]").press()
        except com_error:
            logging.info(' OOHQ =======  已输入的参数尚未找到人员编号')
            return

        msg = paste_from_clip()  # 从剪切板获取内容
        byte_str_charset = chardet.detect(msg)  # 获取字节码编码格式
        byte_str = str(msg, byte_str_charset.get('encoding'))  # type: ignore # 将八进制字节转化为字符串
        matches = re.search('从 OM 处取得组织分配的人员:.*[0-9]', byte_str)
        if matches is None:
            raise Exception('无法匹配到文本')
        people_num_from_om = matches.group()
        number = filter(str.isdigit, people_num_from_om)
        people_num = int(''.join(list(number)))

        logging.info(f'      从 OM 处取得组织分配的人员:{people_num}')
        people_no = []  # 人员编号
        table = session.findById("wnd[0]/usr/cntlGRID1/shellcont/shell/shellcont[1]/shell")
        for r in range(table.rowCount):
            if r % 10 == 0:
                table = session.findById("wnd[0]/usr/cntlGRID1/shellcont/shell/shellcont[1]/shell")
                table.firstVisibleRow = r
            no = str(table.getCellValue(r, table.columnOrder(0))).strip()
            people_no.append(no)
        logging.info(f'      提取的人员编号为：{people_no}')
        if people_num == 0:
            logging.info('      执行：生成 + 批导工作经历，更新简历流程')
            # 执行2.3.3-----》2.3.4 批导工作经历，更新简历
            chk_2_3_3_to_2_3_4(filename, people_no, begin_date[0])

        else:
            # 进入/n sm35
            today = time.strftime('%Y.%m.%d', time.localtime(time.time()))
            session.findById("wnd[0]").sendVKey(0)
            session.findById("wnd[0]/tbar[0]/okcd").text = "/n sm35"
            session.findById("wnd[0]/tbar[0]/btn[0]").press()

            # 查找 创建者、日期、时间、事务 符合条件的数据
            table = session.findById(
                "/app/con[0]/ses[0]/wnd[0]/usr/tabsD1000_TABSTRIP/tabpALLE/ssubD1000_SUBSCREEN:SAPMSBDC_CC:1010/tblSAPMSBDC_CCTC_APQI")
            flag = False
            for row in range(table.RowCount):
                # 获取 创建者
                creator = session.findById(
                    f"wnd[0]/usr/tabsD1000_TABSTRIP/tabpALLE/ssubD1000_SUBSCREEN:SAPMSBDC_CC:1010/tblSAPMSBDC_CCTC_APQI/txtITAB_APQI-CREATOR[2,{row}]").Text
                # 获取 日期
                credate = session.findById(
                    f"wnd[0]/usr/tabsD1000_TABSTRIP/tabpALLE/ssubD1000_SUBSCREEN:SAPMSBDC_CC:1010/tblSAPMSBDC_CCTC_APQI/txtITAB_APQI-CREDATE[3,{row}]").Text
                # 获取 时间
                cretime = session.findById(
                    f"wnd[0]/usr/tabsD1000_TABSTRIP/tabpALLE/ssubD1000_SUBSCREEN:SAPMSBDC_CC:1010/tblSAPMSBDC_CCTC_APQI/txtITAB_APQI-CRETIME[4,{row}]").Text
                # 获取 事务
                transcnt = session.findById(
                    f"wnd[0]/usr/tabsD1000_TABSTRIP/tabpALLE/ssubD1000_SUBSCREEN:SAPMSBDC_CC:1010/tblSAPMSBDC_CCTC_APQI/txtITAB_APQI-TRANSCNT[8,{row}]").Text
                exe_time_date = datetime.datetime.strptime(exe_time, "%H:%M:%S")
                cretime_date = datetime.datetime.strptime(cretime, "%H:%M:%S")
                transcnt = transcnt.replace(',', '')
                if creator == 'FUNJ0016' and credate == today and int(transcnt) == int(people_num) and (
                        exe_time_date - cretime_date).seconds < 120:
                    # 选择数据
                    flag = True
                    session.findById(
                        "wnd[0]/usr/tabsD1000_TABSTRIP/tabpALLE/ssubD1000_SUBSCREEN:SAPMSBDC_CC:1010/tblSAPMSBDC_CCTC_APQI").getAbsoluteRow(
                        row).selected = -1
                    break
            if flag:  # 如果查找成功
                session.findById("wnd[0]/tbar[1]/btn[8]").press()  # 工具栏 Process 按钮
                session.findById("wnd[1]/usr/radD0300-ERROR").select()  # 勾选 仅显示错误
                session.findById("wnd[1]/usr/radD0300-ERROR").setFocus()
                session.findById("wnd[1]/tbar[0]/btn[0]").press()  # 点击窗口1的 Process 按钮
                try:
                    session.findById("wnd[1]/tbar[0]/btn[12]").press()  # 点击窗口[信息-批输入会话的处理已完成]的[退出批量输入]按钮
                    close_sap()
                    # 执行2.3.3-----》2.3.4 生成批导工作经历，并更新简历。
                    chk_2_3_3_to_2_3_4(filename, people_no, begin_date[0])
                except Exception:
                    sap_status = session.findById("wnd[0]/sbar/pane[0]").text
                    if '锁定' in sap_status:
                        current_org_id = session.findById("wnd[0]/usr/ctxtP0001-ORGEH").text
                        logging.error(f'SM35同步失败，{sap_status}，当前组织机构编码：{current_org_id}')
                    logging.error(sap_status)
                    ctool = WbTool(filename)
                    for i in range(len(indexes)):
                        ctool.set_red_comment_type2(f'AN{int(indexes[i]) + 7}', 'SM35同步失败')  # 关闭SAP，并在OOHQ屏所有勾选设为失败
                    ctool.save()
                    close_sap()
            else:
                ctool = WbTool(filename)
                for i in range(len(indexes)):
                    ctool.set_red_comment_type2(f'AN{int(indexes[i]) + 7}', 'SM35同步失败，未查找到事务')
                ctool.save()
                close_sap()


def chk_2_3_2_to_2_3_4(filename: str):
    logging.info('sap系统执行-------------->>>【2.3.2 机构更名、调整-组织机构简称、全称处理】')
    df_org_info = load_org_info(filename)
    df_org_info['contains_d_or_e'] = df_org_info['节点定位'].apply(lambda v: 'D' in v or 'E' in v)
    df_filter = df_org_info[df_org_info['contains_d_or_e'] == True]  # 注意：此处不能修改为is True
    if df_filter.empty is True:
        logging.info('未找到【节点定位】包含“D”或“E”的数据，不执行此流程')
        return
    df_filter = df_org_info

    org_no = df_filter['组织机构编码'].to_list()
    indexes = df_filter['序号'].to_list()
    org_short_names = df_filter['组织机构简称'].to_list()
    org_full_names = df_filter['组织机构全称'].to_list()
    begin_date = df_filter['开始日期'].to_list()

    chk_2_3_2_below_360_a_d(filename, org_no, begin_date, indexes, org_short_names, org_full_names)  # TODO 暂时屏蔽部分规则
    chk_2_3_2_below_360_e_i(filename, org_no, begin_date, indexes)

    # max_row = df_filter.shape[0]
    # if max_row >= 360:
    #     chk_2_3_2_above_360(org_no, begin_date, org_short_names, org_full_names)
    #     return
    # else:
    #     chk_2_3_2_below_360_a_d(filename, org_no, begin_date, indexes, org_short_names, org_full_names)
    #     chk_2_3_2_below_360_e_i(filename, org_no, begin_date, indexes)


# 下载103 生成 0023_HR_BI_0023新增工作经历模板，生成简历 （生成、批导工作经历，并更新简历）


def chk_2_3_3_to_2_3_4(filename: str, staff_ids: List[str], begin_date: str):
    """
    下载103 生成 0023新增工作经历模板，生成简历 （生成、批导工作经历，并更新简历）
    :param staff_ids: 人员编号  list类型 ['123456','123457'...]
    :param begin_date: 开始日期 '20200401'
    :param filename: 附件表路径
    :return:
    """
    _103_filename = _export_103(staff_ids, begin_date)
    df_103 = pd.read_excel(_103_filename)
    logging.info('=================  生成【0023_HR_BI_0023--人员导入--工作经历.xlsx】 模板  =============')
    df_103_filter = df_103[df_103['人员子组'].isin(['15', '16', '17', '61', '62', '63'])].copy()
    # 获取附件表的开始日期
    fujian_df = load_org_info(filename)
    start_date = fujian_df['开始日期'].to_list()[0]

    # 提取103表A B L M C W Y
    a_103 = df_103_filter['人员编号'].to_list()
    b_103 = df_103_filter['人员编号.1'].to_list()
    m_103 = df_103_filter['结束日期.1'].to_list()
    w_103 = df_103_filter['组织机构.1'].to_list()
    y_103 = df_103_filter['职务（岗位）具体名称'].to_list()

    # 如果没有符合的条件 下面流程不执行
    if not a_103:
        logging.info('========  103表中没有 人员子组为[15, 16, 17, 61, 62, 63] 的数据 ========')
        return

    # 将103提取数据写入 0023_HR_BI_0023新增工作经历
    wt_0023 = WbTool(TEMPLATE_DIR + '/' + '0023_HR_BI_0023--人员导入--工作经历.xlsx')
    for row in range(len(a_103)):
        wt_0023.sheetname[f'A{7 + row}'] = str(row + 1)
        wt_0023.sheetname[f'B{7 + row}'] = str(a_103[row])
        wt_0023.sheetname[f'C{7 + row}'] = b_103[row]
        wt_0023.sheetname[f'D{7 + row}'] = start_date  # 开始日期
        wt_0023.sheetname[f'E{7 + row}'] = str(m_103[row].replace('.', ''))
        wt_0023.sheetname[f'F{7 + row}'] = w_103[row]
        wt_0023.sheetname[f'G{7 + row}'] = y_103[row]
    wt_0023.wb.save(SAVE_PATH + '/0023_HR_BI_0023--人员导入--工作经历.xlsx')
    logging.info('              【0023_HR_BI_0023--人员导入--工作经历.xlsx】 模板 已生成完毕！')

    # 批导 新增工作经历表,批导全部成功返回True，有一条失败返回False
    # flag = import_add_work_history(SAVE_PATH + '/0023_HR_BI_0023--人员导入--工作经历.xlsx', filename, xuhao)
    # if flag:
    # 无论新增工作经历是否批导成功都要生成简历
    # chk_2_3_4(_103_filename)  # 20201207 SAP系统生成简历功能调整，暂时屏蔽各事件生成简历功能，由业务人员手工处理。


# 提取剪切板内容
def paste_from_clip() -> str:
    time.sleep(3)
    import win32clipboard as w
    import win32con
    w.OpenClipboard()
    t = w.GetClipboardData(win32con.CF_TEXT)
    w.CloseClipboard()
    return t


# 设置剪切板内容
def copy_to_clip(text: str) -> None:
    import win32clipboard as w
    import win32con

    # 打开剪贴板
    w.OpenClipboard()
    # 清空剪贴板
    w.EmptyClipboard()
    # 将数据aString写入剪贴板
    w.SetClipboardData(win32con.CF_UNICODETEXT, text)
    # 关闭剪贴板
    w.CloseClipboard()
    time.sleep(3)


# 下载103


def _export_103(staff_ids: List[str], begin_date: str) -> str:
    """导出103，并返回文件路径"""
    logging.info('=================  开始下载【模板_103.xlsx】  =============')
    with SapWithoutClose('login_tx') as session:
        table = export_103(session, staff_ids, begin_date)
        table.save_to(SAVE_PATH)
        logging.info('=================  删除【模板_103.xlsx】同编码的数据，保留最后一条  =============')
        # 删除重复行
        df = pd.read_excel(SAVE_PATH + r'\模板_103.xlsx', converters={'PSubarea': str})
        rybh = df['人员编号'].to_list()  # 获取103表中的【人员编号】
        remove_index = []
        for value in rybh:
            id1 = [i for i, x in enumerate(rybh) if x == value]
            if len(id1) > 1:
                if id1[1:] not in remove_index:
                    remove_index.extend(id1[1:])
        remove_index = [i - 1 for i in list(set(remove_index))]
        df.drop(index=remove_index, inplace=True)
        df.to_excel(SAVE_PATH + r'\模板_103.xlsx', index=None)
        logging.info('=================  下载【模板_103.xlsx】完毕！  =============')
        return SAVE_PATH + r'\模板_103.xlsx'


# 批导 新增工作经历表 0023_HR_BI_0023


def import_add_work_history(_0023_filename: str, filename: str, indexes):
    logging.info('sap系统批导-------------->>>【0023_HR_BI_0023--人员导入--工作经历】 模板')
    with SapWithoutClose('login_tx') as session:
        session.findById("wnd[0]").maximize()
        session.findById("wnd[0]").sendVKey(0)
        session.findById("wnd[0]/tbar[0]/okcd").text = "/n zhrbi0013"
        session.findById("wnd[0]/tbar[0]/btn[0]").press()
        session.findById("wnd[0]/tbar[1]/btn[8]").press()  # 点击左上角 小对号
        session.findById("wnd[0]/usr/ctxtP_SRTFD").text = "0023->HR_BI_0023"
        # 选择上传数据
        t = Thread(target=click_continue, daemon=True)
        t1 = Thread(target=up_file, daemon=True, args=(_0023_filename,))
        t1.start()
        t.start()
        session.findById("wnd[0]/usr/radRB_UP").setFocus()
        session.findById("wnd[0]/usr/radRB_UP").select()
        session.findById("wnd[0]/tbar[1]/btn[8]").press()  # 点击左上角 小对号
        sap_status = session.findById("wnd[0]/sbar/pane[0]").text
        logging.info(f'批导后SAP状态栏信息:{sap_status}')
        if sap_status in ('没有需要处理的数据或数据错误', '文件不符合要求', '没有需要处理的数据或数据错误'):
            logging.error(sap_status)
        if '没有需要处理的数据或数据错误' in sap_status:
            logging.error('文件：{file}批导失败，请检查模板是否加锁或被占用')
            raise Exception(f'SAP批导新增工作经历表失败，错误信息：{sap_status}')
        dispose_num_msg = session.findById("wnd[1]/usr/txtSPOP-TEXTLINE2").text  # 其中：成功1284 行，失败0 行
        matches = re.match(r'其中：\s*成功\s*(\d+)\s*行，失败\s*(\d+)\s*行', dispose_num_msg)
        if matches is not None:
            success_num = matches.group(1)
            fail_num = matches.group(2)
            all_num = int(success_num) + int(fail_num)
        else:
            all_num = 0
        close_sap()
        logging.info('sap系统批导-------------->>>【0023_HR_BI_0023--人员导入--工作经历】 模板完毕')
        # 将批模板批导结果，回写到附件表
        template_excel = WbToolEx(_0023_filename)
        success_col = template_excel.sheetname.max_column - 2
        is_success = [i.value for i in template_excel.sheetname[get_column_letter(success_col)][6:]]
        msg_dict = {}  # 回填附件表用到的对应信息 {1：失败，2：成功...} 序号：信息

        # 如果处理的数据个数缺少了
        if template_excel.sheetname.max_row - 6 != all_num:
            for i in range(len(indexes)):
                msg_dict[indexes[i]] = f'0023工作经历批导失败：sap应处理【{template_excel.sheetname.max_row - 6}】条数据,实际处理了【{all_num}】条数据'
                logging.info(
                    f'sap系统批导-->>>【0023_HR_BI_0023--人员导入--工作经历】出错：sap应处理【{template_excel.sheetname.max_row - 6}】条数据,实际处理了【{all_num}】条数据')
            wte_file = WbToolEx(filename)  # 附件
            wte_file.update_break_point(msg_dict, '0023')  # 更新附件表
            return False

        # 如果sap处理模板之后，有标记失败的数据
        if '失败' in is_success:
            for i in range(len(indexes)):
                msg_dict[indexes[i]] = '0023工作经历批导失败'
                logging.info('sap系统批导-->>>【0023_HR_BI_0023--人员导入--工作经历】出错：工作经历批导失败')
            wte_file = WbToolEx(filename)  # 附件
            wte_file.update_break_point(msg_dict, '0023')  # 更新附件表
            # return False
        else:
            logging.info('sap系统批导-->>>【0023_HR_BI_0023--人员导入--工作经历】成功！')
            # return True
            # 如果批导没有出错，给AN列添加批导成功
            df_org_info = load_org_info(filename)
            df_filter = df_org_info[~df_org_info['机构维护类型'].isin(['机构撤销'])].copy()
            indexes = df_filter['序号'].to_list()
            _an = df_filter['是否成功'].to_list()
            wt_file = WbTool(filename)
            for i in range(len(indexes)):
                if not _an[i]:  # 如果AN 没有内容，说明是批导成功的！
                    wt_file.concat_value(f'AN{int(indexes[i]) + 7}', '批导成功')
            wt_file.save()


# 2.3.4 生成简历 /n zhrpa175
def chk_2_3_4(_103_filename: str):
    logging.info('===================  sap系统 执行 【/n zhrpa175】更新简历  =====================')
    df_103 = pd.read_excel(_103_filename)
    _pa = list(set(df_103['PA'].to_list()))
    people_no = df_103['人员编号'].to_list()
    with SapWithoutClose('login_tx') as session:
        session.findById("wnd[0]").maximize()
        session.findById("wnd[0]").sendVKey(0)
        session.findById("wnd[0]/tbar[0]/okcd").text = "/n zhrpa175"
        session.findById("wnd[0]/tbar[0]/btn[0]").press()

        # PA放入剪切板
        copy_pa = "\r\n".join([str(x) for x in _pa if x])
        pyperclip.copy(copy_pa)

        # 粘贴人事范围
        session.findById("wnd[0]/usr/ctxtPNPWERKS-LOW").text = "1"
        session.findById("wnd[0]/usr/ctxtPNPWERKS-LOW").caretPosition = 1
        session.findById("wnd[0]/usr/btn%_PNPWERKS_%_APP_%-VALU_PUSH").press()
        session.findById("wnd[1]/tbar[0]/btn[16]").press()
        session.findById("wnd[1]/tbar[0]/btn[24]").press()
        session.findById("wnd[1]/tbar[0]/btn[8]").press()

        # 粘贴人员编号
        copy_people_no = "\r\n".join([str(x) for x in people_no if x])
        pyperclip.copy(copy_people_no)
        session.findById("wnd[0]/usr/btn%_PNPPERNR_%_APP_%-VALU_PUSH").press()
        session.findById("wnd[1]/tbar[0]/btn[16]").press()
        session.findById("wnd[1]/tbar[0]/btn[24]").press()
        session.findById("wnd[1]/tbar[0]/btn[8]").press()
        session.findById("wnd[0]/tbar[1]/btn[8]").press()  # 点击执行
        # 点击删除原简历并重新提取与保存按钮
        session.findById("wnd[0]/tbar[1]/btn[14]").press()
        logging.info('点击删除原简历并重新提取')
        session.findById("wnd[0]/tbar[1]/btn[23]").press()
        print('点击保存按钮')
        logging.info('===================  【/n zhrpa175】更新简历完毕！  =====================')


# 事后校验
def after_check(filename: str):
    check_1073_logic(filename, '组织机构编码', '组织机构编码', save_name='机构维护事后备份')


# 扫表AN列+上传
def up_ftp(filename: str) -> bool:
    # 扫描AN列是否成功字段，并上传ftp--------------------------------------------------------------------------------------------------------------------
    df_org_info = load_org_info(filename)
    df_filter = df_org_info[~df_org_info['机构维护类型'].isin(['机构撤销'])].copy()
    indexes = df_filter['序号'].to_list()
    _an = df_filter['是否成功'].to_list()
    is_succ = True
    for cell in _an:
        if cell != '批导成功':
            is_succ = False
            logging.info(f'=================  【AN-是否成功】不全为【批导成功】，出现错误：{cell}，已上传FTP==============')
            upload_to_ftp(filename, '失败', cell, indexes, _an)  # 出现失败，数据库记录：AN列的描述，状态改为 失败
            break
    if is_succ is True:
        upload_to_ftp(filename, '成功', '成功', indexes, _an)
        logging.info('=================  【AN-是否成功】全为【批导成功】，已上传FTP==============')
    return is_succ
