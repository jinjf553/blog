# 批导
import logging
import os

from rpa.fastrpa.adtable import load_from_xlsx_file
from rpa.ssc.hr.orm.orm import rpa_work_amount
from rpa.ssc_rpa.hr.rpa_ji_gou_wei_hu.create.generate_org_info import \
    load_org_info
from rpa.ssc_rpa.hr.rpa_ji_gou_wei_hu.create.generate_template import (
    generate_1000_o_template, generate_9005_template,
    generate_a00_2oo_template, generate_other_template)
from rpa.ssc_rpa.hr.rpa_ji_gou_wei_hu.sap.import_template import (
    import_1000_o, import_1001, import_1008, import_9004, import_9005,
    import_9007, import_9010, import_9014, import_9022, import_9064,
    import_9068, import_a00_2oo)
from rpa.ssc_rpa.hr.rpa_ji_gou_wei_hu.tools.excel_tool import WbTool


def sap_import(filename: str):  # 前两个模板批导失败转人工，后面的批导失败则忽略继续执行，执行结束将批导结果写回批导文件上

    logging.info('============== 开始批导生成的模板 =================')
    from rpa.ssc_rpa.hr.rpa_ji_gou_wei_hu.ftp_control import SAVE_PATH

    # 生成1000O创建组织机构，进入批导
    generate_1000_o_template(filename)
    files = os.listdir(SAVE_PATH)
    if '1000_HR_BI_1000O--人员导入--创建组织机构.xlsx' in files:
        import_1000_o(SAVE_PATH + r"\1000_HR_BI_1000O--人员导入--创建组织机构.xlsx", filename)
    else:
        logging.error(f'【{SAVE_PATH}】路径没有检测到1000_HR_BI_1000O--人员导入--创建组织机构.xlsx')

    # 生成A002OO指定机构的直接上级机构，进入批导
    generate_a00_2oo_template(filename)  # 这一步可能不生成模板
    files = os.listdir(SAVE_PATH)
    if '1001_HR_BI_A002OO--人员导入--指定机构的直接上级机构.xlsx' in files:
        import_a00_2oo(SAVE_PATH + r"\1001_HR_BI_A002OO--人员导入--指定机构的直接上级机构.xlsx", filename)  # 可重复批导
    else:
        logging.warning(f'【{SAVE_PATH}】路径没有检测到1001_HR_BI_A002OO--人员导入--指定机构的直接上级机构.xlsx')

    lt = load_from_xlsx_file(filename, skip_header=7)
    org_ids = lt['C'].values
    rpa_work_amount(org_ids)  # 将机构ID写入工作量表

    # 生成9005生成机构分类属，进入批导
    generate_9005_template(filename)
    files = os.listdir(SAVE_PATH)

    # 找出“9005_HR_BI_9005-10010060--人员导入--机构分类属性” 模板
    org_type_attrs = list(filter(lambda x: '机构分类属性' in x, files))
    org_type_attr_count = len(org_type_attrs)
    customer_num = 0
    for jgflsx in org_type_attrs:
        customer_num += 1
        org_no = jgflsx[jgflsx.index('性') + 1:jgflsx.index('.')]
        if customer_num == org_type_attr_count:
            import_9005(SAVE_PATH + rf'/{jgflsx}', org_no, filename, is_check=True)
        else:
            import_9005(SAVE_PATH + rf'/{jgflsx}', org_no, filename)

    # 生成其他模板
    generate_other_template(filename)
    templates_files_list = os.listdir(SAVE_PATH)

    # 4.找出“9010_HR_BI_9010--人员导入--通讯地址” 模板,如果有就去批导
    if '9010_HR_BI_9010--人员导入--通讯地址.xlsx' in templates_files_list:
        address = list(filter(lambda x: '通讯地址' in x, templates_files_list))[0]
        import_9010(SAVE_PATH + rf'/{address}', filename)

    # 5.找出“9068_HR_BI_9068--人员导入--单位简化全称” 模板  9068_HR_BI_9068--人员导入--单位简化全称
    if '9068_HR_BI_9068--人员导入--单位简化全称.xlsx' in templates_files_list:
        unit_short_names = list(filter(lambda x: '单位简化全称' in x, templates_files_list))[0]
        import_9068(SAVE_PATH + rf'/{unit_short_names}', filename)

    # 6.找出“1008_HR_BI_1008--人员导入--财务科目设置” 模板
    if '1008_HR_BI_1008--人员导入--财务科目设置.xlsx' in templates_files_list:
        finance_setups = list(filter(lambda x: '财务科目设置' in x, templates_files_list))[0]
        import_1008(SAVE_PATH + rf'/{finance_setups}', filename)

    # 7.找出“9004_HR_BI_9004--人员导入--注册登记信息” 模板
    if '9004_HR_BI_9004--人员导入--注册登记信息.xlsx' in templates_files_list:
        reg_infos = list(filter(lambda x: '注册登记信息' in x, templates_files_list))
        if reg_infos:
            import_9004(SAVE_PATH + rf'/{reg_infos[0]}', filename)

    # 8.找出“9007_HR_BI_9007--人员导入--基层单位特有属性” 模板
    if '9007_HR_BI_9007--人员导入--基层单位特有属性.xlsx' in templates_files_list:
        base_unit_attrs = list(filter(lambda x: '基层单位特有属性' in x, templates_files_list))
        if base_unit_attrs:
            import_9007(SAVE_PATH + rf'/{base_unit_attrs[0]}', filename)

    # 9.找出“9022_HR_BI_9022--人员导入--销售企业单位属性” 模板
    if '9022_HR_BI_9022--人员导入--销售企业单位属性.xlsx' in templates_files_list:
        sall_unit_attrs = list(filter(lambda x: '销售企业单位属性' in x, templates_files_list))
        if sall_unit_attrs:
            import_9022(SAVE_PATH + rf'/{sall_unit_attrs[0]}', filename)

    # 10.找出“9014_HR_BI_9014--人员导入--加油站信息” 模板
    if '9014_HR_BI_9014--人员导入--加油站信息.xlsx' in templates_files_list:
        gas_sation_infos = list(filter(lambda x: '加油站信息' in x, templates_files_list))
        if gas_sation_infos:
            import_9014(SAVE_PATH + rf'/{gas_sation_infos[0]}', filename)

    # 11.找出“1001_HR_BI_A011OK--人员导入--关系_O_K_A011” 模板
    if '1001_HR_BI_A011OK--人员导入--关系_O_K_A011.xlsx' in templates_files_list:
        relations = list(filter(lambda x: '关系_O_K_A011' in x, templates_files_list))
        if relations:
            import_1001(SAVE_PATH + rf'/{relations[0]}', filename)

    # 12.“9064_HR_BI_9064--人员导入--领导班子信息” 模板
    if '9064_HR_BI_9064--人员导入--领导班子信息.xlsx' in templates_files_list:
        leader_infos = list(filter(lambda x: '领导班子信息' in x, templates_files_list))
        if leader_infos:
            import_9064(SAVE_PATH + rf'/{leader_infos[0]}', filename)

    # 给批导没有出错的行的AN单元格，加入“批导成功”
    df_org_info = load_org_info(filename)
    df_filter = df_org_info[~df_org_info['机构维护类型'].isin(['机构撤销'])].copy()
    indexes = df_filter['序号'].to_list()
    AN = df_filter['是否成功'].to_list()
    ctool = WbTool(filename)
    for i in range(len(indexes)):
        if not AN[i]:  # 如果AN 没有内容，说明是批导成功的！
            ctool.concat_value(f'AN{int(indexes[i]) + 7}', '批导成功')
    ctool.save()

    # 判断除了三个主要模板外，其他模板是否出错！，出错上传FTP
    df_org_info = load_org_info(filename)
    indexes = df_org_info['序号'].to_list()
    is_success = df_org_info['是否成功'].to_list()
    # error_msg = df_org_info['错误描述'].to_list()
    if '批导失败' in is_success:
        # error_msg = list(map(lambda x: x + '批导失败' if x else '批导成功', error_msg))
        # upload_to_ftp(filename, '失败', '非主要模板批导失败', indexes, error_msg)
        logging.error('===========  非主要模板批导失败！ =============')
        # raise Exception('===========  非主要模板批导失败！ 流程中断   =============')


if __name__ == '__main__':
    filename = r"x:\Users\Administrator\Desktop\1000162803-浙江石油-组织机构维护-常盛(1).xlsx"
    # sap_import(fujian)
