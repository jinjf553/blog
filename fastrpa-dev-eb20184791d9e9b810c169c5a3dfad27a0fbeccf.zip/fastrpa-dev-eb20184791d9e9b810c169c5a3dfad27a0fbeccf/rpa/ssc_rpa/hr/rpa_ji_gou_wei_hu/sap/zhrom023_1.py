import time

from rpa.fastrpa.sap.session import SapWithoutClose, close_sap


def check_org_ids(org_list, start_time_list):
    with SapWithoutClose('login_tx') as session:
        session.findById("wnd[0]").maximize()
        session.findById("wnd[0]").sendVKey(0)
        session.findById("wnd[0]/tbar[0]/okcd").text = "/n zhrom023_1"
        session.findById("wnd[0]/tbar[0]/btn[0]").press()
        error_index = []
        for i in range(len(org_list)):
            start_time = str(start_time_list[i][:4]) + '.' + str(start_time_list[i][4:6]) + '.' + str(start_time_list[i][6:])
            session.findById("wnd[0]/usr/ctxtPM0D1-SEARK").text = str(org_list[i])
            session.findById("wnd[0]/usr/ctxtPPHDR-BEGDA").text = start_time
            session.findById("wnd[0]/usr/ctxtPM0D1-SEARK").caretPosition = 8
            session.findById("wnd[0]").sendVKey(0)
            time.sleep(1)
            footer_error = session.findById("wnd[0]/sbar/pane[0]").text
            if footer_error:
                error_index.append(i + 1)
                session.findById("wnd[0]/tbar[0]/okcd").text = "/n zhrom023_1"
                session.findById("wnd[0]/usr/ctxtPM0D1-SEARK").caretPosition = 12
                session.findById("wnd[0]/tbar[0]/btn[0]").press()
        close_sap()
        return error_index


if __name__ == '__main__':
    check_org_ids(['31450001', '31450001', '798', '31450001'], ['20200203', '20200204', '20200205', '20200206'])
