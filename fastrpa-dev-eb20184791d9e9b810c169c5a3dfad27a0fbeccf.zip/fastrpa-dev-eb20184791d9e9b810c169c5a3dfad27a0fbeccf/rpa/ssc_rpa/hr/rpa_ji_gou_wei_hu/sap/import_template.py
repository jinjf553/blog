import logging

from openpyxl import load_workbook
from rpa.fastrpa.adtable import load_from_xlsx_file
from rpa.ssc.hr.sap.import_xlsx import import_single
from rpa.ssc.sap.utils import init_sap_id
from rpa.ssc_rpa.hr.rpa_ji_gou_wei_hu.tools.excel_tool import WbTool


class WbToolEx(WbTool):
    def __init__(self, filename):
        self.wb = load_workbook(filename)
        self.sheetname = self.wb.get_sheet_by_name(self.wb.sheetnames[0])
        self.filename = filename
        logging.info(f'扫描【{filename}】 sap批导之后的结果')

    def check_value_set_valuse(self, cell, value):
        if not self.sheetname[cell].value or '批导失败' not in self.sheetname[cell].value:
            self.concat_value(cell, value)

    # 出错更新附件表
    def update_break_point(self, fujian_msg_dict, template_tag):
        logging.info(fujian_msg_dict)
        # now_time = time.strftime('%Y-%m-%d %H:%M:%S', time.localtime())
        logging.info('开始回写批导结果')
        for key, value in fujian_msg_dict.items():
            if '失败' in value:
                self.set_red(f'AN{7 + int(key)}')
                self.check_value_set_valuse(f'AN{7 + int(key)}', '批导失败')
                self.concat_value(f'AO{7 + int(key)}', f'{template_tag}')
                logging.info(f'序号【{key}】:批导失败 错误原因：{value}')
        self.save()
        logging.info('批导结果回写到附件表完毕！')


def write_import_result(filename: str, import_file: str, import_name: str):
    """将批导结果回写到模板文件中"""
    lt_file = load_from_xlsx_file(filename, skip_header=7)  # 加载组织机构维护模板
    lt_file['C'].apply(init_sap_id)  # 机构编码转换为8位
    df_file = lt_file.to_dataframe()  # 转化为pandas DataFrame
    lt_import = load_from_xlsx_file(import_file, skip_header=6)  # 加载批导模板（标题都是6行）
    lt_file['B'].apply(init_sap_id)  # 机构编码转换为8位
    df_import = lt_import.to_dataframe()
    df_import_columns = df_import.columns
    is_failed = False
    for rn in df_import.index:
        import_string = df_import[df_import_columns[-2]][rn] + df_import[df_import_columns[-1]][rn]
        org_id = df_import['B'][rn]  # 所有批导模板第二列均为机构编码
        _rn = df_file[df_file['C'] == org_id].index[0]
        if '失败' in import_string:
            is_failed = True
            if '批导失败' not in lt_file['AN'][_rn].value:
                if lt_file['AN'][_rn].value == '':
                    lt_file['AN'][_rn].cmt('red', '批导失败')
                    lt_file['AN'][_rn].value = '批导失败'
                else:
                    lt_file['AN'][_rn].cmt('red', '批导失败')
                    lt_file['AN'][_rn].value = lt_file['AN'][_rn].value + '、' + '批导失败'
            if import_name not in lt_file['AO'][_rn].value:
                if lt_file['AO'][_rn].value == '':
                    lt_file['AO'][_rn].cmt('red', import_name)
                    lt_file['AO'][_rn].value = import_name
                else:
                    lt_file['AO'][_rn].cmt('red', import_name)
                    lt_file['AO'][_rn].value = lt_file['AN'][_rn].value + '、' + import_name
            logging.error(f'机构编码【{org_id}】:批导失败 错误原因：{import_string}')
    lt_file.save(filename)
    if is_failed is False:  # 批导模板结果中没有失败字样
        if list(set(df_import[df_import_columns[-2]].values.tolist())) != ['成功']:
            logging.error(f'{import_name}模板批导失败，但SAP未将错误信息写入模板中')
        else:
            logging.info(f'{import_name}模板批导结果所有记录均成功')


def import_1000_o(_1000_filename: str, filename: str, repeat_times=5):
    if import_single('1000->HR_BI_1000O', _1000_filename, repeat_times) is False:
        write_import_result(filename, _1000_filename, '1000')


def import_a00_2oo(a00_filename: str, filename: str, repeat_times=5):
    if import_single('1001->HR_BI_A002OO', a00_filename, repeat_times) is False:
        write_import_result(filename, a00_filename, '1001')


def import_9005(_9005_filename: str, staff_rng: str, filename: str, is_check=False, repeat_times=5):
    if import_single('9005->HR_BI_9005', _9005_filename, repeat_times) is False:
        write_import_result(filename, _9005_filename, f'9005({staff_rng})')


def import_9010(_9010_filename: str, filename: str, repeat_times=5):
    if import_single('9010->HR_BI_9010', _9010_filename, repeat_times) is False:
        write_import_result(filename, _9010_filename, '9010')


def import_9068(_9068_filename: str, filename: str, repeat_times=5):
    if import_single('9068->HR_BI_9068', _9068_filename, repeat_times) is False:
        write_import_result(filename, _9068_filename, '9068')


def import_1008(_1008_filename: str, filename: str, repeat_times=5):
    if import_single('1008->HR_BI_1008', _1008_filename, repeat_times) is False:
        write_import_result(filename, _1008_filename, '1008')


def import_9004(_9004_filename: str, filename: str, repeat_times=5):
    if import_single('9004->HR_BI_9004', _9004_filename, repeat_times) is False:
        write_import_result(filename, _9004_filename, '9004')


def import_9007(_9007_filename: str, filename: str, repeat_times=5):
    if import_single('9007->HR_BI_9007', _9007_filename, repeat_times) is False:
        write_import_result(filename, _9007_filename, '9007')


def import_9022(_9022_filename: str, filename: str, repeat_times=5):
    if import_single('9022->HR_BI_9022', _9022_filename, repeat_times) is False:
        write_import_result(filename, _9022_filename, '9022')


def import_9014(_9014_filename: str, filename: str, repeat_times=5):
    if import_single('9014->HR_BI_9014', _9014_filename, repeat_times) is False:
        write_import_result(filename, _9014_filename, '9014')


def import_1001(_1001_filename: str, filename: str, repeat_times=5):
    if import_single('1001->HR_BI_A011OK', _1001_filename, repeat_times) is False:
        write_import_result(filename, _1001_filename, '1001')


def import_9064(_9046_filename: str, filename: str, repeat_times=5):
    if import_single('9064->HR_BI_9064', _9046_filename, repeat_times) is False:
        write_import_result(filename, _9046_filename, '9046')


if __name__ == '__main__':
    import_9010(r"x:\mengzhao\Desktop\9010_HR_BI_9010--人员导入--通讯地址.xlsx",
                r"x:\mengzhao\Desktop\1000241287-X63Z-组织机构维护-常盛-1.xlsx")
