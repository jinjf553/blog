import logging
import sys

import rpa
from rpa.ssc.hr.orm.session import DbSession
from rpa.ssc.hr.orm.tb_hr_non_mid import TB_HR_NON_MID as TB_HR_NON_MID
from rpa.ssc.hr.orm.td_hr_gang_wei_diao_pei_rulebase import \
    Event  # 注意：这里必须为Dim，因为eval会把调用函数的table='Dim'解析为此命名空间的Dim; 注意：这里Event不能省略，因为eval会把调用函数的table='Event'解析为此命名空间的Event
from rpa.ssc.hr.orm.td_hr_gang_wei_diao_pei_rulebase import Event as Dim
from sqlalchemy import and_

sys.path.append('../')


def Query(table='TB_HR_NON_MID', **kwargs):
    tup = ()
    for key, value in kwargs.items():
        eval_str = table + '.' + key
        tup = tup + (eval(eval_str) == value,)
    with DbSession() as session:
        for res in session.query(eval(table)).filter(and_(*tup)).all():
            yield res


def QueryFirst(table='TB_HR_NON_MID', **kwargs):
    tup = ()
    for key, value in kwargs.items():
        eval_str = table + '.' + key
        tup = tup + (eval(eval_str) == value,)
    with DbSession() as session:
        res = session.query(eval(table)).filter(and_(*tup)).first()
        yield res


def Insert(table="TB_HR_NON_MID", **kwargs):
    with DbSession() as session:
        obj = eval(table)(**kwargs)
        session.add(obj)


def Insert_all(obj_list):
    with DbSession() as session:
        session.add_all(obj_list)


def Delete(table='TB_HR_NON_MID', **kwargs):
    tup = ()
    for key, value in kwargs.items():
        eval_str = table + '.' + key
        tup = tup + (eval(eval_str) == value,)
    with DbSession() as session:
        session.query(eval(table)).filter(and_(*tup)).delete()


def Update(table='TB_HR_NON_MID', id=None, **kwargs):
    if id is None:
        raise Exception('id is required...')
    tup = ()
    for key, value in kwargs.items():
        eval_str = table + '.' + key
        tup = tup + (eval(eval_str) == value,)
    with DbSession() as session:
        eval_str = table + '.' + 'id'
        que = session.query(eval(table)).filter(eval(eval_str) == id)
        if que.all():
            que.update(kwargs)
        else:
            raise Exception('Not Found Any data!')


def query_dims_staff_rngs(code):
    """查询码表库人事范围"""
    for res in QueryFirst(table='Event', db_BJ=code):
        return res.db_BK


def query_dims_busi_rngs(code) -> str:
    """查询码表库业务范围"""
    with DbSession() as session:
        res = session.query(Dim).filter(Dim.db_BO.like(f'{code}%')).first()
        if res:
            return res.db_BO
        else:
            return ''


def query_dims_corp_ids(code) -> str:
    """查询码表库公司代码"""
    with DbSession() as session:
        res = session.query(Dim).filter(Dim.db_BJ.like(f'{code}%')).first()
        if res:
            return res.db_BI
        else:
            return ''


if __name__ == '__main__':
    logging.info(query_dims_busi_rngs('4000'))
