import logging
import os
import time
from pathlib import Path

from rpa.fastrpa.tempdir import gentempdir

year = time.strftime('%Y', time.localtime(time.time()))
month = time.strftime('%m', time.localtime(time.time()))
day = time.strftime('%d', time.localtime(time.time()))
SAVE_PATH = gentempdir()
FTP_PATH = r'/HR人事/组织机构维护'


# 初始化文件保存路径与FTP回传路径
def reset_save_path_and_ftp_path(filename):
    global SAVE_PATH, FTP_PATH
    if not os.path.exists(SAVE_PATH):
        os.makedirs(SAVE_PATH)
    logging.info('====== 初始化：文件保存目录，与FTP回传目录 =====')
    # SAVE_PATH = rf'{SAVE_PATH}/{filename}'  # 本地保存路径 x:\rpa\files\非中层组织机构维护\文件名
    FTP_PATH = rf'{FTP_PATH}/{year}{month}/{year}{month}{day}/'  # 回传ftp路径 /HR人事/组织机构维护/202004/20200401/
    logging.info(f'====== 文件保存目录为：{SAVE_PATH} =====')
    logging.info(f'====== FTP回传目录为：{FTP_PATH} =====')
    if not os.path.exists(SAVE_PATH):
        os.mkdir(SAVE_PATH)
    return SAVE_PATH, FTP_PATH


# 恢复路径
def reset_global_file_path():
    """重新设置全局变量SAVE_PATH, FTP_BACK_PATH的值"""
    global SAVE_PATH, FTP_PATH
    # SAVE_PATH = r"x:\rpa\files\非中层组织机构维护"
    FTP_PATH = r'/HR人事/组织机构维护'
    Path(SAVE_PATH).mkdir(parents=True, exist_ok=True)
