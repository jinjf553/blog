import logging
import time

import win32api
import win32con
import win32gui

# 按照xpath来点击
KEYBD_EVENT = win32api.keybd_event(115, 0, win32con.KEYEVENTF_KEYUP, 0)


def click_Microsoft_Excel():
    for i in range(240):
        time.sleep(1)
        dialog = win32gui.FindWindow('#32770', 'Microsoft Excel')  # 对话框
        if dialog:
            button = win32gui.FindWindowEx(dialog, 0, 'Button', None)  # 是按钮Button
            win32gui.PostMessage(button, win32con.WM_LBUTTONDOWN, win32con.MK_LBUTTON, 0)
            win32gui.PostMessage(button, win32con.WM_LBUTTONUP, win32con.MK_LBUTTON, 0)
            break
        time.sleep(0.5)


#  点掉 "Microsoft Excel - 兼容性检查器"
def click_continue():
    for i in range(240):
        dialog = win32gui.FindWindow("NUIDialog", "Microsoft Excel - 兼容性检查器")
        if dialog:
            aa = win32gui.FindWindowEx(dialog, 0, 'NetUIHWND', None)
            win32api.PostMessage(aa, win32con.WM_KEYDOWN, win32con.VK_RETURN, 0)  # 发送回车键
            win32api.PostMessage(aa, win32con.WM_KEYUP, win32con.VK_RETURN, 0)
            break
        time.sleep(0.5)


def up_file(file_path, classs=u'#32770', title=u'选择上传文件'):
    for i in range(240):
        dialog = win32gui.FindWindow(classs, title)  # 对话框
        if dialog:
            ComboBoxEx32 = win32gui.FindWindowEx(dialog, 0, 'ComboBoxEx32', None)
            time.sleep(1)
            ComboBox = win32gui.FindWindowEx(ComboBoxEx32, 0, 'ComboBox', None)
            time.sleep(1)
            Edit = win32gui.FindWindowEx(ComboBox, 0, 'Edit', None)  # 上面三句依次寻找对象，直到找到输入框Edit对象的句柄
            time.sleep(1)
            button = win32gui.FindWindowEx(dialog, 0, 'Button', None)  # 确定按钮Button
            time.sleep(1)
            win32gui.SendMessage(Edit, win32con.WM_SETTEXT, None, file_path)
            time.sleep(1)
            win32gui.SendMessage(dialog, win32con.WM_COMMAND, 1, button)
            break
        else:
            time.sleep(0.5)


def quit_bro(browser):
    browser.quit()
    logging.info('浏览器成功退出...')
