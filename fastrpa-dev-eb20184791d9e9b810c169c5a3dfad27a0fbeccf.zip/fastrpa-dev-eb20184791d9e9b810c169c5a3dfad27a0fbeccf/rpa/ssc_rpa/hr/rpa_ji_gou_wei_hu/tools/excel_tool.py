import logging

import xlrd
from openpyxl import load_workbook
from openpyxl.comments import Comment
from openpyxl.styles import PatternFill
from openpyxl.utils import get_column_letter
from rpa.config import TEMPLATE_DIR
from rpa.fastrpa.adtable import RED, load_from_xlsx_file


def alltypestrip(args):
    return args.strip() if type(args) is str else args


# 获取表头与字母的关系
def cols_map(file_path):
    workbook = xlrd.open_workbook(file_path)
    sheet = workbook.sheet_by_name(workbook.sheet_names()[0])
    col_dict = {}
    for i in range(sheet.ncols):
        col_dict[alltypestrip(sheet.cell_value(0, i))] = get_column_letter(i + 1)
    return col_dict


class WbCreateTool():
    def __init__(self, template_name):
        logging.info(f'开始生成【{template_name}】')
        self.wb = load_workbook(TEMPLATE_DIR + '/' + template_name)
        self.sheet = self.wb.get_sheet_by_name(self.wb.sheetnames[0])
        self.template_name = template_name
        self.columns = cols_map(TEMPLATE_DIR + '/' + template_name)

    # 指定列，给从start索引行开始，设置list值
    def set_col_range_value(self, col_name, start, val_list):
        for i in range(len(val_list)):
            self.sheet[rf'{self.columns[col_name]}{start + i}'] = val_list[i]

    # 指定列，从第start索引行开始，重复设置time个值
    def rep_col_range_value(self, col_name, start, _time, value):
        for i in range(_time):
            self.sheet[rf'{self.columns[col_name]}{start + i}'] = value

    # 保存
    def save(self, file_name=None):
        from rpa.ssc_rpa.hr.rpa_ji_gou_wei_hu.ftp_control import SAVE_PATH
        if not file_name:
            self.wb.save(SAVE_PATH + '/' + self.template_name)
            logging.info(f'【{self.template_name}】生成完毕！')
        else:
            self.wb.save(SAVE_PATH + '/' + file_name)
            logging.info(f'【{file_name}】生成完毕！')


class WbTool():
    def __init__(self, filename):
        self.wb = load_workbook(filename)
        self.sheetname = self.wb[self.wb.sheetnames[0]]
        self.filename = filename

    def strip_cell_spaces(self):
        """给表内容中 字符串数据清除左右空格"""
        for col_number in range(self.sheetname.max_column):
            for cell in self.sheetname[get_column_letter(col_number + 1)]:
                if isinstance(cell.value, str):
                    cell.value = cell.value.strip(' ')

    def reset_column_a_index(self):
        """重新设置A列序号"""
        for row in range(self.sheetname.max_row - 7):
            self.sheetname[f'A{row + 8}'].value = row + 1
        self.save()

    def concat_value(self, cell, value):
        """给单元格追加信息"""
        if self.sheetname[cell].value:
            self.sheetname[cell].value += '、' + value
        else:
            self.sheetname[cell].value = value

    def set_red_comment_type1(self, cell):
        """设置批导前校验出错"""
        self.set_red(cell)
        if '批导前校验出错' not in str(self.sheetname[cell].value):
            self.concat_value(cell, '批导前校验出错')

    def set_red_comment_type2(self, cell, value):
        """设置机构更名出错"""
        self.set_red(cell)
        self.concat_value(cell, value)

    # 给单元格设置信息(会覆盖之前的值)
    def replace_value(self, cell, value):
        self.sheetname[cell].value = value

    # 添加批注
    def set_comment(self, cell, error_msg, height=100, width=200):
        comment_msg = self.sheetname[cell].comment.content + error_msg if self.sheetname[
            cell].comment else '' + error_msg
        comment = Comment(rf'{comment_msg}', '机器人', height=height, width=width)
        self.sheetname[cell].comment = comment

    # 设置红色背景
    def set_red(self, cell):
        fill_red = PatternFill(fill_type='solid', fgColor=RED)
        self.sheetname[cell].fill = fill_red

    # 保存
    def save(self):
        self.wb.save(self.filename)


# 清空批注与描述
def remove_comment_and_fgcolor(file):
    lt = load_from_xlsx_file(file, skip_header=7)
    lt.clear_comment_and_fgcolor()
    for column_letter in ['AN', 'AO', 'AP']:
        for cell in lt[column_letter].cells:
            cell.value = ''
    lt.save(file)
    logging.info('清除完毕')


# 检测扩展名与内容转为str类型


if __name__ == '__main__':
    file = r"x:\Users\Administrator\Desktop\非中层待办\1000173639-内蒙古石油-组织机构维护-常盛.xlsx"
    remove_comment_and_fgcolor(file)
