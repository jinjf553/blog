#!/usr/bin/env python
# -*- coding: utf-8 -*-
# @Date    : 2019-04-08 21:45:47

import logging
import os
import re
import shutil
import time
from collections import defaultdict
from datetime import datetime, timedelta
from threading import Thread

from openpyxl import load_workbook
from rpa.fastrpa.adtable import BLUE, RED
from rpa.fastrpa.path import to_windows_path_format
from rpa.fastrpa.sap.session import attach_sap
from rpa.public.config import FILE_PATH, remote_lwg
from rpa.public.db import update_db
from rpa.public.event_public import (clear_all_colour_and_comment, send_email,
                                     update_database)
from rpa.public.myftp import MYFTP
from rpa.public.tools import cel, cells, find_window
from rpa.ssc.hr.orm.orm import rpa_work_amount
from rpa.ssc.hr.rpa_dir import get_rpa_dir
from rpa.ssc.hr.sap.export_other_103 import (export_103_li_zhi2,
                                             export_103_li_zhi3)
from rpa.ssc_kit.hr.kit_chai_dan.check_280 import check_zhrpy280


def lao_wu_gong_pre_check(filename):
    logging.info("开始劳务工退回事件批导前校验...")
    wb = load_workbook(filename)
    ws = wb.active

    # 1.1.2	校验文件名格式
    li = os.path.basename(filename).split("-")
    if len(li) < 4 or not (li[0].isdigit() or li[0] != "无单号") or len(li[1]) != 4 or li[2] != "劳务工退回":
        cells(ws, "A7", "文件名称错误，应为:单号-人事范围代码-劳务工退回-业务人员姓名或无单号-人事范围代码-劳务工退回-业务人员姓名", RED)

    # 1.1.3  通过组合逻辑查询下载离职C23-2、C23-3
    lis = [cel(ws, f"B{x}") for x in range(7, len(ws["A"]) + 1) if cel(ws, f"B{x}")]
    date = [cel(ws, f"D{x}") for x in range(7, len(ws["A"]) + 1) if cel(ws, f"D{x}")][0]
    if not lis:
        logging.info("劳务工退回模板中没有离职事件。")
        return
    logging.info("提取校验所需要的劳务工退回103数据...")
    export_103_li_zhi2(None, lis, date).save_to(FILE_PATH)

    try:
        time_stamp = time.mktime(time.strptime(date, "%Y%m%d"))
        yesterday = time.strftime("%Y%m%d", time.localtime(int(time_stamp) - 24 * 60 * 60))
    except Exception:
        yesterday = date
    export_103_li_zhi3("reuse", lis, yesterday).save_to(FILE_PATH)

    wb_103 = load_workbook(FILE_PATH + "/C23-2离职.xlsx")
    ws_103 = wb_103.active
    values_103 = defaultdict(list)
    for i in range(2, len(ws_103["A"]) + 1):
        for x in ["C", "D", "F", "L", "M", "O", "AS", "AT", "AV", "BA", "BB", "BD", "BK", "BM"]:
            ws_103[f"{x}{i}"] = str(ws_103[f"{x}{i}"].value).replace(".", "").replace("00000000", "")
        for col in ["S", "G", "AT", "BB", "BK", "BM"]:
            values_103[cel(ws_103, f"A{i}").lstrip('0')].append(cel(ws_103, f"{col}{i}"))
    wb_103.save(FILE_PATH + "/事前-C23-2离职.xlsx")

    wb_103 = load_workbook(FILE_PATH + "/C23-3劳动合同.xlsx")
    ws_103 = wb_103.active
    values_103_1 = defaultdict(list)
    for i in range(2, len(ws_103["A"]) + 1):
        for x in ["D", "E", "G", "P"]:
            ws_103[f"{x}{i}"] = str(ws_103[f"{x}{i}"].value).replace(".", "").replace("00000000", "")
        for col in ["D", "E", "Z"]:
            values_103_1[cel(ws_103, f"A{i}").lstrip('0')].append(cel(ws_103, f"{col}{i}"))
    wb_103.save(FILE_PATH + "/事前-C23-3劳动合同.xlsx")

    now = datetime.now()
    next_month = datetime(*(now.year, now.month + 1) if now.month + 1 < 13 else (now.year + 1, 1), 1, 0, 0, 0)
    last_month = datetime(*(now.year, now.month - 1) if now.month - 1 > 0 else (now.year - 1, 12), 1, 0, 0, 0)
    cur_month = datetime(now.year, now.month, 1, 0, 0, 0)
    las, cur, nex = last_month.strftime("%Y%m%d"), cur_month.strftime("%Y%m%d"), next_month.strftime("%Y%m%d")
    month_last = (next_month - timedelta(days=1)).strftime("%Y%m%d")
    up_last = (cur_month - timedelta(days=1)).strftime("%Y%m%d")

    for i in range(7, len(ws["A"]) + 1):
        # 1.2.1  校验人员编号
        logging.info(f"开始校验劳务工退回模板第{i - 6}行数据...")
        ws[f"B{i}"] = key = "".join(re.findall(r"\d", str(ws[f"B{i}"].value))).lstrip("0")
        if len(cel(ws, f"B{i}")) > 8:
            cells(ws, f"B{i}", "人员编号有误", RED)
        if key not in values_103.keys():
            cells(ws, f"B{i}", "离职103中没有该人员编号", RED)
            continue

        # 1.2.3	 校验开始日期
        if cel(ws, f"D{i}") not in [cur, nex]:
            if cel(ws, f"D{i}") in [month_last, up_last]:
                cells(ws, f"D{i}", "事件执行日期为月末，请核对！", BLUE)
            else:
                cells(ws, f"D{i}", "事件执行日期有误！", RED)

        # 1.2.4	劳动合同确认
        ws[f"I{i}"], ws[f"H{i}"] = "", ""
        if key in values_103_1.keys():
            if len(values_103_1[key]) == 3 and not values_103_1[key][1]:
                cells(ws, f"H{i}", "不存在需要定界的劳动合同！", BLUE)
            else:
                ws[f"I{i}"] = values_103_1[key][1]
                try:
                    tmp_ls = values_103_1[key]
                    for x in range(0, len(tmp_ls), 3):
                        if tmp_ls[x] and int(cel(ws, f"D{i}")) <= int(tmp_ls[x]):
                            cells(ws, f"H{i}", "该人存在未来时间的劳动合同，请与企业确认如何处理！", RED)
                except Exception:
                    cells(ws, f"H{i}", "D列事件日期非正确值", RED)

        # 1.2.5	校验人员组
        if values_103[key][0] != "C":
            cells(ws, f"B{i}", "人员组只能为C类！", RED)

        # 1.3.6	校验当月是否已有事件
        if values_103[key][1].replace("暂停/恢复发薪", ""):
            cells(ws, f"A{i}", "当月已有事件！", RED)

        # 1.4.1	生成合同解除/终止日期
        if ws[f"H{i}"].comment is None:
            if cel(ws, f"D{i}") in [las, cur, nex]:
                ws[f"J{i}"] = (datetime.strptime(cel(ws, f"D{i}"), "%Y%m%d") - timedelta(days=1)).strftime("%Y%m%d")
            elif cel(ws, f"D{i}").isdigit() and int(las) < int(cel(ws, f"D{i}")) <= int(nex[:-2] + "31"):
                ws[f"J{i}"] = cel(ws, f"D{i}")
            else:
                cells(ws, f"J{i}", "劳务工退回RPA只执行上月、当月、次月的事件！", RED)
        # 事件执行日期上月的最后一天
        if cel(ws, f"D{i}").isdigit() and len(cel(ws, f"D{i}")) == 8:
            d_date = (datetime.strptime(cel(ws, f"D{i}")[:-2] + "01", "%Y%m%d") - timedelta(1)).strftime("%Y%m%d")
        else:
            d_date = ""
        # 1.4.2	生成其他用工信息定界日期
        ws[f"M{i}"] = ""
        if values_103[key][2]:
            ws[f"M{i}"] = d_date

        # 1.4.3	生成增减变动定界日期
        ws[f"N{i}"] = ""
        if values_103[key][3]:
            ws[f"N{i}"] = d_date

        # 1.4.4	生成行政党派主次职务定界日期
        ws[f"K{i}"] = ""
        if values_103[key][4]:
            ws[f"K{i}"] = d_date

        # 1.4.5	生成行政党派兼任职务定界日期
        ws[f"L{i}"] = ""
        if values_103[key][5]:
            ws[f"L{i}"] = d_date

    logging.info("劳务工退回模板执行事件前校验完成...")
    wb.save(filename)


# 执行离职事件操作
def lao_wu_gong_tui_hui_operate(count, r_file):
    logging.info("开始执行劳务工退回模板批导...")
    r_file = str(r_file).replace("/", "\\")
    session = attach_sap("login_tx")
    session.findById("wnd[0]/tbar[0]/okcd").text = "/n zhrbi0013"
    session.findById("wnd[0]").sendVKey(0)
    session.findById("wnd[0]/usr/radRB_M").select()
    session.findById("wnd[0]/usr/radRB_M_MZ").select()
    session.findById("wnd[0]/tbar[1]/btn[8]").press()
    session.findById("wnd[0]/usr/radRB_UP").select()
    # fix_excel(r_file)
    t = Thread(target=find_window, args=(r_file, '#32770', u'选择上传文件'))
    t.setDaemon(True)
    t.start()
    session.findById("wnd[0]/tbar[1]/btn[8]").press()
    if "上载的模板中没有数据或数据错误" in session.findById("wnd[0]/sbar/pane[0]").text:
        if 10 < count:
            with MYFTP() as my_ftp:
                hhmmss = datetime.datetime.now().strftime(r'%H%M%S')  # 上传的目录前面加时分秒前缀，避免同一天一个单子，第二次做覆盖上一次的文件
                remote = remote_lwg + f"失败/{hhmmss}_" + os.path.basename(r_file).split(".")[0] + "/"
                my_ftp.upload_file(r_file, remote + os.path.basename(r_file).split(".")[0] + "_模板错误.xlsx")
            session.findById("wnd[0]/tbar[0]/okcd").text = "/nex"
            session.findById("wnd[0]").sendVKey(0)
            return True
        count += 1
        time.sleep(10)
        flag = lao_wu_gong_tui_hui_operate(count, r_file)
        return flag

    try:
        tb = session.findById("wnd[1]/usr/cntlG_GRID/shellcont/shell")
        wb = load_workbook(r_file)
        ws = wb.active
        for i in range(tb.rowCount):
            cells(ws, f"A{int(tb.getCellValue(i, 'ZZ_XH')) + 6}",
                  f'{tb.getCellValue(i, "FIELD")}:{tb.getCellValue(i, "MSG")}', RED)
        wb.save(r_file)
    except Exception:  # nosec
        pass  # SAP情形不存在，跳过执行
    try:
        result = session.findById("wnd[1]/usr/txtSPOP-TEXTLINE2").text
        session.findById("wnd[1]/usr/btnSPOP-OPTION1").press()
    except Exception:
        result = f'{session.findById("wnd[0]/sbar/pane[0]").text}'
    logging.info(result)
    if "失败0" not in result:
        with MYFTP() as my_ftp:
            dir_path = get_rpa_dir('劳务工退回', os.path.basename(r_file), False)
            hhmmss = datetime.datetime.now().strftime(r'%H%M%S')  # 上传的目录前面加时分秒前缀，避免同一天一个单子，第二次做覆盖上一次的文件
            remote = remote_lwg + f"失败/{hhmmss}_" + r_file.split('\\')[-1].split(".")[0] + "/"
            my_ftp.upload_file(r_file, remote + r_file.split('\\')[-1].split(".")[0] + "_批导失败.xlsx")
            for _file in os.listdir(FILE_PATH):
                my_ftp.upload_file(os.path.join(FILE_PATH, _file), f'{remote}/{_file}')
                shutil.copyfile(os.path.join(FILE_PATH, _file), f'{dir_path}/{_file}')
        update_database(r_file, f"批导结束，{result}")
        logging.info(result)
        logging.error('zhrbi0013批导模板表批导失败, 程序结束运行')
        return True


def first_check_lwg_103(file):
    wb_temp = load_workbook(file)
    ws_temp = wb_temp.active
    # 1.1.3  通过组合逻辑查询下载离职C23-2
    lis = [cel(ws_temp, f"B{x}") for x in range(7, len(ws_temp["A"]) + 1) if cel(ws_temp, f"B{x}")]
    date = [cel(ws_temp, f"D{x}") for x in range(7, len(ws_temp["A"]) + 1) if cel(ws_temp, f"D{x}")][0]
    logging.info("批导后校验劳务工退回103数据...")
    # 1.6.1	通过组合逻辑查询下载离职C23-2
    export_103_li_zhi2(None, lis, date).save_to(FILE_PATH)
    wb = load_workbook(FILE_PATH + "/C23-2离职.xlsx")
    ws = wb.active
    res_dict = defaultdict(list)
    for i in range(2, len(ws["A"]) + 1):
        # 1.6.2	校验事件是否成功
        if cel(ws, f"G{i}") != "劳务派遣工退回":
            cells(ws, f"G{i}", "劳务工退回事件不成功！", RED)
            res_dict[True].append(f"G{i}")

        # 1.6.3	校验事件是否成功
        if cel(ws, f"J{i}") != "离职":
            cells(ws, f"J{i}", "岗位状态有误！", RED)
            res_dict[True].append(f"J{i}")
    wb.save(f"{FILE_PATH}/劳务工模板批导后_103.xlsx")
    logging.info(f"校验结果为：{f'失败, 失败原因在文件【{FILE_PATH}/劳务工模板批导后_103.xlsx】中批注标记' if True in res_dict.keys() else '成功'}！")
    return True if True in res_dict.keys() else False


def lao_wu_gong_pa30(file):
    def enter_pa30(session, value, date, col, row):
        session.findById("wnd[0]/tbar[0]/okcd").text = '/n pa30'
        session.findById("wnd[0]").sendVKey(0)
        session.findById("wnd[0]/usr/ctxtRP50G-PERNR").text = value
        session.findById("wnd[0]").sendVKey(0)
        session.findById(f"wnd[0]/usr/tabsMENU_TABSTRIP/tabpTAB0{col}").select()
        session.findById(
            f"wnd[0]/usr/tabsMENU_TABSTRIP/tabpTAB0{col}/ssubSUBSCR_MENU:SAPMP50A:0400/subSUBSCR_ITMENU:SAPMP50A:0310/tblSAPMP50ATC_MENU").verticalScrollbar.position = row
        text = session.findById(
            f"wnd[0]/usr/tabsMENU_TABSTRIP/tabpTAB0{col}/ssubSUBSCR_MENU:SAPMP50A:0400/subSUBSCR_ITMENU:SAPMP50A:0310/tblSAPMP50ATC_MENU/lblINF_EX[1,0]").toolTip
        session.findById(
            f"wnd[0]/usr/tabsMENU_TABSTRIP/tabpTAB0{col}/ssubSUBSCR_MENU:SAPMP50A:0400/subSUBSCR_ITMENU:SAPMP50A:0310/tblSAPMP50ATC_MENU").getAbsoluteRow(
            row).selected = -1
        button = "6" if text == "存在" else "5"
        session.findById(
            "wnd[0]/usr/tabsMENU_TABSTRIP/tabpTAB03/ssubSUBSCR_MENU:SAPMP50A:0400/subSUBSCR_TIME:SAPMP50A:0330/ctxtRP50G-BEGDA").text = date
        session.findById(
            "wnd[0]/usr/tabsMENU_TABSTRIP/tabpTAB03/ssubSUBSCR_MENU:SAPMP50A:0400/subSUBSCR_TIME:SAPMP50A:0330/ctxtRP50G-ENDDA").text = "99991231"
        return button

    wb = load_workbook(file)
    ws = wb.active
    sess = attach_sap("login_tx")
    logging.info("开始劳务工退回事件PA30各屏信息的修改")
    for i in range(7, len(ws["A"]) + 1):
        try:
            # 2.1.6	生成合同解除/终止日期
            if "rgb='000000FF'" not in str(ws[f"T{i}"].fill):
                btn = enter_pa30(sess, cel(ws, f"B{i}"), cel(ws, f"D{i}"), 3, 3)
                sess.findById(f"wnd[0]/tbar[1]/btn[{btn}]").press()
                sess.findById("wnd[0]/usr/ctxtP9299-ENDDA").text = cel(ws, f"J{i}")
                sess.findById("wnd[0]/usr/cmbP9299-ZZ_HTBS").key = "4"
                sess.findById("wnd[0]/usr/ctxtP9299-ZZ_HTJSRQ").text = cel(ws, f"I{i}")
                sess.findById("wnd[0]/usr/txtP9299-ZZ_JCHBGYY").text = "劳务派遣工退回"
                sess.findById("wnd[0]").sendVKey(0)
                sess.findById("wnd[0]").sendVKey(0)
                sess.findById("wnd[0]/tbar[0]/btn[11]").press()
        except Exception:
            # ws[f"P{i}"] = f"{cel(ws, f'P{i}')}劳动合同屏错误; "
            # ws[f"Q{i}"] = cel(ws, f"Q{i}") + f"; 劳动合同屏错误,SAP报错：【{sess.findById('wnd[0]/sbar').text}】"
            logging.info(f"    劳动合同屏错误,SAP报错：【{sess.findById('wnd[0]/sbar').text}】")

        try:
            # 2.1.7	生成其他用工信息定界日期
            if cel(ws, f"M{i}"):
                btn = enter_pa30(sess, cel(ws, f"B{i}"), cel(ws, f"D{i}"), 2, 0)
                sess.findById(f"wnd[0]/tbar[1]/btn[{btn}]").press()
                sess.findById("wnd[0]/usr/ctxtP9241-ENDDA").text = cel(ws, f"M{i}")
                sess.findById("wnd[0]").sendVKey(0)
                sess.findById("wnd[0]").sendVKey(0)
                sess.findById("wnd[0]/tbar[0]/btn[11]").press()
        except Exception:
            # ws[f"P{i}"] = f"{cel(ws, f'P{i}')}其他用工信息屏错误; "
            # ws[f"Q{i}"] = cel(ws, f"Q{i}") + f"; 其他用工信息屏错误,SAP报错：【{sess.findById('wnd[0]/sbar').text}】"
            logging.info(f"    其他用工信息屏错误,SAP报错：【{sess.findById('wnd[0]/sbar').text}】")

        try:
            # 2.1.8	生成人员增减变动信息定界日期
            if cel(ws, f"N{i}"):
                enter_pa30(sess, cel(ws, f"B{i}"), cel(ws, f"D{i}"), 3, 7)
                sess.findById("wnd[0]/tbar[1]/btn[20]").press()
                d_date = datetime.strptime(cel(ws, f"N{i}"), "%Y%m%d")
                for x in range(20):
                    try:
                        s_date = sess.findById(f"wnd[0]/usr/tblMP925300TC3000/txtP9253-BEGDA[0,{x}]").text
                        s_date = datetime.strptime(s_date, "%Y.%m.%d")
                    except Exception:
                        break
                    e_date = sess.findById(f"wnd[0]/usr/tblMP925300TC3000/txtP9253-ENDDA[1,{x}]").text
                    if s_date < d_date and e_date == "9999.12.31":
                        sess.findById("wnd[0]/usr/tblMP925300TC3000").getAbsoluteRow(x).selected = -1
                        sess.findById("wnd[0]/tbar[1]/btn[6]").press()
                        sess.findById("wnd[0]/usr/ctxtP9253-ENDDA").text = cel(ws, f"N{i}")
                        sess.findById("wnd[0]").sendVKey(0)
                        sess.findById("wnd[0]/tbar[0]/btn[11]").press()
        except Exception:
            # ws[f"P{i}"] = f"{cel(ws, f'P{i}')}优化配置与人员增减信息屏错误; "
            # ws[f"Q{i}"] = cel(ws, f"Q{i}") + f"; 优化配置与人员增减信息屏错误,SAP报错：【{sess.findById('wnd[0]/sbar').text}】"
            logging.info(f"    优化配置与人员增减信息屏错误,SAP报错：【{sess.findById('wnd[0]/sbar').text}】")

        try:
            # 2.1.10	生成行政党派主次职务定界日期
            if cel(ws, f"K{i}"):
                enter_pa30(sess, cel(ws, f"B{i}"), cel(ws, f"D{i}"), 4, 1)
                sess.findById("wnd[0]/tbar[1]/btn[20]").press()
                for x in range(20):
                    try:
                        e_date = sess.findById(f"wnd[0]/usr/tblMP925100TC3000/txtP9251-ENDDA[1,{x}]").text
                    except Exception:
                        break
                    if e_date == "9999.12.31":
                        sess.findById("wnd[0]/usr/tblMP925100TC3000").getAbsoluteRow(x).selected = -1
                        sess.findById("wnd[0]/tbar[1]/btn[6]").press()
                        sess.findById("wnd[0]/usr/ctxtP9251-ENDDA").text = cel(ws, f"K{i}")
                        sess.findById("wnd[0]").sendVKey(0)
                        sess.findById("wnd[0]/tbar[0]/btn[11]").press()
        except Exception:
            # ws[f"P{i}"] = f"{cel(ws, f'P{i}')}行政党派职务信息屏错误; "
            # ws[f"Q{i}"] = cel(ws, f"Q{i}") + f"; 行政党派职务信息屏错误,SAP报错：【{sess.findById('wnd[0]/sbar').text}】"
            logging.info(f"    行政党派职务信息屏错误,SAP报错：【{sess.findById('wnd[0]/sbar').text}】")

        try:
            # 2.1.11	生成行政党派兼任职务定界日期
            if cel(ws, f"L{i}"):
                enter_pa30(sess, cel(ws, f"B{i}"), cel(ws, f"D{i}"), 4, 2)
                sess.findById("wnd[0]/tbar[1]/btn[20]").press()
                for x in range(20):
                    try:
                        e_date = sess.findById(f"wnd[0]/usr/tblMP924200TC3000/txtP9242-ENDDA[1,{x}]").text
                    except Exception:
                        break
                    if e_date == "9999.12.31":
                        sess.findById("wnd[0]/usr/tblMP924200TC3000").getAbsoluteRow(x).selected = -1
                        sess.findById("wnd[0]/tbar[1]/btn[6]").press()
                        sess.findById("wnd[0]/usr/ctxtP9242-ENDDA").text = cel(ws, f"L{i}")
                        sess.findById("wnd[0]").sendVKey(0)
                        sess.findById("wnd[0]/tbar[0]/btn[11]").press()
        except Exception:
            # ws[f"P{i}"] = f"{cel(ws, f'P{i}')}兼任职务信息屏错误; "
            # ws[f"Q{i}"] = cel(ws, f"Q{i}") + f"; 兼任职务信息屏错误,SAP报错：【{sess.findById('wnd[0]/sbar').text}】"
            logging.info(f"    兼任职务信息屏错误,SAP报错：【{sess.findById('wnd[0]/sbar').text}】")

        try:
            sess.findById("wnd[0]/tbar[0]/okcd").text = "/n PA30"
            sess.findById("wnd[0]").sendVKey(0)
            sess.findById(
                "wnd[0]/shellcont/shell/shellcont[0]/shell/shellcont[1]/shell[1]").topNode = "          1"
            sess.findById("wnd[0]/usr/ctxtRP50G-PERNR").text = cel(ws, f"B{i}")
            sess.findById("wnd[0]/usr/ctxtRP50G-PERNR").caretPosition = 7
            sess.findById("wnd[0]").sendVKey(0)
            sess.findById("wnd[0]/usr/tabsMENU_TABSTRIP/tabpTAB03").select()
            sess.findById(
                "wnd[0]/usr/tabsMENU_TABSTRIP/tabpTAB03/ssubSUBSCR_MENU:SAPMP50A:0400/subSUBSCR_ITMENU:SAPMP50A:0310/tblSAPMP50ATC_MENU").getAbsoluteRow(
                0).selected = -1
            sess.findById("wnd[0]/tbar[1]/btn[20]").press()
            sess.findById("wnd[0]/usr/tblMP000100TC3000").getAbsoluteRow(0).selected = -1
            sess.findById("wnd[0]/usr/tblMP000100TC3000/txtP0001-BEGDA[0,0]").setFocus()
            sess.findById("wnd[0]/usr/tblMP000100TC3000/txtP0001-BEGDA[0,0]").caretPosition = 0
            sess.findById("wnd[0]/tbar[1]/btn[6]").press()
            try:
                sess.findById("wnd[0]/usr/subSUBSCREEN_T582C:ZP000100:0200/ctxtP0001-ZZ_ZEFW").text = ''
                sess.findById("wnd[0]/usr/subSUBSCREEN_T582C:ZP000100:0200/ctxtP0001-ZZ_ZEFW").setFocus()
                sess.findById(
                    "wnd[0]/usr/subSUBSCREEN_T582C:ZP000100:0200/ctxtP0001-ZZ_ZEFW").caretPosition = 2
            except Exception:
                logging.warning('工资总额控制范围已带出，无需修改')
                time.sleep(1)
                sess.findById("wnd[0]").sendVKey(0)
                sess.findById("wnd[0]").sendVKey(0)
            sess.findById("wnd[0]/tbar[0]/btn[11]").press()
        except Exception:
            logging.info(f"    组织分配屏错误,SAP报错：【{sess.findById('wnd[0]/sbar').text}】")
        wb.save(file)


# 离职事件事后校验
def lao_wu_gong_post_check(s_file):
    logging.info("开始劳务工退回事件后置校验...")
    wb_temp = load_workbook(s_file)
    ws_temp = wb_temp.active
    res_dict = defaultdict(list)

    # 1.1.3  通过组合逻辑查询下载离职C23-2、C23-3
    lis = [cel(ws_temp, f"B{x}") for x in range(7, len(ws_temp["A"]) + 1) if cel(ws_temp, f"B{x}")]
    rpa_work_amount(lis)
    date = [cel(ws_temp, f"D{x}") for x in range(7, len(ws_temp["A"]) + 1) if cel(ws_temp, f"D{x}")][0]
    if not lis:
        logging.info("人员离退表中没有劳务工退回事件。")
        return
    logging.info("提取校验所需要的劳务工退回离职103数据...")
    export_103_li_zhi2(None, lis, date).save_to(FILE_PATH)

    try:
        time_stamp = time.mktime(time.strptime(date, "%Y%m%d"))
        yesterday = time.strftime("%Y%m%d", time.localtime(int(time_stamp) - 24 * 60 * 60))
    except Exception:
        yesterday = date
    logging.info("提取校验所需要的劳务工退回离职劳动合同103数据...")
    export_103_li_zhi3("reuse", lis, yesterday).save_to(FILE_PATH)

    wb = load_workbook(FILE_PATH + "/C23-2离职.xlsx")
    ws = wb.active
    for i in range(2, len(ws["A"]) + 1):
        for x in ["C", "D", "F", "L", "M", "O", "AS", "AT", "AV", "BA", "BB", "BD", "BK", "BM"]:
            ws[f"{x}{i}"] = str(ws[f"{x}{i}"].value).replace(".", "").replace("00000000", "")
    wb.save(FILE_PATH + "/C23-2离职.xlsx")

    wb_103 = load_workbook(FILE_PATH + "/C23-3劳动合同.xlsx")
    ws_103 = wb_103.active
    values_103_1 = defaultdict(list)
    for i in range(2, len(ws_103["A"]) + 1):
        for x in ["D", "E", "G", "P"]:
            ws_103[f"{x}{i}"] = str(ws_103[f"{x}{i}"].value).replace(".", "").replace("00000000", "")
        for col in ["D"]:
            values_103_1[cel(ws_103, f"A{i}").lstrip('0')].append(cel(ws_103, f"{col}{i}"))
    wb_103.save(FILE_PATH + "/C23-3劳动合同.xlsx")

    for i in range(2, len(ws["A"]) + 1):
        logging.info(f"开始校验事后劳务工退回103第{i - 1}行数据...")

        # 3.1.2	校验事件是否成功
        if cel(ws, f"G{i}") != "劳务派遣工退回":
            cells(ws, f"G{i}", "劳务工退回事件不成功！", RED)
            res_dict[True].append(f"G{i}")

        # 3.1.3	校验事件是否成功
        if cel(ws, f"J{i}") != "离职":
            cells(ws, f"J{i}", "岗位状态有误！", RED)
            res_dict[True].append(f"J{i}")

        # 3.1.4	校验事件是否成功
        if cel(ws, f"K{i}") != "不在册不在岗":
            cells(ws, f"K{i}", "雇佣状态有误！", RED)

        # 3.1.5.1	校验开始日期
        if not (cel(ws, f"C{i}") == cel(ws, f"L{i}") == date):
            cells(ws, f"C{i}", "开始日期与表单不一致！", RED)
            cells(ws, f"L{i}", "开始日期与表单不一致！", RED)
            res_dict[True].append(f"C{i}")
            res_dict[True].append(f"L{i}")

        # 3.1.5.2	校验开始日期
        if not (cel(ws, f"C{i}")[-2:] == cel(ws, f"L{i}")[-2:] == "01"):
            cells(ws, f"C{i}", "开始日期不为1日！", RED)
            cells(ws, f"L{i}", "开始日期不为1日！", RED)
            res_dict[True].append(f"C{i}")
            res_dict[True].append(f"L{i}")

        # 3.1.6	校验工资范围
        if cel(ws, f"Z{i}") != "00":
            cells(ws, f"Z{i}", "工资范围不为00！", RED)
            res_dict[True].append(f"Z{i}")

        # 3.1.7	校验工资总额控制范围
        if cel(ws, f"Z{i}") == "00" and cel(ws, f"AB{i}"):
            cells(ws, f"AB{i}", "工资范围为00，工资总额控制范围应为空！", RED)
            res_dict[True].append(f"AB{i}")

        # 3.1.8	校验事件是否成功
        if cel(ws, f"S{i}") != "N":
            cells(ws, f"S{i}", "人员组有误！", RED)
            res_dict[True].append(f"S{i}")

        # 3.1.9	校验事件是否成功
        if cel(ws, f"T{i}") != "71":
            cells(ws, f"T{i}", "人员子组有误！", RED)
            res_dict[True].append(f"T{i}")

        # 3.1.10	校验事件是否成功
        if cel(ws, f"X{i}") != "99999999":
            cells(ws, f"X{i}", "劳务工退回事件失败！", RED)
            res_dict[True].append(f"X{i}")

        # 3.1.11	校验其他用工信息
        if cel(ws, f"AS{i}"):
            cells(ws, f"AS{i}", "其他用工信息未定界！", RED)
            res_dict[True].append(f"AS{i}")

        # 3.1.12	校验行政党派
        if cel(ws, f"BK{i}"):
            cells(ws, f"BK{i}", "行政党派未定界！", RED)
            res_dict[True].append(f"BK{i}")

        # 3.1.13	校验兼任职务
        if cel(ws, f"BM{i}"):
            cells(ws, f"BM{i}", "兼任职务未定界！", RED)
            res_dict[True].append(f"BM{i}")

        # 3.1.15	校验劳动合同
        if cel(ws, f"A{i}") in values_103_1.keys() and len(values_103_1[cel(ws, f"A{i}")]) == 1:
            if values_103_1[cel(ws, f"A{i}")][0]:
                cells(ws, f"A{i}", "劳动合同未定界！", RED)
                res_dict[True].append(f"A{i}")
    wb.save(FILE_PATH + "/C23-2离职.xlsx")

    res, flag = ("失败", False) if True in res_dict.keys() else ("成功", True)
    dir_path = get_rpa_dir('劳务工退回', os.path.basename(s_file), flag)
    with MYFTP() as my_ftp:
        remote = remote_lwg + f"{res}/{os.path.basename(s_file)[:-5]}/"
        ds = {s_file: (f"{dir_path}/{os.path.basename(s_file)}", remote + os.path.basename(s_file)),
              f"{FILE_PATH}/C23-2离职.xlsx": (f"{dir_path}/事后-C23-2离职.xlsx", f"{remote}事后-C23-2离职.xlsx"),
              f"{FILE_PATH}/C23-3劳动合同.xlsx": (f"{dir_path}/事后-C23-3劳动合同.xlsx", f"{remote}事后-C23-3劳动合同.xlsx"),
              f"{FILE_PATH}/事前-C23-2离职.xlsx": (f"{dir_path}/事前-C23-2离职.xlsx", f"{remote}事前-C23-2离职.xlsx"),
              f"{FILE_PATH}/事前-C23-3劳动合同.xlsx": (f"{dir_path}/事前-C23-3劳动合同.xlsx", f"{remote}事前-C23-3劳动合同.xlsx"),
              f"{FILE_PATH}/劳务工模板批导后_103.xlsx": (f"{dir_path}/劳务工批导后_103.xlsx", f"{remote}劳务工批导后_103.xlsx")}
        for x, (y, z) in ds.items():
            if os.path.exists(x):
                shutil.copyfile(x, y)
            if os.path.exists(y):
                my_ftp.upload_file(y, z)
    update_database(s_file, "执行结束")


def upload_ftp(filename):
    dir_path = get_rpa_dir('劳务工退回', os.path.basename(filename), False)
    with MYFTP() as my_ftp:
        hhmmss = datetime.datetime.now().strftime(r'%H%M%S')  # 上传的目录前面加时分秒前缀，避免同一天一个单子，第二次做覆盖上一次的文件
        remote = f'{remote_lwg}失败/{hhmmss}_{os.path.basename(filename)[:-5]}/'
        ds = {filename: (f"{dir_path}/{os.path.basename(filename)}", remote + os.path.basename(filename)),
              f"{FILE_PATH}/事前-C23-2离职.xlsx": (f"{dir_path}/事前-C23-2离职.xlsx", f"{remote}事前-C23-2离职.xlsx"),
              f"{FILE_PATH}/事前-C23-3劳动合同.xlsx": (f"{dir_path}/事前-C23-3劳动合同.xlsx", f"{remote}事前-C23-3劳动合同.xlsx"),
              f"{FILE_PATH}/劳务工模板批导后_103.xlsx": (f"{dir_path}/劳务工批导后_103.xlsx", f"{remote}劳务工批导后_103.xlsx")}
        for x, (y, z) in ds.items():
            if os.path.exists(x):
                shutil.copyfile(x, y)
            if os.path.exists(y):
                my_ftp.upload_file(y, z)


def run_lao_wu_gong_shi_jian(filename):
    file = to_windows_path_format(filename)
    update_db(file, "开始执行")
    # 模板批导前校验
    clear_all_colour_and_comment(file, "劳务工退回模板表", remote_lwg)
    check_zhrpy280(file)
    lao_wu_gong_pre_check(file)
    if send_email(file):
        upload_ftp(file)
        return
    # 模板批导
    if lao_wu_gong_tui_hui_operate(1, file):
        return
    if first_check_lwg_103(file):
        upload_ftp(file)
        return
    lao_wu_gong_pa30(file)
    lao_wu_gong_post_check(file)
