import logging
import os
import shutil
import time
from collections import defaultdict
from pathlib import Path

from openpyxl import load_workbook
from openpyxl.utils import get_column_letter
from rpa.fastrpa.adtable import BLUE, RED
from rpa.public.all_party_up import (clear_comments_backgrand, file_archive,
                                     updateDB)
from rpa.public.config import local_path, user_name
from rpa.public.tools import cel, cells
from rpa.public.validate_103 import add_color_comment
from rpa.ssc.hr.orm.orm import rpa_work_amount
from rpa.ssc.hr.orm.orm_ope import Query
from rpa.ssc.hr.orm.td_hr_gang_wei_diao_pei_rulebase import Event
from rpa.ssc_rpa.hr.rpa_bu_zai_gang.no_job_change import (export_three_tables,
                                                          gen_work_experience,
                                                          org_distribution,
                                                          yd_zn_batch_import)


def employee_absences(filename):
    # work_dir = get_work_path(filename, ctype='离岗')
    file = Path(local_path).joinpath(Path(filename).name).as_posix()
    if os.path.exists(file):
        os.remove(file)
    fname = Path(local_path).joinpath('103.xlsx')
    if fname.exists():
        os.remove(fname.as_posix())
    shutil.copyfile(filename, file)
    # config(f'{os.path.splitext(fname)[0]}.log')  # 不能在事件里调用，否则会覆盖RPA启动器的日志配置
    # sr, code, comment, worker = fname.split('-') if len(fname.split('-')) == 4 else ('', '', '', '')
    # if len(sr) != 10 or len(code) != 4 or '离岗' not in comment or len(worker[:-5]) < 2:
    #     logging.warning(f'{fname} 文件命名不规范，请重新命名（例：1000023001-X112-离岗-王XX.xlsx）')
    #     return
    result = absences_pre_check(file)
    if result:
        logging.warning(f'数据校验未通过，请检查模板文件【 {file} 】')
        logging.warning(f'校验结果：({result})')
        return
    per_nos = absences_execution_event(file)
    # # 20201222 Mengzhao添加：执行SAP修改后计入工作量汇总表
    # lt = load_from_xlsx_file(filename, skip_header=6)
    # staff_ids = lt['B'].values
    # rpa_work_amount(staff_ids)  # 将人员编号写入工作量表
    rpa_work_amount(list(per_nos))  # 将人员编号写入工作量表
    result = absences_check_result(file)
    if result:
        logging.info(f'事后校验未通过，请查看事后103文件{result}！')
        file_archive(file, is_succ=False, ctype='离岗')
        # uploadFtp(file, is_succ=False, ctype='离岗')
        return
    updateDB(file, len(per_nos), step='执行结束')
    file_archive(file, is_succ=True, ctype='离岗')
    # uploadFtp(file, is_succ=True, ctype='离岗')
    logging.info('离岗事件执行成功完成！')


def absences_pre_check(file):
    logging.info('正在进行事前表单检查~~~')
    clear_comments_backgrand(file, header=7)
    wb = load_workbook(file)
    ws = wb.active
    result_lst = []
    value_dict, dict_p = defaultdict(list), defaultdict(str)
    date, dir_name = cel(ws, "D7"), os.path.dirname(file)

    for i in range(7, len(ws["B"]) + 1):
        if ws[f"B{i}"].value and ws[f"F{i}"].value:
            if cel(ws, f"B{i}") in dict_p.keys():
                cells(ws, f'B{i}', "人员编号有重复", RED)
                result_lst.append(f'B{i}人员编号有重复')
            dict_p[cel(ws, f"B{i}").lstrip('0')] = cel(ws, f"F{i}").lstrip('0')
            value_dict[cel(ws, f"B{i}").lstrip('0')] = [cel(ws, f'{get_column_letter(x)}{i}').replace('None', '') for x
                                                        in range(2, 28)]
    wb.save(file)
    if not dict_p or not date:
        logging.warning("离岗事件模板中没有数据，请检查")
        return ["模板中无数据", ]
    if not value_dict:
        logging.warning("离岗事件模板中岗位编号未填写，请检查")
        return ["模板中无岗位编号", ]
    elif len(value_dict.keys()) != len(ws["B"]) - 6:
        logging.warning("离岗事件模板中人员编号有重复，请检查")
        return ["模板中人员编号重复", ]

    value_103, value_1071, value_1072 = export_three_tables(dict_p, date, dir_name)
    # # 生成工作经历模板数据  已调整使用模板批导
    # work_dict = defaultdict(set)
    # for k, v in value_dict.items():
    #     if v[4].lstrip('0') in value_1072:
    #         work_dict[k] = (v[1], value_1072[v[4].lstrip('0')][3], value_1072[v[4].lstrip('0')][4], v[2])
    # work_experience(work_dict, dir_name)
    rule_values = defaultdict(list)
    [rule_values[res.db_U.split()[1]].append(res.db_U.split()[0]) for res in Query(table=Event) if res.db_U]
    rule_J = [res.db_J for res in Query(table=Event) if res.db_J]  # 人员组
    rule_L = [res.db_L for res in Query(table=Event) if res.db_L]  # 人员子组
    rule_AG = [res.db_AG for res in Query(table=Event) if res.db_AG]  # 工资核算范围
    rule_F = [res.db_F for res in Query(table=Event) if res.db_F]  # 企业自定义分类1
    rule_G = [res.db_G.replace(" ", "") for res in Query(table=Event) if res.db_G]  # 企业自定义分类2
    rule_H = [res.db_H.replace(" ", "") for res in Query(table=Event) if res.db_H]  # 企业自定义分类3
    rule_BF = [res.db_BF for res in Query(table=Event) if res.db_BF]  # 离岗事件原因
    # rule_AZ = [res.db_AZ for res in Query(table=Event) if res.db_AZ]  # 人员标识

    for num, (key, value) in enumerate(list(value_dict.items())):

        ws[f"A{num + 7}"] = str(num + 1)
        if not key or key.lstrip('0') not in value_103.keys():
            cells(ws, f"A{num + 7}", "系统中无此人信息，请核查", RED)
            result_lst.append(f'A{num + 7}系统中无此人信息')
            continue

        if value[1] != value_103[key.lstrip('0')][5]:
            cells(ws, f"C{num + 7}", "人员编号和系统姓名不匹配，请核查", RED)
            result_lst.append(f'A{num + 7}人员编号和系统姓名不匹配')
            continue

        if value[9] and value[9] not in rule_F:
            cells(ws, f"K{num + 7}", "企业自定义分类1非码值", RED)
            result_lst.append(f'K{num + 7}企业自定义分类1非码值')

        if value[10] and value[10] not in rule_G:
            cells(ws, f"L{num + 7}", "企业自定义分类2非码值", RED)
            result_lst.append(f'L{num + 7}企业自定义分类2非码值')

        if value[19] and value[19].replace(" ", "") not in rule_H:
            cells(ws, f"U{num + 7}", "企业自定义分类3非码值", RED)
            result_lst.append(f'U{num + 7}企业自定义分类3非码值')

        current_date = time.strftime("%d", time.localtime(time.time()))
        current_month = time.strftime("%Y%m01", time.localtime(time.time()))
        next_month = time.strftime("%Y%m01",
                                   time.localtime(time.time() + (32 - int(current_date)) * 24 * 60 * 60))
        try:
            time.strptime(value[2], '%Y%m%d')
            if not value[2] or value[2] not in [current_month, next_month]:
                cells(ws, f"D{num + 7}", "事件日期需核对", RED)
                result_lst.append(f'D{num + 7}事件日期需核对')
            if num != 0 and ws[f"D{num + 6}"].value != value[2]:
                cells(ws, f"D{num + 7}", "事件日期需核对", RED)
                result_lst.append(f'D{num + 7}事件日期需核对')
        except:
            cells(ws, f"D{num + 7}", "事件日期需核对", RED)
            result_lst.append(f'D{num + 7}事件日期需核对')

        if not value[3] or value[3] not in rule_BF:
            cells(ws, f"E{num + 7}", "事件原因需核对", RED)
            result_lst.append(f'E{num + 7}事件原因需核对')

        if not value[4]:
            cells(ws, f"F{num + 7}", "岗位编号不能为空", RED)
            result_lst.append(f'F{num + 7}岗位编号不能为空')

        if value_103[key][1][:2] != "在岗":
            cells(ws, f"B{num + 7}", "现岗位状态为非在岗，请检查", RED)
            result_lst.append(f'B{num + 7}人员非在岗')

        if value_1072[value[4].lstrip('0')][0] and value[25] not in value_1072[value[4].lstrip('0')][0]:
            cells(ws, f"AA{num + 7}", "人事范围发生变化，请核对", RED)
            result_lst.append(f'AA{num + 7}人事范围发生变化')

        if not value[5] or (value[24] and value[5][:4] != value[24][:4]):
            cells(ws, f"G{num + 7}", "人事子范围发生变化，请核对", RED)
            result_lst.append(f'G{num + 7}人事子范围发生变化')

        if not value[6] or value_103[key][2] != value[6][:1] or value[6] not in rule_J:
            cells(ws, f"H{num + 7}", "请检查人员组信息", RED)
            result_lst.append(f'H{num + 7}人员组有误')

        # 人员子组一般为22其他不在岗人员（部分企业外派、退二线领导干部执行离岗，人员子组仍为中基层领导干部）
        if (value[7][:2] not in ['22', '23'] and ('派外' not in value[3] or value[7][:2] not in ['12', '13'])) or value[
                7] not in rule_L:
            cells(ws, f"I{num + 7}", "请检查人员子组", RED)
            result_lst.append(f'I{num + 7}人员子组有误')
        if '22' in value[7] and ('派外' in value[3] or value[7][:2] in ['12', '13']):
            cells(ws, f"I{num + 7}", "人员子组需核对", BLUE)
            # result_lst.append(f'I{num + 7}人员子组需核对')

        if not value[8] or value[8] not in rule_AG:
            cells(ws, f"J{num + 7}", "码表库中没有该工资核算范围，请检查", RED)
            result_lst.append(f'J{num + 7}工资范围有误')

        if value_103[key.lstrip('0')][0].replace('.', '') >= current_month:
            cells(ws, f"A{num + 7}", "请注意该人员该月已做过事件", RED)
            result_lst.append(f'A{num + 7}人员本月已做过事件')

        if value[11] and value[11] != 'X 是':
            cells(ws, f"M{num + 7}", "企业统计标识非码值（如为否请删除保留空白）", RED)
            result_lst.append(f'M{num + 7}非码值')
        # # 工作经历  todo 20201222简历调整暂时不处理
        # ws[f'N{num + 7}'] = value_1072[value[4].lstrip('0')][4]
        # ws[f'O{num + 7}'] = value_1072[value[4].lstrip('0')][3]

        if 'P' in value_1071[value[4].lstrip('0')][2] and '否' in value_1071[value[4].lstrip('0')][6]:
            if key != value_1071[value[4].lstrip('0')][5]:
                cells(ws, f"F{num + 7}", f"此岗位为实岗且已经分配有人员编号：{value_1071[value[4].lstrip('0')][5]}", RED)
                result_lst.append(f'F{num + 7}岗位下分配有人')
            else:
                cells(ws, f"F{num + 7}", f"确认是否实岗离岗（{value[3]}）", BLUE)

        if '否' in value_1071[value[4].lstrip('0')][6] and (value_1071[value[4].lstrip('0')][3] or not
                                                           value_1071[value[4].lstrip('0')][0] or not value_1071[value[4].lstrip('0')][1]):
            cells(ws, f"F{num + 7}", "此岗位分类信息有误，请检查", RED)
            result_lst.append(f'F{num + 7}此岗位分类信息有误')

        if not value_1072[value[4].lstrip('0')][0] or not value_1072[value[4].lstrip('0')][1]:
            cells(ws, f"Z{num + 7}", "此机构人事范围、人事子范围信息为空", BLUE)

        '''岗位上的成本中心编码46	职务（岗位）码47	备注48	海外岗位重要性类别49	海外岗位类别大类50	海外岗位类别51'''

    wb.save(file)
    wb.close()
    return result_lst


def absences_execution_event(d_file):
    wb = load_workbook(d_file, data_only=True)
    ws = wb.active
    values = [[str(x).replace("None", "") for x in value[:54]] for value in ws.values if value[6:]][6:]
    per_dict = {value[1].lstrip('0'): (value[11], value[20], value[9], '') for value in values}  # 自定义分类2、3
    date, code = values[0][3], os.path.basename(d_file).split('-')[1]
    wb.close()
    logging.info(f'数据校验通过，正在执行离岗事件......)')
    updateDB(d_file, len(per_dict), step='开始执行')
    if len(per_dict) > 0:
        logging.info('正在进行模板批导......')
        yd_zn_batch_import(d_file, xcode=code, e_type='ZN')  # 多信息模板批导处理
    else:
        logging.warning('执行模板数据为空，请检查！')
        return
    # 组织分配屏修改保存（自定义2、3和工资范围00修改总额范围）
    logging.info('正在进行组织分配屏信息修改......')
    org_distribution(per_dict, date=date)
    # batch_file = os.path.join(os.path.dirname(d_file), "工作经历模板.xlsx")
    # if os.path.exists(batch_file):
    #     batch_import(batch_file, "0023->HR_BI_0023", 1)
    # else:
    #     logging.warning(f'工作经历批导文件({batch_file})不存在,工作经历和简历未生成！')
    logging.info('正在生成简历......')
    gen_work_experience(list(per_dict.keys()), date, codes=[code])
    return per_dict.keys()


# def sap_mod(d_file):
#     logging.info('调整使用批导执行事件')
# for value in values:
#     logging.info(f"正在执行第{values.index(value) + 1}行数据...")
#     # per_dict.append(value[1])
#     string = ""
#     try:
#         session.findById("wnd[0]").maximize()
#         session.findById("wnd[0]/tbar[0]/okcd").text = "/n ZPA40_08"
#         session.findById("wnd[0]").sendVKey(0)
#         session.findById("wnd[0]/usr/ctxtRP50G-PERNR").text = value[1]
#         # session.findById("wnd[0]").sendVKey(0)
#         session.findById("wnd[0]/usr/ctxtRP50G-EINDA").text = value[3]
#         session.findById("wnd[0]/usr/tblSAPMP50ATC_MENU_EVENT").getAbsoluteRow(7).selected = -1
#         session.findById("wnd[0]/tbar[1]/btn[8]").press()
#         #  人事调配屏
#         session.findById("wnd[0]/usr/ctxtP0000-MASSG").text = value[4][:2]
#         session.findById("wnd[0]/usr/ctxtPSPAR-PLANS").text = value[5]
#         session.findById("wnd[0]/usr/ctxtPSPAR-PERSK").text = value[8][:2]
#         session.findById("wnd[0]").sendVKey(0)
#         string = click_enter(session, "人事调配")
#         if string:
#             logging.info(f'错误人员编号:{value[1]},错误原因: {string}')
#             ws[f"Q{values.index(value) + 7}"] = string
#             wb.save(d_file)
#             # upload_ftp(d_file, "失败")
#             logging.error(f'执行事件失败，请检查人事调配屏信息{string}')
#             return
#         session.findById("wnd[0]/tbar[0]/btn[11]").press()
#     except Exception:
#         string = string if string else session.findById("wnd[0]/sbar").text
#         ws[f"Q{values.index(value) + 7}"] = string
#         wb.save(d_file)
#         return
#
#     # 组织分配屏
#     if "组织分配及岗位聘任" not in session.findById("wnd[0]/titl").text:
#         ws[f"Q{values.index(value) + 7}"] = string
#         wb.save(d_file)
#         logging.error(f'{value[1]} 执行未成功，请检查模板数据。')
#         continue
#     try:
#         session.findById("wnd[0]/usr/ctxtP0001-BEGDA").text = value[3]
#         tmp = session.findById("wnd[0]/usr/ctxtP0001-BTRTL").text
#         if not tmp:
#             session.findById("wnd[0]/usr/ctxtP0001-BTRTL").text = value[6][:4]
#         session.findById("wnd[0]/usr/ctxtP0001-ABKRS").text = value[9][:2]
#         if value[10]:
#             session.findById("wnd[0]/usr/subSUBSCREEN_T582C:ZP000100:0200/ctxtP0001-ZZ_QYZDYYGFL").text = \
#                 value[10].split()[0]
#         if value[11]:
#             session.findById("wnd[0]/usr/subSUBSCREEN_T582C:ZP000100:0200/ctxtP0001-ZZ_QYZDYYGFL1").text = \
#                 value[11].split()[0]
#         if value[20]:
#             session.findById("wnd[0]/usr/subSUBSCREEN_T582C:ZP000100:0200/ctxtP0001-ZZ_QYZDYYGFL2").text = \
#                 value[20].split()[0]
#         if "是" in str(value[12]):
#             session.findById("wnd[0]/usr/subSUBSCREEN_T582C:ZP000100:0200/chkP0001-ZZ_QYTJBS1").selected = -1
#         session.findById("wnd[0]").sendVKey(0)
#         session.findById("wnd[0]/tbar[0]/btn[11]").press()
#         tmp = click_enter(session, "组织分配")
#         if tmp:
#             logging.info(f'错误人员编号:{value[1]},错误原因: {tmp}')
#             ws[f"Q{values.index(value) + 7}"] = tmp
#             wb.save(d_file)
#             #             upload_ftp(d_file, "失败")
#             logging.error(f'执行事件失败，请检查组织分配屏信息{tmp}')
#             return
#     except Exception:
#         string = string if string else session.findById("wnd[0]/sbar").text
#         ws[f"Q{values.index(value) + 7}"] = string
#         wb.save(d_file)
#         return
#
#     session.findById("wnd[0]/tbar[0]/btn[15]").press()
#     logging.error(f'{value[1]} 离岗事件执行成功。')
# wb.save(d_file)


def absences_check_result(d_file):
    dict_p, dict_mb = defaultdict(list), defaultdict(dict)
    logging.info(f'离岗事件执行完毕，正在执行事后校验...)')
    wb = load_workbook(d_file)
    ws = wb.active
    date, basedir = cel(ws, "D7"), os.path.dirname(d_file)
    lis = ["G", "H", "I", "K", "L", "U", "J", "M", "E", "W"]
    for i in range(7, len(ws["B"]) + 1):
        if ws[f"B{i}"].value and ws[f"F{i}"].value:
            dict_p[cel(ws, f"B{i}").lstrip('0')] = cel(ws, f'F{i}').lstrip('0')
            dict_mb[cel(ws, f"B{i}").lstrip("0")] = {y: cel(ws, f"{y}{i}").strip() for y in lis}
    wb.close()

    values_103, values_1071, values_1072 = export_three_tables(dict_p, date, basedir, type=1)

    wb_103 = load_workbook(os.path.join(basedir, "事后_103_校验结果.xlsx"))
    ws_103 = wb_103.active

    result, tmp = defaultdict(list), set(dict_mb.keys() - values_103.keys())
    if tmp:
        cells(ws_103, "A1", f"有人员事件执行未成功{tmp}，请注意检查", RED)

    for i in range(2, len(ws_103["A"]) + 1):
        i, per_code = str(i), cel(ws_103, f"A{i}").lstrip('0')
        # 1.事件是否执行成功
        if values_103[per_code][0].replace('.', '') != date or cel(ws_103, f"D{i}") != '9999.12.31' or \
                '离岗' not in cel(ws_103, f"G{i}") or dict_mb[per_code]['E'][:2] != cel(ws_103, f"H{i}"):
            add_color_comment(ws_103[f"F{i}"], RED, "请检查此人事件执行可能未成功！", result[per_code])

        if values_103[per_code][2] != dict_mb[per_code]['H'][:1]:
            add_color_comment(ws_103[f"S{i}"], RED, "请核对人员组！", result[per_code])

        if values_103[per_code][3] != dict_mb[per_code]['I'] or values_103[per_code][3][:2] != '22':
            add_color_comment(ws_103[f"T{i}"], RED, "请核对人员子组！", result[per_code])

        if values_103[per_code][4] != dict_mb[per_code]['J'][:2]:
            add_color_comment(ws_103[f"Z{i}"], RED, "请检查工资核算范围！", result[per_code])

        for k, v in {"L": "M", "BL": "BM"}.items():  # "AR": "AS", "CB": "CC", "BT": "BU",
            if ws_103[f"C{i}"].value != ws_103[f"{k}{i}"].value:
                add_color_comment(ws_103[f"{k}{i}"], RED, "请检查事件开始日期！", result[per_code])
            if ws_103[f"D{i}"].value != ws_103[f"{v}{i}"].value:
                add_color_comment(ws_103[f"{v}{i}"], RED, "请检查事件结束日期！", result[per_code])

        if ws_103[f"AP{i}"].value not in dict_mb[per_code]['M']:
            add_color_comment(ws_103[f"AP{i}"], BLUE, "请核对企业统计标识！", result[per_code])

        if values_1072[dict_p[per_code]][3] not in dict_mb[per_code]['W'] and \
                dict_mb[per_code]['W'] not in values_1072[dict_p[per_code]][3]:
            # add_color_comment(ws_103[f"X{i}"], RED, "请检查调动后岗位名称！", result[per_code])
            cells(ws_103, f"Y{i}", "请检查调动后岗位名称！", RED)

        if values_103[per_code][6] not in dict_mb[per_code]['G']:
            add_color_comment(ws_103[f"W{i}"], RED, "请检查调动后机构！", result[per_code])

        for k, (x, y) in {"K": ("AD", "AE"), "L": ("AF", "AG"), "U": ("AH", "AI")}.items():
            value = (str(ws_103[f"{x}{i}"].value) + str(ws_103[f"{y}{i}"].value)).replace(" ", "").replace("None", "")
            if per_code in dict_mb.keys() and value != dict_mb[per_code][k].replace(" ", "").replace("None", ""):
                add_color_comment(ws_103[f"{x}{i}"], RED, f'模板信息：{dict_mb[per_code][k]}', result[per_code])

        if ws_103[f"F{i}"].value != ws_103[f"BS{i}"].value or ws_103[f"BR{i}"].value != user_name()[0].upper():
            add_color_comment(ws_103[f"BS{i}"], RED, "请检查简历是否生成！", result[per_code])

        ab, z = ws_103[f"AB{i}"].value, ws_103[f'Z{i}'].value
        if (not ab and z != '00') or (z == '00' and ab):
            add_color_comment(ws_103[f"AB{i}"], RED, "请检查工资总额控制范围！", result[per_code])

        if dict_p[per_code] in values_1071.keys() and per_code in values_1071.keys() and '是' in \
                values_1071[dict_p[per_code]][6]:
            index, lis = list(values_1071.keys()).index(dict_p[per_code]), list(values_1071.values())
            if len(lis) >= index + 3 and lis[index + 1][-1] == lis[index + 2][-1] == "P":
                add_color_comment(ws_103[f"X{i}"], RED, "请检查存在一岗多人情况！", result[per_code])

    wb_103.save(Path(basedir).joinpath("事后_103_校验结果.xlsx").as_posix())
    logging.info('事后校验完成，结束事件！')
    return result
