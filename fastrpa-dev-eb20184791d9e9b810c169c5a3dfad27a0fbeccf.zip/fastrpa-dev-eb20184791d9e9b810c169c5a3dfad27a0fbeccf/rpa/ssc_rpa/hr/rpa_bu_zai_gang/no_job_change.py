import datetime
import logging
import os
import shutil
import time
from collections import defaultdict
from pathlib import Path
from threading import Thread

import pyperclip
from openpyxl import load_workbook
from openpyxl.utils import get_column_letter
from rpa.fastrpa.adtable import BLUE, RED, load_from_xlsx_file
from rpa.fastrpa.date_funcs import to_yyyymmdd
from rpa.fastrpa.sap.session import attach_sap
from rpa.public.all_party_up import (clear_comments_backgrand, file_archive,
                                     updateDB)
from rpa.public.config import local_path, remote_path, templates, user_name
from rpa.public.create_work_experience import download_work_experience_template
from rpa.public.myftp import MYFTP
from rpa.public.run_sap import close_sap
from rpa.public.tools import cel, cells, find_window
from rpa.public.validate_103 import add_color_comment
from rpa.ssc.hr.orm.orm import rpa_work_amount
from rpa.ssc.hr.orm.orm_ope import Query
from rpa.ssc.hr.orm.td_hr_gang_wei_diao_pei_rulebase import Event
from rpa.ssc.hr.rpa_dir import get_rpa_dir
from rpa.ssc.hr.sap.export_103 import export_103
from rpa.ssc.hr.sap.export_1071 import export_1071
from rpa.ssc.hr.sap.export_1072 import export_1072
from rpa.ssc.hr.sap.refresh_user_data import refresh_user_data


def no_job_change(filename):
    # work_dir = get_work_path(filename, ctype='不在岗变动')
    file = Path(local_path).joinpath(Path(filename).name).as_posix()
    if Path(file).exists():
        os.remove(file)
    if Path(local_path).joinpath('103.xlsx').exists():
        os.remove(f'{local_path}/103.xlsx')
    shutil.copyfile(filename, file)
    # config(f'{os.path.splitext(fname)[0]}.log')
    result = pre_check(file)
    if result:
        logging.warning(f'数据校验未通过，请检查模板文件【 {file} 】')
        logging.info(f'校验结果：({result})')
        return
    logging.info('数据校验通过，可以执行不在岗变动事件！')
    per_no = execution_event(file)
    if not per_no:
        logging.info('事件执行失败，请查看模板文件中错误提示！')
        file_archive(file, is_succ=False, ctype='不在岗变动')
        # uploadFtp(file, is_succ=False, ctype='不在岗变动')
        return
    # # 20201222 Mengzhao添加：执行SAP修改后计入工作量汇总表
    # lt = load_from_xlsx_file(filename, skip_header=6)
    # staff_ids = lt['B'].values
    # rpa_work_amount(staff_ids) # 将人员编号写入工作量表
    rpa_work_amount(list(per_no))  # 将人员编号写入工作量表
    flag, result = check_result(file)
    if flag:
        logging.warning('有事件执行未成功人员，请查看103校验结果文件！')
        file_archive(file, is_succ=False, ctype='不在岗变动')
        # uploadFtp(file, is_succ=False, ctype='不在岗变动')
        return
    if result:
        logging.info(f'事后校验有需要核对信息{result}，请查看103文件中事后校验结果！')
    updateDB(file, len(per_no), step='执行结束')
    if not organize_file(file):
        logging.warning('导出文件整理合并失败！')
    file_archive(file, is_succ=True, ctype='不在岗变动')
    # uploadFtp(file, is_succ=True, ctype='不在岗变动')

    logging.info('不在岗变动事件执行成功完成！')


def pre_check(file):
    clear_comments_backgrand(file, header=7)
    lt = load_from_xlsx_file(file, skip_header=6, data_only=False)
    lt.del_blank_rows_by_column("B")
    lt.save(file)
    wb = load_workbook(file)
    ws = wb.active
    result_lst = []
    value_dict, dict_p = defaultdict(list), defaultdict(str)
    date, dir_name = cel(ws, "D7"), os.path.dirname(file)

    for i in range(7, len(ws["B"]) + 1):
        if ws[f"B{i}"].value and ws[f"F{i}"].value:
            if cel(ws, f"B{i}") in dict_p.keys():
                cells(ws, f'B{i}', "人员编号有重复", RED)
                result_lst.append(f'B{i}人员编号有重复')
            dict_p[cel(ws, f"B{i}").lstrip('0')] = cel(ws, f"F{i}").lstrip('0')
            value_dict[cel(ws, f"B{i}").lstrip('0')] = [cel(ws, f'{get_column_letter(x)}{i}') for x in range(2, 54)]
    wb.save(file)
    if not dict_p or not date or len(value_dict.keys()) != len(ws["B"]) - 6:
        logging.warning("不在岗变动模板中没有数据或人员编号有重复，请检查")
        result_lst.append('不在岗变动模板中没有数据或人员编号有重复')
        return result_lst

    value_103, value_1071, value_1072 = export_three_tables(dict_p, date, dir_name)

    rule_values = defaultdict(list)
    [rule_values[res.db_U.split()[1]].append(res.db_U.split()[0]) for res in Query(table=Event) if res.db_U]
    rule_J = [res.db_J for res in Query(table=Event) if res.db_J]  # 人员组
    rule_L = [res.db_L for res in Query(table=Event) if res.db_L]  # 人员子组
    rule_AG = [res.db_AG for res in Query(table=Event) if res.db_AG]  # 工资核算范围
    rule_F = [res.db_F for res in Query(table=Event) if res.db_F]  # 企业自定义分类1
    rule_G = [res.db_G.replace(" ", "") for res in Query(table=Event) if res.db_G]  # 企业自定义分类2
    rule_H = [res.db_H.replace(" ", "") for res in Query(table=Event) if res.db_H]  # 企业自定义分类3
    rule_BH = [res.db_BH for res in Query(table=Event) if res.db_BH]  # 不在岗事件原因
    # rule_AZ = [res.db_AZ for res in Query(table=Event) if res.db_AZ]  # 人员标识

    for num, (key, value) in enumerate(list(value_dict.items())):

        ws[f"A{num + 7}"] = str(num + 1)
        if not key or key not in value_103.keys():
            cells(ws, f"A{num + 7}", "系统中无此人信息，请核查", RED)
            result_lst.append(f'A{num + 7}系统中无此人信息')
            continue

        if value[1] != value_103[key][5]:
            cells(ws, f"C{num + 7}", "人员编号和系统姓名不匹配，请核查", RED)
            result_lst.append(f'A{num + 7}人员编号和系统姓名不匹配')
            continue
        for n, col in {4: 'AG', 3: 'AH'}.items():
            if not value_1072[value[4].lstrip('0')][n]:
                cells(ws, f"{col}{num + 7}", "107中无此岗位信息，请核查", RED)
            else:  # todo 20201222简历调整暂不处理
                ws[f'{col}{num + 7}'] = value_1072[value[4].lstrip('0')][n]

        if value[11] not in ["None", None, ''] and value[11] not in rule_F:
            cells(ws, f"M{num + 7}", "企业自定义分类1非码值", RED)
            result_lst.append(f'M{num + 7}企业自定义分类1非码值')

        if value[38] not in ["None", None, ''] and value[38] not in rule_G:
            cells(ws, f"AN{num + 7}", "企业自定义分类2非码值", RED)
            result_lst.append(f'AN{num + 7}企业自定义分类2非码值')

        if value[39] not in ["None", None, ''] and value[39].replace(" ", "") not in rule_H:
            cells(ws, f"AO{num + 7}", "企业自定义分类3非码值", RED)
            result_lst.append(f'AO{num + 7}企业自定义分类3非码值')

        current_date = time.strftime("%d", time.localtime())
        current_month = time.strftime("%Y%m01", time.localtime())
        next_month = time.strftime("%Y%m01",
                                   time.localtime(time.time() + (32 - int(current_date)) * 24 * 60 * 60))
        try:
            time.strptime(value[2], '%Y%m%d')
            if not value[2] or value[2] not in [current_month, next_month]:
                cells(ws, f"D{num + 7}", "事件日期需核对", RED)
                result_lst.append(f'D{num + 7}事件日期需核对')
            if num != 0 and ws[f"D{num + 6}"].value != value[2]:
                cells(ws, f"D{num + 7}", "事件日期需核对", RED)
                result_lst.append(f'D{num + 7}事件日期需核对')
        except:
            cells(ws, f"D{num + 7}", "事件日期需核对", RED)
            result_lst.append(f'D{num + 7}事件日期需核对')

        if not value[3] or value[3] not in rule_BH:
            cells(ws, f"E{num + 7}", "事件原因需核对", RED)
            result_lst.append(f'E{num + 7}事件原因需核对')

        if not value[4] or value[4] in ['None', None]:
            cells(ws, f"F{num + 7}", "岗位编号不能为空", RED)
            result_lst.append(f'F{num + 7}岗位编号不能为空')

        if "在岗" == value_103[key][1][:2]:
            cells(ws, f"B{num + 7}", "岗位状态为在岗，请检查人员岗位状态", RED)
            result_lst.append(f'B{num + 7}人员在岗')

        if not value[5] or value[5][:4] != value[44][:4]:
            cells(ws, f"G{num + 7}", "人事范围发生变化，请核对", RED)
            result_lst.append(f'G{num + 7}人事范围发生变化')

        if not value[6] or (value[45] and value[6] != value[45]):
            cells(ws, f"H{num + 7}", "人事子范围发生变化，请核对", RED)
            result_lst.append(f'H{num + 7}人事子范围发生变化')

        if not value[7] or (value_103[key][2] != value[7] and value[7] not in rule_J):
            cells(ws, f"I{num + 7}", "请检查人员组信息", RED)
            result_lst.append(f'I{num + 7}人员组有误')
        # 20210512 组长会议讨论增加功能
        if (value[7][:1] == 'K' or value[8][:1] == '21') and value[3][:2] != '17':
            cells(ws, f"E{num + 7}", "内退退休人员事件原因只能为17管理单位发生变化！", RED)
            result_lst.append(f'E{num + 7}内退退休人员事件原因有误')

        if not value[8] or (
                value_103[key][3] not in rule_L and value[8] not in rule_L[5:7] + rule_L[16:19]):
            cells(ws, f"J{num + 7}", "人员子组需核对", RED)
            result_lst.append(f'J{num + 7}人事子组有误')

        if not value[9] or value[9] not in rule_AG:
            cells(ws, f"K{num + 7}", "码表库中没有该工资核算范围，请检查", RED)
            result_lst.append(f'K{num + 7}工资范围有误')

        if value_103[key][0].replace('.', '') >= current_month:
            cells(ws, f"A{num + 7}", "请注意该人员该月已做过事件", RED)
            result_lst.append(f'A{num + 7}人员本月已做过事件')

        if value[10] and value[10][:2] not in ['01', '02']:
            cells(ws, f"L{num + 7}", "工作合同非码值", RED)
            result_lst.append(f'L{num + 7}工作合同非码值')

        if 'P' in value_1071[value[4].lstrip('0')][2] and '否' in value_1071[value[4].lstrip('0')][6]:
            cells(ws, f"F{num + 7}", f"此岗位下已经分配有人,人员编号：{value_1071[value[4].lstrip('0')][5]}", RED)
            result_lst.append(f'F{num + 7}岗位下分配有人')

        if '否' in value_1071[value[4].lstrip('0')][6] and (value_1071[value[4].lstrip('0')][3] or
                                                           not value_1071[value[4].lstrip('0')][0] or not
                                                           value_1071[value[4].lstrip('0')][1]):
            cells(ws, f"F{num + 7}", "此岗位分类信息有误，请检查", RED)
            result_lst.append(f'F{num + 7}此岗位分类信息有误')

        if not value_1072[0] or not value_1072[2]:
            cells(ws, f"AP{num + 7}", "此机构人事范围、人事子范围信息为空", BLUE)

        if value[12]:
            if '是' in value[12] or 'X' in value[12]:
                ws[f'N{num + 7}'] = 'X'
            elif '否' in value[12]:
                ws[f'N{num + 7}'] = ''
            else:
                cells(ws, f"N{num + 7}", "请核对企业统计标识！", RED)

        '''岗位上的成本中心编码46	职务（岗位）码47	备注48	海外岗位重要性类别49	海外岗位类别大类50	海外岗位类别51'''

    wb.save(file)
    wb.close()
    return result_lst


def execution_event(d_file):
    if not d_file and len(os.path.basename(d_file).split('-')) != 4:
        logging.warning('文件不存在或命名不符合要求【例：1001621188-X123-离岗-王某某.xlsx】，请修改后重新执行！')
        return
    wb = load_workbook(d_file, data_only=True)
    ws = wb.active
    values = [[str(x).replace("None", "") for x in value[:54]] for value in ws.values if value[6:]][6:]
    per_dict = {value[1].lstrip('0'): (value[39], value[40], value[10], '') for value in values}  # 自定义分类2、3
    date, code = values[0][3], list(set([v[6][:4] for v in values]))
    wb.close()
    updateDB(d_file, len(per_dict), step='开始执行')
    if len(per_dict) > 0:
        yd_zn_batch_import(d_file, xcode=code, e_type='YD')  # 多信息模板批导处理
    else:
        logging.warning('执行模板数据为空，请检查！')
        return

        # for value in values:
        #     logging.info(f"正在执行第{values.index(value) + 1}行数据...")
        #     string = ""
        #     try:
        #         session.findById("wnd[0]").maximize()
        #         session.findById("wnd[0]/tbar[0]/okcd").text = "/n ZPA40_13"
        #         session.findById("wnd[0]").sendVKey(0)
        #         session.findById("wnd[0]/usr/ctxtRP50G-PERNR").text = value[1]
        #         session.findById("wnd[0]").sendVKey(0)
        #         session.findById("wnd[0]/usr/ctxtRP50G-EINDA").text = value[3]
        #         session.findById("wnd[0]/usr/tblSAPMP50ATC_MENU_EVENT").getAbsoluteRow(2).selected = -1
        #         session.findById("wnd[0]/tbar[1]/btn[8]").press()
        #         #  人事调配屏
        #         session.findById("wnd[0]/usr/ctxtP0000-MASSG").text = value[4][:2]
        #         session.findById("wnd[0]/usr/ctxtPSPAR-PLANS").text = value[5]
        #         if value[6]: session.findById("wnd[0]/usr/ctxtPSPAR-WERKS").text = value[6]
        #         if value[8]: session.findById("wnd[0]/usr/ctxtPSPAR-PERSG").text = value[8][:1]
        #         session.findById("wnd[0]/usr/ctxtPSPAR-PERSK").text = value[9][:2]
        #         session.findById("wnd[0]").sendVKey(0)
        #         # session.findById("wnd[0]/tbar[0]/btn[11]").press()
        #         string = click_enter(session, "人事调配")
        #         if string:
        #             logging.info(f'错误人员编号:{value[1]},错误原因: {string}')
        #             ws[f"AJ{values.index(value) + 7}"] = string
        #             wb.save(d_file)
        #             # upload_ftp(d_file, "失败")
        #             logging.error(f'执行事件失败，请检查人事调配屏信息{string}')
        #             return
        #     except Exception:
        #         string = string if string else session.findById("wnd[0]/sbar").text
        #         ws[f"AJ{values.index(value) + 7}"] = string
        #         wb.save(d_file)
        #         return
        #
        #     # 组织分配屏
        #     if "组织分配及岗位聘任" not in session.findById("wnd[0]/titl").text:
        #         logging.error(f'{value[1]} 执行未成功，请检查模板数据。')
        #         continue
        #     try:
        #         tmp = session.findById("wnd[0]/usr/ctxtP0001-BTRTL").text
        #         if not tmp: session.findById("wnd[0]/usr/ctxtP0001-BTRTL").text = value[7][:4]
        #         session.findById("wnd[0]/usr/ctxtP0001-ABKRS").text = value[10][:2]
        #         if value[11]: session.findById("wnd[0]/usr/cmbP0001-ANSVH").key = value[11][:2]
        #         session.findById("wnd[0]/usr/ctxtP0001-BEGDA").text = value[3]
        #         if value[12]:
        #             session.findById("wnd[0]/usr/subSUBSCREEN_T582C:ZP000100:0200/ctxtP0001-ZZ_QYZDYYGFL").text = \
        #                 value[12].split()[0]
        #         if value[38]:
        #             session.findById("wnd[0]/usr/subSUBSCREEN_T582C:ZP000100:0200/ctxtP0001-ZZ_QYZDYYGFL1").text = \
        #                 value[38].split()[0]
        #         if value[39]:
        #             session.findById("wnd[0]/usr/subSUBSCREEN_T582C:ZP000100:0200/ctxtP0001-ZZ_QYZDYYGFL2").text = \
        #                 value[39].split()[0]
        #         if "是" in str(value[13]):
        #             session.findById("wnd[0]/usr/subSUBSCREEN_T582C:ZP000100:0200/chkP0001-ZZ_QYTJBS1").selected = -1
        #         session.findById("wnd[0]").sendVKey(0)
        #         session.findById("wnd[0]/tbar[0]/btn[11]").press()
        #         tmp = click_enter(session, "组织分配")
        #         if tmp:
        #             logging.info(f'错误人员编号:{value[1]},错误原因: {tmp}')
        #             ws[f"AJ{values.index(value) + 7}"] = tmp
        #             wb.save(d_file)
        #             #             upload_ftp(d_file, "失败")
        #             logging.error(f'执行事件失败，请检查组织分配屏信息{tmp}')
        #             return
        #     except Exception:
        #         string = string if string else session.findById("wnd[0]/sbar").text
        #         ws[f"AJ{values.index(value) + 7}"] = string
        #         wb.save(d_file)
        #         return
        #
        #     # 岗位聘任补充信息屏
        #     if "岗位聘任补充信息" not in session.findById("wnd[0]/titl").text:
        #         logging.error(f'{value[1]} 执行未成功，请检查模板数据。')
        #         continue
        #     try:
        #         tmp = to_yyyymmdd(session.findById("wnd[0]/usr/ctxtP9209-BEGDA").text)
        #         if tmp != value[3]:
        #             session.findById("wnd[0]/usr/ctxtP9209-BEGDA").text = value[3]
        #         session.findById("wnd[0]/tbar[0]/btn[11]").press()
        #     except:
        #         logging.error(f'{value[1]} 执行未成功，请检查模板数据。')
        #         return
        #     # 叉掉工作经历屏
        #     session.findById("wnd[0]/tbar[0]/btn[12]").press()
        #     logging.info(f'{value[1]} 执行成功。')
        #
        # wb.save(d_file)
    # 组织分配屏修改保存（自定义2、3和工资范围00修改总额范围）
    org_distribution(per_dict, date=date)
    # 生成简历
    codes = list(set([v[6][:4] for v in values]))
    gen_work_experience(per_dict.keys(), date, codes)
    return per_dict.keys()


def yd_zn_batch_import(file, xcode, e_type="YD"):
    file = file.replace('/', '\\')
    # session = attach_sap()
    session = attach_sap('login_tx')  # 个人账号登录
    refresh_user_data(session)
    logging.info(f'正在批导{"不在岗变动" if e_type == "YD" else "离岗"}事件数据模板......')
    for i in range(5):
        session.findById("wnd[0]/tbar[0]/okcd").text = "/n zhrbi0013"
        session.findById("wnd[0]").sendVKey(0)
        session.findById("wnd[0]/usr/radRB_M").select()
        session.findById(f"wnd[0]/usr/radRB_M_{e_type}").select()
        session.findById("wnd[0]/tbar[1]/btn[8]").press()
        if e_type == 'ZN':
            session.findById("wnd[0]/usr/ctxtP_WERKS").text = xcode
        session.findById("wnd[0]/usr/radRB_UP").select()
        # fix_excel(file)
        t = Thread(target=find_window, args=(file, '#32770', u'选择上传文件'), daemon=True)
        # t.setDaemon(True)
        t.start()
        session.findById("wnd[0]/tbar[1]/btn[8]").press()
        if "上载的模板中没有数据或数据错误" in session.findById("wnd[0]/sbar/pane[0]").text:
            continue
        try:
            result = session.findById("wnd[1]/usr/txtSPOP-TEXTLINE2").text
            session.findById("wnd[1]/usr/btnSPOP-OPTION1").press()
            break
        except Exception as e:
            result = f'{session.findById("wnd[0]/sbar/pane[0]").text}\n\n\n{e}'
        if "成功" in result and '失败' in result:
            session.findById("wnd[0]/tbar[0]/okcd").text = "/n"
            session.findById("wnd[0]").sendVKey(0)
            break
    else:
        with MYFTP() as my_ftp:
            hhmmss = datetime.datetime.now().strftime(r'%H%M%S')  # 上传的目录前面加时分秒前缀，避免同一天一个单子，第二次做覆盖上一次的文件
            remote = remote_path + f"失败/{hhmmss}_" + file.split('\\')[-1].split(".")[0] + "/"
            my_ftp.upload_file(file, remote + file.split('\\')[-1].split(".")[0] + "_模板错误.xlsx")
        session.findById("wnd[0]/tbar[0]/okcd").text = "/n"
        session.findById("wnd[0]").sendVKey(0)
        logging.error('zhrbi0013批导模板表批导失败, 程序结束运行')
        raise Exception('上载的模板中没有数据或数据批导失败，结束运行')


def org_distribution(per_dict, date):
    # session = attach_sap()
    session = attach_sap('login_tx')  # 个人账号登录
    refresh_user_data(session)
    logging.info("正在修改组织分配屏信息（自定义分类2、3和工资总额范围）...")
    text = '\r\n'.join(per_dict.keys())
    session.findById("wnd[0]/tbar[0]/okcd").text = "/n PA30"
    session.findById("wnd[0]").sendVKey(0)
    temp = "wnd[0]/shellcont/shell/shellcont[0]/shell/shellcont[1]/shell[1]"
    session.findById(temp).clickLink("          2", "&Hierarchy")
    for i in range(1, 20):
        try:
            if "IC 号码" in session.findById(f"wnd[1]/usr/tabsG_SELONETABSTRIP/tabpTAB00{i}").text:
                idx = i
                break
        except Exception:
            raise Exception("修改组织分配屏为找到  IC 号码  的标签")
    session.findById(f"wnd[1]/usr/tabsG_SELONETABSTRIP/tabpTAB00{idx}").select()
    pyperclip.copy(text)
    session.findById(
        "wnd[1]/usr/tabsG_SELONETABSTRIP/tabpTAB003/ssubSUBSCR_PRESEL:SAPLSDH4:0220/sub:SAPLSDH4:0220/btnG_SELFLD_TAB-MORE[4,56]").press()
    session.findById("wnd[2]/tbar[0]/btn[16]").press()
    session.findById("wnd[2]/tbar[0]/btn[24]").press()
    session.findById("wnd[2]/tbar[0]/btn[8]").press()
    session.findById("wnd[1]/tbar[0]/btn[0]").press()
    session.findById("wnd[0]/usr/tabsMENU_TABSTRIP/tabpTAB03").select()
    session.findById(
        "wnd[0]/usr/tabsMENU_TABSTRIP/tabpTAB03/ssubSUBSCR_MENU:SAPMP50A:0400/subSUBSCR_ITMENU:SAPMP50A:0310/tblSAPMP50ATC_MENU").getAbsoluteRow(
        0).selected = -1
    tmpid = session.findById("wnd[0]/shellcont/shell/shellcont[1]/shell")
    for x in range(tmpid.RowCount):
        if x % 30 == 0:
            tmpid.firstVisibleRow = x
        session.findById("wnd[0]/shellcont/shell/shellcont[1]/shell").setCurrentCell(int(x), "ADD_FIELD2")
        session.findById("wnd[0]/shellcont/shell/shellcont[1]/shell").selectedRows = str(x)
        session.findById("wnd[0]/shellcont/shell/shellcont[1]/shell").doubleClickCurrentCell()

        try:  # 取消数据保存
            session.findById("wnd[1]/usr/btnSPOP-OPTION1").press()
        except Exception:
            pass
        if "维护人力资源主数据" in session.findById("wnd[0]/titl").text:
            session.findById("wnd[0]/tbar[1]/btn[6]").press()
        perno = session.findById(
            "wnd[0]/usr/subSUBSCREEN_HEADER:/1PAPAXX/HDR_80003A:0100/txt$_DG01_800A03_DAT_P0000_PERNR").text
        for i in range(3):
            tmp = to_yyyymmdd(session.findById("wnd[0]/usr/ctxtP0001-BEGDA").text)
            if tmp != date:
                session.findById("wnd[0]/tbar[1]/btn[19]").press()
                continue
            if per_dict[perno][0]:  # 自定义分类2
                sapid = session.findById("wnd[0]/usr/subSUBSCREEN_T582C:ZP000100:0200/ctxtP0001-ZZ_QYZDYYGFL1")
                sapid.text = per_dict[perno][0][:4]
            if per_dict[perno][1]:  # 自定义分类3
                sapid = session.findById("wnd[0]/usr/subSUBSCREEN_T582C:ZP000100:0200/ctxtP0001-ZZ_QYZDYYGFL2")
                sapid.text = per_dict[perno][1][:4]
            if session.findById("wnd[0]/usr/ctxtP0001-ABKRS").text == '00':
                session.findById("wnd[0]").sendVKey(0)
                if session.findById("wnd[0]/usr/subSUBSCREEN_T582C:ZP000100:0200/ctxtP0001-ZZ_ZEFW").Changeable:
                    session.findById("wnd[0]/usr/subSUBSCREEN_T582C:ZP000100:0200/ctxtP0001-ZZ_ZEFW").text = ''
                session.findById("wnd[0]").sendVKey(0)
            elif per_dict[perno][3][:2]:
                # if session.findById("wnd[0]/usr/subSUBSCREEN_T582C:ZP000100:0200/ctxtP0001-ZZ_ZEFW").Changeable:
                #     session.findById("wnd[0]/usr/subSUBSCREEN_T582C:ZP000100:0200/ctxtP0001-ZZ_ZEFW").text = \
                #         per_dict[perno][3][:2]
                #     session.findById("wnd[0]").sendVKey(0)
                #     msg = session.findById("wnd[0]/sbar/pane[0]").text
                #     if '请保存你的输入' not in msg:
                #         logging.warning(f'工资总额控制范围修改未成功，提示信息：{msg}')
                #         session.findById("wnd[0]/usr/subSUBSCREEN_T582C:ZP000100:0200/ctxtP0001-ZZ_ZEFW").text = ''
                #         session.findById("wnd[0]").sendVKey(0)
                try:
                    session.findById("wnd[0]/usr/subSUBSCREEN_T582C:ZP000100:0200/ctxtP0001-ZZ_ZEFW").text = \
                        per_dict[perno][3][:2]
                    session.findById("wnd[0]").sendVKey(0)
                except:
                    logging.warning(f'工资总额控制范围修改未成功，提示信息：{session.findById("wnd[0]/sbar/pane[0]").text}')
                    session.findById("wnd[0]").sendVKey(0)
            else:
                session.findById("wnd[0]").sendVKey(0)
            session.findById("wnd[0]").sendVKey(0)
            try:
                session.findById("wnd[0]/tbar[0]/btn[11]").press()
                if '记录已更改' not in session.findById("wnd[0]/sbar/pane[0]").text:
                    logging.error(f'{perno}:未保存成功,错误提示：{session.findById("wnd[0]/sbar/pane[0]").text}')
            except Exception as e:
                logging.error(f'{session.findById("wnd[0]/sbar/pane[0]").text}, {e}')
            break

    session.findById("wnd[0]/tbar[0]/okcd").text = "/nex"
    session.findById("wnd[0]").sendVKey(0)


def gen_work_experience(per_nos, date, codes):
    if not per_nos and not codes:
        logging.error("人员编号和人事范围不正确！")
        return False
    download_work_experience_template(per_nos, date, codes)
    # # session = attach_sap()
    # session = attach_sap('login_tx')  # 个人账号登录
    # # refresh_user_date(session)
    # try:
    #     session.findById("wnd[0]/tbar[0]/okcd").text = "/n zhrpa175"
    #     session.findById("wnd[0]").sendVKey(0)
    #     session.findById("wnd[0]/usr/ctxtPNPWERKS-LOW").text = code
    #     session.findById("wnd[0]/usr/btn%_PNPPERNR_%_APP_%-VALU_PUSH").press()
    #     session.findById("wnd[1]/tbar[0]/btn[16]").press()
    #     text = '\r\n'.join(per_nos)
    #     pyperclip.copy(text)
    #     session.findById("wnd[1]/tbar[0]/btn[24]").press()
    #     session.findById("wnd[1]/tbar[0]/btn[8]").press()
    #     session.findById("wnd[0]/tbar[1]/btn[8]").press()
    #     session.findById("wnd[0]/tbar[1]/btn[14]").press()
    #     session.findById("wnd[0]/tbar[1]/btn[23]").press()
    # except Exception as e:
    #     logging.error(f"{code}下人员生成简历失败！错误提示：{e}")
    #     return False
    # finally:
    #     session.findById("wnd[0]/tbar[0]/okcd").text = "/n"
    #     session.findById("wnd[0]").sendVKey(0)
    return True


def check_result(d_file):
    logging.info(f'事件执行完毕，正在执行事后校验...')
    wb = load_workbook(d_file)
    ws = wb.active
    dict_p, dict_mb, flag = defaultdict(list), defaultdict(dict), False
    date, basedir = cel(ws, "D7"), os.path.dirname(d_file)
    result_file = os.path.join(basedir, "事后_103_校验结果.xlsx")
    tmp = ["D", "G", "I", "J", "K", "M", "N", "AN", "AO", "AQ", "AP"]
    for i in range(7, len(ws["B"]) + 1):
        if cel(ws, f"B{i}") and cel(ws, f"F{i}"):
            dict_p[cel(ws, f"B{i}").lstrip('0')] = cel(ws, f"F{i}").lstrip('0')
        dict_mb[cel(ws, f"B{i}").lstrip("0")] = {y: cel(ws, f"{y}{i}") for y in tmp}
    wb.close()

    values_103, values_1071, values_1072 = export_three_tables(dict_p, date, basedir, type=1)
    # sr = os.path.basename(file)[:10] if os.path.basename(file)[:10].isdigit() else None
    clear_comments_backgrand(result_file, header=2)
    wb_103 = load_workbook(result_file)
    ws_103 = wb_103.active

    result, tmp = defaultdict(list), set(dict_mb.keys() - values_103.keys())
    if tmp:
        cells(ws_103, "A1", f"有人员事件执行未成功{tmp}，请注意检查", RED)
    for i in range(2, len(ws_103["A"]) + 1):
        per_code = cel(ws_103, f"A{i}").lstrip('0')
        event_date = dict_mb[per_code]['D']
        # 1.事件是否执行成功
        if values_103[per_code][0].replace('.', '') != event_date or cel(ws_103, f"D{i}") != '9999.12.31' or \
                not cel(ws_103, f"H{i}") or not cel(ws_103, f"G{i}"):
            add_color_comment(ws_103[f"A{i}"], RED, "事件执行未成功！", result[per_code])
            flag = True

        if values_103[per_code][2] not in dict_mb[per_code]['I']:
            add_color_comment(ws_103[f"S{i}"], RED, "请核对人员组！", result[per_code])

        if values_103[per_code][3] not in dict_mb[per_code]['J']:
            add_color_comment(ws_103[f"T{i}"], RED, "请核对人员子组！", result[per_code])

        if values_103[per_code][4] != dict_mb[per_code]['K'][:2]:
            add_color_comment(ws_103[f"Z{i}"], RED, "请检查工资核算范围！", result[per_code])

        for k, v in {"L": "M", "AR": "AS", "BL": "BM"}.items():
            if ws_103[f"C{i}"].value != ws_103[f"{k}{i}"].value != event_date:
                add_color_comment(ws_103[f"{k}{i}"], RED, "请检查事件开始日期！", result[per_code])
            if ws_103[f"D{i}"].value != ws_103[f"{v}{i}"].value != '9999.12.31':
                add_color_comment(ws_103[f"{v}{i}"], RED, "请检查事件结束日期！", result[per_code])

        if ('是' in values_103[per_code][8] and 'X' not in dict_mb[per_code]['N']) or (
                '否' in values_103[per_code][8] and dict_mb[per_code]['N']):
            cells(ws_103, f"AP{i}", "请核对企业统计标识！", RED)

        if values_1072[dict_p[per_code]][3] not in dict_mb[per_code]['AQ']:
            add_color_comment(ws_103[f"Y{i}"], RED, "请检查调动后岗位名称！", result[per_code])

        if values_103[per_code][7] not in dict_mb[per_code]['AP'] and dict_mb[per_code]['AP'] not in \
                values_103[per_code][7]:
            cells(ws_103, f"W{i}", f"{dict_mb[per_code]['AP']}", BLUE)

        for k, (x, y) in {"M": ("AD", "AE"), "AN": ("AF", "AG"), "AO": ("AH", "AI")}.items():
            value = (str(ws_103[f"{x}{i}"].value) + str(ws_103[f"{y}{i}"].value)).replace(" ", "").replace("None", "")
            if per_code in dict_mb.keys() and value != dict_mb[per_code][k].replace(" ", "").replace("None", ""):
                add_color_comment(ws_103[f"{x}{i}"], RED, f'模板信息：{dict_mb[per_code][k]}', result[per_code])

        if ws_103[f"F{i}"].value != ws_103[f"BS{i}"].value or ws_103[f"BR{i}"].value != user_name()[0].upper():
            add_color_comment(ws_103[f"BS{i}"], RED, "请检查简历是否生成！", result[per_code])

        if dict_p[per_code] in values_1071.keys() and per_code in values_1071.keys() and '是' in \
                values_1071[dict_p[per_code]][6]:
            index, lis = list(values_1071.keys()).index(dict_p[per_code]), list(values_1071.values())
            if len(lis) >= index + 3 and lis[index + 1][-1] == lis[index + 2][-1] == "P":
                add_color_comment(ws_103[f"X{i}"], RED, "请检查存在一岗多人情况！", result[per_code])

    wb_103.save(result_file)
    # logging.info('事后校验完成，结束事件！')
    return flag, result


def export_three_tables(dict_p, date, dir_path, type=0):
    """type 区分 事前（0） 还是 事后（1）"""
    prefix = "事后_" if type else ""
    file103 = os.path.join(dir_path, f"{prefix}103{'_校验结果' if type else ''}.xlsx")
    # ctm = time.strftime("%m%d%H%M",time.gmtime(os.path.getctime(file103)))

    if not os.path.exists(file103):  # or type == 1:
        tmp = export_103(None, dict_p.keys(), date).save_to(dir_path)
        if tmp:
            shutil.move(tmp, file103)
    file1071 = os.path.join(dir_path, f'{prefix}1071.xlsx')
    if not os.path.exists(file1071):
        tmp = export_1071("reuse", dict_p.values(), date).save_to(dir_path)
        if tmp:
            shutil.move(tmp, file1071)

    file1072 = os.path.join(dir_path, f'{prefix}1072.xlsx')
    if not os.path.exists(file1072):
        tmp = export_1072("reuse", dict_p.values(), date).save_to(dir_path)
        if tmp:
            shutil.move(tmp, file1072)

    values_103, values_1071, values_1072 = defaultdict(list), defaultdict(list), defaultdict(list)
    wb_103 = load_workbook(file103)
    ws_103 = wb_103.active
    # tmp = ['C','J','S','T','U','Z','B','Q','W']
    for i in range(2, len(ws_103["A"]) + 1):
        values_103[cel(ws_103, f"A{i}").lstrip('0')] = [cel(ws_103, f'C{i}'), cel(ws_103, f'J{i}'),
                                                        cel(ws_103, f'S{i}'),
                                                        cel(ws_103, f'T{i}') + ' ' + cel(ws_103, f'U{i}'),
                                                        cel(ws_103, f'Z{i}'), cel(ws_103, f'B{i}'),
                                                        cel(ws_103, f'Q{i}'),
                                                        cel(ws_103, f'W{i}'), cel(ws_103, f'AP{i}')]
    wb_103.close()

    wb_1071 = load_workbook(file1071)
    ws_1071 = wb_1071.active
    for i in range(2, len(ws_1071["A"]) + 1):
        if cel(ws_1071, f"B{i}") == "S":
            p, q, s, u, w, y, k, z, ac = [ws_1071[x + str(i)].value for x in
                                          ["P", "Q", "S", "U", "W", "Y", "K", "Z", "AC"]]
            if bool((str(p).strip() in ["1", "2"] and q and s) or (str(p).strip() == "3" and u and w and y) and (
                    k and z and ac)):
                tmp_flag = False
            else:
                tmp_flag = True
            tmp_list = [cel(ws_1071, f"P{i}"), cel(ws_1071, f"Z{i}") + " " + cel(ws_1071, f"AA{i}"),
                        cel(ws_1071, f"B{i + 1}"), tmp_flag, cel(ws_1071, f"K{i}")[:2],
                        cel(ws_1071, f"A{i + 1}").lstrip("0"), cel(ws_1071, f"AE{i}")]
            values_1071[cel(ws_1071, f"A{i}").lstrip("0")] = tmp_list
    wb_1071.close()

    tmp_dict = {res.db_AS[0:4]: str(res.db_AS).rstrip() for res in Query(table=Event) if res.db_AS}
    wb_1072 = load_workbook(file1072)
    ws_1072 = wb_1072.active
    for i in range(2, len(ws_1072["A"]) + 1):
        if cel(ws_1072, f"B{i}") == "S" and cel(ws_1072, f"B{i + 1}") == "O":
            if cel(ws_1072, f"P{i + 1}") and cel(ws_1072, f"P{i + 1}") in tmp_dict.keys():
                tmp = tmp_dict[cel(ws_1072, f"P{i + 1}")]
            else:
                tmp = ''
            tmp_list = [tmp, cel(ws_1072, f"Q{i + 1}") + " " + cel(ws_1072, f"R{i + 1}"),
                        cel(ws_1072, f"M{i + 1}") + " " + cel(ws_1072, f"N{i + 1}"),
                        cel(ws_1072, f"H{i}").strip(), cel(ws_1072, f"H{i + 1}")]
            values_1072[cel(ws_1072, f"A{i}").lstrip("0")] = tmp_list
    wb_1072.close()

    close_sap()

    return values_103, values_1071, values_1072


def work_experience(work_dict, dir_name):
    if not work_dict:
        return
    logging.info('正在生成工作经历模板....')
    wb = load_workbook(os.path.join(templates, '模板_0023_HR_BI_0023_工作经历.xlsx'))
    ws = wb.active
    num = 1
    for k, v in work_dict.items():
        ws[f'A{num + 6}'] = num
        ws[f'B{num + 6}'] = k
        ws[f'C{num + 6}'] = v[0]
        ws[f'D{num + 6}'] = v[3]
        ws[f'E{num + 6}'] = '99991231'
        ws[f'F{num + 6}'] = v[2]
        ws[f'G{num + 6}'] = v[1]
        num += 1
    wb.save(os.path.join(dir_name, '工作经历模板.xlsx'))
    wb.close()
    logging.info(f'    【 {dir_name} 】下工作经历批导模板已生成')


def organize_file(file, is_succ=True, ctype='不在岗变动'):
    """
        实现导出文件合并功能，dict_file[key]=(d_file, shtname),默认第一个工作表
        key d_file 需要保留的文件  (s_file 需要复制后删除的文件  shtname 保存工作表名称)
    """
    base_dir = os.path.dirname(file)
    dict_files = defaultdict(tuple)
    for x in ('103', '1071', '1072'):
        dict_files[f'{x}.xlsx'] = (f'事后_{x}.xlsx' if x != '103' else f'事后_{x}_校验结果.xlsx', f'事后_{x}')
    from win32com.client import DispatchEx
    try:
        xl = DispatchEx("Excel.Application")
        xl.Visible, xl.DisplayAlerts, xl.ScreenUpdating = False, False, False
    except:
        logging.error('EXCEL 文件打开失败！')
        return False
    for d_file, (s_file, shtname) in dict_files.items():
        s_file = os.path.join(base_dir, s_file)
        d_file = os.path.join(base_dir, d_file)
        if not os.path.exists(s_file) or not os.path.exists(d_file):
            return False
        wb1 = xl.Workbooks.Open(Filename=s_file)
        wb2 = xl.Workbooks.Open(Filename=d_file)
        ws1 = wb1.Worksheets(1)
        sheets = [x.Name for x in wb2.Worksheets]
        if shtname in sheets:
            wb2.Worksheets(shtname).Delete()
        ws1.Copy(Before=wb2.Worksheets(1))
        wb2.Worksheets(1).Name = shtname
        wb1.Close(SaveChanges=False)
        wb2.Close(SaveChanges=True)
        os.remove(os.path.join(base_dir, s_file))
    xl.DisplayAlerts, xl.ScreenUpdating = True, True
    xl.Quit()
    dir_path = get_rpa_dir(ctype, os.path.splitext(os.path.basename(file))[0], is_succ)
    if os.path.exists(dir_path):
        shutil.rmtree(dir_path)
    shutil.copytree(base_dir, dir_path)
    return True


def click_enter(session, string):
    for i in range(5):
        session.findById("wnd[0]").sendVKey(0)
        text = session.findById("wnd[0]/sbar").text
        if '记录已创建' in text:
            return
        if '请保存' in text:
            session.findById("wnd[0]/tbar[0]/btn[11]").press()
            try:
                session.findById("wnd[1]/tbar[0]/btn[0]").press()
            except:
                logging.info(string + str(session.findById("wnd[1]").text))
            return
    else:
        logging.info(string + text)
        session.findById("wnd[0]/tbar[0]/btn[12]").press()
        return string + text
