import datetime
import logging
import os
import re
import shutil
import time
from collections import defaultdict
from threading import Thread

import pyperclip
from openpyxl import load_workbook
from openpyxl.utils import get_column_letter
from PIL import Image
from rpa.fastrpa.adtable import RED
from rpa.fastrpa.log import config
from rpa.fastrpa.sap.session import attach_sap
from rpa.fastrpa.utils.window import click_allow
from rpa.fastrpa.xlsx import convert_xlsx_to_xls
from rpa.public.config import FILE_PATH, remote_ruzhi_path, templates
from rpa.public.db import update_db
from rpa.public.myftp import MYFTP
from rpa.public.run_sap import close_sap
from rpa.public.tools import cel, cells, click_continue, find_window
from rpa.public.validate_103 import check_103
from rpa.ssc.hr.orm.orm import rpa_work_amount
from rpa.ssc.hr.orm.orm_ope import DbSession, Query
from rpa.ssc.hr.orm.tb_hr_ruzhi_log_detail import RZLog_detail
from rpa.ssc.hr.orm.td_hr_gang_wei_diao_pei_rulebase import Event
from rpa.ssc.hr.rpa_dir import get_rpa_dir
from rpa.ssc_rpa.hr.rpa_ru_zhi.ru_zhi_check_old import check_excel
from rpa.ssc_rpa.hr.rpa_ru_zhi.ru_zhi_shi_hou_jiao_yan import \
    export_103_1071_1072
from sqlalchemy import and_
from win32com.universal import com_error

file = None


def pa30(value, session):
    string, error_text = "", ""
    logging.info(f'正在维护【{value[81]}{value[1]}】的信息.....')

    def tmp_func(session, value, col, row):
        session.findById("wnd[0]/tbar[0]/okcd").text = '/n pa30'
        session.findById("wnd[0]").sendVKey(0)
        session.findById("wnd[0]/usr/ctxtRP50G-PERNR").text = value[81]
        session.findById("wnd[0]").sendVKey(0)
        session.findById(f"wnd[0]/usr/tabsMENU_TABSTRIP/tabpTAB0{col}").select()
        session.findById(
            f"wnd[0]/usr/tabsMENU_TABSTRIP/tabpTAB0{col}/ssubSUBSCR_MENU:SAPMP50A:0400/subSUBSCR_ITMENU:SAPMP50A:0310/tblSAPMP50ATC_MENU").verticalScrollbar.position = row
        text = session.findById(
            f"wnd[0]/usr/tabsMENU_TABSTRIP/tabpTAB0{col}/ssubSUBSCR_MENU:SAPMP50A:0400/subSUBSCR_ITMENU:SAPMP50A:0310/tblSAPMP50ATC_MENU/lblINF_EX[1,0]").toolTip
        session.findById(
            f"wnd[0]/usr/tabsMENU_TABSTRIP/tabpTAB0{col}/ssubSUBSCR_MENU:SAPMP50A:0400/subSUBSCR_ITMENU:SAPMP50A:0310/tblSAPMP50ATC_MENU").getAbsoluteRow(
            row).selected = -1
        btn = "6" if text == "存在" else "5"
        session.findById(f"wnd[0]/tbar[1]/btn[{btn}]").press()
        return btn

    # 组织分配屏
    try:
        btn = tmp_func(session, value, 3, 0)
        if btn == "5":
            tmp_func(session, value, 1, 0)
            session.findById("wnd[0]/usr/ctxtP0000-MASSG").text = value[3][:2]
            session.findById("wnd[0]/usr/ctxtPSPAR-PLANS").text = value[4]
            session.findById("wnd[0]/usr/ctxtPSPAR-WERKS").text = value[5][:4]
            session.findById("wnd[0]/usr/ctxtPSPAR-PERSG").text = value[7][:1]
            session.findById("wnd[0]/usr/ctxtPSPAR-PERSK").text = value[8][:2]
            session.findById("wnd[0]").sendVKey(0)
            session.findById("wnd[0]/tbar[0]/btn[11]").press()
            if "组织分配及岗位聘任" not in session.findById("wnd[0]/titl").text:
                click_enter(session, "组织分配")
        dxs_date = session.findById("wnd[0]/usr/ctxtP0001-BEGDA").text
        session.findById("wnd[0]/usr/ctxtP0001-BEGDA").text = value[2]
        session.findById("wnd[0]/usr/ctxtP0001-BTRTL").text = value[6][:4]
        try:
            session.findById("wnd[0]/usr/ctxtP0001-GSBER").text = value[9][:4] if value[9] else "4000"
        except Exception:  # nosec
            pass
        session.findById("wnd[0]/usr/ctxtP0001-ABKRS").text = value[10][:2]
        session.findById("wnd[0]/usr/cmbP0001-ANSVH").key = value[12][:2] if value[12] else " "
        session.findById("wnd[0]/usr/subSUBSCREEN_T582C:ZP000100:0200/ctxtP0001-ZZ_QYZDYYGFL").text = value[13].split()[
            0] if value[13] else ""
        session.findById("wnd[0]/usr/subSUBSCREEN_T582C:ZP000100:0200/ctxtP0001-ZZ_QYZDYYGFL1").text = \
            value[82].split()[0] if value[82] else ""
        session.findById("wnd[0]/usr/subSUBSCREEN_T582C:ZP000100:0200/ctxtP0001-ZZ_QYZDYYGFL2").text = \
            value[83].split()[0] if value[83] else ""
        if "X" in str(value[15]):
            session.findById(
                "wnd[0]/usr/subSUBSCREEN_T582C:ZP000100:0200/chkP0001-ZZ_QYTJBS1").selected = -1
        session.findById("wnd[0]/usr/subSUBSCREEN_T582C:ZP000100:0200/cmbP0001-ZZ_ZBTJWYBZ").key = value[16][:2]
        session.findById("wnd[0]").sendVKey(0)
        try:
            tmp_text = session.findById("wnd[0]/usr/subSUBSCREEN_T582C:ZP000100:0200/txtZHR_PYZEKZFWT-ZZ_ZEFW_TXT").text
            if not tmp_text and value[14]:
                session.findById("wnd[0]/usr/subSUBSCREEN_T582C:ZP000100:0200/ctxtP0001-ZZ_ZEFW").text = \
                    value[14].split()[0]
        except Exception:  # nosec
            pass
        session.findById("wnd[0]/tbar[0]/btn[11]").press()
        click_enter(session, "组织分配")
    except Exception as e:
        logging.warning(f"组织分配错误：{e}")
        return "组织分配" + str(session.findById("wnd[0]/titl").text), ""

    # 岗位聘任补充信息屏
    try:
        tmp_func(session, value, 3, 1)
        session.findById("wnd[0]/usr/ctxtP9209-BEGDA").text = value[2]
        session.findById("wnd[0]/usr/ctxtP9209-ZZ_ZWCJXL1").text = value[17][:1]
        session.findById("wnd[0]/usr/ctxtP9209-ZZ_ZWCJXL2").text = value[18][:2]
        session.findById("wnd[0]/usr/ctxtP9209-ZZ_ZWCJXL3").text = value[19][:2]
        session.findById("wnd[0]/usr/txtP9209-ZZ_ZWMC_RC").text = value[20]
        session.findById("wnd[0]/usr/txtP9209-ZZ_PRWH").text = value[25] if value[25] else ""
        session.findById("wnd[0]").sendVKey(0)
        session.findById("wnd[0]/tbar[0]/btn[11]").press()
        click_enter(session, "聘补信息")
    except Exception:
        string = string + "聘补信息、"

    # 人员基本信息
    try:
        tmp_func(session, value, 1, 1)
        error_text = ren_yuan_ji_ben_xin_xi(session, value)
        session.findById("wnd[0]/tbar[0]/btn[11]").press()
        if click_enter(session, "人员基本信息"):
            return "编号已生成，人员基本信息异常，需手工处理。", ""
    except Exception:
        return "编号已生成，人员基本信息异常，需手工处理。", ""
    # 政治面貌
    if value[84]:
        try:
            tmp_func(session, value, 1, 3)
            session.findById("wnd[0]/usr/ctxtP0534-BEGDA").text = value[85] if value[85] else value[2]
            session.findById("wnd[0]/usr/cmbP0534-PCODE").key = value[84][:2]
            session.findById("wnd[0]").sendVKey(0)
            session.findById("wnd[0]/tbar[0]/btn[11]").press()
            click_enter(session, "政治面貌")
        except Exception:
            string = string + "政治面貌、"
    # 证件信息
    try:
        btn = tmp_func(session, value, 1, 7)
        if btn == "5":
            session.findById("wnd[0]").sendVKey(0)
            session.findById("wnd[0]/usr/ctxtP0185-BEGDA").text = dxs_date[:-2] + "01" if dxs_date else value[2]
            session.findById("wnd[0]/usr/txtICNN1").text = value[57].replace(" ", '')[:6]
            session.findById("wnd[0]/usr/txtICNN2").text = value[57].replace(" ", '')[6:14]
            session.findById("wnd[0]/usr/txtICNN3").text = value[57].replace(" ", '')[14:17]
            session.findById("wnd[0]/usr/txtICNN4").text = value[57].replace(" ", '')[17:18]
            session.findById("wnd[0]").sendVKey(0)
            session.findById("wnd[0]/tbar[0]/btn[11]").press()
            click_enter(session, "证件信息")
    except Exception:
        string = string + "证件信息、"
    # 通讯信息
    if value[70]:
        try:
            session.findById("wnd[0]/tbar[0]/okcd").text = '/n pa30'
            session.findById("wnd[0]").sendVKey(0)
            session.findById("wnd[0]/usr/ctxtRP50G-PERNR").text = value[81]
            session.findById("wnd[0]").sendVKey(0)
            session.findById(
                "wnd[0]/usr/tabsMENU_TABSTRIP/tabpTAB01/ssubSUBSCR_MENU:SAPMP50A:0400/subSUBSCR_ITKEYS:SAPMP50A:0350/ctxtRP50G-CHOIC").text = "通讯信息"
            session.findById(
                "wnd[0]/usr/tabsMENU_TABSTRIP/tabpTAB01/ssubSUBSCR_MENU:SAPMP50A:0400/subSUBSCR_ITKEYS:SAPMP50A:0350/ctxtRP50G-SUBTY").text = "CELL"
            session.findById(
                "wnd[0]/usr/tabsMENU_TABSTRIP/tabpTAB01/ssubSUBSCR_MENU:SAPMP50A:0400/subSUBSCR_ITMENU:SAPMP50A:0310/tblSAPMP50ATC_MENU").verticalScrollbar.position = 9
            text = session.findById(
                "wnd[0]/usr/tabsMENU_TABSTRIP/tabpTAB01/ssubSUBSCR_MENU:SAPMP50A:0400/subSUBSCR_ITMENU:SAPMP50A:0310/tblSAPMP50ATC_MENU/lblINF_EX[1,0]").toolTip
            btn = "6" if text == "存在" else "5"
            session.findById(f"wnd[0]/tbar[1]/btn[{btn}]").press()
            session.findById("wnd[0]/usr/ctxtP0105-BEGDA").text = value[2]
            session.findById("wnd[0]/usr/txtP0105-USRID").text = value[70]
            session.findById("wnd[0]").sendVKey(0)
            session.findById("wnd[0]/tbar[0]/btn[11]").press()
            click_enter(session, "通讯信息")
        except Exception:
            string = string + "通讯信息、"

    #  地址信息
    if value[66]:
        try:
            tmp_func(session, value, 1, 10)
            session.findById("wnd[0]/usr/ctxtP0006-BEGDA").text = value[2]
            session.findById("wnd[0]/usr/ctxtP0006-ANSSA").text = "1"
            session.findById(
                "wnd[0]/usr/tabsTABSTRIP_0006_CN/tabpADR/ssubSUBSCREEN_ADD:MP000600:2128/txtP0006-ORT01").text = \
                value[66]
            session.findById("wnd[0]").sendVKey(0)
            session.findById("wnd[0]/tbar[0]/btn[11]").press()
            click_enter(session, "地址信息")
        except Exception:
            string = string + "地址信息、"

    #  其他用工
    if value[97]:
        try:
            tmp_func(session, value, 2, 0)
            session.findById("wnd[0]/usr/ctxtP9241-BEGDA").text = value[2]
            session.findById("wnd[0]/usr/cmbP9241-ZZ_QTYGLY").key = value[97][:2]
            try:
                session.findById("wnd[0]/usr/cmbP9241-ZZ_LWPQDW").key = value[98][:4] if value[98] else " "
                # session.findById("wnd[0]/usr/txtP9241-ZZ_LWPQDWMC").text = value[99] if value[99] else ""
                session.findById("wnd[0]/usr/cmbP9241-ZZ_LWPQDWLB").key = value[100][:1] if value[100] else " "
            except AttributeError:
                session.findById("wnd[0]/usr/txtP9241-ZZ_LWPQDWMC").text = value[99] if value[99] else ""
                session.findById("wnd[0]/usr/cmbP9241-ZZ_LWPQDWLB").key = value[100][:1] if value[100] else " "
            except com_error:
                logging.warning(f'SAP系统界面不存在,【{value[81]}】劳务派遣单位代码、名称、类别未维护成功！')
            except Exception as e:
                logging.error(f'SAP系统错误【{value[81]}】劳务派遣单位代码、名称、类别未维护成功（{e}）！')
            session.findById("wnd[0]").sendVKey(0)
            session.findById("wnd[0]/tbar[0]/btn[11]").press()
            click_enter(session, "其他用工")
        except Exception:
            string = string + "其他用工、"

    #  人员增减
    try:
        tmp_func(session, value, 3, 7)
        session.findById("wnd[0]/usr/ctxtP9253-BEGDA").text = value[2]
        session.findById("wnd[0]/usr/ctxtP9253-ZZ_ZJLB").text = value[72][:5] if value[72] else "19000"
        text = session.findById(
            "wnd[0]/usr/subSUBSCREEN_HEADER:/1PAPAXX/HDR_80001A:0100/txt$_DG07_800A01_DTX_P0001_BTRTL").text
        session.findById("wnd[0]/usr/txtP9253-ZZ_DRCBM").text = str(text)[:12]
        session.findById("wnd[0]").sendVKey(0)
        session.findById("wnd[0]/tbar[0]/btn[11]").press()
        click_enter(session, "人员增减")
    except Exception:
        string = string + "人员增减、"

    #  特殊日期
    try:
        tmp_func(session, value, 3, 6)
        session.findById("wnd[0]/usr/ctxtP0041-BEGDA").text = value[2]
        dic = {"参加工作日期": ("01", value[60]), "核定工龄起算日期": ("02", value[61]), "进入本系统工作日期": ("03", value[62]),
               "进入本单位工作日期": ("04", value[63]), "倒班工龄起始日期": ("05", value[64]),
               "核定倒班工龄起算日期": ("06", value[65]), "进入加油站工作日期": ("15", value[96])}
        for i in range(1, 10):
            text = session.findById(f"wnd[0]/usr/txtQ0041-TXT0{i}").text
            if text in dic.keys():
                session.findById(f"wnd[0]/usr/ctxtP0041-DAT0{i}").text = dic[text][1]
                dic.pop(text)
            elif not text and dic:
                for x, (y, z) in dic.items():
                    if z:
                        session.findById(f"wnd[0]/usr/ctxtP0041-DAR0{i}").text = y
                        session.findById(f"wnd[0]/usr/ctxtP0041-DAT0{i}").text = z
                    dic.pop(x)
                    break
        session.findById("wnd[0]").sendVKey(0)
        session.findById("wnd[0]/tbar[0]/btn[11]").press()
        click_enter(session, "特殊日期")
    except Exception:
        string = string + "特殊日期、"

    string = string[:-1] + "等信息未维护成功" if string else ""
    return string, error_text


def ren_yuan_ji_ben_xin_xi(session, value):
    def tmp_function(sess, sap, val):
        if val:
            sess.findById(sap).text = val
            sess.findById("wnd[0]").sendVKey(0)
            if "不存在" in sess.findById("wnd[0]/sbar/pane[0]").text:
                sess.findById(sap).text = ""
                return val
        return ""

    session.findById("wnd[0]/usr/txtP0002-NACHN").text = value[1]
    session.findById("wnd[0]/usr/ctxtP0002-BEGDA").text = value[35]
    session.findById("wnd[0]/usr/txtP0002-VORNA").text = value[37]
    if "男" in value[38]:
        session.findById("wnd[0]/usr/radQ0002-GESC1").select()
    else:
        session.findById("wnd[0]/usr/radQ0002-GESC2").select()
    session.findById("wnd[0]/usr/ctxtP0002-GBDAT").text = value[35]
    session.findById("wnd[0]/usr/ctxtP0002-NATIO").text = value[39][:2] if value[39] else ""
    session.findById("wnd[0]/usr/ctxtQ0002-FATXT").text = value[40][2:] if value[40] else ""
    if value[41]:
        session.findById("wnd[0]/usr/subSUBSCREEN_T582C:ZP000200:0200/cmbP0002-ZZ_GJREGIO").key = value[41][:3]
    t = tmp_function(session, "wnd[0]/usr/subSUBSCREEN_T582C:ZP000200:0200/ctxtP0002-ZZ_GJCOUNC", value[42][:3])
    t = t + " " + tmp_function(session, "wnd[0]/usr/subSUBSCREEN_T582C:ZP000200:0200/ctxtP0002-ZZ_GJDQX", value[43][:3])
    if value[44]:
        session.findById("wnd[0]/usr/subSUBSCREEN_T582C:ZP000200:0200/cmbP0002-ZZ_CSDREGIO").key = value[44][:3]
    t = t + " " + tmp_function(session, "wnd[0]/usr/subSUBSCREEN_T582C:ZP000200:0200/ctxtP0002-ZZ_CSDCOUNC", value[45][:3])
    t = t + " " + tmp_function(session, "wnd[0]/usr/subSUBSCREEN_T582C:ZP000200:0200/ctxtP0002-ZZ_CSDDQX", value[46][:3])
    if value[49]:
        session.findById("wnd[0]/usr/subSUBSCREEN_T582C:ZP000200:0200/cmbP0002-ZZ_HKXZ").key = value[49][:1]
    if value[104]:
        session.findById("wnd[0]/usr/subSUBSCREEN_T582C:ZP000200:0200/cmbP0002-ZZ_HKREGIO").key = value[104][:3]
    t = t + " " + tmp_function(session, "wnd[0]/usr/subSUBSCREEN_T582C:ZP000200:0200/ctxtP0002-ZZ_HKCOUNC", value[105][:3])
    t = t + " " + tmp_function(session, "wnd[0]/usr/subSUBSCREEN_T582C:ZP000200:0200/ctxtP0002-ZZ_HKDQX", value[106][:3])
    session.findById("wnd[0]/usr/subSUBSCREEN_T582C:ZP000200:0200/txtP0002-ZZ_HKSZD").text = ''.join(
        re.findall("([\u4E00-\u9FA5])", str(value[50])))
    if value[47]:
        session.findById("wnd[0]/usr/subSUBSCREEN_T582C:ZP000200:0200/cmbP0002-ZZ_MZ").key = value[47][:2]
    if value[51]:
        session.findById("wnd[0]/usr/subSUBSCREEN_T582C:ZP000200:0200/cmbP0002-ZZ_JKZK").key = value[51][:1]
    if value[55]:
        session.findById("wnd[0]/usr/subSUBSCREEN_T582C:ZP000200:0200/txtP0002-ZZ_QYYGDM").text = value[55]
    if value[52]:
        session.findById("wnd[0]/usr/subSUBSCREEN_T582C:ZP000200:0200/cmbP0002-ZZ_SFLB").key = value[52][:1]
    session.findById("wnd[0]").sendVKey(0)
    return t


def click_enter(session, string):
    for i in range(5):
        text = session.findById("wnd[0]/sbar").text
        if "记录已" not in text and "维护人力资源主数据" not in session.findById("wnd[0]/titl").text:
            session.findById("wnd[0]").sendVKey(0)
        else:
            return
    else:
        logging.info(string + str(session.findById("wnd[0]/sbar").text))
        time.sleep(5)
        session.findById("wnd[0]/tbar[0]/btn[12]").press()
        return string + str(session.findById("wnd[0]/sbar").text)


# 规则1.1.2: 分屏执行入职事件
def method1(r_file):
    if not r_file:
        return
    sr = os.path.basename(r_file).split("-")[0]
    wb = load_workbook(r_file, data_only=True)
    ws = wb.active
    values = [[str(x).replace("None", "") for x in value[:107]] for value in ws.values if value[4]][4:]
    session = attach_sap("login_tx")
    for value in values:
        logging.info(f"正在执行入职事件第{values.index(value) + 1}行数据...")
        string, error_text = "", ""
        with DbSession() as s:
            res = s.query(RZLog_detail).filter(and_(RZLog_detail.sr == sr, RZLog_detail.name == value[1]))
            if res.first() and res.first().code:
                value[81] = res.first().code
                ws["CA%s" % str(values.index(value) + 7)] = res.first().code
                ws["CD%s" % str(values.index(value) + 7)] = res.first().code
        try:
            if value[81] and str(value[81]).isdigit():
                string, error_text = pa30(value, session)
                ws["CB%s" % str(values.index(value) + 7)] = string
                if error_text.strip():
                    cells(ws, f"CB{values.index(value) + 7}", f"{error_text}不存在".strip(), RED)
                wb.save(r_file)
                continue
            session.findById("wnd[0]").maximize()
            session.findById("wnd[0]/tbar[0]/okcd").text = "/n ZPA40_10"
            session.findById("wnd[0]").sendVKey(0)
            session.findById("wnd[0]/usr/ctxtRP50G-PERNR").text = ""
            session.findById("wnd[0]").sendVKey(0)
            session.findById("wnd[0]/usr/ctxtRP50G-EINDA").text = value[2]
            session.findById("wnd[0]/usr/tblSAPMP50ATC_MENU_EVENT").getAbsoluteRow(1).selected = -1
            session.findById("wnd[0]/tbar[1]/btn[8]").press()
            session.findById("wnd[0]/usr/ctxtP0000-MASSG").text = value[3][:2]
            session.findById("wnd[0]/usr/ctxtPSPAR-PLANS").text = value[4]
            session.findById("wnd[0]/usr/ctxtPSPAR-WERKS").text = value[5][:4]
            session.findById("wnd[0]/usr/ctxtPSPAR-PERSG").text = value[7][:1]
            session.findById("wnd[0]/usr/ctxtPSPAR-PERSK").text = value[8][:2]
            session.findById("wnd[0]").sendVKey(0)
            #  人事调配
            session.findById("wnd[0]/tbar[0]/btn[11]").press()
            temp = session.findById("wnd[0]/sbar").text
            if "请执行审批流程" in temp or "科目分配对象属于公司代码" in temp or "入职操作已关闭" in temp or "被锁定" in temp:
                logging.info(f'{value[1]}, {temp}')
                ws["CB%s" % str(values.index(value) + 7)] = session.findById("wnd[0]/sbar").text
                wb.save(r_file)
                upload_ftp(r_file, "失败")
                logging.error("入职：总部或企业开关未打开或工资范围被锁定，请注意检查")
                raise Exception("入职：总部或企业开关未打开或工资范围被锁定，请注意检查")
            string = click_enter(session, "人事调配")
            try:
                code = session.findById(
                    "wnd[0]/usr/subSUBSCREEN_HEADER:/1PAPAXX/HDR_80003A:0100/txt$_DG01_800A03_DAT_P0000_PERNR").text
                logging.info(f"生成人员编号：{value[1]}: {code}")
            except Exception:
                code = ""
            with DbSession() as s:
                res = s.query(RZLog_detail).filter(and_(RZLog_detail.sr == sr, RZLog_detail.name == value[1]))
                if res.first():
                    res.update({"code": code})
            ws["CA%s" % str(values.index(value) + 7)] = code
            ws["CD%s" % str(values.index(value) + 7)] = code
            value[81] = code
            if code:
                string, error_text = pa30(value, session)
        except Exception:
            string = string if string else session.findById("wnd[0]/sbar").text
        finally:
            wb.save(r_file)
        ws["CB%s" % str(values.index(value) + 7)] = string
        if error_text.strip():
            cells(ws, f"CB{values.index(value) + 7}", f"{error_text}不存在", RED)
        wb.save(r_file)
    session.findById("wnd[0]/tbar[0]/okcd").text = "/nex"
    session.findById("wnd[0]").sendVKey(0)


def upload_ftp(s_file, result):
    path = os.path.dirname(s_file)
    dir_path = get_rpa_dir('员工入职', os.path.basename(os.path.dirname(s_file)), True)
    shutil.copytree(path, dir_path, dirs_exist_ok=True)
    remote = remote_ruzhi_path + os.path.basename(path) + "_" + result
    with MYFTP() as ftp:
        ftp.rmd(remote)
        ftp.rmd(remote[:-2] + "失败")
        ftp.upload_file_tree(path, remote)


# 规则1.1.3、1.1.4: 校验人员子组
def method2(r_file):
    if not r_file:
        return
    name_dict = defaultdict(list)
    wb = load_workbook(r_file)
    ws = wb.active
    values = [[str(x).replace("None", "") for x in value[:108]] for value in ws.values if value[4] and value[81]][1:]
    for v in values:
        dd_v = v[107] if len(v) == 108 else ""
        name_dict[str(v[1]).strip()] = [v[81], v[17][:1], v[2], v[86], v[87], v[89], v[88], v[101], v[93], dd_v]
    create_work_type(r_file, name_dict)
    create_language(r_file, name_dict)
    create_professional(r_file, name_dict)
    create_special(r_file, name_dict)
    update_excel(r_file, name_dict)

    tmp_dict = {"0021->HR_BI_0021": "家庭成员及社会关系模板", "0022->HR_BI_0022": "学历学位模板",
                "9243->HR_BI_9243": "从事职业工种信息模板",
                "9205->HR_BI_9205_1": "语言能力模板", "9217->HR_BI_9217": "专业技术资格模板",
                "9207->HR_BI_9207": "专长信息模板"}  # "0023->HR_BI_0023": "工作经历模板",
    for key, value in tmp_dict.items():
        file_name = os.path.dirname(r_file).replace("/", "\\") + f"\\{value}.xlsx"
        bd_file = os.path.dirname(r_file).replace("/", "\\") + f"\\{value}_文件内容异常.xlsx"
        if not os.path.exists(file_name) and os.path.exists(bd_file):
            os.rename(bd_file, file_name)
        if os.path.exists(file_name):
            if update_file(file_name, name_dict):
                continue
            batch_import(file_name, key, 1)

    work_types_identification(r_file, "CA", "C")
    Organization_distribution(r_file, 0)
    compenent_picture(r_file)
    batch_import_picture(r_file)
    export_103_1071_1072(r_file)
    check_103(r_file, FILE_PATH + "/模板_103_RZ.xlsx", FILE_PATH + "/模板_1071.xlsx", FILE_PATH + "/模板_1072.xlsx")
    for x in ["103_RZ", "1072", "1071"]:
        shutil.move(FILE_PATH + f"/模板_{x}.xlsx", os.path.dirname(r_file) + f"/校验后_{x}表.xlsx")
    # jl_xls = f"{file_path}/简历模板.xls"
    # if os.path.exists(jl_xls):
    #     shutil.move(jl_xls, os.path.dirname(r_file) + f"/简历模板.xls")
    #     shutil.move(jl_xls + 'x', os.path.dirname(r_file) + f"/简历模板.xlsx")


def update_file(filename, name_dict):
    wb = load_workbook(filename)
    ws = wb.active
    lis = []
    lis1 = [x[0].value for x in ws.columns if x[0].value]
    column_name = get_column_letter(len(lis1) + 1)
    if len(ws["A"]) == 6:
        return True
    for i in range(7, len(ws["A"]) + 1):
        if ws[column_name + str(i)].value:
            logging.info(ws[column_name + str(i)].value)
            wb.close()
            return True
        if ws[f"C{i}"].value in name_dict.keys():
            ws[f"B{i}"].value = name_dict[ws[f"C{i}"].value][0]
        else:
            lis.append(i)
        wb.save(filename)
    for i in list(reversed(lis)):
        ws.delete_rows(i, 1)
    wb.save(filename)
    wb.close()
    wb = load_workbook(filename)
    ws = wb.active
    for i in range(7, len(ws["B"]) + 1):
        ws[f"A{i}"].value = str(i - 6)
    wb.save(filename)
    wb.close()


#  生成从事职业工种信息模板
def create_work_type(r_file, name_dict):
    logging.info("    生成从事职业工种信息模板...")
    if os.path.exists(os.path.dirname(r_file) + "/从事职业工种信息模板.xlsx"):
        return
    wb = load_workbook(os.path.join(templates + '/模板_9243_HR_BI_9243-从事职业（工种）情况.xlsx'))
    ws = wb.active
    count = 1
    for key, value in name_dict.items():
        if value[1] == "3":
            ws["A%s" % str(count + 6)].value = str(count)
            ws["B%s" % str(count + 6)].value = value[0]
            ws["C%s" % str(count + 6)].value = key
            ws["D%s" % str(count + 6)].value = value[2]
            ws["E%s" % str(count + 6)].value = "99991231"
            if "其他" not in str(value[8]):
                ws["F%s" % str(count + 6)].value = "X"
            count += 1
            wb.save(os.path.dirname(r_file) + "/从事职业工种信息模板.xlsx")


#  生成语言能力信息模板
def create_language(m_file, name_dict):
    logging.info("    语言能力模板...")
    if os.path.exists(os.path.dirname(m_file) + "/语言能力模板.xlsx"):
        return
    wb = load_workbook(os.path.join(templates + '/9205_HR_BI_9205_1-语言能力.xlsx'))
    ws = wb.active
    count = 1
    for key, value in name_dict.items():
        if value[3]:
            ws["A%s" % str(count + 6)].value = str(count)
            ws["B%s" % str(count + 6)].value = value[0]
            ws["C%s" % str(count + 6)].value = key
            ws["D%s" % str(count + 6)].value = value[2]
            ws["E%s" % str(count + 6)].value = "99991231"
            ws["F%s" % str(count + 6)].value = value[3]
            ws["G%s" % str(count + 6)].value = value[4]
            count += 1
            wb.save(os.path.dirname(m_file) + "/语言能力模板.xlsx")


#  生成专业技术任职资格信息模板
def create_professional(m_file, name_dict):
    logging.info("    专业技术资格模板...")
    if os.path.exists(os.path.dirname(m_file) + "/专业技术资格模板.xlsx"):
        return
    wb = load_workbook(os.path.join(templates + '/9217_HR_BI_9217-专业技术资格.xlsx'))
    ws = wb.active
    count = 1
    db_dict = {res.db_CY.strip(): res.db_CX for res in Query(table=Event) if res.db_CY}
    for key, value in name_dict.items():
        if value[6]:
            ws["A%s" % str(count + 6)].value = str(count)
            ws["B%s" % str(count + 6)].value = value[0]
            ws["C%s" % str(count + 6)].value = key
            ws["D%s" % str(count + 6)].value = value[5] if value[5] else value[2]
            ws["E%s" % str(count + 6)].value = "99991231"
            ws["F%s" % str(count + 6)].value = db_dict[value[6].strip()] if value[6].strip() in db_dict.keys() else ""
            ws["G%s" % str(count + 6)].value = value[6]
            count += 1
            wb.save(os.path.dirname(m_file) + "/专业技术资格模板.xlsx")


#  生成专长信息模板
def create_special(m_file, name_dict):
    logging.info("    专长信息模板...")
    if os.path.exists(os.path.dirname(m_file) + "/专长信息模板.xlsx"):
        return
    wb = load_workbook(os.path.join(templates + '/9207_HR_BI_9207-专长信息.xlsx'))
    ws = wb.active
    count = 1
    for key, value in name_dict.items():
        if value[7]:
            ws["A%s" % str(count + 6)].value = str(count)
            ws["B%s" % str(count + 6)].value = value[0]
            ws["C%s" % str(count + 6)].value = key
            ws["D%s" % str(count + 6)].value = value[2]
            ws["E%s" % str(count + 6)].value = "99991231"
            ws["H%s" % str(count + 6)].value = "1"
            ws["I%s" % str(count + 6)].value = value[7]
            count += 1
            wb.save(os.path.dirname(m_file) + "/专长信息模板.xlsx")


# 学历、工作经历、家庭成员模板填充人员编号
def update_excel(s_file, name_dict):
    for f_name in ["学历学位模板", "工作经历模板", "家庭成员及社会关系模板"]:
        gd_file = os.path.dirname(s_file) + f"/{f_name}.xlsx"
        bd_file = os.path.dirname(s_file) + f"/{f_name}_文件内容异常.xlsx"
        if not os.path.exists(gd_file) and os.path.exists(bd_file):
            os.rename(bd_file, gd_file)
        elif not os.path.exists(gd_file):
            continue
        wb = load_workbook(gd_file)
        ws = wb.active
        for i in range(7, len(ws["C"]) + 1):
            if cel(ws, f"C{i}") in name_dict.keys():
                ws["B%s" % str(i)] = name_dict[cel(ws, f"C{i}")][0]
                if f_name == "工作经历模板" and name_dict[cel(ws, f"C{i}")][2]:
                    if name_dict[cel(ws, f"C{i}")][9] and ws[f"B{i}"] == name_dict[cel(ws, f"C{i}")][2]:
                        ws["F%s" % str(i)] = name_dict[cel(ws, f"C{i}")][9]

        wb.save(gd_file)
    jl_xlsx = fr"{os.path.dirname(s_file)}\工作经历模板.xlsx"
    if os.path.exists(jl_xlsx):
        experience_transformation(jl_xlsx)

# 规则1.2.1：zhrbi0013批导模板表


def batch_import(m_file, key, count):
    logging.info(f"开始批导{m_file}")
    m_file = m_file.replace("/", "\\")
    session = attach_sap("login_tx")
    session.findById("wnd[0]/tbar[0]/okcd").text = "/n zhrbi0013"
    session.findById("wnd[0]").sendVKey(0)
    session.findById("wnd[0]/usr/radRB_S").select()
    session.findById("wnd[0]/tbar[1]/btn[8]").press()
    session.findById("wnd[0]/usr/ctxtP_SRTFD").text = key
    session.findById("wnd[0]/usr/radRB_UP").select()
    # fix_excel(file)
    t = Thread(target=click_continue)
    t.setDaemon(True)
    t.start()
    t = Thread(target=find_window, args=(m_file, '#32770', u'选择上传文件'))
    t.setDaemon(True)
    t.start()
    session.findById("wnd[0]/tbar[1]/btn[8]").press()
    # if "没有需要处理的数据或数据错误" in session.findById("wnd[0]/sbar/pane[0]").text: return
    lis = ["上载的模板中没有数据或数据错误", "文件不符合要求", "没有需要处理的数据或数据错误"]
    if session.findById("wnd[0]/sbar/pane[0]").text in lis:
        if 10 < count:
            os.rename(m_file, m_file[:-5] + "_文件格式" + ".xlsx")
            session.findById("wnd[0]/tbar[0]/okcd").text = "/nex"
            session.findById("wnd[0]").sendVKey(0)
            return
        count += 1
        time.sleep(2)
        batch_import(m_file, key, count)
        return
    try:
        result = session.findById("wnd[1]/usr/txtSPOP-TEXTLINE2").text
    except Exception:
        if 10 < count:
            os.rename(m_file, m_file[:-5] + "_文件内容异常" + ".xlsx")
            close_sap()
            return
        count += 1
        batch_import(m_file, key, count)
        return
    session.findById("wnd[1]/usr/btnSPOP-OPTION1").press()
    session.findById("wnd[0]/tbar[0]/okcd").text = "/nex"
    session.findById("wnd[0]").sendVKey(0)
    logging.info(f'{m_file}, {result}')
    if "失败0" not in result:
        os.rename(m_file, m_file[:-5] + "_批导失败" + ".xlsx")


def batch_import_picture(m_file):
    picture_path = os.path.dirname(m_file) + "\\照片"
    sr = os.path.basename(m_file)[:10]
    if not os.path.exists(picture_path):
        logging.warning('\t\t照片目录不存在')
        return
    code_dict = update_db(m_file, "手动批导照片")

    for _file, dirs, files in os.walk(picture_path):
        for picture_file in files:
            first_name = os.path.splitext(picture_file)[0]
            last_name = os.path.splitext(picture_file)[1]
            if last_name in [".png", ".PNG"]:
                im = Image.open(os.path.join(_file, picture_file))
                rgb_im = im.convert('RGB')
                if not os.path.exists(os.path.join(_file, picture_file[0:-4] + ".jpg")):
                    rgb_im.save(os.path.join(_file, picture_file[0:-4] + ".jpg"))
                os.remove(os.path.join(_file, picture_file))
            elif last_name in [".jpeg", ".JPEG"]:
                os.rename(os.path.join(_file, picture_file), os.path.join(_file, first_name + ".jpg"))
    for _file, dirs, files in os.walk(picture_path):
        for picture_file in files:
            first_name = os.path.splitext(picture_file)[0]
            if first_name in code_dict.keys() and os.path.exists(os.path.join(_file, first_name + ".jpg")):
                if not os.path.exists(os.path.join(_file, picture_file[0:-4] + ".jpg")):
                    continue
                os.rename(os.path.join(_file, first_name + ".jpg"), os.path.join(_file, code_dict[first_name] + ".jpg"))
    logging.info('\t正在进行照片批导.....')
    session = attach_sap("login_tx")
    session.findById("wnd[0]").maximize()
    session.findById("wnd[0]/tbar[0]/okcd").text = "/n ZHRBI0004"
    session.findById("wnd[0]").sendVKey(0)
    session.findById("wnd[0]/usr/ctxtP_PERNR-LOW").text = [x for x in code_dict.values()][0]
    session.findById("wnd[0]/usr/ctxtP_DOKAR").text = "HRICOLFOTO"
    session.findById("wnd[0]/usr/ctxtF_NAME").text = picture_path
    t = Thread(target=click_allow, args=(None, u"SAP GUI 安全性", 1200))
    t.setDaemon(True)
    t.start()
    session.findById("wnd[0]/usr/btn%_P_PERNR_%_APP_%-VALU_PUSH").press()
    session.findById("wnd[1]/tbar[0]/btn[16]").press()
    text = '\r\n'.join([x for x in code_dict.values()])
    pyperclip.copy(text)
    session.findById("wnd[1]/tbar[0]/btn[24]").press()
    session.findById("wnd[1]/tbar[0]/btn[8]").press()
    session.findById("wnd[0]/tbar[1]/btn[8]").press()
    session.findById(
        "wnd[0]/usr/subSUBSCREEN:SAPLHRPADPAL00:0101/cntlSAPLSBAL_DISPLAY_CONTAINER/shellcont/shell/shellcont[0]/shell").doubleClickItem(
        "01        1", "001")
    a, table = [], session.findById(
        "wnd[0]/usr/subSUBSCREEN:SAPLHRPADPAL00:0101/cntlSAPLSBAL_DISPLAY_CONTAINER/shellcont/shell/shellcont[1]/shell")
    if "选取人员数" not in table.getCellValue(0, "T_MSG").split()[-1]:
        for i in range(table.rowCount):
            logging.warning(f'{table.getCellValue(i, "PERNR")} {table.getCellValue(i, "T_MSG")}')
            a.append("0" * (8 - len(table.getCellValue(i, "PERNR"))) + table.getCellValue(i, "PERNR"))

    # message = table.getCellValue(0, "T_MSG").split()[-1]
    # a = [] if "选取人员数" in message else ["0" * (8 - len(table.getCellValue(i, "PERNR"))) + table.getCellValue(i, "PERNR")
    #                                    for i in range(table.rowCount)]
    for k, v in code_dict.items():
        b = "没有相应的文件" if v in a else "成功"
        with DbSession() as s:
            s.query(RZLog_detail).filter(RZLog_detail.sr == sr, RZLog_detail.code == v).update(
                {RZLog_detail.picture: f"{b}"})
    session.findById("wnd[0]/tbar[0]/okcd").text = "/nex"
    session.findById("wnd[0]").sendVKey(0)


# 规则2.1.3 & 2.1.4 & 2.1.5  重新带出从事职业工种信息 & 最高等级工种鉴定标识 & 生成简历
def work_types_identification(file_name, col, key_date_cell, code=""):
    logging.info("重新带出从事职业工种信息 & 最高等级工种鉴定标识 & 生成简历")
    wb = load_workbook(file_name)
    ws = wb.active
    session = attach_sap("login_tx")
    text = ''
    for x in range(7, len(list(ws["B"])) + 1):
        if ws[f"{col}{x}"].value:
            text = text + str(ws[f"{col}{x}"].value).split('.')[0].replace(" ", '') + '\r\n'
    staff_ids = [cel(ws, f"{col}{x}") for x in range(7, len(list(ws["B"])) + 1)]
    # key_date, area_codes = cel(ws, f"{key_date_cell}7"), list({cel(ws, f"F{x}")[:4] for x in range(7, len(list(ws["B"])) + 1)})
    pyperclip.copy('\r\n'.join(staff_ids))
    session.findById("wnd[0]/tbar[0]/okcd").text = "/n zhrconv073"
    session.findById("wnd[0]").sendVKey(0)
    session.findById("wnd[0]/usr/ctxtPNPWERKS-LOW").text = os.path.basename(file_name).split('-')[
        1] if not code else code
    session.findById("wnd[0]/usr/cmbPNPTIMED").key = "I"  # 其他期间
    session.findById("wnd[0]/usr/ctxtPNPBEGDA").text = datetime.datetime.now().strftime(r'%Y%m%d')  # 事件执行日期
    session.findById("wnd[0]/usr/ctxtPNPENDDA").text = "99991231"
    session.findById("wnd[0]/usr/btn%_PNPPERNR_%_APP_%-VALU_PUSH").press()
    session.findById("wnd[1]/tbar[0]/btn[16]").press()
    session.findById("wnd[1]/tbar[0]/btn[24]").press()
    session.findById("wnd[1]/tbar[0]/btn[8]").press()
    session.findById("wnd[0]/tbar[1]/btn[8]").press()
    for x in range(7, len(list(ws["B"])) + 1):
        if not ws[f"{col}{x}"].value:
            continue
        session.findById("wnd[0]/tbar[0]/okcd").text = "/n PA30"
        session.findById("wnd[0]").sendVKey(0)
        session.findById("wnd[0]/shellcont/shell/shellcont[0]/shell/shellcont[1]/shell[1]").topNode = "          1"
        session.findById("wnd[0]/usr/ctxtRP50G-PERNR").text = ws[f"{col}{x}"].value
        session.findById("wnd[0]/usr/ctxtRP50G-PERNR").caretPosition = 7
        session.findById("wnd[0]").sendVKey(0)
        session.findById("wnd[0]/usr/tabsMENU_TABSTRIP/tabpTAB03").select()
        session.findById(
            "wnd[0]/usr/tabsMENU_TABSTRIP/tabpTAB03/ssubSUBSCR_MENU:SAPMP50A:0400/subSUBSCR_ITMENU:SAPMP50A:0310/tblSAPMP50ATC_MENU").getAbsoluteRow(
            2).selected = -1
        session.findById(
            "wnd[0]/usr/tabsMENU_TABSTRIP/tabpTAB03/ssubSUBSCR_MENU:SAPMP50A:0400/subSUBSCR_ITMENU:SAPMP50A:0310/tblSAPMP50ATC_MENU/txtT582S-ITEXT[0,2]").setFocus()
        session.findById(
            "wnd[0]/usr/tabsMENU_TABSTRIP/tabpTAB03/ssubSUBSCR_MENU:SAPMP50A:0400/subSUBSCR_ITMENU:SAPMP50A:0310/tblSAPMP50ATC_MENU/txtT582S-ITEXT[0,2]").caretPosition = 0
        session.findById("wnd[0]/tbar[1]/btn[20]").press()
        try:
            session.findById("wnd[0]/usr/tblMP924300TC3000").getAbsoluteRow(0).selected = -1
            session.findById("wnd[0]/tbar[1]/btn[6]").press()
            session.findById("wnd[0]").sendVKey(0)
            session.findById("wnd[0]").sendVKey(0)
            session.findById("wnd[0]/tbar[0]/btn[11]").press()
        except Exception:  # nosec
            pass
    # logging.info("\t\t 正在生成简历信息...")
    # jl_xls, jl_xlsx = download_work_experience_template(staff_ids, key_date, area_codes)
    # session.findById("wnd[0]/tbar[0]/okcd").text = "/n zhrpa175"
    # session.findById("wnd[0]").sendVKey(0)
    # session.findById("wnd[0]/usr/ctxtPNPWERKS-LOW").text = os.path.basename(file_name).split("-")[
    #     1] if not code else code
    # session.findById("wnd[0]/usr/ctxtPNPWERKS-LOW").setFocus()
    # session.findById("wnd[0]/usr/ctxtPNPWERKS-LOW").caretPosition = 4
    # session.findById("wnd[0]/usr/btn%_PNPPERNR_%_APP_%-VALU_PUSH").press()
    # session.findById("wnd[1]/tbar[0]/btn[16]").press()
    # session.findById("wnd[1]/tbar[0]/btn[24]").press()
    # session.findById("wnd[1]/tbar[0]/btn[8]").press()
    # session.findById("wnd[0]/tbar[1]/btn[8]").press()
    # session.findById("wnd[0]/tbar[1]/btn[14]").press()
    # session.findById("wnd[0]/tbar[1]/btn[23]").press()
    # session.findById("wnd[0]/tbar[0]/okcd").text = "/nex"
    # session.findById("wnd[0]").sendVKey(0)


def Organization_distribution(file_name, flag=1):
    # flag=1 “重新录用”，flag=0 “入职事件”
    logging.info("修改组织分配屏信息...")
    wb = load_workbook(file_name)
    ws = wb.active
    session = attach_sap("login_tx")
    text = ''
    Pnumber = "B" if flag else "CA"
    for x in range(7, len(list(ws[Pnumber])) + 1):
        if ws[f"{Pnumber}{str(x)}"].value:
            text = text + str(ws[f"{Pnumber}{str(x)}"].value).split('.')[0].replace(" ", '') + '\r\n'
    session.findById("wnd[0]/tbar[0]/okcd").text = "/n PA30"
    session.findById("wnd[0]").sendVKey(0)
    temp = "wnd[0]/shellcont/shell/shellcont[0]/shell/shellcont[1]/shell[1]"
    session.findById(temp).clickLink("          2", "&Hierarchy")
    for i in range(1, 20):
        try:
            if "IC 号码" in session.findById(f"wnd[1]/usr/tabsG_SELONETABSTRIP/tabpTAB00{i}").text:
                idx = i
                break
        except Exception:
            raise Exception("修改组织分配屏为找到  IC 号码  的标签")
    session.findById(f"wnd[1]/usr/tabsG_SELONETABSTRIP/tabpTAB00{idx}").select()
    pyperclip.copy(text)
    session.findById(
        "wnd[1]/usr/tabsG_SELONETABSTRIP/tabpTAB003/ssubSUBSCR_PRESEL:SAPLSDH4:0220/sub:SAPLSDH4:0220/btnG_SELFLD_TAB-MORE[4,56]").press()
    session.findById("wnd[2]/tbar[0]/btn[16]").press()
    session.findById("wnd[2]/tbar[0]/btn[24]").press()
    session.findById("wnd[2]/tbar[0]/btn[8]").press()
    session.findById("wnd[1]/tbar[0]/btn[0]").press()
    session.findById("wnd[0]/usr/tabsMENU_TABSTRIP/tabpTAB03").select()
    session.findById(
        "wnd[0]/usr/tabsMENU_TABSTRIP/tabpTAB03/ssubSUBSCR_MENU:SAPMP50A:0400/subSUBSCR_ITMENU:SAPMP50A:0310/tblSAPMP50ATC_MENU").getAbsoluteRow(
        0).selected = -1
    nRow = session.findById("wnd[0]/shellcont/shell/shellcont[1]/shell").RowCount
    for x in range(nRow):
        session.findById("wnd[0]/shellcont/shell/shellcont[1]/shell").setCurrentCell(int(x), "ADD_FIELD2")
        session.findById("wnd[0]/shellcont/shell/shellcont[1]/shell").selectedRows = str(x)
        session.findById("wnd[0]/shellcont/shell/shellcont[1]/shell").doubleClickCurrentCell()
        try:  # 取消数据保存
            session.findById("wnd[1]/usr/btnSPOP-OPTION1").press()
        except Exception:  # nosec
            pass
        if "维护人力资源主数据" in session.findById("wnd[0]/titl").text:
            session.findById("wnd[0]/tbar[1]/btn[6]").press()
        session.findById("wnd[0]").sendVKey(0)
        session.findById("wnd[0]").sendVKey(0)
        try:
            session.findById("wnd[0]/tbar[0]/btn[11]").press()
        except Exception as e:
            logging.error(f'{session.findById("wnd[0]/sbar/pane[0]").text}, {e}')

    session.findById("wnd[0]/tbar[0]/okcd").text = "/nex"
    session.findById("wnd[0]").sendVKey(0)
    rpa_work_amount([cel(ws, f"{Pnumber}{str(x)}") for x in range(7, len(list(ws[Pnumber])) + 1)])


def compenent_picture(m_file):
    wb = load_workbook(m_file)
    ws = wb.active
    logging.info('\t正在根据姓名匹配人员照片.....')
    for i in range(7, len(ws["B"]) + 1):
        name = cel(ws, f"B{i}")
        code = str(ws["CA%s" % str(i)].value).strip()
        if not code.isdigit():
            ws["CB%s" % str(i)] = "人员编号缺失或者有误"
            wb.save(m_file)
            continue
        if not [x for x in os.listdir(os.path.dirname(m_file) + "/照片") if name in x]:
            ws["CB%s" % str(i)] = "人员照片缺失或者照片格式有误"
            wb.save(m_file)


def yuan_gong_ru_zhi(dir_path):
    # 模板批导前校验
    from rpa.ssc_rpa.hr.rpa_chong_xin_lu_yong.chong_xin_lu_yong_shi_jian_old import (
        ChongXin_LuYong, shi_qian_check_excel)
    r_flag, r_file = check_excel(dir_path)
    c_flag, c_file, code, sr = shi_qian_check_excel(dir_path)
    print(r_flag, c_flag)
    if r_flag or c_flag:
        upload_ftp(dir_path + "/1.x", "失败")
        return
    if not update_db(c_file, "开始执行事件操作"):
        logging.info(f"文件{c_file}命名格式不正确")
        return
    if not update_db(r_file, "开始执行事件操作"):
        logging.info(f"文件{r_file}命名格式不正确")
        return
    ChongXin_LuYong(c_file)
    method1(r_file)
    method2(r_file)
    upload_ftp(r_file if r_file else c_file, result="成功")


def da_xue_sheng_ru_zhi(dir_path):
    # 模板批导前校验
    from rpa.ssc_rpa.hr.rpa_chong_xin_lu_yong.chong_xin_lu_yong_shi_jian_old import (
        ChongXin_LuYong, shi_qian_check_excel)
    r_flag, r_file = check_excel(dir_path, "大学生入职")
    c_flag, c_file, code, sr = shi_qian_check_excel(dir_path, "大学生入职")
    print(r_flag, c_flag)
    if r_flag or c_flag:
        upload_ftp(dir_path + "/1.x", "失败")
        return
    if not update_db(c_file, "开始执行事件操作"):
        logging.info(f"文件{c_file}命名格式不正确")
        return
    if not update_db(r_file, "开始执行事件操作"):
        logging.info(f"文件{r_file}命名格式不正确")
        return
    ChongXin_LuYong(c_file)
    method1(r_file)
    method2(r_file)
    upload_ftp(r_file if r_file else c_file, result="成功")


def experience_transformation(filename):
    '''工作经历模板转简历模板'''
    from collections import Counter
    date = datetime.datetime.now().strftime("%Y%m%d")
    template_file = f'{templates}/简历模板.xlsx'
    logging.info(f"转换路径:{filename}")
    wb = load_workbook(filename)
    ws = wb.active
    data_lst = []
    nrow = len([x.value for x in ws['B'][6:] if x.value])
    for n in range(7, nrow + 7):
        data_lst.append([ws[f'{chr(x)}{n}'].value for x in range(66, 74)])
    a_count = dict(Counter([x[1] for x in data_lst]))
    wb.close()
    wb = load_workbook(template_file)
    ws, n, pn = wb.active, 1, 0
    for i in range(len(data_lst)):
        for sn, x in enumerate(['B', 'C', 'G', 'H', 'I', 'J']):
            ws[f'{x}{i + 2}'] = data_lst[i][sn]
        pn = pn + 1 if pn < a_count.get(data_lst[i][1], 1) else 1
        ws[f'A{i + 2}'], ws[f'D{i + 2}'] = n, pn
        ws[f'E{i + 2}'], ws[f'F{i + 2}'] = '9', '工作经历(含教育培训)'
        ws[f'K{i + 2}'], n = date, n + 1
    wb.save(fr'{os.path.dirname(filename)}\简历模板.xlsx')
    wb.close()
    convert_xlsx_to_xls(fr'{os.path.dirname(filename)}\简历模板.xlsx')
    logging.info('工作经历转换简历模板成功！')


if __name__ == "__main__":
    config()
    import rpa.config

    rpa.config.FSO_USERNAME = "dingj2321"  # guoy926
    rpa.config.SAP_FUNJ = "FUNJ0056"
    # attach_sap("login_tx", fso_username="guoy926")
    r_file = r"x:\dk\新建文件夹\1\1000280324-x450-员工入职-丁洁_成功\1000280324-X450-员工入职-丁洁.xlsx"
    method2(r_file)
    # Organization_distribution(r_file, 0)
    # compenent_picture(r_file)
    # batch_import_picture(r_file)
    # export_103_1071_1072(r_file)
    # check_103(r_file, file_path + "/模板_103_RZ.xlsx", file_path + "/模板_1071.xlsx", file_path + "/模板_1072.xlsx")
    # for x in ["103_RZ", "1072", "1071"]:
    #     shutil.move(file_path + f"/模板_{x}.xlsx", os.path.dirname(r_file) + f"/校验后_{x}表.xlsx")
