#!/usr/bin/env python
# -*- coding: utf-8 -*-
# @File    : ru_zhi_check.py
# @Author  : jinjianfeng
# @Contact : 553041800@qq.com
# @Link    : https://github.com/jinjf553
# @software: PyCharm
# @Date    : 2019/10/9 15:12
# @Version : ??
import logging
import os
import shutil
import time
from collections import defaultdict

from id_validator import validator
from openpyxl import load_workbook
from openpyxl.utils import get_column_letter
from rpa.fastrpa.xlsx import connect_to_excel
from rpa.public.all_party_up import str_to_date
from rpa.public.check_template import (check_degree_template,
                                       check_family_members_template,
                                       check_work_experience)
from rpa.public.config import FILE_PATH
from rpa.public.tools import cel, cells
from rpa.ssc.hr.orm.orm_ope import Query
from rpa.ssc.hr.orm.session import DbSession
from rpa.ssc.hr.orm.tb_hr_ruzhi_log_detail import RZLog_detail
from rpa.ssc.hr.orm.td_hr_gang_wei_diao_pei_rulebase import Event
from rpa.ssc.hr.sap.export_1071 import export_1071
from rpa.ssc.hr.sap.export_1072 import export_1072
from rpa.ssc_kit.hr.kit_chai_dan.sap import export_card_info
from sqlalchemy import and_


def check_excel(dir_path, string="员工入职"):
    file_name = ""
    for _file, dir, files in os.walk(dir_path):
        for file in files:
            if string in file:
                file_name = os.path.join(_file, file)
                break
        else:
            continue
        break
    else:
        return False, file_name

    tmp_dict, flag_dict = check_degree_template(dir_path + "/学历学位模板.xlsx", defaultdict(list))
    flag_dict = check_family_members_template(dir_path + "/家庭成员及社会关系模板.xlsx", flag_dict)
    flag_dict = check_work_experience(dir_path + "/工作经历模板.xlsx", flag_dict)

    rule_U_V_W = {res.db_U: [res.db_V, res.db_W] for res in Query(table=Event) if
                  res.db_U and res.db_V and res.db_W}  # 17 职位序列、职位层级、职位级别
    rule_L_M = {res.db_L: res.db_M for res in Query(table=Event) if res.db_L and res.db_M}  # 17 人员子组、职位序列
    rule_AA_AH = {res.db_AA + res.db_AB[:4] + res.db_AE: res.db_AH for res in Query(table=Event) if
                  res.db_AA and res.db_AB and res.db_AE}  # 11 工资总额控制范围
    rule_hi = {str(res.db_J).strip(): str(res.db_K).strip() for res in Query(Event) if res.db_J}
    logging.info("提取码表库码表值")
    tdt = {4: "BN", 6: "AS", 7: "E", 8: "J", 9: "L", 10: "BO", 11: "AG", 12: "BP", 13: "Y", 14: "F", 15: "AH", 16: "R",
           17: "BQ", 18: "V", 19: "W", 20: "U", 22: "R", 23: "V", 24: "W", 25: "U", 28: "R", 29: "R", 30: "R",
           31: "R", 33: "CV", 34: "R", 35: "R", 39: "BR", 40: "CN", 41: "BS", 42: "BT", 43: "BU",
           44: "BV", 45: "BT", 46: "BU", 47: "BV", 48: "BW", 49: "BX", 50: "BY", 52: "BZ", 53: "CA", 54: "CB",
           55: "CC", 57: "R", 73: "CD", 75: "CE", 77: "BY", 85: "CV", 87: "CW", 89: "CY", 98: "CZ", 99: "DF",
           101: "DG", 105: "BT", 106: "BU", 107: "BV"}
    ruledict = defaultdict(list)
    for r in Query(Event):
        for k, v in tdt.items():
            if eval("r.db_" + v):
                ruledict[k].append(eval("r.db_" + v).replace(" ", ""))

    bd_file = file_name
    # xl = win32.Dispatch("Excel.Application")
    xl = connect_to_excel()  # 20210113 用通用连接Excel方法替换直连，连接失败时kill Excel并重试
    # xl.Visible = True
    xl.DisplayAlerts = False
    wb = xl.Workbooks.Open(bd_file)
    try:
        ws = wb.ActiveSheet
        rowcount = ws.Range("B%s" % str(ws.Rows.Count)).End(-4162).Row
        ws.Range("A7:CZ%s" % str(ws.Rows.Count)).ClearComments()
        ws.Range("A7:CZ%s" % str(ws.Rows.Count)).Interior.ColorIndex = -4142
        if rowcount < 7 or "人员编号列" not in ws.Range("CD6").Value:
            logging.info("入职模板为空或者模板错误！")
            return False, ""
        tmpes = [str(x.value).strip().lstrip('0') for x in ws.Range(f'E7:E{rowcount}')]
        name_dict = {i[3]: i[0] for i in ws.Range("B7:E%s" % str(rowcount)).Value}
        logging.info(name_dict)
        card_dict = {ws.Range("BF%s" % str(x)).Value: ws.Range("B%s" % str(x)).Value for x in range(7, rowcount + 7)}
        date = ws.Range("C7").Value
        values_1071, values_1072 = export_1071_1072(name_dict, date, dir_path)
        values_103 = get_card_info(card_dict, dir_path)
        for i in range(7, rowcount + 1):
            logging.info(f"开始校验第{i - 6}行数据...")
            i = str(i)
            ws.Range(f"D{i}").Value = str(ws.Range(f"D{i}").Value).strip().replace("新入职-", "")
            ca, cd = str(ws.Range(f"CA{i}").Value).strip(), str(ws.Range(f"CD{i}").Value).strip()
            ca, cd = ca.split(".")[0], cd.split(".")[0]
            if string == "大学生入职":
                if ca and ca.isdigit():
                    ws.Range(f"CD{i}").Value = ca
                elif cd and cd.isdigit():
                    ws.Range(f"CA{i}").Value = cd
                else:
                    cells(ws, f"CA{i}", "人员编号有误或者不存在", 3)
                    continue

            if ws.Range(f"CA{i}").Value and string == "员工入职":
                if str(ws.Range(f"D{i}").Value).strip()[:2] not in ["13", "14", "15"]:
                    continue

            # 9  填写人事范围、人事子范围
            if not ws.Range("E" + i).Value:
                cells(ws, "E" + i, "岗位编号不能为空", 3)
                continue
            ws.Range("E" + i).value = str(ws.Range("E" + i).value).strip().lstrip('0').replace(".0", "")
            tmpe = str(ws.Range("E" + i).value).strip().lstrip('0').replace(".0",
                                                                            "")  # str(int(ws.Range("E" + i).Value)).lstrip("0")
            if tmpes.count(tmpe) > 1:
                cells(ws, "E" + i, "请检查岗位编号有否重复", 3)
            if tmpe in [x.lstrip("0") for x in values_1072.keys()]:
                if not ws.Cells(int(i), 6).Value:
                    ws.Cells(int(i), 6).Value = values_1072[tmpe][0]
                elif str(ws.Cells(int(i), 6).Value).strip() != values_1072[tmpe][0]:
                    cells(ws, "F" + i, "人事范围与岗位信息不匹配", 3)
                if not ws.Cells(int(i), 7).Value:
                    ws.Cells(int(i), 7).Value = values_1072[tmpe][1]
                if not ws.Cells(int(i), 10).Value:
                    ws.Cells(int(i), 10).Value = values_1072[tmpe][2]

            # 18  检验入职模板中人职位序列、薪酬标杆岗位类别、岗位分类序列符合逻辑
            tmp_list = [x.lstrip("0") for x in values_1071.keys()]
            if tmpe not in tmp_list:
                cells(ws, "E" + i, "1071不存在该岗位编号，请检查", 3)
                continue
            tmp107, tmpr = values_1071[tmpe], str(ws.Range("R" + i).Value)[:1]
            if not ((tmp107[0] == tmp107[1][:1] == tmpr) or (tmp107[0] == tmpr == "3" and tmp107[1][:1] == "4")):
                cells(ws, "E" + i, "请检查岗位分类序列和薪酬标杆信息", 3)

            # 17  检验入职模板中人员子组、职位序列、层级符合逻辑
            tmph = str(ws.Range("H" + i).Value).strip().split()[0]
            tmpi = str(ws.Range("I" + i).Value).strip()
            tmpt = str(ws.Range("T" + i).Value).strip()
            tmpr = str(ws.Range("R" + i).Value).strip()
            tmps = str(ws.Range("S" + i).Value).strip()
            if tmpt not in rule_U_V_W.keys() or rule_U_V_W[tmpt][0] != tmpr or rule_U_V_W[tmpt][1] != tmps:
                cells(ws, "I" + i, "职位序列层次级别信息不匹配", 3)
            if tmph[0] in ['A', 'B', 'C'] and tmpi in rule_L_M.keys() and tmpr != rule_L_M[tmpi]:
                cells(ws, "I" + i, "请检查人员子组和职位序列信息", 3)
            if tmph[0] == 'M' and tmpi[:2] not in ['61', '62', '63']:
                cells(ws, "I" + i, "人员组和人员子组不匹配", 3)

            # 16  检查模板有长度要求的字段符合要求
            if len(str(ws.Range("Z" + i).Value).strip()) > 40:
                cells(ws, "Z" + i, "请检查数据长度超长", 3)
            if len(str(ws.Range("BD" + i).Value).strip()) > 18:
                cells(ws, "BD" + i, "请检查数据长度超长", 3)
            if len(str(ws.Range("BO" + i).Value).strip()) > 40:
                cells(ws, "BO" + i, "请检查数据长度超长", 3)

            # 15  检验入职时间是否符合要求
            tmpc = str(ws.Range("C" + i).Value).strip()[:8]
            try:
                time.strptime(tmpc, '%Y%m%d')
                current_date = time.strftime("%d", time.localtime(time.time()))
                current_month = time.strftime("%Y%m01", time.localtime(time.time()))
                next_month = time.strftime("%Y%m01",
                                           time.localtime(time.time() + (32 - int(current_date)) * 24 * 60 * 60))
                if tmpc not in [current_month, next_month]:
                    cells(ws, "C" + i, "请核查此数值是否为有效入职时间", 3)
                if i != "7" and str(ws.Range("C" + str(int(i) - 1)).Value).strip()[:8] != tmpc:
                    cells(ws, "C" + i, "请核查此数值是否为有效入职时间", 3)
                if tmp_dict[str(ws.Range(f"B{i}").Value).strip()] > int(tmpc):
                    cells(ws, f"C{i}", "学历模板毕业日期不应晚于入职模板的入职时间", 3)
            except Exception:
                cells(ws, "C" + i, "请核查此数值是否为有效入职时间", 3)

            # 14  检验入职模板【BF】列身份证是否有重复
            tmpbf_lt = [ws.Range("BF%s" % str(x)).Value for x in range(int(i) + 1, rowcount + 2)]
            if ws.Range("BF" + i).Value in tmpbf_lt:
                cells(ws, "BF" + i, "请检查人员身份证重复", 3)
                cells(ws, "BF" + str(tmpbf_lt.index(ws.Range("BF" + i).Value) + int(i) + 1), "请检查人员身份证重复", 3)
            # if len(str(ws.Range("BF" + i).Value).replace(" ", '')) != 18:
            #     cells(ws, "BF" + i, "请检查人员身份证号长度", 3)
            if validator.get_info(str(ws.Range("BF" + i).Value).strip()) is False:
                cells(ws, "BF" + i, "请检查人员身份证号是否无效", 3)

            # 13  检验入职所有相关模板中必填项内容不为空
            for j in [chr(x // 26 + 64) + chr(x % 26 + 65) if x > 25 else chr(x + 65) for x in range(79)]:
                if "X" in str(ws.Range(j + "3").Value) and ws.Range(j + i).Value is None:
                    cells(ws, j + i, "此单元格为必填项", 3)

            # 10  检验模板中人事范围、人事子范围、工资核算范围是否匹配
            # 11  填写工资总额控制范围
            tmp_var = str(ws.Range("F" + i).Value)[:4] + str(ws.Range("G" + i).Value)[:4] + str(
                ws.Range("K" + i).Value)[:2]
            if tmp_var in rule_AA_AH.keys():
                if not ws.Range("O" + i).Value:
                    ws.Range("O" + i).Value = rule_AA_AH[tmp_var].strip()
            elif "00" == str(ws.Range("K" + i).Value)[:2]:
                pass
            else:
                cells(ws, "K" + i, "工资核算范围与人事范围、人事子范围不匹配，请核实", 3)
                cells(ws, "O" + i, "工资总额控制范围无匹配，请检查", 3)
            tmpv, tmpu = str(ws.Range("V" + i).Value).strip(), str(ws.Range("U" + i).Value).strip()
            if tmpv == "30 中层管理" or (tmpv[:2].isdigit() and int(tmpv[:2]) < 50 and tmpu == "2 专业技术人员"):
                cells(ws, "O" + i, "请注意检查中层及专家人员的工资总额控制范围", 41)

            # 20  检查岗位编号下是否已经分配有人员
            tmp_flag = True
            if string == "大学生入职":
                if not ("P" in values_1071[tmpe][2] and values_1071[tmpe][5] == str(ws.Range(f"CD{i}").Value).lstrip(
                        "0")):
                    cells(ws, f"E{i}", "此岗位未分配人员，请检查", 3)
            elif "P" in values_1071[tmpe][2]:
                with DbSession() as s:
                    sr, name = os.path.basename(bd_file).split("-")[0], ws.Range(f"B{i}").Value
                    res = s.query(RZLog_detail).filter(and_(RZLog_detail.sr == sr, RZLog_detail.name == name))
                    if len(res.all()) == 1 and res.first().code:
                        ws.Range(f"CA{i}").Value = ws.Range(f"CD{i}").Value = res.first().code
                        tmp_flag = False
                    else:
                        cells(ws, "E" + i, "此岗位已经分配有人员，请检查", 3)

            # 15  检验入职模板【BF】列身份证是否在SAP中
            tmpbf = ws.Range("BF" + i).Value
            if string == "员工入职" and tmpbf in values_103.keys():
                if values_103[tmpbf][0] != "None" and not ws.Range(f"CD{i}").Value:
                    if "减册人员" not in values_103[tmpbf] and "离退休人员" not in values_103[tmpbf] and tmp_flag:
                        cells(ws, "BF" + i, "系统中已有此人员，请注意检查", 3)

            # 21  检查岗位信息是否完整
            if values_1071[tmpe][3]:
                cells(ws, "E" + i, "此岗位信息不完整，请检查", 3)

            # 22  检查事件原因、人员组和岗位信息逻辑关系
            tmpd, tmph = str(ws.Range("D" + i).Value).strip(), str(ws.Range("H" + i).Value).strip()
            if 'A 原正式职工' in tmph:  # 20210125 临时增加A类人员管控
                cells(ws, "D" + i, "A类人员入职严格管控，请核实!", 3)
            if ((tmpd == "39 招录的核心业务普通岗位人员" and tmph == "B 合同制员工" and values_1071[tmpe][4][:1] != "C") or
                    (tmph == "C 派遣制员工" and values_1071[tmpe][4] not in ["B2", "C2"])):
                cells(ws, "D" + i, "人员组与岗位信息不匹配", 3)
            # if "其他增员" in tmpd and "B 合同制员工" in tmph:
            #     cells(ws, "D" + i, "B合同制员工入职操作受管控！", 3)
            if tmph == "B 合同制员工" and tmpd[:2] != "39":
                cells(ws, "D" + i, "B合同制员工入职操作受管控！", 41)

            # 23  检查机构名称
            if tmpe in values_1072.keys() and values_1072[tmpe][3] not in str(ws.Range("CM" + i).Value).strip():
                cells(ws, "CM" + i, "请核实入职机构名称", 41)

            # 24  检查人员组与人员子组是否匹配
            tmpi = str(ws.Range("I" + i).Value).strip().split()[0]
            if (tmph == "B" and tmpi not in ["12", "13", "14", "15", "16", "17", "21", "22"]) or \
                    (tmph == "M" and tmpi not in ["61", "62", "63"]):
                cells(ws, "H" + i, "请检查人员组与人员子组是否匹配", 3)

            # 12  检验入职所有相关模板有码表的均符合码表规则
            for key, value in ruledict.items():
                if not ws.Cells(int(i), key).Value:
                    continue
                if str(ws.Cells(int(i), key).Value).replace(" ", "") not in value:
                    cells(ws, (int(i), key), "单元格数据不是码值", 41 if key == 99 else 3)
            # 25  检查AN-国籍
            # 26  提取机构全称
            if tmpe in values_1072.keys():
                ws.Range("DD" + i).Value = values_1072[tmpe][4]

            # # 校验H-人员组与I-人员子组是否对应
            tmph, tmpi = str(ws.Range(f"H{i}").Value).strip(), str(ws.Range(f"I{i}").Value).strip()[:2]
            if tmph in rule_hi.keys():
                if tmpi not in rule_hi[tmph]:
                    cells(ws, f"H{i}", f"该人员组对应的人员子组只能在以下范围：{rule_hi[tmph]}", 3)
            else:
                cells(ws, f"H{i}", f"码表库中没有该人员组", 3)
            c = None
            for date_col in ['C', 'AJ', 'BG', 'BH', 'BI', 'BJ', 'BK', 'BL', 'BM', 'BN', 'CH', 'CL', 'CS', 'CZ']:
                date = str(ws.Range(f"{date_col}{i}").value).replace('None', '').strip()[:8]
                if not date:
                    continue
                d = str_to_date(date)
                if date_col == 'C':
                    c = d
                if d is None:
                    cells(ws, f"{date_col}{i}", "异常日期值", 3)
                elif c is not None:
                    if date_col in ['BI', 'BJ', 'BK', 'BL', 'BM', 'BN']:
                        if (d - c).days > 15:
                            cells(ws, f"{date_col}{i}", "特殊日期和入职时间逻辑错误", 3)
                    elif date_col != 'BH' and (d - c).days > 0:
                        cells(ws, f"{date_col}{i}", "日期晚于入职时间", 3)

        wb.Save()
        # 检查是否有标红单元格
        rowcount = ws.Range("B%s" % str(ws.Rows.Count)).End(-4162).Row
        for r in range(7, rowcount + 1):
            for c in range(1, 105):
                if ws.Range(f"{get_column_letter(c)}{r}").Interior.ColorIndex == 3:
                    flag_dict[True].append(f"入{get_column_letter(c)}{r}")
        if True in flag_dict.keys():
            cells(ws, "A1", f"校验未通过的模板单元格：{flag_dict[True]}", 3)
            wb.Save()
    except Exception as e:
        raise e
    finally:
        wb.Close()
        xl.Quit()
    logging.info(f"True: {flag_dict[True]}" if True in flag_dict.keys() else "模板检查完毕，可执行事件。")
    return True if True in flag_dict else False, file_name


def export_1071_1072(name_dict, date, dir_path):
    logging.warning(name_dict.keys())
    li = [str(int(value)) for value in name_dict.keys()]
    export_1071(None, li, date).save_to(FILE_PATH)
    shutil.move(os.path.join(FILE_PATH, "模板_1071.xlsx"), os.path.join(dir_path, "1071.xlsx"))
    export_1072("reuse", li, date).save_to(FILE_PATH)
    shutil.move(os.path.join(FILE_PATH, "模板_1072.xlsx"), os.path.join(dir_path, "1072.xlsx"))

    wb_1071 = load_workbook(os.path.join(dir_path, "1071.xlsx"))
    ws_1071 = wb_1071.active
    values_1071 = defaultdict(list)
    for i in range(2, len(ws_1071["A"]) + 1):
        if str(ws_1071["B%s" % str(i)].value) == "S":
            p, q, s, u, w, y, k, z, ac = [ws_1071[x + str(i)].value for x in
                                          ["P", "Q", "S", "U", "W", "Y", "K", "Z", "AC"]]
            if bool((str(p).strip() in ["1", "2"] and q and s) or (str(p).strip() == "3" and u and w and y) and (
                    k and z and ac)):
                tmp_flag = False
            else:
                tmp_flag = True
            tmp_list = [cel(ws_1071, f"P{i}"),
                        cel(ws_1071, f"Z{i}") + " " + cel(ws_1071, f"AA{i}"),
                        cel(ws_1071, f"B{i + 1}"), tmp_flag, cel(ws_1071, f"K{i}")[:2],
                        cel(ws_1071, f"A{i + 1}").lstrip("0")]
            values_1071[cel(ws_1071, f"A{i}").lstrip("0")] = tmp_list

    tmp_dict = {res.db_AS[0:4]: str(res.db_AS).rstrip() for res in Query(table=Event) if res.db_AS}
    tmp_dict.update({"": ""})
    wb_1072 = load_workbook(os.path.join(dir_path, "1072.xlsx"))
    ws_1072 = wb_1072.active
    values_1072 = defaultdict(list)
    for i in range(2, len(ws_1072["A"]) + 1):
        if str(ws_1072["B%s" % str(i)].value) == "S" and str(ws_1072["B%s" % str(i + 1)].value) == "O":
            if cel(ws_1072, f"P{i + 1}") not in tmp_dict.keys():
                continue
            tmp_list = [tmp_dict[cel(ws_1072, f"P{i + 1}")],
                        cel(ws_1072, f"Q{i + 1}") + " " + cel(ws_1072, f"R{i + 1}"),
                        cel(ws_1072, f"M{i + 1}") + " " + cel(ws_1072, f"N{i + 1}"),
                        cel(ws_1072, f"G{i + 1}"), cel(ws_1072, f"H{i + 1}")]
            values_1072[cel(ws_1072, f"A{i}").lstrip("0")] = tmp_list
    return values_1071, values_1072


def get_card_info(card_dict, dir_path):
    string = "\r\n".join([value for value in card_dict.keys() if value])
    if string:
        export_card_info(string)

    if os.path.exists(os.path.join(FILE_PATH, "tmp-card.xlsx")):
        shutil.move(os.path.join(FILE_PATH, "tmp-card.xlsx"), os.path.join(dir_path, "103.xlsx"))
    else:
        return {}

    wb_103 = load_workbook(os.path.join(dir_path, "103.xlsx"))
    ws_103 = wb_103.active
    values_103 = defaultdict(list)
    for i in range(2, len(ws_103["A"]) + 1):
        tmp_list = cel(ws_103, f"M{i}")
        values_103[str(ws_103["K%s" % str(i)].value).lstrip("0")].append(tmp_list)
    return values_103
