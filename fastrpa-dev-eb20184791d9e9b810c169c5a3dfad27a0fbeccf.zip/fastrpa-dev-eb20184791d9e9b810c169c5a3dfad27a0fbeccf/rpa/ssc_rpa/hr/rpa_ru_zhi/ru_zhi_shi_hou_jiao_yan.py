#!/usr/bin/env python
# -*- coding: utf-8 -*-
# @File    : ru_zhi_shi_hou_jiao_yan.py
# @Author  : jinjianfeng
# @Contact : 553041800@qq.com
# @Link    : https://github.com/jinjf553
# @software: PyCharm
# @Date    : 2019/11/27 16:25
# @Version : ??
from openpyxl import load_workbook
from rpa.fastrpa.sap.session import close_sap
from rpa.public.config import FILE_PATH
from rpa.public.db import update_db
from rpa.ssc.hr.sap.export_103rz import export_103rz
from rpa.ssc.hr.sap.export_1071 import export_1071
from rpa.ssc.hr.sap.export_1072 import export_1072


def export_103_1071_1072(file):
    update_db(file, "手动事后校验")
    wb = load_workbook(file)
    ws = wb.active

    # 103组合逻辑查询表
    personnel_code = [str(ws[f"CA{x}"].value).split('.')[0].replace(" ", '') for x
                      in range(7, len(list(ws["B"])) + 1) if ws[f"CA{x}"].value]
    position_code = [str(ws[f"E{x}"].value).split('.')[0].replace(" ", '') for x
                     in range(7, len(list(ws["B"])) + 1) if ws[f"E{x}"].value]
    date_time = ([str(ws[f"C{x}"].value) for x in range(7, len(list(ws["B"])) + 1) if
                  len(str(ws[f"C{x}"].value)) == 8 and str(ws[f"C{x}"].value).isdigit()] + [""])[0]

    if not date_time or not personnel_code or not position_code:
        return False
    #  导出组合逻辑查询103表
    export_103rz(None, personnel_code, date_time).save_to(FILE_PATH)

    # 1071组合逻辑查询表
    export_1071("reuse", position_code, date_time).save_to(FILE_PATH)

    # 1072组合逻辑查询表
    export_1072("reuse", position_code, date_time).save_to(FILE_PATH)
    close_sap()
