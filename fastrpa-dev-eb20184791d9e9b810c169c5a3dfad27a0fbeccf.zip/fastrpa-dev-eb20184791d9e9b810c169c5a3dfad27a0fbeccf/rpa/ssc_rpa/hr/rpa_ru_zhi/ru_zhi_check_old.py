#!/usr/bin/env python
# -*- coding: utf-8 -*-
# @File    : ru_zhi_check.py
# @Author  : jinjianfeng
# @Contact : 553041800@qq.com
# @Link    : https://github.com/jinjf553
# @software: PyCharm
# @Date    : 2019/10/9 15:12
# @Version : ??
import logging
import os
import shutil
import time
from collections import defaultdict

from id_validator import validator
from openpyxl import load_workbook
from openpyxl.utils import get_column_letter
from rpa.fastrpa.adtable import BLUE, RED, load_from_xlsx_file
from rpa.public.all_party_up import str_to_date
from rpa.public.check_template import (check_degree_template,
                                       check_family_members_template,
                                       check_work_experience)
from rpa.public.config import FILE_PATH
from rpa.public.tools import cel, cells
from rpa.ssc.hr.orm.orm_ope import Query
from rpa.ssc.hr.orm.session import DbSession
from rpa.ssc.hr.orm.tb_hr_ruzhi_log_detail import RZLog_detail
from rpa.ssc.hr.orm.td_hr_gang_wei_diao_pei_rulebase import Event
from rpa.ssc.hr.sap.export_1071 import export_1071
from rpa.ssc.hr.sap.export_1072 import export_1072
from rpa.ssc_kit.hr.kit_chai_dan.sap import export_card_info
from sqlalchemy import and_


def check_excel(dir_path, string="员工入职"):
    file_name = ""
    for _file, dir, files in os.walk(dir_path):
        for file in files:
            if string in file:
                file_name = os.path.join(_file, file)
                break
        else:
            continue
        break
    else:
        return False, file_name

    tmp_dict, flag_dict = check_degree_template(dir_path + "/学历学位模板.xlsx", defaultdict(list))
    flag_dict = check_family_members_template(dir_path + "/家庭成员及社会关系模板.xlsx", flag_dict)
    flag_dict = check_work_experience(dir_path + "/工作经历模板.xlsx", flag_dict)

    rule_U_V_W = {res.db_U: [res.db_V, res.db_W] for res in Query(table=Event) if
                  res.db_U and res.db_V and res.db_W}  # 17 职位序列、职位层级、职位级别
    rule_L_M = {res.db_L: res.db_M for res in Query(table=Event) if res.db_L and res.db_M}  # 17 人员子组、职位序列
    rule_AA_AH = {res.db_AA + res.db_AB[:4] + res.db_AE: res.db_AH for res in Query(table=Event) if
                  res.db_AA and res.db_AB and res.db_AE}  # 11 工资总额控制范围
    rule_hi = {str(res.db_J).strip(): str(res.db_K).strip() for res in Query(Event) if res.db_J}
    logging.info("提取码表库码表值")
    tdt = {4: "BN", 6: "AS", 7: "E", 8: "J", 9: "L", 10: "BO", 11: "AG", 12: "BP", 13: "Y", 14: "F", 15: "AH", 16: "R",
           17: "BQ", 18: "V", 19: "W", 20: "U", 22: "R", 23: "V", 24: "W", 25: "U", 28: "R", 29: "R", 30: "R",
           31: "R", 33: "CV", 34: "R", 35: "R", 39: "BR", 40: "CN", 41: "BS", 42: "BT", 43: "BU",
           44: "BV", 45: "BT", 46: "BU", 47: "BV", 48: "BW", 49: "BX", 50: "BY", 52: "BZ", 53: "CA", 54: "CB",
           55: "CC", 57: "R", 73: "CD", 75: "CE", 77: "BY", 85: "CV", 87: "CW", 89: "CY", 98: "CZ", 99: "DF",
           101: "DG", 105: "BT", 106: "BU", 107: "BV"}
    ruledict = defaultdict(list)
    for r in Query(Event):
        for k, v in tdt.items():
            if eval("r.db_" + v):
                ruledict[k].append(eval("r.db_" + v).replace(" ", ""))

    adt = load_from_xlsx_file(xlsx_filename=file_name, skip_header=6)
    adt.clear_comment_and_fgcolor()
    adt.del_blank_rows_by_column("B")
    if adt.ws.max_row < 7 or '人员编号列' not in cel(adt.ws, "CD6"):
        logging.info("入职模板为空或者模板错误！")
        return False, ""
    tmpes = [cel(adt.ws, f"E{x}").lstrip('0') for x in range(7, len(adt.ws["A"]) + 1)]
    name_dict = {cel(adt.ws, f"E{x}"): cel(adt.ws, f"B{x}") for x in range(7, len(adt.ws["A"]) + 1) if
                 cel(adt.ws, f"B{x}")}
    logging.info(name_dict)
    card_dict = {cel(adt.ws, f"BF{x}"): cel(adt.ws, f"B{x}") for x in range(7, len(adt.ws["A"]) + 1)}
    date = cel(adt.ws, f"C7")
    values_1071, values_1072 = export_1071_1072(name_dict, date, dir_path)
    values_103 = get_card_info(card_dict, dir_path)
    for i in range(7, len(adt.ws["A"]) + 1):
        logging.info(f"开始校验第{i - 6}行数据...")
        adt.ws[f"D{i}"] = cel(adt.ws, f"D{i}").replace("新入职-", "")
        ca, cd = cel(adt.ws, f"CA{i}").split(".")[0], cel(adt.ws, f"CD{i}").split(".")[0]
        if string == "大学生入职":
            adt.ws[f"CD{i}"] = ca if ca and ca.isdigit() else cd
            if not (ca and ca.isdigit()) and not (cd and cd.isdigit()):
                cells(adt.ws, f"CA{i}", "人员编号有误或者不存在", RED)
                continue

        if cel(adt.ws, f"CA{i}") and string == "员工入职":
            if cel(adt.ws, f"D{i}")[:2] not in ["13", "14", "15"]:
                continue

        # 9  填写人事范围、人事子范围
        if not cel(adt.ws, f"E{i}"):
            cells(adt.ws, f"E{i}", "岗位编号不能为空", RED)
            continue
        adt.ws[f"E{i}"] = tmpe = cel(adt.ws, f"E{i}").lstrip('0').split(".")[0]
        if tmpes.count(tmpe) > 1:
            cells(adt.ws, f"E{i}", "请检查岗位编号有否重复", RED)
        if tmpe in [x.lstrip("0") for x in values_1072.keys()]:
            if not cel(adt.ws, (i, 6)):
                adt.ws.cell(i, 6).value = values_1072[tmpe][0]
            elif cel(adt.ws, (i, 6)) != values_1072[tmpe][0]:
                cells(adt.ws, f"F{i}", "人事范围与岗位信息不匹配", RED)
            if not cel(adt.ws, (i, 7)):
                adt.ws.cell(i, 7).value = values_1072[tmpe][1]
            if not cel(adt.ws, (i, 10)):
                adt.ws.cell(i, 10).value = values_1072[tmpe][2]

        # 18  检验入职模板中人职位序列、薪酬标杆岗位类别、岗位分类序列符合逻辑
        tmp_list = [x.lstrip("0") for x in values_1071.keys()]
        if tmpe not in tmp_list:
            cells(adt.ws, f"E{i}", "1071不存在该岗位编号，请检查", RED)
            continue
        tmp107, tmpr = values_1071[tmpe], cel(adt.ws, f"R{i}")[:1]
        if not ((tmp107[0] == tmp107[1][:1] == tmpr) or (tmp107[0] == tmpr == "3" and tmp107[1][:1] == "4")):
            cells(adt.ws, f"E{i}", "请检查岗位分类序列和薪酬标杆信息", RED)

        # 17  检验入职模板中人员子组、职位序列、层级符合逻辑
        tmph, tmpi, tmpt = cel(adt.ws, f"H{i}").split()[0], cel(adt.ws, f"I{i}"), cel(adt.ws, f"T{i}")
        tmpr, tmps = cel(adt.ws, f"R{i}"), cel(adt.ws, f"S{i}")
        if tmpt not in rule_U_V_W.keys() or rule_U_V_W[tmpt][0] != tmpr or rule_U_V_W[tmpt][1] != tmps:
            cells(adt.ws, f"I{i}", "职位序列层次级别信息不匹配", RED)
        if tmph[0] in ['A', 'B', 'C'] and tmpi in rule_L_M.keys() and tmpr != rule_L_M[tmpi]:
            cells(adt.ws, f"I{i}", "请检查人员子组和职位序列信息", RED)
        if tmph[0] == 'M' and tmpi[:2] not in ['61', '62', '63']:
            cells(adt.ws, f"I{i}", "人员组和人员子组不匹配", RED)

        # 16  检查模板有长度要求的字段符合要求
        if len(cel(adt.ws, f"Z{i}")) > 40:
            cells(adt.ws, f"Z{i}", "请检查数据长度超长", RED)
        if len(cel(adt.ws, f"BD{i}")) > 18:
            cells(adt.ws, f"BD{i}", "请检查数据长度超长", RED)
        if len(cel(adt.ws, f"BO{i}")) > 40:
            cells(adt.ws, f"BO{i}", "请检查数据长度超长", RED)

        # 15  检验入职时间是否符合要求
        tmpc = cel(adt.ws, f"C{i}")[:8]
        try:
            time.strptime(tmpc, '%Y%m%d')
            current_date = time.strftime("%d", time.localtime(time.time()))
            current_month = time.strftime("%Y%m01", time.localtime(time.time()))
            next_month = time.strftime("%Y%m01", time.localtime(time.time() + (32 - int(current_date)) * 24 * 60 * 60))
            if tmpc not in [current_month, next_month]:
                cells(adt.ws, f"C{i}", "请核查此数值是否为有效入职时间", RED)
            if i != 7 and cel(adt.ws, f"C{i - 1}")[:8] != tmpc:
                cells(adt.ws, f"C{i}", "请核查此数值是否为有效入职时间", RED)
            if tmp_dict[cel(adt.ws, f"B{i}")] > int(tmpc):
                cells(adt.ws, f"C{i}", "学历模板毕业日期不应晚于入职模板的入职时间", RED)
        except Exception:
            cells(adt.ws, f"C{i}", "请核查此数值是否为有效入职时间", RED)

        # 14  检验入职模板【BF】列身份证是否有重复
        tmpbf_lt = [cel(adt.ws, f"BF{x}") for x in range(i + 1, len(adt.ws["A"]) + 2)]
        if cel(adt.ws, f"BF{i}") in tmpbf_lt:
            cells(adt.ws, f"BF{i}", "请检查人员身份证重复", RED)
            cells(adt.ws, f"BF{tmpbf_lt.index(cel(adt.ws, f'BF{i}')) + i + 1}", "请检查人员身份证重复", RED)
        # if len(cel(adt.ws, f"BF{i}").replace(" ", '')) != 18:
        #     cells(adt.ws, f"BF{i}", "请检查人员身份证号长度", RED)
        if validator.get_info(cel(adt.ws, f"BF{i}")) is False:
            cells(adt.ws, f"BF{i}", "请检查人员身份证号是否无效", RED)

        # 13  检验入职所有相关模板中必填项内容不为空
        for j in [get_column_letter(x) for x in range(1, 80)]:
            if "X" in cel(adt.ws, f"{j}3") and not cel(adt.ws, f'{j}{i}'):
                cells(adt.ws, f'{j}{i}', "此单元格为必填项", RED)

        # 10  检验模板中人事范围、人事子范围、工资核算范围是否匹配
        # 11  填写工资总额控制范围
        tmp_var = ''.join([cel(adt.ws, f"{x}{i}")[:y] for x, y in {"F": 4, "G": 4, "K": 2}.items()])
        if tmp_var in rule_AA_AH.keys():
            if not cel(adt.ws, f"O{i}"):
                adt.ws[f"O{i}"] = rule_AA_AH[tmp_var].strip()
        elif "00" == cel(adt.ws, f"K{i}")[:2]:
            pass
        else:
            cells(adt.ws, f"K{i}", "工资核算范围与人事范围、人事子范围不匹配，请核实", RED)
            cells(adt.ws, f"O{i}", "工资总额控制范围无匹配，请检查", RED)
        tmpv, tmpu = cel(adt.ws, f"V{i}"), cel(adt.ws, f"U{i}")
        if tmpv == "30 中层管理" or (tmpv[:2].isdigit() and int(tmpv[:2]) < 50 and tmpu == "2 专业技术人员"):
            cells(adt.ws, f"O{i}", "请注意检查中层及专家人员的工资总额控制范围", BLUE)

        # 20  检查岗位编号下是否已经分配有人员
        tmp_flag = True
        if string == "大学生入职":
            if not ("P" in values_1071[tmpe][2] and values_1071[tmpe][5] == cel(adt.ws, f"CD{i}").lstrip("0")):
                cells(adt.ws, f"E{i}", "此岗位未分配人员，请检查", RED)
        elif "P" in values_1071[tmpe][2]:
            with DbSession() as s:
                sr, name = os.path.basename(file_name).split("-")[0], cel(adt.ws, f"B{i}")
                res = s.query(RZLog_detail).filter(and_(RZLog_detail.sr == sr, RZLog_detail.name == name))
                if len(res.all()) == 1 and res.first().code:
                    adt.ws[f"CA{i}"] = adt.ws[f"CD{i}"] = res.first().code
                    tmp_flag = False
                else:
                    cells(adt.ws, f"E{i}", "此岗位已经分配有人员，请检查", RED)

        # 15  检验入职模板【BF】列身份证是否在SAP中
        tmpbf = cel(adt.ws, f"BF{i}")
        if string == "员工入职" and tmpbf in values_103.keys():
            if values_103[tmpbf][0] != "None" and not cel(adt.ws, f"CD{i}"):
                if "减册人员" != values_103[tmpbf][-1] and "离退休" not in values_103[tmpbf][-1] and tmp_flag:
                    cells(adt.ws, f"BF{i}", "系统中已有此人员，请注意检查", RED)

        # 21  检查岗位信息是否完整
        if values_1071[tmpe][3]:
            cells(adt.ws, f"E{i}", "此岗位信息不完整，请检查", RED)

        # 22  检查事件原因、人员组和岗位信息逻辑关系
        tmpd, tmph = cel(adt.ws, f"D{i}"), cel(adt.ws, f"H{i}")
        if 'A 原正式职工' in tmph:  # 20210125 临时增加A类人员管控
            cells(adt.ws, f"D{i}", "A类人员入职严格管控，请核实!", RED)
        if ((tmpd == "39 招录的核心业务普通岗位人员" and tmph == "B 合同制员工" and values_1071[tmpe][4][:1] != "C") or
                (tmph == "C 派遣制员工" and values_1071[tmpe][4] not in ["B2", "C2"])):
            cells(adt.ws, f"D{i}", "人员组与岗位信息不匹配", RED)
        if tmph == "B 合同制员工" and tmpd[:2] != "39":
            cells(adt.ws, f"D{i}", "B合同制员工入职操作受管控！", BLUE)

        # 23  检查机构名称
        if tmpe in values_1072.keys() and values_1072[tmpe][3] not in cel(adt.ws, f"CM{i}").strip():
            cells(adt.ws, f"CM{i}", "请核实入职机构名称", BLUE)

        # 24  检查人员组与人员子组是否匹配
        tmpi = cel(adt.ws, f"I{i}").split()[0]
        if (tmph == "B" and tmpi not in ["12", "13", "14", "15", "16", "17", "21", "22"]) or \
                (tmph == "M" and tmpi not in ["61", "62", "63"]):
            cells(adt.ws, f"H{i}", "请检查人员组与人员子组是否匹配", RED)

        # 12  检验入职所有相关模板有码表的均符合码表规则
        for key, value in ruledict.items():
            if not cel(adt.ws, (i, key)):
                continue
            if cel(adt.ws, (i, key)).replace(" ", "") not in value:
                cells(adt.ws, (i, key), "单元格数据不是码值", BLUE if key == 99 else RED)
        # 25  检查AN-国籍
        # 26  提取机构全称
        if tmpe in values_1072.keys():
            adt.ws[f"DD{i}"] = values_1072[tmpe][4]

        # # 校验H-人员组与I-人员子组是否对应
        tmph, tmpi = cel(adt.ws, f"H{i}"), cel(adt.ws, f"I{i}")[:2]
        if tmph in rule_hi.keys():
            if tmpi not in rule_hi[tmph]:
                cells(adt.ws, f"H{i}", f"该人员组对应的人员子组只能在以下范围：{rule_hi[tmph]}", RED)
        else:
            cells(adt.ws, f"H{i}", f"码表库中没有该人员组", RED)
        c = None
        for date_col in ['C', 'AJ', 'BG', 'BH', 'BI', 'BJ', 'BK', 'BL', 'BM', 'BN', 'CH', 'CL', 'CS', 'CZ']:
            date = cel(adt.ws, f"{date_col}{i}")[:8]
            if not date:
                continue
            d = str_to_date(date)
            if date_col == 'C':
                c = d
            if d is None:
                cells(adt.ws, f"{date_col}{i}", "异常日期值", RED)
            elif c is not None:
                if date_col in ['BI', 'BJ', 'BK', 'BL', 'BM', 'BN']:
                    if (d - c).days > 15:
                        cells(adt.ws, f"{date_col}{i}", "特殊日期和入职时间逻辑错误", RED)
                elif date_col != 'BH' and (d - c).days > 0:
                    cells(adt.ws, f"{date_col}{i}", "日期晚于入职时间", RED)
    adt.wb.save(file_name)
    for r in range(7, len(adt.ws["A"]) + 1):
        for c in range(1, adt.ws.max_column):
            if adt.ws.cell(r, c).fill.fgColor.rgb == f"00{RED}":
                flag_dict[True].append(f"入{get_column_letter(c)}{r}")
    if True in flag_dict.keys():
        cells(adt.ws, "A1", f"校验未通过的模板单元格：{flag_dict[True]}", RED)
        adt.wb.save(file_name)
    logging.info(f"True: {flag_dict[True]}" if True in flag_dict.keys() else "模板检查完毕，可执行事件。")
    return True if True in flag_dict else False, file_name


def export_1071_1072(name_dict, date, dir_path):
    logging.warning(name_dict.keys())
    li = [str(int(value)) for value in name_dict.keys()]
    export_1071(None, li, date).save_to(FILE_PATH)
    shutil.move(os.path.join(FILE_PATH, "模板_1071.xlsx"), os.path.join(dir_path, "1071.xlsx"))
    export_1072("reuse", li, date).save_to(FILE_PATH)
    shutil.move(os.path.join(FILE_PATH, "模板_1072.xlsx"), os.path.join(dir_path, "1072.xlsx"))

    wb_1071 = load_workbook(os.path.join(dir_path, "1071.xlsx"))
    ws_1071 = wb_1071.active
    values_1071 = defaultdict(list)
    for i in range(2, len(ws_1071["A"]) + 1):
        if str(ws_1071["B%s" % str(i)].value) == "S":
            p, q, s, u, w, y, k, z, ac = [ws_1071[x + str(i)].value for x in
                                          ["P", "Q", "S", "U", "W", "Y", "K", "Z", "AC"]]
            if bool((str(p).strip() in ["1", "2"] and q and s) or (str(p).strip() == "3" and u and w and y) and (
                    k and z and ac)):
                tmp_flag = False
            else:
                tmp_flag = True
            tmp_list = [cel(ws_1071, f"P{i}"),
                        cel(ws_1071, f"Z{i}") + " " + cel(ws_1071, f"AA{i}"),
                        cel(ws_1071, f"B{i + 1}"), tmp_flag, cel(ws_1071, f"K{i}")[:2],
                        cel(ws_1071, f"A{i + 1}").lstrip("0")]
            values_1071[cel(ws_1071, f"A{i}").lstrip("0")] = tmp_list

    tmp_dict = {res.db_AS[0:4]: str(res.db_AS).rstrip() for res in Query(table=Event) if res.db_AS}
    tmp_dict.update({"": ""})
    wb_1072 = load_workbook(os.path.join(dir_path, "1072.xlsx"))
    ws_1072 = wb_1072.active
    values_1072 = defaultdict(list)
    for i in range(2, len(ws_1072["A"]) + 1):
        if str(ws_1072["B%s" % str(i)].value) == "S" and str(ws_1072["B%s" % str(i + 1)].value) == "O":
            if cel(ws_1072, f"P{i + 1}") not in tmp_dict.keys():
                continue
            tmp_list = [tmp_dict[cel(ws_1072, f"P{i + 1}")],
                        cel(ws_1072, f"Q{i + 1}") + " " + cel(ws_1072, f"R{i + 1}"),
                        cel(ws_1072, f"M{i + 1}") + " " + cel(ws_1072, f"N{i + 1}"),
                        cel(ws_1072, f"G{i + 1}"), cel(ws_1072, f"H{i + 1}")]
            values_1072[cel(ws_1072, f"A{i}").lstrip("0")] = tmp_list
    return values_1071, values_1072


def get_card_info(card_dict, dir_path):
    string = "\r\n".join([value for value in card_dict.keys() if value])
    if string:
        export_card_info(string)

    if os.path.exists(os.path.join(FILE_PATH, "tmp-card.xlsx")):
        shutil.move(os.path.join(FILE_PATH, "tmp-card.xlsx"), os.path.join(dir_path, "103.xlsx"))
    else:
        return {}

    wb_103 = load_workbook(os.path.join(dir_path, "103.xlsx"))
    ws_103 = wb_103.active
    values_103 = defaultdict(list)
    for i in range(2, len(ws_103["A"]) + 1):
        tmp_list = [str(ws_103["%s%s" % (x, str(i))].value) for x in [chr(y) for y in range(65, 78)]]
        values_103[str(ws_103["K%s" % str(i)].value).lstrip("0")] = tmp_list
    return values_103
