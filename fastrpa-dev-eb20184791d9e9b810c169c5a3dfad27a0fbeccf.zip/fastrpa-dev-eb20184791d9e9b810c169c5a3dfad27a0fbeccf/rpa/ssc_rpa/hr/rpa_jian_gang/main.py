"""建岗RPA
   ------------------
   入口函数说明：
       main()         销售建岗事件RPA主函数
       main_4_1_01()  岗位池主函数（主要功能：1、维护SRC、DST岗位池，2、定界ERR废弃岗位），只开放给管理员账号
       main_5_1_01()  前置检查
       main_6_1_01()  独立模块-1：再次批导B007S3
       main_6_2_01()  独立模块-2：再次批导A003SO
       main_6_3_01()  独立模块-3：定界岗位（【岗位定界模板-【H-定界对象】】为“定界_岗位”，执行此功能）
       main_6_4_01()  独立模块-4：定界岗位财科：不含主成本中心（【岗位定界模板-【H-定界对象】】为“定界_岗位财科_不含主成本中心”，执行此功能）
   ------------------
   同时存在SRC、DST、ERR三个机构
       1、SRC机构负责创建新岗位，直至SRC机构岗位数不低于2500个
       2、SRC机构超过2500个岗位时，DST机构READY岗位数低于2500个时，从SRC机构迁移2500个岗位至DST机构下
       3、DST机构批导003SO模板失败时，将岗位调至ERR机构下
       4、ERR机构下，超过1个月未调走的岗位，执行PPOSE对岗位进行定界
"""
import logging
import re
import uuid
from pathlib import Path
from time import sleep
from typing import Dict, Iterable, List, Optional, Tuple

import pyperclip
import rpa.config
from openpyxl import load_workbook
from pandas import DataFrame
from rpa.fastrpa import ftp
from rpa.fastrpa.adtable import AdTable, load_from_xlsx_file
from rpa.fastrpa.date_funcs import (day_before, hhmmss, month_01, month_end,
                                    next_month_01, prev_month_01, to_yyyymmdd,
                                    today_yyyymmdd, valid_date)
from rpa.fastrpa.log import config, logfn
from rpa.fastrpa.myredis import MyRedis
from rpa.fastrpa.named_lock import ClipboardLock
from rpa.fastrpa.sap.session import SAP, SapSession
from rpa.fastrpa.tempdir import gentempdir
from rpa.fastrpa.utils.peek_encoding import peek_file_encoding
from rpa.ssc.hr.orm.dims_utils import load_tb_dim_hr_diao_pei
from rpa.ssc.hr.orm.session import DbSession
from rpa.ssc.hr.orm.tb_hr_job_bucket import JOB_STATUS, TB_HR_JOB_BUCKET
from rpa.ssc.hr.rpa_dir import get_rpa_dir
from rpa.ssc.hr.sap.export_1074 import export_1074
from rpa.ssc.hr.sap.import_xlsx import import_single_adtable
from rpa.ssc.hr.sap.refresh_user_data import refresh_user_data

# 机构ID-岗位所在机构
BUCKET_SRC_ORG_ID = '12000023'  # (A)机构ID-在此机构下新建岗位，并迁移至BUCKET_DST_ORG_ID机构下
BUCKET_DST_ORG_ID = '12000024'  # (B)机构ID-可使用的空岗（批导2.1.8失败，将失败未调走的岗位迁移至BUCKET_ERR_ORG_ID机构下）
BUCKET_ERR_ORG_ID = '12000026'  # (C)超过1个月未调走的岗位，执行PPOSE对岗位进行定界
BUCKET_MAX_JOBS_COUNT = 2500  # 机构池岗位数量上限

# 待上传FTP的文件
FTP_FILES: Dict[str, Optional[AdTable]] = {}

# 销售建岗批导模板
TEMPLATE_XIAOSHOU_JIANGANG_PATH = Path(rpa.config.TEMPLATE_DIR).joinpath('建岗模板/销售建岗')
TEMPLATE_1000_HR_BI_1000S = TEMPLATE_XIAOSHOU_JIANGANG_PATH.joinpath('01.1000_HR_BI_1000S--人员导入--创建（职务）岗位具体名称（S）.xlsx').as_posix()
TEMPLATE_9019_HR_BI_9019 = TEMPLATE_XIAOSHOU_JIANGANG_PATH.joinpath('02.9019_HR_BI_9019--人员导入--岗位分类信息-33150000.xlsx').as_posix()
TEMPLATE_1001_HR_BI_B007SC = TEMPLATE_XIAOSHOU_JIANGANG_PATH.joinpath('03.1001_HR_BI_B007SC--人员导入--关系_S_C_B007.xlsx').as_posix()
TEMPLATE_1001_HR_BI_A011SK = TEMPLATE_XIAOSHOU_JIANGANG_PATH.joinpath('04.1001_HR_BI_A011SK--人员导入--HR_BI_A011SK.xlsx').as_posix()
TEMPLATE_1018_HR_BI_1018S = TEMPLATE_XIAOSHOU_JIANGANG_PATH.joinpath('05.1018_HR_BI_1018S--人员导入--成本分配_S--X240.xlsx').as_posix()
TEMPLATE_1001_HR_BI_A012SO = TEMPLATE_XIAOSHOU_JIANGANG_PATH.joinpath('06.1001_HR_BI_A012SO--人员导入--关系_S_O_A012.xlsx').as_posix()
TEMPLATE_1001_HR_BI_B007S3 = TEMPLATE_XIAOSHOU_JIANGANG_PATH.joinpath('07.1001_HR_BI_B007S3--人员导入--创建关系_S_03_B007.xlsx').as_posix()
TEMPLATE_1001_HR_BI_A003SO = TEMPLATE_XIAOSHOU_JIANGANG_PATH.joinpath('08.1001_HR_BI_A003SO--人员导入--指定岗位的隶属机构.xlsx').as_posix()
TEMPLATE_1000_HR_BI_1000SC = TEMPLATE_XIAOSHOU_JIANGANG_PATH.joinpath('21.1000_HR_BI_1000SC--人员导入--职务（岗位）具体名称（S)定界.xlsx').as_posix()
TEMPLATE_1001_HR_A011_SKCU = TEMPLATE_XIAOSHOU_JIANGANG_PATH.joinpath('24.1001_HR_A011_SKCU--人员导入--岗位主成本中心_定界.xlsx').as_posix()
TEMPLATE_1018_HR_BI_1018CU = TEMPLATE_XIAOSHOU_JIANGANG_PATH.joinpath('25.1018_HR_BI_1018CU--人员导入--成本分配定界（S）--X420.xlsx').as_posix()

# 码表表头
TEMPLATE_DIMS_HEADERS = {'A3': '编号',
                         'B3': '机构',
                         'C3': '职务岗位码',
                         'D3': '职务（岗位）',
                         'E3': '岗位简称',
                         'F3': '薪酬标杆',
                         'G3': '所属专业大类',
                         'H3': '所属专业小类',
                         'I3': '所属工种大类',
                         'J3': '所属工种小类',
                         'K3': '岗位工时制',
                         'L3': '岗位类别-A-关键岗位',
                         'M3': '岗位类别-B1-非辅助性主体岗位',
                         'N3': '岗位类别-B2-辅助性主体岗位',
                         'O3': '岗位类别-C0-销售企业特定普通岗位',
                         'P3': '岗位类别-C1-非辅助性普通岗位',
                         'Q3': '岗位类别-C2-辅助性普通岗位',
                         'R3': '职位序列',
                         'S3': '职位级别',
                         'T3': '行政党派职务信息',
                         'U3': '报表提取位置',
                         'V3': '油品销售企业定员标准未覆盖标识（计划删除）',
                         'W3': '销售企业特有属性',
                         'X3': '备注', }

# 模板表头
TEMPLATE_HEADERS = {'A1': '成功标识',
                    'A2': 'RPA生成',
                    'A3': '成功',
                    'B1': '岗位编码',
                    'B2': 'RPA生成',
                    'B3': '12345678',
                    'C1': '调动后机构名称',
                    'C2': 'RPA生成',
                    'C3': '人力资源部',
                    'D1': '序号',
                    'D2': '填写说明',
                    'D3': '取值举例',
                    'E1': '岗位所在机构编码',
                    'E2': '必填，文本长度为8位',
                    'E3': '10000026',
                    'F1': '开始日期',
                    'F2': '必填，8位，上月、当月或次月1日',
                    'F3': '20200801',
                    'G1': '岗位简称',
                    'G2': '必填，文本长度不超过12个汉字',
                    'G3': '人力资源部部长',
                    'H1': '岗位全称',
                    'H2': '必填，文本长度不超过40个汉字',
                    'H3': '人力资源部部长',
                    'I1': '岗位目录编号',
                    'I2': '必填，从各目录-【A-编号】复制',
                    'I3': '01-01-07-01',
                    'J1': '职务岗位码不填标识',
                    'J2': '选填，若岗位不需职务岗位码，填写“不填”，默认为空',
                    'J3': '不填',
                    'K1': '岗位类别',
                    'K2': '虚岗位不填，实岗位必填，填写“代码”',
                    'K3': 'C0',
                    'L1': '虚岗位标识',
                    'L2': '选填，X，默认为空',
                    'L3': 'X',
                    'M1': '油品销售企业定员标准未覆盖标识',
                    'M2': '选填，X，默认为空',
                    'M3': 'X',
                    'N1': '班组长标识',
                    'N2': '选填，X，默认为空',
                    'N3': 'X',
                    'O1': '岗位财科_公司代码',
                    'O2': '选填，填写“代码”，不填不维护',
                    'O3': 'X420',
                    'P1': '岗位财科_人事范围',
                    'P2': '选填，填写“代码”，不填不维护',
                    'P3': 'X420',
                    'Q1': '岗位财科_人事子范围',
                    'Q2': '选填，填写“代码+空格+文本”，不填不维护',
                    'Q3': '0001 湖北石油管理机关',
                    'R1': '岗位财科_业务范围',
                    'R2': '选填，填写“代码”，不填不维护',
                    'R3': '4000',
                    'S1': '岗位财科_成本中心',
                    'S2': '选填，长度为10位，不填不维护',
                    'S3': '8XSD013202',
                    'T1': '岗位成本分配_成本中心',
                    'T2': '选填，长度为10位，不填不维护',
                    'T3': '8XSD013202',
                    'U1': '岗位分类序列',
                    'U2': 'RPA生成',
                    'U3': '1 管理序列',
                    'V1': '薪酬标杆',
                    'V2': 'RPA生成',
                    'V3': '105 经营管理岗位其他',
                    'W1': '所属专业大类',
                    'W2': 'RPA生成',
                    'W3': '11 油气勘探',
                    'X1': '所属专业小类',
                    'X2': 'RPA生成',
                    'X3': '01 古生物学与地层学',
                    'Y1': '所属工种大类',
                    'Y2': 'RPA生成',
                    'Y3': '01 物探',
                    'Z1': '所属工种小类',
                    'Z2': 'RPA生成',
                    'Z3': '01001 可控震源操作工 ',
                    'AA1': '岗位工时制',
                    'AA2': 'RPA生成',
                    'AA3': '1 标准工时制 ',
                    'AB1': '03码',
                    'AB2': 'RPA生成',
                    'AB3': '90000195 经营管理类A',
                    'AC1': '职务岗位码',
                    'AC2': 'RPA生成',
                    'AC3': '00200003', }


@logfn
def update_bucket_dst_job_count(bucket_dst_org_id: str = BUCKET_DST_ORG_ID) -> int:
    """更新redis"""
    with DbSession() as db_session:
        bucket_dst_ready_jobs_count = db_session.query(TB_HR_JOB_BUCKET).filter(TB_HR_JOB_BUCKET.parent_org_id == bucket_dst_org_id,
                                                                                TB_HR_JOB_BUCKET.job_status == JOB_STATUS.READY.value).count()
        with MyRedis() as my_redis:
            my_redis.set('建岗:DST机构:岗位数', bucket_dst_ready_jobs_count)  # 更新Redis中DST机构下岗位数
            my_redis.set('建岗:DST机构:机构号', bucket_dst_org_id)  # 更新Redis中DST机构下岗位数
            return bucket_dst_ready_jobs_count


def get_bucket_dst_job_count(bucket_dst_org_id: str = BUCKET_DST_ORG_ID) -> int:
    """"获取redis中机构DST岗位数"""
    with MyRedis() as my_redis:
        bucket_dst_job_count = my_redis.get('建岗:DST机构:岗位数')
        if isinstance(bucket_dst_job_count, str) and bucket_dst_job_count.isdigit():
            return int(bucket_dst_job_count)
        return 0


@logfn
def save_files_to_dir(templates: Iterable[AdTable], output_dir: str):
    for _lt in templates:
        if isinstance(_lt, AdTable):
            _lt.save_to(output_dir)


@logfn
def upload_to_ftp(templates: Iterable[AdTable], subticket_title: str, is_succ: bool) -> str:
    """只要调入模板有任一单元格填充红色，终止程序执行，上传到F_in【“调入”】-【“失败”】文件夹下；若无，继续执行下一规则。
    """
    yyyymmdd = today_yyyymmdd()
    yyyymm = yyyymmdd[:6]
    _hhmmss = hhmmss()
    is_succ_str = '成功' if is_succ is True else '失败'
    failed_ftp_path = Path(f'/HR人事/销售建岗/{yyyymm}/{yyyymmdd}/{_hhmmss}_{is_succ_str}_{subticket_title}').as_posix()
    temp_dir = get_rpa_dir('销售建岗', subticket_title, is_succ)
    # logging.info(f'创建本地文件夹：{temp_dir}')
    filenames = []
    for template in templates:
        if isinstance(template, AdTable):
            try:
                filename = template.save_to(temp_dir)
                filenames.append(filename)
            except (FileNotFoundError, PermissionError):
                logging.error('文件生成失败')
    ftp.upload_files(filenames, failed_ftp_path)
    return temp_dir


@logfn
def chk_1_1_01_20210620(lt: AdTable) -> bool:  # 校验销售企业建岗模板
    """清除“销售企业建岗模板”上所有的批注及单元格颜色。"""
    lt.clear_all_fgcolors()
    lt.clear_all_comments()
    return True


@logfn
def chk_1_1_02_20210620(filename: str) -> bool:  # 校验文件名称
    """校验文件名格式
       ------------------
       单号-人事范围代码-销售建岗-业务人员姓名    或
       无单号-人事范围代码-销售建岗-业务人员姓名
       ------------------
       1.若“不符合要求”，在【销售企业建岗模板-【A1】】单元格填充红色并插入批注“文件名称错误！”，并退出销售企业建岗RPA程序。
    """
    logging.info('校验文件名称')
    filename_parts: List[str] = Path(filename).stem.split('-')
    if len(filename_parts) >= 4:
        if re.match(r'^\d{10}$', filename_parts[0]) or filename_parts[0] == '无单号':
            if filename_parts[2] == '销售建岗':
                return True
    logging.error('文件名称错误！')
    wb = load_workbook(filename)
    if '销售企业建岗模板' in wb.sheetnames:
        ws = wb['销售企业建岗模板']
    else:
        ws = wb.active
    lt = AdTable(filename, wb, ws, skip_header=3)
    lt['A'][1].cmt('red', '文件名称错误！')
    lt.save(filename)
    return False


@logfn
def chk_1_1_03_20210620(filename: str) -> bool:  # 校验模板表头
    """校验模板表头
       ------------------
       检验表单【A1至U1、A3】是否与标准模板一致，若不一致，见1。
       ------------------
       1.若“不符合要求”，在【销售企业建岗模板-【A2】】单元格填充红色并插入批注“非标准模板！”，并退出销售企业建岗RPA程序。
    """
    logging.info('校验模板表头')
    lt = load_from_xlsx_file(filename, '销售企业建岗模板', skip_header=3)
    is_check_passed = True
    for cell_pos in TEMPLATE_HEADERS.keys():
        if lt.cell_at(cell_pos).value != TEMPLATE_HEADERS[cell_pos]:
            lt.cell_at(cell_pos).cmt('red', '非标准模板，应为: ' + TEMPLATE_HEADERS[cell_pos])
            is_check_passed = False
    if is_check_passed is False:
        lt['A'][2].cmt('red', '非标准模板！')
    lt.save(filename)
    return is_check_passed


@logfn
def chk_1_1_04_20210630(filename: str) -> bool:  # 校验岗位目录表头
    """校验岗位目录表头
       ------------------
       检验各岗位目录【B1、A3至X3】是否与标准模板一致，若不一致，见1。
       ------------------
       1.若“不符合要求”，在【销售企业建岗模板-【A3】】单元格填充红色并插入批注“非标准岗位目录！”，并退出销售企业建岗RPA程序。
    """
    is_check_passed = True
    wb = load_workbook(filename)
    for sheetname in ['销售机关', '省级机关职能处室及专业中心', '地市机关职能及专业部室', '大区公司及成品油管道']:
        if sheetname not in wb.sheetnames:
            is_check_passed = False
            logging.error(f'文件缺失sheet页[{sheetname}]')
        else:
            ws = wb[sheetname]
            lt = AdTable(filename, wb, ws, skip_header=3)
            if f'标准岗位目录--{sheetname}' not in lt['B'][1].value:
                logging.error(f'sheet页[{sheetname}]B1单元格值不为[标准岗位目录--{sheetname}]')
                is_check_passed = False
            else:
                for cell_pos in TEMPLATE_DIMS_HEADERS.keys():
                    if lt.cell_at(cell_pos).value != TEMPLATE_DIMS_HEADERS[cell_pos]:
                        is_check_passed = False
                        lt.cell_at(cell_pos).cmt('red', '非标准模板，应为: ' + TEMPLATE_DIMS_HEADERS[cell_pos])
    lt.save(filename)
    return is_check_passed


@logfn
def chk_1_1_05_20210701(filename: str) -> None:  # 清空信息
    """清空信息
       ------------------
       ------------------
       1.清空【销售企业建岗模板-【A至C、U至AC】】的值。
    """
    lt = load_from_xlsx_file(filename, '销售企业建岗模板', skip_header=3)
    df = lt.to_dataframe()
    for rn in df.index:
        lt['A'][rn].value = ''
        lt['B'][rn].value = ''
        lt['C'][rn].value = ''
    lt.save(filename)


def chk_1_2_01_20210620(df: DataFrame, lt: AdTable, rn: int) -> bool:  # 校验机构编号码值性
    """校验机构编码
       ------------------
       清除【销售企业建岗模板-【E-岗位所在机构编码】】除数字以外的任何字符（清除空格等符号），再检验其值是否等于8位。
       ------------------
       1.若值“不符合条件”，在【销售企业建岗模板-【E-岗位所在机构编码】】】单元格填充红色并插入批注“机构编码有误！”。
    """
    new_value = ''.join([v for v in df['E'][rn] if v.isdigit()])
    lt['E'][rn].value = new_value
    if len(new_value) == 8:
        return True
    lt['E'][rn].cmt('red', '机构编码有误！')
    return False


def chk_1_2_02_20210620(df: DataFrame, lt: AdTable, rn: int) -> bool:  # 校验事件执行日期逻辑性
    """校验开始日期
       ------------------
       检验【销售企业建岗模板-【F-执行时间】】是否为当月1日或者次月1日，若不是，检验是否为上月1日，若是，见1，若不是，见2。
       ------------------
       1.为“是”，在【销售企业建岗模板-【F-执行时间】】单元格填充蓝色并插入批注“事件执行日期为上月1日，请核对！”；
       2.为“不是”，在【销售企业建岗模板-【F-执行时间】】单元格填充红色并插入批注“事件执行日期有误！”。
    """
    prevmonth01 = prev_month_01()
    yyyymm01 = month_01()
    nextmonth01 = next_month_01()
    if rn >= 5 and df['F'][rn] != df['F'][rn - 1]:
        lt['F'][rn].cmt('red', '同一模板事件执行日期应相同')
        return False
    if valid_date(df['F'][rn]) is False:
        lt['F'][rn].cmt('red', '不是合法的8位日期')
        return False
    if df['F'][rn] in [yyyymm01, nextmonth01]:
        return True
    elif df['F'][rn] == prevmonth01:
        lt['F'][rn].cmt('blue', '事件执行日期为上月1日，请核对！')
        return True
    else:
        lt['F'][rn].cmt('red', '事件执行日期有误！')
        return False


def chk_1_2_03_20210620(df: DataFrame, lt: AdTable, rn: int) -> bool:  # 校验岗位简称长度
    """校验岗位简称
       ------------------
       检验【销售企业建岗模板-【G-岗位简称】】是否小于等于12个字符，若不是，见1。
       ------------------
       1.为“不是”，在【销售企业建岗模板-【G-岗位简称】】单元格填充红色并插入批注“岗位简称超长！”。
    """
    if len(df['G'][rn]) <= 12:
        return True
    else:
        lt['G'][rn].cmt('red', '岗位简称超长！')
        return False


def chk_1_2_04_20210620(df: DataFrame, lt: AdTable, rn: int) -> bool:  # 校验岗位全称长度
    """校验岗位全称
       ------------------
       检验【销售企业建岗模板-【H-岗位全称】】是否小于等于40个字符，若不是，见1。
       ------------------
       1.为“不是”，在【销售企业建岗模板-【H-岗位全称】】单元格填充红色并插入批注“岗位全称超长！”。
    """
    if len(df['H'][rn]) <= 40:
        return True
    else:
        lt['H'][rn].cmt('red', '岗位全称超长！')
        return False


def chk_1_2_05_20210620(df: DataFrame, lt: AdTable, rn: int, df_dims_prov: DataFrame, df_dims_city: DataFrame, df_dims_area: DataFrame) -> bool:  # 检验岗位目录编号存在性
    """检验企业岗位目录编号
       ------------------
       当【销售企业建岗模板-【I-岗位目录编号】】的值不为空时，提取其值，检验其长度是否为11位，若不是，见1；
       若是，若前两个字符为“01”，在【省级机关职能处室及专业中心-【A-编号】】检验是否存在；若前两个字符为“02”，在【地市机关职能及专业部室-【A-编号】】检验是否存在；
       若前两个字符为“03”，在【大区公司及成品油管道-【A-编号】】中检验是否存在，若不存在，见1。
       ------------------
       1.为“不存在”，在相应的【销售企业建岗模板-【I-岗位目录编号】】单元格填充红色并插入批注“岗位目录编号有误！”。
    """
    is_check_passed = True
    _i = df['I'][rn]
    if _i != '':
        if len(_i) != 11:
            is_check_passed = False
        elif _i.startswith('01') and _i in df_dims_prov['A'].values:
            pass
        elif _i.startswith('02') and _i in df_dims_city['A'].values:
            pass
        elif _i.startswith('03') and _i in df_dims_area['A'].values:
            pass
        else:
            is_check_passed = False
    if is_check_passed is False:
        lt['I'][rn].cmt('red', '岗位目录编号有误！')
    return is_check_passed


def chk_1_2_06_20210620(df: DataFrame, lt: AdTable, rn: int) -> bool:  # 校验必填项
    """检验必填项
       ------------------
       检验【销售企业建岗模板-【E、F、G、H、I】】的值全部有值，若不是，见1。
       ------------------
       1.为“不是”，在相应的【销售企业建岗模板-【E、F、G、H、I】】单元格填充红色并插入批注“必填项不能为空！”。
    """
    is_check_passed = True
    for column_letter in ['E', 'F', 'G', 'H', 'I']:
        if df[column_letter][rn].strip() == '':
            lt[column_letter][rn].cmt('red', '必填项不能为空！')
            is_check_passed = False
    return is_check_passed


def chk_1_2_07_20210620(df: DataFrame, lt: AdTable, rn: int) -> bool:  # 检验职务岗位码不填标识码值性
    """检验职务岗位码不填标识
       ------------------
       当【销售企业建岗模板-【J-职务岗位码不填标识】】的值不为空时，检验其值是否为“不填”，若不是，见1。
       ------------------
       1.为“不存在”，在相应的【销售企业建岗模板-【J-职务岗位码不填标识】】单元格填充红色并插入批注“若岗位无需职务岗位码，则标识应为“不填”！”。
    """
    if df['J'][rn] not in ['', '不填']:
        lt['J'][rn].cmt('red', '若岗位无需职务岗位码，则标识应为“不填”！')
        return False
    return True


def chk_1_2_08_20210620(df: DataFrame, lt: AdTable, rn: int, df_dims_prov: DataFrame, df_dims_city: DataFrame, df_dims_area: DataFrame) -> bool:  # 检验岗位类别码值性、逻辑性，提取03码
    """检验岗位类别
       ------------------
       当【销售企业建岗模板-【K-岗位类别】】不为空时，检验其值是为下述【A、B1、B2、C0、C1、C2】之一，若不是，见1；若是，锁定【销售企业建岗模板-【I-岗位目录编号】】，
       在相应的《省级机关职能处室及专业中心》或《地市机关职能及专业部室》或《大区公司及成品油管道》中（方法见1.2.5）锁定相应行，检验岗位类别是否存在（检验方法为：
       根据【销售企业建岗模板-【K-岗位类别】】的值，在相应的列查找是否存在，其中：L列为A，M列为B1，N列为B2，O列为C0，P列为C1，Q列为C2 ），若不存在，见2；若存在，见3。
       ------------------
       1.为“不是”，在【销售企业建岗模板-【K-岗位类别】】单元格填充红色并插入批注“岗位类别只能为【A、B1、B2、C0、C1、C2】之一！”；
       2.为“不是”，在【销售企业建岗模板-【K-岗位类别】】单元格填充红色并插入批注“所填的岗位目录编号无此岗位类别！”；
       3.为“不是”，提取【【L、M、N、O、P、Q 】-符号“-”后的字段】，复制在【销售企业建岗模板-【AB-03码】】单元格填中。
    """
    k_value_column_letter_map = {'A': 'L',
                                 'B1': 'M',
                                 'B2': 'N',
                                 'C0': 'O',
                                 'C1': 'P',
                                 'C2': 'Q'}
    _k: str = df['K'][rn]
    _i: str = df['I'][rn]
    if _k != '':
        if _k not in k_value_column_letter_map.keys():
            lt['K'][rn].cmt('red', '岗位类别只能为【A、B1、B2、C0、C1、C2】之一！')
            return False
        _df_dims: Optional[DataFrame] = None
        if _i.startswith('01'):
            _df_dims = df_dims_prov
        elif _i.startswith('02'):
            _df_dims = df_dims_city
        elif _i.startswith('03'):
            _df_dims = df_dims_area
        if _df_dims is not None:
            _df_tmp = _df_dims[_df_dims['A'] == _i]
            column_letter = k_value_column_letter_map[_k]
            if _df_tmp.empty is False and _df_tmp[column_letter].values[0].startswith(_k):
                lt['AB'][rn].value = _df_tmp[column_letter].values[0][len(_k) + 1:]  # 提取【【L、M、N、O、P、Q 】-符号“-”后的字段
                return True
            else:
                lt['K'][rn].cmt('red', '所填的岗位目录编号无此岗位类别！')
                return False
    return True


def chk_1_2_09_20210620(df: DataFrame, lt: AdTable, rn: int) -> bool:  # 检验虚岗位标识码值性
    """检验虚岗位标识
       ------------------
       当【销售企业建岗模板-【L-虚岗位标识】】的值不为空时，检验其值是否为“X”，若不是，见1。
       ------------------
       1.为“不是”，在相应的【销售企业建岗模板-【L-虚岗位标识】】单元格填充红色并插入批注“码值应为“X”！”。
    """
    if df['L'][rn] not in ['', 'X']:
        lt['L'][rn].cmt('red', '码值应为“X”！')
        return False
    return True


def chk_1_2_10_20210620(df: DataFrame, lt: AdTable, rn: int) -> bool:  # 检验油品销售企业定员标准未覆盖标识码值性
    """检验油品销售企业定员标准未覆盖标识
       ------------------
       当【销售企业建岗模板-【M-油品销售企业定员标准未覆盖标识】】的值不为空时，检验其值是否为“X”，若不是，见1。
       ------------------
       1.为“不是”，在相应的【销售企业建岗模板-【M-油品销售企业定员标准未覆盖标识】】单元格填充红色并插入批注“码值应为“X”！”。
    """
    if df['M'][rn] not in ['', 'X']:
        lt['M'][rn].cmt('red', '码值应为“X”！')
        return False
    return True


def chk_1_2_11_20210620(df: DataFrame, lt: AdTable, rn: int) -> bool:  # 检验班组长标识码值性
    """检验班组长标识
       ------------------
       当【销售企业建岗模板-【N-班组长标识】】的值不为空时，检验其值是否为“X”，若不是，见1。
       ------------------
       1.为“不是”，在相应的【销售企业建岗模板-【N-班组长标识】】单元格填充红色并插入批注“码值应为“X”！”。
    """
    if df['N'][rn] not in ['', 'X']:
        lt['N'][rn].cmt('red', '码值应为“X”！')
        return False
    return True


def chk_1_2_12_20210620(df: DataFrame, lt: AdTable, rn: int) -> bool:  # 检验虚岗位与岗位类别的互斥性
    """检验虚岗位与岗位类别的互斥性
       ------------------
       检验【销售企业建岗模板-【L-虚岗位标识】与【K-岗位类别】】的值是否必有一者为空，若不是，见1。
       ------------------
       1.为“不是”，在相应的【销售企业建岗模板-【L-虚岗位标识】与【K-岗位类别】】单元格填充红色并插入批注“【L-虚岗位标识】与【K-岗位类别】两者必有一者为空！”。
    """
    _l = df['L'][rn]
    _k = df['K'][rn]
    if '' in [_l, _k] and _l != _k:
        return True
    else:
        lt['L'][rn].cmt('red', '【L-虚岗位标识】与【K-岗位类别】两者必有一者为空！')
        lt['K'][rn].cmt('red', '【L-虚岗位标识】与【K-岗位类别】两者必有一者为空！')
        return False


def chk_1_2_13_20210620(df: DataFrame, lt: AdTable, rn: int, df_dims_diao_pei: DataFrame) -> bool:  # 校验公司代码码值性
    """检验岗位财科公司代码
       ------------------
       当【销售企业建岗模板-【O-岗位财科_公司代码】】的值不为空时，检验长度是否为四位，若不是，见1；若是，提取RPA平台个人账号组别，检验其值是否在【调配码表库-【BI（前四位代码） & 相同组别】】中，若不是，见2。
       ------------------
       1.为“不是”，在【销售企业建岗模板-【O-岗位财科_公司代码】】单元格填充红色并插入批注“应为四位代码！”；
       2.为“不是”，在【销售企业建岗模板-【O-岗位财科_公司代码】】单元格填充红色并插入批注“公司代码不存在于调配码表库中，请确认是否码值是否正确，如正确请联系组长补充码表库！”。
    """
    _o = df['O'][rn]
    if _o != '':
        if len(_o) != 4:
            lt['O'][rn].cmt('red', '应为四位代码！')
            return False
        else:
            staff_group = rpa.config.STAFF_GROUP  # 用户组别
            _df_bi = df_dims_diao_pei[df_dims_diao_pei['BL'] == staff_group]['BI']
            for _bi in _df_bi.values:
                if _bi.startswith(_o):
                    return True
            lt['O'][rn].cmt('red', f'公司代码不存在于【{staff_group}调配码表库-BI】中，请确认是否码值是否正确，如正确请联系组长补充码表库！')
            return False
    return True


def chk_1_2_14_20210620(df: DataFrame, lt: AdTable, rn: int, df_dims_diao_pei: DataFrame) -> bool:  # 校验人事范围码值性
    """检验岗位财科人事范围
       ------------------
       当【销售企业建岗模板-【P-岗位财科_人事范围】】的值不为空时，检验长度是否为四位，若不是，见1；
       若是，提取RPA平台个人账号组别，检验其值是否在【调配码表库-【BK（前四位代码）& 相同组别】】中，若不是，见2。
       ------------------
       1.为“不是”，在【销售企业建岗模板-【P-岗位财科_人事范围】】单元格填充红色并插入批注“应为四位代码！”；
       2.为“不是”，在【销售企业建岗模板-【P-岗位财科_人事范围】】单元格填充红色并插入批注“人事范围不存在于调配码表库中，请确认是否码值是否正确，如正确请联系组长补充码表库！”。
    """
    _p = df['P'][rn]
    if _p != '':
        if len(_p) != 4:
            lt['P'][rn].cmt('red', '应为四位代码！')
            return False
        else:
            staff_group = rpa.config.STAFF_GROUP  # 用户组别
            _df_bk = df_dims_diao_pei[df_dims_diao_pei['BL'] == staff_group]['BK']
            for _bk in _df_bk.values:
                if _bk.startswith(_p):
                    return True
        lt['P'][rn].cmt('red', f'公司代码不存在于【{staff_group}调配码表库-BK】中，请确认是否码值是否正确，如正确请联系组长补充码表库！')
        return False
    return True


def chk_1_2_15_20210620(df: DataFrame, lt: AdTable, rn: int) -> bool:  # 检验公司代码与人事范围一致性
    """检验公司代码与人事范围一致性
       ------------------
       当【销售企业建岗模板-【O、P】】的值都不为空时，检验是否相同，若不是，见1。
       ------------------
       1.为“不是”，在相应的【销售企业建岗模板-【O-岗位财科_公司代码、P-岗位财科_人事范围】】单元格填充红色并插入批注“公司代码与人事范围不同！”。
    """
    _o = df['O'][rn]
    _p = df['P'][rn]
    if _o + _p != '':
        if _o != _p:
            lt['O'][rn].cmt('red', '公司代码与人事范围不同！')
            lt['P'][rn].cmt('red', '公司代码与人事范围不同！')
            return False
    return True


def chk_1_2_16_20210620(df: DataFrame, lt: AdTable, rn: int, df_dims_diao_pei: DataFrame) -> bool:  # 校验人事子范围
    """检验岗位财科人事子范围
       ------------------
       当【销售企业建岗模板-【Q-岗位财科_人事子范围】】的值不为空时，先在【调配码表库-【D-人事范围代码】】锁定【销售企业建岗模板-【P-岗位财科_人事范围】】的值
       （若【销售企业建岗模板-【P-岗位财科_人事范围】】为空，跳转下一规则），再检验其值是否在对应的【调配码表库-【E-人事子范围】】中，若不存在，见1。
       ------------------
       1.为“不存在”，在【销售企业建岗模板-【Q-岗位财科_人事子范围】】单元格填充红色并插入批注“人事子范围不存在于调配码表库对应的人事范围中，请确认码值是否正确，如正确请联系组长补充码表库！”。
    """
    _q = df['Q'][rn]
    _p = df['P'][rn]
    if _q != '' and _p != '':
        _df_tmp = df_dims_diao_pei[(df_dims_diao_pei['D'] == _p) & (df_dims_diao_pei['E'] == _q)]
        if _df_tmp.empty is True:
            lt['Q'][rn].cmt('red', '人事子范围不存在于调配码表库对应的人事范围中，请确认码值是否正确，如正确请联系组长补充码表库！')
            return False
    return True


def chk_1_2_17_20210620(df: DataFrame, lt: AdTable, rn: int, df_dims_diao_pei: DataFrame) -> bool:  # 校验业务范围
    """检验岗位财科业务范围
       ------------------
       当【销售企业建岗模板-【R-岗位财科_业务范围】】的值不为空时，检验其值是否为【调配码表库-【BO-业务范围（前四位）】的值，若不是，见1；若是，再检验其值是否为“4000”，若不是，见2。
       ------------------
       1.为“不是”，在【销售企业建岗模板-【R-岗位财科_业务范围】】单元格填充红色并插入批注“业务范围非码值！”；
       2.为“不是”，在【销售企业建岗模板-【R-岗位财科_业务范围】】单元格填充蓝色并插入批注“业务范围不是“4000”，请确认！”。
    """
    _r = df['R'][rn]
    if _r != '':
        for _bo in df_dims_diao_pei['BO'].values:
            if _bo.startswith(_r):
                if _r != '4000':
                    lt['R'][rn].cmt('blue', '业务范围不是“4000”，请确认！')
                    return True
                return True
        else:
            lt['R'][rn].cmt('red', '业务范围非码值！')
            return False
    return True


def chk_1_2_18_20210705(df: DataFrame, lt: AdTable, rn: int) -> bool:  # 检验岗位财科一致性
    """检验岗位财科一致性
       ------------------
       检验【销售企业建岗模板-【O、P、Q、R】】的值是否全部有值或者全部为空，若不是，见1；若全部有值，再检验【销售企业建岗模板-【S-岗位财科_成本中心】】是否为空，若是，见2。
       ------------------
       1.为“不是”，在相应的【销售企业建岗模板-【O、P、Q、R】】单元格填充红色并插入批注“O、P、Q、R四列必须全部有值或者全部为空！”；
       2.为“是”，在【销售企业建岗模板-【S-岗位财科_成本中心】】单元格填充蓝色并插入批注“岗位财科的成本中心为空，请确认！”。
    """
    _o = df['O'][rn]
    _p = df['P'][rn]
    _q = df['Q'][rn]
    _r = df['R'][rn]
    _s = df['S'][rn]
    if '' in [_o, _p, _q, _r] and _o + _p + _q + _r != '':  # 至少有一个为空，且不全为空
        lt['O'][rn].cmt('red', 'O、P、Q、R四列必须全部有值或者全部为空！')  # 1
        lt['P'][rn].cmt('red', 'O、P、Q、R四列必须全部有值或者全部为空！')
        lt['Q'][rn].cmt('red', 'O、P、Q、R四列必须全部有值或者全部为空！')
        lt['R'][rn].cmt('red', 'O、P、Q、R四列必须全部有值或者全部为空！')
        return False
    if '' not in [_o, _p, _q, _r] and _s == '':
        lt['S'][rn].cmt('blue', '岗位财科的成本中心为空，请确认！')  # 2
    return True


def chk_1_2_19_20210620(df: DataFrame, lt: AdTable, rn: int) -> bool:  # 校验岗位财科_成本中心码值性
    """检验岗位财科成本中心
       ------------------
       当【销售企业建岗模板-【S-岗位财科_成本中心】】的值不为空时，检验其是否为10位数字+英文字母的组合，若不是，检验其值是否为10位数字，若不是，见1；若是，见2。
       ------------------
       1.为“不是”，在相应的【销售企业建岗模板-【S-岗位财科_成本中心】】单元格填充红色并插入批注“成本中心码值有误！”；
       2.为“不是”，在相应的【销售企业建岗模板-【S-岗位财科_成本中心】】单元格填充蓝色并插入批注“成本中心码值不为数字+英文字母的组合，请确认！”。
    """
    _s = df['S'][rn]
    if _s != '':
        if re.match(r'\d{10}', _s):
            lt['S'][rn].cmt('blue', '成本中心码值不为数字+英文字母的组合，请确认！')
            return True
        elif re.match('[a-zA-Z0-9]{10}', _s):
            return True
        else:
            lt['S'][rn].cmt('red', '成本中心码值有误！')
            return False
    return True


def chk_1_2_20_20210620(df: DataFrame, lt: AdTable, rn: int) -> bool:  # 校验岗位成本分配_成本中心码值性
    """检验岗位成本分配成本中心
       ------------------
       当【销售企业建岗模板-【T-岗位成本分配_成本中心】】的值不为空时，检验其是否为10位数字+英文字母的组合，若不是，检验其值是否为10位数字，若不是，见1；若是，见2
       ------------------
       1.为“不是”，在相应的【销售企业建岗模板-【T-岗位成本分配_成本中心】】单元格填充红色并插入批注“成本中心码值有误！”；
       2.为“不是”，在相应的【销售企业建岗模板-【T-岗位成本分配_成本中心】】单元格填充蓝色并插入批注“成本中心码值不为数字+英文字母的组合，请确认！”。
    """
    _t = df['T'][rn]
    if _t != '':
        if re.match(r'\d{10}', _t):
            lt['T'][rn].cmt('blue', '成本中心码值不为数字+英文字母的组合，请确认！')
            return True
        elif re.match('[a-zA-Z0-9]{10}', _t):
            return True
        else:
            lt['T'][rn].cmt('red', '成本中心码值有误！')
            return False
    return True


@logfn
def chk_1_2_21_20210620(df: DataFrame, lt: AdTable) -> bool:  # 校验岗位财科_成本中心存在性
    """检验岗位财科成本中心存在性
       ------------------
       当【销售企业建岗模板-【S-岗位财科_成本中心】】不为空且无红色报错时，提取其值，执行KS02，检验其是否存在，若不存在，见1。
       ------------------
       1.为“不存在”，在相应的【销售企业建岗模板-【S-岗位财科_成本中心】】单元格填充红色并插入批注“成本中心尚未建立！”。
    """
    column_s_no_comment = True
    for rn in df.index:
        if df['S'][rn] != '' and lt['S'][rn].comment is not None:
            column_s_no_comment = False
    if column_s_no_comment is True:
        pass
    return column_s_no_comment


@logfn
def chk_1_2_22_20210620(df: DataFrame, lt: AdTable) -> bool:  # 校验岗位成本分配_成本中心存在性
    """检验岗位成本分配成本中心存在性
       ------------------
       当【销售企业建岗模板-【T-岗位成本分配_成本中心】】不为空且无红色报错时，提取其值，执行KS02，检验其是否存在，若不存在，见1。
       ------------------
       1.为“不是”，在相应的【销售企业建岗模板-【T-岗位成本分配_成本中心】】单元格填充红色并插入批注“成本中心码尚未建立！”。
    """
    column_s_no_comment = True
    for rn in df.index:
        if df['T'][rn] != '' and lt['T'][rn].comment is not None:
            column_s_no_comment = False
    if column_s_no_comment is True:
        pass
    return column_s_no_comment


@logfn
def chk_ks02(df: DataFrame, lt: AdTable, is_chk_1_2_21_succ: bool, is_chk_1_2_22_succ: bool):  # 1、执行KS02，2、合并执行规则1.2.21和1.2.22
    """执行KS02，2、合并执行规则1.2.21和1.2.22"""
    if any([v.strip() != '' for v in df[['S', 'T']].values.flatten()]) is True:  # S、T列存在非空值
        is_check_passed = True
        logging.info('执行KS02')
        with SAP() as session:
            for rn in df.index:
                cost_center_map: Dict[str, str] = {}
                if is_chk_1_2_21_succ is True:
                    cost_center_map.update({'S': df['S'][rn]})  # 岗位财科_成本中心
                if is_chk_1_2_22_succ is True:
                    cost_center_map.update({'T': df['T'][rn]})  # 岗位成本分配_成本中心
                for column_letter, cost_center_id in cost_center_map.items():
                    session.findById("wnd[0]/tbar[0]/okcd").text = "/n ks02"  # SAP事务码：KS02
                    session.findById("wnd[0]").sendVKey(0)  # 回车
                    if cost_center_id != '':
                        session.findById("wnd[0]/usr/ctxtCSKSZ-KOSTL").text = cost_center_id
                        session.findById("wnd[0]").sendVKey(0)  # 回车
                        sap_status = session.findById("wnd[0]/sbar/pane[0]").text
                        if sap_status != '':
                            logging.info(f'SAP状态栏信息：{sap_status}')
                            if '不存在' in sap_status:
                                lt[column_letter][rn].cmt('red', '成本中心尚未建立！')
                                is_check_passed = False
        return is_check_passed
    else:
        logging.info('不需要执行KS02')
        return True


@logfn
def chk_1074(job_ids: List[str]) -> AdTable:
    begin_date = next_month_01()
    end_date = '99991231'
    with SAP('login_tx') as user_sap_session:
        return export_1074(user_sap_session, job_ids, begin_date=begin_date, end_date=end_date)


@logfn
def chk_1_2_23_20210620(df: DataFrame, lt: AdTable, df_1074: DataFrame) -> bool:  # 检验机构编码存在性
    """校验岗位所在机构编码是否存在于系统中
       ------------------
       组合逻辑查询1074，提取【销售企业建岗模板-【E-岗位所在机构编码】】，在【报告期间】字段里选择【其他期间】，依次输入【销售企业建岗模板-【F-开始日期】】和“99991231”，
       回车，判断是否有提示“未选取数据”：
       1.未提示“未选取数据”，则下载数据，先在【销售企业建岗模板-【E-岗位所在机构编码】】中匹配与【1074-【A-对象标识】】相同的机构编码，若匹配不成功，见1；若匹配成功，
       则将【1074-【G-机构全称】】填写至【销售企业建岗模板-【C-岗位所在机构名称】】，
       再检验同一个机构编码的【1074-【C-结束日期】】是否存在“99991231”（若有多行，只要同一个机构编码存在一处“99991231”即可），若不存在，见2；
       2.提示“未选取数据”，见3。
       ------------------
       1.若“匹配不成功”，则在【销售企业建岗模板-【E-岗位所在机构编码】】单元格填充红色并插入批注“机构编码有误！”；
       2.若“匹配不成功”，则在【销售企业建岗模板-【E-岗位所在机构编码】】单元格填充红色并插入批注“该机构已被定界！”；
       3.若提示“未选取数据”，则在【销售企业建岗模板-【E-岗位所在机构编码】】单元格填充红色并插入批注“机构编码有误！”。
    """
    is_check_passed = True
    for rn in df.index:
        org_id: str = df['E'][rn]
        df_tmp = df_1074[df_1074['A'] == org_id]
        if df_tmp.empty is True:
            is_check_passed = False
            lt['E'][rn].cmt('red', '机构编码有误！')
            return is_check_passed
        else:
            lt['C'][rn].value = df_tmp['G'].values[0]
        _c_list = [to_yyyymmdd(v) for v in df_tmp['C'].values]  # 将日期转换为yyyymmdd格式
        if '99991231' not in _c_list:
            is_check_passed = False
            lt['E'][rn].cmt('red', '该机构已被定界！')
    return is_check_passed


@logfn
def chk_1_3_01_20210620(df: DataFrame, lt: AdTable, df_dims_prov: DataFrame, df_dims_city: DataFrame, df_dims_area: DataFrame, df_dims_diao_pei: DataFrame) -> bool:  # 事前校验完成
    """
       ------------------
       若1.1.2至1.2.21有任一红色批注报错，返回人工；若无红色批注报错，执行批导。
       ------------------
    """
    logging.info('事前校验')
    is_check_passed: List[bool] = []
    chk_1_1_01_20210620(lt)  # 清除“销售企业建岗模板”上所有的批注及单元格颜色
    logging.info('校验模板内容')
    for rn in df.index:
        is_check_passed.append(chk_1_2_01_20210620(df, lt, rn))  # 校验机构编码
        is_check_passed.append(chk_1_2_02_20210620(df, lt, rn))  # 校验开始日期
        is_check_passed.append(chk_1_2_03_20210620(df, lt, rn))  # 校验岗位简称
        is_check_passed.append(chk_1_2_04_20210620(df, lt, rn))  # 校验岗位全称
        is_check_passed.append(chk_1_2_05_20210620(df, lt, rn, df_dims_prov, df_dims_city, df_dims_area))  # 检验企业岗位目录编号
        is_check_passed.append(chk_1_2_06_20210620(df, lt, rn))  # 检验必填项
        is_check_passed.append(chk_1_2_07_20210620(df, lt, rn))  # 检验职务岗位码不填标识
        is_check_passed.append(chk_1_2_08_20210620(df, lt, rn, df_dims_prov, df_dims_city, df_dims_area))  # 检验岗位类别
        is_check_passed.append(chk_1_2_09_20210620(df, lt, rn))  # 检验虚岗位标识
        is_check_passed.append(chk_1_2_10_20210620(df, lt, rn))  # 检验油品销售企业定员标准未覆盖标识
        is_check_passed.append(chk_1_2_11_20210620(df, lt, rn))  # 检验班组长标识
        is_check_passed.append(chk_1_2_12_20210620(df, lt, rn))  # 检验虚岗位与岗位类别的互斥性
        is_check_passed.append(chk_1_2_13_20210620(df, lt, rn, df_dims_diao_pei))  # 检验岗位财科公司代码
        is_check_passed.append(chk_1_2_14_20210620(df, lt, rn, df_dims_diao_pei))  # 检验岗位财科人事范围
        is_check_passed.append(chk_1_2_15_20210620(df, lt, rn))  # 检验公司代码与人事范围一致性
        is_check_passed.append(chk_1_2_16_20210620(df, lt, rn, df_dims_diao_pei))  # 检验岗位财科人事子范围
        is_check_passed.append(chk_1_2_17_20210620(df, lt, rn, df_dims_diao_pei))  # 检验岗位财科业务范围
        is_check_passed.append(chk_1_2_18_20210705(df, lt, rn))  # 检验岗位财科一致性
        is_check_passed.append(chk_1_2_19_20210620(df, lt, rn))  # 检验岗位财科成本中心
        is_check_passed.append(chk_1_2_20_20210620(df, lt, rn))  # 检验岗位成本分配成本中心
    is_check_passed.append(chk_ks02(df, lt, chk_1_2_21_20210620(df, lt), chk_1_2_22_20210620(df, lt)))  # 检验岗位财科成本中心存在性、检验岗位成本分配成本中心存在性
    # if '已对该模板进行结构化刷新，后续跳过' not in str(lt.wb.properties.keywords):
    #     if refresh_user_data() is True:  # 结构化刷新
    #         lt.wb.properties.keywords = '已对该模板进行结构化刷新，后续跳过'
    #         logging.warning('结构化刷新成功，模板[标记]属性中写入“已对该模板进行结构化刷新，后续跳过”，如仍需结构化刷新，请清除模板[标记]属性')
    # else:
    #     logging.warning('已对该模板进行结构化刷新，后续跳过')
    lt_1074 = chk_1074(df['E'].values.tolist())
    if isinstance(lt_1074, AdTable):
        FTP_FILES['1074'] = lt_1074
        is_check_passed.append(chk_1_2_23_20210620(df, lt, lt_1074.to_dataframe()))  # 校验岗位所在机构编码是否存在于系统中
    else:
        logging.error('导出组合逻辑查询1074失败')
    logging.info('事前校验结束')
    return all(is_check_passed) is True


def chk_1_4_01_20210620(df: DataFrame, lt: AdTable, df_dims_prov: DataFrame, df_dims_city: DataFrame, df_dims_area: DataFrame) -> bool:  # 提取岗位信息
    """
       ------------------
       锁定【销售企业建岗模板-【L-虚岗位标识】的值不为“X”】的【销售企业建岗模板-【I-岗位目录编号】】，在相应的《省级机关职能处室及专业中心》或
       《地市机关职能及专业部室》或《大区公司及成品油管道》中（方法见1.2.5），在【相应目录-【A-编号】】匹配相同的值，锁定同一行，进行如下操作:
       1.先提取【相应目录-【F-薪酬标杆】】，复制到【销售企业建岗模板-【V-薪酬标杆】】；再根据【销售企业建岗模板-【V-薪酬标杆】首字符】的对应关系
       （1：1 管理序列；2：2 专业技术序列；3：3 技能操作序列），将对应的值复制到【销售企业建岗模板-【U-岗位分类序列】】中；
       2.提取【相应目录-【G-所属专业大类】】，复制到【销售企业建岗模板-【W-所属专业大类】】；
       3.提取【相应目录-【H-所属专业小类】】，复制到【销售企业建岗模板-【X-所属专业小类】】；
       4.提取【相应目录-【I-所属工种大类】】，复制到【销售企业建岗模板-【Y-所属工种大类】】；
       5.提取【相应目录-【J-所属工种小类】】，复制到【销售企业建岗模板-【Z-所属工种小类】】；
       6.提取【相应目录-【K-岗位工时制】】，复制到【销售企业建岗模板-【AA-岗位工时制】】；
       7.提取【相应目录-【C-职务岗位码】】，复制到【销售企业建岗模板-【AC-职务岗位码】】。
       ------------------
    """
    logging.info('提取岗位信息，职务岗位码的再处理')
    for rn in df.index:
        if df['L'][rn] != 'X':
            _i = df['I'][rn]
            _df_dims: Optional[DataFrame] = None
            if _i.startswith('01'):
                _df_dims = df_dims_prov
            elif _i.startswith('02'):
                _df_dims = df_dims_city
            elif _i.startswith('03'):
                _df_dims = df_dims_area
            if _df_dims is not None:
                _df_tmp = _df_dims[_df_dims['A'] == _i]
                lt['V'][rn].value = _df_tmp['F'].values[0]
                if _df_tmp['F'].values[0].startswith('1'):
                    lt['U'][rn].value = '1 管理序列'
                elif _df_tmp['F'].values[0].startswith('2'):
                    lt['U'][rn].value = '2 专业技术序列'
                elif _df_tmp['F'].values[0].startswith('3'):
                    lt['U'][rn].value = '3 技能操作序列'
                elif _df_tmp['F'].values[0].startswith('4'):  # 4同3
                    lt['U'][rn].value = '3 技能操作序列'
                else:
                    logging.error('规则外的情形')
                lt['W'][rn].value = _df_tmp['G'].values[0]
                lt['X'][rn].value = _df_tmp['H'].values[0]
                lt['Y'][rn].value = _df_tmp['I'].values[0]
                lt['Z'][rn].value = _df_tmp['J'].values[0]
                lt['AA'][rn].value = _df_tmp['K'].values[0]
                lt['AC'][rn].value = _df_tmp['C'].values[0]
        chk_1_4_02_20210620(df, lt, rn)  # 职务岗位码的再处理
        chk_1_4_03_20210630(df, lt, rn, df_dims_prov)  # 高管人员报警
    return True


def chk_1_4_02_20210620(df: DataFrame, lt: AdTable, rn: int) -> bool:  # 职务岗位码的再处理
    """职务岗位码的再处理
       ------------------
       当【销售企业建岗模板-【J-职务岗位码不填标识】】的值为“不填”时，清空【销售企业建岗模板-【AC-职务岗位码】】。
       ------------------
    """
    if df['J'][rn] == '不填':
        lt['AC'][rn].value = ''
    return True


def chk_1_4_03_20210630(df: DataFrame, lt: AdTable, rn: int, df_dims_prov: DataFrame) -> bool:  # 高管人员报警
    """高管人员报警
       ------------------
       当【销售企业建岗模板-【J-职务岗位码不填标识】】为空且【销售企业建岗模板-【I-岗位目录编号】】的值为【省级机关职能处室及专业中心-【A-“01-01”】中的值】时，见1。
       ------------------
       1.若“符合要求”，在【销售企业建岗模板-【I-岗位目录编号】】单元格填充蓝色并插入批注“该职务岗位码对应高管人员，请核实！”。
    """
    if df['J'][rn] != '':
        if df['I'][rn].startswith('01-01'):
            lt['I'][rn].cmt('blue', '该职务岗位码对应高管人员，请核实！')
    return True


def chk_2_1_01_20210620(df: DataFrame, lt: AdTable, dict_job_ids: Dict[int, str]) -> AdTable:  # 生成1000S模板
    """1000_HR_BI_1000S--岗位简称、全称
       ------------------
       1000_HR_BI_1000S--人员导入--创建（职务）岗位具体名称（S）
       ------------------
       1.【1000_HR_BI_1000S-【B-职位（岗位）具体名称编码】】从岗位池提取；
       2.【1000_HR_BI_1000S-【D-开始日期】】从【销售企业建岗模板-【F-执行时间】】提取；
       3.【1000_HR_BI_1000S-【E-结束日期】】固定为“99991231”；
       4.【1000_HR_BI_1000S-【F-简称】】从【销售企业建岗模板-【G-岗位简称】】提取；；
       5.【1000_HR_BI_1000S-【G-全称】】从【销售企业建岗模板-【H-岗位全称】】提取；
       6.【1000_HR_BI_1000S-【A-中文名称】】按序递增。
    """
    logging.info('生成批导模板: ' + Path(TEMPLATE_1000_HR_BI_1000S).name)
    lt_1000_hr_bi_1000s = load_from_xlsx_file(TEMPLATE_1000_HR_BI_1000S, skip_header=6)
    for idx, rn in enumerate(df.index, start=1):
        lt_1000_hr_bi_1000s['B'][6 + idx].value = dict_job_ids[rn]  # 【B-职位（岗位）具体名称编码】】从岗位池提取
        lt_1000_hr_bi_1000s['D'][6 + idx].value = df['F'][rn]  # 【D-开始日期】】从【销售企业建岗模板-【F-执行时间】】提取
        lt_1000_hr_bi_1000s['E'][6 + idx].value = '99991231'  # 【E-结束日期】】固定为“99991231”
        lt_1000_hr_bi_1000s['F'][6 + idx].value = df['G'][rn]  # 【F-简称】】从【销售企业建岗模板-【G-岗位简称】】提取
        lt_1000_hr_bi_1000s['G'][6 + idx].value = df['H'][rn]  # 【G-全称】】从【销售企业建岗模板-【H-岗位全称】】提取
        lt_1000_hr_bi_1000s['A'][6 + idx].value = str(idx)  # 【A-中文名称】】按序递增
    return lt_1000_hr_bi_1000s


def chk_2_1_02_20210620(df: DataFrame, lt: AdTable, dict_job_ids: Dict[int, str]) -> Optional[AdTable]:  # 生成9019模板
    """9019_HR_BI_9019--岗位分类信息
       ------------------
       9019_HR_BI_9019--人员导入--岗位分类信息
       ------------------
       1.【9019_HR_BI_9019-【B-职位（岗位）具体名称编码】】从【1000_HR_BI_1000S-【B-职位（岗位）具体名称编码】】提取；
       2.【9019_HR_BI_9019-【D-开始日期】】从【销售企业建岗模板-【F-开始日期】】提取；
       3.【9019_HR_BI_9019-【E-结束日期】】固定为“99991231”；
       4.【9019_HR_BI_9019-【F-岗位分类序列】】从【销售企业建岗模板-【U-岗位分类序列】】提取；
       5.当【销售企业建岗模板-【W-所属专业大类】】不为空时，【9019_HR_BI_9019-【G-所属专业类别】】从【销售企业建岗模板-【W-所属专业大类】】提取；
       6.当【销售企业建岗模板-【W-所属专业大类】】不为空时，【9019_HR_BI_9019-【H-所属专业名称】】从【销售企业建岗模板-【X-所属专业小类】】提取；
       7.当【销售企业建岗模板-【Y-所属工种大类】】不为空时，【9019_HR_BI_9019-【J-所属工种类别】】从【销售企业建岗模板-【Y-所属工种大类】】提取；
       8.当【销售企业建岗模板-【Y-所属工种大类】】不为空时，【9019_HR_BI_9019-【K-所属工种】】从【销售企业建岗模板-【Z-所属工种小类】】提取；
       9.当【销售企业建岗模板-【Y-所属工种大类】】不为空时，【9019_HR_BI_9019-【L-工种名称】】从【销售企业建岗模板-【Z-所属工种小类】空格后（即：第七个字符开始）的文本】提取；
       10.【9019_HR_BI_9019-【M-薪酬标杆岗位类别】】从【销售企业建岗模板-【V-薪酬标杆】】提取；
       11.【9019_HR_BI_9019-【Q-岗位工时制】】从【销售企业建岗模板-【AA-岗位工时制】】提取；
       12.【9019_HR_BI_9019-【V-班组长标识】】从【销售企业建岗模板-【N-班组长标识】】提取；
       13【9019_HR_BI_9019-【W-虚岗位标识】】从【销售企业建岗模板-【L-虚岗位标识】】提取；
       14.【9019_HR_BI_9019-【X-油品销售企业定员标准未覆盖标识】】从【销售企业建岗模板-【M-油品销售企业定员标准未覆盖标识】】提取；
       15.【9019_HR_BI_9019-【A-中文名称】】按序递增。
    """
    if '' not in df['L'].values:  # 虚岗位L列为空，虚岗位维护由规则3.1.2执行
        logging.info('跳过生成批导模板: 1001_HR_BI_B007SC--人员导入--关系_S_C_B007（全部为虚岗位）')
        return None
    logging.info('生成批导模板: ' + Path(TEMPLATE_9019_HR_BI_9019).name)
    lt_9019_hr_bi_9019 = load_from_xlsx_file(TEMPLATE_9019_HR_BI_9019, skip_header=6)
    df_filter = df[df['U'] != '']
    for idx, rn in enumerate(df_filter.index, start=1):
        lt_9019_hr_bi_9019['B'][6 + idx].value = dict_job_ids[rn]  # 【B-职位（岗位）具体名称编码】】从【1000_HR_BI_1000S-【B-职位（岗位）具体名称编码】】提取
        lt_9019_hr_bi_9019['D'][6 + idx].value = df_filter['F'][rn]  # 【D-开始日期】】从【销售企业建岗模板-【F-开始日期】】提取
        lt_9019_hr_bi_9019['E'][6 + idx].value = '99991231'  # 【E-结束日期】】固定为“99991231”
        lt_9019_hr_bi_9019['F'][6 + idx].value = df_filter['U'][rn]  # 【F-岗位分类序列】】从【销售企业建岗模板-【U-岗位分类序列】】提取
        if df_filter['W'][rn] != '':  # 当【销售企业建岗模板-【W-所属专业大类】】不为空时
            lt_9019_hr_bi_9019['G'][6 + idx].value = df_filter['W'][rn]  # 【9019_HR_BI_9019-【G-所属专业类别】】从【销售企业建岗模板-【W-所属专业大类】】提取
            lt_9019_hr_bi_9019['H'][6 + idx].value = df_filter['X'][rn]  # 【9019_HR_BI_9019-【H-所属专业名称】】从【销售企业建岗模板-【X-所属专业小类】】提取
        if df_filter['I'][rn] != '':  # 当【销售企业建岗模板-【Y-所属工种大类】】不为空时
            lt_9019_hr_bi_9019['J'][6 + idx].value = df_filter['Y'][rn]  # 【9019_HR_BI_9019-【J-所属工种类别】】从【销售企业建岗模板-【Y-所属工种大类】】提取
            lt_9019_hr_bi_9019['K'][6 + idx].value = df_filter['Z'][rn]  # 【9019_HR_BI_9019-【K-所属工种】】从【销售企业建岗模板-【Z-所属工种小类】】提取
            lt_9019_hr_bi_9019['L'][6 + idx].value = df_filter['Z'][rn][6:]  # 【9019_HR_BI_9019-【L-工种名称】】从【销售企业建岗模板-【Z-所属工种小类】空格后（即：第七个字符开始）的文本】提取
        lt_9019_hr_bi_9019['M'][6 + idx].value = df_filter['V'][rn]  # 【9019_HR_BI_9019-【M-薪酬标杆岗位类别】】从【销售企业建岗模板-【V-薪酬标杆】】提取
        lt_9019_hr_bi_9019['Q'][6 + idx].value = df_filter['AA'][rn]  # 【9019_HR_BI_9019-【Q-岗位工时制】】从【销售企业建岗模板-【AA-岗位工时制】】提取
        lt_9019_hr_bi_9019['V'][6 + idx].value = df_filter['N'][rn]  # 【9019_HR_BI_9019-【V-班组长标识】】从【销售企业建岗模板-【N-班组长标识】】提取
        lt_9019_hr_bi_9019['W'][6 + idx].value = df_filter['L'][rn]  # 【9019_HR_BI_9019-【W-虚岗位标识】】从【销售企业建岗模板-【L-虚岗位标识】】提取
        lt_9019_hr_bi_9019['X'][6 + idx].value = df_filter['M'][rn]  # 【9019_HR_BI_9019-【X-油品销售企业定员标准未覆盖标识】】从【销售企业建岗模板-【M-油品销售企业定员标准未覆盖标识】】提取
        lt_9019_hr_bi_9019['A'][6 + idx].value = str(idx)  # 【A-中文名称】】按序递增
    return lt_9019_hr_bi_9019


def chk_2_1_03_20210620(df: DataFrame, lt: AdTable, dict_job_ids: Dict[int, str]) -> Optional[AdTable]:  # 生成B007SC模板
    """1001_HR_BI_B007SC--关系_S_C_B007
       ------------------
       1001_HR_BI_B007SC--人员导入--关系_S_C_B007
       ------------------
       当存在【销售企业建岗模板-【AC-职务岗位码】】不为空的岗位时，锁定所有不为空的岗位，若不存在执行下一规则：
       1.【1001_HR_BI_B007SC-【B-职位（岗位）具体名称编码】】从【1000_HR_BI_1000S-【B-职位（岗位）具体名称编码】】提取；
       2.【1001_HR_BI_B007SC-【D-开始日期】】从【销售企业建岗模板-【F-执行时间】】提取；
       3.【1001_HR_BI_B007SC-【E-结束日期】】固定为“99991231”；
       4.【1001_HR_BI_B007SC-【F-职务（岗位）编码】】从【销售企业建岗模板-【AC-职务岗位码】】提取；
       5.【1001_HR_BI_B007SC-【A-中文名称】】按序递增。
    """
    lt_1001_hr_bi_b007sc = load_from_xlsx_file(TEMPLATE_1001_HR_BI_B007SC, skip_header=6)
    is_ac_all_empty = True
    idx = 0
    for rn in df.index:
        if df['AC'][rn] != '':
            is_ac_all_empty = False
            idx += 1
            lt_1001_hr_bi_b007sc['B'][6 + idx].value = dict_job_ids[rn]  # 【B-职位（岗位）具体名称编码】】从【1000_HR_BI_1000S-【B-职位（岗位）具体名称编码】】提取
            lt_1001_hr_bi_b007sc['D'][6 + idx].value = df['F'][rn]  # 【D-开始日期】】从【销售企业建岗模板-【F-执行时间】】提取
            lt_1001_hr_bi_b007sc['E'][6 + idx].value = '99991231'  # 【E-结束日期】】固定为“99991231”
            lt_1001_hr_bi_b007sc['F'][6 + idx].value = df['AC'][rn]  # 【F-职务（岗位）编码】】从【销售企业建岗模板-【AC-职务岗位码】】提取
            lt_1001_hr_bi_b007sc['A'][6 + idx].value = str(idx)  # 【A-中文名称】】按序递增
    if is_ac_all_empty is True:
        logging.info('跳过生成批导模板: 1001_HR_BI_B007SC--人员导入--关系_S_C_B007')
        return None
    else:
        logging.info('生成批导模板: ' + Path(TEMPLATE_1001_HR_BI_B007SC).name)
        return lt_1001_hr_bi_b007sc


def chk_2_1_04_20210620(df: DataFrame, lt: AdTable, dict_job_ids: Dict[int, str]) -> Optional[AdTable]:  # 生成A011SK模板
    """1001_HR_BI_A011SK--HR_BI_A011SK
       ------------------
       1001_HR_BI_A011SK--人员导入--HR_BI_A011SK
       ------------------
       当存在【销售企业建岗模板-【S-岗位财科_成本中心】】不为空的岗位时，锁定所有不为空的岗位，若不存在执行下一规则：
       1.【1001_HR_BI_A011SK-【B-职位（岗位）具体名称编码】】从【1000_HR_BI_1000S-【B-职位（岗位）具体名称编码】】提取；
       2.【1001_HR_BI_A011SK-【D-开始日期】】从【销售企业建岗模板-【F-执行时间】】提取；
       3.【1001_HR_BI_A011SK-【E-结束日期】】固定为“99991231”；
       4.【1001_HR_BI_A011SK-【F-职务（岗位）编码】】从【销售企业建岗模板-【S-岗位财科_成本中心】】提取；
       5.【1001_HR_BI_A011SK-【A-中文名称】】按序递增。
    """
    lt_1001_hr_bi_a011sk = load_from_xlsx_file(TEMPLATE_1001_HR_BI_A011SK, skip_header=6)
    is_s_all_empty = True
    idx = 0
    for rn in df.index:
        if df['S'][rn] != '':
            is_s_all_empty = False
            idx += 1
            lt_1001_hr_bi_a011sk['B'][6 + idx].value = dict_job_ids[rn]  # 【B-职位（岗位）具体名称编码】】从【1000_HR_BI_1000S-【B-职位（岗位）具体名称编码】】提取
            lt_1001_hr_bi_a011sk['D'][6 + idx].value = df['F'][rn]  # 【D-开始日期】】从【销售企业建岗模板-【F-执行时间】】提取
            lt_1001_hr_bi_a011sk['E'][6 + idx].value = '99991231'  # 【E-结束日期】】固定为“99991231”
            lt_1001_hr_bi_a011sk['F'][6 + idx].value = df['S'][rn] + 'SINO'  # 【F-职务（岗位）编码】】从【销售企业建岗模板-【S-岗位财科_成本中心】】提取
            lt_1001_hr_bi_a011sk['A'][6 + idx].value = str(idx)  # 【A-中文名称】】按序递增
    if is_s_all_empty is True:
        logging.info('跳过生成批导模板: 1001_HR_BI_A011SK--人员导入--HR_BI_A011SK')
        return None
    else:
        logging.info('生成批导模板: ' + Path(TEMPLATE_1001_HR_BI_A011SK).name)
        return lt_1001_hr_bi_a011sk


def chk_2_1_06_20210620(df: DataFrame, lt: AdTable, dict_job_ids: Dict[int, str]) -> Optional[AdTable]:  # 生成S_O_A012模板
    """1001_HR_BI_A012SO--关系_S_O_A012
       ------------------
       1001_HR_BI_A012SO--人员导入--关系_S_O_A012
       ------------------
       当存在【销售企业建岗模板-【V-薪酬标杆】的首字符的值存在“1”】的岗位时，锁定所有符合“首字符为“1””的岗位，若不存在执行下一规则：
       1.【1001_HR_BI_A012SO-【B-职位（岗位）具体名称编码】】从【1000_HR_BI_1000S-【B-职位（岗位）具体名称编码】】提取；
       2.【1001_HR_BI_A012SO-【D-开始日期】】从【销售企业建岗模板-【F-执行时间】】提取；
       3.【1001_HR_BI_A012SO-【E-结束日期】】固定为“99991231”；
       4.【1001_HR_BI_A012SO-【A-中文名称】】按序递增。
    """
    lt_1001_hr_bi_a012so = load_from_xlsx_file(TEMPLATE_1001_HR_BI_A012SO, skip_header=6)
    is_k_eq_1_not_exists = True
    idx = 0
    for rn in df.index:
        if df['V'][rn].startswith('1'):
            is_k_eq_1_not_exists = False
            idx += 1
            lt_1001_hr_bi_a012so['B'][6 + idx].value = dict_job_ids[rn]  # 【B-职位（岗位）具体名称编码】】从【1000_HR_BI_1000S-【B-职位（岗位）具体名称编码】】提取
            lt_1001_hr_bi_a012so['D'][6 + idx].value = df['F'][rn]  # 【D-开始日期】】从【销售企业建岗模板-【F-执行时间】】提取
            lt_1001_hr_bi_a012so['E'][6 + idx].value = '99991231'  # 【E-结束日期】】固定为“99991231”\
            lt_1001_hr_bi_a012so['F'][6 + idx].value = df['E'][rn]  # 20210621新增规则
            lt_1001_hr_bi_a012so['A'][6 + idx].value = str(idx)  # 【A-中文名称】】按序递增
    if is_k_eq_1_not_exists is True:
        logging.info('跳过生成批导模板: 1001_HR_BI_A012SO--人员导入--关系_S_O_A012')
        return None
    else:
        logging.info('生成批导模板: ' + Path(TEMPLATE_1001_HR_BI_A012SO).name)
        return lt_1001_hr_bi_a012so


def chk_2_1_07_20210620(df: DataFrame, lt: AdTable, dict_job_ids: Dict[int, str]) -> Optional[AdTable]:  # 生成S_03_B007模板
    """1001_HR_BI_B007S3--创建关系_S_03_B007
       ------------------
       1001_HR_BI_B007S3--人员导入--创建关系_S_03_B007
       ------------------
       当存在【销售企业建岗模板-【L-虚岗位标识】的值为空】的岗位时，锁定所有符合“值为空”的岗位，若不存在执行下一规则：
       1.【1001_HR_BI_B007S3-【B-职位（岗位）具体名称编码】】从【1000_HR_BI_1000S-【B-职位（岗位）具体名称编码】】提取；
       2.【1001_HR_BI_B007S3-【D-开始日期】】从【销售企业建岗模板-【F-执行时间】】提取；
       3.【1001_HR_BI_B007S3-【E-结束日期】】固定为“99991231”；
       4.【1001_HR_BI_B007S3-【F-职务（岗位）编码】】从【销售企业建岗模板-【AB-03码】“第一个空格前的数字”】提取；
       5.【1001_HR_BI_B007S3-【A-中文名称】】按序递增。
    """
    lt_1001_hr_bi_b007s3 = load_from_xlsx_file(TEMPLATE_1001_HR_BI_B007S3, skip_header=6)
    is_l_eq_null_not_exists = True
    idx = 0
    for rn in df.index:
        if df['L'][rn] == '':
            is_l_eq_null_not_exists = False
            idx += 1
            lt_1001_hr_bi_b007s3['B'][6 + idx].value = dict_job_ids[rn]  # 【B-职位（岗位）具体名称编码】】从【1000_HR_BI_1000S-【B-职位（岗位）具体名称编码】】提取
            lt_1001_hr_bi_b007s3['D'][6 + idx].value = df['F'][rn]  # 【D-开始日期】】从【销售企业建岗模板-【F-执行时间】】提取
            lt_1001_hr_bi_b007s3['E'][6 + idx].value = '99991231'  # 【E-结束日期】】固定为“99991231”
            lt_1001_hr_bi_b007s3['F'][6 + idx].value = df['AB'][rn].split(' ')[0]  # 【F-职务（岗位）编码】】从【销售企业建岗模板-【AB-03码】“第一个空格前的数字”】提取
            lt_1001_hr_bi_b007s3['A'][6 + idx].value = str(idx)  # 【A-中文名称】】按序递增
    if is_l_eq_null_not_exists is True:
        logging.info('跳过生成批导模板: 1001_HR_BI_B007S3--人员导入--创建关系_S_03_B007')
        return None
    else:
        logging.info('生成批导模板: ' + Path(TEMPLATE_1001_HR_BI_B007S3).name)
        return lt_1001_hr_bi_b007s3


def chk_2_1_08_20210620(df: DataFrame, lt: AdTable, dict_job_ids: Dict[int, str]) -> Optional[AdTable]:  # 生成A003SO模板
    """1001_HR_BI_A003SO--指定岗位的隶属机构
       ------------------
       1001_HR_BI_A003SO--人员导入--指定岗位的隶属机构
       ------------------
       1.【1001_HR_BI_A003SO-【B-职位（岗位）具体名称编码】】从【1000_HR_BI_1000S-【B-职位（岗位）具体名称编码】】提取；
       2.【1001_HR_BI_A003SO-【D-开始日期】】从【销售企业建岗模板-【F-执行时间】】提取；
       3.【1001_HR_BI_A003SO-【E-结束日期】】固定为“99991231”；
       4.【1001_HR_BI_A003SO-【F-直接隶属机构编码】】从【销售企业建岗模板-【E-岗位所在机构编码】】提取；
       5.【1001_HR_BI_A003SO-【A-中文名称】】按序递增。
    """
    logging.info('生成批导模板: ' + Path(TEMPLATE_1001_HR_BI_A003SO).name)
    lt_1001_hr_bi_a003so = load_from_xlsx_file(TEMPLATE_1001_HR_BI_A003SO, skip_header=6)
    for idx, rn in enumerate(df.index, start=1):
        lt_1001_hr_bi_a003so['B'][6 + idx].value = dict_job_ids[rn]
        lt_1001_hr_bi_a003so['D'][6 + idx].value = df['F'][rn]  # 【D-开始日期】】从【销售企业建岗模板-【F-执行时间】】提取
        lt_1001_hr_bi_a003so['E'][6 + idx].value = '99991231'  # 【E-结束日期】】固定为“99991231”
        lt_1001_hr_bi_a003so['F'][6 + idx].value = df['E'][rn]  # 【F-直接隶属机构编码】】从【销售企业建岗模板-【E-岗位所在机构编码】】提取
        lt_1001_hr_bi_a003so['A'][6 + idx].value = str(idx)  # 【A-中文名称】】按序递增
    return lt_1001_hr_bi_a003so


@logfn
def move_err_job_to_org(lt_1001_hr_bi_a003so: AdTable, bucket_err_org_id: str) -> bool:
    df_1001_hr_bi_a003so = lt_1001_hr_bi_a003so.to_dataframe()
    lt_1001_hr_bi_a003so_new = load_from_xlsx_file(TEMPLATE_1001_HR_BI_A003SO, skip_header=6)
    idx = 0
    for rn in df_1001_hr_bi_a003so.index:
        if df_1001_hr_bi_a003so['H'][rn] != '成功':
            idx += 1
            lt_1001_hr_bi_a003so_new['A'][6 + idx].value = str(idx)  # 序列号
            lt_1001_hr_bi_a003so_new['B'][6 + idx].value = df_1001_hr_bi_a003so['B'][rn]
            lt_1001_hr_bi_a003so_new['D'][6 + idx].value = df_1001_hr_bi_a003so['D'][rn]
            lt_1001_hr_bi_a003so_new['E'][6 + idx].value = df_1001_hr_bi_a003so['E'][rn]
            lt_1001_hr_bi_a003so_new['F'][6 + idx].value = bucket_err_org_id  # 存放错误岗位的机构
    return import_single_adtable('1001->HR_BI_A003SO', lt_1001_hr_bi_a003so_new, enter_mode='reopen')


@logfn
def chk_2_2_01_20210620(df: DataFrame, lt: AdTable, lt_1000_hr_bi_1000s, lt_9019_hr_bi_9019, lt_1001_hr_bi_b007sc, lt_1001_hr_bi_a011sk, lt_1001_hr_bi_a012so, lt_1001_hr_bi_b007s3, lt_1001_hr_bi_a003so, dict_job_ids: Dict[int, str], bucket_err_org_id: str) -> Tuple[bool, bool, bool]:  # 模板批导
    """模板批导
    """
    is_import_all_succ: List[bool] = []
    is_import_7_succ = True
    is_import_8_succ = True
    if lt_1000_hr_bi_1000s is not None:
        is_import_all_succ.append(import_single_adtable('1000->HR_BI_1000S', lt_1000_hr_bi_1000s, enter_mode='reopen'))  # 01
    if lt_9019_hr_bi_9019 is not None:
        is_import_all_succ.append(import_single_adtable('9019->HR_BI_9019', lt_9019_hr_bi_9019, enter_mode='reopen'))  # 02
    if lt_1001_hr_bi_b007sc is not None:
        is_import_all_succ.append(import_single_adtable('1001->HR_BI_B007SC', lt_1001_hr_bi_b007sc, enter_mode='reopen'))  # 03
    if lt_1001_hr_bi_a011sk is not None:
        is_import_all_succ.append(import_single_adtable('1001->HR_BI_A011SK', lt_1001_hr_bi_a011sk, enter_mode='reopen'))  # 04
    if lt_1001_hr_bi_a012so is not None:
        is_import_all_succ.append(import_single_adtable('1001->HR_BI_A012SO', lt_1001_hr_bi_a012so, enter_mode='reopen'))  # 06(05批导已弃用)
    if all(is_import_all_succ) is True:  # 2.1.6 前批导全成功，就将岗位编号写入主模板
        for rn, job_id in dict_job_ids.items():
            lt['B'][rn].value = job_id
    if lt_1001_hr_bi_b007s3 is not None:
        is_import_7_succ = import_single_adtable('1001->HR_BI_B007S3', lt_1001_hr_bi_b007s3, enter_mode='reopen')  # 07
        is_import_all_succ.append(is_import_7_succ)
    if lt_1001_hr_bi_a003so is not None:
        is_import_8_succ = import_single_adtable('1001->HR_BI_A003SO', lt_1001_hr_bi_a003so, enter_mode='reopen')
        is_import_all_succ.append(is_import_8_succ)
        if is_import_8_succ is False:  # 08
            move_err_job_to_org(lt_1001_hr_bi_a003so, bucket_err_org_id)  # 将废岗转移至其他机构下
    return all(is_import_all_succ) is True, is_import_7_succ, is_import_8_succ


def chk_zhrom095(job_ids: List[str], key_date: str) -> bool:
    logging.info('执行zhrom095')
    with SAP() as sap_session:
        sap_session.findById("wnd[0]/tbar[0]/okcd").text = "/n zhrom095"
        sap_session.findById("wnd[0]").sendVKey(0)
        sap_session.findById("wnd[0]/usr/ctxtPCHOTYPE").text = "S"
        sap_session.findById("wnd[0]/usr/ctxtP_DATE").text = key_date
        sap_session.findById("wnd[0]/usr/btn%_PCHOBJID_%_APP_%-VALU_PUSH").press()
        sap_session.findById("wnd[1]/tbar[0]/btn[16]").press()
        with ClipboardLock():
            pyperclip.copy('\r\n'.join(job_ids))
            sap_session.findById("wnd[1]/tbar[0]/btn[24]").press()
        sap_session.findById("wnd[1]/tbar[0]/btn[8]").press()
        sap_session.findById("wnd[0]/tbar[1]/btn[8]").press()
        sap_session.findById("wnd[0]/tbar[1]/btn[2]").press()
        sap_status = sap_session.findById("wnd[0]/sbar/pane[0]").text
        if sap_status != '':
            logging.info(f'SAP状态栏文本: {sap_status}')
    return True


@logfn
def chk_2_3_01_20210620(lt_1001_hr_bi_b007s3: AdTable) -> bool:  # 执行zhrom095
    """执行zhrom095
       ------------------
       当存在【销售企业建岗模板-【L-虚岗位标识】的值为空】的岗位时，执行口令：zhrom095
       ------------------
    """
    df_1001_hr_bi_b007s3 = lt_1001_hr_bi_b007s3.to_dataframe()
    job_ids: List[str] = df_1001_hr_bi_b007s3['B'].values.tolist()
    key_date: str = df_1001_hr_bi_b007s3['D'].values[0]
    return chk_zhrom095(job_ids, key_date)


def chk_ppome_o_p_q_r(df: DataFrame, lt: AdTable) -> bool:
    logging.info('进入PPOME')
    is_ppome_succ = True
    with SAP() as session:
        session.findById("wnd[0]").maximize()
        session.findById("wnd[0]/tbar[0]/okcd").text = "/n ppome"
        session.findById("wnd[0]").sendVKey(0)
        for rn in df.index:
            job_id = df['B'][rn]
            _o = df['O'][rn]  # 岗位财科_公司代码
            _p = df['P'][rn]  # 岗位财科_人事范围
            _q = df['Q'][rn]  # 岗位财科_人事子范围
            _r = df['R'][rn]  # 岗位财科_业务范围
            logging.info('点击[职务(岗位)具体名称]')
            session.findById("wnd[0]/shellcont/shell/shellcont[0]/shell/shellcont[1]/shell[1]").clickLink("         16", "&Hierarchy")
            session.findById("wnd[1]/usr/subSEARCH_FUNCTION_SUBSCREEN:SAPLOM_SEARCHTOOL_ORGPLAN:0160/txtSEARCH_FUNCTION-SEARK").text = job_id  # 带名称
            session.findById("wnd[1]/tbar[0]/btn[0]").press()  # 查找
            sap_status = session.findById("wnd[0]/sbar/pane[0]").text
            if sap_status != '':
                logging.info(f'SAP状态栏信息：{sap_status}')
            if '搜索中没有找到任何命中' in sap_status:
                is_ppome_succ = False
                lt['B'][rn].cmt('red', '零星操作-岗位财科设置设置失败，PPOSE中没有找到对应岗位编码')
                continue
            # 双击[命中清单]第一个行
            session.findById("wnd[0]/shellcont/shell/shellcont[1]/shell").currentCellColumn = "ADD_FIELD3"
            session.findById("wnd[0]/shellcont/shell/shellcont[1]/shell").selectedRows = "0"
            session.findById("wnd[0]/shellcont/shell/shellcont[1]/shell").doubleClickCurrentCell()
            # 双击[人员分析]第一个行
            session.findById("wnd[0]/usr/subMAINSCREEN:SAPLOM_NAVFRAMEWORK_OO_OBJ:1200/subWORKSPACE:SAPLOM_NAVFRAMEWORK_OO_OBJ:0200/subOVERVIEW:SAPLOM_GEN_OVERVIEW:1000/cntlTREE_CONTAINER/shellcont/shell").selectItem("          1", "ORG_STEXT")
            session.findById("wnd[0]/usr/subMAINSCREEN:SAPLOM_NAVFRAMEWORK_OO_OBJ:1200/subWORKSPACE:SAPLOM_NAVFRAMEWORK_OO_OBJ:0200/subOVERVIEW:SAPLOM_GEN_OVERVIEW:1000/cntlTREE_CONTAINER/shellcont/shell").ensureVisibleHorizontalItem("          1", "ORG_STEXT")
            session.findById("wnd[0]/usr/subMAINSCREEN:SAPLOM_NAVFRAMEWORK_OO_OBJ:1200/subWORKSPACE:SAPLOM_NAVFRAMEWORK_OO_OBJ:0200/subOVERVIEW:SAPLOM_GEN_OVERVIEW:1000/cntlTREE_CONTAINER/shellcont/shell").doubleClickItem("          1", "ORG_STEXT")
            # 点击[财务科目设置]
            session.findById("wnd[0]/usr/subMAINSCREEN:SAPLOM_NAVFRAMEWORK_OO_OBJ:1200/subWORKSPACE:SAPLOM_NAVFRAMEWORK_OO_OBJ:0200/subDETAIL:SAPLRHOMDETAILMANAGER:0100/tabsSTRIP_OMDETAIL/tabpDETLTAB02").select()
            # 重置业务范围
            if session.findById("wnd[0]/usr/subMAINSCREEN:SAPLOM_NAVFRAMEWORK_OO_OBJ:1200/subWORKSPACE:SAPLOM_NAVFRAMEWORK_OO_OBJ:0200/subDETAIL:SAPLRHOMDETAILMANAGER:0100/tabsSTRIP_OMDETAIL/tabpDETLTAB02/ssubSUB_OMDETAIL:SAPLRHOMDETAIL_APPL:0500/subSUB_ACCOUNT:SAPLRHOMDETAIL_APPL:0504/btnREPGSBER", False) is not None:
                session.findById("wnd[0]/usr/subMAINSCREEN:SAPLOM_NAVFRAMEWORK_OO_OBJ:1200/subWORKSPACE:SAPLOM_NAVFRAMEWORK_OO_OBJ:0200/subDETAIL:SAPLRHOMDETAILMANAGER:0100/tabsSTRIP_OMDETAIL/tabpDETLTAB02/ssubSUB_OMDETAIL:SAPLRHOMDETAIL_APPL:0500/subSUB_ACCOUNT:SAPLRHOMDETAIL_APPL:0504/btnREPGSBER").press()
                session.findById("wnd[0]/usr/subMAINSCREEN:SAPLOM_NAVFRAMEWORK_OO_OBJ:1200/subWORKSPACE:SAPLOM_NAVFRAMEWORK_OO_OBJ:0200/subDETAIL:SAPLRHOMDETAILMANAGER:0100/tabsSTRIP_OMDETAIL/tabpDETLTAB02/ssubSUB_OMDETAIL:SAPLRHOMDETAIL_APPL:0500/subSUB_ACCOUNT:SAPLRHOMDETAIL_APPL:0504/cmbQ1008-GSBER").key = _r  # 业务范围
            else:
                logging.info('无[重置业务范围]按钮')
            # 重置公司代码
            try:
                if session.findById("wnd[0]/usr/subMAINSCREEN:SAPLOM_NAVFRAMEWORK_OO_OBJ:1200/subWORKSPACE:SAPLOM_NAVFRAMEWORK_OO_OBJ:0200/subDETAIL:SAPLRHOMDETAILMANAGER:0100/tabsSTRIP_OMDETAIL/tabpDETLTAB02/ssubSUB_OMDETAIL:SAPLRHOMDETAIL_APPL:0500/subSUB_ACCOUNT:SAPLRHOMDETAIL_APPL:0504/btnREPBUKRS", False) is not None:
                    session.findById("wnd[0]/usr/subMAINSCREEN:SAPLOM_NAVFRAMEWORK_OO_OBJ:1200/subWORKSPACE:SAPLOM_NAVFRAMEWORK_OO_OBJ:0200/subDETAIL:SAPLRHOMDETAILMANAGER:0100/tabsSTRIP_OMDETAIL/tabpDETLTAB02/ssubSUB_OMDETAIL:SAPLRHOMDETAIL_APPL:0500/subSUB_ACCOUNT:SAPLRHOMDETAIL_APPL:0504/btnREPBUKRS").press()
                    session.findById("wnd[0]/usr/subMAINSCREEN:SAPLOM_NAVFRAMEWORK_OO_OBJ:1200/subWORKSPACE:SAPLOM_NAVFRAMEWORK_OO_OBJ:0200/subDETAIL:SAPLRHOMDETAILMANAGER:0100/tabsSTRIP_OMDETAIL/tabpDETLTAB02/ssubSUB_OMDETAIL:SAPLRHOMDETAIL_APPL:0500/subSUB_ACCOUNT:SAPLRHOMDETAIL_APPL:0504/ctxtQ1008-BUKRS").text = _o  # 公司代码
                else:
                    logging.info('无[重置公司代码]按钮')
            except Exception as e:
                logging.error(e)
            # 重置人事范围&人事子范围
            try:
                if session.findById("wnd[0]/usr/subMAINSCREEN:SAPLOM_NAVFRAMEWORK_OO_OBJ:1200/subWORKSPACE:SAPLOM_NAVFRAMEWORK_OO_OBJ:0200/subDETAIL:SAPLRHOMDETAILMANAGER:0100/tabsSTRIP_OMDETAIL/tabpDETLTAB02/ssubSUB_OMDETAIL:SAPLRHOMDETAIL_APPL:0500/subSUB_ACCOUNT:SAPLRHOMDETAIL_APPL:0504/btnREPPERSB", False) is not None:
                    session.findById("wnd[0]/usr/subMAINSCREEN:SAPLOM_NAVFRAMEWORK_OO_OBJ:1200/subWORKSPACE:SAPLOM_NAVFRAMEWORK_OO_OBJ:0200/subDETAIL:SAPLRHOMDETAILMANAGER:0100/tabsSTRIP_OMDETAIL/tabpDETLTAB02/ssubSUB_OMDETAIL:SAPLRHOMDETAIL_APPL:0500/subSUB_ACCOUNT:SAPLRHOMDETAIL_APPL:0504/btnREPPERSB").press()
                    session.findById("wnd[0]/usr/subMAINSCREEN:SAPLOM_NAVFRAMEWORK_OO_OBJ:1200/subWORKSPACE:SAPLOM_NAVFRAMEWORK_OO_OBJ:0200/subDETAIL:SAPLRHOMDETAILMANAGER:0100/tabsSTRIP_OMDETAIL/tabpDETLTAB02/ssubSUB_OMDETAIL:SAPLRHOMDETAIL_APPL:0500/subSUB_ACCOUNT:SAPLRHOMDETAIL_APPL:0504/ctxtQ1008-PERSA").text = _p  # 人事范围
                    session.findById("wnd[0]/usr/subMAINSCREEN:SAPLOM_NAVFRAMEWORK_OO_OBJ:1200/subWORKSPACE:SAPLOM_NAVFRAMEWORK_OO_OBJ:0200/subDETAIL:SAPLRHOMDETAILMANAGER:0100/tabsSTRIP_OMDETAIL/tabpDETLTAB02/ssubSUB_OMDETAIL:SAPLRHOMDETAIL_APPL:0500/subSUB_ACCOUNT:SAPLRHOMDETAIL_APPL:0504/ctxtQ1008-BTRTL").text = _q[:4]  # 人事子范围
                else:
                    logging.info('无[重置人事范围]按钮')
            except Exception as e:
                logging.error(e)
            session.findById("wnd[0]/tbar[0]/btn[11]").press()  # 保存
            sap_status = session.findById("wnd[0]/sbar/pane[0]").text
            if sap_status != '':
                logging.info(f'SAP状态栏信息：{sap_status}')
            if '数据已保存' not in sap_status:
                is_ppome_succ = False
                logging.error(sap_status)
    return is_ppome_succ


def chk_3_1_00_20210701():
    """结果判断
       ------------------
       若2.1.8失败，不执行3.*后续规则；若在修改过程中，出现机构/岗位占用的情况，记录并退出。
       ------------------
    """
    pass


@logfn
def chk_3_1_01_20210620(df: DataFrame, lt: AdTable) -> bool:  # 零星操作
    """
       ------------------
       岗位池所在机构编码：30260400、30260401
       ------------------
       当存在【销售企业建岗模板-【O、P、Q、R】】的值是否全部有值的岗位时，锁定所有符合“值为空”的岗位，若不存在执行下一规则：
       进入PPOME，锁定岗位-财务科目设置，维护数据。
    """
    df_tmp = df[(df['O'] != '') & (df['P'] != '') & (df['Q'] != '') & (df['R'] != '')]
    if df_tmp.empty is True:
        logging.info('不存在O、P、Q、R全为空的行，跳过执行零星操作')
        return True
    else:
        logging.info('零星操作')
        return chk_ppome_o_p_q_r(df_tmp, lt)


@logfn
def chk_3_1_02_20210620(df: DataFrame, lt: AdTable) -> bool:  # 虚岗位标识维护
    """虚岗位标识维护
       ------------------
       ------------------
       当存在【销售企业建岗模板-【L-虚岗位标识】的值不为空】的岗位时，锁定所有符合“值不为空”的岗位，若不存在执行下一规则：
       进入PPOME，锁定岗位-岗位分类信息，将【销售企业建岗模板-【F-开始日期】】填入“有效日从”，点击“新建”，勾选“虚岗位标识”，保存。
    """
    if 'X' not in df['L'].values:
        logging.info('不存在【销售企业建岗模板-【L-虚岗位标识】的值不为空】的岗位，跳过勾选虚岗位标识')
        return True
    logging.info('虚岗位标识维护')
    df_filter = df[df['L'] == 'X']
    logging.info('进入PPOME')
    is_ppome_succ = True
    with SAP() as session:
        session.findById("wnd[0]").maximize()
        session.findById("wnd[0]/tbar[0]/okcd").text = "/n ppome"
        session.findById("wnd[0]").sendVKey(0)
        for rn in df_filter.index:
            v_job_id = df_filter['B'][rn]  # 虚岗位编号
            begin_date = df_filter['F'][rn]  # 开始日期
            logging.info('点击[职务(岗位)具体名称]')
            session.findById("wnd[0]/shellcont/shell/shellcont[0]/shell/shellcont[1]/shell[1]").clickLink("         16", "&Hierarchy")
            session.findById("wnd[1]/usr/subSEARCH_FUNCTION_SUBSCREEN:SAPLOM_SEARCHTOOL_ORGPLAN:0160/txtSEARCH_FUNCTION-SEARK").text = v_job_id  # 带名称
            session.findById("wnd[1]/tbar[0]/btn[0]").press()  # 查找
            sap_status = session.findById("wnd[0]/sbar/pane[0]").text
            if sap_status != '':
                logging.info(f'SAP状态栏信息：{sap_status}')
            if '搜索中没有找到任何命中' in sap_status:
                is_ppome_succ = False
                lt['B'][rn].cmt('red', '零星操作-勾选虚岗位标识设置失败，PPOSE中没有找到对应岗位编码')
                continue
            # 双击[命中清单]第一个行
            session.findById("wnd[0]/shellcont/shell/shellcont[1]/shell").currentCellColumn = "ADD_FIELD3"
            session.findById("wnd[0]/shellcont/shell/shellcont[1]/shell").selectedRows = "0"
            session.findById("wnd[0]/shellcont/shell/shellcont[1]/shell").doubleClickCurrentCell()
            # 双击[人员分析]第一个行
            session.findById("wnd[0]/usr/subMAINSCREEN:SAPLOM_NAVFRAMEWORK_OO_OBJ:1200/subWORKSPACE:SAPLOM_NAVFRAMEWORK_OO_OBJ:0200/subOVERVIEW:SAPLOM_GEN_OVERVIEW:1000/cntlTREE_CONTAINER/shellcont/shell").selectItem("          1", "ORG_STEXT")
            session.findById("wnd[0]/usr/subMAINSCREEN:SAPLOM_NAVFRAMEWORK_OO_OBJ:1200/subWORKSPACE:SAPLOM_NAVFRAMEWORK_OO_OBJ:0200/subOVERVIEW:SAPLOM_GEN_OVERVIEW:1000/cntlTREE_CONTAINER/shellcont/shell").ensureVisibleHorizontalItem("          1", "ORG_STEXT")
            session.findById("wnd[0]/usr/subMAINSCREEN:SAPLOM_NAVFRAMEWORK_OO_OBJ:1200/subWORKSPACE:SAPLOM_NAVFRAMEWORK_OO_OBJ:0200/subOVERVIEW:SAPLOM_GEN_OVERVIEW:1000/cntlTREE_CONTAINER/shellcont/shell").doubleClickItem("          1", "ORG_STEXT")
            # 点击[岗位分类信息]
            session.findById("wnd[0]/usr/subMAINSCREEN:SAPLOM_NAVFRAMEWORK_OO_OBJ:1200/subWORKSPACE:SAPLOM_NAVFRAMEWORK_OO_OBJ:0200/subDETAIL:SAPLRHOMDETAILMANAGER:0100/tabsSTRIP_OMDETAIL/tabpDETLTAB03").select()
            # 点击[新建]
            session.findById("wnd[0]/usr/subMAINSCREEN:SAPLOM_NAVFRAMEWORK_OO_OBJ:1200/subWORKSPACE:SAPLOM_NAVFRAMEWORK_OO_OBJ:0200/subDETAIL:SAPLRHOMDETAILMANAGER:0100/tabsSTRIP_OMDETAIL/tabpDETLTAB03/ssubSUB_OMDETAIL:SAPLRHOMDETAIL_PP01:0600/ssubSUB_INFTY:SAPLRHOMDETAIL_PP01:0610/btn%#AUTOTEXT013").press()
            # 填入[开始日期]
            session.findById("wnd[0]/usr/subMAINSCREEN:SAPLOM_NAVFRAMEWORK_OO_OBJ:1200/subWORKSPACE:SAPLOM_NAVFRAMEWORK_OO_OBJ:0200/subDETAIL:SAPLRHOMDETAILMANAGER:0100/tabsSTRIP_OMDETAIL/tabpDETLTAB03/ssubSUB_OMDETAIL:SAPLRHOMDETAIL_PP01:0600/ssubSUB_INFTY:SAPLRHOMDETAIL_PP01:0610/subSUB_PERIOD:SAPLRHOMDETAILMANAGER:0300/txtDISPLAY_PERIOD-BEGDA").text = begin_date
            # 勾选[虚岗位标识]
            session.findById("wnd[0]/usr/subMAINSCREEN:SAPLOM_NAVFRAMEWORK_OO_OBJ:1200/subWORKSPACE:SAPLOM_NAVFRAMEWORK_OO_OBJ:0200/subDETAIL:SAPLRHOMDETAILMANAGER:0100/tabsSTRIP_OMDETAIL/tabpDETLTAB03/ssubSUB_OMDETAIL:SAPLRHOMDETAIL_PP01:0600/ssubSUB_INFTY:SAPLRHOMDETAIL_PP01:0610/ssubSUB_INFTY:MP901900:7000/chkP9019-ZZ_XGW").selected = -1
            session.findById("wnd[0]/tbar[0]/btn[11]").press()  # 保存
            sap_status = session.findById("wnd[0]/sbar/pane[0]").text
            if sap_status != '':
                logging.info(f'SAP状态栏信息：{sap_status}')
            if '数据已保存' in sap_status:
                logging.info(f'虚岗位编号：{v_job_id}，开始日期：{begin_date}，勾选虚岗位标识，数据已保存')
    return is_ppome_succ


@logfn
def chk_3_1_03_20210701(df: DataFrame, lt: AdTable) -> bool:  # 成本分配_成本中心维护
    """成本分配_成本中心维护
       ------------------
       ------------------
       当存在【销售企业建岗模板-【T-岗位成本分配_成本中心】的值不为空】的岗位时，锁定所有符合“值不为空”的岗位，若不存在执行下一规则：
       进入PPOME，锁定岗位-成本分配，将【销售企业建岗模板-【F-开始日期】】填入“有效日从”，在“成本中心”输入【销售企业建岗模板-【T-岗位成本分配_成本中心】】，
       在“比率”输入“100”，保存。
    """
    df_tmp = df[df['T'] != '']
    if df_tmp.empty is True:
        logging.info('不存在【销售企业建岗模板-【T-岗位成本分配_成本中心】的值不为空】的岗位，跳过成本分配_成本中心维护')
        return True
    logging.info('成本分配_成本中心维护')
    is_ppome_succ = True
    with SAP() as session:
        session.findById("wnd[0]/tbar[0]/okcd").text = "/n ppome"
        session.findById("wnd[0]").sendVKey(0)
        for rn in df_tmp.index:
            job_id = df['B'][rn]
            begin_date = df['F'][rn]
            cost_center_id = df['T'][rn]
            logging.info(f'岗位编号：{job_id}，开始日期：{begin_date}，成本中心：{cost_center_id}')
            # 点击[职务岗位具体名称]
            session.findById("wnd[0]/shellcont/shell/shellcont[0]/shell/shellcont[1]/shell[1]").selectItem("         16", "&Hierarchy")
            session.findById("wnd[0]/shellcont/shell/shellcont[0]/shell/shellcont[1]/shell[1]").ensureVisibleHorizontalItem("         16", "&Hierarchy")
            session.findById("wnd[0]/shellcont/shell/shellcont[0]/shell/shellcont[1]/shell[1]").clickLink("         16", "&Hierarchy")
            # 输入岗位编号
            session.findById("wnd[1]/usr/subSEARCH_FUNCTION_SUBSCREEN:SAPLOM_SEARCHTOOL_ORGPLAN:0160/txtSEARCH_FUNCTION-SEARK").text = job_id
            # 查找
            session.findById("wnd[1]/tbar[0]/btn[0]").press()
            sap_status = session.findById("wnd[0]/sbar/pane[0]").text
            if sap_status != '':
                logging.info(f'SAP状态栏信息：{sap_status}')
            if '搜索中没有找到任何命中' in sap_status:
                is_ppome_succ = False
                lt['T'][rn].cmt('red', '零星操作-成本分配_成本中心维护设置失败，PPOSE中没有找到对应岗位编码')
                continue
            # 双击第一个单元格
            session.findById("wnd[0]/shellcont/shell/shellcont[1]/shell").currentCellColumn = "ADD_FIELD3"
            session.findById("wnd[0]/shellcont/shell/shellcont[1]/shell").selectedRows = "0"
            session.findById("wnd[0]/shellcont/shell/shellcont[1]/shell").doubleClickCurrentCell()
            # 点击[成本分配]
            session.findById("wnd[0]/usr/subMAINSCREEN:SAPLOM_NAVFRAMEWORK_OO_OBJ:1200/subWORKSPACE:SAPLOM_NAVFRAMEWORK_OO_OBJ:0200/subDETAIL:SAPLRHOMDETAILMANAGER:0100/tabsSTRIP_OMDETAIL/tabpDETLTAB08").select()
            # 有效日期从
            session.findById("wnd[0]/usr/subMAINSCREEN:SAPLOM_NAVFRAMEWORK_OO_OBJ:1200/subWORKSPACE:SAPLOM_NAVFRAMEWORK_OO_OBJ:0200/subDETAIL:SAPLRHOMDETAILMANAGER:0100/tabsSTRIP_OMDETAIL/tabpDETLTAB08/ssubSUB_OMDETAIL:SAPLRHOMDETAIL_APPL:0501/ssubSUB_PERIOD:SAPLRHOMDETAILMANAGER:0300/txtDISPLAY_PERIOD-BEGDA").text = begin_date
            session.findById("wnd[0]/usr/subMAINSCREEN:SAPLOM_NAVFRAMEWORK_OO_OBJ:1200/subWORKSPACE:SAPLOM_NAVFRAMEWORK_OO_OBJ:0200/subDETAIL:SAPLRHOMDETAILMANAGER:0100/tabsSTRIP_OMDETAIL/tabpDETLTAB08/ssubSUB_OMDETAIL:SAPLRHOMDETAIL_APPL:0501/ssubSUB_PERIOD:SAPLRHOMDETAILMANAGER:0300/txtDISPLAY_PERIOD-BEGDA").caretPosition = 8
            session.findById("wnd[0]").sendVKey(0)
            if session.findById("wnd[1]", False) is not None:
                logging.error(session.findById("wnd[1]/usr/txtMESSTXT1").text)  # 没有更改数据, 周期没有结束（重复做）
                session.findById("wnd[1]/tbar[0]/btn[0]").press()
            # 输入成本中心，比率固定为100
            session.findById("wnd[0]/usr/subMAINSCREEN:SAPLOM_NAVFRAMEWORK_OO_OBJ:1200/subWORKSPACE:SAPLOM_NAVFRAMEWORK_OO_OBJ:0200/subDETAIL:SAPLRHOMDETAILMANAGER:0100/tabsSTRIP_OMDETAIL/tabpDETLTAB08/ssubSUB_OMDETAIL:SAPLRHOMDETAIL_APPL:0501/subDISTRIBUTION:SAPLRHCD:0100/tblSAPLRHCDDISTR/ctxtRHCD_TAB-KOSTL[1,0]").text = cost_center_id
            session.findById("wnd[0]/usr/subMAINSCREEN:SAPLOM_NAVFRAMEWORK_OO_OBJ:1200/subWORKSPACE:SAPLOM_NAVFRAMEWORK_OO_OBJ:0200/subDETAIL:SAPLRHOMDETAILMANAGER:0100/tabsSTRIP_OMDETAIL/tabpDETLTAB08/ssubSUB_OMDETAIL:SAPLRHOMDETAIL_APPL:0501/subDISTRIBUTION:SAPLRHCD:0100/tblSAPLRHCDDISTR/txtRHCD_TAB-PROZT[5,0]").text = "100"
            session.findById("wnd[0]/usr/subMAINSCREEN:SAPLOM_NAVFRAMEWORK_OO_OBJ:1200/subWORKSPACE:SAPLOM_NAVFRAMEWORK_OO_OBJ:0200/subDETAIL:SAPLRHOMDETAILMANAGER:0100/tabsSTRIP_OMDETAIL/tabpDETLTAB08/ssubSUB_OMDETAIL:SAPLRHOMDETAIL_APPL:0501/subDISTRIBUTION:SAPLRHCD:0100/tblSAPLRHCDDISTR/txtRHCD_TAB-PROZT[5,0]").setFocus()
            session.findById("wnd[0]/usr/subMAINSCREEN:SAPLOM_NAVFRAMEWORK_OO_OBJ:1200/subWORKSPACE:SAPLOM_NAVFRAMEWORK_OO_OBJ:0200/subDETAIL:SAPLRHOMDETAILMANAGER:0100/tabsSTRIP_OMDETAIL/tabpDETLTAB08/ssubSUB_OMDETAIL:SAPLRHOMDETAIL_APPL:0501/subDISTRIBUTION:SAPLRHCD:0100/tblSAPLRHCDDISTR/txtRHCD_TAB-PROZT[5,0]").caretPosition = 3
            # 保存
            session.findById("wnd[0]/tbar[0]/btn[11]").press()
            sap_status = session.findById("wnd[0]/sbar/pane[0]").text
            if sap_status != '':
                logging.info(f'SAP状态栏信息：{sap_status}')
            if '数据已保存' not in sap_status:
                lt['T'][rn].cmt('red', '成本分配_成本中心维护失败')
                is_ppome_succ = False
    return is_ppome_succ


def enter_ppoxe(session: SapSession, keycode: str, parent_org_id: str):  # keycode枚举值：PPOSE(查看) PPOME(修改)
    """进入PPOSE或PPOME，查看指定机构编码下的岗位信息(PPOSE不会占用机构)"""
    # 进入[PPOME]
    session.findById("wnd[0]/tbar[0]/okcd").text = f"/n {keycode}"
    session.findById("wnd[0]").sendVKey(0)  # 回车
    # 点选[组织机构]
    session.findById("wnd[0]/shellcont/shell/shellcont[0]/shell/shellcont[1]/shell[1]").selectItem("          1", "&Hierarchy")
    session.findById("wnd[0]/shellcont/shell/shellcont[0]/shell/shellcont[1]/shell[1]").ensureVisibleHorizontalItem("          1", "&Hierarchy")
    session.findById("wnd[0]/shellcont/shell/shellcont[0]/shell/shellcont[1]/shell[1]").clickLink("          1", "&Hierarchy")
    # 输入[机构编码]
    session.findById("wnd[1]/usr/subSEARCH_FUNCTION_SUBSCREEN:SAPLOM_SEARCHTOOL_ORGPLAN:0160/txtSEARCH_FUNCTION-SEARK").text = parent_org_id  # 带名称
    session.findById("wnd[1]").sendVKey(0)  # 回车
    session.findById("wnd[0]/shellcont/shell/shellcont[1]/shell").currentCellColumn = "ADD_FIELD2"  # 选中第二列
    session.findById("wnd[0]/shellcont/shell/shellcont[1]/shell").selectedRows = "0"  # 选中第一行
    session.findById("wnd[0]/shellcont/shell/shellcont[1]/shell").doubleClickCurrentCell()  # 双击单元格
    sap_id = "wnd[0]/usr/subMAINSCREEN:SAPLOM_NAVFRAMEWORK_OO_OBJ:1200/subWORKSPACE:SAPLOM_NAVFRAMEWORK_OO_OBJ:0200/" \
        "subOVERVIEW:SAPLOM_GEN_OVERVIEW:1000/cntlTOOLBAR_CONTAINER/shellcont/shell"
    session.findById(sap_id).pressButton("EXPAND_NODE")
    if session.findById("wnd[1]/usr/btnBUTTON_1", False) is not None:
        session.findById("wnd[1]/usr/btnBUTTON_1").press()
    session.findById(sap_id).pressButton("CONFIGURE_COLUMNS")
    session.findById("wnd[1]/usr/btn%#AUTOTEXT002").press()  # 列格式
    session.findById("wnd[1]/usr/cntlCHECKBOX_TREE/shellcont/shell").selectItem("ORG_STEXT", "Text")
    session.findById("wnd[1]/usr/cntlCHECKBOX_TREE/shellcont/shell").ensureVisibleHorizontalItem("ORG_STEXT", "Text")
    session.findById("wnd[1]/usr/cntlCHECKBOX_TREE/shellcont/shell").changeCheckbox("ORG_STEXT", "Text", -1)  # 名称
    session.findById("wnd[1]/usr/cntlCHECKBOX_TREE/shellcont/shell").selectItem("ORG_OBJID", "Text")
    session.findById("wnd[1]/usr/cntlCHECKBOX_TREE/shellcont/shell").ensureVisibleHorizontalItem("ORG_OBJID", "Text")
    session.findById("wnd[1]/usr/cntlCHECKBOX_TREE/shellcont/shell").changeCheckbox("ORG_OBJID", "Text", -1)  # ID
    session.findById("wnd[1]/tbar[0]/btn[0]").press()  # 继续


def parse_job_infos(session: SapSession, parent_org_id: str) -> Dict[str, List[str]]:
    """解析机构下岗位信息"""
    # 选择日期
    # session.findById("wnd[0]/usr/subCONTROLSTRIP:SAPLOM_NAVFRAMEWORK_OO_OBJ:0010/subTIME_OBJECT_OVERVIEW_STRIP:SAPLOM_STANDARD_TIME_OBJ:0040/subICON:SAPLOM_STANDARD_TIME_OBJ:0045/btnDATE").press()
    # session.findById("wnd[1]/usr/subPERIODCHANGE:SAPLOM_STANDARD_TIME_OBJ:6020/ctxtOMFRAMEWRK-SEL_DATE").text = begin_date
    # session.findById("wnd[1]/usr/subPERIODCHANGE:SAPLOM_STANDARD_TIME_OBJ:6020/ctxtOMFRAMEWRK-SEL_DATE").caretPosition = 8
    # session.findById("wnd[1]/tbar[0]/btn[8]").press()
    sap_id = "wnd[0]/usr/subMAINSCREEN:SAPLOM_NAVFRAMEWORK_OO_OBJ:1200/subWORKSPACE:SAPLOM_NAVFRAMEWORK_OO_OBJ:0200/" \
        "subOVERVIEW:SAPLOM_GEN_OVERVIEW:1000/cntlTOOLBAR_CONTAINER/shellcont/shell"
    # 打印
    session.findById(sap_id).pressButton("PRINT")
    session.findById("wnd[0]/mbar/menu[0]/menu[5]/menu[2]/menu[2]").select()
    session.findById("wnd[1]/usr/subSUBSCREEN_STEPLOOP:SAPLSPO5:0150/sub:SAPLSPO5:0150/radSPOPLI-SELFLAG[1,0]").select()
    session.findById("wnd[1]/tbar[0]/btn[0]").press()
    output_dir = gentempdir()
    session.findById("wnd[1]/usr/ctxtDY_PATH").text = output_dir
    session.findById("wnd[1]/usr/ctxtDY_FILENAME").text = "query_string.txt"
    session.findById("wnd[1]/usr/ctxtDY_FILE_ENCODING").text = "4110"
    session.findById("wnd[1]/tbar[0]/btn[11]").press()
    session.findById("wnd[0]/tbar[0]/btn[12]").press()  # 取消
    query_string_file = Path(output_dir).joinpath('query_string.txt')
    query_string_encoding = peek_file_encoding(query_string_file.as_posix())
    query_string = query_string_file.read_text(encoding=query_string_encoding)
    query_string_lines = query_string.splitlines()[3:-1]
    job_infos: Dict[str, List[str]] = {}
    for line in query_string_lines:
        match_result = re.findall(r'^\s+([^\s]+)\s+([^\s]+)\s+S\s{2}(\d+)\s*$', line)  # 简称\s全称\sS  编号
        if len(match_result) > 0:
            job_short_name, job_full_name, job_id = match_result[0]
            job_infos[job_id] = [job_id, job_short_name, job_full_name, parent_org_id]
        else:
            match_result = re.findall(r'^\s+([^\s]+)\s+S\s{2}(\d+)\s+([^\s]+)\s*$', line)  # 简称\sS  编号\s全称
            if len(match_result) > 0:
                job_short_name, job_id, job_full_name = match_result[0]
                job_infos[job_id] = [job_id, job_short_name, job_full_name, parent_org_id]
    return job_infos


def get_job_infos(parent_org_id: str) -> Dict[str, List[str]]:
    """获取指定机构下岗位信息"""
    with SAP() as session:
        enter_ppoxe(session, 'PPOSE', parent_org_id)
        job_infos = parse_job_infos(session, parent_org_id)
        logging.info(f'机构{parent_org_id}当前岗位个数: {len(job_infos)}')
        return job_infos


@logfn
def create_new_jobs(parent_org_id: str, begin_date: str = '20210101', count: int = 500) -> Dict[str, List[str]]:  # 返回当前机构的岗位列表
    """创建新岗位"""
    job_infos: Dict[str, List[str]] = get_job_infos(parent_org_id)
    job_count = len(job_infos)
    if job_count < BUCKET_MAX_JOBS_COUNT:
        with SAP() as session:
            enter_ppoxe(session, 'PPOME', parent_org_id)
            logging.info('创建新岗位')
            sap_id = "wnd[0]/usr/subMAINSCREEN:SAPLOM_NAVFRAMEWORK_OO_OBJ:1200/subWORKSPACE:SAPLOM_NAVFRAMEWORK_OO_OBJ:0200/" \
                "subOVERVIEW:SAPLOM_GEN_OVERVIEW:1000/cntlTOOLBAR_CONTAINER/shellcont/shell"
            session.findById(sap_id).pressButton("CREATE_OBJECT")
            session.findById("wnd[1]/usr/ctxtHROMDYBASE-HROMBEGDAT").text = begin_date
            session.findById("wnd[1]/usr/tblSAPLOM_UTILITIESTABLE_CONTROL/txtIT_OBJECTS-SHORT[0,0]").text = "新位置"  # 机构简称
            session.findById("wnd[1]/usr/tblSAPLOM_UTILITIESTABLE_CONTROL/txtIT_OBJECTS-STEXT[1,0]").text = "新位置"  # 机构全称
            session.findById("wnd[1]/tbar[0]/btn[0]").press()  # 继续
            logging.info('复制岗位')
            new_job_count = 1
            while new_job_count < count:
                session.findById(sap_id).pressButton("COPY_OBJECT")
                session.findById("wnd[1]/usr/txtOMCOPYINFO-COPYCOUNT").text = '50'  # 副本数: 最大可设置999，白天网络慢，复制岗位数建议为50
                session.findById("wnd[1]/usr/txtOMCOPYINFO-COPYCOUNT").caretPosition = 3
                session.findById("wnd[1]/tbar[0]/btn[0]").press()  # 继续
                logging.info(session.findById("wnd[0]/sbar/pane[0]").text)
                session.findById("wnd[0]/tbar[0]/btn[11]").press()  # 保存
                if '数据已保存' in session.findById("wnd[0]/sbar/pane[0]").text:
                    new_job_count += 50
                    logging.info(f'机构{parent_org_id}当前岗位个数: {job_count + new_job_count}')
                else:
                    logging.warning(session.findById("wnd[0]/sbar/pane[0]").text)
                    logging.error('复制岗位出现非预期结果，停止建岗')
                    break
            job_infos = parse_job_infos(session, parent_org_id)
    with DbSession() as db_session:  # 维护岗位数据到数据库
        res = db_session.query(TB_HR_JOB_BUCKET).filter(TB_HR_JOB_BUCKET.parent_org_id == parent_org_id,
                                                        TB_HR_JOB_BUCKET.job_status == JOB_STATUS.READY.value).all()
        for r in res:
            if r.job_id not in job_infos:
                r.job_status = JOB_STATUS.ERROR.value
                r.remark = '数据库中存在，SAP中不存在'
        for job_id, job_short_name, job_full_name, _parent_org_id in job_infos.values():
            db_session.merge(TB_HR_JOB_BUCKET(parent_org_id=_parent_org_id,
                                              begin_date=begin_date,
                                              job_id=job_id,
                                              job_short_name=job_short_name,
                                              job_full_name=job_full_name,
                                              job_status=JOB_STATUS.READY.value))  # 已存在的岗位信息不会被更新
    return job_infos


@logfn
def chk_4_1_01_20210620(bucket_src_org_id: str, bucket_dst_org_id: str, bucket_err_org_id: str) -> bool:  # 反馈
    """设定
       ------------------
       岗位池机构编码：12000023、12000024、12000026
       ------------------
       1.每个岗位池至少有600个岗位可供使用，一次性补充50个岗位，当岗位池小于100个岗位，或不足以满足业务表单的需求时，自动切换到下一个岗位池
       ，同时触发补岗，若业务表单的需求大于岗位池的容量（即600个以上的岗位需求），可按序使用所有岗位池的岗位，使用完毕后按序依补岗；
       2.缓存期为72小时，之后仍留置于岗位池中视为废弃岗位，执行岗位定界模块4.1.2：
       3.当2.1.1 至2.1.6 模板批导全部成功时，将生成的岗位编号填写至【销售企业建岗模板-【B-岗位编码】】；
       4.当2.1.1 至2.18 模板批导全部成功时，在【销售企业建岗模板-【A-成功标识】】填入“成功”；任一模版批导失败，在【销售企业建岗模板-【A-成功标识】】
       单元格填充红色并填入“失败”，并将失败的模板名称作为批注插入。
       5.无论失败与否，下载1075（----T89-3）备份。
    """
    while True:
        bucket_src_job_infos = get_job_infos(bucket_src_org_id)  # 获取SAP中机构SRC下岗位信息
        bucket_dst_job_infos = get_job_infos(bucket_dst_org_id)  # 获取SAP中机构DST下岗位信息
        update_bucket_job_infos(bucket_src_job_infos, bucket_dst_job_infos)  # 更新数据库中岗位信息状态
        update_bucket_dst_job_count()  # 更新Redis中记录的DST机构下岗位数
        bucket_src_ready_jobs_count = get_bucket_ready_job_count(bucket_src_org_id)
        bucket_dst_ready_jobs_count = get_bucket_ready_job_count(bucket_dst_org_id)
        if bucket_dst_ready_jobs_count < BUCKET_MAX_JOBS_COUNT and bucket_src_ready_jobs_count >= 500:  # 如果DST机构岗位数量少于上限，从SRC机构向DST调岗位，直至DST超过2500或SRC岗位枯竭
            logging.info(f'机构{bucket_dst_org_id}岗位数{bucket_dst_ready_jobs_count}小于{BUCKET_MAX_JOBS_COUNT}')
            logging.info(f'机构{bucket_src_org_id}岗位数{bucket_src_ready_jobs_count}大于500')
            logging.info(f'从机构{bucket_src_org_id}调500岗位到机构{bucket_dst_org_id}')
            move_bucket_src_jobs_to_dst(bucket_src_org_id, bucket_dst_org_id, 500)  # 从SRC机构迁移岗位至DST机构
            continue
        elif bucket_src_ready_jobs_count < BUCKET_MAX_JOBS_COUNT:
            logging.info(f'机构{bucket_src_org_id}岗位数{bucket_src_ready_jobs_count}小于{BUCKET_MAX_JOBS_COUNT}，新建500岗位')
            create_new_jobs(bucket_src_org_id, '20210101', 500)  # 如不满足，则每次补充500个岗位
            continue
        else:
            chk_4_1_02_20210620(bucket_err_org_id)  # 定界超时岗位（优先级较低的任务）
            break
    logging.info('岗位池已满，处于空闲状态，休眠60秒钟后重新扫描岗位池状态')
    sleep(60)
    return True


def chk_4_1_02_20210620(bucket_err_org_id: str) -> bool:  # 生成1000SC模板并批导
    """岗位定界模块
       ------------------
       先生成1000_HR_BI_1000SC模板，再执行批导
       ------------------
       1.【1000_HR_BI_1000SC-【B-职位（岗位）具体名称编码】】从废弃岗位中提取；
       2.【1000_HR_BI_1000SC-【C-开始日期】】固定为次月1日；
       3.【1000_HR_BI_1000SC-【D-结束日期】】固定为“99991231”；
       4.【1000_HR_BI_1000SC-【E-定界日期】】固定为次月月末；
       5.【1000_HR_BI_1000SC-【A-中文名称】】按序递增。
    """
    logging.info(f'定界机构{bucket_err_org_id}废岗')
    err_job_infos: Dict[str, List[str]] = get_job_infos(bucket_err_org_id)
    logging.info('生成批导模板: ' + Path(TEMPLATE_1000_HR_BI_1000SC).name)
    lt_1000_hr_bi_1000sc = load_from_xlsx_file(TEMPLATE_1000_HR_BI_1000SC, skip_header=6)
    three_day_before = day_before(today_yyyymmdd(), 3)  # 3天前
    idx = 0
    with DbSession() as db_session:
        res = db_session.query(TB_HR_JOB_BUCKET).filter(TB_HR_JOB_BUCKET.parent_org_id == bucket_err_org_id,
                                                        TB_HR_JOB_BUCKET.job_status == JOB_STATUS.INUSE.value,
                                                        TB_HR_JOB_BUCKET.inuse_date != '',
                                                        TB_HR_JOB_BUCKET.inuse_date < three_day_before).all()  # 3天前被使用，仍在机构下的岗位
        for r in res:
            if r.job_id in err_job_infos:
                idx += 1
                lt_1000_hr_bi_1000sc['A'][6 + idx].value = str(idx)  # 【A-中文名称】】按序递增
                lt_1000_hr_bi_1000sc['B'][6 + idx].value = r.job_id
                lt_1000_hr_bi_1000sc['C'][6 + idx].value = r.begin_date
                lt_1000_hr_bi_1000sc['D'][6 + idx].value = '99991231'
                _month_end = month_end(r.begin_date)
                lt_1000_hr_bi_1000sc['E'][6 + idx].value = _month_end
    if idx >= 1:
        is_import_succ = import_single_adtable('1000->HR_BI_1000SC', lt_1000_hr_bi_1000sc, enter_mode='reopen')
        if is_import_succ is True:
            logging.info('定界岗位执行成功')
        else:
            logging.info('定界岗位执行失败')
        return is_import_succ  # TODO 不成功或部分成功时如何更新状态
    else:
        logging.info(f'机构{bucket_err_org_id}不存在需要定界的岗位')
        return True


def chk_5_1_01_20210620(df: DataFrame, lt: AdTable) -> bool:
    """清除“岗位定界模板”上所有的批注及单元格颜色，清除【岗位定界模板-【A、B】】两列的数据。
       ------------------
       ------------------
    """
    lt.clear_all_comments()
    lt.clear_all_fgcolors()
    for rn in df.index:
        lt['A'][rn] = ''
        lt['B'][rn] = ''
    return True


def chk_5_1_02_20210620(df: DataFrame, lt: AdTable, rn: int) -> bool:  # 校验岗位编号码值性
    """校验岗位编号码值性
       ------------------
       清除【岗位定界模板-【D-岗位编码】】除数字以外的任何字符（清除空格等符号），再检验其值是否小于等于8位。
       ------------------
       1.若值“不符合条件”，在【岗位定界模板-【D-岗位编码】】】单元格填充红色并插入批注“岗位编码应小于等于8位！”。
    """
    new_value = ''.join([v for v in df['D'][rn] if v.isdigit()])
    lt['D'][rn].value = new_value
    if len(new_value) == 8:
        return True
    lt['D'][rn].cmt('red', '机构编码有误！')
    return False


@logfn
def chk_5_1_03_20210620(df: DataFrame, lt: AdTable, rn: int) -> bool:  # 校验事件执行日期逻辑性
    """校验事件执行日期逻辑性
       ------------------
       先检验【岗位定界模板-【E-开始日期】】是否为当月1日或者次月1日，若不是，检验是否为上月1日，若是，见1，若不是，见2；
       再检验【岗位定界模板-【E-开始日期】】是否全部相同，若有不同，见3。
       ------------------
       1.为“是”，在【岗位定界模板-【E-开始日期】】单元格填充蓝色并插入批注“事件执行日期为上月1日，请核对！”；
       2.为“不是”，在【岗位定界模板-【E-开始日期】】单元格填充红色并插入批注“事件执行日期有误！”；
       3.为“不同”，在【岗位定界模板-【E-开始日期】】单元格填充红色并插入批注“事件执行日期必须相同！”。
    """
    prevmonth01 = prev_month_01()  # 上月1号
    yyyymm01 = month_01()  # 当月1号
    nextmonth01 = next_month_01()  # 下月1号
    if rn >= 5 and df['F'][rn] != df['F'][rn - 1]:
        lt['E'][rn].cmt('red', '同一模板事件执行日期应相同')
        return False
    if valid_date(df['F'][rn]) is False:
        lt['E'][rn].cmt('red', '不是合法的8位日期')
        return False
    if df['E'][rn] in [yyyymm01, nextmonth01]:
        return True
    elif df['E'][rn] == prevmonth01:
        lt['E'][rn].cmt('blue', '事件执行日期为上月1日，请核对！')
        return True
    else:
        lt['E'][rn].cmt('red', '事件执行日期有误！')
        return False


@logfn
def chk_5_1_04_20210620(df: DataFrame, lt: AdTable, rn) -> bool:  # 校验定界日期码值性
    """校验定界日期码值性
       ------------------
       检验【岗位定界模板-【F-定界日期】】是否为【岗位定界模板-【F-开始日期】-月末】，若不是，见1。
       ------------------
       1.为“是”，在【岗位定界模板-【F-定界日期】】单元格填充红色并插入批注“定界日期应为开始日期当月月末！”。
    """
    begin_date = df['C'][rn]
    _month_end = month_end(begin_date)
    if df['F'][rn] != _month_end:
        lt['E'][rn].cmt('red', '定界日期应为开始日期当月月末！')
        return False
    return True


def chk_5_1_05_20210620(df: DataFrame, lt: AdTable, rn) -> bool:  # 校验定界对象码值性
    """校验定界对象码值性
       ------------------
       检验【岗位定界模板-【G-定界对象】】是否为“定界_岗位”或“定界_岗位财科_不含主成本中心”二者之一，若不是，见1；若是，按需跳转。
       ------------------
       1.为“是”，在【岗位定界模板-【G-定界对象】】单元格填充红色并插入批注“定界对象非码值！”。
    """
    if df['G'][rn] not in ['定界_岗位', '定界_岗位财科_不含主成本中心']:
        lt['G'][rn].cmt('red', '定界对象非码值！')
        return False
    return True


def chk_5_1_06_20210620(df: DataFrame, lt: AdTable) -> bool:
    """
       ------------------
       若5.1.1至5.1.5有任一红色批注报错，返回人工；若无红色批注报错，跳转下一规则。
       ------------------
    """
    is_check_passed: List[bool] = [chk_5_1_01_20210620(df, lt)]
    for rn in df.index:
        is_check_passed.append(chk_5_1_02_20210620(df, lt, rn))
        is_check_passed.append(chk_5_1_03_20210620(df, lt, rn))
        is_check_passed.append(chk_5_1_04_20210620(df, lt, rn))
        is_check_passed.append(chk_5_1_05_20210620(df, lt, rn))
    return all(is_check_passed) is True


def chk_6_1_01_20210620(df: DataFrame, lt: AdTable) -> bool:  # 再次批导B007S3
    """再次批导B007S3
       ------------------
       识别模板唯一码，匹配后确认岗位是否是数据库中的数据，若是，先清空【1001_HR_BI_B007S3-【I、J、K】】三列的数据，再批导1001_HR_BI_B007S3
       ------------------
    """
    is_check_passed = True
    if isinstance(lt.wb.properties.description, str) and lt.wb.properties.description != '':
        template_uuid = lt.wb.properties.description
        job_ids: List[str] = []
        with DbSession() as db_session:
            res = db_session.query(TB_HR_JOB_BUCKET).filter(TB_HR_JOB_BUCKET.template_uuid == template_uuid).all()
            job_ids = [r.job_id for r in res]
        for rn in df.index:
            if df['D'][rn] not in job_ids:
                lt['D'][rn].cmt('red', '岗位编码不是已分配的值')
                is_check_passed = False
        if is_check_passed is True:  # 生成并批导1001_HR_BI_B007S3
            lt_1001_hr_bi_b007s3 = load_from_xlsx_file(TEMPLATE_1001_HR_BI_B007S3, skip_header=6)
            for idx, rn in enumerate(df.index, start=1):
                lt_1001_hr_bi_b007s3['A'][6 + idx].value = str(idx)  # 【A-中文名称】】按序递增
                lt_1001_hr_bi_b007s3['B'][6 + idx].value = df['D'][rn]  # 岗位编码
                lt_1001_hr_bi_b007s3['D'][6 + idx].value = df['E'][rn]  # 开始日期
                lt_1001_hr_bi_b007s3['E'][6 + idx].value = df['F'][rn]  # TODO 定界日期（待确认）
                lt_1001_hr_bi_b007s3['F'][6 + idx].value = df['AB'][rn].split(' ')[0]  # TODO 定界日期（待确认）
            logging.info('生成批导模板: ' + Path(TEMPLATE_1001_HR_BI_B007S3).name)  # TODO 保存文件
            is_check_passed = import_single_adtable('1001->HR_BI_B007S3', lt_1001_hr_bi_b007s3, enter_mode='reopen')
    return is_check_passed


def chk_6_2_01_20210620(df: DataFrame, lt: AdTable, bucket_dst_org_id: str) -> bool:  # 再次批导A003SO
    """再次批导A003SO
       ------------------
       识别模板唯一码，匹配后确认岗位是否是数据库中的数据，若是，先清空【1001_HR_BI_A003SO-【H、I、J】】三列的数据，再批导1001_HR_BI_A003SO
       ------------------
    """
    is_check_passed = True
    if isinstance(lt.wb.properties.description, str) and lt.wb.properties.description != '':
        template_uuid = lt.wb.properties.description
        job_ids: List[str] = []
        parent_org_id = bucket_dst_org_id
        with DbSession() as db_session:
            res = db_session.query(TB_HR_JOB_BUCKET).filter(TB_HR_JOB_BUCKET.template_uuid == template_uuid).all()
            parent_org_id = res[0].parent_org_id
            job_ids = [r.job_id for r in res]
        for rn in df.index:
            if df['B'][rn] not in job_ids:
                lt['B'][rn].cmt('red', '岗位编码不是已分配的值')
                is_check_passed = False
        if is_check_passed is True:  # 生成并批导1001_HR_BI_B007S3
            lt_1001_hr_bi_a003so = load_from_xlsx_file(TEMPLATE_1001_HR_BI_A003SO, skip_header=6)
            for idx, rn in enumerate(df.index, start=1):
                if df['L'][rn] == '':
                    lt_1001_hr_bi_a003so['A'][6 + idx].value = str(idx)  # 【A-中文名称】】按序递增
                    lt_1001_hr_bi_a003so['B'][6 + idx].value = df['D'][rn]  # 岗位编码
                    lt_1001_hr_bi_a003so['D'][6 + idx].value = df['E'][rn]  # 开始日期
                    lt_1001_hr_bi_a003so['E'][6 + idx].value = df['F'][rn]  # TODO 定界日期（待确认）
                    lt_1001_hr_bi_a003so['F'][6 + idx].value = parent_org_id
            logging.info('生成批导模板: ' + Path(TEMPLATE_1001_HR_BI_B007S3).name)  # TODO 保存文件
            is_check_passed = import_single_adtable('1001->HR_BI_A003SO', lt_1001_hr_bi_a003so, enter_mode='reopen')
    return is_check_passed


def chk_6_3_01_20210620(df: DataFrame, lt: AdTable) -> bool:  # 检验岗位编码存在性（业务人员账号、风险管控）
    """组合逻辑查询1072
       ------------------
       调用组合逻辑查询1072，在【报告期间】字段里选择【其他期间】，依次输入【岗位定界模板-【E-开始日期】】和【岗位定界模板-【E-开始日期】的次月1日】，
       回车，判断是否有提示“未选取数据”：
       1.未提示“未选取数据”，则：
        1.1 下载数据，先在【岗位定界模板-【D-岗位编码】】中匹配与【1072-【A-对象标识】】相同的岗位编码（S），若匹配不成功，见1；
        1.2 若匹配成功，则锁定相同岗位的最下一行（排除多行干扰），先检验【1072-【D-结束日期】】的值是否是“99991231”，若不是，见2；
        1.3 锁定相同岗位隶属机构的最下一行（即：【1072-【B-OT】=“O”】的最下一行，）（排除多行干扰），将【1072-【A-对象标识】】和【1072-【H-机构全称】】
        以“A 空格 B”的形式填写至【岗位定界模板-【B-岗位所在机构名称】】，并检验【1072-【D-结束日期】】是否存在“99991231”，若不存在，见3；
       2.提示“未选取数据”，见1。
       ------------------
       1.若“匹配不成功”，则在【岗位定界模板-【D-岗位编码】】单元格填充红色并插入批注“岗位编码或开始日期有误！”；
       2.若“不是”，则在【岗位定界模板-【F-定界日期】】单元格填充红色并插入批注“该岗位已被定界！”；
       3.若“不存在”，则在【岗位定界模板-【B-岗位所在机构名称】】单元格填充红色并插入批注“该机构已被定界！”。
    """
    pass  # TODO 待开发


def chk_6_3_02_20210620(df: DataFrame, lt: AdTable) -> bool:  # 检验定界业务逻辑性（业务人员账号、风险管控）
    """组合逻辑查询1071
       ------------------
       组合逻辑查询1071，提取【岗位定界模板-【D-岗位编码】】，在【报告期间】字段里选择【其他期间】，依次输入
       “岗位定界模板-【E-开始日期】的上月1日】”和“99991231”，回车，判断是否有提示“未选取数据”：
       1.未提示“未选取数据”，则下载数据，先在【岗位定界模板-【D-岗位编码】】中匹配与【1071-【A-对象标识】】相同的岗位编码，
       若匹配不成功，见1；若匹配成功，则检验紧邻该岗位下是否存在【1071-【B-OT】=“P”】，若存在，见2；
       2.提示“未选取数据”，见1。
       ------------------
       1.若“匹配不成功”，则在【岗位定界模板-【D-岗位编码】】单元格填充红色并插入批注“岗位编码或开始日期有误！”；
       2.若“存在”，则在【岗位定界模板-【F-定界日期】】单元格填充红色并插入批注“开始日期的上月该岗位仍有人员存在，不可定界！”。
    """
    pass  # TODO 待开发


def chk_6_3_03_20210620(df: DataFrame, lt: AdTable) -> bool:
    """
       ------------------
       若6.3.1-6.3.2有红色批注报错，返回人工；若无红色批注报错，跳转下一规则。
       ------------------
    """
    pass  # TODO 待开发


def chk_6_3_04_20210620(df: DataFrame, lt: AdTable) -> bool:  # 生成1000SC模板并批导
    """1000_HR_BI_1000SC--职务（岗位）具体名称（S)定界
       ------------------
       先生成1000_HR_BI_1000SC模板，再执行批导
       ------------------
       1.【1000_HR_BI_1000SC-【B-职位（岗位）具体名称编码】】从【岗位定界模板-【D-岗位编码】】提取；
       2.【1000_HR_BI_1000SC-【C-开始日期】】从【岗位定界模板-【E-开始日期】】提取；
       3.【1000_HR_BI_1000SC-【D-结束日期】】固定为“99991231”；
       4.【1000_HR_BI_1000SC-【E-定界日期】】从【岗位定界模板-【F-定界日期】】提取；
       5.【1000_HR_BI_1000SC-【A-中文名称】】按序递增。
    """
    pass  # TODO 待开发


def chk_6_3_05_20210620(df: DataFrame, lt: AdTable) -> bool:
    """
       ------------------
       更改完毕后，下载1071，1075备份。
       ------------------
    """
    pass  # TODO 待开发


def chk_6_4_01_20210620(df: DataFrame, lt: AdTable) -> bool:  # 检验岗位编码存在性，定界日期的逻辑性（业务人员账号、风险管控）
    """组合逻辑查询1072
       ------------------
       调用组合逻辑查询1072，在【报告期间】字段里选择【其他期间】，依次输入【岗位定界模板-【E-开始日期】】和【岗位定界模板-【E-开始日期】的次月1日】，
       回车，判断是否有提示“未选取数据”：
       1.未提示“未选取数据”，则：
        1.1 下载数据，先在【岗位定界模板-【D-岗位编码】】中匹配与【1072-【A-对象标识】】相同的岗位编码（S），若匹配不成功，见1；
        1.2 若匹配成功，则锁定相同岗位的最下一行（排除多行干扰），先检验【1072-【D-结束日期】】的值是否是“99991231”，若不是，见2；
        1.3 继续锁定相同岗位的最下一行（排除多行干扰），再检验【1072-【J-结束日期】】的值是否早于【岗位定界模板-【F-定界日期】】
        （“0000.00.00”视为早于所有日期，全篇同），若是，见3；
        1.4 锁定相同岗位隶属机构的最下一行（即：【1072-【B-OT】=“O”】的最下一行，）（排除多行干扰），将该行【1072-【A-对象标识】】和
        【1072-【H-机构全称】】以“A 空格 B”的形式填写至【岗位定界模板-【B-岗位所在机构名称】】，并检验【1072-【D-结束日期】】是否存在“99991231”，若不存在，见4；
       2.提示“未选取数据”，见1。
       ------------------
       1.若“匹配不成功”，则在【岗位定界模板-【D-岗位编码】】单元格填充红色并插入批注“岗位编码或开始日期有误！”；
       2.若“不是”，则在【岗位定界模板-【D-岗位编码】】单元格填充红色并插入批注“该岗位已被定界！”；
       3.若“不是”，则在【岗位定界模板-【F-定界日期】】单元格填充红色并插入批注“定界日期与岗位财科结束日期冲突，请检查！”；
       4.若“不存在”，则在【岗位定界模板-【B-岗位所在机构名称】】单元格填充红色并插入批注“该机构已被定界！”。
    """
    pass  # TODO 待开发


def chk_6_4_02_20210620(df: DataFrame, lt: AdTable) -> bool:
    """
       ------------------
       若6.1.1有红色批注报错，返回人工；若无红色批注报错，跳转下一规则。
       ------------------
    """
    pass  # TODO 待开发


def chk_6_4_03_20210620(df: DataFrame, lt: AdTable) -> bool:
    """
       ------------------
       进入PPOME，执行相应修改：定界岗位财科：业务范围、公司代码、人事范围三项，回车两次后保存，
       若报错，在【岗位定界模板-【A-成功标识】】输入“失败”，并将报错内容作为批注插入；若成功，在【岗位定界模板-【A-成功标识】】输入“成功”。
       ------------------
    """
    pass  # TODO 待开发


def chk_6_4_04_20210620(df: DataFrame, lt: AdTable) -> bool:
    """
       ------------------
       更改完毕后，下载1071，1075备份。
       ------------------
    """
    pass  # TODO 待开发


def main(filename: str, bucket_dst_org_id: str = BUCKET_DST_ORG_ID, bucket_err_org_id: str = BUCKET_ERR_ORG_ID) -> bool:
    global FTP_FILES
    FTP_FILES = {}  # 事件执行前先清空要上传的文件
    if chk_1_1_02_20210620(filename) is False:  # 校验文件名格式
        logging.error('文件名格式不符合要求')
        return False
    if chk_1_1_03_20210620(filename) is False:  # 校验模板[销售企业建岗模板]表头
        logging.error('文件非标准模板表头')
        return False
    if chk_1_1_04_20210630(filename) is False:  # 校验模板[销售机关, 省级机关职能处室及专业中心, 地市机关职能及专业部室, 大区公司及成品油管道]表头
        logging.error('文件非标准模板表头')
        return False
    chk_1_1_05_20210701(filename)  # 清空【销售企业建岗模板-【A至C、U至AC】】的值
    output_dir = Path(filename).parent.as_posix()  # 模板所在目录（RPA执行过程中生成的文件保存至此目录下）
    lt = load_from_xlsx_file(filename, '销售企业建岗模板', skip_header=3)
    lt.del_blank_rows_by_column('E')
    FTP_FILES['模板文件'] = lt
    df = lt.to_dataframe()
    logging.info('分配岗位编号')
    template_uuid: str = str(uuid.uuid1())  # 文件唯一标识
    dict_job_ids: Dict[int, str] = {}  # 行号-岗位编码
    with DbSession() as db_session:
        if isinstance(lt.wb.properties.description, str) and lt.wb.properties.description != '':
            template_uuid = lt.wb.properties.description  # 如果文件已经有标识了，则用文件自身的标识
        else:
            res = db_session.query(TB_HR_JOB_BUCKET).filter(TB_HR_JOB_BUCKET.parent_org_id == bucket_dst_org_id,
                                                            TB_HR_JOB_BUCKET.job_status == JOB_STATUS.READY.value).limit(len(df)).all()
            if len(res) == len(df):
                for idx, r in enumerate(res, start=1):  # 分配指定数量的岗位
                    r.template_name = Path(filename).name[:250]
                    r.template_uuid = template_uuid
                    r.template_rn = idx + 3
                    r.inuse_date = today_yyyymmdd()
                    r.job_status = JOB_STATUS.INUSE.value
                lt.wb.properties.description = template_uuid
                lt.save(filename)
            else:
                logging.error(f'模板需要{len(df)}个岗位，建岗RPA岗位池可用岗位数{len(res)}，不满足需求，请等待岗位池补充足够岗位后再执行事件')
                return False
        res = db_session.query(TB_HR_JOB_BUCKET).filter(TB_HR_JOB_BUCKET.parent_org_id == bucket_dst_org_id,
                                                        TB_HR_JOB_BUCKET.template_uuid == template_uuid).all()
        dict_job_ids = {r.template_rn: r.job_id for r in res}
    update_bucket_dst_job_count()  # 更新Redis中记录的DST机构下岗位数
    logging.info('加载码表库')
    df_dims_diao_pei = load_tb_dim_hr_diao_pei().to_dataframe()  # 码表: 调配码表库
    df_dims_prov = load_from_xlsx_file(filename, '省级机关职能处室及专业中心', skip_header=3).to_dataframe()  # 码表: 省级机关职能处室及专业中心
    df_dims_city = load_from_xlsx_file(filename, '地市机关职能及专业部室', skip_header=3).to_dataframe()  # 码表: 地市机关职能及专业部室
    df_dims_area = load_from_xlsx_file(filename, '大区公司及成品油管道', skip_header=3).to_dataframe()  # 码表: 大区公司及成品油管道
    if chk_1_3_01_20210620(df, lt, df_dims_prov, df_dims_city, df_dims_area, df_dims_diao_pei) is False:
        # 前置校验失败返还岗位编号到岗位池中
        with DbSession() as db_session:
            res = db_session.query(TB_HR_JOB_BUCKET).filter(TB_HR_JOB_BUCKET.template_uuid == template_uuid)
            for r in res:
                r.template_uuid = ''
                r.template_name = ''
                r.template_rn = 0
                r.inuse_date = ''
                r.job_status = JOB_STATUS.READY.value
        update_bucket_dst_job_count()  # 更新Redis中记录的DST机构下岗位数
        lt.wb.properties.description = ''  # 清除uuid
        lt.save(filename)  # 失败时将批注保存至文件中
        logging.error("事前校验未通过，上传失败文件至FTP")
        upload_to_ftp(FTP_FILES.values(), Path(filename).stem, False)
        return False
    df = lt.to_dataframe()  # 更新df
    chk_1_4_01_20210620(df, lt, df_dims_prov, df_dims_city, df_dims_area)  # 提取岗位信息，职务岗位码的再处理
    df = lt.to_dataframe()  # 更新df
    logging.info('生成批导模板')
    lt_1000_hr_bi_1000s = chk_2_1_01_20210620(df, lt, dict_job_ids)  # 生成1000S模板
    lt_9019_hr_bi_9019 = chk_2_1_02_20210620(df, lt, dict_job_ids)  # 生成9019模板
    lt_1001_hr_bi_b007sc = chk_2_1_03_20210620(df, lt, dict_job_ids)  # 生成B007SC模板
    lt_1001_hr_bi_a011sk = chk_2_1_04_20210620(df, lt, dict_job_ids)  # 生成A011SK模板
    lt_1001_hr_bi_a012so = chk_2_1_06_20210620(df, lt, dict_job_ids)  # 生成S_O_A012模板
    lt_1001_hr_bi_b007s3 = chk_2_1_07_20210620(df, lt, dict_job_ids)  # 生成S_03_B007模板
    lt_1001_hr_bi_a003so = chk_2_1_08_20210620(df, lt, dict_job_ids)  # 生成A003SO模板
    FTP_FILES.update({'1000_HR_BI_1000S': lt_1000_hr_bi_1000s,
                      '9019_HR_BI_9019': lt_9019_hr_bi_9019,
                      '1001_HR_BI_B007SC': lt_1001_hr_bi_b007sc,
                      '1001_HR_BI_A011SK': lt_1001_hr_bi_a011sk,
                      '1001_HR_BI_A012SO': lt_1001_hr_bi_a012so,
                      '1001_HR_BI_B007S3': lt_1001_hr_bi_b007s3,
                      '1001_HR_BI_A003SO': lt_1001_hr_bi_a003so})
    save_files_to_dir(FTP_FILES.values(), output_dir)
    is_import_all_succ, is_import_7_succ, is_import_8_succ = chk_2_2_01_20210620(df, lt, lt_1000_hr_bi_1000s, lt_9019_hr_bi_9019, lt_1001_hr_bi_b007sc, lt_1001_hr_bi_a011sk, lt_1001_hr_bi_a012so, lt_1001_hr_bi_b007s3, lt_1001_hr_bi_a003so, dict_job_ids, bucket_err_org_id)
    lt.save(filename)
    if is_import_all_succ is False:
        logging.error('批导流程未通过')
    is_rpa_succ = is_import_all_succ
    if lt_1001_hr_bi_b007s3 is not None and is_import_7_succ is True:
        is_rpa_succ = chk_2_3_01_20210620(lt_1001_hr_bi_b007s3)  # 执行zhrom095
    chk_3_1_00_20210701()
    if is_import_8_succ is False:  # 规则 3.1.0 批导8失败时，岗位留在DST机构下，无法执行后续的零星修改，否则会占用DST机构
        logging.error('指定岗位的隶属机构批导失败，文件上传FTP')
        save_files_to_dir(FTP_FILES.values(), output_dir)
        upload_to_ftp(FTP_FILES.values(), Path(filename).stem, False)
        return False
    df = lt.to_dataframe()  # 更新df
    lt.save(filename)
    is_rpa_succ = chk_3_1_01_20210620(df, lt) and is_rpa_succ  # 零星操作
    is_rpa_succ = chk_3_1_02_20210620(df, lt) and is_rpa_succ  # 虚岗位标识维护
    is_rpa_succ = chk_3_1_03_20210701(df, lt) and is_rpa_succ  # 成本分配_成本中心维护
    if is_rpa_succ is False:
        logging.error("零星操作不成功，上传失败文件至FTP")
    for rn in df.index:
        lt['A'][rn].value = '成功' if is_rpa_succ is True else '失败'
    lt.save(filename)
    save_files_to_dir(FTP_FILES.values(), output_dir)
    upload_to_ftp(FTP_FILES.values(), Path(filename).stem, is_rpa_succ)
    return is_rpa_succ


def update_bucket_job_infos(bucket_src_job_infos: Dict[str, List[str]], bucket_dst_job_infos: Dict[str, List[str]], begin_date: str = '20210101'):
    job_infos: Dict[str, List[str]] = {**bucket_src_job_infos, **bucket_dst_job_infos}
    with DbSession() as db_session:
        for job_id, job_short_name, job_full_name, _parent_org_id in job_infos.values():
            db_session.merge(TB_HR_JOB_BUCKET(parent_org_id=_parent_org_id,
                                              begin_date=begin_date,
                                              job_id=job_id,
                                              job_short_name=job_short_name,
                                              job_full_name=job_full_name,
                                              job_status=JOB_STATUS.READY.value))  # 不存在则插入，存在则忽略
        org_ids: List[str] = list(set([job_info[3] for job_info in job_infos]))
        res = db_session.query(TB_HR_JOB_BUCKET).filter(TB_HR_JOB_BUCKET.job_status.in_([JOB_STATUS.READY.value, JOB_STATUS.INUSE.value, JOB_STATUS.ERROR.value])).all()
        for r in res:
            if r.job_id in job_infos:
                r.parent_org_id = job_infos[r.job_id][3]
                if r.job_id in bucket_src_job_infos and r.job_status != JOB_STATUS.READY.value:
                    r.job_status = JOB_STATUS.READY.value
                    r.remark = ''
            elif r.job_status == JOB_STATUS.READY.value:
                r.job_status = JOB_STATUS.ERROR.value
                r.remark = f'岗位{r.job_id}状态为可用，但岗位不在{org_ids}机构下'  # 一般为人工操作，将岗位调走
            elif r.job_status == JOB_STATUS.INUSE.value:
                r.job_status = JOB_STATUS.SUCC.value  # 岗位状态为使用，但岗位不在SRC、DST机构下，说明岗位已被调走
                r.remark = f'岗位{r.job_id}状态为使用，但岗位不在{org_ids}机构下'


def get_bucket_ready_job_count(parent_job_id: str) -> int:
    """更新岗位池B信息，返回可用岗位数量"""
    with DbSession() as db_session:
        return db_session.query(TB_HR_JOB_BUCKET).filter(TB_HR_JOB_BUCKET.parent_org_id == parent_job_id,
                                                         TB_HR_JOB_BUCKET.job_status == JOB_STATUS.READY.value).count()


def move_bucket_src_jobs_to_dst(bucket_src_org_id: str, bucket_dst_org_id: str, count: int = 500) -> bool:
    logging.info(f'从机构{bucket_src_org_id}迁移岗位至机构{bucket_dst_org_id}')
    logging.info('生成批导模板: ' + Path(TEMPLATE_1001_HR_BI_A003SO).name)
    lt_1001_hr_bi_a003so = load_from_xlsx_file(TEMPLATE_1001_HR_BI_A003SO, skip_header=6)
    with DbSession() as db_session:
        res = db_session.query(TB_HR_JOB_BUCKET).filter(TB_HR_JOB_BUCKET.parent_org_id == bucket_src_org_id,
                                                        TB_HR_JOB_BUCKET.job_status == JOB_STATUS.READY.value).limit(count).all()
        if len(res) < count:
            logging.error(f'机构{bucket_src_org_id}下可用岗位数不足{count}，无法调往机构{bucket_dst_org_id}')
            return False
        for idx, r in enumerate(res, start=1):
            lt_1001_hr_bi_a003so['B'][6 + idx].value = r.job_id
            lt_1001_hr_bi_a003so['D'][6 + idx].value = r.begin_date  # 【D-开始日期】】从【销售企业建岗模板-【F-执行时间】】提取
            lt_1001_hr_bi_a003so['E'][6 + idx].value = '99991231'  # 【E-结束日期】】固定为“99991231”
            lt_1001_hr_bi_a003so['F'][6 + idx].value = bucket_dst_org_id  # 【F-直接隶属机构编码】】从【销售企业建岗模板-【E-岗位所在机构编码】】提取
            lt_1001_hr_bi_a003so['A'][6 + idx].value = str(idx)  # 【A-中文名称】】按序递增
            r.parent_org_id = bucket_dst_org_id
    is_succ = import_single_adtable('1001->HR_BI_A003SO', lt_1001_hr_bi_a003so, enter_mode='reopen')
    return is_succ  # TODO 不成功或部分成功时如何更新状态


def main_4_1_01(bucket_src_org_id: str = BUCKET_SRC_ORG_ID, bucket_dst_org_id: str = BUCKET_DST_ORG_ID, bucket_err_org_id: str = BUCKET_ERR_ORG_ID):
    """岗位池主函数（主要功能：1、维护SRC、DST岗位池，2、定界ERR废弃岗位），只开放给管理员账号
       ------------------
       ------------------
    """
    while True:
        config('销售建岗[新]_补充岗位池.log')
        chk_4_1_01_20210620(bucket_src_org_id, bucket_dst_org_id, bucket_err_org_id)


def main_5_1_01() -> bool:
    """前置检查
       ------------------
       ------------------
    """
    pass  # TODO 待开发


def main_6_1_01() -> bool:
    """独立模块-1：再次批导B007S3
       ------------------
       ------------------
    """
    pass  # TODO 待开发


def main_6_2_01() -> bool:
    """独立模块-2：再次批导A003SO
       ------------------
       ------------------
    """
    pass  # TODO 待开发


def main_6_3_01() -> bool:
    """独立模块-3：定界岗位（【岗位定界模板-【H-定界对象】】为“定界_岗位”，执行此功能）
       ------------------
       ------------------
    """
    pass  # TODO 待开发


def main_6_4_01() -> bool:
    """独立模块-4：定界岗位财科：不含主成本中心（【岗位定界模板-【H-定界对象】】为“定界_岗位财科_不含主成本中心”，执行此功能）
       ------------------
       ------------------
    """
    pass  # TODO 待开发


if __name__ == '__main__':
    filename = "x:/无单号-X420-销售建岗-郭运/无单号-X420-销售建岗-郭运.xlsx"
    config(filename)
    rpa.config.SAP_FUNJ = 'FUNJ0179'
    rpa.config.FSO_USERNAME = 'guoy926'  # 业务人员FSO账号写入全局配置里
    rpa.config.STAFF_GROUP = 'RPA团队'
    rpa.config.STAFF_ID = 49
    rpa.config.STAFF_TYPE = '组员'
    rpa.config.STAFF_NAME = '郭运'
    # main(filename)
