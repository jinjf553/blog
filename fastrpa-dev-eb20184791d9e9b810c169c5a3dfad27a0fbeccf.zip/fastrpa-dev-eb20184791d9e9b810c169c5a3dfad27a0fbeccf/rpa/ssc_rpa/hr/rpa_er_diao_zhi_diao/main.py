"""二级岗位变动"""
# 跨企业调动独立于直属单位间调动
import datetime
import logging
import pathlib
import re
import sys
from typing import Dict, List, Tuple

import pyperclip
import rpa.config
from pandas import DataFrame
from rpa.fastrpa import ftp
from rpa.fastrpa.adtable import AdTable, AdTableRow, load_from_xlsx_file
from rpa.fastrpa.date_funcs import to_yyyymmdd, valid_date
from rpa.fastrpa.log import config, logfn
from rpa.fastrpa.sap.session import SapClose, SapWithoutClose
from rpa.public.create_work_experience import new_work_experience_modify
from rpa.ssc.hr.orm.dims_utils import load_tb_dim_hr_diao_pei
from rpa.ssc.hr.orm.orm import rpa_work_amount
from rpa.ssc.hr.rpa_dir import get_rpa_dir
from rpa.ssc.hr.sap.export_103 import export_103
from rpa.ssc.hr.sap.export_103_bk import export_103_bk
from rpa.ssc.hr.sap.export_1071 import export_1071
from rpa.ssc.hr.sap.export_1072 import export_1072
from rpa.ssc.hr.sap.import_9243 import import_9243
from rpa.ssc.hr.sap.import_checkin import import_checkin
from rpa.ssc.hr.sap.import_checkout import import_checkout
from rpa.ssc.hr.sap.refresh_user_data import refresh_user_data
from rpa.ssc.hr.sap.zhrpy280 import check_zhrpy280
from rpa.ssc.sap.utils import init_sap_id, init_sap_value


@logfn
def load_infile(filename: str) -> AdTable:
    """打开调入模板文件"""
    _in = load_from_xlsx_file(filename, skip_header=6)
    _in.del_blank_rows_by_column('B')
    # _in['B'].apply(init_sap_id)
    # _in['F'].apply(init_sap_id)
    _in['G'].apply(lambda v: v.strip(' \t') if isinstance(v, str) else v)
    _in['H'].apply(lambda v: v.strip(' \t') if isinstance(v, str) else v)
    _in['P'].apply(lambda v: v.strip(' \t') if isinstance(v, str) else v)
    # _in.apply(init_sap_value)
    for cell in _in.cells:
        cell.value = cell.value.rstrip(' \t')
    return _in


@logfn
def load_outfile() -> AdTable:
    _out = load_from_xlsx_file(f'{rpa.config.TEMPLATE_DIR}/调出事件模板表.xlsx', '0000_人事事件_ZH调出', skip_header=6)
    return _out


@logfn
def load_9243() -> AdTable:  # 加载9243模板
    _9243 = load_from_xlsx_file(f'{rpa.config.TEMPLATE_DIR}/模板_9243_HR_BI_9243-从事职业（工种）情况.xlsx', '9243_从事职业（工种）情况', skip_header=6)
    _9243.filename = '9243'
    return _9243


@logfn
def chk_1_1_01(_in: AdTable):  # 清除“调入模板”上所有的批注及单元格颜色
    """清除“调入模板”上所有的批注及单元格颜色。
    """
    # _in.clear_all_comments()
    _in.clear_all_fgcolors()


@logfn
def chk_1_1_2_1(_in: AdTableRow) -> bool:  # 校验人员编号码值性
    """清除【调入模板-【B-人员编号】】除数字以外的任何字符（清除空格等符号），再检验其值是否小于等于8位。
       ------------------
       1.若值“不符合条件”，在【调入模板-【B-人员编号】】单元格填充红色并插入批注“人员编号有误！”，继续检验下一人员。
    """
    staff_id: str = _in['B'].value
    staff_id = ''.join([c for c in staff_id if c.isdigit()])  # 清除除数字以外的任何字符（清除空格等符号）
    staff_id = init_sap_id(staff_id)
    if len(staff_id) != 8:
        _in['B'].cmt('red', '人员编号有误！')
        return False
    else:
        _in['B'].value = staff_id
        return True


@logfn
def chk_1_1_03(_in: AdTable) -> bool:  # 模板本体勾稽关系校验
    """提取【调入模板-【B-人员编号】、【C-人员姓名】】，复制到【编号姓名核查-【B5-人员编号】、【C5-人员姓名】】。
       ------------------
       1.检查zhrpy280导入【编号姓名模板】后是否有报错项，在【调入模板-【B-人员编号】】填充红色并插入批注“Excel员工编号+姓名与系统中员工编号+姓名不一致，请检查;”。
    """
    staffs = [{'staff_id': row['B'].value, 'staff_name': row['C'].value} for row in _in.rows]
    err_staff_ids = check_zhrpy280(staffs)
    if len(err_staff_ids) > 0:
        for err_staff_id in err_staff_ids:
            _in['B'].find(err_staff_id).same_line('B').cmt('red', 'Excel员工编号+姓名与系统中员工编号+姓名不一致，请检查')
        return False
    return True


@logfn
def chk_1_1_03_b(_in: AdTableRow) -> bool:  # 新增检查规则：检查调入模板是否存在空值
    """检查调入模板是否存在空值"""
    is_check_passed = True
    assert_not_null_cols = ['B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'P', 'Q', 'R', 'S', 'BB', 'BC', 'BD', 'BE', 'BF', 'BG', 'BH', 'BI', 'BJ']
    for column in assert_not_null_cols:
        if _in[column].value == '':
            _in[column].cmt('red', '此单元格不应为空')
            is_check_passed = False
    return is_check_passed


@logfn
def chk_1_1_04(_in: AdTableRow) -> bool:  # 1.1.04 校验事件执行日期
    """检验【调入模板-【D-调入日期】】的值是否同时满足下列条件：
       情形1：符合常识，
       情形2：第一位员工的开始日期最后两位为“01”，
       情形3：所有人员的开始日期都与其相同。
       ------------------
       1.若值“不符合条件”，在【调入模板-【D-调入日期】】单元格填充红色并插入批注“调入日期需核对”，继续检验下一人员。
    """
    if valid_date(_in['D'].value) is True and _in.table['D'][7].value[-2:] == '01' and _in['D'].value == _in.table['D'][7].value:
        return True
    else:
        _in['D'].cmt('red', '调入日期需核对')
        return False


@logfn
def chk_1_1_05(_in: AdTableRow, dims: AdTable) -> bool:  # 1.1.05 校验调入原因
    """检验【调入模板-【E-调入原因】】的值是否是【码表库-【AK-二级单位间调动事件调入原因】】或【码表库-【AV-直属单位间调动事件调入原因】】的值。
       ------------------
       1.若值“不符合条件”，在【调入模板-【E-调入原因】】单元格填充红色并插入批注“事件原因非码值”，继续检验下一人员。
    """
    if _in['E'].value in dims.columns_at(['AK', 'AV']).values:
        return True
    else:
        _in['E'].cmt('red', '事件原因非码值')
        return False


@logfn
def chk_1_1_06(_in: AdTableRow) -> bool:  # 1.1.06 校验岗位编号
    """清除【调入模板-【F-岗位编号】】除数字以外的任何字符（清除空格等符号），再检验其值是否小于等于8位。
       ------------------
       1.若值“不符合条件”，在【调入模板-【F-岗位编号】】单元格填充红色并插入批注“岗位编号有误”，继续检验下一人员。
    """
    job_id: str = _in['F'].value
    job_id = ''.join([c for c in job_id if c.isdigit()])  # 清除除数字以外的任何字符（清除空格等符号）
    job_id = init_sap_id(job_id)
    if len(job_id) != 8:
        _in['F'].cmt('red', '岗位编号有误')
        return False
    else:
        _in['F'].value = job_id
        return True


@logfn
def _export_1071(_in: AdTable) -> AdTable:  # 1.1.02 导出组合逻辑查询1071
    """导出组合逻辑查询1072"""
    job_ids = _in['F'].values
    key_date = _in['D'].values[0]
    with SapClose():
        _1071 = export_1071(None, job_ids, key_date)
    _1071.apply(init_sap_value)
    _1071['A'].apply(init_sap_id)
    return _1071


@logfn
def chk_1_1_02(_in: AdTable) -> AdTable:  # 1.1.02 导出组合逻辑查询1072
    """导出组合逻辑查询1072"""
    job_ids = _in['F'].values
    key_date = _in['D'].values[0]
    with SapClose():
        _1072 = export_1072(None, job_ids, key_date)
    _1072.apply(init_sap_value)
    _1072['A'].apply(init_sap_id)
    return _1072


@logfn
def chk_1_1_07_1(_in: AdTableRow, df_dims: DataFrame) -> bool:  # 1.1.07.1 校验人员子组码值性
    """检验【调入模板-【J-人员子组】】的值是否为【调配码表库【L-人员子组】】的值，若不是，见1。
       ------------------
       1.为“不是”，在【调入模板-【J-人员子组】】单元格填充红色并插入批注“人员子组非码值！”，继续检验下一人员。
    """
    if _in['J'].value not in df_dims['L'].values:
        _in['J'].cmt('red', '人员子组非码值！')
        return False
    return True


@logfn
def chk_1_1_07_2_1(_in: AdTableRow, df_dims: DataFrame) -> bool:  # 1.1.07.2.1 校验职位序列、职位层次、职位级别码值性
    """检验【调入模板-【R-职位级别】】的值是否为【调配码表库-【U-职位级别】】的值，若不是，见1；
       若是，提取对应的【调配码表库-【V-职位序列】】和【调配码表库-【W-职位层次】】的值，分别与【调入模板-【P-职位序列】】
       和【调入模板-【Q-职位层次】】的值比较是否相同，若不是，见2。
       ------------------
       1.为“不是”，在【调入模板-【R-职位级别】】单元格填充红色并插入批注“职位级别非码值！”，继续检验下一人员；
       2.为“不是”，若“职位序列”不同，则在【调入模板-【P-职位序列】】单元格填充红色并插入批注“职位序列有误！” ；
         若“职位层次”不同，则在【调入模板-【Q-职位层次】】单元格填充红色并插入批注“职位层次有误！”，继续检验下一人员。
    """
    _r = _in['R'].value
    if _r not in df_dims['U'].values:
        _in['R'].cmt('red', '职位级别非码值！')
        return False
    else:
        is_check_passed = True
        df_tmp = df_dims[df_dims['U'] == _r]
        _v = df_tmp['V'].values[0]
        _w = df_tmp['W'].values[0]
        if _v != _in['P'].value:
            _in['P'].cmt('red', '职位序列有误！')
            is_check_passed = False
        if _w != _in['Q'].value:
            _in['Q'].cmt('red', '职位层次有误！')
            is_check_passed = False
        return is_check_passed


@logfn
def chk_1_1_07_2_2(_in: AdTableRow):  # 1.1.07.2.2 校验兼任职位信息完整性
    """检验【调入模板-【T-兼任职位标识】、【U-兼任职位序列】、【V-兼任职位层次】、【W-兼任职位级别】】是否同时为空或同时不为空，若不是，见1。
       ------------------
       1.为“不是”，在为空的单元格填充红色并插入批注“兼任职务信息不能为空！”，继续检验下一人员。
    """
    _t = _in['T'].value
    _u = _in['U'].value
    _v = _in['V'].value
    _w = _in['W'].value
    is_check_passed = False
    # 20201228 更新，码表【否】前面有空格，判断时需要先去除空格
    if _t.strip() in ('', '否') and _u == '' and _v == '' and _w == '':  # 同时为空
        is_check_passed = True
    elif _t.strip() != '' and _u != '' and _v != '' and _w != '':  # 同时不为空
        is_check_passed = True
    if is_check_passed is False:
        if _t == '':
            _in['T'].cmt('red', '兼任职务信息不能为空！')
        if _u == '':
            _in['U'].cmt('red', '兼任职务信息不能为空！')
        if _v == '':
            _in['V'].cmt('red', '兼任职务信息不能为空！')
        if _w == '':
            _in['W'].cmt('red', '兼任职务信息不能为空！')
    return is_check_passed


@logfn
def chk_1_1_07_2_3(_in: AdTableRow, df_dims: DataFrame) -> bool:  # 1.1.07.2.3 校验兼任职位序列、兼任职位层次、兼任职位级别码值性
    """当【调入模板-【W-兼任职位级别】】不为空时，检验其值是否为【调配码表库-【U-职位级别】】的值，若不是，见1；
       若是，提取对应的【调配码表库-【V-职位序列】】和【调配码表库-【W-职位层次】】的值，分别与【调入模板-【U-兼任职位序列】】和
       【调入模板-【V-兼任职位层次】】的值比较是否相同，若不是，见2。
       ------------------
       1.为“不是”，在【调入模板-【W-兼任职位级别】】单元格填充红色并插入批注“职位级别非码值！”，继续检验下一人员；
       2.为“不是”，若“职位序列”不同，则在【调入模板-【U-兼任职位序列】】单元格填充红色并插入批注“职位序列有误！” ；若“职位层次”
         不同，则在【调入模板-【V-兼任职位层次】】单元格填充红色并插入批注“职位层次有误！”，继续检验下一人员。
    """
    _w = _in['W'].value
    if _w != '':
        if _w not in df_dims['U'].values:
            _in['W'].cmt('red', '职位级别非码值！')
            return False
        else:
            is_check_passed = True
            df_tmp = df_dims[df_dims['U'] == _w]
            if _in['U'].value != df_tmp['V'].values[0]:
                _in['U'].cmt('red', '职位序列有误！')
                is_check_passed = False
            if _in['V'].value != df_tmp['W'].values[0]:
                _in['V'].cmt('red', '职位层次有误！')
                is_check_passed = False
            return is_check_passed
    return True


@logfn
def chk_1_1_07_2_4(_in: AdTableRow, df_dims: DataFrame) -> bool:  # 1.1.07.2.4 校验兼任职位序列与主要职位序列的关联
    """当【调入模板-【U-兼任职位序列】】的值不为空时，检验其与【调入模板-【P-职位序列】】的值是否相同，若相同，见1；
       若不相同，检验【调入模板-【U-兼任职位序列】】的值是否为【调配码表库-【V3】】，若是，见2。
       ------------------
       1.为“相同”，在【调入模板-【U-兼任职位序列】】单元格填充红色并插入批注“兼任职位不能与主要职位处于同一序列！”，继续检验下一人员；
       2.为“是”，在【调入模板-【U-兼任职位序列】】单元格填充红色并插入批注“兼任职位序列不能为管理序列，管理序列必为主要职位序列！” ，继续检验下一人员。
    """
    _u = _in['U'].value
    if _u != '':
        if _u == _in['P'].value:
            _in['U'].cmt('red', '兼任职位不能与主要职位处于同一序列！')
            return False
        elif _u == df_dims['V'][3]:
            _in['U'].cmt('red', '兼任职位序列不能为管理序列，管理序列必为主要职位序列！')
            return False
    return True


@logfn
def chk_1_1_07_2_5(_in: AdTableRow, df_1072: DataFrame) -> bool:  # 1.1.07.2.5 调整班组长标识
    """锁定【调入模板-【F-岗位编号】】与【1072-【B-OT】= S  【A-对象标识】】相同的值，
       检验【1072-【B-OT】= S  【AL-班组长标识】】的值是否为“是”，若是，见1；若不是，见2。
       ------------------
       1.为“是”，先清空【调入模板-【Z-班组长标识】】，再填入“X”，保存，继续检验下一人员；
       2.为“不是”，清空【调入模板-【Z-班组长标识】】，保存，继续检验下一人员。
    """
    job_id = _in['F'].value
    df_tmp = df_1072[(df_1072['A'] == job_id) & (df_1072['B'] == 'S')]
    if df_tmp['AL'].values[0] == '是':
        _in['Z'].value = 'X'
    else:
        _in['Z'].value = ''
    return True


@logfn
def chk_1_1_07_2_6(lt_103: AdTableRow, df_103: DataFrame) -> bool:  # 1.1.7.2.6 检验H类人员岗位状态
    """锁定【组合逻辑导出表103-【S-人员组】】的值为“H”的人员，检验【组合逻辑导出表103-【J-岗位状态】】的值是否为"在岗"，若是，执行下一规则；若不是，见1。
       ------------------
       1.为”不是“，在【组合逻辑导出表103-【J-岗位状态】】填充红色并插入批注”H类人员调动后岗位状态必须为在岗“，继续检验下一人员。
    """
    pass  # TODO 待开发


@logfn
def chk_1_1_07_3(_in: AdTableRow, df_dims: DataFrame) -> bool:  # 1.1.07.3 校验人员子组与职位序列是否对应
    """当【调入模板-【J-人员子组】】的值为【调配码表库-【L3 或 L4 或 L5 或 L6 或 L7】】之一时，在【调配码表库-【U-职位级别】】匹配相同的【调入模板-【R-职位级别】】值，
       检验其对应的【调配码表库-【V-职位序列】】与【调入模板-【P-职位序列】】是否相同，若不相同，见1。
       ------------------
       1.为“不同”，在【调入模板-【I-人员组】】单元格填充红色并插入批注“人员子组与职位序列不对应！”，继续检验下一人员。
    """
    _j = _in['J'].value
    if _j in (df_dims['L'][3], df_dims['L'][4], df_dims['L'][5], df_dims['L'][6], df_dims['L'][7]):
        _r = _in['R'].value
        df_tmp = df_dims[df_dims['U'] == _r]
        if df_tmp['W'].values[0] != _in['Q'].value:
            _in['I'].cmt('red', '人员子组与职位序列不对应！')
            return False
    return True


@logfn
def chk_1_1_07_4(_in: AdTableRow, df_dims: DataFrame) -> bool:  # 1.1.07.4 校验工作合同码值性
    """当【调入模板-【M-工作合同】】不为空时，检验【调入模板-【M-工作合同】】的值是否为【调配码表库【Y-工作合同】】的值，若不是，见1。
       ------------------
       1.为“不是”，在【调入模板-【M-工作合同】】单元格填充红色并插入批注“工作合同非码值！”，继续检验下一人员。
    """
    _m = _in['M'].value
    if _m != '':
        if _m not in df_dims['Y'].values:
            _in['M'].cmt('red', '工作合同非码值！')
            return False
    return True


@logfn
def chk_1_1_07_5(_in: AdTableRow, df_dims: DataFrame) -> bool:  # 1.1.07.5 校验企业统计标识码值性
    """检验【调入模板-【O-企业统计标识】】的值是否为【调配码表库【R-人员标识】】的值，若不是，见1。
       ------------------
       1.为“不是”，在【调入模板-【O-企业统计标识】】单元格填充红色并插入批注“企业统计标识非码值！”，继续检验下一人员。
    """
    _o = _in['O'].value
    if _o not in df_dims['R'].values:
        _in['O'].cmt('red', '企业统计标识非码值！')
        return False
    return True


@logfn
def chk_1_1_08(_in: AdTableRow) -> bool:  # 1.1.08 检验职位名称长度
    """检验【调入模板-【S-职位名称】】值的长度是否超过20个字符。
       ------------------
       1.若值为“是”，在【调入模板-【S-职位名称】】单元格填充红色并插入批注“职位名称超长”，人员全部检验完毕后将表单协同。
    """
    if len(_in['S'].value) > 20:
        _in['S'].cmt('red', '职位名称超长')
        return False
    else:
        return True


@logfn
def chk_1_1_09(_in: AdTableRow) -> bool:  # 1.1.09 检验聘任文号长度
    """检验【调入模板-【X-聘任文号】】值的长度是否超过40个字符。
       ------------------
       1.若值为“是”，在【调入模板-【X-聘任文号】】单元格填充红色并插入批注“聘任文号超长”，人员全部检验完毕后将表单协同。
    """
    if _in['X'].value != '' and len(_in['X'].value) > 40:
        _in['X'].cmt('red', '聘任文号超长')
        return False
    return True


@logfn
def chk_1_1_10(_in: AdTableRow) -> bool:  # 1.1.10 校验调动日期（工作经历开始日期）
    """检验【调入模板-【BB】】的值是否为符合常识的日期。
       ------------------
       1.若值“不为正确日期”，在【调入模板-【BB】】单元格填充红色并插入批注“工作经历开始日期非正确值”，继续检验下一人员。
    """
    if valid_date(_in['BB'].value) is False:
        _in['BB'].cmt('red', '工作经历开始日期非正确值')
        return False
    return True


@logfn
def chk_1_1_11(_in: AdTableRow, dims: AdTable) -> bool:  # 1.1.11 校验人员组
    """检验【调入模板-【BI-调动前人员组】】的值是否是【码表库-【J-人员组】】的值。
       ------------------
       1.若值“不符合条件”，在【调入模板-【BI-调动前人员组】】单元格填充红色并插入批注“调动前人员组非码值”，继续检验下一人员。
    """
    if _in['BI'].value not in dims['J'].values:
        _in['BI'].cmt('red', '调动前人员组非码值')
        return False
    else:
        return True


@logfn
def chk_1_1_11_1(_in: AdTableRow) -> bool:  # 1.1.11.1 校验人员组是否发生变化
    """检验【调入模板-【I-人员组】】的值是否与【调入模板-【BI-调动前人员组】】相同，若不同，见1。
       ------------------
       1.为“不同”，在【调入模板-【H-人员组】】单元格填充红色并插入批注“二调/直调RPA不允许调整人员组！”，继续检验下一人员。
    """
    if _in['I'].value != _in['BI'].value:
        _in['H'].cmt('red', '二调/直调RPA不允许调整人员组！')
        return False
    return True


@logfn
def chk_1_1_12(_in: AdTableRow, dims: AdTable) -> bool:  # 1.1.12 校验人事子范围、人事范围码值
    """检验【调入模板-【H-人事子范围】】的值是否是【码表库-【E-人事子范围】】的值，若不是，见1；
       若是，提取同一行的【码表库-【D-人事范围】】，检验其与【调入模板-【G-人事范围】-（前四位代码）】是否相同，若不相同，见2；
       若相同，检验【调入模板-【G-人事范围】】是否是【码表库-【AS-人事范围全称】】的值，若不是，见3。
       ------------------
       1.若“不是”，在【调入模板-【H-人事子范围】】单元格填充红色并插入批注“人事子范围非码值”，在【调入模板-【G-人事范围】】单元格填充红色并插入批注“人事范围未予校验”，继续检验下一人员；
       2.若“不是”，在【调入模板-【G-人事范围】】单元格填充红色并插入批注“人事范围与人事子范围不对应”，继续检验下一人员；
       3.若“不是”，在【调入模板-【G-人事范围】】单元格填充红色并插入批注“人事范围非码值”，继续检验下一人员。
    """
    if _in['H'].value not in dims['E'].values:
        _in['H'].cmt('red', '人事子范围非码值')
        _in['G'].cmt('red', '人事范围未予校验')
        return False
    else:
        _h = _in['H'].value
        if _in['G'].value[:4] != dims['E'].find(_h).same_line('D').value:
            _in['G'].cmt('red', '人事范围与人事子范围不对应')
            return False
        elif _in['G'].value not in dims['AS'].values:
            _in['G'].cmt('red', '人事范围非码值”')
            return False
        else:
            return True


@logfn
def chk_1_1_13(_in: AdTableRow, dims: AdTable) -> bool:  # 1.1.13 校验调动前人事子范围、调动前人事范围码值
    """检验【调入模板-【BH-调动前人事子范围】】的值是否是【码表库-【E-人事子范围】】的值，若不是，见1；
       若是，提取同一行的【码表库-【D-人事范围】】，检验其与【调入模板-【BG-调动前人事范围】-（前四位代码）】是否相同，若不相同，见2；
       若相同，检验【调入模板-【BG-调动前人事范围】】是否是【码表库-【AS-人事范围全称】】前4位的值，若不是，见3。
       ------------------
       1.若“不是”，在【调入模板-【BH-调动前人事子范围】】单元格填充红色并插入批注“人事子范围非码值”，在【调入模板-【BG-调动前人事范围】】单元格填充红色并插入批注“调动前人事范围未予校验”，继续检验下一人员；
       2.若“不是”，在【调入模板-【BG-调动前人事范围】】单元格填充红色并插入批注“人事范围与人事子范围不对应”，继续检验下一人员；
       3.若“不是”，在【调入模板-【BG-调动前人事范围】】单元格填充红色并插入批注“调动前人事范围非码值”，继续检验下一人员。
    """
    if _in['BH'].value not in dims['E'].values:
        _in['BH'].cmt('red', '人事子范围非码值')
        _in['BG'].cmt('red', '调动前人事范围未予校验')
        return False
    else:
        _bh = _in['BH'].value
        if _in['BG'].value[:4] != dims['E'].find(_bh).same_line('D').value:
            _in['BG'].cmt('red', '人事范围与人事子范围不对应')
            return False
        else:
            _bg = _in['BG'].value
            for value in dims['AS'].values:
                if value != '' and len(value) >= 4 and _bg == value[:4]:
                    return True
            _in['BG'].cmt('red', '调动前人事范围非码值')
            return False


@logfn
def chk_1_1_14(_in: AdTableRow, dims: AdTable) -> bool:  # 1.1.14 校验企业自定义分类1
    """检验【调入模板-【N-企业自定义员工分类】】是否为空值，若是空值，跳转下一人继续执行，若不是空值，检验其值是否为【码表库-【F-企业自定义分类1】】的值。
       ------------------
       1.若值不为码表值，在【调入模板-【N-企业自定义员工分类】】单元格填充红色并插入批注“企业自定义分类1非码值”，继续检验下一人员。
    """
    if _in['N'].value != '' and _in['N'].value != '清空':
        if _in['N'].value not in dims['F'].values:
            _in['N'].cmt('red', '企业自定义分类1非码值')
            return False
    return True


@logfn
def chk_1_1_15(_in: AdTableRow, dims: AdTable) -> bool:  # 1.1.15 校验企业自定义分类2
    """检验【调入模板-【AZ】】是否为空值，若是空值，跳转下一人继续执行，若不是空值，检验其值是否为“清空”，
       若是，保留其值并跳转下一人继续执行；若不是，检验其值是否为【码表库-【G-企业自定义分类2】】的值。
       ------------------
       1.若值不为“清空”且不为码表值，在【调入模板-【AZ】】单元格填充红色并插入批注“企业自定义分类2非码值”，继续检验下一人员。
    """
    if _in['AZ'].value != '' and _in['AZ'].value != '清空':
        if _in['AZ'].value not in dims['G'].values:
            _in['AZ'].cmt('red', '企业自定义分类2非码值')
            return False
    return True


@logfn
def chk_1_1_16(_in: AdTableRow, dims: AdTable) -> bool:  # 1.1.16 校验企业自定义分类3
    """检验【调入模板-【BA】】是否为空值，若是空值，跳转下一人继续执行，若不是空值，检验其值是否为“清空”，
       若是，保留其值并跳转下一人继续执行；若不是，检验其值是否为【码表库-【H-企业自定义分类3】】的值
       ------------------
       1.若值不为“清空”且不为码表值，在【调入模板-【BA】】单元格填充红色并插入批注“企业自定义分类3非码值”，继续检验下一人员。
    """
    if _in['BA'].value != '' and _in['BA'].value != '清空':
        if _in['BA'].value not in dims['H'].values:
            _in['BA'].cmt('red', '企业自定义分类3非码值')
            return False
    return True


@logfn
def chk_1_1_17(_in: AdTableRow, dims: AdTable) -> bool:  # 1.1.17 校验是否是二级单位间调动、校验二级单位间调动事件原因
    """先检验同一人的【调入模板-【G-人事范围】】与【调入模板-【BG-调动前人事范围】】是否相同，若不同，执行1.1.18规则；
       若相同，再检验【调入模板-【H-人事子范围】】与【调入模板-【BH-调动前人事子范围】】的值是否相同，若相同，见1；
       若不相同，见2。
       ------------------
       1.若值为“相同”，检验【调入模板-【G-人事范围】-前四位代码】是否是【码表库-【C】】的值，
         若不是，在【调入模板-【C-人员姓名】】单元格填充红色并插入批注“事件类型应为：岗位变动事件！”，继续检验下一人员；
       2.若值为“不同”，
         当【调入模板-【BG-调动前人事范围】的值为"5650"时，检验【调入模板-【E-调入原因】】的值是否是【码表库-【AK4】】，
         若不是，在【调入模板-【C-人员姓名】】单元格填充红色并插入批注“调入原因错误1！”，继续检验下一人员；
         当【调入模板-【BG-调动前人事范围】的值不为"5650"时，检验【调入模板-【E-调入原因】】的值是否是【码表库-【AK3】】，
         若不是，在【调入模板-【C-人员姓名】】单元格填充红色并插入批注“调入原因错误2！”，继续检验下一人员。
    """
    if _in['G'].value.split(' ')[0] != _in['BG'].value:
        return chk_1_1_18(_in, dims)
    else:
        if _in['H'].value == _in['BH'].value:
            # 1
            if _in['G'].value[:4] not in dims['C'].values:
                _in['C'].cmt('red', '事件类型应为：岗位变动事件！')
                return False
            else:
                return True
        else:
            # 2
            if _in['BG'].value == '5650':  # dims['AS'][466].value.split(' ')[0]
                if _in['E'].value != dims['AK'][4].value:
                    _in['C'].cmt('red', '调入原因错误1！')
                    return False
                else:
                    return True
            else:
                if _in['E'].value != dims['AK'][3].value:
                    _in['C'].cmt('red', '调入原因错误2！')
                    return False
                else:
                    return True


@logfn
def chk_1_1_18(_in: AdTableRow, dims: AdTable) -> bool:  # 1.1.18 校验是二级单位间调动还是直属单位间调动、校验调动事件原因、批注直属单位间调动类型（规则18是可选检查项，由规则17根据情形调用）
    """分别提取同一人的【调入模板-【G-人事范围】】与【调入模板-【BG-调动前人事范围】】的前四位数字代码，在【码表库-【BD-人事范围】】找到相同的值，
       先检验【码表库-【BB-合并机构代码】】是否相同，再检验【码表库-【BC-直属单位代码】】是否相同。
       ------------------
       1.当【码表库-【BB-合并机构代码】】相同，且【码表库-【BC-直属机构代码】】也相同时，检验【调入模板-【E-调入原因】】的值是否是【码表库-【AK3】】，
         若不是，在【调入模板-【C-人员姓名】】单元格填充红色并插入批注“调入原因错误3！”，继续检验下一人员；
       2.当【码表库-【BB-合并机构代码】】相同，但【码表库-【BC-直属机构代码】】不相同时，检验【调入模板-【E-调入原因】】的值是否是【码表库-【AV3】】，
         若不是，在【调入模板-【C-人员姓名】】单元格填充红色并插入批注“调入原因错误4！”，继续检验下一人员；若是，在【调入模板-【C-人员姓名】】单元格填充
         蓝色并插入批注“上市与非上市公司间调动！”，继续检验下一人员；
       3.当【码表库-【BB-合并机构代码】】不同，且【码表库-【BC-直属机构代码】】也不相同时，检验【调入模板-【E-调入原因】】的值是否是【码表库-【AV3】】，
         若不是，在【调入模板-【C-人员姓名】】单元格填充红色并插入批注“调入原因错误5！”，继续检验下一人员；若是，在【调入模板-【C-人员姓名】】单元格填充
         蓝色并插入批注“跨企业调动！”，继续检验下一人员。
    """
    _bb = dims['BD'].find(_in['G'].value[:4]).same_line('BB').value
    _prev_bb = dims['BD'].find(_in['BG'].value[:4]).same_line('BB').value
    _bc = dims['BD'].find(_in['G'].value[:4]).same_line('BC').value
    _prev_bc = dims['BD'].find(_in['BG'].value[:4]).same_line('BC').value
    if _bb == _prev_bb and _bc == _prev_bc:  # 1
        if _in['E'].value != dims['AK']['3'].value:
            _in['C'].cmt('red', '调入原因错误3！')
            return False
    if _bb == _prev_bb and _bc != _prev_bc:  # 2
        if _in['E'].value != dims['AV'][3].value:
            _in['C'].cmt('red', '调入原因错误4！')
            return False
        else:
            _in['C'].cmt('blue', '上市与非上市公司间调动！')
            return True
    if _bb != _prev_bb and _bc != _prev_bc:  # 3
        if _in['E'].value != dims['AV'][3].value:
            _in['C'].cmt('red', '调入原因错误5！')
            return False
        else:
            _in['C'].cmt('blue', '跨企业调动！')
            return True
    return True


@logfn
def chk_1_1_19(_in: AdTableRow, df_1072: DataFrame) -> bool:  # 1.1.19 校验岗位本身或其隶属机构的财务科目设置的人事范围、人事子范围与调入模板是否一致
    """锁定【组合逻辑导出表1072-【B-OT】= S】与【调入模板-【F-岗位编号】】相同的值，若在【组合逻辑导出表1072】中未匹配到相应的岗位，见1；在匹配到的岗位中：
       1.先检验【组合逻辑导出表1072-【B-OT】= S（S的首行）】的【P-PA】、【Q-PSubarea】是否都不为空，若不是（即：任一单元格有值），见2；
         若是，则分别与【调入模板-【G-人事范围】-前四位代码】、【H-人事子范围】-前四位代码】】检验是否相同，若不相同，见3；若全部为空，执行下条规则：
       2.检验【组合逻辑导出表1072-【B-OT】= O（S的次行）】的【P-PA】、【Q-PSubarea】是否都为空，若都为空，见4；若只有任一单元格有值（另一单元格为空），见5；
         若都不为空，则分别与【调入模板-【G-人事范围】-前四位代码、【H-人事子范围】-前四位代码】检验是否相同，若不相同，见6。
       ------------------
       1.为“未在1072表中匹配到相应的岗位”，在【调入模板-【F-岗位编号】】单元格填充红色并插入批注“岗位编号有误！”，继续检验下一人员；
       2.为“不是”，在【调入模板-【A-中文名称】】单元格填充红色并插入批注“岗位财务科目设置有值，但人事范围、人事子范围信息不完整！”，继续检验下一人员；
       3.为“不相同”，在【调入模板-【A-中文名称】】单元格填充红色并插入批注“岗位财务科目设置有值，但其人事范围、人事子范围与模板信息不一致！”，继续检验下一人员；
       4.为”空“，在【调入模板-【A-中文名称】】单元格填充蓝色并插入批注“岗位所在机构的财务科目设置的人事范围、人事子范围为空！”，继续检验下一人员；
       5.为“只有任一单元格有值（另一单元格为空）”，在【调入模板-【A-中文名称】】单元格填充红色并插入批注“岗位所在机构的财务科目设置有值，但人事范围、人事子范围信息不完整！”，继续检验下一人员；
       6.为“不相同”，在【调入模板-【A-中文名称】】单元格填充红色并插入批注“岗位所在机构的财务科目设置的人事范围、人事子范围与调入模板不一致！”，继续检验下一人员；
    """
    job_id = _in['F'].value
    df_tmp = df_1072[(df_1072['A'] == job_id) & (df_1072['B'] == 'S')]
    if df_tmp.empty is True:
        _in['F'].cmt('red', '岗位编号有误！')  # 1
        return False
    _p = df_tmp['P'].values[0]
    _q = df_tmp['Q'].values[0]
    if '' in (_p, _q) and _p + _q != '':
        _in['A'].cmt('red', '岗位财务科目设置有值，但人事范围、人事子范围信息不完整！')  # 2
        return False
    elif _p != '' and _q != '':
        if _in['G'].value.startswith(_p) is False or _in['H'].value.startswith(_q) is False:
            _in['A'].cmt('red', '岗位财务科目设置有值，但其人事范围、人事子范围与模板信息不一致！')  # 3
            return False
    elif _p == '' and _q == '':  # 全部为空
        o_rn = None
        min_idx = df_tmp.index[0]
        max_idx = max(df_1072.index)
        for rn in range(min_idx, max_idx + 1):
            if df_1072['B'][rn] == 'S':
                continue
            elif df_1072['B'][rn] == 'O':
                o_rn = rn
                break
            else:
                break
        if o_rn is None:
            raise ValueError(f'在1072岗位编号为{job_id}且B列为S的行，向下未找到B列值为O行')

        __p = df_1072['P'][o_rn]
        __q = df_1072['Q'][o_rn]
        if __p == '' and __q == '':
            _in['A'].cmt('blue', '岗位所在机构的财务科目设置的人事范围、人事子范围为空！')  # 4
            return True
        if '' in (_p, _q) and _p + _q != '':
            _in['A'].cmt('red', '岗位所在机构的财务科目设置有值，但人事范围、人事子范围信息不完整！')  # 5
            return False
        if _in['G'].value.startswith(__p) is False or _in['H'].value.startswith(__q) is False:
            _in['A'].cmt('red', '岗位所在机构的财务科目设置的人事范围、人事子范围与调入模板不一致！')  # 6
            return False
    return True


@logfn
def chk_1_1_20(_in: AdTableRow, df_1072: DataFrame) -> bool:  # 1.1.20 校验岗位分类信息，未校验岗位分类序列（事后校验）
    """锁定【组合逻辑导出表1072-【B-OT】= S】与【调入模板-【F-岗位编号】】相同的值，先检验【组合逻辑导出表1072-【B-OT】= S-【D-结束日期】】的值是否为”99991231“，若不是，见1；
       再提取【组合逻辑导出表1072-【B-OT= S】-【AA-薪酬标杆岗位类别】】的值，当【组合逻辑导出表1072-【B-OT】= S-【AM-虚岗位标识】】的值不为“是“时，检验其是否满足下述两个条件之一，
       若不满足，见2：
       1.当该值首字符为“1”或者”2“时：【W-所属专业大类】不为空，且【AG-所属工种类别】、【AH-所属工种】为空，且：
           当【W-所属专业大类】的值为”20、21、22、24、43、46“六者任一值时，【Y-所属专业小类】为空；
           当【W-所属专业大类】的值不为”20、21、22、24、43、46“六者任一值时，【Y-所属专业小类】不为空；
       2.当该值首字符为“3”或者“4”时：【AG-所属工种类别】、【AH-所属工种】不为空，且【W-所属专业大类】、【Y-所属专业小类】为空。
       ------------------
       1.为“不是”，在【调入模板-【F-岗位编号】】单元格填充红色并插入批注“该岗位已被定界，请更换岗位“，继续检验下一人员。
       2.为“不满足条件”，在【调入模板-【F-岗位编号】】单元格填充红色并插入批注“岗位分类信息有误“，继续检验下一人员。
    """
    job_id = _in['F'].value
    df_tmp = df_1072[(df_1072['A'] == job_id) & (df_1072['B'] == 'S')]
    is_check_passed = True
    _d: str = df_tmp['D'].values[0]
    if to_yyyymmdd(_d) != '99991231':
        _in['F'].cmt('red', '该岗位已被定界，请更换岗位')
        is_check_passed = False
    _aa: str = df_tmp['AA'].values[0]
    _am: str = df_tmp['AM'].values[0]
    if _am != '是':
        is_rule_2_passed = False
        _w = df_tmp['W'].values[0]
        _ag = df_tmp['AG'].values[0]
        _ah = df_tmp['AH'].values[0]
        _y = df_tmp['Y'].values[0]
        if _aa.startswith('1') or _aa.startswith('2'):
            if _w != '' and _ag == '' and _ah == '':
                if _w in ('20', '21', '22', '24', '43', '46') and _y == '':
                    is_rule_2_passed = True
                elif _w not in ('20', '21', '22', '24', '43', '46') and _y != '':
                    is_rule_2_passed = True
        elif _aa.startswith('3') or _aa.startswith('4'):
            if _ag != '' and _ah != '' and _w == '' and _y == '':
                is_rule_2_passed = True
        if is_rule_2_passed is False:
            _in['F'].cmt('red', '岗位分类信息有误')
            is_check_passed = False
    return is_check_passed


@logfn
def chk_1_1_21(_in: AdTableRow, _1072: AdTable, dims: AdTable) -> bool:  # 1.1.21 校验薪酬标杆与职位序列是否一致
    """锁定【组合逻辑导出表1072-【B-OT】= S】与【调入模板-【F-岗位编号】】相同的值，提取【组合逻辑导出表1072-【B-OT= S】-【AA-薪酬标杆岗位类别】】的值，
       当【组合逻辑导出表1072-【B-OT】= S-【AM-虚岗位标识】】的值不为“是“时，检验其是否满足下述三个条件之一，若不满足，见1：
       1.当该值首字符为“1”时：【调入模板-【P-职位序列】】的值为【码表库-【V3】】；
       2.当该值首字符为”2“时：【调入模板-【P-职位序列】】的值为【码表库-【V12】】；
       3.当该值首字符为“3”或者“4”时：【调入模板-【P-职位序列】】的值为【码表库-【V31】】。
       ------------------
       1.为“不满足条件”，在【调入模板-【P-职位序列】】单元格填充红色并插入批注“薪酬标杆与职位序列不对应”，继续检验下一人员。
    """
    job_id = _in['F'].value
    _aa = _1072['A'].find_all(job_id).same_line('B').find('S').same_line('AA').value  # 薪酬标杆岗位类别
    _am = _1072['A'].find_all(job_id).same_line('B').find('S').same_line('AM').value  # 虚岗位标识
    if _am.strip(' \t') != '是':
        if _aa[:1] == '1' and _in['P'].value == dims['V'][3].value:
            return True
        elif _aa[:1] == '2' and _in['P'].value == dims['V'][12].value:
            return True
        elif _aa[:1] in ('3', '4') and _in['P'].value == dims['V'][31].value:
            return True
        else:
            _in['P'].cmt('red', '薪酬标杆与职位序列不对应')
            return False
    else:
        return True


@logfn
def chk_1_1_22(_in: AdTableRow, df_1071: DataFrame) -> bool:  # 1.1.22 检验是否分配岗位类别、岗位分类序列与薪酬标杆是否对应
    """锁定【组合逻辑导出表1071-【B-OT】= S】与【调入模板-【F-岗位编号】】相同的值，当【组合逻辑导出表1071-【B-OT】= S-【AM-虚岗位标识】】的值
       不为“是“时，检验【组合逻辑导出表1071-【B-OT】= S-【K-岗位类别】】是否不为空，若未空，见1；；再检验下述条件：
       1.当【组合逻辑导出表1071-【B-OT】= S-【P-岗位分类序列】】为”1“时，检验【组合逻辑导出表1071-【B-OT】= S-【Z-薪酬标杆岗位类别】-第一个数字】是否
         为”1“，若不是，见2；
       2.当【组合逻辑导出表1071-【B-OT】= S-【P-岗位分类序列】】为”2“时，检验【组合逻辑导出表1071-【B-OT】= S-【Z-薪酬标杆岗位类别】-第一个数字】是否
         为”2“，若不是，见2；
       3.当【组合逻辑导出表1071-【B-OT】= S-【P-岗位分类序列】】为”3“时，检验【组合逻辑导出表1071-【B-OT】= S-【Z-薪酬标杆岗位类别】-第一个数字】是否
         为”3“或者”4“，若不是，见2。
       ------------------
       1.为“空”，在【调入模板-【F-岗位编号】】单元格填充红色并插入批注“没有分配岗位类别”，继续检验下一人员；
       2.为“空”，在【调入模板-【F-岗位编号】】单元格填充红色并插入批注“岗位分类序列与薪酬标杆不对应”，继续检验下一人员。。
    """
    job_id = _in['F'].value
    df_tmp = df_1071[(df_1071['A'] == job_id) & (df_1071['B'] == 'S')]
    _am = df_tmp['AM'].values[0]
    if _am == '是':
        if df_tmp['K'].values[0] == '':
            _in['F'].cmt('red', '没有分配岗位类别')
            return False
    else:
        _p = df_tmp['P'].values[0]
        _z = df_tmp['Z'].values[0]
        if _p == '1' and _z.startswith('1') is False:
            _in['F'].cmt('red', '岗位分类序列与薪酬标杆不对应1')
            return False
        elif _p == '2' and _z.startswith('2') is False:
            _in['F'].cmt('red', '岗位分类序列与薪酬标杆不对应2')
            return False
        elif _p == '3' and (_z.startswith('3') or _z.startswith('4')) is False:
            _in['F'].cmt('red', '岗位分类序列与薪酬标杆不对应3')
            return False
    return True


@logfn
def chk_1_1_23(_in: AdTableRow, df_1072: DataFrame) -> bool:  # 1.1.23 补充调入模板工作经历所在机构
    """锁定【组合逻辑导出表1072-【B-OT】= S】与【调入模板-【F-岗位编号】】相同的值，提取提取【组合逻辑导出表1072-【B-OT= O】-【H-机构全称】】复制到
       【调入模板-【AS-所在单位及部门名称】】中。
    """
    job_id = _in['F'].value
    df_tmp = df_1072[(df_1072['A'] == job_id) & (df_1072['B'] == 'S')]
    if df_tmp.empty is True:
        raise ValueError(f'1072找不到岗位编号{job_id}【B-OT】=S的行')  # 不应该出现的情形
    o_rn = None
    min_idx = df_tmp.index[0]
    max_idx = max(df_1072.index)
    for rn in range(min_idx, max_idx + 1):
        if df_1072['B'][rn] == 'S':
            continue
        elif df_1072['B'][rn] == 'O':
            o_rn = rn
            break
        else:
            break
    if o_rn is None:
        raise ValueError(f'在1072岗位编号为{job_id}且B列为S的行，向下未找到B列值为O行')
    _in['AS'].value = df_1072['H'][o_rn]
    return True


@logfn
def chk_1_1_24(_in: AdTableRow) -> bool:  # 1.1.24 补充调入模板工作经历职务
    """将【调入模板-【BD-调动后岗位】】复制到【调入模板-【AT-从事工作及担任职务】】中。
    """
    _in['AT'].value = _in['BD'].value
    return True


@logfn
def chk_1_1_25(_in: AdTableRow, df_103: DataFrame, df_dims: DataFrame) -> bool:  # 1.1.25 调出、调入事件分支
    """若103同一人【组合逻辑导出表103-【G-事件类型】】的值不存在“调出”也不存在“调入”，见1；若存在“调出”但不存在“调入”，且【调入模板-【C-人员姓名】】的批注为“跨企业调动！”时，见2；
       若存在“调出”但不存在“调入”，但【调入模板-【C-人员姓名】】的批注不为“跨企业调动！”时，见3；若不存在“调出”但存在“调入”，见4；若存在“调出”也存在“调入”，见5。
       ------------------
       1.为“不存在“调出”也不存在“调入””，清空同一人【调入模板-【BK-【只执行调入事件标识】】的值；
       2.为“存在“调出”但不存在“调入””，且【调入模板-【C-人员姓名】】的批注为“跨企业调动！”时，先清空同一人【调入模板-【BK-【只执行调入事件标识】】的值，
       再检验以下条件是否成立：【103-【H-事件原因】+【I-事件原因】】的值与去空格的【码表库-【AU3】】的值相同且同时【调入模板-【E-调入原因】】的值与【码表库-【AV3】】相同，
       若成立，在【调入模板-【BK-【只执行调入事件标识】】写入“是”；若不成立，在【调入模板-【A-【中文名称】】单元格填充红色并插入批注“该人员已有调出事件，但调出原因与调入原因不匹配，
       请更正错误后再执行RPA！”；
       3.为“存在“调出”但不存在“调入””，但【调入模板-【C-人员姓名】】的批注不为“跨企业调动！”时，清空同一人【调入模板-【BK-【只执行调入事件标识】】的值；
       4.为“不存在“调出”但存在“调入””，清空同一人【调入模板-【BK-【只执行调入事件标识】】的值，在【调入模板-【A-【中文名称】】单元格填充红色并插入批注“该人员有调入事件，
       无调出事件，请删除调入事件后再执行RPA！”；
       5.为“存在“调出”也存在“调入””，清空同一人【调入模板-【BK-【只执行调入事件标识】】的值，在【调入模板-【A-【中文名称】】单元格填充红色并插入批注“该人员有调出、调入事件已存在，
       请删除调出、调入事件后再执行RPA！”。
    """
    is_check_passed = True
    staff_id = _in['B'].value
    df_tmp = df_103[df_103['A'] == staff_id]
    _103_g_list = df_tmp['G'].values
    if '调出' not in _103_g_list and '调入'not in _103_g_list:  # 1
        _in['BK'].value = ''
    elif '调出' in _103_g_list and '调入' not in _103_g_list:
        _c_comment = _in['C'].comment.text if _in['C'].comment is not None else ''
        if '跨企业调动！' in _c_comment:  # 2
            _in['BK'].value = ''
            is_match = False
            if df_tmp['H'].values[0] + ' ' + df_tmp['I'].values[0] == df_dims['AU'][3]:  # 25 调往其他直属单位
                if _in['E'].value == df_dims['AV'][3]:  # 25 从其他直属单位调入
                    is_match = True
                    _in['BK'].value = '是'
            if is_match is False:
                _in['A'].cmt('red', '该人员已有调出事件，但调出原因与调入原因不匹配，请更正错误后再执行RPA！')
                is_check_passed = False
        else:  # 3
            _c_comment = _in['C'].comment.text if _in['C'].comment is not None else ''
            if '跨企业调动！' not in _c_comment:
                _in['BK'].value = ''
    elif '调出' not in _103_g_list and '调入' in _103_g_list:  # 4
        _in['BK'].value = ''
        _in['A'].cmt('red', '该人员有调入事件，无调出事件，请删除调入事件后再执行RPA！')
        is_check_passed = False
    elif '调出' in _103_g_list and '调入' in _103_g_list:  # 5
        _in['BK'].value = ''
        _in['A'].cmt('red', '该人员有调出、调入事件已存在，请删除调出、调入事件后再执行RPA！')
        is_check_passed = False
    return is_check_passed


@logfn
def upload_to_ftp(templates: List[AdTable], subticket_title: str, is_succ: bool) -> str:  # 1.1.26 上传校验失败的调入模板
    """只要调入模板有任一单元格填充红色，终止程序执行，上传到F_in【“调入”】-【“失败”】文件夹下；若无，继续执行下一规则。
    """
    subticket_type = '二级单位间调动'
    if '直属单位间调动' in subticket_title:
        subticket_type = '直属单位间调动'
    yyyymmdd = datetime.datetime.now().strftime(r'%Y%m%d')
    yyyymm = yyyymmdd[:6]
    # dirname = _in.filename[:-4]
    if is_succ is True:
        is_succ_str = '成功'
    else:
        is_succ_str = '失败'
    failed_ftp_path = pathlib.Path(f'/HR人事/{subticket_type}/{yyyymm}/{yyyymmdd}/{is_succ_str}').joinpath(subticket_title).as_posix()
    temp_dir = get_rpa_dir(subticket_type, subticket_title, is_succ)
    logging.info(f'创建本地文件夹：{temp_dir}')
    filenames = []
    for template in templates:
        try:
            filename = template.save_to(temp_dir)
            filenames.append(filename)
        except Exception:
            logging.error('文件生成失败')
    ftp.upload_files(filenames, failed_ftp_path)
    return temp_dir


@logfn
def chk_1_2_1(_in: AdTable, _out: AdTable):  # 1.2.1 生成调出模板的人员编号、姓名、岗位、人事范围、人事子范围
    """提取【调入模板-【BK-【只执行调入事件标识】】不为“是”的行，将【调入模板-【B-人员编号】、【C-人员姓名】、【D-调出日期】【F-岗位编号】、【G-人事范围】、
       【H-人事子范围】】复制到【调出模板-【B-人员编号】、【C-人员姓名】、【D-调入日期】、【F-岗位编号】、【G-人事范围】、【H-人事子范围】】中。
    """
    _out['B'] = _in['B']
    _out['C'] = _in['C']
    _out['D'] = _in['D']
    _out['F'] = _in['F']
    _out['G'] = _in['G']
    _out['H'] = _in['H']


@logfn
def chk_1_2_2(_in: AdTable, _out: AdTable, dims: AdTable) -> None:  # 1.2.2 生成调出模板的事件原因
    """在【码表库-【AK-二级单位间调动事件调入原因】】中查找【调入模板-【E-调入原因】】的值，若有相同的值，则将对应的【码表库-【AJ-二级单位间调动事件调出原因】】
                                                                                                  粘贴到【调出模板-【E-调出原因】】中；
       若无相同的值，则在【码表库-【AV-直属单位间调动事件调入原因】】中查找【调入模板-【E-调入原因】】的值，将对应的【码表库-【AU-直属单位间调动事件调出原因】】
                                                                                                    粘贴到【调出模板-【E-调出原因】】中。
    """
    for row in _in.rows:
        _e = row['E'].value
        staff_id = row['B'].value
        if _e != '' and _e in dims['AK'].values:
            _out['B'].find(staff_id).same_line('E').value = dims['AK'].find(_e).same_line('AJ').value
        elif _e != '' and _e in dims['AV'].values:
            _out['B'].find(staff_id).same_line('E').value = dims['AV'].find(_e).same_line('AU').value
    _out.re_index('A')  # 生成序列号


@logfn
def chk_1_2_3(_out: AdTable, repeat_times=3) -> bool:  # 1.2.3 批导调出模板
    """批导调出模板(调出批导失败后可重复执行)
    """
    for i in range(repeat_times):
        is_import_succ = import_checkout(_out)
        if is_import_succ is True:
            return True
    return False


@logfn
def chk_1_2_4_bk(_in: AdTable) -> AdTable:
    """事前导出组合逻辑查询103备份
    """
    staff_ids = _in['B'].values
    key_date = _in['D'].values[0]
    with SapClose():
        _103: AdTable = export_103_bk(None, staff_ids, key_date)
    return _103


@logfn
def chk_1_2_4(_in: AdTable) -> AdTable:  # 1.2.4 批导成功，导出组合逻辑查询103
    """批导成功，导出组合逻辑查询103
    """
    staff_ids = _in['B'].values
    key_date = _in['D'].values[0]
    with SapClose():
        _103: AdTable = export_103(None, staff_ids, key_date)
    return _103


@logfn
def chk_1_2_5(_103: AdTable) -> bool:  # 1.2.5 检验事件是否批导成功
    """检验同一人的【组合逻辑导出表103-【G-事件类型】】的值是否有“调出”。
       ------------------
       1.不为“调出”，在【组合逻辑导出表103-【G-事件类型】】填充红色并插入批注“调出模板批导不成功”，人员全部检验完毕后将模板上传到Flt_in【“调入”】-【“失败”】文件夹下，程序结束。
    """
    is_check_passed = True
    for row in _103.rows:
        staff_id = row['A'].value
        if '调出' not in _103['A'].find_all(staff_id).same_line('G').values:
            row['G'].cmt('red', '调出模板批导不成功')
            is_check_passed = False
    return is_check_passed


@logfn
def chk_1_3_1(_in: AdTable) -> bool:  # 1.3.1 批导调入模板
    """批导调入模板
    """
    return import_checkin(_in)


@logfn
def chk_1_3_2(_in: AdTable) -> AdTable:  # 1.3.2 批导成功，导出组合逻辑查询103
    """批导成功，导出组合逻辑查询103
    """
    staff_ids = _in['B'].values
    key_date = _in['D'].values[0]
    with SapClose():
        _103: AdTable = export_103(None, staff_ids, key_date)
    return _103


@logfn
def chk_1_3_3(_103: AdTable):  # 1.3.3 校验调入模板批导是否成功
    """检验同一人的【组合逻辑导出表103-【G-事件类型】】的值是否有“调入”。
       ------------------
       1.不为“调入”，在【组合逻辑导出表103-【G-事件类型】】填充红色并插入批注“调入模板批导不成功”，人员全部检验完毕后将模板上传到Flt_in【“调入”】-【“失败”】文件夹下，程序结束。
    """
    is_check_passed = True
    for row in _103.rows:
        staff_id = row['A'].value
        if '调入' not in _103['A'].find_all(staff_id).same_line('G').values:
            row['G'].cmt('red', '调入模板批导不成功')
            is_check_passed = False
    return is_check_passed


@logfn
def chk_1_3_4(_in: AdTable, dims: AdTable, _9243: AdTable) -> bool:  # 1.3.4 生成“新增从事职业工种信息”模板（特殊处理高桥石化）
    """当【调入模板-【G-人事范围】前四个数字不等于“1680”】时，提取【调入模板-【P-职位序列】】的值为【码表库-【V31】】的人员，将其【调入模板-【B-人员编号】
             【C-人员姓名】【D-开始日期】】的值粘贴进分别粘贴进【新增从事职业工种信息-【B-人员编号】【C-人员姓名】【D-开始日期】】中，【新增从事职业工种信息-【E-结束日期】】
             的值为【99991231】，【新增从事职业工种信息-【职业技能鉴定范围标识】】的值为【X】，自动生成序号；
       当【调入模板-【G-人事范围】前四个数字等于“1680”】时，提取【调入模板-【P-职位序列】】的值为【码表库-【V31】】的人员，将其【调入模板-【B-人员编号】【C-人员姓名】【D-开始日期】】
             的值粘贴进分别粘贴进【新增从事职业工种信息-【B-人员编号】【C-人员姓名】【D-开始日期】】中，【新增从事职业工种信息-【E-结束日期】】的值为【99991230】，
             【新增从事职业工种信息-【职业技能鉴定范围标识】】的值为【X】，自动生成序号。
    """
    is_9243_import = False  # 是否需要批导
    for _in_row in _in.rows:
        if _in_row['G'].value[:4] != '1680' and _in_row['P'].value == dims['V'][31].value:
            new_row = _9243.add_row()
            new_row['B'].value = _in_row['B'].value
            new_row['C'].value = _in_row['C'].value
            new_row['D'].value = _in_row['D'].value
            new_row['E'].value = '99991231'
            new_row['F'].value = 'X'
            _9243.re_index('A')
            is_9243_import = True
        elif _in_row['G'].value[:4] != '1680' and _in_row['P'].value == dims['V'][31].value:
            new_row = _9243.add_row()
            new_row['B'].value = _in_row['B'].value
            new_row['C'].value = _in_row['C'].value
            new_row['D'].value = _in_row['D'].value
            new_row['E'].value = '99991230'
            new_row['F'].value = 'X'
            _9243.re_index('A')
            is_9243_import = True
    return is_9243_import


@logfn
def chk_1_3_5(_9243: AdTable) -> bool:  # 1.3.5 批导调入模板新增从事职业工种信息模板
    """批导新增从事职业工种信息模板
    """
    if import_9243(_9243) is False:
        return False
    return True


@logfn
def chk_2_1_1(_in: AdTable, _103: AdTable, dims: AdTable):  # 2.1.1 修改企业自定义分类2、3，校验、修改/重新带出工资总额控制范围
    """1.第一步，进入PA30“组织分配”屏，第一个人第四步执行完毕后，对第二个人重新执行第一步，直至所有人遍历一遍，执行2.1.2规则；
       2.第二步，检验【调入模板-【AZ-调动后企业自定义分类2】】是否为空，若为空，将“企业自定义分类2”清空；若不为空，将“企业自定义分类2”修改为“数字/英文”部分；
       3.第三步，检验【调入模板-【BA-调动后企业自定义分类3】】是否为空，若为空，将“企业自定义分类3”清空；若不为空，将“企业自定义分类3”修改为“数字/英文”部分；
       4.第四步，提取【组合逻辑导出表103-【P-PA】、【R-人事子范围】、【Z-PArea】】的值，依序匹配在【码表库-【AA】、【AB】、【AE】中相同的值，检验同一行的【码表库-【AF】】
                是否与【组合逻辑导出表103-【AB】】相同，若“不相同”，将“工资总额控制范围”修改为【码表库-【AF】】的值，回车两次，保存。
       备注：第四步无论是否在码表库找到AF的值，或者与103-AB相同，都在“工资总额控制范围”回车两次，保存。
    """
    with SapWithoutClose('login_tx') as session:
        for row in _in.rows:
            logging.info('[零星修改-PA30修改企业自定义分类2、3，校验、修改/重新带出工资总额控制范围]-事务码 /n pa30')
            session.findById("wnd[0]/tbar[0]/okcd").text = '/n pa30'
            session.findById("wnd[0]").sendVKey(0)
            staff_id = row['B'].value
            logging.info(f'[零星修改-PA30修改企业自定义分类2、3，校验、修改/重新带出工资总额控制范围]-输入人员编号：{staff_id}')
            session.findById("wnd[0]/usr/ctxtRP50G-PERNR").text = staff_id  # 人员编号
            session.findById("wnd[0]").sendVKey(2)
            logging.info('[零星修改-PA30修改企业自定义分类2、3，校验、修改/重新带出工资总额控制范围]-点选劳动关系')
            session.findById("wnd[0]/usr/tabsMENU_TABSTRIP/tabpTAB03").select()  # 劳动关系
            logging.info('[零星修改-PA30修改企业自定义分类2、3，校验、修改/重新带出工资总额控制范围]-点选组织分配及岗位聘任')
            session.findById("wnd[0]/usr/tabsMENU_TABSTRIP/tabpTAB03/ssubSUBSCR_MENU:SAPMP50A:0400/subSUBSCR_ITMENU:SAPMP50A:0310/tblSAPMP50ATC_MENU").getAbsoluteRow(0).selected = -1  # 组织分配及岗位聘任
            logging.info('[零星修改-PA30修改企业自定义分类2、3，校验、修改/重新带出工资总额控制范围]-点击概览')
            session.findById("wnd[0]/tbar[1]/btn[20]").press()  # 概览
            logging.info('[零星修改-PA30修改企业自定义分类2、3，校验、修改/重新带出工资总额控制范围]-点选第一条记录')
            session.findById("wnd[0]/usr/tblMP000100TC3000").getAbsoluteRow(0).selected = -1  # 第一条记录
            logging.info('[零星修改-PA30修改企业自定义分类2、3，校验、修改/重新带出工资总额控制范围]-点击更改')
            session.findById("wnd[0]/tbar[1]/btn[6]").press()  # 更改
            company_group2 = '' if row['AZ'].value == '' else row['AZ'].value.split(' ')[0]
            logging.info(f'[零星修改-PA30修改企业自定义分类2、3，校验、修改/重新带出工资总额控制范围]-修改企业自定义分类2为{company_group2}')
            session.findById("wnd[0]/usr/subSUBSCREEN_T582C:ZP000100:0200/ctxtP0001-ZZ_QYZDYYGFL1").text = company_group2  # 企业自定义分类2
            company_group3 = '' if row['BA'].value == '' else row['BA'].value.split(' ')[0]
            logging.info(f'[零星修改-PA30修改企业自定义分类2、3，校验、修改/重新带出工资总额控制范围]-修改企业自定义分类3为{company_group3}')
            session.findById("wnd[0]/usr/subSUBSCREEN_T582C:ZP000100:0200/ctxtP0001-ZZ_QYZDYYGFL2").text = company_group3  # 企业自定义分类3
            try:
                _p = _103['A'].find(staff_id).same_line('P').value
                _q = _103['A'].find(staff_id).same_line('Q').value
                _r = _103['A'].find(staff_id).same_line('R').value  # 这里规则不对，码表库存的是编码+空格+文本，这里还要取q列的编码拼接然后在码表库AB列查找
                _z = _103['A'].find(staff_id).same_line('Z').value
                _ab = _103['A'].find(staff_id).same_line('AB').value
                _af = dims['AA'].find_all(_p).same_line('AB').find_all(f'{_q} {_r}').same_line('AE').find(_z).same_line('AF').value
                if _af != _ab:
                    if session.findById("wnd[0]/usr/subSUBSCREEN_T582C:ZP000100:0200/ctxtP0001-ZZ_ZEFW").Changeable is True:
                        logging.info('[零星修改-PA30修改企业自定义分类2、3，校验、修改/重新带出工资总额控制范围]-修改工资总额控制范围')
                        session.findById("wnd[0]/usr/subSUBSCREEN_T582C:ZP000100:0200/ctxtP0001-ZZ_ZEFW").text = _af  # 有可能无法修改
                        logging.info('[零星修改-PA30修改企业自定义分类2、3，校验、修改/重新带出工资总额控制范围]-修改工资总额控制范围成功')
                    else:
                        logging.warning('[零星修改-PA30修改企业自定义分类2、3，校验、修改/重新带出工资总额控制范围]-修改工资总额控制范围失败')
            except AttributeError:
                logging.warning('[零星修改-PA30修改企业自定义分类2、3，校验、修改/重新带出工资总额控制范围]-未找到AF的值')
            logging.info('[零星修改-PA30修改企业自定义分类2、3，校验、修改/重新带出工资总额控制范围]-两次回车保存')
            session.findById("wnd[0]").sendVKey(0)  # 回车1
            session.findById("wnd[0]").sendVKey(0)  # 回车2
            session.findById("wnd[0]/tbar[0]/btn[11]").press()  # 保存
            sap_status = session.findById("wnd[0]/sbar/pane[0]").text
            logging.info(f'[零星修改-PA30修改企业自定义分类2、3，校验、修改/重新带出工资总额控制范围]-SAP状态栏信息：{sap_status}')


@logfn
def chk_2_1_2(_in: AdTable):  # 2.1.2 修改工作经历开始日期
    """1.提取【调入模板-【BB-工作经历开始日期】】与【调入模板-【D-调入日期】】不同的人员，进入PA30“工作经历”屏，将最上部的工作经历开始日期修改为
         【调入模板-【BB-工作经历开始日期】】，并将第二条的工作经历结束日期修改为【调入模板-【BB-工作经历开始日期】的前一天】。
    """
    with SapWithoutClose('login_tx') as session:
        for row in _in.rows:
            if row['BB'].value != row['D'].value:
                staff_id = row['B'].value
                begin_date = row['BB'].value
                end_date = (datetime.datetime.strptime(begin_date, r"%Y%m%d") - datetime.timedelta(days=1)).strftime(r'%Y%m%d')
                logging.info('[零星修改-PA30修改工作经历开始日期]-事务码 /n pa30')
                session.findById("wnd[0]/tbar[0]/okcd").text = '/n pa30'
                session.findById("wnd[0]").sendVKey(0)
                logging.info(f'[零星修改-PA30修改工作经历开始日期]-输入人员编号：{staff_id}')
                session.findById("wnd[0]/usr/ctxtRP50G-PERNR").text = staff_id  # 人员编号
                session.findById("wnd[0]").sendVKey(2)
                logging.info('[零星修改-PA30修改工作经历开始日期]-点选人员基本情况')
                session.findById("wnd[0]/usr/tabsMENU_TABSTRIP/tabpTAB01").select()  # 人员基本情况
                logging.info('[零星修改-PA30修改工作经历开始日期]-点选工作经历')
                session.findById("wnd[0]/usr/tabsMENU_TABSTRIP/tabpTAB01/ssubSUBSCR_MENU:SAPMP50A:0400/subSUBSCR_ITMENU:SAPMP50A:0310/tblSAPMP50ATC_MENU").getAbsoluteRow(4).selected = -1  # 工作经历
                logging.info('[零星修改-PA30修改工作经历开始日期]-点击概览')
                session.findById("wnd[0]/tbar[1]/btn[20]").press()  # 概览
                logging.info('[零星修改-PA30修改工作经历开始日期]-点选第一条记录')
                session.findById("wnd[0]/usr/tblMP002300TC3000").getAbsoluteRow(0).selected = -1  # 第一条记录
                logging.info('[零星修改-PA30修改工作经历开始日期]-点击更改')
                session.findById("wnd[0]/tbar[1]/btn[6]").press()  # 更改
                logging.info(f'[零星修改-PA30修改工作经历开始日期]-填入工作经历开始日期：{begin_date}')
                session.findById("wnd[0]/usr/ctxtP0023-BEGDA").text = begin_date  # 工作经历开始日期
                logging.info('[零星修改-PA30修改工作经历开始日期]-点击保存')
                session.findById("wnd[0]/tbar[0]/btn[11]").press()  # 保存
                sap_status = session.findById("wnd[0]/sbar/pane[0]").text
                logging.info(f'[零星修改-PA30修改工作经历开始日期]-SAP状态栏信息：{sap_status}')
                session.findById("wnd[0]/usr/tblMP002300TC3000").getAbsoluteRow(1).selected = -1  # 第二条记录
                logging.info('[零星修改-PA30修改工作经历开始日期]-点击更改')
                session.findById("wnd[0]/tbar[1]/btn[6]").press()  # 更改
                logging.info(f'[零星修改-PA30修改工作经历开始日期]-填入工作经历结束日期：{end_date}')
                session.findById("wnd[0]/usr/ctxtP0023-ENDDA").text = end_date  # 工作经历结束日期
                logging.info('[零星修改-PA30修改工作经历开始日期]-点击保存')
                session.findById("wnd[0]/tbar[0]/btn[11]").press()  # 保存
                sap_status = session.findById("wnd[0]/sbar/pane[0]").text
                logging.info(f'[零星修改-PA30修改工作经历开始日期]-SAP状态栏信息：{sap_status}')


@logfn
def chk_2_1_3(_103: AdTable, dims: AdTable):  # 2.1.3 定界从事职业工种信息结束日期
    """提取【组合逻辑导出表103-【AV-职位序列】】在【码表库-【V3】和【V12】-的汉字部分】有相同字段的人员，检验【组合逻辑导出表103-【BU-结束日期】】的值是否为空值。
       ------------------
       1.为“不是空值”，RPA进入PA30将“从事职业工种信息”定界。
    """
    with SapWithoutClose('login_tx') as session:
        for row in _103.rows:
            rn = row.row_idx
            _av = row['AV'].value
            staff_id = row['A'].value  # 员工编号
            _bu = row['BU'].value
            if (_av in dims['V'][3].value or _av in dims['V'][12].value) and _bu != '0000.00.00':
                logging.info('[零星修改-PA30定界从事职业工种信息结束日期]-事务码 /n pa30')
                session.findById("wnd[0]/tbar[0]/okcd").text = '/n pa30'
                session.findById("wnd[0]").sendVKey(0)
                logging.info(f'[零星修改-PA30定界从事职业工种信息结束日期]-输入人员编号：{staff_id}')
                session.findById("wnd[0]/usr/ctxtRP50G-PERNR").text = staff_id  # 人员编号
                session.findById("wnd[0]").sendVKey(2)
                logging.info('[零星修改-PA30定界从事职业工种信息结束日期]-点选劳动关系')
                session.findById("wnd[0]/usr/tabsMENU_TABSTRIP/tabpTAB03").select()  # 劳动关系
                logging.info('[零星修改-PA30定界从事职业工种信息结束日期]-点选从事职业（工种）信息')
                session.findById("wnd[0]/usr/tabsMENU_TABSTRIP/tabpTAB03/ssubSUBSCR_MENU:SAPMP50A:0400/subSUBSCR_ITMENU:SAPMP50A:0310/tblSAPMP50ATC_MENU").getAbsoluteRow(2).selected = -1  # 从事职业（工种）信息
                logging.info('[零星修改-PA30定界从事职业工种信息结束日期]-点击工具栏概览按钮')
                session.findById("wnd[0]/tbar[1]/btn[20]").press()  # 概览
                logging.info('[零星修改-PA30定界从事职业工种信息结束日期]-点选第一条记录')
                session.findById("wnd[0]/usr/tblMP924300TC3000").getAbsoluteRow(0).selected = -1  # 第一条记录
                logging.info('[零星修改-PA30定界从事职业工种信息结束日期]-点击工具栏修改按钮')
                session.findById("wnd[0]/tbar[1]/btn[6]").press()  # 修改
                key_date = row['C'].value
                end_date = session.findById("wnd[0]/usr/ctxtP9243-ENDDA").text
                new_end_date = (datetime.datetime.strptime(key_date, "%Y.%m.%d") - datetime.timedelta(days=1)).strftime('%Y%m%d')
                logging.info(f'[零星修改-PA30定界从事职业工种信息结束日期]-将结束日期从{end_date}修改为{new_end_date}')
                session.findById("wnd[0]/usr/ctxtP9243-ENDDA").text = new_end_date  # 结束日期修改为关键日期前一天
                logging.info('[零星修改-PA30定界从事职业工种信息结束日期]-保存')
                session.findById("wnd[0]/tbar[0]/btn[11]").press()  # 保存
                sap_status = session.findById("wnd[0]/sbar/pane[0]").text
                logging.info(f'[零星修改-PA30定界从事职业工种信息结束日期]-SAP状态栏信息：{sap_status}')
            else:
                logging.info(f'[零星修改-PA30定界从事职业工种信息结束日期]-103第{rn}行，员工{staff_id}，BU-结束日期为{_bu}，不需要定界')


@logfn
def chk_2_1_4(_9243: AdTable):  # 2.1.4 重新带出从事职业工种信息
    """锁定【新增从事职业工种信息-【B-人员编号】】的人员，进入PA30重新带出从事职业工种信息。
    """
    with SapWithoutClose('login_tx') as session:
        for row in _9243.rows:
            staff_id = row['B'].value
            logging.info('[零星修改-PA30重新带出从事职业工种信息]-事务码 /n pa30')
            session.findById("wnd[0]/tbar[0]/okcd").text = '/n pa30'
            session.findById("wnd[0]").sendVKey(0)
            logging.info(f'[零星修改-PA30重新带出从事职业工种信息]-输入人员编号：{staff_id}')
            session.findById("wnd[0]/usr/ctxtRP50G-PERNR").text = staff_id  # 人员编号
            session.findById("wnd[0]").sendVKey(2)
            logging.info('[零星修改-PA30重新带出从事职业工种信息]-点选劳动关系')
            session.findById("wnd[0]/usr/tabsMENU_TABSTRIP/tabpTAB03").select()  # 劳动关系
            logging.info('[零星修改-PA30重新带出从事职业工种信息]-点选从事职业（工种）信息')
            session.findById("wnd[0]/usr/tabsMENU_TABSTRIP/tabpTAB03/ssubSUBSCR_MENU:SAPMP50A:0400/subSUBSCR_ITMENU:SAPMP50A:0310/tblSAPMP50ATC_MENU").getAbsoluteRow(2).selected = -1  # 从事职业（工种）信息
            logging.info('[零星修改-PA30重新带出从事职业工种信息]-点击概览')
            session.findById("wnd[0]/tbar[1]/btn[20]").press()  # 概览
            logging.info('[零星修改-PA30重新带出从事职业工种信息]-点选第一条记录')
            session.findById("wnd[0]/usr/tblMP924300TC3000").getAbsoluteRow(0).selected = -1  # 第一条记录
            logging.info('[零星修改-PA30重新带出从事职业工种信息]-点击更改')
            session.findById("wnd[0]/tbar[1]/btn[6]").press()  # 更改
            session.findById("wnd[0]/usr/ctxtP9243-BEGDA").text = row['D'].value  # 开始日期
            session.findById("wnd[0]/usr/ctxtP9243-ENDDA").text = row['E'].value  # 结束日期
            logging.info('[零星修改-PA30重新带出从事职业工种信息]-保存')
            session.findById("wnd[0]/tbar[0]/btn[11]").press()  # 保存
            sap_status = session.findById("wnd[0]/sbar/pane[0]").text
            logging.info(f'[零星修改-PA30重新带出从事职业工种信息]-SAP状态栏信息：{sap_status}')


def chk_2_1_5_step1(_in: AdTableRow, dims: AdTable) -> str:
    remark = ''
    if _in['G'].value[:4] == _in['BG'].value:
        if _in['G'].value[:4] != '5650':  # dims['AS'][466].value
            remark = '16230'  # (1)
        else:
            remark = '16240'  # (2)
    else:
        _g = _in['G'].value[:4]
        _bg = _in['BG'].value[:4]
        if dims['BD'].find(_g) is None or dims['BD'].find(_bg) is None:
            # 5 为“未匹配到”，跳过此人
            return ''
        elif dims['BD'].find(_g).same_line('BB').value != dims['BD'].find(_bg).same_line('BB').value:
            # 3.
            _g_be = dims['BD'].find(_g).same_line('BE').value
            _bg_be = dims['BD'].find(_bg).same_line('BE').value
            if _g_be == '上市' and _bg_be == '上市':
                remark = '16214'  # (6)
            if _g_be == '上市' and _bg_be == '非上市':
                remark = '16213'  # (7)
            if _g_be == '非上市' and _bg_be == '上市':
                remark = '16212'  # (8)
            if _g_be == '非上市' and _bg_be == '非上市':
                remark = '16211'  # (9)
        else:
            # 4.
            _g_be = dims['BD'].find(_g).same_line('BE').value
            _bg_be = dims['BD'].find(_bg).same_line('BE').value
            if _g_be == '上市' and _bg_be == '上市':
                remark = '16224'  # (10)
            elif _g_be == '上市' and _bg_be == '非上市':
                remark = '16223'  # (11)
            elif _g_be == '非上市' and _bg_be == '上市':
                remark = '16222'  # (12)
            elif _g_be == '非上市' and _bg_be == '非上市':
                raise Exception('二调规则2.1.5 生成优化配置与人员增减信息同时出现非上市情形')  # 这种情形应不存在
    return remark


@logfn
def chk_2_1_5(_in: AdTable, dims: AdTable):  # 2.1.5 生成优化配置与人员增减信息
    """第一步：先检验同一人的【调入模板-【G-人事范围】】与【调入模板-【BG-调动前人事范围】是否相同，
              (1)若相同且不为【码表库-【AS466】】，见1；--记为“16230”；
              (2)若相同且都为【码表库-【AS466】】，见2；--记为“16240”；
              (3)若不同，再分别提取同一人的【调入模板-【G-人事范围】】与【调入模板-【BG-调动前人事范围】的前四位数字代码，在【码表库-【BD-人事范围】】找到相同的值，检验【码表库-【BB-合并机构代码】是否相同，若不同，见3；
              (4)若相同，见4；
              (5)若未在【码表库-【BD-人事范围】】匹配到相同的值，见5；
       第三步：得到右侧所记的数字后，进入PA30“优化配置与人员增减信息”屏，新建一屏，开始日期为【调入模板-【D-调入日期】】，结束日期为“99991231”，将所记数字填入“增减类别”，
              调入（出）部门为【调入模板-【AS-所在单位及部门名称】】，来（往）单位类型选择“10 中石化系统内单位”，来（往）单位名称为【调入模板-【BE-调动前机构】】，回车两次，
              保存，继续执行下一人员。
       ------------------
       第二步：
              1.为“相同且不为【码表库-【AS466】】”，记为“16230”；
              3.为“相同且都为【码表库-【AS466】】”，记为“16240”；
              3.为“不同”，分别提取【调入模板-【G-人事范围】】与【调入模板-【BG-调动前人事范围】所对应的【码表库-【BE-集团/股份】】，
              (6)若【调入模板-【G-人事范围】】对应的是“上市”，【调入模板-【BG-调动前人事范围】对应的也是“上市”，记为“16214”；
              (7)若【调入模板-【G-人事范围】】对应的是“上市”，【调入模板-【BG-调动前人事范围】对应的是“非上市”，记为“16213”；
              (8)若【调入模板-【G-人事范围】】对应的是“非上市”，【调入模板-【BG-调动前人事范围】对应的是“上市”，记为“16212”；
              (9)若【调入模板-【G-人事范围】】对应的是“非上市”，【调入模板-【BG-调动前人事范围】对应的也是“非上市”，记为“16211”；
              4.为“相同”，分别提取【调入模板-【G-人事范围】】与【调入模板-【BG-调动前人事范围】所对应的【码表库-【BE-集团/股份】】，
              (10)若【调入模板-【G-人事范围】】对应的是“上市”，【调入模板-【BG-调动前人事范围】对应的也是“上市”，记为“16224”；
              (11)若【调入模板-【G-人事范围】】对应的是“上市”，【调入模板-【BG-调动前人事范围】对应的是“非上市”，记为“16223”；
              (12)若【调入模板-【G-人事范围】】对应的是“非上市”，【调入模板-【BG-调动前人事范围】对应的是“上市”，记为“16222”；
              5.为“未匹配到”，跳过此人，执行下一人员。
    """
    with SapWithoutClose('login_tx') as session:
        for row in _in.rows:  # 遍历调入模板所有行
            remark = chk_2_1_5_step1(row, dims)  # 增减类别编码
            staff_id = row['B'].value  # 人员编码
            begin_date = row['D'].value  # 开始日期
            end_date = '99991231'  # 结束日期
            _as = row['AS'].value
            _be = row['BE'].value
            logging.info('[零星修改-PA30生成优化配置与人员增减信息]-事务码 /n pa30')
            session.findById("wnd[0]/tbar[0]/okcd").text = '/n pa30'
            session.findById("wnd[0]").sendVKey(0)
            logging.info(f'[零星修改-PA30生成优化配置与人员增减信息]-输入人员编号：{staff_id}')
            session.findById("wnd[0]/usr/ctxtRP50G-PERNR").text = staff_id  # 人员编号
            session.findById("wnd[0]").sendVKey(2)
            logging.info('[零星修改-PA30生成优化配置与人员增减信息]-点选劳动关系')
            session.findById("wnd[0]/usr/tabsMENU_TABSTRIP/tabpTAB03").select()  # 劳动关系
            logging.info('[零星修改-PA30生成优化配置与人员增减信息]-点选优化配置与人员增减信息')
            session.findById("wnd[0]/usr/tabsMENU_TABSTRIP/tabpTAB03/ssubSUBSCR_MENU:SAPMP50A:0400/subSUBSCR_ITMENU:SAPMP50A:0310/tblSAPMP50ATC_MENU").getAbsoluteRow(7).selected = -1  # 优化配置与人员增减信息
            logging.info('[零星修改-PA30生成优化配置与人员增减信息]-点击概览')
            session.findById("wnd[0]/tbar[1]/btn[20]").press()  # 概览
            logging.info(f'[零星修改-PA30生成优化配置与人员增减信息]-窗口1标题：{session.findById("wnd[0]").Text}')
            if '优化配置与人员增减信息' in session.findById("wnd[0]").Text:  # 该人员优化配置与人员增减信息有值，可以进入概览
                logging.info('[零星修改-PA30生成优化配置与人员增减信息]-该人员优化配置与人员增减信息有值，可以进入概览')
                first_begin_date = ''
                first_end_date = ''
                if session.findById("wnd[0]/usr/tblMP925300TC3000/txtP9253-BEGDA[0,0]", False) is not None:
                    first_begin_date = session.findById("wnd[0]/usr/tblMP925300TC3000/txtP9253-BEGDA[0,0]").text  # 第一条开始日期
                if session.findById("wnd[0]/usr/tblMP925300TC3000/txtP9253-ENDDA[1,0]", False) is not None:
                    first_end_date = session.findById("wnd[0]/usr/tblMP925300TC3000/txtP9253-ENDDA[1,0]").text  # 第一条结束日期
                if begin_date == to_yyyymmdd(first_begin_date) and end_date == to_yyyymmdd(first_end_date):
                    logging.info('[零星修改-PA30生成优化配置与人员增减信息]-第一条记录开始日期和结束日期与当前要创建的日期相同，先删除再创建')
                    session.findById("wnd[0]/usr/tblMP925300TC3000").getAbsoluteRow(0).selected = -1
                    session.findById("wnd[0]/tbar[1]/btn[14]").press()
                    session.findById("wnd[0]/tbar[1]/btn[14]").press()
                    logging.info('[零星修改-PA30生成优化配置与人员增减信息]-删除成功')
            else:
                logging.info('[零星修改-PA30生成优化配置与人员增减信息]-该人员优化配置与人员增减信息无值，无法进入概览')
            if '优化配置与人员增减信息' in session.findById("wnd[0]").Text:
                try:
                    logging.info('[零星修改-PA30生成优化配置与人员增减信息]-在概览屏（说明还有其他记录），此时定界剩余记录的结束日期')
                    day_before_begin_date = (datetime.datetime.strptime(begin_date, "%Y%m%d") - datetime.timedelta(days=1)).strftime('%Y%m%d')
                    row_count = session.findById("wnd[0]/usr/tblMP925300TC3000").RowCount
                    for rn in range(row_count):
                        line_rn_end_date = session.findById(f"wnd[0]/usr/tblMP925300TC3000/txtP9253-ENDDA[1,{rn}]").text
                        line_rn_end_date = to_yyyymmdd(line_rn_end_date)
                        if re.match(r'\d{8}', line_rn_end_date) is not None:
                            if line_rn_end_date >= begin_date:
                                logging.info(f'[零星修改-PA30生成优化配置与人员增减信息]-第{rn}行，结束日期为{line_rn_end_date}，大于等于事件开始日期{begin_date}，将结束日期定界为{day_before_begin_date}')
                                session.findById("wnd[0]/usr/tblMP925300TC3000").getAbsoluteRow(rn).selected = -1  # 选中结束日期大于当前开始日期的行
                                session.findById("wnd[0]/tbar[1]/btn[6]").press()  # 点击修改
                                session.findById("wnd[0]/usr/ctxtP9253-ENDDA").text = day_before_begin_date  # 结束日期
                                session.findById("wnd[0]").sendVKey(0)  # 回车1
                                session.findById("wnd[0]").sendVKey(0)  # 回车2
                                session.findById("wnd[0]/tbar[0]/btn[11]").press()  # 保存
                            else:
                                logging.info(f'[零星修改-PA30生成优化配置与人员增减信息]-第{rn}行，结束日期为{line_rn_end_date}，小于事件开始日期{begin_date}，不需要结束日期定界')
                        else:
                            pass
                except Exception as e:
                    logging.error(e)
            elif '维护人力资源主数据' in session.findById("wnd[0]").Text:  # 不在概览屏，记录只有一条，且被删完了，SAP回退到PA30屏
                logging.info('[零星修改-PA30生成优化配置与人员增减信息]-不在概览屏')
            else:
                logging.error('[零星修改-PA30生成优化配置与人员增减信息]-预期外的情况')
                logging.error('窗口标题: ' + session.findById("wnd[0]").Text)
            logging.info('[零星修改-PA30生成优化配置与人员增减信息]-点击工具栏创建（F5）按钮')
            session.findById("wnd[0]/tbar[1]/btn[5]").press()  # 创建（F5）
            logging.info(f'[零星修改-PA30生成优化配置与人员增减信息]-填入开始日期：{begin_date}，结束日期：{end_date}')
            session.findById("wnd[0]/usr/ctxtP9253-BEGDA").text = begin_date  # 开始日期
            session.findById("wnd[0]/usr/ctxtP9253-ENDDA").text = end_date  # 结束日期
            logging.info(f'[零星修改-PA30生成优化配置与人员增减信息]-填入增减类别：{remark}')
            session.findById("wnd[0]/usr/ctxtP9253-ZZ_ZJLB").text = remark  # 增减类别
            if len(_as) > 12:
                _as = _as[:12]  # SAP对长度有限制，此处要截断
            logging.info(f'[零星修改-PA30生成优化配置与人员增减信息]-填入调入（出）部门：{_as}')
            session.findById("wnd[0]/usr/txtP9253-ZZ_DRCBM").text = _as  # 调入（出）部门
            logging.info('[零星修改-PA30生成优化配置与人员增减信息]-来（往）单位类型选择“10 中石化系统内单位”')
            session.findById("wnd[0]/usr/cmbP9253-ZZ_LWDWLX").key = "10"  # 来（往）单位类型选择“10 中石化系统内单位”
            logging.info(f'[零星修改-PA30生成优化配置与人员增减信息]-填入来（往）单位名称：{_be}')
            session.findById("wnd[0]/usr/txtP9253-ZZ_LWDWMC").text = _be  # 来（往）单位名称
            logging.info('[零星修改-PA30生成优化配置与人员增减信息]-两次回车保存')
            session.findById("wnd[0]").sendVKey(0)  # 回车1
            session.findById("wnd[0]").sendVKey(0)  # 回车2
            session.findById("wnd[0]/tbar[0]/btn[11]").press()  # 保存
            sap_status = session.findById("wnd[0]/sbar/pane[0]").text
            logging.info(f'[零星修改-PA30生成优化配置与人员增减信息]-SAP状态栏信息：{sap_status}')


def chk_2_1_6(_in: AdTable):
    """ZHRCONV073 生成最高等级工种鉴定标识
    """
    with SapWithoutClose('login_tx') as session:
        logging.info('[零星修改-生成最高等级工种鉴定标识]-事务码 /n ZHRCONV073')
        session.findById("wnd[0]/tbar[0]/okcd").text = '/n ZHRCONV073'
        session.findById("wnd[0]").sendVKey(0)
        session.findById("wnd[0]/usr/cmbPNPTIMED").key = "I"  # 其他期间
        session.findById("wnd[0]/usr/ctxtPNPBEGDA").text = datetime.datetime.now().strftime(r'%Y%m%d')  # 事件执行日期
        session.findById("wnd[0]/usr/ctxtPNPENDDA").text = "99991231"
        logging.info('[零星修改-生成最高等级工种鉴定标识]-人员编号多项选择')
        session.findById("wnd[0]/usr/btn%_PNPPERNR_%_APP_%-VALU_PUSH").press()  # 人员编号多项选择
        logging.info('[零星修改-生成最高等级工种鉴定标识]-删除全部选择行（Shift+F4）')
        session.findById("wnd[1]/tbar[0]/btn[16]").press()  # 删除全部选择行（Shift+F4）
        staff_ids: List[str] = list(set(_in['B'].values))  # 人员编号去重
        staff_ids_str = '\r\n'.join(staff_ids)
        pyperclip.copy(staff_ids_str)  # 复制到剪切板
        logging.info(f'[零星修改-生成最高等级工种鉴定标识]-从剪切板上载（Shift+F12），剪切板人员编号编码：{staff_ids}')
        session.findById("wnd[1]/tbar[0]/btn[24]").press()  # 从剪切板上载（Shift+F12）
        logging.info('[零星修改-生成最高等级工种鉴定标识]-点击确认')
        session.findById("wnd[1]/tbar[0]/btn[8]").press()  # 确认
        logging.info('[零星修改-生成最高等级工种鉴定标识]-点击执行（F8）')
        session.findById("wnd[0]/tbar[1]/btn[8]").press()  # 执行（F8）
        sap_status = session.findById("wnd[0]/sbar/pane[0]").text
        logging.info(f'[零星修改-生成最高等级工种鉴定标识]-SAP状态栏信息：{sap_status}')


@logfn
def chk_2_1_7(_in: AdTable, _103: AdTable):  # 2.1.7 生成简历
    """ZHRPA175 生成简历
       ------------------
       先将【组合逻辑导出表103-【W-组织机构】】复制到【调入模板-【BC-调动后机构】】有相同字段的人员，
       再将【调入模板-【BB-工作经历开始日期】、“99991231”、【BC-调动后机构】、【BD-调动后岗位】】依次填入【PA30-【简历模块】】。
    """
    df = _in.to_dataframe()
    df_103 = _103.to_dataframe()
    ep_dict: Dict[str, List[str]] = {}  # {'人员编号 ':[‘开始时间’，‘所在机构名称’，‘所在岗位’]}
    for rn in df.index:
        staff_id = df['B'][rn]
        df_tmp = df_103[df_103['A'] == staff_id]
        if df_tmp.empty is False:
            _in['BC'][rn] = df_tmp['W'].values[0]
        _bb = df['BB'][rn]
        _bc = df['BC'][rn]
        _bd = df['BD'][rn]
        ep_dict[staff_id] = [_bb, _bc, _bd]
    new_work_experience_modify(ep_dict)
    return True


@logfn
def chk_2_1_8(_103: AdTable):  # 2.1.8 生成简历-确定00工资总额控制范围为空
    """当【组合逻辑导出表103-【Z-PArea】】的值为“00”时，清空其组织分配屏“工资总额控制范围”。
    """
    df_103 = _103.to_dataframe()
    df_tmp = df_103[df_103['Z'] == '00'].copy()
    if df_tmp.empty is True:
        logging.info('组合逻辑查询中不存在【Z-PArea】为00的记录，跳过修改工资总额控制范围')
        return
    staff_ids = list(set(df_tmp['A'].values.tolist()))
    with SapWithoutClose('login_tx') as session:
        for staff_id in staff_ids:
            logging.info('[零星修改-生成简历-确定00工资总额控制范围为空]-事务码 /n pa30')
            session.findById("wnd[0]/tbar[0]/okcd").text = '/n pa30'
            session.findById("wnd[0]").sendVKey(0)
            logging.info(f'[零星修改-生成简历-确定00工资总额控制范围为空]-输入人员编号：{staff_id}')
            session.findById("wnd[0]/usr/ctxtRP50G-PERNR").text = staff_id  # 人员编号
            session.findById("wnd[0]").sendVKey(2)
            logging.info('[零星修改-生成简历-确定00工资总额控制范围为空]-点选劳动关系')
            session.findById("wnd[0]/usr/tabsMENU_TABSTRIP/tabpTAB03").select()  # 劳动关系
            logging.info('[零星修改-生成简历-确定00工资总额控制范围为空]-点选组织分配及岗位聘任')
            session.findById("wnd[0]/usr/tabsMENU_TABSTRIP/tabpTAB03/ssubSUBSCR_MENU:SAPMP50A:0400/subSUBSCR_ITMENU:SAPMP50A:0310/tblSAPMP50ATC_MENU").getAbsoluteRow(0).selected = -1  # 组织分配及岗位聘任
            logging.info('[零星修改-生成简历-确定00工资总额控制范围为空]-点击概览')
            session.findById("wnd[0]/tbar[1]/btn[20]").press()  # 概览
            logging.info('[零星修改-生成简历-确定00工资总额控制范围为空]-点选第一条记录')
            session.findById("wnd[0]/usr/tblMP000100TC3000").getAbsoluteRow(0).selected = -1  # 第一条记录
            logging.info('[零星修改-生成简历-确定00工资总额控制范围为空]-点击更改')
            session.findById("wnd[0]/tbar[1]/btn[6]").press()  # 更改
            if session.findById("wnd[0]/usr/subSUBSCREEN_T582C:ZP000100:0200/ctxtP0001-ZZ_ZEFW").Changeable is True:
                logging.info('[零星修改-生成简历-确定00工资总额控制范围为空]-修改工资总额控制范围')
                session.findById("wnd[0]/usr/subSUBSCREEN_T582C:ZP000100:0200/ctxtP0001-ZZ_ZEFW").text = ''  # 有可能无法修改
            else:
                logging.warning('[零星修改-生成简历-确定00工资总额控制范围为空]-修改工资总额控制范围失败')
            logging.info('[零星修改-生成简历-确定00工资总额控制范围为空]-两次回车保存')
            session.findById("wnd[0]").sendVKey(0)  # 回车1
            session.findById("wnd[0]").sendVKey(0)  # 回车2
            session.findById("wnd[0]/tbar[0]/btn[11]").press()  # 保存
            sap_status = session.findById("wnd[0]/sbar/pane[0]").text
            logging.info(f'[零星修改-生成简历-确定00工资总额控制范围为空]-SAP状态栏信息：{sap_status}')


@logfn
def chk_3_1_01(_in: AdTable) -> Tuple[AdTable, AdTable, AdTable]:  # 3.1.01 导出组合逻辑查询103、1071、1072
    """导出组合逻辑查询103、1071、1072
    """
    job_ids = _in['F'].values
    staff_ids = _in['B'].values
    key_date = _in['D'].values[0]
    with SapClose():
        _103 = export_103(None, staff_ids, key_date)
        _103.filename += '_事后备份'
        _1071 = export_1071(None, job_ids, key_date)
        _1072 = export_1072(None, job_ids, key_date)
    return _103, _1071, _1072


@logfn
def chk_3_1_02(df_103: DataFrame, rn: int, _103: AdTableRow, df_dims: DataFrame) -> bool:  # 3.1.02 校验从事职业工种
    """提取【组合逻辑导出表103-【AV-职位序列】】在【码表库-【V3】和【V12】-的汉字部分】有相同字段的人员，检验【组合逻辑导出表103-【BU-结束日期】】的值是否为空值。
       ------------------
       1.为“不是空值”，在【组合逻辑导出表103-【BU-结束日期】】单元格填充红色并插入批注“从事职业工种信息结束日期需核对”；
    """
    _av = df_103['AV'][rn]
    if (_av in df_dims['V'][3] or _av in df_dims['V'][12]) and df_103['BU'][rn] != '0000.00.00':
        _103['BU'].cmt('red', '从事职业工种信息结束日期需核对')
        return False
    return True


@logfn
def chk_3_1_03(df_103: DataFrame, rn: int, _103: AdTableRow, df_in: DataFrame, df_1071: DataFrame) -> bool:  # 3.1.03 校验从事职业工种
    """1.【组合逻辑导出表103-【P-PA】】的值不为“1680”】时，提取【组合逻辑导出表103-【AV-职位序列】】的值为"技能操作序列"的人员，
         (1)检验【组合逻辑导出表103-【BT-开始日期】】的值是否为【调入模板-【D-调入日期】】，若不是，见1；
         (2)检验【组合逻辑导出表103-【BU-结束日期】】的值是否为“99991231”，若不是，见2；
         提取其【组合逻辑导出表103-【X-职务(岗位)具体名称】】，在【组合逻辑导出表1071-【A-对象标识】】找到相同的值且其【B-OT】的值为“S”的行，
         (3)检验【组合逻辑导出表1071-【W-所属工种】】与【组合逻辑导出表103-【BX-现职业工种】】是否相同，若不是，见3；
       2.【组合逻辑导出表103-【P-PA】】的值为“1680”】时，提取【组合逻辑导出表103-【AV-职位序列】】的值为"技能操作序列"的人员，
         (4)检验【组合逻辑导出表103-【BT-开始日期】】的值是否为【调入模板-【D-调入日期】】，若不是，见1；
         (5)检验【组合逻辑导出表103-【BU-结束日期】】的值是否为“99991230”，若不是，见2；
         提取其【组合逻辑导出表103-【X-职务(岗位)具体名称】】，在【组合逻辑导出表1071-【A-对象标识】】找到相同的值且其【B-OT】的值为“S”的行，
         (6)检验【组合逻辑导出表1071-【W-所属工种】】与【组合逻辑导出表103-【BX-现职业工种】】是否相同，若不是，见3。
       ------------------
       1.【组合逻辑导出表103-【BT-开始日期】】的值“不为“【调入模板-【D-调入日期】】，在【组合逻辑导出表103-【BT-开始日期】】单元格填充红色并插入批注“从事职业工种信息开始日期需核对”；
       2.【组合逻辑导出表103-【BU-结束日期】】的不为“99991231”或“99991230”，在【组合逻辑导出表103-【BU-结束日期】】单元格填充红色并插入批注“从事职业工种信息结束日期需核对”；
       3.【组合逻辑导出表1071-【W-所属工种】】与【组合逻辑导出表103-【BX-现职业工种】】不相同，在【组合逻辑导出表103-【BX-现职业工种】】填充红色并插入批注“从事职业工种信息所属工种需核对”。
    """
    is_check_passed = True
    staff_id = df_103['A'][rn]
    if df_103['P'][rn] != '1680':
        # 1.
        if df_103['AV'][rn] == '技能操作序列':
            # (1)
            if to_yyyymmdd(df_103['BT'][rn]) != df_in[df_in['B'] == staff_id]['D'].values[0]:
                _103['BT'].cmt('red', '从事职业工种信息开始日期需核对')
                is_check_passed = False
            # (2)
            if to_yyyymmdd(df_103['BU'][rn]) != '99991231':
                _103['BU'].cmt('red', '从事职业工种信息结束日期需核对')
                is_check_passed = False
            # (3)
            job_id = df_103['X'][rn]
            if df_103['BX'][rn] != df_1071[(df_1071['A'] == job_id) & (df_1071['B'] == 'S')]['W'].values[0]:
                _103['BX'].cmt('red', '从事职业工种信息所属工种需核对')
                is_check_passed = False
    else:
        # 2.
        if df_103['AV'][rn] == '技能操作序列':
            # (4)
            if to_yyyymmdd(df_103['BT'][rn]) == df_in[df_in['B'] == staff_id]['D'].values[0]:
                _103['BT'].cmt('red', '从事职业工种信息开始日期需核对')
                is_check_passed = False
            # (5)
            if to_yyyymmdd(df_103['BU'][rn]) != '99991230':
                _103['BU'].cmt('red', '从事职业工种信息结束日期需核对')
                is_check_passed = False
            # (6)
            job_id = df_103['X'][rn]
            if df_103['BX'][rn] != df_1071[(df_1071['A'] == job_id) & (df_1071['B'] == 'S')]['W'].values[0]:
                _103['BX'].cmt('red', '从事职业工种信息所属工种需核对')
                is_check_passed = False
    return is_check_passed


@logfn
def chk_3_1_04(df_103: DataFrame, rn: int, _103: AdTableRow, df_dims: DataFrame) -> bool:  # 3.1.04 提醒工资核算范围
    """提取【组合逻辑导出表103-【P-PA】、【R-人事子范围】、【S-人员组】、【T-人员子组】】的值，依序匹配在【码表库-【AA】、【AB】、【AC】、【AD】】中相同的值，
       检验同一行的【码表库-【AE】】的值是否与【组合逻辑导出表103-【Z-PArea】】相同。
       ------------------
       1.为“不相同”，在【组合逻辑导出表103-【Z-PArea】】单元格填充蓝色并插入批注“工资核算范围需核对”。
    """
    _p = df_103['P'][rn]
    _q = df_103['Q'][rn]
    _r = df_103['R'][rn]
    _qr = _q + ' ' + _r
    _s = df_103['S'][rn]
    _t = df_103['T'][rn]
    _103_z = df_103['Z'][rn]

    df_tmp = df_dims[(df_dims['AA'] == _p) & (df_dims['AB'] == _qr)]  # & (df_dims['AC'] == _s) & (df_dims['AD'] == _t)
    is_found = False
    for _rn in df_tmp.index:
        if _s in df_tmp['AC'][_rn].split('/') and _t in df_tmp['AD'][_rn].split('/'):
            is_found = True
            if df_tmp['AE'][_rn] != _103_z:
                _103['Z'].cmt('blue', '工资核算范围需核对')
                return True
    if is_found is False:
        _103['Z'].cmt('red', '工资核算范围不在码表库中，请核查')
        return False
    else:
        return True


@logfn
def chk_3_1_05(df_103: DataFrame, rn: int, _103: AdTableRow, df_dims: DataFrame) -> bool:  # 3.1.05 校验工资总额控制范围
    """提取【组合逻辑导出表103-【P-PA】、【R-人事子范围】、【Z-PArea】】的值，依序匹配在【码表库-【AA】、【AB】、【AE】中相同的值，检验同一行的【码表库-【AF】】是否与【组合逻辑导出表103-【AB-工资总额控制范围】】相同。
       ------------------
       1.为“不相同”，在【组合逻辑导出表103-【AB-工资总额控制范围】】单元格填充红色并插入批注“工资总额控制范围需核对”；
       2.未匹配到相同的工资核算范围，在【组合逻辑导出表103-【AB-工资总额控制范围】】单元格填充红色并插入批注“未在码表库中找到相同的工资核算范围”。
    """
    _p = df_103['P'][rn]
    _q = df_103['Q'][rn]
    _r = df_103['R'][rn]
    _qr = _q + ' ' + _r
    _z = df_103['Z'][rn]
    _103_ab = df_103['AB'][rn]

    df_tmp = df_dims[(df_dims['AA'] == _p) & (df_dims['AB'] == _qr) & (df_dims['AE'] == _z)]
    if df_tmp.empty is True:
        _103['AB'].cmt('red', '未在码表库中找到相同的工资核算范围')
        return False
    elif df_tmp['AF'].values[0] != _103_ab:
        _103['AB'].cmt('red', '工资总额控制范围需核对')
        return False
    else:
        return True


@logfn
def chk_3_1_06(df_103: DataFrame, rn: int, _103: AdTableRow) -> bool:  # 3.1.06 提醒组合逻辑导出表103多行信息
    """检验“组合逻辑导出表103”同一人是否存在三行及以上的信息。
       ------------------
       1.为“同一人存在三行及以上”，在同一人的【组合逻辑导出表103-【A-人员编号】】单元格填充红色并插入批注“请核对该人员信息”。
    """
    staff_id = df_103['A'][rn]
    # 20201014更新：薪酬先处理时，会先生成这条【暂停/恢复发薪】记录，需忽略
    if len(df_103[(df_103['A'] == staff_id) & (df_103['G'] != '暂停/恢复发薪')]) >= 3:
        _103['A'].cmt('red', '请核对该人员信息')
        return False
    return True


@logfn
def chk_3_1_07(df_103: DataFrame, rn: int, _103: AdTableRow) -> bool:  # 3.1.07 校验薪酬标杆
    """检验【组合逻辑导出表103-【AV-职位序列】】的值为“管理序列”时，检验【组合逻辑导出表103-【BH-薪酬标杆岗位类别】】的值的首字符是否为“1”；
       检验【组合逻辑导出表103-【AV-职位序列】】的值为“专业技术序列”时，检验【组合逻辑导出表103-【BH-薪酬标杆岗位类别】】的值的首字符是否为“2”；
       检验【组合逻辑导出表103-【AV-职位序列】】的值为“技能操作序列”时，检验【组合逻辑导出表103-【BH-薪酬标杆岗位类别】】的值的首字符是否为“3”或者“4”。
       ------------------
       1.为“不是”，在【组合逻辑导出表103-【BH-薪酬标杆岗位类别】】单元格填充红色并插入批注“薪酬标杆与职位序列不对应”。
    """
    if df_103['AV'][rn] == '管理序列' and df_103['BH'][rn][:1] == '1':
        return True
    elif df_103['AV'][rn] == '专业技术序列' and df_103['BH'][rn][:1] == '2':
        return True
    elif df_103['AV'][rn] == '技能操作序列' and df_103['BH'][rn][:1] in ('3', '4'):
        return True
    else:
        _103['BH'].cmt('red', '薪酬标杆与职位序列不对应')
        return False


@logfn
def chk_3_1_08(df_103: DataFrame, rn: int, _103: AdTableRow, df_in: DataFrame) -> bool:  # 3.1.08 校验开始日期
    """先检验【组合逻辑导出表103-【L】、【AR】、【BS】、【CB】】的值是否与【组合逻辑导出表103-【C】】的值相同；
       再提取【组合逻辑导出表103-【AV-职位序列】】的值为“技能操作序列”的人员，检验【组合逻辑导出表103-【BT】】的值是否与【组合逻辑导出表103-【C】】相同；
       最后检验同一个人【组合逻辑导出表103-【BL】】的值是否与【调入模板-【BB-工作经历开始日期】】相同。
       ------------------
       1.为“不相同”，在【组合逻辑导出表103】值不同的单元格填充红色并插入批注“开始日期需核对”。
    """
    is_check_passed = True
    staff_id = df_103['A'][rn]
    _c = df_103['C'][rn]
    if df_103['L'][rn] != _c:
        _103['L'].cmt('red', '开始日期需核对')
        is_check_passed = False
    if df_103['AR'][rn] != _c:
        _103['AR'].cmt('red', '开始日期需核对')
        is_check_passed = False
    yyyymmdd = datetime.datetime.now().strftime(r'%Y%m%d')
    if to_yyyymmdd(df_103['BS'][rn]) != yyyymmdd:  # 规则调整：检验BS列是否是简历更改日期（做单子的日期）
        _103['BS'].cmt('red', f'更改日期不等于今天({yyyymmdd})，需核对，请检查模板是否跨天执行（规则3.1.8）')
        is_check_passed = False
    if df_103['CB'][rn] != _c:
        _103['CB'].cmt('red', '开始日期需核对')
        is_check_passed = False
    if df_103['AV'][rn] == '技能操作序列':
        if df_103['BT'][rn] != _c:
            _103['BT'].cmt('red', '开始日期需核对')
            is_check_passed = False
    if to_yyyymmdd(df_103['BL'][rn]) != df_in[df_in['B'] == staff_id]['BB'].values[0]:
        _103['BL'].cmt('red', '开始日期需核对')
        is_check_passed = False
    return is_check_passed


@logfn
def chk_3_1_09(df_103: DataFrame, rn: int, _103: AdTableRow) -> bool:  # 3.1.09 校验结束日期
    """先检验【组合逻辑导出表103-【M】、【AS】、【CC】】的值是否与【组合逻辑导出表103-【D】】的值相同；
       再提取【组合逻辑导出表103-【AV-职位序列】】的值为“技能操作序列”的人员，检验【组合逻辑导出表103-【BU】】的值是否与【组合逻辑导出表103-【D】】相同;
       最后检验同一个人【组合逻辑导出表103-【BM】】的值是否为“99991231”相同。
       ------------------
       1.为“不相同”，在【组合逻辑导出表103】值不同的单元格填充红色并插入批注“结束日期需核对”。
    """
    is_check_passed = True
    _d = df_103['D'][rn]
    if df_103['M'][rn] != _d:
        _103['M'].cmt('red', '结束日期需核对')
        is_check_passed = False
    if df_103['AS'][rn] != _d:
        _103['AS'].cmt('red', '结束日期需核对')
        is_check_passed = False
    if df_103['CC'][rn] != _d:
        _103['CC'].cmt('red', '结束日期需核对')
        is_check_passed = False
    if df_103['AV'][rn] == '技能操作序列':
        if df_103['BU'][rn] != _d:
            _103['BU'].cmt('red', '结束日期需核对')
            is_check_passed = False
    if df_103['BM'][rn] == '99991231':
        _103['BM'].cmt('red', '结束日期需核对')
        is_check_passed = False
    return is_check_passed


@logfn
def chk_3_1_10(df_103: DataFrame, rn: int, _103: AdTableRow) -> bool:  # 3.1.10 校验职位序列、兼任职务序列的对应关系
    """若【组合逻辑导出表103-【BA-兼任职位序列】】不为空，检验同一人是否满足下述条件：
       【组合逻辑导出表103-【AV-职位序列】】和【组合逻辑导出表103-【BA-兼任职位序列】】不相同，
       且【组合逻辑导出表103-【BA-兼任职位序列】】的值不为“管理序列”。
       ------------------
       1.为“不符合条件”，在【组合逻辑导出表103-【BA-兼任职位序列】】不相同的单元格填充红色并插入批注“兼任职位序列与职位序列冲突！”。
    """
    if df_103['BA'][rn] != '':
        if df_103['AV'][rn] == df_103['BA'][rn] or df_103['BA'][rn] == '管理序列':
            _103['BA'].cmt('red', '兼任职位序列与职位序列冲突！')
            return False
    return True


@logfn
def chk_3_1_11(df_103: DataFrame, rn: int, _103: AdTableRow) -> bool:  # 3.1.11 校验兼任职务信息是否完全
    """检验同一人的【组合逻辑导出表103-【AZ-兼任职位标识】=“是”、【BA-兼任职位序列】、【BB-兼任职位层级】、【BC-兼任职位级别】】是否都不为空，
       或同一人的【组合逻辑导出表103-【AZ-兼任职位标识】=“否”、【BA-兼任职位序列】、【BB-兼任职位层级】、【BC-兼任职位级别】】是否都为空。
       ------------------
       1.为“不是”，在【组合逻辑导出表103-【AZ-兼任职位标识】】单元格填充红色并插入批注“兼任职位信息不全”。
    """
    if df_103['AZ'][rn] == '是' and df_103['BA'][rn] != '' and df_103['BB'][rn] != '' and df_103['BC'][rn] != '':
        return True
    elif df_103['AZ'][rn] == '否' and df_103['BA'][rn] == '' and df_103['BB'][rn] == '' and df_103['BC'][rn] == '':
        return True
    else:
        _103['AZ'].cmt('red', '兼任职位信息不全')
        return False


@logfn
def chk_3_1_12(df_103: DataFrame, rn: int, _103: AdTableRow) -> bool:  # 3.1.12 校验职务（岗位）码是否为空
    """检验同一人的【组合逻辑导出表103-【AJ-职务（岗位）】】是否为空。
       ------------------
       1.为“是”，在【组合逻辑导出表103-【AJ-职务（岗位）】】为空的单元格填充蓝色并插入批注“职务（岗位）码需核对”。
    """
    if df_103['AJ'][rn] == '':
        _103['AJ'].cmt('blue', '职务（岗位）码需核对')
    return True


@logfn
def chk_3_1_13(df_103: DataFrame, rn: int, _103: AdTableRow, df_dims: DataFrame) -> bool:  # 3.1.13 校验原中层转聘其他岗位标识是否正确勾选
    """检验下述三种情形是否有任一符合要求：
       1.当【组合逻辑导出表103-【H-事件原因】】为“20 原中层转聘其他岗位”时，【组合逻辑导出表103-【BK-原中层转聘其他岗位标识】】的值是否为“否”；
       2.当【组合逻辑导出表103-【BK-原中层转聘其他岗位标识】】的值为“是”时，【组合逻辑导出表103-【H-事件原因】】是否不为“20 原中层转聘其他岗位”；
       3.当【组合逻辑导出表103-【H-事件原因】】为“20 原中层转聘其他岗位”且【组合逻辑导出表103-【BK-原中层转聘其他岗位标识】】的值为“是”时，【组合逻辑导出表103-【T-人员子组】】的值是否不为【码表库-【L5】】。
       ------------------
       1.为“是”，在【组合逻辑导出表103-【BK-原中层转聘其他岗位标识】】填充红色并插入批注“中层转聘其他岗位：事件原因/人员子组/标识需核对”。
    """
    if df_103['H'][rn] == '20 原中层转聘其他岗位' and df_103['BK'][rn] == '否':
        _103['BK'].cmt('red', '中层转聘其他岗位：事件原因/人员子组/标识需核对')
        return False
    elif df_103['BK'][rn] == '是' and df_103['H'][rn] != '20 原中层转聘其他岗位':
        _103['BK'].cmt('red', '中层转聘其他岗位：事件原因/人员子组/标识需核对')
        return False
    elif df_103['H'][rn] == '20 原中层转聘其他岗位' and df_103['BK'][rn] == '是' and df_103['T'][rn] != df_dims['L'][5].value:
        _103['BK'].cmt('red', '中层转聘其他岗位：事件原因/人员子组/标识需核对')
        return False
    else:
        return True


@logfn
def chk_3_1_14(df_103: DataFrame, rn: int, _103: AdTableRow, df_1071: DataFrame) -> bool:  # 3.1.14 校验是否存在一岗多人
    """检验在【组合逻辑导出表1071-【B-OT】】是否存在两个“P”相连的情形。
       ------------------
       1.为“存在”，提取紧接其上值为“S”的那一行的【A-对象标识】值，在【组合逻辑导出表103-【X-职务(岗位)具体名称】】找到相同的值，填充红色并插入批注“存在一岗多人”。
    """
    job_id = df_103['X'][rn]
    rn_1071 = df_1071[(df_1071['A'] == job_id) & (df_1071['B'] == 'S')].index[0]
    if rn_1071 + 2 <= df_1071.index[-1] and df_1071['B'][rn_1071 + 1] == 'P' and df_1071['B'][rn_1071 + 2] == 'P':
        _103['X'].cmt('red', '存在一岗多人')
        return False
    else:
        return True


@logfn
def chk_3_1_15(df_103: DataFrame, rn: int, _103: AdTableRow, df_in: DataFrame, df_dims: DataFrame) -> bool:  # 3.1.15 校验是否是二级单位间调动、校验二级单位间调动事件原因
    """先检验同一人的【组合逻辑导出表103-【P-PA】】与【调入模板-【BG-调动前人事范围】-前四位代码】是否相同，若不同，执行3.1.16规则；
       若相同，再检验调入模板-【H-人事子范围】】与【调入模板-【BH-调动前人事子范围】】的值是否相同，若相同，见1；若不相同，见2。
       ------------------
       1.若值为“相同”，检验【组合逻辑导出表103-【P-PA】】是否是【码表库-【C】】的值，若不是，在【组合逻辑导出表103-【G-事件类型】】单元格填充红色并插入批注“事件类型应为：岗位变动事件！”，继续检验下一人员；
       2.若值为“不同”，
            当【组合逻辑导出表103-【P-PA】】的值为【码表库-【AS466】-前四位代码】时，检验“【组合逻辑导出表103-【H-事件原因】】+“一个空格”+【组合逻辑导出表103-【I-事件原因】】”是否是【码表库-【AK4】】，
                    若不是，在【组合逻辑导出表103-【G-事件类型】】单元格填充红色并插入批注“调入原因错误！”，继续检验下一人员；
            当【组合逻辑导出表103-【P-PA】】的值不为【码表库-【AS466】-前四位代码】时，检验“【组合逻辑导出表103-【H-事件原因】】+“一个空格”+【组合逻辑导出表103-【I-事件原因】】”是否是【码表库-【AK3】】，
                   若不是，在【组合逻辑导出表103-【G-事件类型】】单元格填充红色并插入批注“调入原因错误！”，继续检验下一人员。
    """
    staff_id = df_103['A'][rn]
    if df_103['P'][rn] != df_in[df_in['B'] == staff_id]['BG'].values[0][:4]:
        return chk_3_1_16(df_103, rn, _103, df_in, df_dims)
    else:
        if df_103['H'][rn] == df_in[df_in['B'] == staff_id]['BH'].values[0]:
            # 1.若值为“相同”
            if df_103['P'][rn] not in df_dims['C'].values:
                _103['G'].cmt('red', '事件类型应为：岗位变动事件！')
                return False
        else:
            # 2.若值为“不同”
            if df_103['P'][rn] == '5650':  # dims['AS'][466].value[:4]
                if df_103['H'][rn] != df_dims['AK'][4][:2]:  # 规则有更新，以代码逻辑为准
                    _103['G'].cmt('red', '调入原因错误3.1.15-1！')
                    return False
            elif df_103['H'][rn] != df_dims['AK'][3][:2]:
                _103['G'].cmt('red', '调入原因错误3.1.15-2！')
                return False
    return True


@logfn
def chk_3_1_16(df_103: DataFrame, rn: int, _103: AdTableRow, df_in: DataFrame, df_dims: DataFrame) -> bool:  # 3.1.16 校验是二级单位间调动还是直属单位间调动、校验调动事件原因、批注直属单位间调动类型
    """分别提取同一人的【组合逻辑导出表103-【P-PA】】与【调入模板-【BG-调动前人事范围】-前四位代码】，在【码表库-【BD-人事范围】】找到相同的值，
       先检验【码表库-【BB-合并机构代码】是否相同，再检验【码表库-【BC-直属机构代码】是否相同。
       ------------------
       1.当【码表库-【BB-合并机构代码】】相同，且【码表库-【BC-直属机构代码】】也相同时，检验“【组合逻辑导出表103-【H-事件原因】】+“一个空格”+【组合逻辑导出表103-【I-事件原因】】”是否是【码表库-【AK3】】，
            若不是，在【组合逻辑导出表103-【G-事件类型】】单元格填充红色并插入批注“调入原因错误！”，继续检验下一人员；
       2.当【码表库-【BB-合并机构代码】】相同，但【码表库-【BC-直属机构代码】】不相同时，检验“【组合逻辑导出表103-【H-事件原因】】+“一个空格”+【组合逻辑导出表103-【I-事件原因】】”是否是【码表库-【AV3】】，
           若不是，在【组合逻辑导出表103-【G-事件类型】】单元格填充红色并插入批注“调入原因错误！”，继续检验下一人员；若是，在【组合逻辑导出表103-【G-事件类型】】单元格填充蓝色并插入批注“上市与非上市公司间调动！”，继续检验下一人员；
       3.当【码表库-【BB-合并机构代码】】不同，且【码表库-【BC-直属机构代码】】也不相同时，检验“【组合逻辑导出表103-【H-事件原因】】+“一个空格”+【组合逻辑导出表103-【I-事件原因】】”是否是【码表库-【AV3】】，
           若不是，在【组合逻辑导出表103-【G-事件类型】】单元格填充红色并插入批注“调入原因错误！”，继续检验下一人员；若是，在【组合逻辑导出表103-【G-事件类型】】单元格填充蓝色并插入批注“跨企业调动！”，继续检验下一人员。
    """
    staff_id = df_103['A'][rn]
    _p = df_103['P'][rn]
    _bg = df_in[df_in['B'] == staff_id]['BG'].values[0][:4]
    _103_bb = df_dims[df_dims['BD'] == _p]['BB'].values[0]
    _in_bb = df_dims[df_dims['BD'] == _bg]['BB'].values[0]
    _103_bc = df_dims[df_dims['BD'] == _p]['BC'].values[0]
    _in_bc = df_dims[df_dims['BD'] == _bg]['BC'].values[0]
    if _103_bb == _in_bb and _103_bc == _in_bc:  # 1
        if _103['H'].value != df_dims['AK'][3][:2]:
            _103['G'].cmt('red', '调入原因错误3.1.16-1！')
            return False
        else:
            return True
    elif _103_bb == _in_bb and _103_bc != _in_bc:  # 2
        if _103['H'].value != df_dims['AV'][3][:2]:
            _103['G'].cmt('red', '调入原因错误3.1.16-2！')
            return False
        else:
            _103['G'].cmt('blue', '上市与非上市公司间调动！')
            return True
    elif _103_bb != _in_bb and _103_bc != _in_bc:  # 3
        if _103['H'].value != df_dims['AV'][3][:2]:
            _103['G'].cmt('red', '调入原因错误3.1.16-3！')
            return False
        else:
            _103['G'].cmt('blue', '跨企业调动！')
            return True
    else:
        return True


@logfn
def chk_3_1_17(df_103: DataFrame, rn: int, _103: AdTableRow, df_1072: DataFrame) -> bool:  # 3.1.17 校验岗位所在财务科目设置的人事范围、人事子范围与调入模板是否一致
    """锁定【组合逻辑导出表1072-【B-OT】= S】与【组合逻辑导出表103-【X-职务(岗位)具体名称】】相同的值，检验【组合逻辑导出表1072-【B-OT】= O（S的次行）】的【P-PA】、【Q-PSubarea】是否为空，若为空，见1，
       若不为空，则分别与【组合逻辑导出表103-【P-PA】】、【组合逻辑导出表103-【Q-PSubarea】】检验是否相同，若不相同，见2。
       ------------------
       1.为”空“，在【组合逻辑导出表103-【V-组织机构】】单元格填充蓝色并插入批注“岗位所在机构的财务科目设置的人事范围、人事子范围为空！”，继续检验下一人员；
       2.为“不相同”，在【组合逻辑导出表103-【V-组织机构】】单元格填充红色并插入批注“岗位所在机构的财务科目设置的人事范围、人事子范围与调入模板不一致！”，继续检验下一人员。
    """
    job_id = df_103['X'][rn]
    rn_1072 = df_1072[(df_1072['A'] == job_id) & (df_1072['B'] == 'S')].index[0]
    _1072_p = df_1072['P'][rn_1072 + 1]
    _1072_q = df_1072['Q'][rn_1072 + 1]
    if _1072_p == '' or _1072_q == '':
        # 1.
        _103['V'].cmt('blue', '岗位所在机构的财务科目设置的人事范围、人事子范围为空！')
        return True
    elif df_103['P'][rn] != _1072_p or df_103['Q'][rn] != _1072_q:
        _103['V'].cmt('red', '岗位所在机构的财务科目设置的人事范围、人事子范围与调入模板不一致！')
        return False
    return True


@logfn
def chk_3_1_18(df_103: DataFrame, rn: int, _103: AdTableRow, df_in: DataFrame) -> bool:  # 3.1.18 校验人员组
    """检验同一人的【组合逻辑导出表103-【S-人员组】】是否与【调入模板-【I】】的第一个字符相同。
       ------------------
       1.为“不相同”，在【组合逻辑导出表103-【S-人员组】】填充红色并插入批注“人员组发生变更”，继续检验下一人员。
    """
    staff_id = df_103['A'][rn]
    if df_103['S'][rn] != df_in[df_in['B'] == staff_id]['I'].values[0][:1]:
        _103['S'].cmt('red', '人员组发生变更')
        return False
    return True


@logfn
def chk_3_1_19(df_103: DataFrame, rn: int, _103: AdTableRow, df_1071: DataFrame) -> bool:  # 3.1.19 校验在岗人员的岗位类别
    """锁定【组合逻辑导出表103-【J-岗位状态】】的值为“在岗”的人员，提取【组合逻辑导出表103-【X-职务(岗位)具体名称】】，与【组合逻辑导出表1071-【B-OT】= S】匹配相同的值，
       检验【组合逻辑导出表1071-【B-OT】= S】的【K-岗位类别】是否为空，若为空，见1。
       ------------------
       1.为“空值”，在【组合逻辑导出表103-【J-岗位状态】】填充红色并插入批注“在岗状态人员未分配岗位类别！”，继续检验下一人员。
    """
    if _103['J'].value == '在岗':
        job_id = _103['X'].value
        if df_1071[(df_1071['A'] == job_id) & (df_1071['B'] == 'S')]['K'].values[0] == '':
            _103['J'].cmt('red', '在岗状态人员未分配岗位类别！')
            return False
    return True


@logfn
def chk_3_1_20(df_103: DataFrame, rn: int, _103: AdTableRow, df_1072: DataFrame) -> bool:  # 3.1.20 校验不在岗人员的岗位类别、虚岗位标识
    """锁定【组合逻辑导出表103-【J-岗位状态】】的值不为“在岗”的人员，提取【组合逻辑导出表103-【X-职务(岗位)具体名称】】，与【组合逻辑导出表1072-【B-OT】= S】匹配相同的值，检验【组合逻辑导出表1072-【B-OT】= S】的
      【K-岗位类别】是否为空，且【组合逻辑导出表1072-【B-OT】= S】的【AE-虚岗位标识】的值为“是”，若不是，见1。
       ------------------
       1.为“不是”，在【组合逻辑导出表103-【K-雇佣状态】】填充红色并插入批注“不在岗状态人员分配了岗位类别或未勾选虚岗位标识！”，继续检验下一人员。
    """
    if _103['J'].value != '在岗':
        job_id = _103['X'].value
        _k = df_1072[(df_1072['A'] == job_id) & (df_1072['B'] == 'S')]['K'].values[0]
        _ae = df_1072[(df_1072['A'] == job_id) & (df_1072['B'] == 'S')]['AE'].values[0]
        if _k != '' or _ae != '是':
            _103['K'].cmt('red', '不在岗状态人员分配了岗位类别或未勾选虚岗位标识！')
            return False
    return True


@logfn
def chk_3_1_21(df_103: DataFrame, rn: int, _103: AdTableRow, df_1071: DataFrame, df_in: DataFrame) -> bool:  # 3.1.21 校验C类人员岗位类别
    """锁定【组合逻辑导出表1071-【B-OT】= S】与【组合逻辑导出表103-【X-职务(岗位)具体名称】】相同的值，检验是否存在下述情况，若存在，见1：
      【组合逻辑导出表103-【S-人员组】】的值为“C”，【组合逻辑导出表1071-【B-OT】= S】的【K-岗位类别】的值为“A-关键岗位”。
       ------------------
       1.为“存在”，在【组合逻辑导出表103-【Y-职务（岗位）具体名称】】填充红色并插入批注“C类人员A类岗！”，继续检验下一人员。
    """
    staff_id = df_103['A'][rn]
    job_id = df_in[df_in['B'] == staff_id]['F'].values[0]
    if df_103['S'][rn] == 'C' and df_1071[(df_1071['A'] == job_id) & (df_1071['B'] == 'S')]['K'].values[0] == 'A-关键岗位':
        _103['Y'].cmt('red', 'C类人员A类岗！')
        return False
    return True


@logfn
def chk_3_1_22(df_103: DataFrame, rn: int, _103: AdTableRow, df_1071: DataFrame, df_in: DataFrame) -> bool:  # 3.1.22 校验非A类人员岗位类别是否发生变化
    """当【组合逻辑导出表103-【S-人员组】】的值不等于“A”时，锁定【组合逻辑导出表1071-【B-OT】= P】与【调入模板-【B-人员编号】】相同的值，检验是否存在下述情况，若存在，见1：
      【调入模板-【BJ-原岗位类别】】与【组合逻辑导出表1071-【B-OT】= S（P上方的第一个S）】的【K-岗位类别】的值不同。
       ------------------
       1.为“存在”，在【组合逻辑导出表103-【W-组织机构】】填充蓝色并插入批注“岗位类别发生变化”，继续检验下一人员。
    """
    staff_id = df_103['A'][rn]
    if df_103['S'][rn] != 'A':
        _in_bj = df_in[df_in['B'] == staff_id]['BJ'].values[0]
        up_cell_rn = df_1071[(df_1071['A'] == staff_id) & (df_1071['B'] == 'P')].index[0] - 1
        while True:
            if df_1071['B'][up_cell_rn] == 'S':  # 可能存在一岗多人，因此向上一直找，直到找到S
                break
            else:
                up_cell_rn = up_cell_rn - 1
        if _in_bj != df_1071['K'][up_cell_rn]:
            _103['W'].cmt('blue', '岗位类别发生变化')
    return True


@logfn
def chk_3_1_23(df_103: DataFrame, rn: int, _103: AdTableRow, df_1071: DataFrame, df_dims: DataFrame) -> bool:  # 3.1.23 校验岗位分类序列
    """检验是否存在下述情况，若存在，见1：锁定【组合逻辑导出表1071-【B-OT】= S】与【组合逻辑导出表103-【X-职务(岗位)具体名称】】相同的值，
       提取【组合逻辑导出表103-【AV-职位序列】】，在【码表库-【O】】进行文字匹配后提取第一个字符，与【组合逻辑导出表1071-【P-岗位分类序列】】不同。
       ------------------
       1.为“不相同”，在【组合逻辑导出表103-【AU-更改日期】】填充红色并插入批注“岗位分类序列与职位序列不对应”。
    """
    job_id = df_103['X'][rn]
    _1071_p = df_1071[(df_1071['A'] == job_id) & (df_1071['B'] == 'S')]['P'].values[0]
    for _o in df_dims['O'].values:
        if df_103['AV'][rn] in _o:
            if _o[:1] != _1071_p:
                _103['AU'].cmt('red', '岗位分类序列与职位序列不对应')
                return False
    return True


@logfn
def chk_3_1_24(df_103: DataFrame, rn: int, _103: AdTableRow) -> bool:  # 3.1.24 校验调入模板批导是否成功
    """检验同一人的【组合逻辑导出表103-【G-事件类型】】是否既有“调入”，又有“调出”。
       ------------------
       1.为“不是”，在【组合逻辑导出表103-【H-事件原因】】填充红色并插入批注“模板批导不成功”。
    """
    staff_id = df_103['A'][rn]
    _g = df_103[df_103['A'] == staff_id]['G'].values
    if '调入' not in _g or '调出' not in _g:
        _103['H'].cmt('red', '模板批导不成功')
        return False
    else:
        return True


@logfn
def chk_3_1_25(df_103: DataFrame, rn: int, _103: AdTableRow) -> bool:  # 3.1.25 校验成本中心是否为空
    """检验同一人的【组合逻辑导出表103-【CI-成本中心】、【CJ-成本中心】、【CK-WBS元素】、【CL-订单】】是否全部为空。
       ------------------
       1.为“是”，在【组合逻辑导出表103-【CI-成本中心】】填充红色并插入批注“机构和岗位的财务科目设置及PA30成本分配的成本中心全部为空”。
    """
    if df_103['CI'][rn] == '' and df_103['CJ'][rn] == '' and df_103['CK'][rn] == '' and df_103['CL'][rn] == '':
        _103['CI'].cmt('red', '机构和岗位的财务科目设置及PA30成本分配的成本中心全部为空')
        return False
    else:
        return True


@logfn
def chk_3_1_26(df_103: DataFrame, rn: int, _103: AdTableRow) -> bool:  # 3.1.26 校验总部统计唯一标识
    """检验同一人的【组合逻辑导出表103-【AQ-总部统计唯一标识】】是否为“用工统计”，若不是，见1。
       ------------------
       1.为“不是”，在【组合逻辑导出表103-【AQ-总部统计唯一标识】】填充红色并插入批注“总部统计唯一标识需核对！”。
    """
    if df_103['AQ'][rn] != '用工统计':
        _103['AQ'].cmt('red', '总部统计唯一标识需核对！')
        return False
    else:
        return True


@logfn
def chk_3_1_27(df_103: DataFrame, rn: int, _103: AdTableRow) -> bool:  # 3.1.27 校验人员子组-校验人员子组与职位序列的对应关系
    """检验当【组合逻辑导出表103-【T-人员子组】】的值为“12”或“13”时，【组合逻辑导出表103-【AV-职位序列】】的值，是否不是“管理序列”，见1；
       检验当【组合逻辑导出表103-【T-人员子组】】的值为“15”时，【组合逻辑导出表103-【AV-职位序列】】的值，是否不是“专业技术序列”，见1；
       检验当【组合逻辑导出表103-【T-人员子组】】的值为“16”或“17”时，【组合逻辑导出表103-【AV-职位序列】】的值，是否不是“技能操作序列”，见1；
       检验当【组合逻辑导出表103-【T-人员子组】】的值为“23”时，【组合逻辑导出表103-【AV-职位序列】】的值，是否不是“技能操作序列”，见2；
       检验当【组合逻辑导出表103-【T-人员子组】】的值为“61”时，【组合逻辑导出表103-【AV-职位序列】】的值，是否不是“专业技术序列”，见2；
       检验当【组合逻辑导出表103-【T-人员子组】】的值为“62”或“63”时，【组合逻辑导出表103-【AV-职位序列】】的值，是否不是“技能操作序列”，见2。
       ------------------
       1.为“不是”，在【组合逻辑导出表103-【T-人员子组】】填充红色并插入批注“人员子组有误！”；
       1.为“不是”，在【组合逻辑导出表103-【T-人员子组】】填充蓝色并插入批注“人员子组需核对！”。
    """
    if df_103['T'][rn] in ('12', '13') and df_103['AV'][rn] != '管理序列':
        _103['T'].cmt('red', '人员子组有误！')
    elif df_103['T'][rn] == '15' and df_103['AV'][rn] != '专业技术序列':
        _103['T'].cmt('red', '人员子组有误！')
    elif df_103['T'][rn] in ('16', '17') and df_103['AV'][rn] != '技能操作序列':
        _103['T'].cmt('red', '人员子组有误！')
    elif df_103['T'][rn] == '23' and df_103['AV'][rn] != '技能操作序列':
        _103['T'].cmt('blue', '人员子组需核对！')
    elif df_103['T'][rn] == '61' and df_103['AV'][rn] != '专业技术序列':
        _103['T'].cmt('blue', '人员子组需核对！')
    elif df_103['T'][rn] in ('62', '63') and df_103['AV'][rn] != '技能操作序列':
        _103['T'].cmt('blue', '人员子组需核对！')
    return True


@logfn
def chk_3_1_28(_103: AdTableRow, df_dims: DataFrame) -> bool:  # 3.1.28 检验人员子组-校验人员子组与在岗人员的对应关系
    """锁定【组合逻辑导出表103-【J-岗位状态】】的值为“在岗”的人员，当【组合逻辑导出表103-【S-人员组】】的值为“A”或“B"或”C"或"I"或"W"时，
       检验【组合逻辑导出表103-【T-人员子组】】的值是否为【码表库-【L3】或【L4】或【L5】或【L6】】，若是，执行下一规则；若不是，
       是否为【码表库-【L7】或【L10】】，若是，见1；若不是，见2。
       ------------------
       1.为“不是”，在【组合逻辑导出表103-【U-人员子组】】填充红色并插入批注“人员子组与在岗状态不对应！”；
       2.为“不是”，在【组合逻辑导出表103-【U-人员子组】】填充蓝色并插入批注“人员子组与在岗状态的对应关系需核对！”。
    """
    if _103['J'].value == '在岗':
        if _103['S'].value in ('A', 'B', 'C', 'I', 'W'):
            _t = _103['T'].value  # 人员子组编码
            _u = _103['U'].value  # 人员子组文本
            staff_sub_group = _t + ' ' + _u  # 人员子组
            if staff_sub_group in (df_dims['L'][3], df_dims['L'][4], df_dims['L'][5], df_dims['L'][6]):
                return True
            elif staff_sub_group in (df_dims['L'][7], df_dims['L'][10]):
                _103['U'].cmt('red', '人员子组与在岗状态不对应！')
                return False
            else:
                _103['U'].cmt('blue', '人员子组与在岗状态的对应关系需核对！')
                return True
    return True


@logfn
def chk_3_1_29(_103: AdTableRow, df_dims: DataFrame) -> bool:  # 3.1.29 检验人员子组-校验人员子组与不在岗人员的对应关系
    """锁定【组合逻辑导出表103-【J-岗位状态】】的值不为“在岗”的人员，当【组合逻辑导出表103-【S-人员组】】的值为“A”或“B"或”C"或"I"或"W"时，
       检验【组合逻辑导出表103-【T-人员子组】】的值是否为【码表库-【L8】或【L9】】，若是，执行下一规则；若不是，见1。
       ------------------
       1.为“不是”，在【组合逻辑导出表103-【U-人员子组】】填充红色并插入批注“人员子组与不在岗状态不对应！”。
    """
    if _103['J'].value != '在岗':
        if _103['S'].value in ('A', 'B', 'C', 'I', 'W'):
            if _103['T'].value in ('21', '22', df_dims['L'][8], df_dims['L'][9]):  # 21 内退人员 22 其他不在岗人员
                return True
            else:
                _103['U'].cmt('red', '人员子组与不在岗状态不对应！')
                return False
    return True


@logfn
def chk_3_1_30(df_103: DataFrame, rn: int, _103: AdTableRow, df_in: DataFrame) -> bool:  # 3.1.30 检验成本中心-校验成本中心是否发生变化
    """检验同一人的【组合逻辑导出表103-【CI-成本中心】】与【调入模板-【BJ-调动前成本中心】】的值是都相同，若相同，见1。
       ------------------
       1.为“相同”，在【组合逻辑导出表103-【CI-成本中心】】填充紫红色并插入批注“调动前后成本中心未发生变化！”。
    """
    staff_id = _103['A'].value
    _bj = df_in[df_in['B'] == staff_id]['BJ'].values[0]
    if df_103[(df_103['A'] == staff_id) & (df_103['CI'] != _bj)].empty is True:
        _103['CI'].cmt('purple', '调动前后成本中心未发生变化！')
        return False
    return True

#


@logfn
def before_chk_01(_in: AdTable, dims: AdTable) -> bool:
    """事前校验"""
    is_check_passed = []
    for row in _in.rows:
        logging.info(f'正在校验调入模板第{row.row_idx}行')
        is_check_passed.append(chk_1_1_2_1(row))  # 校验人员编号
        is_check_passed.append(chk_1_1_03_b(row))  # 检验空值*
        is_check_passed.append(chk_1_1_04(row))  # 校验事件执行日期
        is_check_passed.append(chk_1_1_05(row, dims))  # 校验调入原因
        is_check_passed.append(chk_1_1_06(row))  # 校验岗位编号
    return all(is_check_passed) is True


@logfn
def before_chk_02(_in: AdTable, _103_bak: AdTable, _1071: AdTable, _1072: AdTable, dims: AdTable) -> bool:
    """事前校验"""
    df_dims = dims.to_dataframe()
    df_103 = _103_bak.to_dataframe()
    df_1071 = _1071.to_dataframe()
    df_1072 = _1072.to_dataframe()
    is_check_passed = []
    for row in _in.rows:
        logging.info(f'正在校验调入模板第{row.row_idx}行')
        is_check_passed.append(chk_1_1_07_1(row, df_dims))  # 校验人员子组码值是否正确且其与职位序列是否对应
        is_check_passed.append(chk_1_1_07_2_1(row, df_dims))  # 校验职位序列、职位层次、职位级别码值性
        is_check_passed.append(chk_1_1_07_2_2(row))  # 校验兼任职位信息完整性
        is_check_passed.append(chk_1_1_07_2_3(row, df_dims))   # 校验兼任职位序列、兼任职位层次、兼任职位级别码值性
        is_check_passed.append(chk_1_1_07_2_4(row, df_dims))  # 校验兼任职位序列与主要职位序列的关联
        is_check_passed.append(chk_1_1_07_2_5(row, df_1072))  # 调整班组长标识
        is_check_passed.append(chk_1_1_07_3(row, df_dims))  # 校验人员子组与职位序列是否对应
        is_check_passed.append(chk_1_1_07_4(row, df_dims))  # 校验工作合同码值性
        is_check_passed.append(chk_1_1_07_5(row, df_dims))  # 校验企业统计标识码值性
        is_check_passed.append(chk_1_1_08(row))  # 检验职位名称长度
        is_check_passed.append(chk_1_1_09(row))  # 检验聘任文号长度
        is_check_passed.append(chk_1_1_10(row))  # 校验调动日期（工作经历开始日期）
        is_check_passed.append(chk_1_1_11(row, dims))  # 校验人员组
        is_check_passed.append(chk_1_1_11_1(row))  # 校验人员组是否发生变化
        is_check_passed.append(chk_1_1_12(row, dims))  # 校验人事子范围、人事范围码值
        is_check_passed.append(chk_1_1_13(row, dims))  # 校验调动前人事子范围、调动前人事范围码值
        is_check_passed.append(chk_1_1_14(row, dims))  # 校验企业自定义分类1
        is_check_passed.append(chk_1_1_15(row, dims))  # 校验企业自定义分类2
        is_check_passed.append(chk_1_1_16(row, dims))  # 校验企业自定义分类3
        is_check_passed.append(chk_1_1_17(row, dims))  # 校验是否是二级单位间调动、校验二级单位间调动事件原因* 规则1.1.18由1.1.17执行
        # is_check_passed.append(chk_1_1_18(row, dims))  # 校验是二级单位间调动还是直属单位间调动、校验调动事件原因、批注直属单位间调动类型*
        is_check_passed.append(chk_1_1_19(row, df_1072))  # 校验岗位所在财务科目设置的人事范围、人事子范围与调入模板是否一致
        is_check_passed.append(chk_1_1_20(row, df_1072))  # 校验岗位分类信息，未校验岗位分类序列（事后校验）
        is_check_passed.append(chk_1_1_21(row, _1072, dims))  # 校验薪酬标杆与职位序列是否一致
        is_check_passed.append(chk_1_1_22(row, df_1071))  # 校验是否分配岗位类别
        is_check_passed.append(chk_1_1_23(row, df_1072))  # 补充调入模板工作经历所在机构
        is_check_passed.append(chk_1_1_24(row))  # 补充调入模板工作经历职务
        is_check_passed.append(chk_1_1_25(row, df_103, df_dims))  # 调出、调入事件分支
    return all(is_check_passed) is True


@logfn
def after_check(_103: AdTable, _1071: AdTable, _1072: AdTable, _in: AdTable, dims: AdTable) -> bool:
    """事后校验"""
    df_103 = _103.to_dataframe()
    df_dims = dims.to_dataframe()
    df_in = _in.to_dataframe()
    df_1071 = _1071.to_dataframe()
    df_1072 = _1072.to_dataframe()
    is_check_passed = []
    for rn in df_103.index:
        row = _103.row(rn)
        logging.info(f'正在校验103表第{rn}行')
        is_check_passed.append(chk_3_1_02(df_103, rn, row, df_dims))  # 校验从事职业工种
        is_check_passed.append(chk_3_1_03(df_103, rn, row, df_in, df_1071))  # 校验从事职业工种
        is_check_passed.append(chk_3_1_04(df_103, rn, row, df_dims))  # 提醒工资核算范围
        is_check_passed.append(chk_3_1_05(df_103, rn, row, df_dims))  # 校验工资总额控制范围
        is_check_passed.append(chk_3_1_06(df_103, rn, row))  # 提醒组合逻辑导出表103多行信息
        is_check_passed.append(chk_3_1_07(df_103, rn, row))  # 校验薪酬标杆
        # is_check_passed.append(chk_3_1_08(df_103, rn, row, df_in))  # 校验开始日期（20210520 因简历调整，此条校验规则作废）
        is_check_passed.append(chk_3_1_09(df_103, rn, row))  # 校验结束日期
        is_check_passed.append(chk_3_1_10(df_103, rn, row))  # 校验职位序列、兼任职务序列的对应关系
        is_check_passed.append(chk_3_1_11(df_103, rn, row))  # 校验兼任职务信息是否完全
        is_check_passed.append(chk_3_1_12(df_103, rn, row))  # 校验职务（岗位）码是否为空
        is_check_passed.append(chk_3_1_13(df_103, rn, row, df_dims))  # 校验原中层转聘其他岗位标识是否正确勾选
        is_check_passed.append(chk_3_1_14(df_103, rn, row, df_1071))  # 校验是否存在一岗多人
        is_check_passed.append(chk_3_1_15(df_103, rn, row, df_in, df_dims))  # 校验是否是二级单位间调动、校验二级单位间调动事件原因
        is_check_passed.append(chk_3_1_16(df_103, rn, row, df_in, df_dims))  # 校验是二级单位间调动还是直属单位间调动、校验调动事件原因、批注直属单位间调动类型
        is_check_passed.append(chk_3_1_17(df_103, rn, row, df_1072))  # 校验岗位所在财务科目设置的人事范围、人事子范围与调入模板是否一致
        is_check_passed.append(chk_3_1_18(df_103, rn, row, df_in))  # 校验人员组
        is_check_passed.append(chk_3_1_19(df_103, rn, row, df_1071))  # 校验在岗人员的岗位类别
        is_check_passed.append(chk_3_1_20(df_103, rn, row, df_1072))  # 校验不在岗人员的岗位类别、虚岗位标识
        is_check_passed.append(chk_3_1_21(df_103, rn, row, df_1071, df_in))  # 校验C类人员岗位类别
        is_check_passed.append(chk_3_1_22(df_103, rn, row, df_1071, df_in))  # 校验非A类人员岗位类别是否发生变化
        is_check_passed.append(chk_3_1_23(df_103, rn, row, df_1071, df_dims))  # 校验岗位分类序列
        is_check_passed.append(chk_3_1_24(df_103, rn, row))  # 校验调入模板批导是否成功
        is_check_passed.append(chk_3_1_25(df_103, rn, row))  # 校验成本中心是否为空
        is_check_passed.append(chk_3_1_26(df_103, rn, row))  # 校验总部统计唯一标识
        is_check_passed.append(chk_3_1_27(df_103, rn, row))  # 校验人员子组-校验人员子组与职位序列的对应关系
        is_check_passed.append(chk_3_1_28(row, df_dims))  # 检验人员子组-校验人员子组与在岗人员的对应关系
        is_check_passed.append(chk_3_1_29(row, df_dims))  # 检验人员子组-校验人员子组与不在岗人员的对应关系
        is_check_passed.append(chk_3_1_30(df_103, rn, row, df_in))  # 检验成本中心-校验成本中心是否发生变化
    return all(is_check_passed) is True


@logfn
def _main(filename: str) -> bool:  # 二级单位间调动
    """二级单位间调动*直属单位间调动"""
    logging.info("加载码表库")
    dims: AdTable = load_tb_dim_hr_diao_pei()
    logging.info("清除调入模板批注")
    logging.info("加载调入模板")
    _in = load_infile(filename)  # 加载调入模板
    _in.clear_comment_and_fgcolor()
    chk_1_1_01(_in)  # 清除批注
    staff_ids = _in['B'].values
    dirname = _in.filename
    if before_chk_01(_in, dims) is False:  # 事前校验
        logging.error("事前校验未通过，上传失败文件至FTP")
        _in.save(filename)
        upload_to_ftp([_in], dirname, False)  # 上传校验失败的调入模板
        return False
    logging.info("导出组合逻辑查询1071")
    _1071 = _export_1071(_in)  # 导出组合逻辑查询1071
    if isinstance(_1071, AdTable) is False:
        raise Exception('导出1071失败')
    logging.info("导出组合逻辑查询1072")
    _1072 = chk_1_1_02(_in)  # 导出组合逻辑查询1072
    if isinstance(_1072, AdTable) is False:
        raise Exception('导出1071失败')
    logging.info("导出组合逻辑查询103（事前备份）")
    _103_bak = chk_1_2_4_bk(_in)  # 导出组合逻辑查询103
    _103_bak.filename += '_事前备份'
    _103_bak.save_to(pathlib.Path(filename).parent.as_posix())  # 备份事前103
    logging.info("正在进行事前校验")
    if before_chk_02(_in, _103_bak, _1071, _1072, dims) is False:  # 事前校验
        logging.error("事前校验未通过，上传失败文件至FTP")
        _in.save(filename)
        upload_to_ftp([_in, _103_bak, _1071, _1072], dirname, False)  # 上传校验失败的调入模板
        return False
    logging.info("事前校验通过")
    job_ids = _in['F'].values
    key_date = _in['D'].values[0]
    # 结构化刷新
    if refresh_user_data(job_ids=job_ids, key_date=key_date) is not True:  # 结构化刷新
        logging.error("结构化刷新失败，上传失败文件至FTP")
        _in.save(filename)
        upload_to_ftp([_in, _103_bak, _1071, _1072], dirname, False)  # 上传校验失败的调入模板
        return False
    _out = load_outfile()
    logging.info("生成调出模板的人员编号、姓名、岗位、人事范围、人事子范围")
    chk_1_2_1(_in, _out)  # 生成调出模板的人员编号、姓名、岗位、人事范围、人事子范围
    logging.info("生成调出模板的事件原因")
    chk_1_2_2(_in, _out, dims)  # 生成调出模板的事件原因
    logging.info("批导调出模板")
    if chk_1_2_3(_out) is not True:  # 批导调出模板
        logging.error('批导调出失败，上传失败文件至FTP')
        _in.save(filename)
        upload_to_ftp([_in, _103_bak, _1071, _1072, _out], dirname, False)
        return False
    logging.info("批导成功，导出组合逻辑查询103")
    _103 = chk_1_2_4(_in)  # 批导成功，导出组合逻辑查询103
    logging.info("检验同一人的【组合逻辑导出表103-【G-事件类型】】的值是否有“调出”")
    if chk_1_2_5(_103) is not True:
        logging.error("校验未通过，上传失败文件至FTP")
        _in.save(filename)
        upload_to_ftp([_in, _1071, _1072, _out, _103, _103_bak], dirname, False)
        return False
    logging.info("校验通过")
    logging.info("批导调入模板")
    if chk_1_3_1(_in) is not True:  # 批导调入模板
        logging.error("批导调入失败，上传失败文件至FTP")
        _in.save(filename)
        upload_to_ftp([_in, _1071, _1072, _out, _103, _103_bak], dirname, False)
        return False
    logging.info("批导成功，导出组合逻辑查询103")
    _103 = chk_1_3_2(_in)  # # 批导成功，导出组合逻辑查询103
    logging.info("检验同一人的【组合逻辑导出表103-【G-事件类型】】的值是否有“调入”")
    if chk_1_3_3(_103) is not True:
        logging.error("校验未通过，上传失败文件至FTP")
        _in.save(filename)
        upload_to_ftp([_in, _1071, _1072, _out, _103, _103_bak], dirname, False)
        return False
    logging.info("校验通过")
    logging.info("加载新增从事职业工种信息模板")
    _9243 = load_9243()
    logging.info("生成“新增从事职业工种信息”模板")
    if chk_1_3_4(_in, dims, _9243) is True:  # 生成“新增从事职业工种信息”模板（且模板数据不为空chk_1_3_4返回True）
        logging.info("批导新增从事职业工种信息模板")
        if chk_1_3_5(_9243) is not True:
            logging.error("批导新增从事职业工种信息模板失败，上传失败文件至FTP")
            _in.save(filename)
            upload_to_ftp([_in, _1071, _1072, _out, _103, _9243, _103_bak], dirname, False)
            return False
    logging.info("[零星修改-修改企业自定义分类2、3，校验、修改/重新带出工资总额控制范围】")
    chk_2_1_1(_in, _103, dims)  # 修改企业自定义分类2、3，校验、修改/重新带出工资总额控制范围
    logging.info("[零星修改-修改工作经历开始日期]")
    chk_2_1_2(_in)  # 修改工作经历开始日期
    logging.info("[零星修改-定界从事职业工种信息结束日期]")
    chk_2_1_3(_103, dims)  # 定界从事职业工种信息结束日期
    logging.info("[零星修改-重新带出从事职业工种信息]")
    chk_2_1_4(_9243)  # 重新带出从事职业工种信息
    logging.info("[零星修改-生成优化配置与人员增减信息]")
    chk_2_1_5(_in, dims)  # 生成优化配置与人员增减信息
    logging.info("[零星修改-生成最高等级工种鉴定标识]")
    chk_2_1_6(_in)  # 生成最高等级工种鉴定标识
    try:
        logging.info("[零星修改-生成简历]")
        is_resume_succ = chk_2_1_7(_in, _103)  # 生成简历
    except Exception as e:
        logging.error(e)
    logging.warning("[零星修改-生成简历] 20210520 更新简历功能")
    logging.info("[零星修改-确定00工资总额控制范围为空]")
    chk_2_1_8(_103)  # 确定00工资总额控制范围为空
    rpa_work_amount(staff_ids)
    logging.info("导出组合逻辑查询103、1071、1072")
    _103, _1071, _1072 = chk_3_1_01(_in)  # 导出组合逻辑查询103、1071、1072
    logging.info("事后校验")
    if is_resume_succ is not True:
        _df_103 = _103.to_dataframe()
        for rn in _df_103.index:
            _103['BP'][rn].cmt('red', '简历生成失败，请检查简历模板')
    if after_check(_103, _1071, _1072, _in, dims) is not True or is_resume_succ is not True:  # 事后校验
        logging.error("事后校验未通过，上传失败文件至FTP")
        _in.save(filename)
        upload_to_ftp([_in, _1071, _1072, _103, _out, _9243, _103_bak], dirname, False)
        return False
    logging.info("事后校验通过，未遇到错误，上传文件至FTP")
    upload_to_ftp([_in, _1071, _1072, _103, _out, _9243, _103_bak], dirname, True)
    return True


@logfn
def main(filename: str) -> bool:
    is_passed = _main(filename)
    return is_passed


def is_secondary_work_transfter_template(filename: str) -> bool:
    return '二级单位间调动' in filename or '直属单位间调动' in filename


def run_before_check(filename: str) -> bool:
    """只做事前校验"""
    config('二级单位间调动事前校验.log')
    logging.info("加载码表库")
    dims: AdTable = load_tb_dim_hr_diao_pei()
    logging.info("清除调入模板批注")
    logging.info("加载调入模板")
    _in = load_infile(filename)  # 加载调入模板
    _in.clear_comment_and_fgcolor()
    chk_1_1_01(_in)  # 清除批注
    dirname = _in.filename
    if before_chk_01(_in, dims) is False:  # 事前校验
        logging.error("事前校验未通过，上传失败文件至FTP")
        upload_to_ftp([_in], dirname, False)  # 上传校验失败的调入模板
        return False
    logging.info("导出组合逻辑查询1071")
    _1071 = _export_1071(_in)  # 导出组合逻辑查询1071
    if isinstance(_1071, AdTable) is False:
        raise Exception('导出1071失败')
    logging.info("导出组合逻辑查询1072")
    _1072 = chk_1_1_02(_in)  # 导出组合逻辑查询1072
    if isinstance(_1072, AdTable) is False:
        raise Exception('导出1071失败')
    logging.info("导出组合逻辑查询103（事前备份）")
    _103_bak = chk_1_2_4(_in)  # 导出组合逻辑查询103
    _103_bak.filename += '_事前备份'
    _103_bak.save_to(pathlib.Path(filename).parent.as_posix())  # 备份事前103
    logging.info("正在进行事前校验")
    if before_chk_02(_in, _103_bak, _1071, _1072, dims) is False:  # 事前校验
        logging.error("事前校验未通过，上传失败文件至FTP")
        upload_to_ftp([_in, _103_bak, _1071, _1072], dirname, False)  # 上传校验失败的调入模板
        return False
    logging.info("事前校验通过，未遇到错误，上传文件至FTP")
    upload_to_ftp([_in, _1071, _1072, _103_bak], dirname, True)
    return True


def run_after_check(filename: str) -> bool:
    """只做事后校验"""
    config('二级单位间调动事后校验.log')
    logging.info("加载码表库")
    dims: AdTable = load_tb_dim_hr_diao_pei()
    logging.info("清除调入模板批注")
    logging.info("加载调入模板")
    _in = load_infile(filename)  # 加载调入模板
    _in.clear_comment_and_fgcolor()
    chk_1_1_01(_in)  # 清除批注
    dirname = _in.filename
    logging.info("导出组合逻辑查询103、1071、1072")
    _103, _1071, _1072 = chk_3_1_01(_in)  # 导出组合逻辑查询103、1071、1072
    logging.info("事后校验")
    if after_check(_103, _1071, _1072, _in, dims) is not True:  # 事后校验
        logging.error("事后校验未通过，上传失败文件至FTP")
        upload_to_ftp([_in, _1071, _1072, _103, ], dirname, False)
        return False
    logging.info("事后校验通过，未遇到错误，上传文件至FTP")
    upload_to_ftp([_in, _1071, _1072, _103], dirname, True)
    return True


def only_run_after_check():  # 单独执行事后校验部分（测试用）
    config()
    dims: AdTable = load_tb_dim_hr_diao_pei()
    _in = load_from_xlsx_file(r"x:\102032_失败_0000000000-X942-二级单位间调动-岳子渝（20201101）\0000000000-X942-二级单位间调动-岳子渝（20201101）.xlsx")
    _103 = load_from_xlsx_file(r"x:\102032_失败_0000000000-X942-二级单位间调动-岳子渝（20201101）\模板_103_事后备份.xlsx")
    _1071 = load_from_xlsx_file(r"x:\102032_失败_0000000000-X942-二级单位间调动-岳子渝（20201101）\模板_1071.xlsx")
    _1072 = load_from_xlsx_file(r"x:\102032_失败_0000000000-X942-二级单位间调动-岳子渝（20201101）\模板_1072.xlsx")
    logging.info("事后校验")
    after_check(_103, _1071, _1072, _in, dims)
    _103.save_to('x:/')


if __name__ == '__main__':  # 命令行执行
    # test_after_check()
    if len(sys.argv) >= 2 and len(sys.argv[1]) > 5 and sys.argv[1][:5].lower() == r'.xslx':
        cmd_filename = sys.argv[1]
        config(datetime.datetime.now().strftime(r'%H%M%S') + '_' + pathlib.Path(cmd_filename).name[:-4] + '.txt')
        main(cmd_filename)
    else:
        cmd_filename = r"x:\Users\HR-HDH\Desktop\1000269173-X63Z-二级单位间调动-韩华.xlsx"
        config(datetime.datetime.now().strftime(r'%H%M%S') + '_' + pathlib.Path(cmd_filename).name[:-4] + '.txt')
        main(cmd_filename)
        logging.info('程序调用方式：main.py 调入模板.xlsx')
