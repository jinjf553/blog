#!/usr/bin/env python
# -*- coding: utf-8 -*-
# @File    : nei_tui_shi_jian.py
# @Author  : jinjianfeng
import logging
import os
import re
import shutil
from collections import defaultdict
from datetime import datetime

from openpyxl import load_workbook
from rpa.fastrpa.adtable import BLUE, RED
from rpa.fastrpa.path import to_windows_path_format
from rpa.fastrpa.sap.session import attach_sap
from rpa.public.config import FILE_PATH, remote_nt
from rpa.public.db import update_db
from rpa.public.event_public import (clear_all_colour_and_comment, send_email,
                                     update_database)
from rpa.public.myftp import MYFTP
from rpa.public.tools import cel, cells
from rpa.ssc.hr.orm.orm import rpa_work_amount
from rpa.ssc.hr.orm.orm_ope import Query
from rpa.ssc.hr.orm.td_hr_gang_wei_diao_pei_rulebase import Event
from rpa.ssc.hr.orm.td_hr_li_tui_code_rulebase import LiTui
from rpa.ssc.hr.rpa_dir import get_rpa_dir
from rpa.ssc.hr.sap.export_1072 import export_1072
from rpa.ssc.hr.sap.export_other_103 import export_103_nei_tui
from rpa.ssc_kit.hr.kit_chai_dan.check_280 import check_zhrpy280


def nei_tui_pre_check(filename):
    logging.info("开始内退事件批导前校验...")
    wb = load_workbook(filename)
    ws = wb.active

    # 1.1.2	校验文件名格式
    li = os.path.basename(filename).split("-")
    if len(li) < 4 or not (li[0].isdigit() or li[0] != "无单号") or len(li[1]) != 4 or li[2] != "内退":
        cells(ws, "A7", "文件名称错误，应为:单号-人事范围代码-内退-业务人员姓名或无单号-人事范围代码-内退-业务人员姓名", RED)

    logging.info("提取校验过程中需要使用到的码值...")
    rule_p = [str(res.db_P).strip() for res in Query(LiTui) if res.db_P]  # 内退事件原因
    rule_f = {str(res.db_F).replace(" ", ""): str(res.db_F).strip() for res in Query(Event) if res.db_F}  # 企业自定义分类1
    rule_g = {str(res.db_G).replace(" ", ""): str(res.db_G).strip() for res in Query(Event) if res.db_G}  # 企业自定义分类1
    rule_h = {str(res.db_H).replace(" ", ""): str(res.db_H).strip() for res in Query(Event) if res.db_H}  # 企业自定义分类1
    rule_c = [str(res.db_C).strip() for res in Query(LiTui) if res.db_C]  # 编码
    rule_AZ = [str(res.db_AZ).strip() for res in Query(Event) if res.db_AZ]
    rule_D = {str(res.db_E).strip(): str(res.db_D).strip() for res in Query(Event) if res.db_E}
    rule_Ds = defaultdict(dict)  # 码值
    for res in Query(LiTui):
        t = {"C": res.db_C, "D": res.db_D, "E": res.db_E, "F": res.db_F, "G": res.db_G, "H": res.db_H, "I": res.db_I,
             "J": res.db_J, "K": res.db_K, "L": res.db_L, "M": res.db_M, "N": res.db_N}
        if res.db_C:
            rule_Ds[str(res.db_C).strip()] = {x: str(y).strip().replace("None", "") for x, y in t.items()}

    # 1.1.13	导出组合逻辑查询103、1072
    lis = [cel(ws, f"B{x}") for x in range(7, len(ws["A"]) + 1) if cel(ws, f"B{x}").isdigit()]  # 人员编号
    lis1 = [cel(ws, f"AG{x}") for x in range(7, len(ws["A"]) + 1) if cel(ws, f"AG{x}").isdigit()]  # 岗位编号
    date = [cel(ws, f"D{x}") for x in range(7, len(ws["A"]) + 1) if cel(ws, f"D{x}")][0]  # 事件日期
    if not lis or not lis1:
        logging.info("请确保内退模板中【B列-人员编号】和【AG列-岗位编号】有正确值。")
        raise Exception("请确保内退模板中【B列-人员编号】和【AG列-岗位编号】有正确值。")
    logging.info("提取校验所需要的内退103和内退1072数据...")
    export_103_nei_tui("reuse", lis, date).save_to(FILE_PATH)
    shutil.copyfile(FILE_PATH + "/C22_内退.xlsx", f"{FILE_PATH}/事前_103.xlsx")
    wb_103 = load_workbook(FILE_PATH + "/C22_内退.xlsx")
    ws_103 = wb_103.active
    value_103 = defaultdict(list)
    for i in range(2, len(ws_103["A"]) + 1):
        for col in ["C", "J", "L", ]:
            value_103[cel(ws_103, f"A{i}").lstrip("0")].append(cel(ws_103, f"{col}{i}"))

    export_1072("reuse", lis1, date).save_to(FILE_PATH)
    shutil.copyfile(f"{FILE_PATH}/模板_1072.xlsx", f"{FILE_PATH}/事前_1072.xlsx")
    wb_1072 = load_workbook(FILE_PATH + "/模板_1072.xlsx")
    ws_1072 = wb_1072.active
    value_1072 = defaultdict(list)
    for x in range(2, len(ws_1072["A"]) + 1):
        t = [("G", x), ("AM", x), ("P", x), ("Q", x), ("R", x), ("P", x + 1), ("Q", x + 1), ("R", x + 1)]
        if cel(ws_1072, f"B{x}") == "S":
            value_1072[cel(ws_1072, f"A{x}").lstrip('0')] = [cel(ws_1072, f"{y}{z}") for y, z in t]

    now = datetime.now()
    next_month = datetime(*(now.year, now.month + 1) if now.month + 1 < 13 else (now.year + 1, 1), 1, 0, 0, 0)
    cur_month = datetime(now.year, now.month, 1, 0, 0, 0)

    for i in range(7, len(ws["A"]) + 1):
        # 1.1.3	校验人员编号
        logging.info(f"开始校验内退模板第{i - 6}行数据...")
        ws[f"B{i}"] = "".join(re.findall(r"\d", str(ws[f"B{i}"].value))).lstrip("0")
        if not cel(ws, f"B{i}") or len(cel(ws, f"B{i}")) > 8:
            cells(ws, f"B{i}", "人员编号有误", RED)

        # 1.1.5	校验开始日期
        if cel(ws, f"D{i}") not in [cur_month.strftime("%Y%m%d"), next_month.strftime("%Y%m%d")]:
            cells(ws, f"D{i}", "内退日期有误！", RED)

        # 1.1.6	检验内退原因
        if cel(ws, f"E{i}") not in rule_p:
            cells(ws, f"E{i}", "离退码表库对应编号的内退原因非码值！", RED)

        # 1.1.7	检验企业自定义分类1
        if not cel(ws, f"T{i}"):
            ws[f"T{i}"] = "清空"
        elif cel(ws, f"T{i}") != "清空":
            if cel(ws, f"T{i}").replace(" ", "") in rule_f.keys():
                ws[f"T{i}"] = rule_f[cel(ws, f"T{i}").replace(" ", "")]
            else:
                cells(ws, f"T{i}", "企业自定义分类1非码值！", RED)

        # 1.1.8	检验企业自定义分类2
        if not cel(ws, f"U{i}"):
            ws[f"U{i}"] = "清空"
        elif cel(ws, f"U{i}") != "清空":
            if cel(ws, f"U{i}").replace(" ", "") in rule_g.keys():
                ws[f"U{i}"] = rule_g[cel(ws, f"U{i}").replace(" ", "")]
            else:
                cells(ws, f"U{i}", "企业自定义分类2非码值！", RED)

        # 1.1.9	检验企业自定义分类3
        if not cel(ws, f"V{i}"):
            ws[f"V{i}"] = "清空"
        elif cel(ws, f"V{i}") != "清空":
            if cel(ws, f"V{i}").replace(" ", "") in rule_h.keys():
                ws[f"V{i}"] = rule_h[cel(ws, f"V{i}").replace(" ", "")]
            else:
                cells(ws, f"V{i}", "企业自定义分类3非码值！", RED)

        # 1.1.10	校验离退码表库对应编号
        if cel(ws, f"AC{i}") not in rule_c:
            cells(ws, f"AC{i}", "对应编号非离退码表库码值！", RED)

        # 1.1.11	核对离退码表值
        if cel(ws, f"AC{i}") in rule_Ds.keys():
            t = {"D": "对应表单码值与离退码表库不同！", "E": "对应人事范围与离退码表库不同！", "F": "对应人事子范围与离退码表库不同！",
                 "G": "对应岗位编号与离退码表库不同！", "H": "对应岗位名称与离退码表库不同！", "I": "对应工资核算范围与离退码表库不同！",
                 "J": "对应工资总额控制范围与离退码表库不同！", "K": "对应原因与离退码表库不同！", "L": "对应备注与离退码表库不同！",
                 "M": "对应功能范围与离退码表库不同！", "N": "对应业务范围与离退码表库不同！"}
            for x, y in t.items():
                if cel(ws, f"A{x}{i}") != rule_Ds[cel(ws, f"AC{i}")][x]:
                    cells(ws, f"A{x}{i}", y, RED)

        # 1.1.12	检验备注文本长度
        ws[f"M{i}"] = cel(ws, f"M{i}")
        if len(cel(ws, f"M{i}")) > 100:
            cells(ws, f"M{i}", "离退码表库对应编号的备注文本超过100个字符！", RED)

        # 1.1.14	检验岗位
        ag = cel(ws, f"AG{i}").lstrip("0")
        if ag in value_1072.keys():
            if cel(ws, f"AH{i}") != value_1072[ag][0]:
                cells(ws, f"AH{i}", "岗位名称与离退码表库不同！", RED)
            if value_1072[ag][1] != "是":
                cells(ws, f"AG{i}", "未勾选虚岗位标识！", RED)
        else:
            cells(ws, f"AG{i}", "未在系统中查找到该岗位编号！", RED)

        # 1.1.15	逻辑关系校验-人事范围、人事子范围
        if ag in value_1072.keys():
            if not (value_1072[ag][2] or value_1072[ag][3]):
                if value_1072[ag][5] != cel(ws, f"AE{i}"):
                    cells(ws, f"AE{i}", "岗位所在机构的财务科目设置的人事范围与模板不一致！", RED)  # 7
                else:
                    if value_1072[ag][6] + " " + value_1072[ag][7] == cel(ws, f"AF{i}"):
                        cells(ws, f"AE{i}", "岗位所在机构的财务科目设置的人事范围、人事子范围与模板一致！", BLUE)  # 8
                    else:
                        cells(ws, f"AE{i}", "岗位所在机构的财务科目设置的人事子范围与模板不一致！", RED)  # 9
            elif not value_1072[ag][5]:
                if value_1072[ag][6] + " " + value_1072[ag][7] == cel(ws, f"AF{i}"):
                    cells(ws, f"AE{i}", "岗位财务科目设置有值，人事范围继承自机构、人事子范围设置在岗位上！", BLUE)  # 1
                else:
                    cells(ws, f"AE{i}", "岗位财务科目设置有值，人事范围继承自机构、人事子范围设置在岗位上但与模板不同！", RED)  # 2
            else:
                if value_1072[ag][5] == cel(ws, f"AE{i}"):
                    if not value_1072[ag][6]:
                        cells(ws, f"AE{i}", "岗位财务科目设置有值，人事范围有值、但人事子范围为空或继承自机构！", BLUE)  # 3
                    elif value_1072[ag][6] + " " + value_1072[ag][7] == cel(ws, f"AF{i}"):
                        cells(ws, f"AE{i}", "岗位财务科目设置有值，人事范围、人事子范围均设置在岗位上且与模板一致！", BLUE)  # 4
                    else:
                        cells(ws, f"AE{i}", "岗位财务科目设置有值，人事范围、人事子范围均设置在岗位上，但人事子范围与模板不一致！", RED)  # 5
                else:
                    cells(ws, f"AE{i}", "岗位财务科目设置有值，但人事范围与模板不一致！", RED)  # 6

        # 1.1.16	检验103日期、人员岗位状态
        b = cel(ws, f"B{i}").lstrip("0")
        if b in value_103.keys():
            if value_103[b][2] == cel(ws, f"D{i}"):
                cells(ws, f"D{i}", "组织分配屏开始日期与事件执行日期相同，请检查组织分配屏！", BLUE)
            if value_103[b][0] == cel(ws, f"D{i}"):
                cells(ws, f"D{i}", "事件执行日期已有事件，请检查人事调配屏！", RED)
            if value_103[b][1] in rule_AZ[8:15]:
                cells(ws, f"D{i}", "岗位状态不应做内退事件，请检查人事调配屏！", RED)

        # 1.1.17	检验人事范围、人事子范围
        if cel(ws, f"AE{i}") not in rule_D.values():
            cells(ws, f"AE{i}", "人事范围非码值，请检查离退码表库是否正确！", RED)
        elif cel(ws, f"AF{i}") not in rule_D.keys() or rule_D[cel(ws, f"AF{i}")] != cel(ws, f"AE{i}"):
            cells(ws, f"AF{i}", "人事子范围与人事范围不对应，请检查离退码表库是否正确！", RED)
    logging.info("内退模板执行事件前校验完成...")
    wb.save(filename)


# 执行离职事件操作
def nei_tui_operate(r_file):
    logging.info("开始执行内退事件...")
    session = attach_sap("login_tx")
    wb = load_workbook(r_file)
    ws = wb.active
    for i in range(7, len(ws[f"A"]) + 1):
        logging.info(f"正在执行内退事件第{i-6}条数据...")
        if cel(ws, f"P{i}") == "成功":
            continue
        string = ""
        ws[f"P{i}"], ws[f"Q{i}"] = "", ""
        try:
            def tmp_enter(sess, strings):
                try:
                    sess.findById("wnd[1]").sendVKey(0)
                except Exception:
                    pass
                for _ in range(5):
                    text = session.findById("wnd[0]/sbar").text
                    if "请保存" not in text:
                        session.findById("wnd[0]").sendVKey(0)
                    else:
                        return
                else:
                    logging.info(f'{strings}{str(session.findById("wnd[0]/sbar").text)}')
                    strings = f'{strings}{str(session.findById("wnd[0]/sbar").text)}'
                    return strings if strings else "出现错误"
            #  2.1.1	人事调配屏
            session.findById("wnd[0]/tbar[0]/okcd").text = "/n ZPA40_08"
            session.findById("wnd[0]").sendVKey(0)
            session.findById("wnd[0]/usr/ctxtRP50G-PERNR").text = cel(ws, f"B{i}")  # 人员编号
            session.findById("wnd[0]/usr/ctxtRP50G-EINDA").text = cel(ws, f"D{i}")  # 起始日期
            session.findById("wnd[0]/usr/tblSAPMP50ATC_MENU_EVENT").getAbsoluteRow(8).selected = -1
            session.findById("wnd[0]/tbar[1]/btn[8]").press()

            session.findById("wnd[0]/usr/ctxtP0000-MASSG").text = "20" if "非上市内退" in cel(ws, f"E{i}") else "10"
            session.findById("wnd[0]/usr/ctxtPSPAR-PLANS").text = cel(ws, f"AG{i}")  # 岗位编号 --- 对应岗位编号
            session.findById("wnd[0]/usr/ctxtPSPAR-WERKS").text = cel(ws, f"AE{i}")  # 人事范围 --- 对应人事范围
            session.findById("wnd[0]/usr/ctxtPSPAR-PERSK").text = "21"  # 人员子组
            string = tmp_enter(session, string)
            if string:
                ws[f"P{i}"] = "人事调配屏错误！"
                ws[f"Q{i}"] = string
                wb.save(r_file)
                continue
            session.findById("wnd[0]/tbar[0]/btn[11]").press()
            session.findById("wnd[0]").sendVKey(0)

            #  2.1.2	组织分配屏
            session.findById("wnd[0]/usr/ctxtP0001-BTRTL").text = cel(ws, f"AF{i}")[:4]  # 对应人事子范围 --- 》 人事子范围
            session.findById("wnd[0]/usr/ctxtP0001-GSBER").text = cel(ws, f"AN{i}")  # 对应业务范围 --- 》 业务范围
            session.findById("wnd[0]/usr/ctxtP0001-ABKRS").text = cel(ws, f"AI{i}")[:2]  # 对应工资核算范围 --- 》 工资范围
            session.findById("wnd[0]/usr/subSUBSCREEN_T582C:ZP000100:0200/ctxtP0001-ZZ_QYZDYYGFL").text = cel(ws, f"T{i}").replace("清空", "")  # 自定义分类1
            session.findById("wnd[0]/usr/subSUBSCREEN_T582C:ZP000100:0200/ctxtP0001-ZZ_QYZDYYGFL1").text = cel(ws, f"U{i}").replace("清空", "")  # 自定义分类2
            session.findById("wnd[0]/usr/subSUBSCREEN_T582C:ZP000100:0200/ctxtP0001-ZZ_QYZDYYGFL2").text = cel(ws, f"V{i}").replace("清空", "")  # 自定义分类3
            try:
                session.findById("wnd[0]/usr/subSUBSCREEN_T582C:ZP000100:0200/ctxtP0001-ZZ_ZEFW").text = cel(ws, f"AJ{i}")[:2]  # 对应工资总额控制范围
            except Exception:
                pass
            session.findById("wnd[0]/usr/subSUBSCREEN_T582C:ZP000100:0200/cmbP0001-ZZ_GNFW").key = cel(ws, f"AM{i}") if cel(ws, f"AM{i}") else " "
            string = tmp_enter(session, string)
            if string:
                ws[f"P{i}"] = "组织分配屏错误！"
                ws[f"Q{i}"] = string
                wb.save(r_file)
            session.findById("wnd[0]/tbar[0]/btn[11]").press()
            session.findById("wnd[0]").sendVKey(0)

            # 2.1.3	内退人员信息屏
            session.findById("wnd[0]/usr/ctxtP9256-ENDDA").text = "99991231"  # 结束日期
            session.findById("wnd[0]/usr/txtP9256-ZZ_BZ").text = cel(ws, f"AL{i}")  # 备注
            string = tmp_enter(session, string)
            if string:
                ws[f"P{i}"] = "内退人员信息屏错误!"
                ws[f"Q{i}"] = string
                wb.save(r_file)
            session.findById("wnd[0]/tbar[0]/btn[11]").press()  # 点击对勾之后返回第一屏
            session.findById("wnd[0]").sendVKey(0)
            tmp_enter(session, string)

            # 2.1.4	岗位聘补屏
            session.findById("wnd[0]/tbar[0]/okcd").text = '/n pa30'
            session.findById("wnd[0]").sendVKey(0)
            session.findById("wnd[0]/usr/ctxtRP50G-PERNR").text = cel(ws, f"B{i}")
            session.findById("wnd[0]").sendVKey(0)
            session.findById(f"wnd[0]/usr/tabsMENU_TABSTRIP/tabpTAB03").select()
            session.findById(
                f"wnd[0]/usr/tabsMENU_TABSTRIP/tabpTAB03/ssubSUBSCR_MENU:SAPMP50A:0400/subSUBSCR_ITMENU:SAPMP50A:0310/tblSAPMP50ATC_MENU").verticalScrollbar.position = 1
            session.findById(
                f"wnd[0]/usr/tabsMENU_TABSTRIP/tabpTAB03/ssubSUBSCR_MENU:SAPMP50A:0400/subSUBSCR_ITMENU:SAPMP50A:0310/tblSAPMP50ATC_MENU").getAbsoluteRow(1).selected = -1
            session.findById(
                "wnd[0]/usr/tabsMENU_TABSTRIP/tabpTAB03/ssubSUBSCR_MENU:SAPMP50A:0400/subSUBSCR_TIME:SAPMP50A:0330/ctxtRP50G-BEGDA").text = cel(ws, f"D{i}")
            session.findById(
                "wnd[0]/usr/tabsMENU_TABSTRIP/tabpTAB03/ssubSUBSCR_MENU:SAPMP50A:0400/subSUBSCR_TIME:SAPMP50A:0330/ctxtRP50G-ENDDA").text = "99991231"
            session.findById(f"wnd[0]/tbar[1]/btn[5]").press()
            session.findById("wnd[0]/usr/ctxtP9209-BEGDA").text = cel(ws, f"D{i}")
            tmp_enter(session, string)
            session.findById("wnd[0]/tbar[0]/btn[11]").press()
            session.findById("wnd[0]").sendVKey(0)
            ws[f"P{i}"] = "成功"
        except Exception as e:
            string = session.findById("wnd[0]/sbar").text
            ws[f"P{i}"] = "错误！"
            ws[f"Q{i}"] = string if string else f"未知异常:{e}"
        wb.save(r_file)


# 离职事件事后校验
def nei_tui_post_check(s_file):
    logging.info("开始内退事件后置校验...")
    wb_temp = load_workbook(s_file)
    ws_temp = wb_temp.active

    # 3.1.1	导出组合逻辑查询103、1072
    lis = [cel(ws_temp, f"B{x}") for x in range(7, len(ws_temp["A"]) + 1) if cel(ws_temp, f"B{x}")]  # 人员编号
    lis1 = [cel(ws_temp, f"AG{x}") for x in range(7, len(ws_temp["A"]) + 1) if cel(ws_temp, f"AG{x}")]  # 岗位编号
    date = [cel(ws_temp, f"D{x}") for x in range(7, len(ws_temp["A"]) + 1) if cel(ws_temp, f"D{x}")][0]  # 事件日期
    rpa_work_amount(lis)
    value_temp = defaultdict(list)
    for i in range(7, len(ws_temp["A"]) + 1):
        for col in ["D", "AE", "AF", "AI", "AJ", "T", "U", "V", "P"]:
            value_temp[cel(ws_temp, f"B{i}").lstrip("0")].append(cel(ws_temp, f"{col}{i}"))
    if not lis:
        logging.info("内退模板中没有内退事件。")
        return
    logging.info("提取校验所需要的内退103和内退1072数据...")
    export_103_nei_tui("reuse", lis, date).save_to(FILE_PATH)
    wb_103 = load_workbook(FILE_PATH + "/C22_内退.xlsx")
    ws = wb_103.active

    export_1072("reuse", lis1, date).save_to(FILE_PATH)
    wb_1072 = load_workbook(FILE_PATH + "/模板_1072.xlsx")
    ws_1072 = wb_1072.active
    value_1072 = defaultdict(list)
    for x in range(2, len(ws_1072["A"]) + 1):
        t = [("G", x), ("AM", x), ("P", x), ("Q", x), ("R", x), ("P", x + 1), ("Q", x + 1), ("R", x + 1)]
        if cel(ws_1072, f"B{x}") == "S":
            value_1072[cel(ws_1072, f"A{x}").lstrip('0')] = [cel(ws_1072, f"{y}{z}") for y, z in t]

    res_dict = defaultdict(list)
    for i in range(2, len(ws["A"]) + 1):
        logging.info(f"开始校验事后内退103第{i - 1}行数据...")
        key = cel(ws, f"A{i}").lstrip("0")
        if key not in value_temp.keys():
            cells(ws, f"A{i}", "内退模板中没有该人员编号", RED)
            res_dict[True].append(f"A{i}")
            continue

        # 3.1.2.1	检验数据是否成功
        for x in ["C", "L", "AX"]:
            if cel(ws, f"{x}{i}").replace(".", "") != value_temp[key][0]:
                cells(ws, f"{x}{i}", f"开始日期与表单不一致！", RED)
                res_dict[True].append(f"{x}{i}")

        # 3.1.2.2
        if "内退" not in cel(ws, f"G{i}"):
            cells(ws, f"G{i}", "内退事件未做成功！", RED)
            res_dict[True].append(f"G{i}")

        # 3.1.2.3
        if cel(ws, f"P{i}") != value_temp[key][1]:
            cells(ws, f"P{i}", "人事范围与离退码表库不同！", RED)
            res_dict[True].append(f"P{i}")

        # 3.1.2.4
        if f'{cel(ws, f"Q{i}")} {cel(ws, f"R{i}")}' != value_temp[key][2]:
            cells(ws, f"Q{i}", "人事子范围与离退码表库不同！", RED)
            res_dict[True].append(f"Q{i}")

        # 3.1.2.5
        if f'{cel(ws, f"Z{i}")} {cel(ws, f"AA{i}")}' != value_temp[key][3]:
            cells(ws, f"Z{i}", "工资核算范围与离退码表库不同！", RED)
            res_dict[True].append(f"Z{i}")

        # 3.1.2.6
        if f'{cel(ws, f"AB{i}")} {cel(ws, f"AC{i}")}' != value_temp[key][4]:
            cells(ws, f"AB{i}", "工资总额控制范围与离退码表库不同！", RED)
            res_dict[True].append(f"AB{i}")

        # 3.1.2.7
        if f'{cel(ws, f"AD{i}")}{cel(ws, f"AE{i}")}' != str(value_temp[key][5]).replace(" ", "").replace("清空", ""):
            cells(ws, f"AD{i}", "企业自定义员工分类1与离退码表库不同！", RED)
            res_dict[True].append(f"AD{i}")

        # 3.1.2.8
        if f'{cel(ws, f"AF{i}")}{cel(ws, f"AG{i}")}' != str(value_temp[key][6]).replace(" ", "").replace("清空", ""):
            cells(ws, f"AF{i}", "企业自定义员工分类2与离退码表库不同！", RED)
            res_dict[True].append(f"AF{i}")

        # 3.1.2.9
        if f'{cel(ws, f"AH{i}")}{cel(ws, f"AI{i}")}' != str(value_temp[key][7]).replace(" ", "").replace("清空", ""):
            cells(ws, f"AH{i}", "企业自定义员工分类3与离退码表库不同！", RED)
            res_dict[True].append(f"AH{i}")

        # 3.1.3	检验多行
        if cel(ws, f"A{i}") == cel(ws, f"A{i-1}"):
            cells(ws, f"A{i}", "该人员信息大于等于两行，请核对该人员信息！", RED)
            res_dict[True].append(f"A{i}")

        # 3.1.4	检验时间
        for x, y in {"C": "D", "L": "M", "AP": "AQ"}.items():
            if cel(ws, f"{x}{i}").replace(".", "") != value_temp[key][0]:
                cells(ws, f"{x}{i}", "开始日期与事件执行日期不同！", RED)
                res_dict[True].append(f"{x}{i}")
            elif cel(ws, f"{y}{i}").replace(".", "") != "99991231":
                cells(ws, f"{y}{i}", "结束日期有误！", RED)
                res_dict[True].append(f"{y}{i}")

        # 3.1.5	检验成本中心
        if not (cel(ws, f"BP{i}") or cel(ws, f"BQ{i}") or cel(ws, f"BR{i}") or cel(ws, f"BS{i}")):
            cells(ws, f"BP{i}", "机构和岗位的财务科目设置及PA30成本分配的成本中心全部为空", RED)
            res_dict[key].append(f"BP{i}")

        # 检查模板中是否有错误信息
        if "错误" in value_temp[key][8]:
            res_dict["错误"].append("模板P列")
    wb_103.save(FILE_PATH + "/C22_内退.xlsx")
    res, flag = ("失败", False) if "错误" in res_dict.keys() else ("成功", True)
    dir_path = get_rpa_dir('内退', os.path.basename(s_file), flag)
    with MYFTP() as my_ftp:
        remote = remote_nt + f"{res}/{os.path.basename(s_file)[:-5]}/"
        ds = {s_file: (f"{dir_path}/{os.path.basename(s_file)}", remote + os.path.basename(s_file)),
              f"{FILE_PATH}/C22_内退.xlsx": (f"{dir_path}/事后_103.xlsx", f"{remote}事后_103.xlsx"),
              f"{FILE_PATH}/事前_103.xlsx": (f"{dir_path}/事前备份_103.xlsx", f"{remote}事前备份_103.xlsx"),
              f"{FILE_PATH}/模板_1072.xlsx": (f"{dir_path}/事后_1072.xlsx", f"{remote}事后_1072.xlsx"),
              f"{FILE_PATH}/事前_1072.xlsx": (f"{dir_path}/事前备份_1072.xlsx", f"{remote}事前备份_1072.xlsx")}
        for x, (y, z) in ds.items():
            if os.path.exists(x):
                shutil.copyfile(x, y)
            if os.path.exists(y):
                my_ftp.upload_file(y, z)
    update_database(s_file, "执行结束")


def upload_ftp(filename):
    dir_path = get_rpa_dir('内退', os.path.basename(filename), False)
    with MYFTP() as my_ftp:
        hhmmss = datetime.datetime.now().strftime(r'%H%M%S')  # 上传的目录前面加时分秒前缀，避免同一天一个单子，第二次做覆盖上一次的文件
        remote = f'{remote_nt}失败/{hhmmss}_{os.path.basename(filename)[:-5]}/'
        ds = {filename: (f"{dir_path}/{os.path.basename(filename)}", f"{remote}{os.path.basename(filename)}"),
              f"{filename}/事前_103.xlsx": (f"{dir_path}/事前_103.xlsx", f"{remote}事前_103.xlsx"),
              f"{filename}/事前_1072.xlsx": (f"{dir_path}/事前_1072.xlsx", f"{remote}事前_1072.xlsx")}
        for x, (y, z) in ds.items():
            if os.path.exists(x):
                shutil.copyfile(x, y)
            if os.path.exists(y):
                my_ftp.upload_file(y, z)


def run_nei_tui(filename):
    file = to_windows_path_format(filename)
    update_db(file, "开始执行")
    # 模板批导前校验
    clear_all_colour_and_comment(file, "内退事件批导", remote_nt)
    check_zhrpy280(file)
    nei_tui_pre_check(file)
    if send_email(file):
        upload_ftp(file)
        return
    # 模板批导
    nei_tui_operate(filename)
    nei_tui_post_check(filename)
