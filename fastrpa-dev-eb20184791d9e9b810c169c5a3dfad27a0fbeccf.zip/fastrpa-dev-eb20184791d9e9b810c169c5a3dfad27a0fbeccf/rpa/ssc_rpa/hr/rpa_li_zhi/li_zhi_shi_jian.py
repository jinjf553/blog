#!/usr/bin/env python
# -*- coding: utf-8 -*-
# @Date    : 2019-04-08 21:45:47

import logging
import os
import re
import shutil
import time
from collections import defaultdict
from datetime import datetime, timedelta

from openpyxl import load_workbook
from openpyxl.worksheet.worksheet import Worksheet
from rpa.fastrpa.adtable import BLUE, RED
from rpa.fastrpa.path import to_windows_path_format
from rpa.fastrpa.sap.session import attach_sap
from rpa.public.config import FILE_PATH, remote_lz
from rpa.public.db import update_db
from rpa.public.event_public import (clear_all_colour_and_comment, send_email,
                                     update_database)
from rpa.public.myftp import MYFTP
from rpa.public.tools import cel, cells
from rpa.ssc.hr.orm.orm import rpa_work_amount
from rpa.ssc.hr.orm.orm_ope import Query
from rpa.ssc.hr.orm.td_hr_li_tui_code_rulebase import LiTui
from rpa.ssc.hr.rpa_dir import get_rpa_dir
from rpa.ssc.hr.sap.export_other_103 import (export_103_li_zhi2,
                                             export_103_li_zhi3)
from rpa.ssc_kit.hr.kit_chai_dan.check_280 import check_zhrpy280


def li_zhi_pre_check(filename):
    logging.info("开始离职事件批导前校验...")
    wb = load_workbook(filename)
    ws = wb.active

    # 1.1.2	校验文件名格式
    li = os.path.basename(filename).split("-")
    if len(li) < 4 or not (li[0].isdigit() or li[0] != "无单号") or len(li[1]) != 4 or li[2] != "离职":
        cells(ws, "A7", "文件名称错误，应为:单号-人事范围代码-离职事件-业务人员姓名或无单号-人事范围代码-离职-业务人员姓名", RED)

    logging.info("提取校验过程中需要使用到的码值...")
    rule_s = [str(res.db_S).strip() for res in Query(LiTui) if res.db_S]  # 岗位变动事件原因
    rule_u_v = {str(res.db_U).strip(): str(res.db_V).strip() for res in Query(LiTui) if res.db_U}  # 匹配人员增减变动信息

    # 1.1.3  通过组合逻辑查询下载离职C23-2、C23-3
    lis = [cel(ws, f"B{x}") for x in range(7, len(ws["A"]) + 1) if cel(ws, f"B{x}")]
    date = [cel(ws, f"D{x}") for x in range(7, len(ws["A"]) + 1) if cel(ws, f"D{x}")][0]
    if not lis:
        logging.info("离职模板中没有离职事件。")
        return
    logging.info("提取校验所需要的离职103数据...")
    export_103_li_zhi2(None, lis, date).save_to(FILE_PATH)

    try:
        time_stamp = time.mktime(time.strptime(date, "%Y%m%d"))
        yesterday = time.strftime("%Y%m%d", time.localtime(int(time_stamp) - 24 * 60 * 60))
    except Exception:
        yesterday = date
    export_103_li_zhi3("reuse", lis, yesterday).save_to(FILE_PATH)

    wb_103 = load_workbook(FILE_PATH + "/C23-2离职.xlsx")
    ws_103 = wb_103.active
    values_103 = defaultdict(list)
    for i in range(2, len(ws_103["A"]) + 1):
        for x in ["C", "D", "F", "L", "M", "O", "AS", "AT", "AV", "BA", "BB", "BD", "BK", "BM", "BO"]:
            ws_103[f"{x}{i}"] = str(ws_103[f"{x}{i}"].value).replace(".", "").replace("00000000", "")
        for col in ["P", "S", "K", "G", "AT", "BB", "BO", "BK", "BM", "R"]:
            values_103[cel(ws_103, f"A{i}").lstrip('0')].append(cel(ws_103, f"{col}{i}"))
    wb_103.save(FILE_PATH + "/事前-C23-2离职.xlsx")

    wb_103 = load_workbook(FILE_PATH + "/C23-3劳动合同.xlsx")
    ws_103 = wb_103.active
    values_103_1 = defaultdict(list)
    for i in range(2, len(ws_103["A"]) + 1):
        for x in ["D", "E", "G", "P"]:
            ws_103[f"{x}{i}"] = str(ws_103[f"{x}{i}"].value).replace(".", "").replace("00000000", "")
        for col in ["D", "E", "Z"]:
            values_103_1[cel(ws_103, f"A{i}").lstrip('0')].append(cel(ws_103, f"{col}{i}"))
    wb_103.save(FILE_PATH + "/事前-C23-3劳动合同.xlsx")

    now = datetime.now()
    next_month = datetime(*(now.year, now.month + 1) if now.month + 1 < 13 else (now.year + 1, 1), 1, 0, 0, 0)
    last_month = datetime(*(now.year, now.month - 1) if now.month - 1 > 0 else (now.year - 1, 12), 1, 0, 0, 0)
    cur_month = datetime(now.year, now.month, 1, 0, 0, 0)
    las, cur, nex = last_month.strftime("%Y%m%d"), cur_month.strftime("%Y%m%d"), next_month.strftime("%Y%m%d")
    month_last = next_month - timedelta(days=1)
    up_last = cur_month - timedelta(days=1)

    for i in range(7, len(ws["A"]) + 1):
        # 1.2.1  校验人员编号
        logging.info(f"开始校验离职模板第{i - 6}行数据...")
        ws[f"B{i}"] = key = "".join(re.findall(r"\d", str(ws[f"B{i}"].value))).lstrip("0")
        if len(cel(ws, f"B{i}")) > 8:
            cells(ws, f"B{i}", "人员编号有误", RED)

        # 1.2.3	 校验开始日期
        if cel(ws, f"D{i}") not in [cur_month.strftime("%Y%m%d"), next_month.strftime("%Y%m%d")]:
            if cel(ws, f"D{i}") in [month_last.strftime("%Y%m%d"), up_last.strftime("%Y%m%d")]:
                cells(ws, f"D{i}", "事件执行日期为月末，请核对！", BLUE)
            else:
                cells(ws, f"D{i}", "事件执行日期有误！", RED)

        # 1.2.4	检验离职原因
        if cel(ws, f"E{i}") not in rule_s:
            cells(ws, f"F{i}", "离职原因非码值！", RED)

        if cel(ws, f"AC{i}"):
            try:
                _ = time.strptime(cel(ws, f"AC{i}"), "%Y%m%d")
                tmp_li = [last_month.strftime("%Y%m"), cur_month.strftime("%Y%m"), next_month.strftime("%Y%m")]
                # 1.2.5	校验企业填写的合同解除日期逻辑性
                if cel(ws, f"D{i}")[:-2] in tmp_li:
                    if cel(ws, f"D{i}")[-2:] == "01" and int(cel(ws, f"AC{i}")) >= int(cel(ws, f"D{i}")):
                        cells(ws, f"AC{i}", "企业填写的劳动合同解除日期在事件执行日期之后！", RED)
                    if cel(ws, f"D{i}")[-2:] != "01" and int(cel(ws, f"AC{i}")) > int(cel(ws, f"D{i}")):
                        cells(ws, f"AC{i}", "企业填写的劳动合同解除日期在事件执行日期之后！", RED)
                # 1.2.6	校验企业填写的合同解除日期逻辑性
                if cel(ws, f"F{i}").isdigit() and int(cel(ws, f"F{i}")) >= int(cel(ws, f"AC{i}")):
                    cells(ws, f"AC{i}", "企业填写的劳动合同解除日期早于或等于合同开始日期！", RED)
            except Exception:
                cells(ws, f"AC{i}", "企业填写的劳动合同解除日期有误！", RED)

        # 1.2.7	检验停薪日期
        if key in values_103.keys() and values_103[key][0] in ["X480", "X48Z", "X481"]:
            try:
                _ = time.strptime(cel(ws, f"AA{i}"), "%Y%m%d")
                if int(cel(ws, f"AA{i}")) < int(last_month.strftime("%Y%m%d")) or cel(ws, f"AA{i}")[-2:] != "01":
                    cells(ws, f"AA{i}", "停薪日期有误!", RED)
            except Exception:  # nosec
                pass

        # 1.3.1	补充解除/终止类型
        ws[f"H{i}"] = ""
        if cel(ws, f"E{i}") in ["10 终止劳动合同", "K0 死亡"]:
            ws[f"H{i}"] = "3 合同终止"
        else:
            ws[f"H{i}"] = "4 合同解除"

        # 1.3.2	补充解除/终止原因
        ws[f"I{i}"] = ""
        if key in values_103.keys() and values_103[key][0] not in ["X480", "X48Z", "X481"]:
            ws[f"I{i}"] = cel(ws, f"E{i}").split()[-1]

        # 1.3.3	劳动合同确认
        ws[f"F{i}"], ws[f"S{i}"], ws[f"T{i}"] = "", "", ""
        if key in values_103_1.keys():
            if len(values_103_1[key]) == 3 and not values_103_1[key][1]:
                cells(ws, f"T{i}", "不存在需要定界的劳动合同！", BLUE)
            else:
                ws[f"F{i}"], ws[f"T{i}"] = values_103_1[key][:2]
                try:
                    tmp_ls = values_103_1[key]
                    for x in range(0, len(tmp_ls), 3):
                        if tmp_ls[x] and int(cel(ws, f"D{i}")) <= int(tmp_ls[x]):
                            cells(ws, f"S{i}", "该人存在未来时间的劳动合同，请与企业确认如何处理！", RED)
                except Exception:
                    cells(ws, f"S{i}", "D列减册日期非正确值", RED)

        # 1.3.4	校验人员组
        if key in values_103.keys() and values_103[key][1] in ["C", "N", "S", "K"]:
            cells(ws, f"B{i}", "人员组不能为C类、N类、S类、K类！", RED)

        # 1.3.5	校验雇佣状态
        if key in values_103.keys() and values_103[key][2] in ["不在册不在岗", "不在岗"]:
            cells(ws, f"C{i}", "雇佣状态不能为“不在册不在岗”或“退休”！", RED)

        # 1.3.6	校验当月是否已有事件
        if key in values_103.keys() and values_103[key][3].replace("暂停/恢复发薪", ""):
            cells(ws, f"A{i}", "当月已有事件！", RED)

        # 1.3.7	生成合同解除/终止日期
        ws[f"G{i}"] = ""
        if ws[f"T{i}"].comment is None:
            ws[f"G{i}"] = cel(ws, f"AC{i}")
            if not cel(ws, f"AC{i}"):
                if cel(ws, f"D{i}") in [las, cur, nex]:
                    ws[f"G{i}"] = (datetime.strptime(cel(ws, f"D{i}"), "%Y%m%d") - timedelta(days=1)).strftime("%Y%m%d")
                elif cel(ws, f"D{i}").isdigit() and int(las) < int(cel(ws, f"D{i}")) <= int(nex[:-2] + "31"):
                    ws[f"G{i}"] = cel(ws, f"D{i}")
                else:
                    cells(ws, f"G{i}", "离职RPA只执行上月、当月、次月的事件！", RED)
        # 事件执行日期上月的最后一天
        if cel(ws, f"D{i}").isdigit() and len(cel(ws, f"D{i}")) == 8:
            d_date = (datetime.strptime(cel(ws, f"D{i}")[:-2] + "01", "%Y%m%d") - timedelta(1)).strftime("%Y%m%d")
        else:
            d_date = ""
        # 1.5.1	生成其他用工信息定界日期
        ws[f"Y{i}"] = ""
        if key in values_103.keys() and values_103[key][4]:
            ws[f"Y{i}"] = d_date

        # 1.5.2	生成增减变动定界日期
        ws[f"AD{i}"] = ""
        if key in values_103.keys() and values_103[key][5]:
            ws[f"AD{i}"] = d_date

        # 1.5.3	生成博士后研究人员定界日期
        ws[f"Z{i}"] = ""
        if key in values_103.keys() and values_103[key][6]:
            ws[f"Z{i}"] = d_date

        # 1.5.4	生成行政党派主次职务定界日期
        ws[f"W{i}"] = ""
        if key in values_103.keys() and values_103[key][7]:
            ws[f"W{i}"] = d_date

        # 1.5.5	生成行政党派兼任职务定界日期
        ws[f"X{i}"] = ""
        if key in values_103.keys() and values_103[key][8]:
            ws[f"X{i}"] = d_date

        ws[f"U{i}"] = ""
        if cel(ws, f"E{i}") in rule_u_v.keys():
            ws[f"U{i}"] = rule_u_v[cel(ws, f"E{i}")]
        else:
            ws[f"U{i}"] = "29000 其他减员"

        ws[f"AF{i}"] = ""
        if key in values_103.keys() and values_103[key][0] in ["X480", "X48Z", "S481"]:
            ws[f"AF{i}"] = values_103[key][0]

    logging.info("离职模板执行事件前校验完成...")
    wb.save(filename)


# 执行离职事件操作
def li_zhi_operate(r_file):
    logging.info(f"开始执行离职事件{r_file}")
    session = attach_sap("login_tx")
    wb = load_workbook(r_file)
    ws = wb.active
    for rn in range(7, len(ws["A"]) + 1):
        logging.info(f"正在执行离职事件第{rn-6}条数据...")
        ws[f"P{rn}"], ws[f"Q{rn}"] = "", ""
        try:
            def tmp_enter(sess, strings):
                try:
                    sess.findById("wnd[1]").sendVKey(0)
                except Exception:  # nosec
                    pass
                for _ in range(5):
                    text = session.findById("wnd[0]/sbar").text
                    if "请保存" not in text:
                        session.findById("wnd[0]").sendVKey(0)
                    else:
                        return
                else:
                    logging.info(strings + str(session.findById("wnd[0]/sbar").text))
                    strings = strings + str(session.findById("wnd[0]/sbar").text)
                    return strings if strings else "出现错误"
            #  人事调配事件
            session.findById("wnd[0]/tbar[0]/okcd").text = "/n ZPA40_11"
            session.findById("wnd[0]").sendVKey(0)
            session.findById("wnd[0]/usr/ctxtRP50G-PERNR").text = cel(ws, f"B{rn}")
            session.findById("wnd[0]/usr/ctxtRP50G-EINDA").text = cel(ws, f"D{rn}")
            session.findById("wnd[0]/usr/tblSAPMP50ATC_MENU_EVENT").getAbsoluteRow(0).selected = -1
            session.findById("wnd[0]/tbar[1]/btn[8]").press()
            session.findById("wnd[0]/usr/ctxtP0000-BEGDA").text = cel(ws, f"D{rn}")
            session.findById("wnd[0]/usr/ctxtP0000-MASSG").text = cel(ws, f"E{rn}")[:2]
            session.findById("wnd[0]/usr/ctxtPSPAR-PERSG").text = "N"
            session.findById("wnd[0]/usr/ctxtPSPAR-PERSK").text = "71"
            string = tmp_enter(session, "")
            if string:
                ws[f"P{rn}"] = "人事调配屏错误！"
                ws[f"Q{rn}"] = string
                wb.save(r_file)
                logging.info(f"    人事调配屏错误，SAP返回信息：{string}")
                continue
            session.findById("wnd[0]/tbar[0]/btn[11]").press()
            session.findById("wnd[0]").sendVKey(0)
            #  组织分配屏
            if not (cel(ws, f"AF{rn}") in ["X480", "X48Z", "S481"] and cel(ws, f"AA{rn}")):
                session.findById("wnd[0]/usr/ctxtP0001-ABKRS").text = "00"  #
                sap_id = "wnd[0]/usr/subSUBSCREEN_T582C:ZP000100:0200/ctxtP0001-ZZ_ZEFW"  #
                try:
                    session.findById(sap_id).text = ""
                except Exception:  # nosec
                    pass
            string = tmp_enter(session, "")
            if string:
                ws[f"P{rn}"] = "组织分配屏错误！"
                ws[f"Q{rn}"] = string
                wb.save(r_file)
                logging.info(f"    组织分配屏错误，SAP返回信息：{string}")
                continue
            session.findById("wnd[0]/tbar[0]/btn[11]").press()
            session.findById("wnd[0]").sendVKey(0)
            li_zhi_pa30(session, ws, rn)
        except Exception as e:
            string = session.findById("wnd[0]/sbar").text
            ws[f"P{rn}"] = "未知错误！"
            ws[f"Q{rn}"] = string if string else f"未知异常:{e}"
        wb.save(r_file)


def li_zhi_pa30(sap_session, ws: Worksheet, rn: int):
    def enter_pa30(session, value, date, col, row):
        session.findById("wnd[0]/tbar[0]/okcd").text = '/n pa30'
        session.findById("wnd[0]").sendVKey(0)
        session.findById("wnd[0]/usr/ctxtRP50G-PERNR").text = value  # 人员编号
        session.findById("wnd[0]").sendVKey(0)
        session.findById(f"wnd[0]/usr/tabsMENU_TABSTRIP/tabpTAB0{col}").select()
        session.findById(
            f"wnd[0]/usr/tabsMENU_TABSTRIP/tabpTAB0{col}/ssubSUBSCR_MENU:SAPMP50A:0400/subSUBSCR_ITMENU:SAPMP50A:0310/tblSAPMP50ATC_MENU").verticalScrollbar.position = row
        text = session.findById(
            f"wnd[0]/usr/tabsMENU_TABSTRIP/tabpTAB0{col}/ssubSUBSCR_MENU:SAPMP50A:0400/subSUBSCR_ITMENU:SAPMP50A:0310/tblSAPMP50ATC_MENU/lblINF_EX[1,0]").toolTip
        session.findById(
            f"wnd[0]/usr/tabsMENU_TABSTRIP/tabpTAB0{col}/ssubSUBSCR_MENU:SAPMP50A:0400/subSUBSCR_ITMENU:SAPMP50A:0310/tblSAPMP50ATC_MENU").getAbsoluteRow(
            row).selected = -1
        button = "6" if text == "存在" else "5"
        session.findById(
            "wnd[0]/usr/tabsMENU_TABSTRIP/tabpTAB03/ssubSUBSCR_MENU:SAPMP50A:0400/subSUBSCR_TIME:SAPMP50A:0330/ctxtRP50G-BEGDA").text = date  # 开始日期
        session.findById(
            "wnd[0]/usr/tabsMENU_TABSTRIP/tabpTAB03/ssubSUBSCR_MENU:SAPMP50A:0400/subSUBSCR_TIME:SAPMP50A:0330/ctxtRP50G-ENDDA").text = "99991231"
        return button
    try:
        # 2.1.4	人员增减变动信息屏
        enter_pa30(sap_session, cel(ws, f"B{rn}"), cel(ws, f"D{rn}"), 3, 7)
        sap_session.findById("wnd[0]/tbar[1]/btn[5]").press()  # 点击[新建]按钮
        sap_session.findById("wnd[0]/usr/ctxtP9253-ZZ_ZJLB").text = cel(ws, f"U{rn}")[:5]  # 增减类别
        t = sap_session.findById("wnd[0]/usr/subSUBSCREEN_HEADER:/1PAPAXX/HDR_80001A:0100/txt$_DG07_800A01_DTX_P0001_BTRTL").text
        sap_session.findById("wnd[0]/usr/txtP9253-ZZ_DRCBM").text = t[:12]  # wnd[0]/usr/txtP9253-ZZ_DRCBM
        sap_session.findById("wnd[0]").sendVKey(0)
        sap_session.findById("wnd[0]").sendVKey(0)
        sap_session.findById("wnd[0]/tbar[0]/btn[11]").press()  # 保存
    except Exception:
        ws[f"P{rn}"] = f"{cel(ws, f'P{rn}')}人员增减变动信息屏错误; "
        ws[f"Q{rn}"] = cel(ws, f"Q{rn}") + f"; 人员增减变动信息屏错误,SAP报错：【{sap_session.findById('wnd[0]/sbar').text}】"
        logging.info(f"    人员增减变动信息屏错误,SAP报错：【{sap_session.findById('wnd[0]/sbar').text}】")

    try:
        # 2.1.5	组织分配屏
        if cel(ws, f"AF{rn}") in ["X480", "X48Z", "S481"] and cel(ws, f"AA{rn}"):
            enter_pa30(sap_session, cel(ws, f"B{rn}"), cel(ws, f"D{rn}"), 3, 0)
            sap_session.findById("wnd[0]/tbar[1]/btn[5]").press()
            sap_session.findById("wnd[0]/usr/ctxtP0001-BEGDA").text = cel(ws, f"AA{rn}")
            sap_session.findById("wnd[0]/usr/ctxtP0001-ENDDA").text = "99991231"
            sap_session.findById("wnd[0]/usr/ctxtP0001-ABKRS").text = "00"
            sap_id = "wnd[0]/usr/subSUBSCREEN_T582C:ZP000100:0200/ctxtP0001-ZZ_ZEFW"
            try:
                sap_session.findById(sap_id).text = ""
            except Exception:  # nosec
                pass
            sap_session.findById("wnd[0]").sendVKey(0)
            sap_session.findById("wnd[0]").sendVKey(0)
            sap_session.findById("wnd[0]/tbar[0]/btn[11]").press()
    except Exception:
        ws[f"P{rn}"] = f"{cel(ws, f'P{rn}')}组织分配及岗位聘任屏错误; "
        ws[f"Q{rn}"] = cel(ws, f"Q{rn}") + f"; 组织分配及岗位聘任屏错误,SAP报错：【{sap_session.findById('wnd[0]/sbar').text}】"
        logging.info(f"    组织分配及岗位聘任屏错误,SAP报错：【{sap_session.findById('wnd[0]/sbar').text}】")

    try:
        # 2.1.6	生成合同解除/终止日期
        if "rgb='000000FF'" not in str(ws[f"T{rn}"].fill):
            btn = enter_pa30(sap_session, cel(ws, f"B{rn}"), cel(ws, f"D{rn}"), 3, 3)
            sap_session.findById(f"wnd[0]/tbar[1]/btn[{btn}]").press()
            if cel(ws, f"G{rn}"):
                sap_session.findById("wnd[0]/usr/ctxtP9299-ENDDA").text = cel(ws, f"G{rn}")
                sap_session.findById("wnd[0]/usr/cmbP9299-ZZ_HTBS").key = cel(ws, f"H{rn}")[:1]
                sap_session.findById("wnd[0]/usr/ctxtP9299-ZZ_HTJSRQ").text = cel(ws, f"T{rn}")
            if cel(ws, f"AF{rn}") in ["X480", "X48Z", "S481"]:
                sap_session.findById("wnd[0]/usr/txtP9299-ZZ_JCHBGYY").text = cel(ws, f"AB{rn}")
            else:
                sap_session.findById("wnd[0]/usr/txtP9299-ZZ_JCHBGYY").text = cel(ws, f"E{rn}").split()[-1]
            if cel(ws, f"K{rn}"):
                sap_session.findById("wnd[0]/usr/txtP9299-ZZ_DWBCJ").text = cel(ws, f"K{rn}")
            sap_session.findById("wnd[0]").sendVKey(0)
            sap_session.findById("wnd[0]").sendVKey(0)
            sap_session.findById("wnd[0]/tbar[0]/btn[11]").press()
    except Exception:
        ws[f"P{rn}"] = f"{cel(ws, f'P{rn}')}劳动合同屏错误; "
        ws[f"Q{rn}"] = cel(ws, f"Q{rn}") + f"; 劳动合同屏错误,SAP报错：【{sap_session.findById('wnd[0]/sbar').text}】"
        logging.info(f"    劳动合同屏错误,SAP报错：【{sap_session.findById('wnd[0]/sbar').text}】")

    try:
        # 2.1.7	生成其他用工信息定界日期
        if cel(ws, f"Y{rn}"):
            btn = enter_pa30(sap_session, cel(ws, f"B{rn}"), cel(ws, f"D{rn}"), 2, 0)
            sap_session.findById(f"wnd[0]/tbar[1]/btn[{btn}]").press()
            sap_session.findById("wnd[0]/usr/ctxtP9241-ENDDA").text = cel(ws, f"Y{rn}")
            sap_session.findById("wnd[0]").sendVKey(0)
            sap_session.findById("wnd[0]").sendVKey(0)
            sap_session.findById("wnd[0]/tbar[0]/btn[11]").press()
    except Exception:
        ws[f"P{rn}"] = f"{cel(ws, f'P{rn}')}其他用工信息屏错误; "
        ws[f"Q{rn}"] = cel(ws, f"Q{rn}") + f"; 其他用工信息屏错误,SAP报错：【{sap_session.findById('wnd[0]/sbar').text}】"
        logging.info(f"    其他用工信息屏错误,SAP报错：【{sap_session.findById('wnd[0]/sbar').text}】")

    try:
        # 2.1.8	生成人员增减变动信息定界日期
        if cel(ws, f"AD{rn}"):
            enter_pa30(sap_session, cel(ws, f"B{rn}"), cel(ws, f"D{rn}"), 3, 7)
            sap_session.findById("wnd[0]/tbar[1]/btn[20]").press()
            d_date = datetime.strptime(cel(ws, f"D{rn}"), "%Y%m%d")
            for x in range(20):  # 循环遍历列表项
                try:
                    s_date = sap_session.findById(f"wnd[0]/usr/tblMP925300TC3000/txtP9253-BEGDA[0,{x}]").text  # 开始日期
                    s_date = datetime.strptime(s_date, "%Y.%m.%d")
                except Exception:
                    break
                e_date = sap_session.findById(f"wnd[0]/usr/tblMP925300TC3000/txtP9253-ENDDA[1,{x}]").text  # 结束日期
                if s_date < d_date and e_date == "9999.12.31":
                    sap_session.findById("wnd[0]/usr/tblMP925300TC3000").getAbsoluteRow(x).selected = -1
                    sap_session.findById("wnd[0]/tbar[1]/btn[6]").press()
                    sap_session.findById("wnd[0]/usr/ctxtP9253-ENDDA").text = cel(ws, f"AD{rn}")
                    sap_session.findById("wnd[0]").sendVKey(0)
                    sap_session.findById("wnd[0]/tbar[0]/btn[11]").press()
    except Exception:
        ws[f"P{rn}"] = f"{cel(ws, f'P{rn}')}优化配置与人员增减信息屏错误; "
        ws[f"Q{rn}"] = cel(ws, f"Q{rn}") + f"; 优化配置与人员增减信息屏错误,SAP报错：【{sap_session.findById('wnd[0]/sbar').text}】"
        logging.info(f"    优化配置与人员增减信息屏错误,SAP报错：【{sap_session.findById('wnd[0]/sbar').text}】")

    try:
        # 2.1.9	生成博士后研究人员定界日期
        if cel(ws, f"Z{rn}"):
            enter_pa30(sap_session, cel(ws, f"B{rn}"), cel(ws, f"D{rn}"), 2, 2)
            sap_session.findById("wnd[0]/tbar[1]/btn[20]").press()
            for x in range(20):
                try:
                    e_date = sap_session.findById(f"wnd[0]/usr/tblMP923900TC3000/txtP9239-ENDDA[1,{x}]").text
                except Exception:
                    break
                if e_date == "9999.12.31":
                    sap_session.findById("wnd[0]/usr/tblMP923900TC3000").getAbsoluteRow(x).selected = -1
                    sap_session.findById("wnd[0]/tbar[1]/btn[6]").press()
                    sap_session.findById("wnd[0]/usr/ctxtP9239-ENDDA").text = cel(ws, f"Z{rn}")
                    sap_session.findById("wnd[0]").sendVKey(0)
                    sap_session.findById("wnd[0]/tbar[0]/btn[11]").press()
    except Exception:
        ws[f"P{rn}"] = f"{cel(ws, f'P{rn}')}博士后研究人员屏错误; "
        ws[f"Q{rn}"] = cel(ws, f"Q{rn}") + f"; 博士后研究人员屏错误,SAP报错：【{sap_session.findById('wnd[0]/sbar').text}】"
        logging.info(f"    博士后研究人员屏错误,SAP报错：【{sap_session.findById('wnd[0]/sbar').text}】")

    try:
        # 2.1.10	生成行政党派主次职务定界日期
        if cel(ws, f"W{rn}"):
            enter_pa30(sap_session, cel(ws, f"B{rn}"), cel(ws, f"D{rn}"), 4, 1)  # 4任职情况-1行政党派职务信息
            sap_session.findById("wnd[0]/tbar[1]/btn[20]").press()
            for x in range(20):
                try:
                    e_date = sap_session.findById(f"wnd[0]/usr/tblMP925100TC3000/txtP9251-ENDDA[1,{x}]").text
                except Exception:
                    break
                if e_date == "9999.12.31":  # 20210706 mengzhao 将 != 9999.12.31 调整为等于9999.12.31
                    sap_session.findById("wnd[0]/usr/tblMP925100TC3000").getAbsoluteRow(x).selected = -1
                    sap_session.findById("wnd[0]/tbar[1]/btn[6]").press()
                    sap_session.findById("wnd[0]/usr/ctxtP9251-ENDDA").text = cel(ws, f"W{rn}")
                    sap_session.findById("wnd[0]").sendVKey(0)
                    sap_session.findById("wnd[0]/tbar[0]/btn[11]").press()
    except Exception:
        ws[f"P{rn}"] = f"{cel(ws, f'P{rn}')}行政党派职务信息屏错误; "
        ws[f"Q{rn}"] = cel(ws, f"Q{rn}") + f"; 行政党派职务信息屏错误,SAP报错：【{sap_session.findById('wnd[0]/sbar').text}】"
        logging.info(f"    行政党派职务信息屏错误,SAP报错：【{sap_session.findById('wnd[0]/sbar').text}】")

    try:
        # 2.1.11	生成行政党派兼任职务定界日期
        if cel(ws, f"X{rn}"):
            enter_pa30(sap_session, cel(ws, f"B{rn}"), cel(ws, f"D{rn}"), 4, 2)  # 4任职情况-2兼任职务信息
            sap_session.findById("wnd[0]/tbar[1]/btn[20]").press()
            for x in range(20):
                try:
                    e_date = sap_session.findById(f"wnd[0]/usr/tblMP924200TC3000/txtP9242-ENDDA[1,{x}]").text
                except Exception:
                    break
                if e_date == "9999.12.31":
                    sap_session.findById("wnd[0]/usr/tblMP924200TC3000").getAbsoluteRow(x).selected = -1
                    sap_session.findById("wnd[0]/tbar[1]/btn[6]").press()
                    sap_session.findById("wnd[0]/usr/ctxtP9242-ENDDA").text = cel(ws, f"X{rn}")
                    sap_session.findById("wnd[0]").sendVKey(0)
                    sap_session.findById("wnd[0]/tbar[0]/btn[11]").press()
    except Exception:
        ws[f"P{rn}"] = f"{cel(ws, f'P{rn}')}兼任职务信息屏错误; "
        ws[f"Q{rn}"] = cel(ws, f"Q{rn}") + f"; 兼任职务信息屏错误,SAP报错：【{sap_session.findById('wnd[0]/sbar').text}】"
        logging.info(f"    兼任职务信息屏错误,SAP报错：【{sap_session.findById('wnd[0]/sbar').text}】")


# 离职事件事后校验
def li_zhi_post_check(s_file):
    logging.info("开始离职事件后置校验...")
    wb_temp = load_workbook(s_file)
    ws_temp = wb_temp.active
    res_dict = defaultdict(list)

    # 1.1.3  通过组合逻辑查询下载离职C23-2、C23-3
    lis = [cel(ws_temp, f"B{x}") for x in range(7, len(ws_temp["A"]) + 1) if cel(ws_temp, f"B{x}")]
    rpa_work_amount(lis)
    date = [cel(ws_temp, f"D{x}") for x in range(7, len(ws_temp["A"]) + 1) if cel(ws_temp, f"D{x}")][0]
    _ = [res_dict[True].append(f'模板P{x}') for x in range(7, len(ws_temp["A"]) + 1) if '错误' in cel(ws_temp, f"P{x}")]
    if not lis:
        return
    logging.info("提取校验所需要的离职103数据...")
    if not lis:
        logging.info("人员离退表中没有离职事件。")
        return
    export_103_li_zhi2(None, lis, date).save_to(FILE_PATH)

    try:
        time_stamp = time.mktime(time.strptime(date, "%Y%m%d"))
        yesterday = time.strftime("%Y%m%d", time.localtime(int(time_stamp) - 24 * 60 * 60))
    except Exception:
        yesterday = date
    logging.info("提取校验所需要的离职劳动合同103数据...")
    export_103_li_zhi3("reuse", lis, yesterday).save_to(FILE_PATH)

    wb = load_workbook(FILE_PATH + "/C23-2离职.xlsx")
    ws = wb.active
    for i in range(2, len(ws["A"]) + 1):
        for x in ["C", "D", "F", "L", "M", "O", "AS", "AT", "AV", "BA", "BB", "BD", "BK", "BM", "BO"]:
            ws[f"{x}{i}"] = str(ws[f"{x}{i}"].value).replace(".", "").replace("00000000", "")
    wb.save(FILE_PATH + "/C23-2离职.xlsx")

    wb_103 = load_workbook(FILE_PATH + "/C23-3劳动合同.xlsx")
    ws_103 = wb_103.active
    values_103_1 = defaultdict(list)
    for i in range(2, len(ws_103["A"]) + 1):
        for x in ["D", "E", "G", "P"]:
            ws_103[f"{x}{i}"] = str(ws_103[f"{x}{i}"].value).replace(".", "").replace("00000000", "")
        for col in ["D"]:
            values_103_1[cel(ws_103, f"A{i}").lstrip('0')].append(cel(ws_103, f"{col}{i}"))
    wb_103.save(FILE_PATH + "/C23-3劳动合同.xlsx")

    for i in range(2, len(ws["A"]) + 1):
        logging.info(f"开始校验事后离职103第{i - 1}行数据...")

        # 3.1.2	校验事件是否成功
        if cel(ws, f"G{i}") != "在职人员减册":
            cells(ws, f"G{i}", "离职事件不成功！", RED)
            res_dict[True].append(f"G{i}")

        # 3.1.3	校验事件是否成功
        if cel(ws, f"J{i}") != "离职":
            cells(ws, f"J{i}", "岗位状态有误！", RED)
            res_dict[True].append(f"J{i}")

        # 3.1.4	校验事件是否成功
        if cel(ws, f"K{i}") != "不在册不在岗":
            cells(ws, f"K{i}", "雇佣状态有误！", RED)

        # 3.1.5.1	校验开始日期
        if not (cel(ws, f"C{i}") == cel(ws, f"L{i}") == date):
            cells(ws, f"C{i}", "开始日期与表单不一致！", RED)
            cells(ws, f"L{i}", "开始日期与表单不一致！", RED)
            res_dict[True].append(f"C{i}")
            res_dict[True].append(f"L{i}")

        # 3.1.5.2	校验开始日期
        if not (cel(ws, f"C{i}")[-2:] == cel(ws, f"L{i}")[-2:] == "01"):
            cells(ws, f"C{i}", "开始日期不为1日！", RED)
            cells(ws, f"L{i}", "开始日期不为1日！", RED)
            res_dict[True].append(f"C{i}")
            res_dict[True].append(f"L{i}")

        # 3.1.6	校验工资范围
        if cel(ws, f"P{i}") not in ["X480", "X48Z", "S481"] and cel(ws, f"Z{i}") != "00":
            cells(ws, f"Z{i}", "工资范围不为00！", RED)
            res_dict[True].append(f"Z{i}")
        if cel(ws, f"P{i}") in ["X480", "X48Z", "S481"] and cel(ws, f"A{i}") == cel(ws, f"A{i-1}"):
            if cel(ws, f"L{i}") != cel(ws, f"L{i-1}"):
                if cel(ws, f"Z{i-1}") != "00":
                    cells(ws, f"Z{i-1}", "工资范围不应为00！", RED)
                    res_dict[True].append(f"Z{i-1}")
                if cel(ws, f"Z{i}") != "00":
                    cells(ws, f"Z{i}", "工资范围不为00！", RED)
                    res_dict[True].append(f"Z{i}")
            elif cel(ws, f"Z{i-1}") != "00":
                cells(ws, f"Z{i-1}", "工资范围不为00！", RED)
                res_dict[True].append(f"Z{i-1}")

        # 3.1.7	校验工资总额控制范围
        if cel(ws, f"Z{i}") == "00" and cel(ws, f"AB{i}"):
            cells(ws, f"AB{i}", "工资范围为00，工资总额控制范围应为空！", RED)
            res_dict[True].append(f"AB{i}")
        if cel(ws, f"Z{i}") != "00" and not cel(ws, f"AB{i}"):
            cells(ws, f"AB{i}", "工资范围不为00，工资总额控制范围不应为空！", RED)
            res_dict[True].append(f"AB{i}")

        # 3.1.8	校验事件是否成功
        if cel(ws, f"S{i}") != "N":
            cells(ws, f"S{i}", "人员组有误！", RED)
            res_dict[True].append(f"S{i}")

        # 3.1.9	校验事件是否成功
        if cel(ws, f"T{i}") != "71":
            cells(ws, f"T{i}", "人员子组有误！", RED)
            res_dict[True].append(f"T{i}")

        # 3.1.10	校验事件是否成功
        if cel(ws, f"X{i}") != "99999999":
            cells(ws, f"X{i}", "离职事件失败！", RED)
            res_dict[True].append(f"X{i}")

        # 3.1.11	校验其他用工信息
        if cel(ws, f"AS{i}"):
            cells(ws, f"AS{i}", "其他用工信息未定界！", RED)
            res_dict[True].append(f"AS{i}")

        # 3.1.12	校验行政党派
        if cel(ws, f"BK{i}"):
            cells(ws, f"BK{i}", "行政党派未定界！", RED)
            res_dict[True].append(f"BK{i}")

        # 3.1.13	校验兼任职务
        if cel(ws, f"BM{i}"):
            cells(ws, f"BM{i}", "兼任职务未定界！", RED)
            res_dict[True].append(f"BM{i}")

        # 3.1.14	校验博士后站人员信息
        if cel(ws, f"BO{i}"):
            cells(ws, f"BO{i}", "博士后站人员信息未定界！", RED)
            res_dict[True].append(f"BO{i}")

        # 3.1.15	校验劳动合同
        if cel(ws, f"A{i}") in values_103_1.keys() and len(values_103_1[cel(ws, f"A{i}")]) == 1:
            if values_103_1[cel(ws, f"A{i}")][0]:
                cells(ws, f"A{i}", "劳动合同未定界！", RED)
                res_dict[True].append(f"A{i}")
    wb.save(FILE_PATH + "/C23-2离职.xlsx")

    res, flag = ("失败", False) if True in res_dict.keys() else ("成功", True)
    dir_path = get_rpa_dir('在职减册', os.path.basename(s_file), flag)
    with MYFTP() as my_ftp:
        remote = remote_lz + f"{res}/{os.path.basename(s_file)[:-5]}/"
        ds = {s_file: (f"{dir_path}/{os.path.basename(s_file)}", remote + os.path.basename(s_file)),
              f"{FILE_PATH}/C23-2离职.xlsx": (f"{dir_path}/事后-C23-2离职.xlsx", f"{remote}事后-C23-2离职.xlsx"),
              f"{FILE_PATH}/C23-3劳动合同.xlsx": (f"{dir_path}/事后-C23-3劳动合同.xlsx", f"{remote}事后-C23-3劳动合同.xlsx"),
              f"{FILE_PATH}/事前-C23-2离职.xlsx": (f"{dir_path}/事前-C23-2离职.xlsx", f"{remote}事前-C23-2离职.xlsx"),
              f"{FILE_PATH}/事前-C23-3劳动合同.xlsx": (f"{dir_path}/事前-C23-3劳动合同.xlsx", f"{remote}事前-C23-3劳动合同.xlsx")}
        for x, (y, z) in ds.items():
            if os.path.exists(x):
                shutil.copyfile(x, y)
            if os.path.exists(y):
                my_ftp.upload_file(y, z)
    update_database(s_file, "执行结束")


def upload_ftp(filename):
    dir_path = get_rpa_dir('在职减册', os.path.basename(filename), False)
    with MYFTP() as my_ftp:
        hhmmss = datetime.datetime.now().strftime(r'%H%M%S')  # 上传的目录前面加时分秒前缀，避免同一天一个单子，第二次做覆盖上一次的文件
        remote = f'{remote_lz}失败/{hhmmss}_{os.path.basename(filename)[:-5]}/'
        ds = {filename: (f"{dir_path}/{os.path.basename(filename)}", remote + os.path.basename(filename)),
              f"{FILE_PATH}/事前-C23-2离职.xlsx": (f"{dir_path}/事前-C23-2离职.xlsx", f"{remote}事前-C23-2离职.xlsx"),
              f"{FILE_PATH}/事前-C23-3劳动合同.xlsx": (f"{dir_path}/事前-C23-3劳动合同.xlsx", f"{remote}事前-C23-3劳动合同.xlsx")}
        for x, (y, z) in ds.items():
            if os.path.exists(x):
                shutil.copyfile(x, y)
            if os.path.exists(y):
                my_ftp.upload_file(y, z)


def run_li_zhi(filename):
    file = to_windows_path_format(filename)
    update_db(file, "开始执行")
    # 模板批导前校验
    clear_all_colour_and_comment(file, "离职事件模板表", remote_lz)
    check_zhrpy280(file)
    li_zhi_pre_check(file)
    if send_email(file):
        upload_ftp(file)
        return
    # 模板批导
    li_zhi_operate(filename)
    li_zhi_post_check(filename)


if __name__ == '__main__':
    from rpa.fastrpa.log import config
    import rpa.config
    config('离职.log')
    rpa.config.SAP_FUNJ = 'FUNJ0179'
    rpa.config.FSO_USERNAME = 'guoy926'  # 业务人员FSO账号写入全局配置里
    rpa.config.STAFF_GROUP = 'RPA团队'
    rpa.config.STAFF_ID = 49
    rpa.config.STAFF_TYPE = '组员'
    rpa.config.STAFF_NAME = '郭运'
    li_zhi_operate(r"x:\mengzhao\Desktop\0000000000-X420-离职-郭运.xlsx")
