#!/usr/bin/env python
# -*- coding: utf-8 -*-
# @File    : nei_tui_shi_jian.py
# @Author  : jinjianfeng
import logging
import os
import re
import shutil
import time
import traceback
from collections import defaultdict
from datetime import datetime
from threading import Thread

from openpyxl import load_workbook
from rpa.fastrpa.adtable import RED
from rpa.fastrpa.mail import sendmail
from rpa.fastrpa.path import to_windows_path_format
from rpa.fastrpa.sap.session import attach_sap
from rpa.public.config import FILE_PATH, remote_ltx
from rpa.public.db import update_db
from rpa.public.event_public import (clear_all_colour_and_comment, send_email,
                                     update_database)
from rpa.public.myftp import MYFTP
from rpa.public.tools import cel, cells, find_window
from rpa.ssc.hr.orm.orm import rpa_work_amount
from rpa.ssc.hr.orm.orm_ope import Query
from rpa.ssc.hr.orm.td_hr_li_tui_code_rulebase import LiTui
from rpa.ssc.hr.rpa_dir import get_rpa_dir
from rpa.ssc.hr.sap.export_other_103 import export_103_li_tui_xiu_jian_ce
from rpa.ssc_kit.hr.kit_chai_dan.check_280 import check_zhrpy280


def li_tui_xiu_jian_ce_pre_check(filename):
    logging.info("开始离退休减册事件批导前校验...")
    wb = load_workbook(filename)
    ws = wb.active

    # 1.1.2	校验文件名格式
    li = os.path.basename(filename).split("-")
    if len(li) < 4 or not (li[0].isdigit() or li[0] != "无单号") or len(li[1]) != 4 or li[2] != "离退休减册":
        cells(ws, "A7", "文件名称错误，应为:单号-人事范围代码-离退休减册-业务人员姓名或无单号-人事范围代码-离退休减册-业务人员姓名", RED)

    logging.info("提取校验过程中需要使用到的码值...")
    rule_R = [str(res.db_R).strip() for res in Query(LiTui) if res.db_R]  # 离退休减册事件原因
    rule_W = [str(res.db_W).strip() for res in Query(LiTui) if res.db_W]  # 离退休类别
    rule_X = [str(res.db_X).strip() for res in Query(LiTui) if res.db_X]  # 待遇级别
    rule_Y = [str(res.db_Y).strip() for res in Query(LiTui) if res.db_Y]  # 离退休人员来源

    # 1.1.3	通过组合逻辑查询下载离退休减册C21
    lis = [cel(ws, f"B{x}") for x in range(7, len(ws["A"]) + 1) if cel(ws, f"B{x}")]  # 人员编号
    date = [cel(ws, f"D{x}") for x in range(7, len(ws["A"]) + 1) if cel(ws, f"D{x}")][0]  # 事件日期
    if not lis:
        logging.info("内退模板中没有离退休减册事件。")
        return
    logging.info("提取校验所需要的离退休减册103数据...")
    export_103_li_tui_xiu_jian_ce("reuse", lis, date).save_to(FILE_PATH)
    shutil.copyfile(f"{FILE_PATH}/C21_离退休减册.xlsx", f"{FILE_PATH}/事前_C21_103.xlsx")
    wb_103 = load_workbook(FILE_PATH + "/C21_离退休减册.xlsx")
    ws_103 = wb_103.active
    values_103 = defaultdict(list)
    for i in range(2, len(ws_103["A"]) + 1):
        for col in ["U", "V", "J", "K", "G"]:
            values_103[cel(ws_103, f"A{i}").lstrip('0')].append(cel(ws_103, f"{col}{i}"))

    now = datetime.now()
    next_month = datetime(*(now.year, now.month + 1) if now.month + 1 < 13 else (now.year + 1, 1), 1, 0, 0, 0)
    cur_month = datetime(now.year, now.month, 1, 0, 0, 0)

    for i in range(7, len(ws["A"]) + 1):
        # 1.2.1	校验人员编号
        logging.info(f"开始校验离退休减册模板第{i - 6}行数据...")
        ws[f"B{i}"] = key = "".join(re.findall(r"\d", str(ws[f"B{i}"].value))).lstrip("0")
        if not cel(ws, f"B{i}") or len(cel(ws, f"B{i}")) > 8:
            cells(ws, f"B{i}", "人员编号有误", RED)
        if key not in values_103.keys():
            cells(ws, f"B{i}", "103中没有该人员编号", RED)
            continue

        # 1.2.3	校验开始日期
        if cel(ws, f"D{i}") not in [cur_month.strftime("%Y%m%d"), next_month.strftime("%Y%m%d")]:
            cells(ws, f"D{i}", "内退日期有误！", RED)

        # 1.2.4	检验离退休减册原因
        if cel(ws, f"E{i}") not in rule_R:
            cells(ws, f"E{i}", "离退休减册原因非码值！", RED)

        # 1.2.5	校验人员组
        if cel(ws, f"F{i}") != "S 离退休后减册人员":
            cells(ws, f"F{i}", "人员组有误！", RED)

        # 1.2.6	校验人员子组
        if cel(ws, f"G{i}") != values_103[key][0] + " " + values_103[key][1]:
            cells(ws, f"G{i}", "人员子组与事前103不同！", RED)

        # 1.2.7	校验工资核算范围
        if cel(ws, f"H{i}") != "00 不发工资":
            cells(ws, f"H{i}", "工资范围不是“00 不发工资”！", RED)

        # 1.2.8	校验离(退)休人员类别码值性
        if cel(ws, f"I{i}") not in rule_W:
            cells(ws, f"I{i}", "离退休人员类别非码值！", RED)

        # 1.2.9	校验离(退)休后享受待遇级别码值性
        if cel(ws, f"J{i}") and cel(ws, f"J{i}") not in rule_X:
            cells(ws, f"J{i}", "离退休后享受待遇级别非码值！", RED)

        # 1.2.10	校验离（退）休人员来源码值性
        if cel(ws, f"K{i}") not in rule_Y:
            cells(ws, f"K{i}", "离退休人员来源非码值！", RED)

        # 1.2.11	校验离(退)休后管理单位文本长度
        if len(cel(ws, f"L{i}")) > 40:
            cells(ws, f"L{i}", "离退休管理单位长度超过40！", RED)

        # 1.2.12	校验延长退休批准文号文本长度
        if len(cel(ws, f"M{i}")) > 20:
            cells(ws, f"M{i}", "延长退休批准文号长度超过20！", RED)

        # 1.2.13	校验异地接收(安置)情况文本长度
        if len(cel(ws, f"N{i}")) > 40:
            cells(ws, f"M{i}", "异地接收(安置)情况长度超过40！", RED)

        # 1.2.14	校验离(退)休人员死亡日期
        try:
            datetime.strptime(cel(ws, f"O{i}"), "%Y%m%d")
        except Exception:
            cells(ws, f"O{i}", "死亡日期有误！", RED)

        # 1.2.15	校验返聘标识码值性
        if cel(ws, f"P{i}") and cel(ws, f"P{i}") not in ["否", "X 是"]:
            cells(ws, f"P{i}", "返聘标识非码值！", RED)
        ws[f"P{i}"] = "  否" if cel(ws, f"P{i}") == "否" else cel(ws, f"P{i}")

        # 1.2.16	校验领取企业年金标识码值性
        if cel(ws, f"Q{i}") and cel(ws, f"Q{i}") not in ["否", "X 是"]:
            cells(ws, f"Q{i}", "领取企业年金标识非码值！", RED)
        ws[f"Q{i}"] = "  否" if cel(ws, f"Q{i}") == "否" else cel(ws, f"Q{i}")

        # 1.2.17	校验备注
        if len(cel(ws, f"R{i}")) > 100:
            cells(ws, f"R{i}", "备注长度超过100！", RED)

        # 1.3.1	校验岗位状态
        if values_103[key][2] != "离退休（在册）":
            cells(ws, f"B{i}", "请核对该人员的岗位状态是否正确", RED)

        # 1.3.2	校验雇佣状态
        if values_103[key][3] != "退休":
            cells(ws, f"C{i}", "请核对该人员的雇佣状态是否正确", RED)

        # 1.3.3	校验当月是否已有事件
        if values_103[key][4].replace("暂停/恢复发薪", ""):
            cells(ws, f"A{i}", "当月已有事件！", RED)
    logging.info("离退休减册模板执行事件前校验完成...")
    wb.save(filename)


# 执行离职事件操作
def li_tui_xiu_jian_ce_operate(count, r_file):
    logging.info("开始批导离退休减册模板...")
    session = attach_sap("reuse")
    session.findById("wnd[0]/tbar[0]/okcd").text = "/n zhrbi0013"
    session.findById("wnd[0]").sendVKey(0)
    session.findById("wnd[0]/usr/radRB_M").select()
    session.findById("wnd[0]/usr/radRB_M_YB").select()
    session.findById("wnd[0]/tbar[1]/btn[8]").press()
    session.findById("wnd[0]/usr/radRB_UP").select()
    # fix_excel(r_file)
    t = Thread(target=find_window, args=(r_file, '#32770', u'选择上传文件'))
    t.setDaemon(True)
    t.start()
    session.findById("wnd[0]/tbar[1]/btn[8]").press()
    if "上载的模板中没有数据或数据错误" in session.findById("wnd[0]/sbar/pane[0]").text:
        if 10 < count:
            with MYFTP() as my_ftp:
                hhmmss = datetime.datetime.now().strftime(r'%H%M%S')  # 上传的目录前面加时分秒前缀，避免同一天一个单子，第二次做覆盖上一次的文件
                remote = remote_ltx + f"失败/{hhmmss}_" + os.path.basename(r_file).split(".")[0] + "/"
                my_ftp.upload_file(r_file, remote + os.path.basename(r_file).split(".")[0] + "_模板错误.xlsx")
            session.findById("wnd[0]/tbar[0]/okcd").text = "/nex"
            session.findById("wnd[0]").sendVKey(0)
            return True
        count += 1
        time.sleep(10)
        flag = li_tui_xiu_jian_ce_operate(count, r_file)
        return flag

    try:
        tb = session.findById("wnd[1]/usr/cntlG_GRID/shellcont/shell")
        wb = load_workbook(r_file)
        ws = wb.active
        for i in range(tb.rowCount):
            cells(ws, f"A{int(tb.getCellValue(i, 'ZZ_XH')) + 6}",
                  f'{tb.getCellValue(i, "FIELD")}:{tb.getCellValue(i, "MSG")}', RED)
        wb.save(r_file)
    except Exception:  # nosec
        pass  # SAP情形不存在，跳过执行
    try:
        result = session.findById("wnd[1]/usr/txtSPOP-TEXTLINE2").text
        session.findById("wnd[1]/usr/btnSPOP-OPTION1").press()
    except Exception as e:
        result = f'{session.findById("wnd[0]/sbar/pane[0]").text}\n\n\n{e}'
    if "失败0" not in result:
        with MYFTP() as my_ftp:
            hhmmss = datetime.datetime.now().strftime(r'%H%M%S')  # 上传的目录前面加时分秒前缀，避免同一天一个单子，第二次做覆盖上一次的文件
            remote = remote_ltx + f"失败/{hhmmss}_" + r_file.split('\\')[-1].split(".")[0] + "/"
            my_ftp.upload_file(r_file, remote + r_file.split('\\')[-1].split(".")[0] + "_批导失败.xlsx")
        update_database(r_file, f"批导结束，{result}")
        logging.info(result)
        logging.error('zhrbi0013批导模板表批导失败, 程序结束运行')
        return True


# 离退休减册事件事后校验
def li_tui_xiu_jian_ce_post_check(s_file):
    logging.info("开始离退休减册事件后置校验...")
    wb_temp = load_workbook(s_file)
    ws_temp = wb_temp.active

    # 3.1.1	导出组合逻辑查询103、1072
    lis = [cel(ws_temp, f"B{x}") for x in range(7, len(ws_temp["A"]) + 1) if cel(ws_temp, f"B{x}")]  # 人员编号
    rpa_work_amount(lis)
    date = [cel(ws_temp, f"D{x}") for x in range(7, len(ws_temp["A"]) + 1) if cel(ws_temp, f"D{x}")][0]  # 事件日期
    value_temp = defaultdict(list)
    for i in range(7, len(ws_temp["A"]) + 1):
        for col in ["D", "G"]:
            value_temp[cel(ws_temp, f"B{i}").lstrip("0")].append(cel(ws_temp, f"{col}{i}"))
    if not lis:
        logging.info("内退模板中没有内退事件。")
        return
    logging.info("提取校验所需要的离退休减册103数据...")
    export_103_li_tui_xiu_jian_ce("reuse", lis, date).save_to(FILE_PATH)
    shutil.copyfile(f"{FILE_PATH}/C21_离退休减册.xlsx", f"{FILE_PATH}/事前_C21_103.xlsx")
    wb_103 = load_workbook(FILE_PATH + "/C21_离退休减册.xlsx")
    ws = wb_103.active

    res_dict = defaultdict(list)
    for i in range(2, len(ws["A"]) + 1):
        logging.info(f"开始校验事后离退休减册103第{i - 1}行数据...")
        key = cel(ws, f"A{i}").lstrip("0")
        if key not in value_temp.keys():
            cells(ws, f"A{i}", "离退休减册模板中没有该人员编号", RED)
            res_dict[True].append(f"A{i}")
            continue

        # 2.1.2	校验开始日期
        for x in ["C", "L", "AE"]:
            if cel(ws, f"{x}{i}").replace(".", "") != value_temp[key][0]:
                cells(ws, f"{x}{i}", "开始日期与表单不一致！", RED)
                res_dict[True].append(f"{x}{i}")

        # 2.1.3	校验事件是否成功
        if "离退休人员减册" not in cel(ws, f"G{i}"):
            cells(ws, f"G{i}", "离退休减册事件不成功！", RED)
            res_dict[True].append(f"G{i}")

        # 2.1.4	校验事件是否成功
        if cel(ws, f"J{i}") != "离退休（不在册）":
            cells(ws, f"J{i}", "岗位状态有误！", RED)
            res_dict[True].append(f"J{i}")

        # 2.1.5	校验事件是否成功
        if cel(ws, f"K{i}") != "不在册不在岗":
            cells(ws, f"K{i}", "雇佣状态有误！", RED)
            res_dict[True].append(f"K{i}")

        # 2.1.6	校验事件是否成功
        if cel(ws, f"S{i}") != "S":
            cells(ws, f"S{i}", "人员组有误！", RED)
            res_dict[True].append(f"S{i}")

        # 2.1.7	校验事件是否成功
        if cel(ws, f"U{i}") != value_temp[key][1][:2]:
            cells(ws, f"U{i}", "人员子组与模板不同！", RED)
            res_dict[True].append(f"U{i}")

        # 2.1.8	校验事件是否成功
        if cel(ws, f"Y{i}") != "99999999":
            cells(ws, f"Y{i}", "离退休减册事件失败！", RED)
            res_dict[True].append(f"Y{i}")

        # 2.1.9	校验工资范围
        if cel(ws, f"AA{i}") != "00":
            cells(ws, f"AA{i}", "工资范围不为00！", RED)
            res_dict[True].append(f"AA{i}")

        # 2.1.10	校验工资总额控制范围
        if cel(ws, f"AC{i}"):
            cells(ws, f"AC{i}", "工资范围为00，工资总额控制范围应为空！", RED)
            res_dict[True].append(f"AC{i}")
    wb_103.save(FILE_PATH + "/模板_103.xlsx")
    res, flag = ("失败", False) if "错误" in res_dict.keys() else ("成功", True)
    dir_path = get_rpa_dir('离退休减册', os.path.basename(s_file), flag)
    with MYFTP() as my_ftp:
        remote = remote_ltx + f"{res}/{os.path.basename(s_file)[:-5]}/"
        ds = {s_file: (f"{dir_path}/{os.path.basename(s_file)}", remote + os.path.basename(s_file)),
              f"{FILE_PATH}/模板_103.xlsx": (f"{dir_path}/事后_103.xlsx", f"{remote}事后_103.xlsx"),
              f"{FILE_PATH}/事前_C21_103.xlsx": (f"{dir_path}/事前备份_103.xlsx", f"{remote}事前备份_103.xlsx")}
        for x, (y, z) in ds.items():
            if os.path.exists(x):
                shutil.copyfile(x, y)
            if os.path.exists(y):
                my_ftp.upload_file(y, z)
    update_database(s_file, "执行结束")


def upload_ftp(filename):
    dir_path = get_rpa_dir('离退休减册', os.path.basename(filename), False)
    with MYFTP() as my_ftp:
        hhmmss = datetime.datetime.now().strftime(r'%H%M%S')  # 上传的目录前面加时分秒前缀，避免同一天一个单子，第二次做覆盖上一次的文件
        remote = f'{remote_ltx}失败/{hhmmss}_{os.path.basename(filename)[:-5]}/'
        ds = {filename: (f"{dir_path}/{os.path.basename(filename)}", f"{remote}{os.path.basename(filename)}"),
              f"{filename}/事前_C21_103.xlsx": (f"{dir_path}/事前备份_103.xlsx", f"{remote}事前备份_103.xlsx")}
        for x, (y, z) in ds.items():
            if os.path.exists(x):
                shutil.copyfile(x, y)
            if os.path.exists(y):
                my_ftp.upload_file(y, z)


def check_payroll_control_range(filename):
    try:
        session = attach_sap("login_tx")
        logging.info("检查并修改离退休减册事件工资总额控制范围的信息")
        wb = load_workbook(filename)
        ws = wb.active
        for i in range(7, len(ws["A"]) + 1):
            if cel(ws, f"H{i}") != "00 不发工资":
                continue
            session.findById("wnd[0]/tbar[0]/okcd").text = "/n PA30"
            session.findById("wnd[0]").sendVKey(0)
            session.findById(
                "wnd[0]/shellcont/shell/shellcont[0]/shell/shellcont[1]/shell[1]").topNode = "          1"
            session.findById("wnd[0]/usr/ctxtRP50G-PERNR").text = cel(ws, f"B{i}")
            session.findById("wnd[0]/usr/ctxtRP50G-PERNR").caretPosition = 7
            session.findById("wnd[0]").sendVKey(0)
            session.findById("wnd[0]/usr/tabsMENU_TABSTRIP/tabpTAB03").select()
            session.findById(
                "wnd[0]/usr/tabsMENU_TABSTRIP/tabpTAB03/ssubSUBSCR_MENU:SAPMP50A:0400/subSUBSCR_ITMENU:SAPMP50A:0310/tblSAPMP50ATC_MENU").getAbsoluteRow(
                0).selected = -1
            session.findById("wnd[0]/tbar[1]/btn[20]").press()
            session.findById("wnd[0]/usr/tblMP000100TC3000").getAbsoluteRow(0).selected = -1
            session.findById("wnd[0]/usr/tblMP000100TC3000/txtP0001-BEGDA[0,0]").setFocus()
            session.findById("wnd[0]/usr/tblMP000100TC3000/txtP0001-BEGDA[0,0]").caretPosition = 0
            session.findById("wnd[0]/tbar[1]/btn[6]").press()
            try:
                session.findById("wnd[0]/usr/subSUBSCREEN_T582C:ZP000100:0200/ctxtP0001-ZZ_ZEFW").text = ''
                session.findById("wnd[0]/usr/subSUBSCREEN_T582C:ZP000100:0200/ctxtP0001-ZZ_ZEFW").setFocus()
                session.findById(
                    "wnd[0]/usr/subSUBSCREEN_T582C:ZP000100:0200/ctxtP0001-ZZ_ZEFW").caretPosition = 2
            except Exception:
                logging.warning('工资总额控制范围已带出，无需修改')
                time.sleep(1)
                session.findById("wnd[0]").sendVKey(0)
                session.findById("wnd[0]").sendVKey(0)
            session.findById("wnd[0]/tbar[0]/btn[11]").press()
    except Exception:
        sendmail(receivers="553041800@qq.com", subject="li_tui_xiu_jian_ce_shi_jian.py 351行", body=traceback.format_exc())
        logging.info("1.5.2	确定00工资总额控制范围为空可能执行异常，跳过执行后续步骤。")


def run_rpa_li_tui_xiu_jian_ce(filename):
    file = to_windows_path_format(filename)
    update_db(file, "开始执行")
    # 模板批导前校验
    clear_all_colour_and_comment(file, "离退休减册事件批导", remote_ltx)
    check_zhrpy280(file)
    li_tui_xiu_jian_ce_pre_check(file)
    if send_email(file):
        upload_ftp(file)
        return
    # 模板批导
    if li_tui_xiu_jian_ce_operate(1, file):
        return
    check_payroll_control_range(file)
    li_tui_xiu_jian_ce_post_check(file)


if __name__ == '__main__':
    run_rpa_li_tui_xiu_jian_ce(r"x:\Users\lenovo\Desktop\1000209726-X420-离退休减册-薛胜坤.xlsx")
