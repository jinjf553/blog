
import logging
import traceback
from pathlib import Path
from time import sleep

import pythoncom

import rpa.public.config
from rpa.fastrpa.obs import OBS_REC
from rpa.fastrpa.sap.session import SapClose, close_sap
from rpa.fastrpa.tempdir import (clean_last_3mon_temp_dir, gentempdir,
                                 reset_tempdir)
from rpa.fastrpa.third_party.dont_sleep import DONT_SLEEP
from rpa.ssc.hr.orm.dims_utils import (load_tb_dim_hr_diao_pei,
                                       load_tb_dim_hr_li_tui, query_dims)
from rpa.ssc.hr.orm.orm import rpa_login, rpa_subticket
from rpa.ssc.hr.orm.session import DbSession
from rpa.ssc.hr.sap.pa30 import main as run_kit_pa30  # 组织分配屏修改
from rpa.ssc_kit.hr.kit_chai_dan.main import \
    run_chai_dan as run_kit_zi_dong_chai_dan  # 自动拆单
from rpa.ssc_kit.hr.kit_chai_dan.run_A import \
    run_kit_shou_dong_chai_dan as run_kit_shou_dong_chai_dan  # 手动拆单
from rpa.ssc_kit.hr.kit_cost_center.run import \
    main as run_kit_cost_center  # 成本中心定位
from rpa.ssc_kit.hr.kit_export_103_107.main import \
    main as run_kit_export_sap_query  # 组合逻辑查询导出
from rpa.ssc_kit.hr.kit_export_cost_center.main import \
    main as run_kit_export_cost_center  # 成本中心信息导出
from rpa.ssc_kit.hr.kit_export_job_info_v2.main import \
    main as run_kit_export_job_info  # 机构岗位查询分析
from rpa.ssc_kit.hr.kit_update_org_name.main import \
    main as run_kit_update_org_name  # 单位简化全称修改
from rpa.ssc_rpa.hr.rpa_bu_zai_gang.no_job_change import \
    no_job_change as run_rpa_bu_zai_gang  # 不在岗变动
from rpa.ssc_rpa.hr.rpa_er_diao_zhi_diao.main import \
    main as run_rpa_er_diao  # 二级单位间调动
from rpa.ssc_rpa.hr.rpa_gang_bian.SAP import \
    rpa_gang_bian as run_rpa_gang_bian  # 岗位变动
from rpa.ssc_rpa.hr.rpa_ji_gou_wei_hu.main import \
    main as run_rpa_ji_gou_wei_hu  # 非中层机构
from rpa.ssc_rpa.hr.rpa_jian_gang.main import \
    main as run_rpa_xiao_shou_jian_gang_new  # 建岗RPA[新]
from rpa.ssc_rpa.hr.rpa_lao_wu_gong.lao_wu_gong_tui_hui import \
    run_lao_wu_gong_shi_jian as run_rpa_lao_wu_gong  # 劳务工退回
from rpa.ssc_rpa.hr.rpa_li_gang.employee_absences import \
    employee_absences as run_rpa_li_gang  # 离岗
from rpa.ssc_rpa.hr.rpa_li_tui_xiu_jian_ce.li_tui_xiu_jian_ce_shi_jian import \
    run_rpa_li_tui_xiu_jian_ce as run_rpa_li_tui_xiu_jian_ce  # 离退休减册
from rpa.ssc_rpa.hr.rpa_li_zhi.li_zhi_shi_jian import \
    run_li_zhi as run_rpa_li_zhi  # 离职
from rpa.ssc_rpa.hr.rpa_nei_tui.nei_tui_shi_jian import \
    run_nei_tui as run_rpa_nei_tui  # 内退
from rpa.ssc_rpa.hr.rpa_ru_zhi.ru_zhi_shi_jian import \
    da_xue_sheng_ru_zhi as run_rpa_da_xue_sheng_ru_zhi  # 大学生入职
from rpa.ssc_rpa.hr.rpa_ru_zhi.ru_zhi_shi_jian import \
    yuan_gong_ru_zhi as run_rpa_yuan_gong_ru_zhi  # 员工入职（传目录）


def run_rpa(filename: str, subticket_type: str = ''):
    """根据工单类型判断要执行的功能"""
    pythoncom.CoInitialize()
    try:
        try:
            with DbSession('165') as _:
                pass
        except Exception:  # nosec
            logging.error('165服务器无法连接，影响RPA工作量汇总，请联系RPA管理员解决')
        reset_tempdir()
        with DONT_SLEEP():  # 禁用休眠
            with OBS_REC(filename):  # 录屏
                with SapClose():
                    clean_last_3mon_temp_dir()
                    load_tb_dim_hr_diao_pei.cache_clear()  # 清理码表缓存，避免更新码表时，需要重启RPA的问题
                    load_tb_dim_hr_li_tui.cache_clear()  # 清理码表缓存
                    query_dims.cache_clear()
                    rpa.public.config.FILE_PATH = gentempdir()
                    if subticket_type == '自动拆单':  # 自动拆单
                        try:
                            logging.info('正在循环执行自动拆单')
                            run_kit_zi_dong_chai_dan(1)  # 自动拆单（需要权鉴）
                        except Exception as e:
                            logging.error(f'执行出错，异常原因：{e}')
                            logging.error(f"调用栈: {traceback.format_exc()}")
                        finally:
                            logging.info('【RPA】执行结束')
                            return
                    elif subticket_type == '手动拆单':  # 手动拆单
                        try:
                            logging.info('正在执行手动拆单')
                            logging.info(filename)
                            run_kit_shou_dong_chai_dan(filename)  # 手动拆单
                        except Exception as e:
                            logging.error(f'执行出错，异常原因：{e}')
                            logging.error(f"调用栈: {traceback.format_exc()}")
                        finally:
                            logging.info('【RPA】执行结束')
                            return
                    elif subticket_type == '成本中心定位':
                        run_kit_cost_center(filename)
                    elif subticket_type == '组合逻辑查询导出':
                        run_kit_export_sap_query(filename)
                    elif subticket_type == '机构岗位查询分析':
                        run_kit_export_job_info(filename)
                    elif subticket_type == '成本中心信息导出':
                        run_kit_export_cost_center(filename)
                    elif subticket_type == '组织分配屏修改':
                        run_kit_pa30(filename, True, True, False)
                    elif subticket_type == '单位简化全称修改':
                        run_kit_update_org_name(filename)
                    else:
                        with rpa_login(filename):
                            try:
                                with rpa_subticket(filename):
                                    if subticket_type == '岗位变动':
                                        run_rpa_gang_bian(filename)  # 岗位变动
                                    elif subticket_type == '员工入职':
                                        run_rpa_yuan_gong_ru_zhi(Path(filename).parent.as_posix())  # 员工入职（传目录）
                                    elif subticket_type == '劳务工退回':
                                        run_rpa_lao_wu_gong(filename)
                                    elif subticket_type == '离退休减册':
                                        run_rpa_li_tui_xiu_jian_ce(filename)
                                    elif subticket_type == '大学生入职':
                                        run_rpa_da_xue_sheng_ru_zhi(Path(filename).parent.as_posix())  # 大学生入职（传目录）
                                    elif subticket_type == '离职':
                                        run_rpa_li_zhi(filename)  # 离职
                                    elif subticket_type == '内退':
                                        run_rpa_nei_tui(filename)  # 内退
                                    elif subticket_type == '销售建岗':
                                        # run_rpa_xiao_shou_jian_gang(filename)  # 建岗
                                        run_rpa_xiao_shou_jian_gang_new(filename)  # 建岗RPA[新]
                                    elif subticket_type == '离岗':
                                        run_rpa_li_gang(filename)  # 离岗
                                    elif subticket_type == '不在岗变动':
                                        run_rpa_bu_zai_gang(filename)  # 不在岗变动
                                    elif subticket_type == '组织机构维护':
                                        run_rpa_ji_gou_wei_hu(filename)  # 组织机构维护
                                    elif subticket_type in ('二级单位间调动', '直属单位间调动'):
                                        run_rpa_er_diao(filename)  # 二级单位间调动
                                    else:
                                        logging.error('不支持的模板类型')
                            except Exception as e:
                                logging.error(f'执行出错，异常原因：{e}')
                                logging.error(f"调用栈: {traceback.format_exc()}")
                                return
                            finally:
                                sleep(2)  # 等待1秒保证OBS录制到这条日志
    except Exception as e:
        logging.error(f'执行出错，异常原因：{e}')
        logging.error(f"调用栈: {traceback.format_exc()}")
    finally:
        close_sap()


if __name__ == '__main__':
    from rpa.fastrpa.log import config
    config('99998888-X420-岗位变动-常盛')
    # rpa.config.SAP_FUNJ = 'FUNJ0036'
    # rpa.config.FSO_USERNAME = 'changsh55'  # 业务人员FSO账号写入全局配置里
    # rpa.config.STAFF_GROUP = 'RPA团队'
    # rpa.config.STAFF_ID = 42
    # rpa.config.STAFF_TYPE = '组员'
    # rpa.config.STAFF_NAME = '常盛'
    # run_rpa(r"x:\mengzhao\Desktop\120703_失败_99998888-X420-岗位变动-常盛.xlsx\99998888-X420-岗位变动-常盛.xlsx", '岗位变动')
    rpa.config.SAP_FUNJ = 'FUNJ0179'
    rpa.config.FSO_USERNAME = 'guoy926'  # 业务人员FSO账号写入全局配置里
    rpa.config.STAFF_GROUP = 'RPA团队'
    rpa.config.STAFF_ID = 49
    rpa.config.STAFF_TYPE = '组员'
    rpa.config.STAFF_NAME = '郭运'
    run_rpa(r"D:\mengzhao\Desktop\0000000000-X420-离职-郭运.xlsx", '离职')
