import datetime
import logging
import re
import uuid
from pathlib import Path
from time import sleep
from typing import Any, List

import pyperclip
import pythoncom
import rpa.config
from pandas import DataFrame
from rpa.fastrpa.adtable import AdTable, load_from_xlsx_file
from rpa.fastrpa.path import to_windows_path_format
from rpa.fastrpa.sap.grid_view_ctrl import GridViewCtrl
from rpa.fastrpa.sap.gui_table import GuiTable
from rpa.fastrpa.tempdir import gentempdir
from rpa.fastrpa.utils.peek_encoding import peek_file_encoding
from rpa.public.myftp import MYFTP


def save_query_selection(session: Any, query_name: str) -> bool:
    """保存勾选结果（query_name必须为大写字母、下划线、数字组成）
       重要：输入字段必须有默认值，否则保存后重新加载时不显示该输入字段"""
    try:
        session.findById("wnd[0]/tbar[0]/btn[11]").press()  # 保存
        try:
            if '仍未为输出选择字段' in session.findById("/app/con[0]/ses[0]/wnd[1]/usr/txtMESSTXT1").Text:  # 未选择字段，无法保存
                session.findById("wnd[1]/tbar[0]/btn[0]").press()  # 继续（回车）
                return False
        except pythoncom.com_error:  # pylint: disable=fixme, no-member
            pass
        try:
            session.findById("wnd[1]/usr/txtDYNP4200-QUERY").text = query_name  # 名称（必须由大写字母、下划线、数字组成）
        except AttributeError:
            return False
        session.findById("wnd[1]/tbar[0]/btn[0]").press()  # 继续（回车）
        try:
            session.findById("wnd[1]/usr/btnBUTTON_1").press()  # 确认（弹窗：已存在时是否覆盖）
        except pythoncom.com_error:  # pylint: disable=fixme, no-member
            pass
        sap_status = session.findById("wnd[0]/sbar/pane[0]").text
        if '查询已保存' in sap_status:
            return True
        else:
            return False
    except pythoncom.com_error:  # pylint: disable=fixme, no-member
        return False


def load_query_selection(session: Any, query_name: str) -> bool:
    """加载勾选结果"""
    try:
        session.findById("wnd[0]/tbar[1]/btn[6]").press()  # 打开查询
        gui_table = GuiTable(session, "wnd[1]/usr/tblSAPLAQ_INT_FUNCTIONSTCH_OPEN_QUERIES")
        is_find = gui_table.find_by_name(query_name)
        if is_find == -1:
            session.findById("wnd[1]/tbar[0]/btn[12]").press()  # 取消
            return False
        else:
            session.findById("wnd[1]").sendVKey(2)  # 双击选择项
            # session.findById("wnd[1]/tbar[0]/btn[0]").press()  # 找到后点击确定
            # session.findById("wnd[1]/tbar[0]/btn[0]").press()  # 选择查询信息框-确认
            return True
    except pythoncom.com_error:  # pylint: disable=fixme, no-member
        return False


def query_selection(session: Any, query_name: str, select_fn, header_ids: List[str],
                    grid_view_ctrl_id="wnd[0]/shellcont[0]/shell"):
    """信息集查询
    --------------------------------
    session: SAP SESSION会话对象
    query_name: 信息集名称（最长14个字符）
    select_fn: 勾选函数
    header_ids: 勾选结果列ID
    --------------------------------
    加载名为query_name的信息集，如不存在，则调用select_fn重新勾选，并将勾选结果保存为query_name，
    如存在，则校验加载后的信息集列ID与预设值是否一致，不一致则重新勾选，并将勾选结果保存为query_name。
    """
    logging.info(f'组合逻辑查询变式名称：{query_name}')
    # assert len(query_name) <= 14
    if load_query_selection(session, query_name) is False:  # 找不到命名勾选结果
        logging.error(f'找不到{query_name}变式，重新勾选')
        select_fn(session)  # 重新勾选
        save_query_selection(session, query_name)  # 保存勾选结果
    grid_view_ctrl = GridViewCtrl(session, grid_view_ctrl_id)  # 定位底部勾选结果样例表格
    if grid_view_ctrl.header_ids != header_ids:  # 表格列id不等于预设值
        logging.info('表格列id不等于预设值')
        logging.info(grid_view_ctrl.header_ids)
        logging.info('执行重新勾选')
        select_fn(session)  # 重新勾选
        logging.info('保存勾选结果')
        save_query_selection(session, query_name)  # 保存勾选结果（如存在则覆盖）
        logging.info(f'重新勾选后列id为：{grid_view_ctrl.header_ids}')


def parse_query_string(query_string: str):
    line_strs = query_string.splitlines(keepends=False)  # 按\n分割行，并剔除行两端的\r，同时兼容CRLF和LF
    seps = [idx for idx, line in enumerate(line_strs) if
            re.match('^[-]{10,}$', line) is not None]  # 找到所有分隔符行号（只包含"-"的行）
    header_str = ''.join(line_strs[seps[-3] + 1:seps[-2]])  # 标题行字符串
    header_names = [header_name.strip(' \t\r\n') for header_name in header_str.strip(' |').split('|')]  # 标题名称
    column_cnt = len(header_names)  # 标题行字段个数
    if len(seps) >= 6:  # 超过6万行，输出内容的包含分页（导出组合逻辑查询107_T83-2，岗位33250000时遇到的）
        content_lines = line_strs[seps[2] + 1:seps[3] - 1] + line_strs[seps[-2] + 1:seps[-1]]  # 正文行字符串
    else:
        content_lines = line_strs[seps[-2] + 1:seps[-1]]  # 正文行字符串
    contents = []  # 内容数组
    line_cnt = len(content_lines)  # 行数
    merge_lines = [1, 2, 3, 4, 5]
    last_match_line = 2
    begin_line = 0  # 开始行
    end_with_vertical_line = True  # 每一行最后是否以竖线结尾
    for k in range(line_cnt):
        succ_flag = False  # 是否命中
        for i in [last_match_line] + merge_lines:  # 一次匹配i行
            end_line = begin_line + i  # 结束行
            if end_line > line_cnt:  # 超过最大行数跳过
                continue
            if not (end_with_vertical_line is True and len(content_lines[end_line - 1]) > 0 and
                    content_lines[end_line - 1][-1] == '|'):
                continue  # 如果不是以竖线结尾，则跳过
            line = [cell_text.strip(' \t\r\n"') for cell_text in
                    ''.join(content_lines[begin_line:end_line]).strip('|').split('|')]
            if len(line) == column_cnt:
                contents.append(line)
                succ_flag = True
                begin_line = end_line  # 匹配成功后，下次匹配从上次结束行继续匹配
                last_match_line = i
                break
        if begin_line == 0 and succ_flag is False:
            raise Exception("首行无法解析")
        elif succ_flag is False:
            break  # 中间无法解析，停止解析
        elif begin_line >= line_cnt:
            break  # 超出末尾，停止解析
    return header_names, contents


def save_unparsed_query_string():
    import datetime
    query_string = pyperclip.paste()
    filename = r'x:/sap_query_string_' + datetime.datetime.now().strftime(r'%Y%m%d%H%M%S') + '.txt'
    with open(filename, 'w') as f:
        f.write(query_string)


def export_query(session: Any, grid_view_ctrl_id=r'wnd[0]/usr/cntlGRID1/shellcont/shell', template_file='',
                 skip_header=1, *, query_name: str = '') -> AdTable:
    """函数抛出异常：未选取数据、系统不能读取任何数据"""
    if query_name == '':
        raise Exception('必须指定参数query_name')
    grid_view_ctrl = GridViewCtrl(session, grid_view_ctrl_id)
    sap_status = session.findById("wnd[0]/sbar/pane[0]").text
    logging.info(f"SAP系统提示信息：{sap_status}")
    if '未选取数据' in sap_status or '系统不能读取任何数据' in sap_status:
        raise Exception(sap_status)
    try:
        if 'SAP 清单浏览器' in session.findById("wnd[0]/usr/rad%ALV").text:
            logging.warning('\t已选择“通过选择屏幕开始”模式，注意检查编辑设置（输出）！')
            session.findById("wnd[0]/tbar[1]/btn[8]").press()
    except Exception:  # nosec
        pass

    try:
        session.findById("wnd[0]/tbar[1]/btn[45]").press()  # 本地文件（按钮）
    except Exception as e:
        try:
            sleep(1)
            export_query_screenshot = to_windows_path_format(Path(f'{rpa.config.RPA_SCREENSHOTS_DIR}/export_query_screenshot.bmp').as_posix())
            logging.error(f'组合逻辑查询导出遇到未知错误，屏幕截图：{export_query_screenshot}')
            session.findById('wnd[0]').HardCopy(export_query_screenshot)
            session.findById("wnd[0]/mbar/menu[0]/menu[3]/menu[2]").select()
        except Exception:
            sap_title = session.findById("wnd[0]").Text
            if '运行时间错误' in sap_title:
                logging.error(f'SAP查询超时：{sap_title}')
            raise e
    session.findById(
        "wnd[1]/usr/subSUBSCREEN_STEPLOOP:SAPLSPO5:0150/sub:SAPLSPO5:0150/radSPOPLI-SELFLAG[4,0]").select()  # 勾选[保存到剪切板]
    session.findById("wnd[1]/tbar[0]/btn[0]").press()  # 确定
    query_string = pyperclip.paste()

    # session.findById(
    #     "wnd[1]/usr/subSUBSCREEN_STEPLOOP:SAPLSPO5:0150/sub:SAPLSPO5:0150/radSPOPLI-SELFLAG[0,0]").select()  # 勾选[未转换的]
    # session.findById("wnd[1]/tbar[0]/btn[0]").press()  # 保存到本地文件
    output_dir = gentempdir()
    query_string_filename = Path(output_dir).joinpath('query_string.txt').as_posix()
    Path(query_string_filename).write_text(query_string)
    # session.findById("wnd[1]/usr/ctxtDY_PATH").text = output_dir  # 目录
    # session.findById("wnd[1]/usr/ctxtDY_FILENAME").text = "query_string.txt"  # 文件名（ANSI编码）
    # session.findById("wnd[1]/usr/ctxtDY_FILENAME").caretPosition = 16
    # if Path(query_string_filename).exists() is True:
    #     session.findById("wnd[1]/tbar[0]/btn[11]").press()  # 覆盖
    # else:
    #     session.findById("wnd[1]/tbar[0]/btn[0]").press()  # 生成
    # for _ in range(60):  # 1分钟，等待文件写完
    #     sap_status = session.findById("wnd[0]/sbar/pane[0]").text
    #     if '字节已传输，代码页为' in sap_status:
    #         break
    #     else:
    #         sleep(1)
    # # WARN GUI安全性窗口已禁止弹出
    # query_string_encoding = peek_file_encoding(Path(output_dir).joinpath('query_string.txt').as_posix())
    # query_string = Path(output_dir).joinpath('query_string.txt').read_text(encoding=query_string_encoding)
    if template_file == '':
        _table = AdTable('SAP Query', skip_header=skip_header)
    else:
        _table = load_from_xlsx_file(template_file, skip_header=skip_header)
    try:
        header_names, contents = parse_query_string(query_string)  # 先尝试用剪切板方式解析导出序列，如失败则逐行逐单元格读取
        # assert grid_view_ctrl.column_count == len(header_names)
        # assert grid_view_ctrl.row_count == len(contents)
        for column, value in enumerate(header_names, start=1):
            _table[column][1].value = value
        for row, line in enumerate(contents, start=1 + skip_header):
            for column, value in enumerate(line, start=1):
                _table[column][row].value = value
        logging.info(f'共导出{len(contents)}条记录')
    except Exception:
        logging.error(f'组合逻辑查询结果文本解析失败，文件名：{Path(output_dir).joinpath("query_string.txt").as_posix()}')
        save_unparsed_query_string()
        logging.info('尝试逐个单元格导出组合逻辑查询结果')
        _table = grid_view_ctrl.to_adtable(_table)  # 逐行逐单元格读取
    query_name = ''.join([ch for ch in query_name if ch not in ['\\', '/', ':', '*', '?', '"', '<', '>', '|', ' ', '.']])  # 过滤不能作为文件名的特殊字符
    query_name = '未知变式' if query_name == '' else query_name
    uuid_query_title = str(uuid.uuid1())
    with MYFTP() as my_ftp:
        now = datetime.datetime.now()
        yyyymm = now.strftime(r'%Y%m')
        yyyymmdd = now.strftime(r'%Y%m%d')
        hhmmss = now.strftime(r'%H%M%S')
        local_filename = f'{rpa.config.D_RPA}/HR组合逻辑查询备份/{query_name}/{yyyymm}/{yyyymmdd}/{hhmmss}_{uuid_query_title}.xlsx'
        _table.save(local_filename)
        remote_filename = f'/HR组合逻辑查询备份/{query_name}/{yyyymm}/{yyyymmdd}/{hhmmss}_{uuid_query_title}.xlsx'
        my_ftp.upload_file(local_filename, remote_filename, False)
        logging.info(f'组合逻辑查询已备份至FTP: {remote_filename}')
    return _table


def export_query_to_dataframe(session: Any, grid_view_ctrl_id=r'wnd[0]/usr/cntlGRID1/shellcont/shell') -> DataFrame:
    import pandas as pd
    grid_view_ctrl = GridViewCtrl(session, grid_view_ctrl_id)
    sap_status = session.findById("wnd[0]/sbar/pane[0]").text
    logging.info(f"SAP系统提示信息：{sap_status}")
    if '未选取数据' in sap_status or '系统不能读取任何数据' in sap_status:
        raise Exception(sap_status)
    try:
        session.findById("wnd[0]/tbar[1]/btn[45]").press()  # 本地文件（按钮）
    except Exception as e:
        sap_title = session.findById("wnd[0]").Text
        if '运行时间错误' in sap_title:
            logging.error(f'SAP查询超时：{sap_title}')
        raise e
    # session.findById("wnd[1]/usr/subSUBSCREEN_STEPLOOP:SAPLSPO5:0150/sub:SAPLSPO5:0150/radSPOPLI-SELFLAG[4,0]").select()  # 勾选[保存到剪切板]
    # session.findById("wnd[1]/tbar[0]/btn[0]").press()  # 确定
    # query_string = pyperclip.paste()
    session.findById(
        "wnd[1]/usr/subSUBSCREEN_STEPLOOP:SAPLSPO5:0150/sub:SAPLSPO5:0150/radSPOPLI-SELFLAG[0,0]").select()  # 勾选[未转换的]
    session.findById("wnd[1]/tbar[0]/btn[0]").press()  # 保存到本地文件
    output_dir = gentempdir()
    query_string_filename = Path(output_dir).joinpath('query_string.txt').as_posix()
    session.findById("wnd[1]/usr/ctxtDY_PATH").text = output_dir  # 目录
    session.findById("wnd[1]/usr/ctxtDY_FILENAME").text = "query_string.txt"  # 文件名（ANSI编码）
    session.findById("wnd[1]/usr/ctxtDY_FILENAME").caretPosition = 16
    if Path(query_string_filename).exists() is True:
        session.findById("wnd[1]/tbar[0]/btn[11]").press()  # 覆盖
    else:
        session.findById("wnd[1]/tbar[0]/btn[0]").press()  # 生成
    for _ in range(60):  # 1分钟，等待文件写完
        sap_status = session.findById("wnd[0]/sbar/pane[0]").text
        if '字节已传输，代码页为' in sap_status:
            break
        else:
            sleep(1)
    # WARN GUI安全性窗口已禁止弹出
    query_string_encoding = peek_file_encoding(Path(output_dir).joinpath('query_string.txt').as_posix())
    query_string = Path(output_dir).joinpath('query_string.txt').read_text(encoding=query_string_encoding)
    try:
        header_names, contents = parse_query_string(query_string)  # 先尝试用剪切板方式解析导出序列，如失败则逐行逐单元格读取
        # column_count = grid_view_ctrl.column_count
        # row_count = grid_view_ctrl.row_count
        # assert column_count == len(header_names)
        # assert row_count == len(contents)
        df = pd.DataFrame(contents, columns=header_names)
    except Exception:
        save_unparsed_query_string()
        df = grid_view_ctrl.to_dataframe()  # 逐行逐单元格读取
    return df


if __name__ == '__main__':
    with open('x:/query_string.txt', encoding='utf-8') as f:
        query_string = f.read()
        header_names, contents = parse_query_string(query_string)
        print(len(contents), contents[-1])
