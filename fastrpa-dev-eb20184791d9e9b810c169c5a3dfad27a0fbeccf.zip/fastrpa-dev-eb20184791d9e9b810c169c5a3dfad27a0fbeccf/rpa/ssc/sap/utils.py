def init_sap_value(text: str) -> str:
    """剔除单元格首尾空格"""
    if isinstance(text, str):
        return text.rstrip(' \t\r\n')
    else:
        return text


def init_sap_id(id: str) -> str:
    """初始化SAP导出的id列（一般为A列）
       如果id为8位，直接返回
       小于8位前置补0补齐8位
       大于8位剔除前置0
       其余情况返回原值"""
    if isinstance(id, str):
        new_id: str = id.strip(' \t\r\n')
        if len(new_id) > 8:
            new_id = new_id.lstrip('0')
        if new_id != '' and len(new_id) < 8:
            new_id = '0' * (8 - len(new_id)) + new_id
        if len(new_id) == 8 and new_id.isdigit() is True:
            return new_id
    return id  # 修正后id不是8位，说明不是id列，返回原结果
