import os
import signal
from time import sleep

import pythoncom
import wmi


def refresh_explorer() -> bool:
    """注销explorer.exe，解决win7卡顿问题"""
    try:
        pythoncom.CoInitialize()
        for process in wmi.WMI().Win32_Process():
            if process.Name == 'explorer.exe':
                os.kill(process.ProcessId, signal.SIGINT)
        return True
    except Exception:
        return False
