"""人事工作量汇总相关日期函数"""
import datetime
from typing import Tuple


def get_today() -> str:
    return datetime.datetime.now().strftime(r'%Y%m%d')


def get_year(yyyymmdd: str) -> str:
    """返回yyyy年份"""
    week_str = get_week_str(yyyymmdd)
    week_begin_day = yyyymmdd
    _yyyymmdd = yyyymmdd
    while True:
        _yyyymmdd = before_day(_yyyymmdd)
        if week_str == get_week_str(_yyyymmdd):
            week_begin_day = _yyyymmdd
        else:
            break
    return week_begin_day[:4]


def week3_day(yyyymmdd: str):
    """以[周四,周三]为一周,获取当前日期所在周的周三日期"""
    date = datetime.datetime.strptime(yyyymmdd, "%Y%m%d")
    isoweekday = date.isoweekday()  # 星期数(1,2,3,4,5,6,7)
    if isoweekday <= 3:
        return (date + datetime.timedelta(days=3 - isoweekday)).strftime('%Y%m%d')
    elif isoweekday > 3:
        return (date + datetime.timedelta(days=10 - isoweekday)).strftime('%Y%m%d')


def before_day(yyyymmdd: str) -> str:
    """获取前一天日期"""
    return (datetime.datetime.strptime(yyyymmdd, "%Y%m%d") - datetime.timedelta(days=1)).strftime('%Y%m%d')


def next_day(yyyymmdd: str) -> str:
    """获取下一天日期"""
    return (datetime.datetime.strptime(yyyymmdd, "%Y%m%d") + datetime.timedelta(days=1)).strftime('%Y%m%d')


def get_month_week(yyyymmdd: str) -> Tuple[int, int]:
    """获取当天所在月份,周次"""
    assert len(yyyymmdd) == 8, f'日期非8位标准日期：【{yyyymmdd}】'
    mm = yyyymmdd[4:6]
    yyyymm = yyyymmdd[:6]  # 当月
    yyyymm01 = yyyymm + '01'  # 当月第一天
    week1_end_day = week3_day(yyyymm01)  # 当月第一周结束日期
    if yyyymm01 <= yyyymmdd <= week1_end_day:
        return int(week1_end_day[4:6]), 1
    week2_begin_day = next_day(week1_end_day)
    week2_end_day = week3_day(week2_begin_day)
    if week2_begin_day <= yyyymmdd <= week2_end_day:
        return int(week2_end_day[4:6]), 2
    week3_begin_day = next_day(week2_end_day)
    week3_end_day = week3_day(week3_begin_day)
    if week3_begin_day <= yyyymmdd <= week3_end_day:
        return int(week3_end_day[4:6]), 3
    week4_begin_day = next_day(week3_end_day)
    week4_end_day = week3_day(week4_begin_day)
    if week4_begin_day <= yyyymmdd <= week4_end_day:
        if week4_end_day[4:6] == mm:
            return int(week4_end_day[4:6]), 4
        else:
            return int(week4_end_day[4:6]), 1
    week5_begin_day = next_day(week4_end_day)
    week5_end_day = week3_day(week5_begin_day)
    if week5_begin_day <= yyyymmdd <= week5_end_day:
        if week5_end_day[4:6] == mm:
            return int(week5_end_day[4:6]), 5
        else:
            return int(week5_end_day[4:6]), 1
    week6_begin_day = next_day(week5_end_day)
    week6_end_day = week3_day(week6_begin_day)
    if week6_begin_day <= yyyymmdd <= week6_end_day:
        if week6_end_day[4:6] == mm:
            return int(week6_end_day[4:6]), 6
        else:
            return int(week6_end_day[4:6]), 1
    raise Exception('日期错误')


def get_month_week_str(yyyymmdd: str) -> Tuple[str, str]:
    month, week = get_month_week(yyyymmdd)
    return f'{month}月', f'{yyyymmdd[:4]}年{month}月第{week}周'


def get_month_str(yyyymmdd: str) -> str:
    month, _ = get_month_week(yyyymmdd)
    return f'{month}月'


def get_week_str(yyyymmdd: str) -> str:
    month, week = get_month_week(yyyymmdd)
    return f'第{week}周'


def get_week_range(yyyymmdd: str) -> Tuple[str, str]:
    week_str = get_week_str(yyyymmdd)
    week_begin_day = yyyymmdd
    week_end_day = yyyymmdd
    _yyyymmdd = yyyymmdd
    while True:
        _yyyymmdd = next_day(_yyyymmdd)
        if week_str == get_week_str(_yyyymmdd):
            week_end_day = _yyyymmdd
        else:
            break
    _yyyymmdd = yyyymmdd
    while True:
        _yyyymmdd = before_day(_yyyymmdd)
        if week_str == get_week_str(_yyyymmdd):
            week_begin_day = _yyyymmdd
        else:
            break
    return week_begin_day, week_end_day


if __name__ == '__main__':
    yyyymmdd = '20210101'
    print(before_day(yyyymmdd))
    print(get_week_range(yyyymmdd))
    # yyyymmdd = '20201225'
    # for i in range(20):
    #     yyyymmdd = next_day(yyyymmdd)
    #     _, s = get_month_week_str(yyyymmdd)
    #     week = datetime.datetime.strptime(yyyymmdd, "%Y%m%d").isoweekday()
    #     week_cn = {1: '一', 2: '二', 3: '三', 4: '四', 5: '五', 6: '六', 7: '日'}[week]
    #     print(f'{yyyymmdd},星期{week_cn},{s}')
