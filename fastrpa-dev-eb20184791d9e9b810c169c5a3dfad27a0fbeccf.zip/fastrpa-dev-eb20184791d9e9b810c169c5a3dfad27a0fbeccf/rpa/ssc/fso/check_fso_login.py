import logging
import re
from time import sleep
from typing import Dict, List, Tuple

import requests
import urllib3

FSO_DOMAIN_URL = 'fso.sinopec.com'
FSO_START_URL = f'https://{FSO_DOMAIN_URL}'  # 开始界面，由此地址重定向至登录页面

# 禁止错误日志 InsecureRequestWarning: Unverified HTTPS request is being made to host 'auth.siam.sinopec.com'
urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

# 规避错误 Max retries exceeded with url（20210105更新：经排查为DNS问题，如需使用自定义DNS，需要修改hosts文件）
requests.adapters.DEFAULT_RETRIES = 1


def get_fso_login_url(session: requests.Session, url: str = FSO_START_URL, cookies={}, redirect_times=5) -> Tuple[str, Dict[str, str]]:
    # 打开网址，并返回cookie
    logging.info(url)
    for _ in range(15):
        try:
            response = session.get(url=url, verify=False, allow_redirects=False, cookies=cookies, headers={'Connection': 'close', })
            status_code: int = response.status_code
            _cookies: Dict[str, str] = response.cookies.get_dict()
            cookies = {**cookies, **_cookies}  # 合并cookie
            if(status_code in (301, 302, 303, 307, 308)) and redirect_times > 1:  # 重定向
                url = response.headers['Location']
                if url.startswith('/'):
                    url = f'{FSO_START_URL}{url}'
                return get_fso_login_url(session, url, cookies, redirect_times - 1)
            else:
                return url, cookies
        except requests.exceptions.ConnectionError:
            sleep(1)
    else:
        raise Exception('校验FSO登录信息错误，FSO网站接口返回结果非预期')  # 登录失败


def check_fso_login(fso_username: str, fso_passowrd: str):
    # 如FSO地址不能访问，请检查DNS设置
    fso_login_url = ''
    cookies: Dict[str, str] = {}
    with requests.Session() as session:
        session.trust_env = False  # 禁用代理
        # session.keep_alive = False
        fso_login_url, cookies = get_fso_login_url(session, FSO_START_URL)
    data_body = {
        "j_username": fso_username,
        "j_password": fso_passowrd,
        "j_checkcode": "验证码",
        "j_authMethodID": "1",
    }
    try:
        with requests.Session() as session:
            session.trust_env = False  # 禁用代理
            # session.keep_alive = False
            response = session.post(url=fso_login_url, verify=False, allow_redirects=False, data=data_body, cookies=cookies, timeout=10, headers={'Connection': 'close', })
            if response.status_code == 200:
                html: str = response.text
                account_locked_minutes = re.findall(r'account is locked. Please retry after (\d+) minutes', html)
                if len(account_locked_minutes) > 0:
                    raise Exception(f'FSO账号被锁定，{int(account_locked_minutes[0])}分钟后解锁')
                retries: List[str] = re.findall(r'Login was failed, and you have (\d+)', html)
                if len(retries) > 0:
                    raise Exception(f'FSO账号信息错误，您还有{int(retries[0])}次重试机会')
                if html.find("No verification code. Please enter it.") > 0:
                    raise Exception('FSO要求输入验证码，请登录FSO系统解锁账号')
                if html.find("Wrong user name or password") > 0:
                    raise Exception('FSO账号或者密码错误')
            if response.status_code == 302:
                return True
    except requests.Timeout:
        raise Exception('验证FSO登录信息超时')
    except requests.exceptions.ConnectionError as e:
        logging.error(e)
    return False


if __name__ == '__main__':
    check_fso_login('test', 'test')  # FSO系统确实有test账号
