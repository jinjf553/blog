"""导出组合逻辑查询103_T69-2"""
import logging
from typing import Any, List

import pyperclip
from rpa.fastrpa.adtable import AdTable
from rpa.fastrpa.sap.grid_view_ctrl import GridViewCtrl
from rpa.fastrpa.sap.session import attach_sap
from rpa.ssc.sap.query import export_query, query_selection
from rpa.ssc.sap.utils import init_sap_id


def enter_103(session: Any) -> None:
    """进入103"""
    session.findById("wnd[0]").maximize()
    session.findById("wnd[0]/tbar[0]/okcd").text = "/n S_PH0_48000513"
    session.findById("wnd[0]").sendVKey(0)
    session.findById("wnd[1]/usr/cmbDYNP4100-DD_WORKSPACE").setFocus()
    session.findById("wnd[1]/usr/cmbDYNP4100-DD_WORKSPACE").key = "2"  # 全局区域（跨集团）
    session.findById("wnd[1]/usr/cmbDYNP4100-DD_USERGROUP").setFocus()
    session.findById("wnd[1]/usr/cmbDYNP4100-DD_USERGROUP").key = "103"  # SAP_HR查询   （ZHR_ALL）
    session.findById("wnd[1]/usr/tblSAPLAQ_INT_FUNCTIONSTCH_FUNCAREAS").getAbsoluteRow(1).selected = -1
    session.findById("wnd[1]/usr/tblSAPLAQ_INT_FUNCTIONSTCH_FUNCAREAS/txtDYNP4100_TC_FUNCAREAS-NAME[0,1]").setFocus()
    session.findById("wnd[1]/usr/tblSAPLAQ_INT_FUNCTIONSTCH_FUNCAREAS/txtDYNP4100_TC_FUNCAREAS-NAME[0,1]").caretPosition = 0
    session.findById("wnd[1]/tbar[0]/btn[0]").press()  # 信息集查询（信息集：SAP_HR查询）


def throw_exception_when_query_changed(session: Any):
    raise Exception('组合逻辑查询变式103___T69-2列ID与开发时不匹配')


def fill_103(session: Any, staff_rngs: List[str], key_date: str, begin_date='', end_date='') -> None:
    """填充103"""
    session.findById("wnd[0]/usr/subSUB_MAIN:SAPLAQ_ADHOC:0210/subSUB_APPLICATION:SAPLHR_QUERY_APPL_AREA:0122/subSUB:SAPLHR_QUERY_APPL_AREA:0121/btnDYNP121-EVALUATION_PERIOD_TEXT").press()  # 点击报告时间
    if key_date != '':
        session.findById("wnd[0]/usr/subSUB_MAIN:SAPLAQ_ADHOC:0210/subSUB_APPLICATION:SAPLHR_QUERY_APPL_AREA:0122/subSUB:SAPLHR_QUERY_APPL_AREA:0120/cmbDD_DATE").key = "7"  # 选择关键日期
        session.findById("wnd[0]/usr/subSUB_MAIN:SAPLAQ_ADHOC:0210/subSUB_APPLICATION:SAPLHR_QUERY_APPL_AREA:0122/subSUB:SAPLHR_QUERY_APPL_AREA:0120/ctxtG_APPL_AREA-BEGDA").text = key_date  # 填充关键日期
    else:
        session.findById("wnd[0]/usr/subSUB_MAIN:SAPLAQ_ADHOC:0210/subSUB_APPLICATION:SAPLHR_QUERY_APPL_AREA:0122/subSUB:SAPLHR_QUERY_APPL_AREA:0120/cmbDD_DATE").key = "8"  # 其他期间
        session.findById("wnd[0]/usr/subSUB_MAIN:SAPLAQ_ADHOC:0210/subSUB_APPLICATION:SAPLHR_QUERY_APPL_AREA:0122/subSUB:SAPLHR_QUERY_APPL_AREA:0120/ctxtG_APPL_AREA-BEGDA").text = begin_date  # 开始日期
        session.findById("wnd[0]/usr/subSUB_MAIN:SAPLAQ_ADHOC:0210/subSUB_APPLICATION:SAPLHR_QUERY_APPL_AREA:0122/subSUB:SAPLHR_QUERY_APPL_AREA:0120/ctxtG_APPL_AREA-ENDDA").text = end_date  # 结束日期
    grid_view_ctrl_id = 'wnd[0]/usr/subSUB_MAIN:SAPLAQ_ADHOC:0210/subSUB_SELECTION:SAPLAQ_ADHOC:0310/cntlSEL_DEF_CONTAINER/shellcont/shell'
    grid_view_ctrl = GridViewCtrl(session, grid_view_ctrl_id)
    grid_view_ctrl['字段名称'].find('人事范围').same_line('更多值 ').press_button()
    pyperclip.copy('\r\n'.join(staff_rngs))  # 复制到剪切板
    session.findById("wnd[1]/tbar[0]/btn[16]").press()
    session.findById("wnd[1]/tbar[0]/btn[24]").press()  # 粘贴
    try:
        session.findById("wnd[2]/tbar[0]/btn[0]").press()
    except Exception:  # nosec
        pass
    session.findById("wnd[1]/tbar[0]/btn[8]").press()
    session.findById("wnd[0]/tbar[1]/btn[8]").press()  # 输出按钮


HEADER_IDS: List[str] = ['VALUE1273', 'TEXT1273', 'VALUE2', 'VALUE3', 'VALUE4', 'VALUE5', 'TEXT6', 'VALUE7', 'TEXT7',
                         'TEXT8', 'TEXT9', 'VALUE1245', 'VALUE1246', 'VALUE1247', 'VALUE1248', 'VALUE1251', 'TEXT1251',
                         'VALUE1252', 'TEXT1252', 'VALUE1253', 'TEXT1253', 'VALUE15', 'VALUE16', 'VALUE17', 'VALUE18',
                         'VALUE21', 'TEXT21', 'VALUE23', 'VALUE24', 'TEXT24', 'VALUE26', 'VALUE27', 'TEXT27', 'VALUE30',
                         'TEXT30', 'VALUE31', 'TEXT31', 'VALUE29', 'TEXT29', 'VALUE40', 'TEXT40', 'VALUE36', 'TEXT36',
                         'VALUE37', 'TEXT37', 'VALUE38', 'TEXT38', 'TEXT32', 'TEXT28', 'VALUE22', 'TEXT22', 'VALUE39',
                         'TEXT39', 'VALUE19', 'TEXT19', 'TEXT34', 'TEXT35', 'VALUE362', 'VALUE363', 'VALUE364', 'VALUE365',
                         'TEXT366', 'TEXT367', 'TEXT368', 'VALUE369']


def export_103_t69_2(session: Any, staff_rngs: List[str], key_date: str, begin_date='', end_date='') -> AdTable:
    """导出103
       ------------------
       入参：
       session: SAP SESSION，如为None，则新打开SAP
       staff_rngs: 人事范围数组
       key_date: 关键日期
       ------------------
       返回值：
       AdTable，可通过.wb访问Workbook，或.ws访问Worksheet
       ------------------
       调用样例：
       _table: AdTable = export_103(None, ['01576547'], '20200301')
       _table.filename = '模板_103'
       _table.save_to('x:/') # 保存模板至x:/下
    """
    if key_date != '':
        logging.info(f'导出组合逻辑查询103_t69_2，人事范围：{staff_rngs}，关键日期：{key_date}')
        if key_date.isdigit() is False:
            raise Exception(f'组合逻辑查询日期必须为纯数字，当前值：{key_date}')
    else:
        logging.info(f'导出组合逻辑查询103_t69_2，人事范围：{staff_rngs}，开始日期：{begin_date}，结束日期：{end_date}')
        if begin_date.isdigit() is False or end_date.isdigit() is False:
            raise Exception(f'组合逻辑查询日期必须为纯数字，当前值：{begin_date}-{end_date}')
    if all(map(lambda v: v == '', staff_rngs)) is True:
        raise Exception('人事范围全为空值，请检查模板人事范围是否填充')
    if session is None:
        session = attach_sap()
    elif isinstance(session, str):
        session = attach_sap(session)
    enter_103(session)  # 进入103信息集查询屏
    query_selection(session, '___T69-2', throw_exception_when_query_changed, HEADER_IDS)  # 勾选103选项
    fill_103(session, staff_rngs, key_date, begin_date, end_date)  # 填入人事范围和关键日期，并查询
    _table: AdTable = export_query(session, query_name='___T69-2')
    _table['A'].apply(init_sap_id)
    _table.filename = 'T69-2'
    return _table


# example
if __name__ == '__main__':
    sap_ids = ['X040']
    _table: AdTable = export_103_t69_2(None, sap_ids, '', '20200701', '99991231')
    _table.save_to('x:/')
