"""S_AHR_61016503 人员配备情况"""
import logging
from pathlib import Path
from time import sleep
from typing import Any, List, Optional

import pyperclip
from pythoncom import com_error  # pylint: disable=fixme, no-name-in-module
from rpa.fastrpa.adtable import AdTable
from rpa.fastrpa.sap.session import SapWithoutClose
from rpa.fastrpa.tempdir import gentempdir
from rpa.fastrpa.utils.peek_encoding import peek_file_encoding
from rpa.ssc.sap.query import parse_query_string


def export_original_table(session: Any) -> AdTable:
    logging.info('正在导出文件：S_AHR_61016503')
    lt_org = AdTable('S_AHR_61016503')
    logging.info('表格数据复制到剪切板')
    session.findById("wnd[0]/tbar[1]/btn[9]").press()
    # session.findById("wnd[1]/usr/subSUBSCREEN_STEPLOOP:SAPLSPO5:0150/sub:SAPLSPO5:0150/radSPOPLI-SELFLAG[4,0]").select()  # 勾选[保存到剪切板]
    # session.findById("wnd[1]/tbar[0]/btn[0]").press()  # 确定
    # query_string = pyperclip.paste()
    session.findById("wnd[1]/usr/subSUBSCREEN_STEPLOOP:SAPLSPO5:0150/sub:SAPLSPO5:0150/radSPOPLI-SELFLAG[0,0]").select()  # 勾选[未转换的]
    session.findById("wnd[1]/tbar[0]/btn[0]").press()  # 保存到本地文件
    output_dir = gentempdir()
    query_string_filename = Path(output_dir).joinpath('query_string.txt').as_posix()
    session.findById("wnd[1]/usr/ctxtDY_PATH").text = output_dir  # 目录
    session.findById("wnd[1]/usr/ctxtDY_FILENAME").text = "query_string.txt"  # 文件名（ANSI编码）
    session.findById("wnd[1]/usr/ctxtDY_FILENAME").caretPosition = 16
    if Path(query_string_filename).exists() is True:
        session.findById("wnd[1]/tbar[0]/btn[11]").press()  # 覆盖
    else:
        session.findById("wnd[1]/tbar[0]/btn[0]").press()  # 生成
    for _ in range(60):  # 1分钟，等待文件写完
        sap_status = session.findById("wnd[0]/sbar/pane[0]").text
        if '字节已传输，代码页为' in sap_status:
            break
        else:
            sleep(1)
    # WARN GUI安全性窗口已禁止弹出
    query_string_encoding = peek_file_encoding(Path(output_dir).joinpath('query_string.txt').as_posix())
    query_string = Path(output_dir).joinpath('query_string.txt').read_text(encoding=query_string_encoding)
    logging.info('解析SAP Query文本')
    headers, table = parse_query_string(query_string)
    for column, header in enumerate(headers, start=1):
        lt_org[column][1].value = header
    for rn, row in enumerate(table, start=2):
        for column, value in enumerate(row, start=1):
            lt_org[column][rn].value = value
    logging.info('导出文件：S_AHR_61016503/人员配备情况 成功')
    return lt_org


def export_s_ahr_6106503(org_ids: List[str], key_date: str, normal_screen: bool = False, path: str = 'ORGEH', depth: int = 0) -> Optional[AdTable]:
    """[summary]

    Args:
        org_ids (List[str]): 机构ID数组
        key_date (str): 关键日期
        normal_screen (bool, optional): 标准选择屏幕标识. Defaults to False.
        path (str, optional): 评估路径. Defaults to ''.
        depth (int, optional): 显示深度. Defaults to 0.

    Returns:
        Optional[AdTable]: 遇到错误返回None，其余返回AdTable
    """
    with SapWithoutClose() as session:
        logging.info('填入事务码：S_AHR_61016503')
        session.findById("wnd[0]/tbar[0]/okcd").text = 'S_AHR_61016503'
        session.findById("wnd[0]").sendVKey(0)
        session.findById("wnd[0]/usr/ctxtPCHOBJID-LOW").text = "12345678"  # 先填充机构编码，再清空，否则会报错“警告：将编辑对象类型的所有对象类型”
        session.findById("wnd[0]/usr/btn%_PCHOBJID_%_APP_%-VALU_PUSH").press()  # 多项选择
        try:
            session.findById("wnd[1]/tbar[0]/btn[0]").press()  # 选择计划版本窗口(第一次时弹出，后续不弹出)
        except com_error:  # pylint: disable=fixme, no-member
            pass
        session.findById("wnd[1]/tbar[0]/btn[16]").press()  # 清空
        pyperclip.copy('\r\n'.join(org_ids))  # 复制机构编码到剪切板
        logging.info(f'填入机构编码:{org_ids}')
        session.findById("wnd[1]/tbar[0]/btn[24]").press()  # 粘贴
        session.findById("wnd[1]/tbar[0]/btn[8]").press()  # 确认
        session.findById("wnd[0]/usr/ctxtPCHOBEG").text = key_date  # 关键日期
        if normal_screen is True:
            session.findById("wnd[0]/usr/chkSEL_BOX").selected = -1  # 勾选【标准选择屏幕】选择框
            session.findById("wnd[0]/tbar[1]/btn[8]").press()  # 执行
            session.findById("wnd[0]/usr/ctxtPCHWEGID").text = path  # 评估路径
            session.findById("wnd[0]/usr/txtPCHDEPTH").text = str(depth)  # 显示深度
            logging.info('点击执行')
            session.findById("wnd[0]/tbar[1]/btn[8]").press()  # 执行
            sap_status = session.findById("wnd[0]/sbar/pane[0]").text
            if '不允许评估路径' in sap_status:
                logging.error(sap_status)
                return None
        else:
            logging.info('点击执行')
            session.findById("wnd[0]/tbar[1]/btn[8]").press()  # 执行
        try:
            session.findById("wnd[1]/tbar[0]/btn[0]").press()  # 选择计划版本窗口(第一次时弹出，后续不弹出)
        except com_error:  # pylint: disable=fixme, no-member
            pass
        try:
            session.findById("wnd[0]/tbar[1]/btn[8]").press()
            logging.error('机构编码不存在')
            return None
        except com_error:  # pylint: disable=fixme, no-member
            pass
        sap_title = session.findById("wnd[0]").Text
        if '运行时间错误' in sap_title:
            logging.error(f'查询超时：{sap_title}')
            return None
        session.findById("wnd[0]/tbar[1]/btn[33]").press()  # 选择
        session.findById("wnd[1]/usr/ssubD0500_SUBSCREEN:SAPLSLVC_DIALOG:0501/cntlG51_CONTAINER/shellcont/shell").contextMenu()  # 右键菜单
        session.findById("wnd[1]/usr/ssubD0500_SUBSCREEN:SAPLSLVC_DIALOG:0501/cntlG51_CONTAINER/shellcont/shell").selectContextMenuItem("&FIND")  # 查找
        session.findById("wnd[2]/usr/txtGS_SEARCH-VALUE").text = "/CS"  # 检索项
        session.findById("wnd[2]/usr/cmbGS_SEARCH-SEARCH_ORDER").key = "0"  # 搜索方向:由表格开头向下
        session.findById("wnd[2]/usr/chkGS_SEARCH-EXACT_WORD").selected = -1  # 仅查找整个词或值
        session.findById("wnd[2]/tbar[0]/btn[0]").press()  # 确定
        try:
            session.findById("wnd[2]/tbar[0]/btn[12]").press()  # 取消(此时定位到第一个匹配项，点击取消，停止搜索)
            # 在特定机器上需要点击取消按钮
        except com_error:  # pylint: disable=fixme, no-member
            pass
        session.findById("wnd[1]/usr/ssubD0500_SUBSCREEN:SAPLSLVC_DIALOG:0501/cntlG51_CONTAINER/shellcont/shell").clickCurrentCell()  # 双击匹配项
        return export_original_table(session)


if __name__ == '__main__':
    lt_org = export_s_ahr_6106503(['36150572'], '20201001')
    if lt_org is not None:
        lt_org.save_to('x:/')
