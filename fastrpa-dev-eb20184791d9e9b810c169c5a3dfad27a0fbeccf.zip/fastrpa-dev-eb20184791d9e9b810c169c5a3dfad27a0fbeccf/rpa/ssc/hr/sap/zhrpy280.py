"""zhrpy280 进入SAP，检查人员编号姓名是否一致（20201215更新，事务码zhrpy280失效，使用组合逻辑查询103替代）"""

import logging
from typing import Dict, List

from rpa.fastrpa.adtable import load_from_xlsx_file
from rpa.ssc.hr.sap.export_103_z280 import export_103_z280
from rpa.ssc.sap.utils import init_sap_id


def check_zhrpy280(staffs: List[Dict]) -> List:
    """staffs: [{'staff_id': 'xxxxxxx'}, 'staff_name': 'xxx'},{'staff_id': 'xxxxxxx'}, 'staff_name': 'xxx'},]
    """
    staff_ids = [staff['staff_id'] for staff in staffs]
    lt_280 = export_103_z280(None, staff_ids)
    df_280 = lt_280.to_dataframe()
    err_staff_ids = []
    for staff in staffs:
        staff_id = staff['staff_id']
        staff_name = staff['staff_name']
        df_tmp = df_280[df_280['A'] == staff_id]
        if df_tmp.empty is True:  # 人员编号有误
            err_staff_ids.append(staff_id)
        elif df_tmp['B'].values[0].replace('・', '·') != staff_name:  # 人员编号-姓名不一致
            err_staff_ids.append(staff_id)
    return err_staff_ids


def check_zhrpy280_file(filename: str) -> bool:
    lt = load_from_xlsx_file(filename, skip_header=4)
    lt.del_blank_rows_by_column('B')
    df = lt.to_dataframe()
    for rn in df.index:
        lt['D'][rn].value = ''
    staffs = [{'staff_id': init_sap_id(df['B'][rn]), 'staff_name': df['C'][rn]} for rn in df.index]
    err_staff_ids = check_zhrpy280(staffs)
    if len(err_staff_ids) == 0:
        return True
    else:
        logging.error(err_staff_ids)
        for rn in df.index:
            if init_sap_id(df['B'][rn]) in err_staff_ids:
                lt['D'][rn].value = '人员信息有误'
                lt['B'][rn].cmt('red', '人员信息有误')
                lt['C'][rn].cmt('red', '人员信息有误')
        lt.save(filename)
        return False


if __name__ == '__main__':
    check_zhrpy280_file('x:/rpa/tmp/202106/20210620/170320/tmp.xlsx')
