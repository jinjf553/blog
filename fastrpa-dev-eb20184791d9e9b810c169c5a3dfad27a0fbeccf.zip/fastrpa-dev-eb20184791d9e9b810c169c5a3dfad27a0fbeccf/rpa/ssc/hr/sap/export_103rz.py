"""导出组合逻辑查询103（入职流程用）"""
import time
from typing import Any, List

import pyperclip
from rpa.config import TEMPLATE_DIR
from rpa.fastrpa.adtable import AdTable
from rpa.fastrpa.sap.session import attach_sap
from rpa.public.check_card import more_icon
from rpa.ssc.hr.sap.export_103 import enter_103
from rpa.ssc.sap.query import export_query, query_selection
from rpa.ssc.sap.utils import init_sap_id


def select_103rz(session: Any) -> None:
    """勾选103（入职流程用）"""
    raise Exception('103列顺序发生变化，请联系RPA管理员重新勾选')
    # enter_103(session)
    # temp = "wnd[0]/shellcont[1]/shell/shellcont[0]/shell/shellcont[1]/shell[1]"
    # session.findById(temp).expandNode("          2")
    # session.findById(temp).changeCheckbox("          3", "C          3", -1)
    # session.findById(temp).changeCheckbox("          3", "C          4", -1)
    # session.findById(temp).itemContextMenu("          3", "C          4")
    # session.findById(temp).selectContextMenuItem("OUTPUT_BOTH")
    # session.findById(temp).expandNode("          4")
    # session.findById(temp).changeCheckbox("          6", "C          4", -1)
    # session.findById(temp).changeCheckbox("          7", "C          4", -1)
    # session.findById(temp).changeCheckbox("          8", "C          4", -1)
    # session.findById(temp).changeCheckbox("          9", "C          4", -1)
    # session.findById(temp).changeCheckbox("         10", "C          4", -1)
    # session.findById(temp).changeCheckbox("         11", "C          4", -1)
    # session.findById(temp).itemContextMenu("         11", "C          4")
    # session.findById(temp).selectContextMenuItem("OUTPUT_BOTH")
    # session.findById(temp).changeCheckbox("         12", "C          4", -1)
    # session.findById(temp).changeCheckbox("         13", "C          4", -1)
    # session.findById(temp).expandNode("         19")
    # session.findById(temp).changeCheckbox("         20", "C          4", -1)
    # session.findById(temp).changeCheckbox("         21", "C          4", -1)
    # session.findById(temp).changeCheckbox("         22", "C          4", -1)
    # session.findById(temp).changeCheckbox("         23", "C          4", -1)
    # session.findById(temp).changeCheckbox("         28", "C          4", -1)
    # session.findById(temp).itemContextMenu("         28", "C          4")
    # session.findById(temp).selectContextMenuItem("OUTPUT_ONLYVALUE")
    # session.findById(temp).changeCheckbox("         29", "C          4", -1)
    # session.findById(temp).itemContextMenu("         29", "C          4")
    # session.findById(temp).selectContextMenuItem("OUTPUT_BOTH")
    # session.findById(temp).changeCheckbox("         31", "C          4", -1)
    # session.findById(temp).itemContextMenu("         31", "C          4")
    # session.findById(temp).selectContextMenuItem("OUTPUT_ONLYVALUE")
    # session.findById(temp).changeCheckbox("         32", "C          4", -1)
    # session.findById(temp).itemContextMenu("         32", "C          4")
    # session.findById(temp).selectContextMenuItem("OUTPUT_BOTH")
    # session.findById(temp).changeCheckbox("         35", "C          4", -1)
    # session.findById(temp).itemContextMenu("         35", "C          4")
    # session.findById(temp).selectContextMenuItem("OUTPUT_BOTH")
    # session.findById(temp).changeCheckbox("         36", "C          4", -1)
    # session.findById(temp).itemContextMenu("         36", "C          4")
    # session.findById(temp).selectContextMenuItem("OUTPUT_BOTH")
    # session.findById(temp).changeCheckbox("         34", "C          4", -1)
    # session.findById(temp).itemContextMenu("         34", "C          4")
    # session.findById(temp).selectContextMenuItem("OUTPUT_BOTH")
    # session.findById(temp).changeCheckbox("         45", "C          4", -1)
    # session.findById(temp).itemContextMenu("         45", "C          4")
    # session.findById(temp).selectContextMenuItem("OUTPUT_BOTH")
    # session.findById(temp).changeCheckbox("         41", "C          4", -1)
    # session.findById(temp).itemContextMenu("         41", "C          4")
    # session.findById(temp).selectContextMenuItem("OUTPUT_BOTH")
    # session.findById(temp).changeCheckbox("         42", "C          4", -1)
    # session.findById(temp).itemContextMenu("         42", "C          4")
    # session.findById(temp).selectContextMenuItem("OUTPUT_BOTH")
    # session.findById(temp).changeCheckbox("         43", "C          4", -1)
    # session.findById(temp).itemContextMenu("         43", "C          4")
    # session.findById(temp).selectContextMenuItem("OUTPUT_BOTH")
    # session.findById(temp).changeCheckbox("         37", "C          4", -1)
    # session.findById(temp).changeCheckbox("         33", "C          4", -1)
    # session.findById(temp).changeCheckbox("         27", "C          4", -1)
    # session.findById(temp).itemContextMenu("         27", "C          4")
    # session.findById(temp).selectContextMenuItem("OUTPUT_BOTH")
    # session.findById(temp).changeCheckbox("         44", "C          4", -1)
    # session.findById(temp).itemContextMenu("         44", "C          4")
    # session.findById(temp).selectContextMenuItem("OUTPUT_BOTH")
    # session.findById(temp).changeCheckbox("         39", "C          4", -1)
    # session.findById(temp).changeCheckbox("         40", "C          4", -1)
    # session.findById(temp).expandNode("        387")
    # session.findById(temp).changeCheckbox("        389", "C          4", -1)
    # session.findById(temp).changeCheckbox("        390", "C          4", -1)
    # session.findById(temp).changeCheckbox("        391", "C          4", -1)
    # session.findById(temp).changeCheckbox("        392", "C          4", -1)
    # session.findById(temp).changeCheckbox("        393", "C          4", -1)
    # session.findById(temp).changeCheckbox("        394", "C          4", -1)
    # session.findById(temp).changeCheckbox("        395", "C          4", -1)
    # session.findById(temp).changeCheckbox("        396", "C          4", -1)
    # session.findById(temp).changeCheckbox("        397", "C          4", -1)
    # session.findById(temp).changeCheckbox("        398", "C          4", -1)
    # session.findById(temp).changeCheckbox("        399", "C          4", -1)
    # session.findById(temp).changeCheckbox("        400", "C          4", -1)
    # session.findById(temp).changeCheckbox("        401", "C          4", -1)
    # session.findById(temp).itemContextMenu("        401", "C          4")
    # session.findById(temp).selectContextMenuItem("OUTPUT_BOTH")
    # session.findById(temp).changeCheckbox("        402", "C          4", -1)
    # session.findById(temp).itemContextMenu("        402", "C          4")
    # session.findById(temp).selectContextMenuItem("OUTPUT_BOTH")
    # session.findById(temp).changeCheckbox("        406", "C          4", -1)
    # session.findById(temp).itemContextMenu("        406", "C          4")
    # session.findById(temp).selectContextMenuItem("OUTPUT_ONLYVALUE")
    # session.findById(temp).changeCheckbox("        405", "C          4", -1)
    # session.findById(temp).changeCheckbox("        409", "C          4", -1)
    # session.findById(temp).changeCheckbox("        410", "C          4", -1)
    # session.findById(temp).expandNode("        150")
    # session.findById(temp).changeCheckbox("        152", "C          4", -1)
    # session.findById(temp).changeCheckbox("        153", "C          4", -1)
    # session.findById(temp).changeCheckbox("        154", "C          4", -1)
    # session.findById(temp).changeCheckbox("        155", "C          4", -1)
    # session.findById(temp).changeCheckbox("        158", "C          4", -1)
    # session.findById(temp).changeCheckbox("        159", "C          4", -1)
    # session.findById(temp).itemContextMenu("        157", "C          4")
    # session.findById(temp).selectContextMenuItem("OUTPUT_ONLYVALUE")
    # #职务（岗位）作业?
    # # session.findById(temp).expandNode("         19")
    # # session.findById(temp).itemContextMenu("         37", "C          4")
    # # session.findById(temp).selectContextMenuItem("OUTPUT_ONLYVALUE")
    # session.findById(temp).expandNode("        417")
    # session.findById(temp).changeCheckbox("        419", "C          4", -1)
    # session.findById(temp).changeCheckbox("        420", "C          4", -1)
    # session.findById(temp).changeCheckbox("        421", "C          4", -1)
    # session.findById(temp).changeCheckbox("        422", "C          4", -1)
    # session.findById(temp).changeCheckbox("        424", "C          4", -1)
    # session.findById(temp).itemContextMenu("        424", "C          4")
    # session.findById(temp).selectContextMenuItem("OUTPUT_BOTH")
    # session.findById(temp).changeCheckbox("        425", "C          4", -1)
    # session.findById(temp).changeCheckbox("        426", "C          4", -1)
    # session.findById(temp).expandNode("        366")
    # session.findById(temp).changeCheckbox("        367", "C          4", -1)
    # session.findById(temp).changeCheckbox("        368", "C          4", -1)
    # session.findById(temp).changeCheckbox("        370", "C          4", -1)
    # session.findById(temp).changeCheckbox("        371", "C          4", -1)
    # session.findById(temp).changeCheckbox("        372", "C          4", -1)
    # session.findById(temp).changeCheckbox("        373", "C          4", -1)
    # session.findById(temp).changeCheckbox("        375", "C          4", -1)
    # session.findById(temp).changeCheckbox("         26", "C          4", -1)
    # session.findById(temp).itemContextMenu("         26", "C          4")
    # session.findById(temp).selectContextMenuItem("OUTPUT_ONLYVALUE")
    # session.findById(temp).expandNode("       1261")
    # session.findById(temp).changeCheckbox("       1268", "C          4", -1)
    # session.findById(temp).itemContextMenu("       1268", "C          4")
    # session.findById(temp).selectContextMenuItem("OUTPUT_ONLYVALUE")
    # session.findById(temp).changeCheckbox("       1269", "C          4", -1)
    # session.findById(temp).itemContextMenu("       1269", "C          4")
    # session.findById(temp).selectContextMenuItem("OUTPUT_ONLYVALUE")
    # session.findById(temp).changeCheckbox("       1270", "C          4", -1)
    # session.findById(temp).itemContextMenu("       1270", "C          4")
    # session.findById(temp).selectContextMenuItem("OUTPUT_ONLYVALUE")
    # session.findById(temp).expandNode("        132")
    # session.findById(temp).changeCheckbox("        137", "C          4", -1)
    # session.findById(temp).expandNode("        160")
    # session.findById(temp).changeCheckbox("        166", "C          4", -1)
    # session.findById(temp).expandNode("        230")
    # session.findById(temp).changeCheckbox("        236", "C          4", -1)
    # session.findById(temp).expandNode("        238")
    # session.findById(temp).changeCheckbox("        245", "C          4", -1)
    # session.findById(temp).expandNode("        278")
    # session.findById(temp).changeCheckbox("        283", "C          4", -1)
    # session.findById(temp).changeCheckbox("        284", "C          4", -1)
    # session.findById(temp).expandNode("        294")
    # session.findById(temp).changeCheckbox("        301", "C          4", -1)
    # # session.findById(temp).changeCheckbox("        302", "C          4", -1)
    # session.findById(temp).changeCheckbox("        303", "C          4", -1)


def fill_103rz(session: Any, staff_ids: List[str], key_date: str) -> None:
    """填充103（入职流程用）"""
    if key_date == "None" or not key_date:
        current_date = time.strftime("%d", time.localtime(time.time()))
        key_date = time.strftime("%Y%m01", time.localtime(time.time() + (32 - int(current_date)) * 24 * 60 * 60))
    more_icon(session, key_date)
    session.findById("wnd[1]/tbar[0]/btn[16]").press()
    pyperclip.copy('\r\n'.join(staff_ids))  # 复制到剪切板
    session.findById("wnd[1]/tbar[0]/btn[24]").press()
    session.findById("wnd[1]/tbar[0]/btn[8]").press()
    session.findById("wnd[0]/tbar[1]/btn[8]").press()


HEADER_IDS: List[str] = ['VALUE1273', 'TEXT1273', 'VALUE2', 'VALUE3', 'VALUE4', 'VALUE5', 'TEXT6', 'VALUE7', 'TEXT7',
                         'TEXT8', 'TEXT9', 'VALUE15', 'VALUE16', 'VALUE17', 'VALUE18', 'VALUE23', 'VALUE24', 'TEXT24',
                         'VALUE26', 'VALUE27', 'TEXT27', 'VALUE30', 'TEXT30', 'VALUE31', 'TEXT31', 'VALUE29', 'TEXT29',
                         'VALUE40', 'TEXT40', 'VALUE36', 'TEXT36', 'VALUE37', 'TEXT37', 'VALUE38', 'TEXT38', 'TEXT32',
                         'TEXT28', 'VALUE22', 'TEXT22', 'VALUE39', 'TEXT39', 'TEXT34', 'TEXT35', 'VALUE362', 'VALUE363',
                         'VALUE364', 'VALUE365', 'TEXT366', 'TEXT367', 'TEXT368', 'VALUE369', 'TEXT370', 'TEXT371',
                         'TEXT372', 'TEXT373', 'VALUE374', 'TEXT374', 'VALUE375', 'TEXT375', 'VALUE379', 'VALUE378',
                         'TEXT382', 'TEXT383', 'VALUE142', 'VALUE143', 'VALUE144', 'VALUE145', 'VALUE148', 'VALUE149',
                         'VALUE147', 'VALUE32', 'VALUE391', 'VALUE392', 'VALUE393', 'VALUE394', 'VALUE396', 'TEXT396',
                         'VALUE397', 'TEXT398', 'VALUE341', 'VALUE342', 'VALUE344', 'VALUE345', 'VALUE346', 'VALUE347',
                         'VALUE349', 'VALUE21', 'VALUE1251', 'VALUE1252', 'VALUE1253', 'TEXT129', 'VALUE155',
                         'VALUE219', 'TEXT263', 'TEXT264', 'VALUE279', 'VALUE281', 'VALUE282']


def export_103rz(session: Any, staff_ids: List[str], key_date: str) -> AdTable:
    """导出103（入职流程用）
       ------------------
       入参：
       session: SAP SESSION，如为None，则新打开SAP
       staff_ids: 人员编号数组
       key_date: 关键日期
       ------------------
       返回值：
       AdTable，可通过.wb访问Workbook，或.ws访问Worksheet
       ------------------
       调用样例：
       _table: AdTable = export_103(None, ['01576547'], '20200301')
       _table.filename = '模板_103rz'
       _table.save_to('x:/') # 保存模板至x:/下
    """
    session = attach_sap() if session is None else session
    enter_103(session)  # 进入103信息集查询屏
    query_selection(session, 'RPA_HR_103RZ_T', select_103rz, HEADER_IDS)  # 勾选103选项
    fill_103rz(session, staff_ids, key_date)  # 填入员工编号和关键日期，并查询
    _table: AdTable = export_query(session, template_file=f'{TEMPLATE_DIR}/模板_103_RZ.xlsx', query_name='RPA_HR_103RZ_2')
    _table['A'].apply(init_sap_id)
    return _table


# example
if __name__ == '__main__':
    _table: AdTable = export_103rz(None, ['00997235', '00997250', '00997305', '00997245'], '20210501')
    _table.save_to('x:/')
