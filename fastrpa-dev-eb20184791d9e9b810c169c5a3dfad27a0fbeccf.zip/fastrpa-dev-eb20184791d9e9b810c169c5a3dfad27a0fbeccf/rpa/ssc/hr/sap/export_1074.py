"""导出组合逻辑查询1074（建岗RPA使用）"""
import logging
from typing import Any, List, Optional

import pyperclip
from rpa.fastrpa.adtable import AdTable
from rpa.fastrpa.sap.grid_view_ctrl import GridViewCtrl
from rpa.fastrpa.sap.session import attach_sap
from rpa.ssc.sap.query import export_query, query_selection
from rpa.ssc.sap.utils import init_sap_id


def enter_1074(session: Any) -> None:
    """进入1074"""
    session.findById("wnd[0]").maximize()
    session.findById("wnd[0]/tbar[0]/okcd").text = "/n S_PH0_48000513"
    session.findById("wnd[0]").sendVKey(0)
    session.findById("wnd[1]/usr/cmbDYNP4100-DD_WORKSPACE").setFocus()
    session.findById("wnd[1]/usr/cmbDYNP4100-DD_WORKSPACE").key = "2"
    session.findById("wnd[1]/usr/cmbDYNP4100-DD_USERGROUP").setFocus()
    session.findById("wnd[1]/usr/cmbDYNP4100-DD_USERGROUP").key = "107"
    session.findById("wnd[1]/usr/tblSAPLAQ_INT_FUNCTIONSTCH_FUNCAREAS").getAbsoluteRow(1).selected = -1
    session.findById("wnd[1]/usr/tblSAPLAQ_INT_FUNCTIONSTCH_FUNCAREAS/txtDYNP4100_TC_FUNCAREAS-NAME[0,1]").setFocus()
    session.findById("wnd[1]/usr/tblSAPLAQ_INT_FUNCTIONSTCH_FUNCAREAS/txtDYNP4100_TC_FUNCAREAS-NAME[0,1]").caretPosition = 0
    session.findById("wnd[1]/tbar[0]/btn[0]").press()


def select_1074(session: Any) -> None:
    """勾选1074"""
    raise Exception('1074（----T89）列顺序发生变化，请联系RPA管理员重新勾选')


def fill_1074(session: Any, job_ids: List[str], *, key_date: Optional[str] = None, begin_date: Optional[str] = None, end_date: Optional[str] = None) -> None:
    """填充1074"""
    grid_view_ctrl_id = 'wnd[0]/usr/subSUB_MAIN:SAPLAQ_ADHOC:0212/subSUB_SELECTION:SAPLAQ_ADHOC:0310/cntlSEL_DEF_CONTAINER/shellcont/shell'
    grid_view_ctrl = GridViewCtrl(session, grid_view_ctrl_id)
    grid_view_ctrl['字段名称'].find('对象标识').same_line('更多值 ').press_button()
    session.findById("wnd[1]/tbar[0]/btn[16]").press()
    pyperclip.copy('\r\n'.join(job_ids))  # 复制到剪切板
    session.findById("wnd[1]/tbar[0]/btn[24]").press()  # 粘贴
    session.findById("wnd[1]/tbar[0]/btn[8]").press()
    session.findById("wnd[0]/usr/subSUB_MAIN:SAPLAQ_ADHOC:0212/subSUB_APPLICATION:SAPLHR_QUERY_APPL_AREA:0122/subSUB:SAPLHR_QUERY_APPL_AREA:0121/btnDYNP121-EVALUATION_PERIOD_TEXT").press()  # 报告期间
    session.findById("wnd[0]/usr/subSUB_MAIN:SAPLAQ_ADHOC:0212/subSUB_APPLICATION:SAPLHR_QUERY_APPL_AREA:0122/subSUB:SAPLHR_QUERY_APPL_AREA:0120/cmbDD_DATE").setFocus()
    if key_date is not None:
        session.findById("wnd[0]/usr/subSUB_MAIN:SAPLAQ_ADHOC:0212/subSUB_APPLICATION:SAPLHR_QUERY_APPL_AREA:0122/subSUB:SAPLHR_QUERY_APPL_AREA:0120/cmbDD_DATE").key = "7"  # 8 关键日期
        session.findById("wnd[0]/usr/subSUB_MAIN:SAPLAQ_ADHOC:0212/subSUB_APPLICATION:SAPLHR_QUERY_APPL_AREA:0122/subSUB:SAPLHR_QUERY_APPL_AREA:0120/ctxtG_APPL_AREA-BEGDA").text = key_date  # 关键日期
    else:
        session.findById("wnd[0]/usr/subSUB_MAIN:SAPLAQ_ADHOC:0212/subSUB_APPLICATION:SAPLHR_QUERY_APPL_AREA:0122/subSUB:SAPLHR_QUERY_APPL_AREA:0120/cmbDD_DATE").key = "8"  # 8 其他期间
        session.findById("wnd[0]/usr/subSUB_MAIN:SAPLAQ_ADHOC:0212/subSUB_APPLICATION:SAPLHR_QUERY_APPL_AREA:0122/subSUB:SAPLHR_QUERY_APPL_AREA:0120/ctxtG_APPL_AREA-BEGDA").text = begin_date  # 开始日期
        session.findById("wnd[0]/usr/subSUB_MAIN:SAPLAQ_ADHOC:0212/subSUB_APPLICATION:SAPLHR_QUERY_APPL_AREA:0122/subSUB:SAPLHR_QUERY_APPL_AREA:0120/ctxtG_APPL_AREA-ENDDA").text = end_date  # 结束日期
    session.findById("wnd[0]/tbar[1]/btn[8]").press()  # 输出


HEADER_IDS: List[str] = ['VALUE1', 'VALUE5', 'VALUE6', 'VALUE7', 'VALUE8', 'VALUE9', 'VALUE10', 'VALUE33',
                         'VALUE34', 'VALUE35', 'VALUE36', 'VALUE39', 'VALUE40', 'VALUE41', 'TEXT41', 'VALUE38']


def export_1074(session: Any, job_ids: List[str], *, key_date: Optional[str] = None, begin_date: Optional[str] = None, end_date: Optional[str] = None) -> AdTable:
    """导出1074
       ------------------
       入参：
       session: SAP SESSION，如为None，则新打开SAP
       job_ids: 机构编码
       key_date: 关键日期
       begin_date: 开始日期
       end_date: 结束日期
       ------------------
       返回值：
       AdTable，可通过.wb访问Workbook，或.ws访问Worksheet
       ------------------
       调用样例：
       _table: AdTable = export_1074(None, ['30260400', '30260401'], key_date='20210601')
       _table.filename = '模板_1074'
       _table.save_to('x:/') # 保存模板至x:/下
    """
    if key_date is not None:
        logging.info(f'导出组合逻辑查询1074，机构编号：{job_ids}，关键日期：{key_date}')
    elif begin_date is not None and end_date is not None:
        logging.info(f'导出组合逻辑查询1074，机构编号：{job_ids}，开始日期：{begin_date}，结束日期：{end_date}')
    else:
        raise Exception('【关键日期】和【开始日期-结束日期】至少有一个有值')
    if all(map(lambda v: v == '', job_ids)) is True:
        raise Exception('机构编号全为空值，请检查模板机构编号是否填充')
    if session is None:
        session = attach_sap('login_tx')  # 重要：用个人账号查询
    enter_1074(session)  # 进入1074信息集查询屏
    query_selection(session, '----T89', select_1074, HEADER_IDS)  # 勾选1074选项
    fill_1074(session, job_ids, key_date=key_date, begin_date=begin_date, end_date=end_date)  # 填入员工编号和日期，并查询
    _table: AdTable = export_query(session, query_name='----T89')
    _table.filename = '1074'
    _table['A'].apply(init_sap_id)
    # _table.filename = '1074'
    return _table


# example
if __name__ == '__main__':
    from rpa.fastrpa.log import config
    config()
    _table: AdTable = export_1074(None, ['30260400', '30260401'], begin_date='20210601', end_date='99991231')
    _table.save_to('x:/')
