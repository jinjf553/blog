"""导出组合逻辑查询103，用于手工拆单、自动拆单、岗位变动（事前备份）、二调/直调（事前备份）"""
import time
from typing import Any, List

import pyperclip
from rpa.config import TEMPLATE_DIR
from rpa.fastrpa.adtable import AdTable
from rpa.fastrpa.named_lock import ClipboardLock
from rpa.fastrpa.sap.session import attach_sap
from rpa.public.check_card import more_icon
from rpa.ssc.sap.query import export_query, query_selection
from rpa.ssc.sap.utils import init_sap_id


def enter_103(session: Any) -> None:
    """进入103"""
    session.findById("wnd[0]").maximize()
    session.findById("wnd[0]/tbar[0]/okcd").text = "/n S_PH0_48000513"
    session.findById("wnd[0]").sendVKey(0)
    session.findById("wnd[1]/usr/cmbDYNP4100-DD_WORKSPACE").setFocus()
    session.findById("wnd[1]/usr/cmbDYNP4100-DD_WORKSPACE").key = "2"  # 全局区域（跨集团）
    session.findById("wnd[1]/usr/cmbDYNP4100-DD_USERGROUP").setFocus()
    session.findById("wnd[1]/usr/cmbDYNP4100-DD_USERGROUP").key = "103"  # SAP_HR查询   （ZHR_ALL）
    session.findById("wnd[1]/usr/tblSAPLAQ_INT_FUNCTIONSTCH_FUNCAREAS").getAbsoluteRow(1).selected = -1
    session.findById("wnd[1]/usr/tblSAPLAQ_INT_FUNCTIONSTCH_FUNCAREAS/txtDYNP4100_TC_FUNCAREAS-NAME[0,1]").setFocus()
    session.findById("wnd[1]/usr/tblSAPLAQ_INT_FUNCTIONSTCH_FUNCAREAS/txtDYNP4100_TC_FUNCAREAS-NAME[0,1]").caretPosition = 0
    session.findById("wnd[1]/tbar[0]/btn[0]").press()  # 信息集查询（信息集：SAP_HR查询）


def select_103(session: Any) -> None:
    """勾选103"""
    raise Exception('103变式（_________111-2）列顺序发生变化，请联系RPA管理员重新勾选')


def fill_103(session: Any, staff_ids: List[str], key_date: str, key: str = '8', end_date: str = '99991231') -> None:
    """填充103"""
    more_icon(session, key_date, key, end_date)
    with ClipboardLock():
        pyperclip.copy('\r\n'.join(staff_ids))  # 复制到剪切板
        session.findById("wnd[1]/tbar[0]/btn[16]").press()
        session.findById("wnd[1]/tbar[0]/btn[24]").press()  # 粘贴
    try:
        session.findById("wnd[2]/tbar[0]/btn[0]").press()
    except Exception:  # nosec
        pass
    session.findById("wnd[1]/tbar[0]/btn[8]").press()
    session.findById("wnd[0]/tbar[1]/btn[8]").press()  # 输出按钮


HEADER_IDS: List[str] = ['VALUE1273', 'TEXT1273', 'VALUE2', 'VALUE3', 'VALUE4', 'VALUE5', 'TEXT6', 'VALUE7', 'TEXT7', 'TEXT8', 'TEXT9',
                         'VALUE15', 'VALUE16', 'VALUE17', 'VALUE18', 'VALUE23', 'VALUE24', 'TEXT24', 'VALUE26', 'VALUE27', 'TEXT27',
                         'VALUE30', 'TEXT30', 'VALUE31', 'TEXT31', 'VALUE29', 'TEXT29', 'VALUE40', 'TEXT40', 'VALUE36', 'TEXT36',
                         'VALUE37', 'TEXT37', 'VALUE38', 'TEXT38', 'TEXT32', 'TEXT28', 'VALUE22', 'TEXT22', 'VALUE39', 'TEXT39',
                         'TEXT34', 'TEXT35', 'VALUE362', 'VALUE363', 'VALUE364', 'VALUE365', 'TEXT366', 'TEXT367', 'TEXT368', 'VALUE369',
                         'TEXT370', 'TEXT371', 'TEXT372', 'TEXT373', 'VALUE374', 'TEXT374', 'VALUE375', 'TEXT375', 'VALUE379', 'VALUE378',
                         'TEXT382', 'TEXT383', 'VALUE142', 'VALUE143', 'VALUE144', 'VALUE145', 'VALUE148', 'VALUE149', 'VALUE147', 'VALUE32',
                         'VALUE391', 'VALUE392', 'VALUE393', 'VALUE394', 'VALUE396', 'TEXT396', 'VALUE397', 'TEXT398', 'VALUE341', 'VALUE342',
                         'VALUE344', 'VALUE345', 'VALUE346', 'VALUE347', 'VALUE349', 'VALUE21', 'VALUE1251', 'VALUE1252', 'VALUE1253']


def export_103_bk(session: Any, staff_ids: List[str], key_date: str) -> AdTable:
    """导出103
       ------------------
       入参：
       session: SAP SESSION，如为None，则新打开SAP
       staff_ids: 人员编号数组
       key_date: 关键日期
       ------------------
       返回值：
       AdTable，可通过.wb访问Workbook，或.ws访问Worksheet
       ------------------
       调用样例：
       _table: AdTable = export_103_bk(None, ['01576547'], '20200301')
       _table.filename = '模板_103'
       _table.save_to('x:/') # 保存模板至x:/下
    """
    if all(map(lambda v: v == '', staff_ids)) is True:
        raise Exception('人员编号全为空值，请检查模板人员编号是否填充')
    next_month = time.strftime("%Y%m31", time.localtime(time.time() + (35 - int(time.strftime("%d"))) * 24 * 3600))
    if not key_date.isdigit() or len(key_date) != 8 or int(key_date) < int(time.strftime("%Y%m01")) or int(key_date) > int(next_month):
        raise Exception("事件执行日期错误，日期应为8位数字且大于等于本月1号小于等于次月月底。")
    if session is None:
        session = attach_sap()
    elif isinstance(session, str):
        session = attach_sap(session)
    enter_103(session)  # 进入103信息集查询屏
    query_selection(session, '_________111-2', select_103, HEADER_IDS)  # 勾选103选项
    fill_103(session, staff_ids, key_date)  # 填入员工编号和关键日期，并查询
    _table: AdTable = export_query(session, template_file=f'{TEMPLATE_DIR}/模板_103.xlsx', query_name='_________111-2')
    _table['A'].apply(init_sap_id)
    # _table.filename = '103'
    return _table


# example
if __name__ == '__main__':
    from rpa.fastrpa.log import config
    config()
    _table: AdTable = export_103_bk(None, ['00997235', '00997250', '00997305', '00997245'], '20210501')
    _table.save_to('x:/')
