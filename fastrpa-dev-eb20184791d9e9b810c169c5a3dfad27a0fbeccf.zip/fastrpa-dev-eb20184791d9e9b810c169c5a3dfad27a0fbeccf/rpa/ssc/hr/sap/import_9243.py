"""批导9243（从事职业工种模板）"""
import logging

from rpa.fastrpa.adtable import AdTable, load_from_xlsx_file
from rpa.fastrpa.tempdir import gentempdir
from rpa.ssc.hr.sap.import_xlsx import import_single


def import_9243(_9243: AdTable) -> bool:
    """上传/批导新增从事职业工种信息模板（9243）至SAP，成功返回True，失败返回False。"""
    temp_dir = gentempdir()
    logging.info(f'生成新增从事职业工种批导文件')
    try:
        filename = _9243.save_to(temp_dir)
    except PermissionError:
        _9243.filename += '_副本'
        filename = _9243.save_to(temp_dir)
    logging.info(f'新增从事职业工种模板生成成功，文件路径：{filename}')
    is_import_succ = import_single('9243->HR_BI_9243', filename)
    _9243_imported = load_from_xlsx_file(filename, skip_header=6)
    _9243.replace_content_by(_9243_imported)  # 读取批导结果，并写入原文件
    return is_import_succ
