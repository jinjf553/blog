"""导出组合逻辑查询1073"""
import logging
from typing import Any, List

import pyperclip
from rpa.config import TEMPLATE_DIR
from rpa.fastrpa.adtable import AdTable
from rpa.fastrpa.sap.grid_view_ctrl import GridViewCtrl
from rpa.fastrpa.sap.session import attach_sap
from rpa.ssc.sap.query import export_query, query_selection
from rpa.ssc.sap.utils import init_sap_id


def enter_1073(session: Any) -> None:
    """进入1073"""
    session.findById("wnd[0]").maximize()
    session.findById("wnd[0]/tbar[0]/okcd").text = "/n S_PH0_48000513"
    session.findById("wnd[0]").sendVKey(0)
    session.findById("wnd[1]/usr/cmbDYNP4100-DD_WORKSPACE").setFocus()
    session.findById("wnd[1]/usr/cmbDYNP4100-DD_WORKSPACE").key = "2"
    session.findById("wnd[1]/usr/cmbDYNP4100-DD_USERGROUP").setFocus()
    session.findById("wnd[1]/usr/cmbDYNP4100-DD_USERGROUP").key = "107"
    session.findById("wnd[1]/usr/tblSAPLAQ_INT_FUNCTIONSTCH_FUNCAREAS").getAbsoluteRow(1).selected = -1
    session.findById("wnd[1]/usr/tblSAPLAQ_INT_FUNCTIONSTCH_FUNCAREAS/txtDYNP4100_TC_FUNCAREAS-NAME[0,1]").setFocus()
    session.findById("wnd[1]/usr/tblSAPLAQ_INT_FUNCTIONSTCH_FUNCAREAS/txtDYNP4100_TC_FUNCAREAS-NAME[0,1]").caretPosition = 0
    session.findById("wnd[1]/tbar[0]/btn[0]").press()


def select_1073(session: Any) -> None:
    """勾选1073"""
    enter_1073(session)
    session.findById("wnd[0]/shellcont[1]/shell/shellcont[0]/shell/shellcont[1]/shell[1]").selectItem("          8", "C          3")
    session.findById("wnd[0]/shellcont[1]/shell/shellcont[0]/shell/shellcont[1]/shell[1]").ensureVisibleHorizontalItem("          8", "C          3")
    session.findById("wnd[0]/shellcont[1]/shell/shellcont[0]/shell/shellcont[1]/shell[1]").changeCheckbox("          8", "C          3", -1)
    session.findById("wnd[0]/shellcont[1]/shell/shellcont[0]/shell/shellcont[1]/shell[1]").selectItem("         11", "C          3")
    session.findById("wnd[0]/shellcont[1]/shell/shellcont[0]/shell/shellcont[1]/shell[1]").ensureVisibleHorizontalItem("         11", "C          3")
    session.findById("wnd[0]/shellcont[1]/shell/shellcont[0]/shell/shellcont[1]/shell[1]").changeCheckbox("         11", "C          3", -1)
    session.findById("wnd[0]/shellcont[1]/shell/shellcont[0]/shell/shellcont[1]/shell[1]").selectItem("         12", "C          3")
    session.findById("wnd[0]/shellcont[1]/shell/shellcont[0]/shell/shellcont[1]/shell[1]").ensureVisibleHorizontalItem("         12", "C          3")
    session.findById("wnd[0]/shellcont[1]/shell/shellcont[0]/shell/shellcont[1]/shell[1]").changeCheckbox("         12", "C          3", -1)
    session.findById("wnd[0]/shellcont[1]/shell/shellcont[0]/shell/shellcont[1]/shell[1]").expandNode("         24")
    session.findById("wnd[0]/shellcont[1]/shell/shellcont[0]/shell/shellcont[1]/shell[1]").topNode = "          1"
    session.findById("wnd[0]/shellcont[1]/shell/shellcont[0]/shell/shellcont[1]/shell[1]").selectItem("         25", "C          4")
    session.findById("wnd[0]/shellcont[1]/shell/shellcont[0]/shell/shellcont[1]/shell[1]").ensureVisibleHorizontalItem("         25", "C          4")
    session.findById("wnd[0]/shellcont[1]/shell/shellcont[0]/shell/shellcont[1]/shell[1]").topNode = "         13"
    session.findById("wnd[0]/shellcont[1]/shell/shellcont[0]/shell/shellcont[1]/shell[1]").changeCheckbox("         25", "C          4", -1)
    session.findById("wnd[0]/shellcont[1]/shell/shellcont[0]/shell/shellcont[1]/shell[1]").selectItem("         29", "C          4")
    session.findById("wnd[0]/shellcont[1]/shell/shellcont[0]/shell/shellcont[1]/shell[1]").ensureVisibleHorizontalItem("         29", "C          4")
    session.findById("wnd[0]/shellcont[1]/shell/shellcont[0]/shell/shellcont[1]/shell[1]").changeCheckbox("         29", "C          4", -1)
    session.findById("wnd[0]/shellcont[1]/shell/shellcont[0]/shell/shellcont[1]/shell[1]").selectItem("         30", "C          4")
    session.findById("wnd[0]/shellcont[1]/shell/shellcont[0]/shell/shellcont[1]/shell[1]").ensureVisibleHorizontalItem("         30", "C          4")
    session.findById("wnd[0]/shellcont[1]/shell/shellcont[0]/shell/shellcont[1]/shell[1]").changeCheckbox("         30", "C          4", -1)
    session.findById("wnd[0]/shellcont[1]/shell/shellcont[0]/shell/shellcont[1]/shell[1]").selectItem("         31", "C          4")
    session.findById("wnd[0]/shellcont[1]/shell/shellcont[0]/shell/shellcont[1]/shell[1]").ensureVisibleHorizontalItem("         31", "C          4")
    session.findById("wnd[0]/shellcont[1]/shell/shellcont[0]/shell/shellcont[1]/shell[1]").changeCheckbox("         31", "C          4", -1)
    session.findById("wnd[0]/shellcont[1]/shell/shellcont[0]/shell/shellcont[1]/shell[1]").selectItem("         32", "C          4")
    session.findById("wnd[0]/shellcont[1]/shell/shellcont[0]/shell/shellcont[1]/shell[1]").ensureVisibleHorizontalItem("         32", "C          4")
    session.findById("wnd[0]/shellcont[1]/shell/shellcont[0]/shell/shellcont[1]/shell[1]").changeCheckbox("         32", "C          4", -1)
    session.findById("wnd[0]/shellcont[1]/shell/shellcont[0]/shell/shellcont[1]/shell[1]").selectItem("         33", "C          4")
    session.findById("wnd[0]/shellcont[1]/shell/shellcont[0]/shell/shellcont[1]/shell[1]").ensureVisibleHorizontalItem("         33", "C          4")
    session.findById("wnd[0]/shellcont[1]/shell/shellcont[0]/shell/shellcont[1]/shell[1]").changeCheckbox("         33", "C          4", -1)
    session.findById("wnd[0]/shellcont[1]/shell/shellcont[0]/shell/shellcont[1]/shell[1]").selectItem("         34", "C          4")
    session.findById("wnd[0]/shellcont[1]/shell/shellcont[0]/shell/shellcont[1]/shell[1]").ensureVisibleHorizontalItem("         34", "C          4")
    session.findById("wnd[0]/shellcont[1]/shell/shellcont[0]/shell/shellcont[1]/shell[1]").changeCheckbox("         34", "C          4", -1)
    session.findById("wnd[0]/shellcont[1]/shell/shellcont[0]/shell/shellcont[1]/shell[1]").selectItem("         35", "C          4")
    session.findById("wnd[0]/shellcont[1]/shell/shellcont[0]/shell/shellcont[1]/shell[1]").ensureVisibleHorizontalItem("         35", "C          4")
    session.findById("wnd[0]/shellcont[1]/shell/shellcont[0]/shell/shellcont[1]/shell[1]").changeCheckbox("         35", "C          4", -1)
    session.findById("wnd[0]/shellcont[1]/shell/shellcont[0]/shell/shellcont[1]/shell[1]").expandNode("         36")
    session.findById("wnd[0]/shellcont[1]/shell/shellcont[0]/shell/shellcont[1]/shell[1]").topNode = "         13"
    session.findById("wnd[0]/shellcont[1]/shell/shellcont[0]/shell/shellcont[1]/shell[1]").selectItem("         43", "C          3")
    session.findById("wnd[0]/shellcont[1]/shell/shellcont[0]/shell/shellcont[1]/shell[1]").ensureVisibleHorizontalItem("         43", "C          3")
    session.findById("wnd[0]/shellcont[1]/shell/shellcont[0]/shell/shellcont[1]/shell[1]").topNode = "         23"
    session.findById("wnd[0]/shellcont[1]/shell/shellcont[0]/shell/shellcont[1]/shell[1]").changeCheckbox("         43", "C          3", -1)
    session.findById("wnd[0]/shellcont[1]/shell/shellcont[0]/shell/shellcont[1]/shell[1]").selectItem("         44", "C          3")
    session.findById("wnd[0]/shellcont[1]/shell/shellcont[0]/shell/shellcont[1]/shell[1]").ensureVisibleHorizontalItem("         44", "C          3")
    session.findById("wnd[0]/shellcont[1]/shell/shellcont[0]/shell/shellcont[1]/shell[1]").changeCheckbox("         44", "C          3", -1)
    session.findById("wnd[0]/shellcont[1]/shell/shellcont[0]/shell/shellcont[1]/shell[1]").selectItem("         39", "C          4")
    session.findById("wnd[0]/shellcont[1]/shell/shellcont[0]/shell/shellcont[1]/shell[1]").ensureVisibleHorizontalItem("         39", "C          4")
    session.findById("wnd[0]/shellcont[1]/shell/shellcont[0]/shell/shellcont[1]/shell[1]").changeCheckbox("         39", "C          4", -1)
    session.findById("wnd[0]/shellcont[1]/shell/shellcont[0]/shell/shellcont[1]/shell[1]").selectItem("         40", "C          4")
    session.findById("wnd[0]/shellcont[1]/shell/shellcont[0]/shell/shellcont[1]/shell[1]").ensureVisibleHorizontalItem("         40", "C          4")
    session.findById("wnd[0]/shellcont[1]/shell/shellcont[0]/shell/shellcont[1]/shell[1]").changeCheckbox("         40", "C          4", -1)
    session.findById("wnd[0]/shellcont[1]/shell/shellcont[0]/shell/shellcont[1]/shell[1]").selectItem("         41", "C          4")
    session.findById("wnd[0]/shellcont[1]/shell/shellcont[0]/shell/shellcont[1]/shell[1]").ensureVisibleHorizontalItem("         41", "C          4")
    session.findById("wnd[0]/shellcont[1]/shell/shellcont[0]/shell/shellcont[1]/shell[1]").changeCheckbox("         41", "C          4", -1)
    session.findById("wnd[0]/shellcont[1]/shell/shellcont[0]/shell/shellcont[1]/shell[1]").selectItem("         42", "C          4")
    session.findById("wnd[0]/shellcont[1]/shell/shellcont[0]/shell/shellcont[1]/shell[1]").ensureVisibleHorizontalItem("         42", "C          4")
    session.findById("wnd[0]/shellcont[1]/shell/shellcont[0]/shell/shellcont[1]/shell[1]").changeCheckbox("         42", "C          4", -1)
    session.findById("wnd[0]/shellcont[1]/shell/shellcont[0]/shell/shellcont[1]/shell[1]").selectItem("         45", "C          4")
    session.findById("wnd[0]/shellcont[1]/shell/shellcont[0]/shell/shellcont[1]/shell[1]").ensureVisibleHorizontalItem("         45", "C          4")
    session.findById("wnd[0]/shellcont[1]/shell/shellcont[0]/shell/shellcont[1]/shell[1]").changeCheckbox("         45", "C          4", -1)
    session.findById("wnd[0]/shellcont[1]/shell/shellcont[0]/shell/shellcont[1]/shell[1]").expandNode("         49")
    session.findById("wnd[0]/shellcont[1]/shell/shellcont[0]/shell/shellcont[1]/shell[1]").topNode = "         35"
    session.findById("wnd[0]/shellcont[1]/shell/shellcont[0]/shell/shellcont[1]/shell[1]").selectItem("         52", "C          4")
    session.findById("wnd[0]/shellcont[1]/shell/shellcont[0]/shell/shellcont[1]/shell[1]").ensureVisibleHorizontalItem("         52", "C          4")
    session.findById("wnd[0]/shellcont[1]/shell/shellcont[0]/shell/shellcont[1]/shell[1]").changeCheckbox("         52", "C          4", -1)
    session.findById("wnd[0]/shellcont[1]/shell/shellcont[0]/shell/shellcont[1]/shell[1]").selectItem("         53", "C          4")
    session.findById("wnd[0]/shellcont[1]/shell/shellcont[0]/shell/shellcont[1]/shell[1]").ensureVisibleHorizontalItem("         53", "C          4")
    session.findById("wnd[0]/shellcont[1]/shell/shellcont[0]/shell/shellcont[1]/shell[1]").changeCheckbox("         53", "C          4", -1)
    session.findById("wnd[0]/shellcont[1]/shell/shellcont[0]/shell/shellcont[1]/shell[1]").selectItem("         54", "C          4")
    session.findById("wnd[0]/shellcont[1]/shell/shellcont[0]/shell/shellcont[1]/shell[1]").ensureVisibleHorizontalItem("         54", "C          4")
    session.findById("wnd[0]/shellcont[1]/shell/shellcont[0]/shell/shellcont[1]/shell[1]").changeCheckbox("         54", "C          4", -1)
    session.findById("wnd[0]/shellcont[1]/shell/shellcont[0]/shell/shellcont[1]/shell[1]").selectItem("         55", "C          4")
    session.findById("wnd[0]/shellcont[1]/shell/shellcont[0]/shell/shellcont[1]/shell[1]").ensureVisibleHorizontalItem("         55", "C          4")
    session.findById("wnd[0]/shellcont[1]/shell/shellcont[0]/shell/shellcont[1]/shell[1]").changeCheckbox("         55", "C          4", -1)
    session.findById("wnd[0]/shellcont[1]/shell/shellcont[0]/shell/shellcont[1]/shell[1]").selectItem("         56", "C          4")
    session.findById("wnd[0]/shellcont[1]/shell/shellcont[0]/shell/shellcont[1]/shell[1]").ensureVisibleHorizontalItem("         56", "C          4")
    session.findById("wnd[0]/shellcont[1]/shell/shellcont[0]/shell/shellcont[1]/shell[1]").changeCheckbox("         56", "C          4", -1)
    session.findById("wnd[0]/shellcont[1]/shell/shellcont[0]/shell/shellcont[1]/shell[1]").expandNode("         57")
    session.findById("wnd[0]/shellcont[1]/shell/shellcont[0]/shell/shellcont[1]/shell[1]").topNode = "         35"
    session.findById("wnd[0]/shellcont[1]/shell/shellcont[0]/shell/shellcont[1]/shell[1]").selectItem("         60", "C          4")
    session.findById("wnd[0]/shellcont[1]/shell/shellcont[0]/shell/shellcont[1]/shell[1]").ensureVisibleHorizontalItem("         60", "C          4")
    session.findById("wnd[0]/shellcont[1]/shell/shellcont[0]/shell/shellcont[1]/shell[1]").topNode = "         46"
    session.findById("wnd[0]/shellcont[1]/shell/shellcont[0]/shell/shellcont[1]/shell[1]").changeCheckbox("         60", "C          4", -1)
    session.findById("wnd[0]/shellcont[1]/shell/shellcont[0]/shell/shellcont[1]/shell[1]").selectItem("         61", "C          4")
    session.findById("wnd[0]/shellcont[1]/shell/shellcont[0]/shell/shellcont[1]/shell[1]").ensureVisibleHorizontalItem("         61", "C          4")
    session.findById("wnd[0]/shellcont[1]/shell/shellcont[0]/shell/shellcont[1]/shell[1]").changeCheckbox("         61", "C          4", -1)
    session.findById("wnd[0]/shellcont[1]/shell/shellcont[0]/shell/shellcont[1]/shell[1]").selectItem("         62", "C          4")
    session.findById("wnd[0]/shellcont[1]/shell/shellcont[0]/shell/shellcont[1]/shell[1]").ensureVisibleHorizontalItem("         62", "C          4")
    session.findById("wnd[0]/shellcont[1]/shell/shellcont[0]/shell/shellcont[1]/shell[1]").changeCheckbox("         62", "C          4", -1)
    session.findById("wnd[0]/shellcont[1]/shell/shellcont[0]/shell/shellcont[1]/shell[1]").selectItem("         63", "C          4")
    session.findById("wnd[0]/shellcont[1]/shell/shellcont[0]/shell/shellcont[1]/shell[1]").ensureVisibleHorizontalItem("         63", "C          4")
    session.findById("wnd[0]/shellcont[1]/shell/shellcont[0]/shell/shellcont[1]/shell[1]").changeCheckbox("         63", "C          4", -1)
    session.findById("wnd[0]/shellcont[1]/shell/shellcont[0]/shell/shellcont[1]/shell[1]").selectItem("         65", "C          4")
    session.findById("wnd[0]/shellcont[1]/shell/shellcont[0]/shell/shellcont[1]/shell[1]").ensureVisibleHorizontalItem("         65", "C          4")
    session.findById("wnd[0]/shellcont[1]/shell/shellcont[0]/shell/shellcont[1]/shell[1]").changeCheckbox("         65", "C          4", -1)
    session.findById("wnd[0]/shellcont[1]/shell/shellcont[0]/shell/shellcont[1]/shell[1]").selectItem("         66", "C          4")
    session.findById("wnd[0]/shellcont[1]/shell/shellcont[0]/shell/shellcont[1]/shell[1]").ensureVisibleHorizontalItem("         66", "C          4")
    session.findById("wnd[0]/shellcont[1]/shell/shellcont[0]/shell/shellcont[1]/shell[1]").changeCheckbox("         66", "C          4", -1)
    session.findById("wnd[0]/shellcont[1]/shell/shellcont[0]/shell/shellcont[1]/shell[1]").selectItem("         67", "C          4")
    session.findById("wnd[0]/shellcont[1]/shell/shellcont[0]/shell/shellcont[1]/shell[1]").ensureVisibleHorizontalItem("         67", "C          4")
    session.findById("wnd[0]/shellcont[1]/shell/shellcont[0]/shell/shellcont[1]/shell[1]").changeCheckbox("         67", "C          4", -1)
    session.findById("wnd[0]/shellcont[1]/shell/shellcont[0]/shell/shellcont[1]/shell[1]").selectItem("         68", "C          4")
    session.findById("wnd[0]/shellcont[1]/shell/shellcont[0]/shell/shellcont[1]/shell[1]").ensureVisibleHorizontalItem("         68", "C          4")
    session.findById("wnd[0]/shellcont[1]/shell/shellcont[0]/shell/shellcont[1]/shell[1]").changeCheckbox("         68", "C          4", -1)
    session.findById("wnd[0]/shellcont[1]/shell/shellcont[0]/shell/shellcont[1]/shell[1]").expandNode("         69")
    session.findById("wnd[0]/shellcont[1]/shell/shellcont[0]/shell/shellcont[1]/shell[1]").topNode = "         46"
    session.findById("wnd[0]/shellcont[1]/shell/shellcont[0]/shell/shellcont[1]/shell[1]").selectItem("         72", "C          4")
    session.findById("wnd[0]/shellcont[1]/shell/shellcont[0]/shell/shellcont[1]/shell[1]").ensureVisibleHorizontalItem("         72", "C          4")
    session.findById("wnd[0]/shellcont[1]/shell/shellcont[0]/shell/shellcont[1]/shell[1]").topNode = "         62"
    session.findById("wnd[0]/shellcont[1]/shell/shellcont[0]/shell/shellcont[1]/shell[1]").changeCheckbox("         72", "C          4", -1)
    session.findById("wnd[0]/shellcont[1]/shell/shellcont[0]/shell/shellcont[1]/shell[1]").selectItem("         73", "C          4")
    session.findById("wnd[0]/shellcont[1]/shell/shellcont[0]/shell/shellcont[1]/shell[1]").ensureVisibleHorizontalItem("         73", "C          4")
    session.findById("wnd[0]/shellcont[1]/shell/shellcont[0]/shell/shellcont[1]/shell[1]").changeCheckbox("         73", "C          4", -1)
    session.findById("wnd[0]/shellcont[1]/shell/shellcont[0]/shell/shellcont[1]/shell[1]").selectItem("         74", "C          4")
    session.findById("wnd[0]/shellcont[1]/shell/shellcont[0]/shell/shellcont[1]/shell[1]").ensureVisibleHorizontalItem("         74", "C          4")
    session.findById("wnd[0]/shellcont[1]/shell/shellcont[0]/shell/shellcont[1]/shell[1]").changeCheckbox("         74", "C          4", -1)
    session.findById("wnd[0]/shellcont[1]/shell/shellcont[0]/shell/shellcont[1]/shell[1]").selectItem("         75", "C          4")
    session.findById("wnd[0]/shellcont[1]/shell/shellcont[0]/shell/shellcont[1]/shell[1]").ensureVisibleHorizontalItem("         75", "C          4")
    session.findById("wnd[0]/shellcont[1]/shell/shellcont[0]/shell/shellcont[1]/shell[1]").changeCheckbox("         75", "C          4", -1)
    session.findById("wnd[0]/shellcont[1]/shell/shellcont[0]/shell/shellcont[1]/shell[1]").selectItem("         77", "C          4")
    session.findById("wnd[0]/shellcont[1]/shell/shellcont[0]/shell/shellcont[1]/shell[1]").ensureVisibleHorizontalItem("         77", "C          4")
    session.findById("wnd[0]/shellcont[1]/shell/shellcont[0]/shell/shellcont[1]/shell[1]").changeCheckbox("         77", "C          4", -1)
    session.findById("wnd[0]/shellcont[1]/shell/shellcont[0]/shell/shellcont[1]/shell[1]").selectItem("         78", "C          4")
    session.findById("wnd[0]/shellcont[1]/shell/shellcont[0]/shell/shellcont[1]/shell[1]").ensureVisibleHorizontalItem("         78", "C          4")
    session.findById("wnd[0]/shellcont[1]/shell/shellcont[0]/shell/shellcont[1]/shell[1]").changeCheckbox("         78", "C          4", -1)
    session.findById("wnd[0]/shellcont[1]/shell/shellcont[0]/shell/shellcont[1]/shell[1]").selectItem("         79", "C          4")
    session.findById("wnd[0]/shellcont[1]/shell/shellcont[0]/shell/shellcont[1]/shell[1]").ensureVisibleHorizontalItem("         79", "C          4")
    session.findById("wnd[0]/shellcont[1]/shell/shellcont[0]/shell/shellcont[1]/shell[1]").changeCheckbox("         79", "C          4", -1)
    session.findById("wnd[0]/shellcont[1]/shell/shellcont[0]/shell/shellcont[1]/shell[1]").expandNode("        131")
    session.findById("wnd[0]/shellcont[1]/shell/shellcont[0]/shell/shellcont[1]/shell[1]").topNode = "         62"
    session.findById("wnd[0]/shellcont[1]/shell/shellcont[0]/shell/shellcont[1]/shell[1]").selectItem("        140", "C          4")
    session.findById("wnd[0]/shellcont[1]/shell/shellcont[0]/shell/shellcont[1]/shell[1]").ensureVisibleHorizontalItem("        140", "C          4")
    session.findById("wnd[0]/shellcont[1]/shell/shellcont[0]/shell/shellcont[1]/shell[1]").topNode = "         72"
    session.findById("wnd[0]/shellcont[1]/shell/shellcont[0]/shell/shellcont[1]/shell[1]").changeCheckbox("        140", "C          4", -1)
    session.findById("wnd[0]/shellcont[1]/shell/shellcont[0]/shell/shellcont[1]/shell[1]").expandNode("        144")
    session.findById("wnd[0]/shellcont[1]/shell/shellcont[0]/shell/shellcont[1]/shell[1]").topNode = "         72"
    session.findById("wnd[0]/shellcont[1]/shell/shellcont[0]/shell/shellcont[1]/shell[1]").selectItem("        147", "C          4")
    session.findById("wnd[0]/shellcont[1]/shell/shellcont[0]/shell/shellcont[1]/shell[1]").ensureVisibleHorizontalItem("        147", "C          4")
    session.findById("wnd[0]/shellcont[1]/shell/shellcont[0]/shell/shellcont[1]/shell[1]").topNode = "        140"
    session.findById("wnd[0]/shellcont[1]/shell/shellcont[0]/shell/shellcont[1]/shell[1]").changeCheckbox("        147", "C          4", -1)
    session.findById("wnd[0]/shellcont[1]/shell/shellcont[0]/shell/shellcont[1]/shell[1]").selectItem("        148", "C          4")
    session.findById("wnd[0]/shellcont[1]/shell/shellcont[0]/shell/shellcont[1]/shell[1]").ensureVisibleHorizontalItem("        148", "C          4")
    session.findById("wnd[0]/shellcont[1]/shell/shellcont[0]/shell/shellcont[1]/shell[1]").changeCheckbox("        148", "C          4", -1)
    session.findById("wnd[0]/shellcont[1]/shell/shellcont[0]/shell/shellcont[1]/shell[1]").selectItem("        149", "C          4")
    session.findById("wnd[0]/shellcont[1]/shell/shellcont[0]/shell/shellcont[1]/shell[1]").ensureVisibleHorizontalItem("        149", "C          4")
    session.findById("wnd[0]/shellcont[1]/shell/shellcont[0]/shell/shellcont[1]/shell[1]").changeCheckbox("        149", "C          4", -1)
    session.findById("wnd[0]/shellcont[1]/shell/shellcont[0]/shell/shellcont[1]/shell[1]").selectItem("        150", "C          4")
    session.findById("wnd[0]/shellcont[1]/shell/shellcont[0]/shell/shellcont[1]/shell[1]").ensureVisibleHorizontalItem("        150", "C          4")
    session.findById("wnd[0]/shellcont[1]/shell/shellcont[0]/shell/shellcont[1]/shell[1]").changeCheckbox("        150", "C          4", -1)
    session.findById("wnd[0]/shellcont[1]/shell/shellcont[0]/shell/shellcont[1]/shell[1]").selectItem("        151", "C          4")
    session.findById("wnd[0]/shellcont[1]/shell/shellcont[0]/shell/shellcont[1]/shell[1]").ensureVisibleHorizontalItem("        151", "C          4")
    session.findById("wnd[0]/shellcont[1]/shell/shellcont[0]/shell/shellcont[1]/shell[1]").changeCheckbox("        151", "C          4", -1)
    session.findById("wnd[0]/shellcont[1]/shell/shellcont[0]/shell/shellcont[1]/shell[1]").selectItem("        152", "C          4")
    session.findById("wnd[0]/shellcont[1]/shell/shellcont[0]/shell/shellcont[1]/shell[1]").ensureVisibleHorizontalItem("        152", "C          4")
    session.findById("wnd[0]/shellcont[1]/shell/shellcont[0]/shell/shellcont[1]/shell[1]").changeCheckbox("        152", "C          4", -1)
    session.findById("wnd[0]/shellcont[1]/shell/shellcont[0]/shell/shellcont[1]/shell[1]").selectItem("        153", "C          4")
    session.findById("wnd[0]/shellcont[1]/shell/shellcont[0]/shell/shellcont[1]/shell[1]").ensureVisibleHorizontalItem("        153", "C          4")
    session.findById("wnd[0]/shellcont[1]/shell/shellcont[0]/shell/shellcont[1]/shell[1]").changeCheckbox("        153", "C          4", -1)
    session.findById("wnd[0]/shellcont[1]/shell/shellcont[0]/shell/shellcont[1]/shell[1]").selectItem("        154", "C          4")
    session.findById("wnd[0]/shellcont[1]/shell/shellcont[0]/shell/shellcont[1]/shell[1]").ensureVisibleHorizontalItem("        154", "C          4")
    session.findById("wnd[0]/shellcont[1]/shell/shellcont[0]/shell/shellcont[1]/shell[1]").changeCheckbox("        154", "C          4", -1)
    session.findById("wnd[0]/shellcont[1]/shell/shellcont[0]/shell/shellcont[1]/shell[1]").selectItem("        155", "C          4")
    session.findById("wnd[0]/shellcont[1]/shell/shellcont[0]/shell/shellcont[1]/shell[1]").ensureVisibleHorizontalItem("        155", "C          4")
    session.findById("wnd[0]/shellcont[1]/shell/shellcont[0]/shell/shellcont[1]/shell[1]").changeCheckbox("        155", "C          4", -1)
    session.findById("wnd[0]/shellcont[1]/shell/shellcont[0]/shell/shellcont[1]/shell[1]").selectItem("        156", "C          4")
    session.findById("wnd[0]/shellcont[1]/shell/shellcont[0]/shell/shellcont[1]/shell[1]").ensureVisibleHorizontalItem("        156", "C          4")
    session.findById("wnd[0]/shellcont[1]/shell/shellcont[0]/shell/shellcont[1]/shell[1]").changeCheckbox("        156", "C          4", -1)
    session.findById("wnd[0]/shellcont[1]/shell/shellcont[0]/shell/shellcont[1]/shell[1]").selectItem("        157", "C          4")
    session.findById("wnd[0]/shellcont[1]/shell/shellcont[0]/shell/shellcont[1]/shell[1]").ensureVisibleHorizontalItem("        157", "C          4")
    session.findById("wnd[0]/shellcont[1]/shell/shellcont[0]/shell/shellcont[1]/shell[1]").changeCheckbox("        157", "C          4", -1)
    session.findById("wnd[0]/shellcont[1]/shell/shellcont[0]/shell/shellcont[1]/shell[1]").selectItem("        158", "C          4")
    session.findById("wnd[0]/shellcont[1]/shell/shellcont[0]/shell/shellcont[1]/shell[1]").ensureVisibleHorizontalItem("        158", "C          4")
    session.findById("wnd[0]/shellcont[1]/shell/shellcont[0]/shell/shellcont[1]/shell[1]").changeCheckbox("        158", "C          4", -1)
    session.findById("wnd[0]/shellcont[1]/shell/shellcont[0]/shell/shellcont[1]/shell[1]").selectItem("        159", "C          4")
    session.findById("wnd[0]/shellcont[1]/shell/shellcont[0]/shell/shellcont[1]/shell[1]").ensureVisibleHorizontalItem("        159", "C          4")
    session.findById("wnd[0]/shellcont[1]/shell/shellcont[0]/shell/shellcont[1]/shell[1]").changeCheckbox("        159", "C          4", -1)
    session.findById("wnd[0]/shellcont[1]/shell/shellcont[0]/shell/shellcont[1]/shell[1]").selectItem("        160", "C          4")
    session.findById("wnd[0]/shellcont[1]/shell/shellcont[0]/shell/shellcont[1]/shell[1]").ensureVisibleHorizontalItem("        160", "C          4")
    session.findById("wnd[0]/shellcont[1]/shell/shellcont[0]/shell/shellcont[1]/shell[1]").changeCheckbox("        160", "C          4", -1)
    session.findById("wnd[0]/shellcont[1]/shell/shellcont[0]/shell/shellcont[1]/shell[1]").selectItem("        164", "C          4")
    session.findById("wnd[0]/shellcont[1]/shell/shellcont[0]/shell/shellcont[1]/shell[1]").ensureVisibleHorizontalItem("        164", "C          4")
    session.findById("wnd[0]/shellcont[1]/shell/shellcont[0]/shell/shellcont[1]/shell[1]").changeCheckbox("        164", "C          4", -1)
    session.findById("wnd[0]/shellcont[1]/shell/shellcont[0]/shell/shellcont[1]/shell[1]").selectItem("        165", "C          4")
    session.findById("wnd[0]/shellcont[1]/shell/shellcont[0]/shell/shellcont[1]/shell[1]").ensureVisibleHorizontalItem("        165", "C          4")
    session.findById("wnd[0]/shellcont[1]/shell/shellcont[0]/shell/shellcont[1]/shell[1]").changeCheckbox("        165", "C          4", -1)
    session.findById("wnd[0]/shellcont[1]/shell/shellcont[0]/shell/shellcont[1]/shell[1]").expandNode("        170")
    session.findById("wnd[0]/shellcont[1]/shell/shellcont[0]/shell/shellcont[1]/shell[1]").topNode = "        157"
    session.findById("wnd[0]/shellcont[1]/shell/shellcont[0]/shell/shellcont[1]/shell[1]").selectItem("        173", "C          4")
    session.findById("wnd[0]/shellcont[1]/shell/shellcont[0]/shell/shellcont[1]/shell[1]").ensureVisibleHorizontalItem("        173", "C          4")
    session.findById("wnd[0]/shellcont[1]/shell/shellcont[0]/shell/shellcont[1]/shell[1]").changeCheckbox("        173", "C          4", -1)
    session.findById("wnd[0]/shellcont[1]/shell/shellcont[0]/shell/shellcont[1]/shell[1]").selectItem("        174", "C          4")
    session.findById("wnd[0]/shellcont[1]/shell/shellcont[0]/shell/shellcont[1]/shell[1]").ensureVisibleHorizontalItem("        174", "C          4")
    session.findById("wnd[0]/shellcont[1]/shell/shellcont[0]/shell/shellcont[1]/shell[1]").changeCheckbox("        174", "C          4", -1)
    session.findById("wnd[0]/shellcont[1]/shell/shellcont[0]/shell/shellcont[1]/shell[1]").selectItem("        175", "C          4")
    session.findById("wnd[0]/shellcont[1]/shell/shellcont[0]/shell/shellcont[1]/shell[1]").ensureVisibleHorizontalItem("        175", "C          4")
    session.findById("wnd[0]/shellcont[1]/shell/shellcont[0]/shell/shellcont[1]/shell[1]").changeCheckbox("        175", "C          4", -1)
    session.findById("wnd[0]/shellcont[1]/shell/shellcont[0]/shell/shellcont[1]/shell[1]").selectItem("        176", "C          4")
    session.findById("wnd[0]/shellcont[1]/shell/shellcont[0]/shell/shellcont[1]/shell[1]").ensureVisibleHorizontalItem("        176", "C          4")
    session.findById("wnd[0]/shellcont[1]/shell/shellcont[0]/shell/shellcont[1]/shell[1]").changeCheckbox("        176", "C          4", -1)
    session.findById("wnd[0]/shellcont[1]/shell/shellcont[0]/shell/shellcont[1]/shell[1]").selectItem("        177", "C          4")
    session.findById("wnd[0]/shellcont[1]/shell/shellcont[0]/shell/shellcont[1]/shell[1]").ensureVisibleHorizontalItem("        177", "C          4")
    session.findById("wnd[0]/shellcont[1]/shell/shellcont[0]/shell/shellcont[1]/shell[1]").changeCheckbox("        177", "C          4", -1)
    session.findById("wnd[0]/shellcont[1]/shell/shellcont[0]/shell/shellcont[1]/shell[1]").selectItem("        178", "C          4")
    session.findById("wnd[0]/shellcont[1]/shell/shellcont[0]/shell/shellcont[1]/shell[1]").ensureVisibleHorizontalItem("        178", "C          4")
    session.findById("wnd[0]/shellcont[1]/shell/shellcont[0]/shell/shellcont[1]/shell[1]").changeCheckbox("        178", "C          4", -1)
    session.findById("wnd[0]/shellcont[1]/shell/shellcont[0]/shell/shellcont[1]/shell[1]").expandNode("        212")
    session.findById("wnd[0]/shellcont[1]/shell/shellcont[0]/shell/shellcont[1]/shell[1]").topNode = "        157"
    session.findById("wnd[0]/shellcont[1]/shell/shellcont[0]/shell/shellcont[1]/shell[1]").selectItem("        220", "C          4")
    session.findById("wnd[0]/shellcont[1]/shell/shellcont[0]/shell/shellcont[1]/shell[1]").ensureVisibleHorizontalItem("        220", "C          4")
    session.findById("wnd[0]/shellcont[1]/shell/shellcont[0]/shell/shellcont[1]/shell[1]").topNode = "        172"
    session.findById("wnd[0]/shellcont[1]/shell/shellcont[0]/shell/shellcont[1]/shell[1]").changeCheckbox("        220", "C          4", -1)
    session.findById("wnd[0]/shellcont[1]/shell/shellcont[0]/shell/shellcont[1]/shell[1]").expandNode("        251")
    session.findById("wnd[0]/shellcont[1]/shell/shellcont[0]/shell/shellcont[1]/shell[1]").topNode = "        179"
    session.findById("wnd[0]/shellcont[1]/shell/shellcont[0]/shell/shellcont[1]/shell[1]").selectItem("        254", "C          4")
    session.findById("wnd[0]/shellcont[1]/shell/shellcont[0]/shell/shellcont[1]/shell[1]").ensureVisibleHorizontalItem("        254", "C          4")
    session.findById("wnd[0]/shellcont[1]/shell/shellcont[0]/shell/shellcont[1]/shell[1]").topNode = "        224"
    session.findById("wnd[0]/shellcont[1]/shell/shellcont[0]/shell/shellcont[1]/shell[1]").changeCheckbox("        254", "C          4", -1)
    session.findById("wnd[0]/shellcont[1]/shell/shellcont[0]/shell/shellcont[1]/shell[1]").selectItem("        255", "C          4")
    session.findById("wnd[0]/shellcont[1]/shell/shellcont[0]/shell/shellcont[1]/shell[1]").ensureVisibleHorizontalItem("        255", "C          4")
    session.findById("wnd[0]/shellcont[1]/shell/shellcont[0]/shell/shellcont[1]/shell[1]").changeCheckbox("        255", "C          4", -1)
    session.findById("wnd[0]/shellcont[1]/shell/shellcont[0]/shell/shellcont[1]/shell[1]").selectItem("        256", "C          4")
    session.findById("wnd[0]/shellcont[1]/shell/shellcont[0]/shell/shellcont[1]/shell[1]").ensureVisibleHorizontalItem("        256", "C          4")
    session.findById("wnd[0]/shellcont[1]/shell/shellcont[0]/shell/shellcont[1]/shell[1]").changeCheckbox("        256", "C          4", -1)
    session.findById("wnd[0]/shellcont[1]/shell/shellcont[0]/shell/shellcont[1]/shell[1]").selectItem("        257", "C          4")
    session.findById("wnd[0]/shellcont[1]/shell/shellcont[0]/shell/shellcont[1]/shell[1]").ensureVisibleHorizontalItem("        257", "C          4")
    session.findById("wnd[0]/shellcont[1]/shell/shellcont[0]/shell/shellcont[1]/shell[1]").changeCheckbox("        257", "C          4", -1)
    session.findById("wnd[0]/shellcont[1]/shell/shellcont[0]/shell/shellcont[1]/shell[1]").selectItem("        258", "C          4")
    session.findById("wnd[0]/shellcont[1]/shell/shellcont[0]/shell/shellcont[1]/shell[1]").ensureVisibleHorizontalItem("        258", "C          4")
    session.findById("wnd[0]/shellcont[1]/shell/shellcont[0]/shell/shellcont[1]/shell[1]").changeCheckbox("        258", "C          4", -1)
    session.findById("wnd[0]/shellcont[1]/shell/shellcont[0]/shell/shellcont[1]/shell[1]").selectItem("        259", "C          4")
    session.findById("wnd[0]/shellcont[1]/shell/shellcont[0]/shell/shellcont[1]/shell[1]").ensureVisibleHorizontalItem("        259", "C          4")
    session.findById("wnd[0]/shellcont[1]/shell/shellcont[0]/shell/shellcont[1]/shell[1]").changeCheckbox("        259", "C          4", -1)
    session.findById("wnd[0]/shellcont[1]/shell/shellcont[0]/shell/shellcont[1]/shell[1]").selectItem("        260", "C          4")
    session.findById("wnd[0]/shellcont[1]/shell/shellcont[0]/shell/shellcont[1]/shell[1]").ensureVisibleHorizontalItem("        260", "C          4")
    session.findById("wnd[0]/shellcont[1]/shell/shellcont[0]/shell/shellcont[1]/shell[1]").changeCheckbox("        260", "C          4", -1)
    session.findById("wnd[0]/shellcont[1]/shell/shellcont[0]/shell/shellcont[1]/shell[1]").selectItem("        261", "C          4")
    session.findById("wnd[0]/shellcont[1]/shell/shellcont[0]/shell/shellcont[1]/shell[1]").ensureVisibleHorizontalItem("        261", "C          4")
    session.findById("wnd[0]/shellcont[1]/shell/shellcont[0]/shell/shellcont[1]/shell[1]").changeCheckbox("        261", "C          4", -1)
    session.findById("wnd[0]/shellcont[1]/shell/shellcont[0]/shell/shellcont[1]/shell[1]").selectItem("        262", "C          4")
    session.findById("wnd[0]/shellcont[1]/shell/shellcont[0]/shell/shellcont[1]/shell[1]").ensureVisibleHorizontalItem("        262", "C          4")
    session.findById("wnd[0]/shellcont[1]/shell/shellcont[0]/shell/shellcont[1]/shell[1]").changeCheckbox("        262", "C          4", -1)
    session.findById("wnd[0]/shellcont[1]/shell/shellcont[0]/shell/shellcont[1]/shell[1]").selectItem("        263", "C          4")
    session.findById("wnd[0]/shellcont[1]/shell/shellcont[0]/shell/shellcont[1]/shell[1]").ensureVisibleHorizontalItem("        263", "C          4")
    session.findById("wnd[0]/shellcont[1]/shell/shellcont[0]/shell/shellcont[1]/shell[1]").changeCheckbox("        263", "C          4", -1)
    session.findById("wnd[0]/shellcont[1]/shell/shellcont[0]/shell/shellcont[1]/shell[1]").selectItem("        264", "C          4")
    session.findById("wnd[0]/shellcont[1]/shell/shellcont[0]/shell/shellcont[1]/shell[1]").ensureVisibleHorizontalItem("        264", "C          4")
    session.findById("wnd[0]/shellcont[1]/shell/shellcont[0]/shell/shellcont[1]/shell[1]").changeCheckbox("        264", "C          4", -1)
    session.findById("wnd[0]/shellcont[1]/shell/shellcont[0]/shell/shellcont[1]/shell[1]").selectItem("        265", "C          4")
    session.findById("wnd[0]/shellcont[1]/shell/shellcont[0]/shell/shellcont[1]/shell[1]").ensureVisibleHorizontalItem("        265", "C          4")
    session.findById("wnd[0]/shellcont[1]/shell/shellcont[0]/shell/shellcont[1]/shell[1]").changeCheckbox("        265", "C          4", -1)
    session.findById("wnd[0]/shellcont[1]/shell/shellcont[0]/shell/shellcont[1]/shell[1]").selectItem("        266", "C          4")
    session.findById("wnd[0]/shellcont[1]/shell/shellcont[0]/shell/shellcont[1]/shell[1]").ensureVisibleHorizontalItem("        266", "C          4")
    session.findById("wnd[0]/shellcont[1]/shell/shellcont[0]/shell/shellcont[1]/shell[1]").changeCheckbox("        266", "C          4", -1)
    session.findById("wnd[0]/shellcont[1]/shell/shellcont[0]/shell/shellcont[1]/shell[1]").selectItem("        267", "C          4")
    session.findById("wnd[0]/shellcont[1]/shell/shellcont[0]/shell/shellcont[1]/shell[1]").ensureVisibleHorizontalItem("        267", "C          4")
    session.findById("wnd[0]/shellcont[1]/shell/shellcont[0]/shell/shellcont[1]/shell[1]").changeCheckbox("        267", "C          4", -1)
    session.findById("wnd[0]/shellcont[1]/shell/shellcont[0]/shell/shellcont[1]/shell[1]").selectItem("        268", "C          4")
    session.findById("wnd[0]/shellcont[1]/shell/shellcont[0]/shell/shellcont[1]/shell[1]").ensureVisibleHorizontalItem("        268", "C          4")
    session.findById("wnd[0]/shellcont[1]/shell/shellcont[0]/shell/shellcont[1]/shell[1]").changeCheckbox("        268", "C          4", -1)
    session.findById("wnd[0]/shellcont[1]/shell/shellcont[0]/shell/shellcont[1]/shell[1]").expandNode("        322")
    session.findById("wnd[0]/shellcont[1]/shell/shellcont[0]/shell/shellcont[1]/shell[1]").topNode = "        224"
    session.findById("wnd[0]/shellcont[1]/shell/shellcont[0]/shell/shellcont[1]/shell[1]").selectItem("        325", "C          4")
    session.findById("wnd[0]/shellcont[1]/shell/shellcont[0]/shell/shellcont[1]/shell[1]").ensureVisibleHorizontalItem("        325", "C          4")
    session.findById("wnd[0]/shellcont[1]/shell/shellcont[0]/shell/shellcont[1]/shell[1]").topNode = "        268"
    session.findById("wnd[0]/shellcont[1]/shell/shellcont[0]/shell/shellcont[1]/shell[1]").changeCheckbox("        325", "C          4", -1)
    session.findById("wnd[0]/shellcont[1]/shell/shellcont[0]/shell/shellcont[1]/shell[1]").selectItem("        326", "C          4")
    session.findById("wnd[0]/shellcont[1]/shell/shellcont[0]/shell/shellcont[1]/shell[1]").ensureVisibleHorizontalItem("        326", "C          4")
    session.findById("wnd[0]/shellcont[1]/shell/shellcont[0]/shell/shellcont[1]/shell[1]").changeCheckbox("        326", "C          4", -1)
    session.findById("wnd[0]/shellcont[1]/shell/shellcont[0]/shell/shellcont[1]/shell[1]").selectItem("        327", "C          4")
    session.findById("wnd[0]/shellcont[1]/shell/shellcont[0]/shell/shellcont[1]/shell[1]").ensureVisibleHorizontalItem("        327", "C          4")
    session.findById("wnd[0]/shellcont[1]/shell/shellcont[0]/shell/shellcont[1]/shell[1]").changeCheckbox("        327", "C          4", -1)
    session.findById("wnd[0]/shellcont[1]/shell/shellcont[0]/shell/shellcont[1]/shell[1]").selectItem("        328", "C          4")
    session.findById("wnd[0]/shellcont[1]/shell/shellcont[0]/shell/shellcont[1]/shell[1]").ensureVisibleHorizontalItem("        328", "C          4")
    session.findById("wnd[0]/shellcont[1]/shell/shellcont[0]/shell/shellcont[1]/shell[1]").changeCheckbox("        328", "C          4", -1)
    session.findById("wnd[0]/shellcont[1]/shell/shellcont[0]/shell/shellcont[1]/shell[1]").selectItem("        329", "C          4")
    session.findById("wnd[0]/shellcont[1]/shell/shellcont[0]/shell/shellcont[1]/shell[1]").ensureVisibleHorizontalItem("        329", "C          4")
    session.findById("wnd[0]/shellcont[1]/shell/shellcont[0]/shell/shellcont[1]/shell[1]").changeCheckbox("        329", "C          4", -1)
    session.findById("wnd[0]/shellcont[1]/shell/shellcont[0]/shell/shellcont[1]/shell[1]").selectItem("        330", "C          4")
    session.findById("wnd[0]/shellcont[1]/shell/shellcont[0]/shell/shellcont[1]/shell[1]").ensureVisibleHorizontalItem("        330", "C          4")
    session.findById("wnd[0]/shellcont[1]/shell/shellcont[0]/shell/shellcont[1]/shell[1]").changeCheckbox("        330", "C          4", -1)
    session.findById("wnd[0]/shellcont[1]/shell/shellcont[0]/shell/shellcont[1]/shell[1]").selectItem("        331", "C          4")
    session.findById("wnd[0]/shellcont[1]/shell/shellcont[0]/shell/shellcont[1]/shell[1]").ensureVisibleHorizontalItem("        331", "C          4")
    session.findById("wnd[0]/shellcont[1]/shell/shellcont[0]/shell/shellcont[1]/shell[1]").changeCheckbox("        331", "C          4", -1)
    session.findById("wnd[0]/shellcont[1]/shell/shellcont[0]/shell/shellcont[1]/shell[1]").expandNode("        459")
    session.findById("wnd[0]/shellcont[1]/shell/shellcont[0]/shell/shellcont[1]/shell[1]").topNode = "        268"
    session.findById("wnd[0]/shellcont[1]/shell/shellcont[0]/shell/shellcont[1]/shell[1]").selectItem("        462", "C          4")
    session.findById("wnd[0]/shellcont[1]/shell/shellcont[0]/shell/shellcont[1]/shell[1]").ensureVisibleHorizontalItem("        462", "C          4")
    session.findById("wnd[0]/shellcont[1]/shell/shellcont[0]/shell/shellcont[1]/shell[1]").topNode = "        345"
    session.findById("wnd[0]/shellcont[1]/shell/shellcont[0]/shell/shellcont[1]/shell[1]").changeCheckbox("        462", "C          4", -1)
    session.findById("wnd[0]/shellcont[1]/shell/shellcont[0]/shell/shellcont[1]/shell[1]").selectItem("        463", "C          4")
    session.findById("wnd[0]/shellcont[1]/shell/shellcont[0]/shell/shellcont[1]/shell[1]").ensureVisibleHorizontalItem("        463", "C          4")
    session.findById("wnd[0]/shellcont[1]/shell/shellcont[0]/shell/shellcont[1]/shell[1]").changeCheckbox("        463", "C          4", -1)
    session.findById("wnd[0]/shellcont[1]/shell/shellcont[0]/shell/shellcont[1]/shell[1]").selectItem("        464", "C          4")
    session.findById("wnd[0]/shellcont[1]/shell/shellcont[0]/shell/shellcont[1]/shell[1]").ensureVisibleHorizontalItem("        464", "C          4")
    session.findById("wnd[0]/shellcont[1]/shell/shellcont[0]/shell/shellcont[1]/shell[1]").changeCheckbox("        464", "C          4", -1)
    session.findById("wnd[0]/shellcont[1]/shell/shellcont[0]/shell/shellcont[1]/shell[1]").selectItem("        465", "C          4")
    session.findById("wnd[0]/shellcont[1]/shell/shellcont[0]/shell/shellcont[1]/shell[1]").ensureVisibleHorizontalItem("        465", "C          4")
    session.findById("wnd[0]/shellcont[1]/shell/shellcont[0]/shell/shellcont[1]/shell[1]").changeCheckbox("        465", "C          4", -1)
    session.findById("wnd[0]/shellcont[1]/shell/shellcont[0]/shell/shellcont[1]/shell[1]").selectItem("        466", "C          4")
    session.findById("wnd[0]/shellcont[1]/shell/shellcont[0]/shell/shellcont[1]/shell[1]").ensureVisibleHorizontalItem("        466", "C          4")
    session.findById("wnd[0]/shellcont[1]/shell/shellcont[0]/shell/shellcont[1]/shell[1]").changeCheckbox("        466", "C          4", -1)
    session.findById("wnd[0]/shellcont[1]/shell/shellcont[0]/shell/shellcont[1]/shell[1]").selectItem("        467", "C          4")
    session.findById("wnd[0]/shellcont[1]/shell/shellcont[0]/shell/shellcont[1]/shell[1]").ensureVisibleHorizontalItem("        467", "C          4")
    session.findById("wnd[0]/shellcont[1]/shell/shellcont[0]/shell/shellcont[1]/shell[1]").changeCheckbox("        467", "C          4", -1)
    session.findById("wnd[0]/shellcont[1]/shell/shellcont[0]/shell/shellcont[1]/shell[1]").selectItem("        468", "C          4")
    session.findById("wnd[0]/shellcont[1]/shell/shellcont[0]/shell/shellcont[1]/shell[1]").ensureVisibleHorizontalItem("        468", "C          4")
    session.findById("wnd[0]/shellcont[1]/shell/shellcont[0]/shell/shellcont[1]/shell[1]").changeCheckbox("        468", "C          4", -1)
    session.findById("wnd[0]/shellcont[1]/shell/shellcont[0]/shell/shellcont[1]/shell[1]").selectItem("        469", "C          4")
    session.findById("wnd[0]/shellcont[1]/shell/shellcont[0]/shell/shellcont[1]/shell[1]").ensureVisibleHorizontalItem("        469", "C          4")
    session.findById("wnd[0]/shellcont[1]/shell/shellcont[0]/shell/shellcont[1]/shell[1]").changeCheckbox("        469", "C          4", -1)
    session.findById("wnd[0]/shellcont[1]/shell/shellcont[0]/shell/shellcont[1]/shell[1]").expandNode("        586")
    session.findById("wnd[0]/shellcont[1]/shell/shellcont[0]/shell/shellcont[1]/shell[1]").topNode = "        345"
    session.findById("wnd[0]/shellcont[1]/shell/shellcont[0]/shell/shellcont[1]/shell[1]").selectItem("        589", "C          4")
    session.findById("wnd[0]/shellcont[1]/shell/shellcont[0]/shell/shellcont[1]/shell[1]").ensureVisibleHorizontalItem("        589", "C          4")
    session.findById("wnd[0]/shellcont[1]/shell/shellcont[0]/shell/shellcont[1]/shell[1]").topNode = "        466"
    session.findById("wnd[0]/shellcont[1]/shell/shellcont[0]/shell/shellcont[1]/shell[1]").changeCheckbox("        589", "C          4", -1)
    session.findById("wnd[0]/shellcont[1]/shell/shellcont[0]/shell/shellcont[1]/shell[1]").selectItem("        590", "C          4")
    session.findById("wnd[0]/shellcont[1]/shell/shellcont[0]/shell/shellcont[1]/shell[1]").ensureVisibleHorizontalItem("        590", "C          4")
    session.findById("wnd[0]/shellcont[1]/shell/shellcont[0]/shell/shellcont[1]/shell[1]").changeCheckbox("        590", "C          4", -1)
    session.findById("wnd[0]/shellcont[1]/shell/shellcont[0]/shell/shellcont[1]/shell[1]").selectItem("        591", "C          4")
    session.findById("wnd[0]/shellcont[1]/shell/shellcont[0]/shell/shellcont[1]/shell[1]").ensureVisibleHorizontalItem("        591", "C          4")
    session.findById("wnd[0]/shellcont[1]/shell/shellcont[0]/shell/shellcont[1]/shell[1]").changeCheckbox("        591", "C          4", -1)
    session.findById("wnd[0]/shellcont[1]/shell/shellcont[0]/shell/shellcont[1]/shell[1]").selectItem("        592", "C          4")
    session.findById("wnd[0]/shellcont[1]/shell/shellcont[0]/shell/shellcont[1]/shell[1]").ensureVisibleHorizontalItem("        592", "C          4")
    session.findById("wnd[0]/shellcont[1]/shell/shellcont[0]/shell/shellcont[1]/shell[1]").changeCheckbox("        592", "C          4", -1)
    session.findById("wnd[0]/shellcont[1]/shell/shellcont[0]/shell/shellcont[1]/shell[1]").selectItem("        593", "C          4")
    session.findById("wnd[0]/shellcont[1]/shell/shellcont[0]/shell/shellcont[1]/shell[1]").ensureVisibleHorizontalItem("        593", "C          4")
    session.findById("wnd[0]/shellcont[1]/shell/shellcont[0]/shell/shellcont[1]/shell[1]").changeCheckbox("        593", "C          4", -1)
    session.findById("wnd[0]/shellcont[1]/shell/shellcont[0]/shell/shellcont[1]/shell[1]").expandNode("        662")
    session.findById("wnd[0]/shellcont[1]/shell/shellcont[0]/shell/shellcont[1]/shell[1]").topNode = "        466"
    session.findById("wnd[0]/shellcont[1]/shell/shellcont[0]/shell/shellcont[1]/shell[1]").selectItem("        665", "C          4")
    session.findById("wnd[0]/shellcont[1]/shell/shellcont[0]/shell/shellcont[1]/shell[1]").ensureVisibleHorizontalItem("        665", "C          4")
    session.findById("wnd[0]/shellcont[1]/shell/shellcont[0]/shell/shellcont[1]/shell[1]").topNode = "        521"
    session.findById("wnd[0]/shellcont[1]/shell/shellcont[0]/shell/shellcont[1]/shell[1]").changeCheckbox("        665", "C          4", -1)
    session.findById("wnd[0]/shellcont[1]/shell/shellcont[0]/shell/shellcont[1]/shell[1]").selectItem("        666", "C          4")
    session.findById("wnd[0]/shellcont[1]/shell/shellcont[0]/shell/shellcont[1]/shell[1]").ensureVisibleHorizontalItem("        666", "C          4")
    session.findById("wnd[0]/shellcont[1]/shell/shellcont[0]/shell/shellcont[1]/shell[1]").changeCheckbox("        666", "C          4", -1)
    session.findById("wnd[0]/shellcont[1]/shell/shellcont[0]/shell/shellcont[1]/shell[1]").selectItem("        667", "C          4")
    session.findById("wnd[0]/shellcont[1]/shell/shellcont[0]/shell/shellcont[1]/shell[1]").ensureVisibleHorizontalItem("        667", "C          4")
    session.findById("wnd[0]/shellcont[1]/shell/shellcont[0]/shell/shellcont[1]/shell[1]").changeCheckbox("        667", "C          4", -1)
    session.findById("wnd[0]/shellcont[1]/shell/shellcont[0]/shell/shellcont[1]/shell[1]").selectItem("        668", "C          4")
    session.findById("wnd[0]/shellcont[1]/shell/shellcont[0]/shell/shellcont[1]/shell[1]").ensureVisibleHorizontalItem("        668", "C          4")
    session.findById("wnd[0]/shellcont[1]/shell/shellcont[0]/shell/shellcont[1]/shell[1]").changeCheckbox("        668", "C          4", -1)


def fill_1073(session: Any, org_nums: List[str], start_time: str) -> None:
    """填充1072"""
    session.findById(  # 报告期间
        "wnd[0]/usr/subSUB_MAIN:SAPLAQ_ADHOC:0212/subSUB_APPLICATION:SAPLHR_QUERY_APPL_AREA:0122/subSUB:SAPLHR_QUERY_APPL_AREA:0121/btnDYNP121-EVALUATION_PERIOD_TEXT").press()
    session.findById(
        "wnd[0]/usr/subSUB_MAIN:SAPLAQ_ADHOC:0212/subSUB_APPLICATION:SAPLHR_QUERY_APPL_AREA:0122/subSUB:SAPLHR_QUERY_APPL_AREA:0120/cmbDD_DATE").key = "8"
    # 开始日期
    session.findById(
        "wnd[0]/usr/subSUB_MAIN:SAPLAQ_ADHOC:0212/subSUB_APPLICATION:SAPLHR_QUERY_APPL_AREA:0122/subSUB:SAPLHR_QUERY_APPL_AREA:0120/ctxtG_APPL_AREA-BEGDA").text = start_time
    grid_view_ctrl_id = 'wnd[0]/usr/subSUB_MAIN:SAPLAQ_ADHOC:0212/subSUB_SELECTION:SAPLAQ_ADHOC:0310/cntlSEL_DEF_CONTAINER/shellcont/shell'
    grid_view_ctrl = GridViewCtrl(session, grid_view_ctrl_id)
    grid_view_ctrl['字段名称'].find('对象标识').same_line('更多值 ').press_button()
    # 清空对象标识
    session.findById("wnd[1]/tbar[0]/btn[16]").press()

    # 将组织机构编码放入剪切板
    text = "\r\n".join([x for x in org_nums if x])
    pyperclip.copy(text)
    session.findById("wnd[1]/tbar[0]/btn[24]").press()
    session.findById("wnd[1]/tbar[0]/btn[8]").press()
    # 点击输出生成机构信息表单
    session.findById("wnd[0]/tbar[1]/btn[8]").press()


HEADER_IDS: List[str] = ['VALUE1', 'VALUE5', 'VALUE6', 'VALUE7', 'VALUE8', 'VALUE11', 'VALUE9', 'VALUE10', 'VALUE26',
                         'VALUE27', 'VALUE28', 'VALUE29', 'VALUE30', 'VALUE14', 'VALUE15', 'VALUE16',
                         'VALUE17', 'VALUE21', 'VALUE33', 'VALUE34', 'VALUE35', 'VALUE36', 'VALUE38', 'VALUE39', 'VALUE40',
                         'VALUE41', 'TEXT41', 'VALUE113', 'VALUE114', 'VALUE115', 'VALUE116',
                         'TEXT117', 'VALUE118', 'TEXT119', 'TEXT120', 'TEXT121', 'TEXT122', 'VALUE123', 'VALUE124',
                         'TEXT125', 'TEXT126', 'TEXT130', 'TEXT131', 'TEXT107', 'VALUE524', 'VALUE525',
                         'VALUE526', 'VALUE527', 'TEXT528', 'VALUE44', 'VALUE45', 'VALUE46', 'VALUE47', 'VALUE49', 'VALUE50',
                         'VALUE51', 'VALUE138', 'VALUE139', 'VALUE140', 'VALUE141', 'VALUE142',
                         'VALUE143', 'VALUE279', 'VALUE280', 'VALUE281', 'VALUE282', 'TEXT283', 'TEXT284', 'TEXT285',
                         'VALUE213', 'VALUE214', 'VALUE215', 'VALUE216', 'TEXT217', 'TEXT218', 'TEXT219',
                         'TEXT220', 'TEXT221', 'TEXT222', 'VALUE223', 'VALUE224', 'TEXT225', 'TEXT226', 'VALUE227',
                         'VALUE405', 'VALUE406', 'VALUE407', 'VALUE408', 'VALUE409', 'TEXT410', 'TEXT411',
                         'TEXT412', 'VALUE593', 'VALUE594', 'VALUE595', 'TEXT595', 'TEXT596', 'TEXT182']


def export_1073(session: Any, job_ids: List[str], key_date: str) -> AdTable:
    """导出1073
       ------------------
       入参：
       session: SAP SESSION，如为None，则新打开SAP
       org_nums: xxx机构编码---列表
       start_time: 开始日期 --- 字符串
       ------------------
       返回值：
       AdTable，可通过.wb访问Workbook，或.ws访问Worksheet
       ------------------
       调用样例：
       _table: AdTable = export_1073(None, ['04613370'], '20200301')
       _table.filename = '模板_1073' --------- 指定保存1073的名称
       _table.save_to('x:/') # 保存模板至x:/ ----- 指定保存的文件夹，不存在则自动创建
    """
    logging.info(f'导出组合逻辑查询1073，岗位编号：{job_ids}，关键日期：{key_date}')
    if session is None:
        session = attach_sap()
    elif isinstance(session, str):
        session = attach_sap(session)
    enter_1073(session)  # 进入1073信息集查询屏
    query_selection(session, '----T87', select_1073, HEADER_IDS)  # 勾选1073选项
    fill_1073(session, job_ids, key_date)  # 填入组织机构编号和开始日期，并查询
    _table: AdTable = export_query(session, template_file=f'{TEMPLATE_DIR}/模板_1073.xlsx', query_name='----T87')
    _table['A'].apply(init_sap_id)
    return _table


# example
if __name__ == '__main__':
    li = ['30253976', '30253977', '30253978', '30253979', '30253980', '30253981', '30253982', '30253983', '30253984', '30253985', '30253986', '30253987', '30253988', '30253989', '30253990', '30253991', '30253992', '30253993', '30253994', '30253995', '30253996', '30253997', '30253998', '30253999',
          '30254000', '30254001', '30254002', '30254004', '30254005', '30254006', '30254007', '30254008', '30254009', '30254010', '30254011', '30254012', '30254013', '30254014', '30254015', '30254016', '30254017', '30254018', '30254019', '30254020', '30254021', '30254022', '30254023', '30254024',
          '30254025', '30254026', '30254027', '30254028', '30254029', '30254030', '30254031', '30254032', '30254033', '30254034', '30254035', '30254036', '30254037', '30254038', '30254039', '30254040', '30254042', '30254043', '30254044', '30254045', '30254046', '30254047', '30254048', '30254049',
          '30254050', '30254051', '30254052', '30254053', '30254054', '30254055', '30254056', '30254057', '30256897', '30256898', '30256899', '30256900', '30256901', '30256911', '30257329', '30257330', '30257347', '30257353', '30257541', '30257542', '30257543', '30257544', '30257546', '30257547',
          '30257548', '30257549', '30257550', '30257551', '30257552', '30257553', '30257560', '30258281', '30258404', '30258405', '30258406', '30258407', '30258408', '30258409', '30258410', '30258411', '30258412', '30258413', '30258475', '30258476', '30258477', '30258478', '30258479', '30258481',
          '30258482', '30258483', '30260148', '30260149']
    _table: AdTable = export_1073(None, li, '20200501')
    _table.save_to('x:/')
