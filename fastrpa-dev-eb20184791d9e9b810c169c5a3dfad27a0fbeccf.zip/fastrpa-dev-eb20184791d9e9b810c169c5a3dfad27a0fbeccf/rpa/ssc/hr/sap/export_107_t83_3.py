"""导出组合逻辑查询107_t83_3"""
import logging
from typing import Any, List

import pyperclip
from rpa.fastrpa.adtable import AdTable
from rpa.fastrpa.sap.grid_view_ctrl import GridViewCtrl
from rpa.fastrpa.sap.session import attach_sap
from rpa.ssc.sap.query import export_query, query_selection
from rpa.ssc.sap.utils import init_sap_id


def enter_107(session: Any) -> None:
    """进入107_t83_3"""
    session.findById("wnd[0]").maximize()
    session.findById("wnd[0]/tbar[0]/okcd").text = "/n S_PH0_48000513"
    session.findById("wnd[0]").sendVKey(0)
    session.findById("wnd[1]/usr/cmbDYNP4100-DD_WORKSPACE").setFocus()
    session.findById("wnd[1]/usr/cmbDYNP4100-DD_WORKSPACE").key = "2"
    session.findById("wnd[1]/usr/cmbDYNP4100-DD_USERGROUP").setFocus()
    session.findById("wnd[1]/usr/cmbDYNP4100-DD_USERGROUP").key = "107"
    session.findById("wnd[1]/usr/tblSAPLAQ_INT_FUNCTIONSTCH_FUNCAREAS").getAbsoluteRow(2).selected = -1
    session.findById("wnd[1]/usr/tblSAPLAQ_INT_FUNCTIONSTCH_FUNCAREAS/txtDYNP4100_TC_FUNCAREAS-NAME[0,2]").setFocus()
    session.findById("wnd[1]/usr/tblSAPLAQ_INT_FUNCTIONSTCH_FUNCAREAS/txtDYNP4100_TC_FUNCAREAS-NAME[0,2]").caretPosition = 0
    session.findById("wnd[1]/tbar[0]/btn[0]").press()


def fill_107_t83_3(session: Any, object_ids: List[str], key_date: str, begin_date='', end_date='') -> None:
    """填充107_t83_3"""
    session.findById("wnd[0]/usr/subSUB_MAIN:SAPLAQ_ADHOC:0212/subSUB_APPLICATION:SAPLHR_QUERY_APPL_AREA:0122/subSUB:SAPLHR_QUERY_APPL_AREA:0121/btnDYNP121-EVALUATION_PERIOD_TEXT").press()  # 点击报告时间
    if key_date != '':
        session.findById("wnd[0]/usr/subSUB_MAIN:SAPLAQ_ADHOC:0212/subSUB_APPLICATION:SAPLHR_QUERY_APPL_AREA:0122/subSUB:SAPLHR_QUERY_APPL_AREA:0120/cmbDD_DATE").key = "7"  # 选择关键日期
        session.findById("wnd[0]/usr/subSUB_MAIN:SAPLAQ_ADHOC:0212/subSUB_APPLICATION:SAPLHR_QUERY_APPL_AREA:0122/subSUB:SAPLHR_QUERY_APPL_AREA:0120/ctxtG_APPL_AREA-BEGDA").text = key_date  # 填充关键日期
    else:
        session.findById("wnd[0]/usr/subSUB_MAIN:SAPLAQ_ADHOC:0212/subSUB_APPLICATION:SAPLHR_QUERY_APPL_AREA:0122/subSUB:SAPLHR_QUERY_APPL_AREA:0120/cmbDD_DATE").key = "8"  # 其他期间
        session.findById("wnd[0]/usr/subSUB_MAIN:SAPLAQ_ADHOC:0212/subSUB_APPLICATION:SAPLHR_QUERY_APPL_AREA:0122/subSUB:SAPLHR_QUERY_APPL_AREA:0120/ctxtG_APPL_AREA-BEGDA").text = begin_date  # 开始日期
        session.findById("wnd[0]/usr/subSUB_MAIN:SAPLAQ_ADHOC:0212/subSUB_APPLICATION:SAPLHR_QUERY_APPL_AREA:0122/subSUB:SAPLHR_QUERY_APPL_AREA:0120/ctxtG_APPL_AREA-ENDDA").text = end_date  # 结束日期
    grid_view_ctrl_id = 'wnd[0]/usr/subSUB_MAIN:SAPLAQ_ADHOC:0212/subSUB_SELECTION:SAPLAQ_ADHOC:0310/cntlSEL_DEF_CONTAINER/shellcont/shell'
    grid_view_ctrl = GridViewCtrl(session, grid_view_ctrl_id)
    grid_view_ctrl['字段名称'].find('对象标识').same_line('更多值 ').press_button()
    session.findById("wnd[1]/tbar[0]/btn[16]").press()  # 清空
    pyperclip.copy('\r\n'.join(object_ids))  # 复制到剪切板
    session.findById("wnd[1]/tbar[0]/btn[24]").press()  # 粘贴
    session.findById("wnd[1]/tbar[0]/btn[8]").press()  # 确认
    session.findById("wnd[0]/tbar[1]/btn[8]").press()  # 输出


HEADER_IDS: List[str] = ['VALUE1', 'VALUE2', 'VALUE3', 'VALUE4', 'VALUE5', 'VALUE6', 'VALUE7', 'VALUE8', 'VALUE18', 'VALUE19', 'VALUE126', 'VALUE127', 'TEXT128', 'VALUE41', 'VALUE42', 'VALUE43', 'VALUE44', 'VALUE64', 'VALUE45', 'TEXT45', 'VALUE46', 'TEXT46', 'VALUE53', 'TEXT53', 'VALUE54', 'TEXT54', 'VALUE55', 'VALUE48', 'TEXT48', 'VALUE49', 'TEXT52', 'TEXT60', 'TEXT61',
                         'TEXT62', 'TEXT56', 'TEXT57', 'TEXT58', 'TEXT59', 'VALUE105', 'VALUE106', 'VALUE107', 'VALUE108', 'VALUE110', 'VALUE111', 'VALUE112', 'VALUE96', 'VALUE97', 'VALUE98', 'VALUE99', 'TEXT100', 'TEXT101', 'TEXT102']


def throw_exception_when_query_changed(session: Any):
    raise Exception('组合逻辑查询变式107----T83-3列ID与开发时不匹配')


def export_107_t83_3(session: Any, job_ids: List[str], key_date: str, begin_date='', end_date='') -> AdTable:
    """导出107_t83_3
       ------------------
       入参：
       session: SAP SESSION，如为None，则新打开SAP
       job_ids: 岗位编码
       key_date: 关键日期
       ------------------
       返回值：
       AdTable，可通过.wb访问Workbook，或.ws访问Worksheet
       ------------------
       调用样例：
       _table: AdTable = export_107_t83_3(None, ['04613370'], '20200301')
       _table.filename = '模板_107_t83_3'
       _table.save_to('x:/') # 保存模板至x:/下
    """
    logging.info(f'导出组合逻辑查询107_t83_3，岗位编号：{job_ids}，关键日期：{key_date}，开始日期：{begin_date}，结束日期：{end_date}')
    if all(map(lambda v: v == '', job_ids)) is True:
        raise Exception('岗位编号全为空值，请检查模板岗位编号是否填充')
    if session is None:
        session = attach_sap()
    elif isinstance(session, str):
        session = attach_sap(session)
    enter_107(session)  # 进入107信息集查询屏
    query_selection(session, '----T83-3', throw_exception_when_query_changed, HEADER_IDS)  # 勾选107_t83_3选项
    fill_107_t83_3(session, job_ids, key_date, begin_date=begin_date, end_date=end_date)  # 填入岗位编号和关键日期，并查询
    _lt: AdTable = export_query(session, query_name='----T83-3')
    _lt['A'].apply(init_sap_id)
    _lt.filename = 'T83-3'
    return _lt


# example
if __name__ == '__main__':
    from rpa.fastrpa.log import config
    config()
    sap_ids = ['00990181', '03492865', '03855604', '04442815', '00992832', '03101843', '03101844', '03269577', '03269578',
               '03315772', '03315774', '04110004', '04117893', '04117895', '00994109', '03427236', '03849405', '00994717',
               '00994143', '00994093', '00994789', '00994786', '00994569', '00994788', '03312929', '03312931', '03312930',
               '03312932', '03443071', '03443072', '00996006', '03443073', '03458210', '03491045', '03491046', '00995700',
               '00995701', '03432254', '03116316', '03432257', '04180301', '01000662', '01001066', '01001085', '04067245',
               '01001758', '03070862', '03477682', '03070863', '03236796', '03507136', '01001697', '01002187', '01001689',
               '03255473', '03275262', '01003292', '01004680', '01004814', '03221889', '03064092', '01004514', '01004755',
               '03099444', '03115327', '01004754', '03115329', '03388545', '01004821', '03147104', '03299371', '01004753',
               '03088231', '03388535', '03087017', '01003966', '03275269', '03234806', '03160235', '03561186', '01004494',
               '03115328', '03064087', '01004822', '01003981', '03099446', '01004820', '01004828', '04565926', '01004757',
               '01004758', '01004824', '01003967', '01004756', '03087681', '03147071', '03087677', '01003609', '03102268',
               '01004817', '03102272', '04565977', '03087689', '01004895', '04565975', '03115330', '03160238', '01004131',
               '03087695', '03064072', '01003931', '03459287', '03087023', '01003919', '03139792', '01004726', '03147058',
               '03064068', '01004502', '03087696', '03102300', '03064066', '01004902', '03087558', '01004865', '03087706',
               '03655238', '01004752', '03088339', '04565943', '03115335', '01004904', '03075584', '03314173', '01004089',
               '03087707', '03087708', '03314259', '01004644', '03265748', '03265749', '01004819', '01004806', '01004432',
               '03251938', '03096977', '01004388', '01004892', '01004825', '03236586', '03234808', '03087699', '03344583',
               '01004788', '03075576', '01004823', '03388581', '03096980', '03087692', '01004518', '01004438', '03087648',
               '03255164', '03217238', '03063885', '01004687', '03468233', '01004357', '03160326', '03234812', '04537034',
               '03399983', '03289409', '03096988', '01004826', '01004401', '03432850', '01004827', '03115342', '03251980',
               '03857964', '03791526', '03234809', '03275336', '01004886', '01004725', '03146791', '03372948', '01004555',
               '03255167', ]
    _lt: AdTable = export_107_t83_3(None, sap_ids, '', '20200601', '99991231')
    _lt.save_to('x:/')
