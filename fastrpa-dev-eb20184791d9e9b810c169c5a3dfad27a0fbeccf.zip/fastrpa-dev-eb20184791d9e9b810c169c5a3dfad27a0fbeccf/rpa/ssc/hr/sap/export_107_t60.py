"""导出组合逻辑查询107（----T60）"""
import logging
from typing import Any, List

import pyperclip
from rpa.fastrpa.adtable import AdTable
from rpa.fastrpa.sap.grid_view_ctrl import GridViewCtrl
from rpa.fastrpa.sap.session import attach_sap
from rpa.ssc.sap.query import export_query, query_selection
from rpa.ssc.sap.utils import init_sap_id


def enter_107(session: Any) -> None:
    """进入107"""
    session.findById("wnd[0]").maximize()
    session.findById("wnd[0]/tbar[0]/okcd").text = "/n S_PH0_48000513"
    session.findById("wnd[0]").sendVKey(0)
    session.findById("wnd[1]/usr/cmbDYNP4100-DD_WORKSPACE").setFocus()
    session.findById("wnd[1]/usr/cmbDYNP4100-DD_WORKSPACE").key = "2"
    session.findById("wnd[1]/usr/cmbDYNP4100-DD_USERGROUP").setFocus()
    session.findById("wnd[1]/usr/cmbDYNP4100-DD_USERGROUP").key = "107"
    session.findById("wnd[1]/usr/tblSAPLAQ_INT_FUNCTIONSTCH_FUNCAREAS").getAbsoluteRow(2).selected = -1
    session.findById("wnd[1]/usr/tblSAPLAQ_INT_FUNCTIONSTCH_FUNCAREAS/txtDYNP4100_TC_FUNCAREAS-NAME[0,2]").setFocus()
    session.findById("wnd[1]/usr/tblSAPLAQ_INT_FUNCTIONSTCH_FUNCAREAS/txtDYNP4100_TC_FUNCAREAS-NAME[0,2]").caretPosition = 0
    session.findById("wnd[1]/tbar[0]/btn[0]").press()


def select_107_t60(session: Any) -> None:
    """勾选107（----T60）"""
    raise Exception('列不对应')


def fill_107_t60(session: Any, job_ids: List[str], key_date: str) -> None:
    """填充107（----T60）"""
    pyperclip.copy('\r\n'.join(job_ids))  # 复制到剪切板
    grid_view_ctrl_id = 'wnd[0]/usr/subSUB_MAIN:SAPLAQ_ADHOC:0212/subSUB_SELECTION:SAPLAQ_ADHOC:0310/cntlSEL_DEF_CONTAINER/shellcont/shell'
    grid_view_ctrl = GridViewCtrl(session, grid_view_ctrl_id)
    grid_view_ctrl['字段名称'].find('对象标识').same_line('更多值 ').press_button()
    session.findById("wnd[1]/tbar[0]/btn[16]").press()
    session.findById("wnd[1]/tbar[0]/btn[24]").press()  # 粘贴
    session.findById("wnd[1]/tbar[0]/btn[8]").press()
    session.findById("wnd[0]/usr/subSUB_MAIN:SAPLAQ_ADHOC:0212/subSUB_APPLICATION:SAPLHR_QUERY_APPL_AREA:0122/subSUB:SAPLHR_QUERY_APPL_AREA:0121/btnDYNP121-EVALUATION_PERIOD_TEXT").press()  # 报告期间
    session.findById("wnd[0]/usr/subSUB_MAIN:SAPLAQ_ADHOC:0212/subSUB_APPLICATION:SAPLHR_QUERY_APPL_AREA:0122/subSUB:SAPLHR_QUERY_APPL_AREA:0120/cmbDD_DATE").key = "7"  # 关键日期
    session.findById("wnd[0]/usr/subSUB_MAIN:SAPLAQ_ADHOC:0212/subSUB_APPLICATION:SAPLHR_QUERY_APPL_AREA:0122/subSUB:SAPLHR_QUERY_APPL_AREA:0120/ctxtG_APPL_AREA-BEGDA").text = key_date
    session.findById("wnd[0]/tbar[1]/btn[8]").press()


HEADER_IDS: List[str] = ['VALUE1', 'VALUE2', 'VALUE3', 'VALUE4', 'VALUE9', 'VALUE5', 'VALUE6', 'VALUE7', 'VALUE8', 'VALUE12', 'VALUE13', 'VALUE14', 'VALUE15',
                         'TEXT2', 'VALUE17', 'TEXT17', 'VALUE18', 'VALUE19', 'VALUE126', 'VALUE127', 'TEXT128', 'VALUE41', 'VALUE42', 'VALUE43', 'VALUE44',
                         'VALUE64', 'VALUE45', 'TEXT45', 'VALUE46', 'TEXT46', 'VALUE53', 'TEXT53', 'VALUE54', 'TEXT54', 'VALUE55', 'VALUE48', 'TEXT48',
                         'VALUE49', 'TEXT52', 'TEXT60', 'TEXT62', 'TEXT61', 'TEXT56', 'TEXT57', 'TEXT58', 'TEXT59', 'VALUE105', 'VALUE106', 'VALUE107',
                         'VALUE108', 'VALUE110', 'VALUE111', 'VALUE112', 'VALUE113', 'VALUE96', 'VALUE97', 'VALUE98', 'VALUE99', 'VALUE100', 'TEXT100',
                         'VALUE101', 'TEXT101', 'VALUE102', 'TEXT102']


def export_107_t60(session: Any, job_ids: List[str], key_date: str) -> AdTable:
    """导出107（----T60）
       ------------------
       入参：
       session: SAP SESSION，如为None，则新打开SAP
       job_ids: 岗位编码
       key_date: 关键日期，yyyyMMdd格式，例如：20200901
       ------------------
       返回值：
       AdTable，可通过.wb访问Workbook，或.ws访问Worksheet
       ------------------
       调用样例：
       _table: AdTable = export_107_t60(None, ['04613370'], '20200301')
       _table.filename = '模板_107_T60'
       _table.save_to('x:/') # 保存模板至x:/下
    """
    logging.info(f'导出组合逻辑查询107，岗位编号：{job_ids}，关键日期：{key_date}')
    if all(map(lambda v: v == '', job_ids)) is True:
        raise Exception('岗位编号全为空值，请检查模板岗位编号是否填充')
    if session is None:
        session = attach_sap()
    elif isinstance(session, str):
        session = attach_sap(session)
    enter_107(session)  # 进入1071信息集查询屏
    query_selection(session, '----T60', select_107_t60, HEADER_IDS)  # 勾选1071选项
    fill_107_t60(session, job_ids, key_date)  # 填入员工编号和关键日期，并查询
    _table: AdTable = export_query(session, query_name='----T60')
    _table['A'].apply(init_sap_id)
    _table['R'].apply(init_sap_id)
    _table.filename = '107_T60'
    return _table


# example
if __name__ == '__main__':
    from rpa.fastrpa.log import config
    config()
    _table: AdTable = export_107_t60(None, ['04441606'], '20200901')
    _table.save_to('x:/')
