"""导出组合逻辑查询103_T10"""
import datetime
import logging
import traceback
from pathlib import Path
from typing import Any, List

import pyperclip
import rpa.config
from rpa.fastrpa.adtable import AdTable
from rpa.fastrpa.date_funcs import valid_date
from rpa.fastrpa.ftp import MYFTP
from rpa.fastrpa.log import config, logfn2
from rpa.fastrpa.sap.grid_view_ctrl import GridViewCtrl
from rpa.fastrpa.sap.session import SAP
from rpa.ssc.hr.orm.session import DbSession
from rpa.ssc.hr.orm.td_hr_gang_wei_diao_pei_rulebase import Event
from rpa.ssc.sap.query import export_query, query_selection
from rpa.ssc.sap.utils import init_sap_id


def enter_103(session: Any) -> None:
    """进入103"""
    session.findById("wnd[0]").maximize()
    session.findById("wnd[0]/tbar[0]/okcd").text = "/n S_PH0_48000513"
    session.findById("wnd[0]").sendVKey(0)
    session.findById("wnd[1]/usr/cmbDYNP4100-DD_WORKSPACE").setFocus()
    session.findById("wnd[1]/usr/cmbDYNP4100-DD_WORKSPACE").key = "2"  # 全局区域（跨集团）
    session.findById("wnd[1]/usr/cmbDYNP4100-DD_USERGROUP").setFocus()
    session.findById("wnd[1]/usr/cmbDYNP4100-DD_USERGROUP").key = "103"  # SAP_HR查询   （ZHR_ALL）
    session.findById("wnd[1]/usr/tblSAPLAQ_INT_FUNCTIONSTCH_FUNCAREAS").getAbsoluteRow(1).selected = -1
    session.findById("wnd[1]/usr/tblSAPLAQ_INT_FUNCTIONSTCH_FUNCAREAS/txtDYNP4100_TC_FUNCAREAS-NAME[0,1]").setFocus()
    session.findById("wnd[1]/usr/tblSAPLAQ_INT_FUNCTIONSTCH_FUNCAREAS/txtDYNP4100_TC_FUNCAREAS-NAME[0,1]").caretPosition = 0
    session.findById("wnd[1]/tbar[0]/btn[0]").press()  # 信息集查询（信息集：SAP_HR查询）


def throw_exception_when_query_changed(session: Any):
    raise Exception('组合逻辑查询变式103___T10列ID与开发时不匹配')


def fill_103(session: Any, staff_areas: List[str], key_date: str) -> None:
    """填充103"""
    session.findById("wnd[0]/usr/subSUB_MAIN:SAPLAQ_ADHOC:0210/subSUB_APPLICATION:SAPLHR_QUERY_APPL_AREA:0122/subSUB:SAPLHR_QUERY_APPL_AREA:0121/btnDYNP121-EVALUATION_PERIOD_TEXT").press()  # 点击报告时间
    session.findById("wnd[0]/usr/subSUB_MAIN:SAPLAQ_ADHOC:0210/subSUB_APPLICATION:SAPLHR_QUERY_APPL_AREA:0122/subSUB:SAPLHR_QUERY_APPL_AREA:0120/cmbDD_DATE").key = "7"  # 选择关键日期
    session.findById("wnd[0]/usr/subSUB_MAIN:SAPLAQ_ADHOC:0210/subSUB_APPLICATION:SAPLHR_QUERY_APPL_AREA:0122/subSUB:SAPLHR_QUERY_APPL_AREA:0120/ctxtG_APPL_AREA-BEGDA").text = key_date  # 填充关键日期
    grid_view_ctrl_id = 'wnd[0]/usr/subSUB_MAIN:SAPLAQ_ADHOC:0210/subSUB_SELECTION:SAPLAQ_ADHOC:0310/cntlSEL_DEF_CONTAINER/shellcont/shell'
    grid_view_ctrl = GridViewCtrl(session, grid_view_ctrl_id)
    grid_view_ctrl['字段名称'].find('人事范围').same_line('更多值 ').press_button()
    pyperclip.copy('\r\n'.join(staff_areas))  # 复制到剪切板
    session.findById("wnd[1]/tbar[0]/btn[16]").press()
    session.findById("wnd[1]/tbar[0]/btn[24]").press()  # 粘贴
    try:
        session.findById("wnd[2]/tbar[0]/btn[0]").press()
    except Exception:  # nosec
        pass
    session.findById("wnd[1]/tbar[0]/btn[8]").press()
    session.findById("wnd[0]/tbar[1]/btn[8]").press()  # 输出按钮


HEADER_IDS: List[str] = ['VALUE1273', 'TEXT1273', 'VALUE2', 'VALUE3', 'VALUE4', 'VALUE5', 'TEXT6', 'TEXT7', 'TEXT8', 'TEXT9',
                         'VALUE15', 'VALUE16', 'VALUE17', 'VALUE18', 'VALUE23', 'VALUE24', 'TEXT24', 'VALUE26', 'VALUE27',
                         'VALUE30', 'VALUE31', 'VALUE21', 'VALUE32', 'VALUE22', 'VALUE39', 'VALUE36', 'TEXT36', 'VALUE37',
                         'TEXT37', 'VALUE38', 'TEXT38', 'TEXT35', 'VALUE29', 'VALUE40', 'VALUE1082', 'VALUE1083', 'VALUE1084',
                         'VALUE1085', 'VALUE1086', 'VALUE1087', 'VALUE1088', 'VALUE1089', 'VALUE1090', 'VALUE1091', 'VALUE1092',
                         'VALUE1093', 'VALUE1094', 'VALUE1095', 'VALUE1096', 'TEXT1097', 'VALUE1098', 'VALUE1099', 'VALUE362',
                         'VALUE363', 'VALUE364', 'VALUE365', 'TEXT366', 'TEXT367', 'TEXT368', 'VALUE379', 'TEXT383']


def export_103_t10(staff_areas: List[str], key_date: str) -> AdTable:
    """导出103
       ------------------
       入参：
       staff_area: 人事范围
       key_date: 关键日期
       ------------------
       返回值：
       AdTable，可通过.wb访问Workbook，或.ws访问Worksheet
       ------------------
       调用样例：
       _table: AdTable = export_103(None, ['01576547'], '20200301')
       _table.filename = '模板_103'
       _table.save_to('x:/') # 保存模板至x:/下
    """
    if valid_date(key_date) is False:
        raise Exception(f'组合逻辑查询日期必须为合法日期，yyyyMMdd格式，当前值：{key_date}')
    logging.info(f'导出组合逻辑查询103___T10，人事范围：{staff_areas}，关键日期：{key_date}')
    if all(map(lambda v: v == '', staff_areas)) is True:
        raise Exception('人事范围全为空值')
    with SAP() as session:
        enter_103(session)  # 进入103信息集查询屏
        query_selection(session, '___T10', throw_exception_when_query_changed, HEADER_IDS)  # 勾选103选项
        fill_103(session, staff_areas, key_date)  # 填入人事范围和关键日期，并查询
        _table: AdTable = export_query(session, query_name='___T10')
        _table['A'].apply(init_sap_id)
        _table.filename = '___T10'
        return _table


@logfn2
def export_103_t10_all():
    """从调配码表库BJ列人事范围，逐个导出组合逻辑查询103变式___T10，导出后的结果存放于FTP"""
    config('export_103_t10_all.log')
    staff_areas: List[str] = []  # 人事范围
    with DbSession() as db_session:
        staff_areas = set([r[0] for r in db_session.query(Event.db_BJ).all() if r[0]])  # 去重后的人事范围
    for staff_area in staff_areas:
        now = datetime.datetime.now()
        yyyymm = now.strftime(r'%Y%m')
        yyyymmdd = now.strftime(r'%Y%m%d')
        hhmmss = now.strftime(r'%H%M%S')
        try:
            _table = export_103_t10([staff_area], yyyymmdd)
            local_filename = f'{rpa.config.D_RPA}/HR人事/HR103备份/___T10/{yyyymm}/{yyyymmdd}/{hhmmss}_{staff_area}.xlsx'
            remote_filename = f'/HR103备份/___T10/{yyyymm}/{yyyymmdd}/{hhmmss}_{staff_area}.xlsx'
            Path(local_filename).parent.mkdir(parents=True, exist_ok=True)
            _table.save(local_filename)
            with MYFTP() as ftp:
                ftp.upload_file(local_filename, remote_filename)
        except Exception as e:
            tail_str = '_系统不能读取任何数据' if '系统不能读取任何数据' in str(e) else ''
            local_filename = f'{rpa.config.D_RPA}/HR人事/HR103备份/___T10/{yyyymm}/{yyyymmdd}/{hhmmss}_{staff_area}{tail_str}.log'
            remote_filename = f'/HR103备份/___T10/{yyyymm}/{yyyymmdd}/{hhmmss}_{staff_area}{tail_str}.log'
            Path(local_filename).parent.mkdir(parents=True, exist_ok=True)
            Path(local_filename).write_text(f'{e}\n{traceback.format_exc()}', encoding='utf-8')
            with MYFTP() as ftp:
                ftp.upload_file(local_filename, remote_filename)


if __name__ == '__main__':
    while True:
        export_103_t10_all()
