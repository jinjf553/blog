"""批导调入模板"""
import logging

from rpa.fastrpa.adtable import AdTable, load_from_xlsx_file
from rpa.fastrpa.tempdir import gentempdir
from rpa.ssc.hr.sap.import_xlsx import import_multi


def import_checkin(_in: AdTable) -> bool:
    """上传调入模板/批导调入模板至SAP，成功返回True，失败返回False。"""
    # 导出调入模板为临时文件
    temp_dir = gentempdir()
    logging.info(f'生成调入模板批导文件')
    try:
        filename = _in.save_to(temp_dir)
    except PermissionError:
        _in.filename += '_副本'
        filename = _in.save_to(temp_dir)
    logging.info(f'调入模板生成成功，文件路径：{filename}')
    is_import_succ = import_multi('调入事件批导', filename)
    _in_imported = load_from_xlsx_file(filename, skip_header=6)
    _in.replace_content_by(_in_imported)  # 读取批导结果，并写入原文件
    return is_import_succ
