"""工具类用于操作PPOSE界面，界面各元素结构如下：
       +-------------------------------+
       |            PPOSE              |
       +-------------------------------+
       |GuiNav |                       |
       |       |        GuiView        |
       |       |                       |
       |       |                       |
       |       +-----------------------+
       |       |        GuiTab         |
       |       |                       |
       |       |                       |
       +-------------------------------+
       数据解释：
       GuiNav: 机构树状目录，SAP GuiTree元素
       GuiView: 机构、岗位、人员树状目录，SAP GuiTree元素
       GuiTab: 机构、岗位、人员详情，SAP GuiTab元素
    """
import logging
from functools import lru_cache
from typing import Any, Dict, List

from pandas import DataFrame
from rpa.fastrpa.date_funcs import next_month_01
from rpa.fastrpa.sap.session import (SapSession, attach_sap,
                                     get_all_children_ids)


class GuiNav(object):
    """GuiNav: 机构树状目录，SAP GuiTree元素"""
    org_id_allowlist: List[str] = []  # 业务人员有权限访问的顶层机构 ID
    session: SapSession  # SAP 会话
    df_nav: DataFrame

    def __init__(self, session: SapSession, top_org_ids: List[str] = []):
        self.org_id_allowlist = top_org_ids
        self.session = session
        gui_nav = session.findById("wnd[0]/shellcont/shell/shellcont[1]/shell/shellcont[1]/shell")
        session.findById("wnd[0]/shellcont/shell/shellcont[1]/shell/shellcont[1]/shell").expandNode("          4")  # 展开[中国石化集团公司]
        top_keys = gui_nav.GetAllNodeKeys()  # 顶层机构节点
        exclude_keys = []
        gui_nav.UnselectAll()  # 取消选择
        for key in top_keys:
            org_id = gui_nav.GetItemText(key, 'ORG_OBJID').split('  ')[1]
            if org_id in self.org_id_allowlist:
                gui_nav.selectNode(key)  # 选中机构
            else:
                exclude_keys.append(key)
        session.findById("wnd[0]/shellcont/shell/shellcont[1]/shell/shellcont[0]/shell").pressButton("EXPAND_NODE")  # 展开节点(有可能提供的ID不是顶层ID)
        sap_status = session.findById("wnd[0]/sbar/pane[0]").text
        if '没有选择对象' in sap_status:  # 给定的top_org_ids不是顶层的
            raise Exception(sap_status)
        for _ in range(len(self.org_id_allowlist)):  # 有可能会多次弹出
            try:
                session.findById("wnd[1]/usr/btnBUTTON_1").press()  # [需要大量显示节点]点击[继续]
            except Exception:
                break
        gui_nav.UnselectAll()  # 取消选择
        gui_nav_datas = []
        org_paths = ['10010000']
        org_parent_id = '10010000'
        for key in gui_nav.GetAllNodeKeys():
            if key not in exclude_keys:
                org_id = gui_nav.GetItemText(key, 'ORG_OBJID').split('  ')[1]
                org_name = gui_nav.GetItemText(key, 'ORG_SHORT')
                org_level = gui_nav.GetHierarchyLevel(key)
                org_paths = org_paths[:org_level] + [org_id]
                if '15570000' in org_paths and '14400000' not in org_paths:
                    continue  # 特殊处理，机构15570000下只导出14400000
                org_parent_id = org_paths[-2]
                has_children = gui_nav.IsFolderExpandable(key) or gui_nav.IsFolderExpanded(key)
                # is_expanded = gui_nav.IsFolderExpanded(key)
                is_expanded = False
                # 默认展开层级为1的机构
                # if org_level <= 1:
                #     is_expanded = True
                gui_nav_datas.append([key, org_id, org_name, org_level, org_parent_id, org_paths[:-1], has_children, is_expanded])
        df_nav = DataFrame(gui_nav_datas)
        df_nav.columns = ['key', 'org_id', 'org_name', 'org_level', 'org_parent_id', 'org_paths', 'has_children', 'is_expanded']
        self.df_nav = df_nav

    def select(self, org_id: str):
        session = self.session
        df_nav = self.df_nav
        gui_tree = session.findById("wnd[0]/shellcont/shell/shellcont[1]/shell/shellcont[1]/shell")
        df_tmp = df_nav[df_nav['org_id'] == org_id]
        if df_tmp.empty is True:
            raise Exception(f'找不到{org_id}或者没有访问权限')
        key = df_tmp['key'].values[0]
        gui_tree.UnselectAll()  # 取消选择
        gui_tree.doubleClickNode(key)
        # gui_tree.UnselectAll()  # 取消选择

    def locate(self, org_id: str) -> bool:
        df_nav = self.df_nav
        df_tmp = df_nav[df_nav['org_id'] == org_id]
        if df_tmp.empty is True:
            return False
        org_paths = df_tmp['org_paths'].values[0]
        df_nav['is_expanded'] = False
        df_tmp2 = df_nav[df_nav['org_id'].map(lambda org_id: org_id in org_paths)]
        df_tmp2.loc[:, 'is_expanded'] = True
        df_nav.update(df_tmp2)
        return True

    def select_first(self):
        org_id = self.df_nav['org_id'].values[0]
        self.select(org_id)


class GuiView(object):
    """GuiView: 机构、岗位、人员树状目录，SAP GuiTree元素"""
    top_org_id_allowlist: List[str] = []  # 业务人员有权限访问的顶层机构 ID
    session: SapSession  # SAP 会话
    gui_view_id = "wnd[0]/usr/subMAINSCREEN:SAPLOM_NAVFRAMEWORK_OO_OBJ:1200/subWORKSPACE:SAPLOM_NAVFRAMEWORK_OO_OBJ:0200/subOVERVIEW:SAPLOM_GEN_OVERVIEW:1000/cntlTREE_CONTAINER/shellcont/shell"
    df_view: DataFrame
    back_count = 0  # 可卷回次数
    expanded_obj_ids = []

    def __init__(self, session: SapSession, top_org_id_allowlist: List[str] = []):
        self.top_org_id_allowlist = top_org_id_allowlist
        self.session = session
        session.findById("wnd[0]/usr/subMAINSCREEN:SAPLOM_NAVFRAMEWORK_OO_OBJ:1200/subWORKSPACE:SAPLOM_NAVFRAMEWORK_OO_OBJ:0200/subOVERVIEW:SAPLOM_GEN_OVERVIEW:1000/cntlTOOLBAR_CONTAINER/shellcont/shell").pressButton("CONFIGURE_COLUMNS")  # 列格式
        session.findById("wnd[1]/usr/cntlCHECKBOX_TREE/shellcont/shell").changeCheckbox("ORG_OBJID", "Text", -1)  # ID
        session.findById("wnd[1]/usr/cntlCHECKBOX_TREE/shellcont/shell").changeCheckbox("ORG_STEXT", "Text", -1)  # 名称
        session.findById("wnd[1]/usr/cntlCHECKBOX_TREE/shellcont/shell").changeCheckbox("ORG_BEGDA", "Text", -1)  # 有效期间
        session.findById("wnd[1]/usr/cntlCHECKBOX_TREE/shellcont/shell").changeCheckbox("ORG_VBEGDA", "Text", -1)  # 关系区间
        session.findById("wnd[1]/usr/cntlCHECKBOX_TREE/shellcont/shell").changeCheckbox("ORG_MANAGER", "Text", -1)  # 主管
        session.findById("wnd[1]/tbar[0]/btn[0]").press()  # 确认
        self.refresh()  # 缓存初始数据

    def refresh(self):
        session = self.session
        gui_view_id = self.gui_view_id
        gui_view = session.findById(gui_view_id)
        obj_paths = []
        gui_view.UnselectAll()
        obj_parent_id = ''
        gui_view_datas = []
        for key in gui_view.GetAllNodeKeys():
            obj_name = gui_view.GetItemText(key, 'ORG_SHORT')  # 人员分配(结构)
            obj_type = gui_view.GetItemText(key, 'ORG_OBJID').split('  ')[0]  # 对象类型
            obj_id = gui_view.GetItemText(key, 'ORG_OBJID').split('  ')[1]  # ID
            obj_stext = gui_view.GetItemText(key, 'ORG_STEXT')  # 名称
            obj_begda = gui_view.GetItemText(key, 'ORG_BEGDA')  # 有效日期从
            obj_endda = gui_view.GetItemText(key, 'ORG_ENDDA')  # 有效日期至
            obj_vbegda = gui_view.GetItemText(key, 'ORG_VBEGDA')  # 分配起始日期
            obj_vendda = gui_view.GetItemText(key, 'ORG_VENDDA')  # 分配截止日期
            obj_manager = gui_view.GetItemText(key, 'ORG_MANAGER')  # 主管
            obj_level = gui_view.GetHierarchyLevel(key)
            obj_paths = obj_paths[:obj_level] + [obj_id]
            obj_parent_id = obj_paths[-2] if len(obj_paths) > 1 else ''
            has_children = gui_view.IsFolderExpandable(key) or gui_view.IsFolderExpanded(key)
            is_expanded = gui_view.IsFolderExpanded(key)
            gui_view_datas.append([key, obj_name, obj_type, obj_id, obj_stext, obj_begda, obj_endda, obj_vbegda, obj_vendda, obj_paths[:-1], obj_parent_id, has_children, is_expanded, obj_manager])
        df_view = DataFrame(gui_view_datas)
        df_view.columns = ['key', 'obj_name', 'obj_type', 'obj_id', 'obj_stext', 'obj_begda', 'obj_endda', 'obj_vbegda', 'obj_vendda', 'obj_paths', 'obj_parent_id', 'has_children', 'is_expanded', 'obj_manager']
        self.df_view = df_view

    def select(self, obj_id: str):
        session = self.session
        gui_view_id = self.gui_view_id
        df_view = self.df_view
        gui_view = session.findById(gui_view_id)
        df_tmp = df_view[df_view['obj_id'] == obj_id]
        if df_tmp.empty is True:
            raise Exception(f'找不到{obj_id}')
        key = df_tmp['key'].values[0]
        gui_view.UnselectAll()  # 取消选择
        gui_view.doubleClickNode(key)
        # gui_view.UnselectAll()  # 取消选择
        # self.refresh()

    def expand(self, obj_id: str):
        session = self.session
        gui_view_id = self.gui_view_id
        df_view = self.df_view
        gui_view = session.findById(gui_view_id)
        key = df_view[df_view['obj_id'] == obj_id]['key'].values[0]
        if gui_view.IsFolderExpandable(key) is True and gui_view.IsFolderExpanded(key) is False:
            gui_view.ExpandNode(key)
            gui_view_node_keys = list(gui_view.GetAllNodeKeys())
            obj_level = gui_view.GetHierarchyLevel(key)
            begin_idx = gui_view_node_keys.index(key) + 1
            obj_paths = df_view[df_view['obj_id'] == obj_id]['obj_paths'].values[0] + [obj_id]
            gui_view_new_datas = []
            for key in gui_view_node_keys[begin_idx:]:
                if gui_view.GetHierarchyLevel(key) < obj_level:  # 只读取展开的新内容
                    break
                obj_name = gui_view.GetItemText(key, 'ORG_SHORT')  # 人员分配(结构)
                obj_type = gui_view.GetItemText(key, 'ORG_OBJID').split('  ')[0]  # 对象类型
                obj_id = gui_view.GetItemText(key, 'ORG_OBJID').split('  ')[1]  # ID
                obj_stext = gui_view.GetItemText(key, 'ORG_STEXT')  # 名称
                obj_begda = gui_view.GetItemText(key, 'ORG_BEGDA')  # 有效日期从
                obj_endda = gui_view.GetItemText(key, 'ORG_ENDDA')  # 有效日期至
                obj_vbegda = gui_view.GetItemText(key, 'ORG_VBEGDA')  # 分配起始日期
                obj_vendda = gui_view.GetItemText(key, 'ORG_VENDDA')  # 分配截止日期
                obj_manager = gui_view.GetItemText(key, 'ORG_MANAGER')  # 主管
                obj_level = gui_view.GetHierarchyLevel(key)
                obj_paths = obj_paths[:obj_level] + [obj_id]
                obj_parent_id = obj_paths[-2] if len(obj_paths) > 1 else ''
                has_children = gui_view.IsFolderExpandable(key) or gui_view.IsFolderExpanded(key)
                is_expanded = gui_view.IsFolderExpanded(key)
                gui_view_new_datas.append([key, obj_name, obj_type, obj_id, obj_stext, obj_begda, obj_endda, obj_vbegda, obj_vendda, obj_paths[:-1], obj_parent_id, has_children, is_expanded, obj_manager])
            df_view_new_data = DataFrame(gui_view_new_datas)
            df_view_new_data.columns = ['key', 'obj_name', 'obj_type', 'obj_id', 'obj_stext', 'obj_begda', 'obj_endda', 'obj_vbegda', 'obj_vendda', 'obj_paths', 'obj_parent_id', 'has_children', 'is_expanded', 'obj_manager']
            self.df_view = df_view.append(df_view_new_data).copy()


class GuiTab(object):
    """PPOSE 右侧下半部分机构详情（TAB标签页）"""
    top_org_ids: List[str] = []  # 业务人员有权限访问的顶层机构 ID
    session: SapSession  # SAP 会话

    def __init__(self, session: SapSession, top_org_ids: List[str] = []):
        self.top_org_ids = top_org_ids
        self.session = session


class PPOSE(object):
    top_org_ids: List[str] = []  # 业务人员有权限访问的顶层机构 ID
    session: SapSession  # SAP 会话
    back_count = 0  # 可卷回次数
    gui_nav: GuiNav  # 机构目录
    gui_view: GuiView  # 机构视图
    gui_tab: GuiTab  # 机构详情
    begin_date: str  # yyyymm01
    end_date: str  # 99991231
    current_org_id: str

    def __init__(self, top_org_ids: List[str] = []):
        if len(top_org_ids) == 0:
            raise Exception('当前用户无可访问的机构ID')
        self.top_org_ids = [org_id for org_id in top_org_ids if org_id not in ['10010117']]  # 去掉公司总部
        self.begin_date = next_month_01()  # 次月1号
        self.end_date = '99991231'
        self.session = attach_sap()
        self.enter_ppose()  # 进入PPOSE
        self.gui_nav = GuiNav(self.session, top_org_ids)  # 机构目录
        self.gui_nav.select_first()
        self.current_org_id = self.gui_nav.df_nav['org_id'].values[0]
        self.gui_view = GuiView(self.session, top_org_ids)  # 机构视图
        # 展开[显示关键日期]=>[显示期间]
        self.session.findById("wnd[0]/usr/subMAINSCREEN:SAPLOM_NAVFRAMEWORK_OO_OBJ:1200/subWORKSPACE:SAPLOM_NAVFRAMEWORK_OO_OBJ:0200/subDETAIL:SAPLRHOMDETAILMANAGER:0100/tabsSTRIP_OMDETAIL/tabpDETLTAB01/ssubSUB_OMDETAIL:SAPLRHOMDETAIL_BASE:0200/ssubSUB_PERIOD:SAPLRHOMDETAILMANAGER:0300/btnPERIOD_ICON").press()
        self.gui_tab = GuiTab(self.session, top_org_ids)  # 机构详情（未用到）

    def enter_ppose(self) -> DataFrame:
        """进入PPOSE并根据用户权限，缓存SAP左侧机构目录"""
        session = self.session
        session.findById("wnd[0]/tbar[0]/okcd").text = "/n ppose"
        session.findById("wnd[0]").sendVKey(0)
        session.findById("wnd[0]/shellcont/shell/shellcont[0]/shell/shellcont[1]/shell[1]").expandNode("          1")  # 点开组织机构菜单项
        session.findById("wnd[0]/shellcont/shell/shellcont[0]/shell/shellcont[1]/shell[1]").clickLink("          3", "&Hierarchy")  # 点击结构搜索
        session.findById("wnd[0]/usr/subCONTROLSTRIP:SAPLOM_NAVFRAMEWORK_OO_OBJ:0010/subTIME_OBJECT_OVERVIEW_STRIP:SAPLOM_STANDARD_TIME_OBJ:0040/subICON:SAPLOM_STANDARD_TIME_OBJ:0045/btnDATE").press()  # 指定日期和预览期间
        session.findById("wnd[1]/usr/subPERIODCHANGE:SAPLOM_STANDARD_TIME_OBJ:6020/radABSOLUT").select()  # 点选结束日期
        session.findById("wnd[1]/usr/subPERIODCHANGE:SAPLOM_STANDARD_TIME_OBJ:6020/ctxtOMFRAMEWRK-SEL_DATE").text = self.begin_date  # 开始日期设为次月1号
        session.findById("wnd[1]/usr/subPERIODCHANGE:SAPLOM_STANDARD_TIME_OBJ:6020/ctxtENDE_DAT").text = "99991231"  # 结束日期设为99991231
        session.findById("wnd[1]/tbar[0]/btn[8]").press()  # 确定

    def get_org_parent_id(self, org_id: str) -> str:
        df_nav = self.gui_nav.df_nav
        org_parent_id = df_nav[df_nav['org_id'] == org_id]['org_parent_id'].values[0]
        return org_parent_id

    def get_current_org_id(self) -> str:
        return self.current_org_id

    def gui_nav_select(self, org_id: str):
        self.gui_nav.select(org_id)
        self.gui_view.refresh()
        self.current_org_id = org_id

    def gui_nav_locate(self, org_id: str) -> bool:
        """搜索机构ID"""
        if self.gui_nav.locate(org_id) is True:
            self.gui_nav_select(org_id)
            return True
        return False

    # def gui_view_upper(self) -> bool:
    #     """一级以上"""
    #     if self.current_org_id is not None:
    #         df_nav = self.gui_nav.df_nav
    #         if df_nav[df_nav['org_id'] == self.current_org_id]['org_level'].values[0] <= 1:
    #             return False
    #         org_parent_id = df_nav[df_nav['org_id'] == self.current_org_id]['org_parent_id'].values[0]
    #         self.gui_nav_locate(org_parent_id)
    #         return True
    #     return False

    def gui_view_select(self, obj_id: str):
        self.gui_view.select(obj_id)
        self.gui_view.refresh()

    def gui_view_locate(self, search_obj_type: str, search_obj_id: str) -> bool:
        session = self.session
        session.findById("wnd[0]/usr/subMAINSCREEN:SAPLOM_NAVFRAMEWORK_OO_OBJ:1200/subWORKSPACE:SAPLOM_NAVFRAMEWORK_OO_OBJ:0200/subOVERVIEW:SAPLOM_GEN_OVERVIEW:1000/cntlTOOLBAR_CONTAINER/shellcont/shell").pressButton("SEARCH")
        if search_obj_type == '机构':
            session.findById("wnd[1]/usr/lbl[1,3]").setFocus()  # [O] 组织机构
        elif search_obj_type == '人员':
            session.findById("wnd[1]/usr/lbl[1,4]").setFocus()  # [P] 人员
        elif search_obj_type == '岗位':
            session.findById("wnd[1]/usr/lbl[1,5]").setFocus()  # [S] 职务（岗位）具体名称
        else:
            raise Exception('未知对象类型')
        session.findById("wnd[1]/tbar[0]/btn[0]").press()  # 回车
        if search_obj_type == '机构':
            session.findById("wnd[1]/usr/tabsG_SELONETABSTRIP/tabpTAB001/ssubSUBSCR_PRESEL:SAPLSDH4:0220/sub:SAPLSDH4:0220/txtG_SELFLD_TAB-LOW[0,24]").text = search_obj_id
        elif search_obj_type == '人员':
            session.findById("wnd[1]/usr/tabsG_SELONETABSTRIP/tabpTAB003/ssubSUBSCR_PRESEL:SAPLSDH4:0220/sub:SAPLSDH4:0220/txtG_SELFLD_TAB-LOW[4,24]").text = search_obj_id
        elif search_obj_type == '岗位':
            session.findById("wnd[1]/usr/tabsG_SELONETABSTRIP/tabpTAB001/ssubSUBSCR_PRESEL:SAPLSDH4:0220/sub:SAPLSDH4:0220/txtG_SELFLD_TAB-LOW[0,24]").text = search_obj_id
        session.findById("wnd[1]/tbar[0]/btn[0]").press()  # 点击确认
        sap_status = session.findById("wnd[0]/sbar/pane[0]").text
        if sap_status != '':
            session.findById("wnd[1]").close()  # 关闭搜索窗口
            logging.error(sap_status)
            raise Exception(sap_status)
        session.findById("wnd[1]/usr/chk[1,3]").selected = -1  # 选择第一个结果
        session.findById("wnd[1]/tbar[0]/btn[0]").press()  # 点击确定
        self.gui_view_select(search_obj_id)

    @lru_cache()
    def _get_combobox_entries(self, combobox_key: str) -> List[str]:
        try:
            session = self.session
            combobox = session.findById(combobox_key)
            return [combobox_entry.key + ' ' + combobox_entry.value for combobox_entry in combobox.Entries]
        except Exception:
            return []

    def gui_tab_select(self, tab_name: str) -> Dict[str, Any]:
        session = self.session
        gui_tab_strip = session.findById('wnd[0]/usr/subMAINSCREEN:SAPLOM_NAVFRAMEWORK_OO_OBJ:1200/subWORKSPACE:SAPLOM_NAVFRAMEWORK_OO_OBJ:0200/subDETAIL:SAPLRHOMDETAILMANAGER:0100/tabsSTRIP_OMDETAIL')
        tab_name = tab_name.strip(' ')  # 前端RPC会在tab_name前面加空格，未定位原因，暂时在后端去掉空格
        for gui_tab in gui_tab_strip.children:
            if tab_name in gui_tab.text:  # 匹配标签名
                gui_tab.select()  # 选中标签
                break
        # 这里的gui_tab_strip需要重新获取，原对象不能用了
        gui_tab_strip = session.findById('wnd[0]/usr/subMAINSCREEN:SAPLOM_NAVFRAMEWORK_OO_OBJ:1200/subWORKSPACE:SAPLOM_NAVFRAMEWORK_OO_OBJ:0200/subDETAIL:SAPLRHOMDETAILMANAGER:0100/tabsSTRIP_OMDETAIL')
        gui_tab = gui_tab_strip.SelectedTab
        gui_tab_children_ids = get_all_children_ids(session, gui_tab.id)  # 获取所有子元素
        result = {'tab_name': tab_name}
        for sap_id in gui_tab_children_ids:
            sap_comp = session.findById(sap_id)
            sap_comp_type = sap_comp.type
            sap_comp_name = sap_comp.name.lower().replace('-', '__')  # javascript不支持减号作为属性标识符
            if sap_comp_type in ('GuiCTextField', 'GuiTextField', 'GuiLabel'):  # 文本框、输入框、标签
                result[sap_comp_name] = sap_comp.text
            elif sap_comp_type == 'GuiComboBox':  # TODO 下拉选择框（返回可选项及当前选择项）
                result[sap_comp_name] = {'value': sap_comp.key + ' ' + sap_comp.value, 'entries': self._get_combobox_entries(sap_comp.id)}
            elif sap_comp_type in ('GuiCheckBox', 'GuiRadioButton'):  # 多选框、单选框
                result[sap_comp_name] = sap_comp.selected
        return result

    def get_gui_nav(self, org_id: str) -> List[Dict[str, str]]:
        df_nav = self.gui_nav.df_nav
        df_tmp = df_nav[df_nav['org_parent_id'] == org_id]
        return df_tmp.to_dict('records')

    def get_gui_view(self, obj_id: str) -> List[Dict[str, str]]:
        df_view = self.gui_view.df_view
        df_tmp = df_view[df_view['obj_parent_id'] == obj_id]
        if df_tmp.empty is True:  # 需要先展开再返回结果
            self.gui_view.expand(obj_id)
            df_view = self.gui_view.df_view
            df_tmp = df_view[df_view['obj_parent_id'] == obj_id]
        return df_tmp.to_dict('records')

    def get_gui_tab_status(self) -> List[Dict[str, str]]:
        session = self.session
        gui_tab_strip = session.findById('wnd[0]/usr/subMAINSCREEN:SAPLOM_NAVFRAMEWORK_OO_OBJ:1200/subWORKSPACE:SAPLOM_NAVFRAMEWORK_OO_OBJ:0200/subDETAIL:SAPLRHOMDETAILMANAGER:0100/tabsSTRIP_OMDETAIL')
        selected_gui_tab = gui_tab_strip.SelectedTab
        return [{'text': gui_tab.text, 'icon_name': gui_tab.IconName, 'idx': idx, 'is_selected': gui_tab == selected_gui_tab} for idx, gui_tab in enumerate(gui_tab_strip.children)]


if __name__ == '__main__':
    ppose = PPOSE(['10010117', '10010001', '15570000'])
