"""建岗导出107机构信息（变式名称：----T90）"""
import logging
from typing import Any, List

import pyperclip
from rpa.fastrpa.adtable import AdTable
from rpa.fastrpa.sap.grid_view_ctrl import GridViewCtrl
from rpa.fastrpa.sap.session import attach_sap
from rpa.ssc.sap.query import export_query, query_selection
from rpa.ssc.sap.utils import init_sap_id

HEADER_IDS: List[str] = ['VALUE1', 'VALUE2', 'VALUE5', 'VALUE6', 'VALUE7', 'VALUE8', 'VALUE9', 'VALUE10', 'VALUE14',
                         'VALUE15', 'VALUE16', 'VALUE17', 'VALUE20', 'VALUE21', 'TEXT19', 'VALUE524', 'VALUE525',
                         'TEXT528', 'VALUE26', 'VALUE27', 'VALUE28', 'VALUE29', 'VALUE30', 'VALUE33', 'VALUE34',
                         'VALUE35', 'VALUE36', 'VALUE38', 'VALUE39', 'VALUE40', 'VALUE41', 'TEXT41', 'VALUE101',
                         'VALUE102', 'TEXT107', 'VALUE113', 'VALUE114', 'VALUE115', 'VALUE116', 'TEXT117', 'VALUE118',
                         'TEXT119', 'TEXT120', 'TEXT121', 'TEXT122', 'VALUE123', 'VALUE124', 'TEXT125', 'VALUE126',
                         'TEXT126', 'TEXT127', 'TEXT128', 'TEXT129', 'TEXT130', 'TEXT131', 'VALUE44', 'VALUE45',
                         'VALUE49', 'VALUE50', 'VALUE51', 'VALUE52', 'VALUE138', 'VALUE139', 'VALUE142', 'VALUE143',
                         'VALUE279', 'VALUE280', 'TEXT283', 'TEXT284', 'TEXT285', 'VALUE213', 'VALUE214', 'TEXT217',
                         'TEXT218', 'TEXT219', 'TEXT220', 'TEXT221', 'TEXT222', 'VALUE223', 'VALUE224', 'TEXT225',
                         'TEXT226', 'VALUE227', 'VALUE593', 'VALUE594', 'VALUE595', 'TEXT595', 'TEXT596', 'VALUE405',
                         'VALUE406', 'VALUE409', 'TEXT410', 'TEXT411', 'TEXT412']


def enter_107(session: Any) -> None:
    """进入107"""
    session.findById("wnd[0]").maximize()
    session.findById("wnd[0]/tbar[0]/okcd").text = "/n S_PH0_48000513"
    session.findById("wnd[0]").sendVKey(0)
    session.findById("wnd[1]/usr/cmbDYNP4100-DD_WORKSPACE").setFocus()
    session.findById("wnd[1]/usr/cmbDYNP4100-DD_WORKSPACE").key = "2"
    session.findById("wnd[1]/usr/cmbDYNP4100-DD_USERGROUP").setFocus()
    session.findById("wnd[1]/usr/cmbDYNP4100-DD_USERGROUP").key = "107"
    session.findById("wnd[1]/usr/tblSAPLAQ_INT_FUNCTIONSTCH_FUNCAREAS").getAbsoluteRow(1).selected = -1  # 选择【ZHR_OM_O 组织机构管理】
    session.findById("wnd[1]/usr/tblSAPLAQ_INT_FUNCTIONSTCH_FUNCAREAS/txtDYNP4100_TC_FUNCAREAS-NAME[0,2]").setFocus()
    session.findById("wnd[1]/tbar[0]/btn[0]").press()


def throw_exception_when_query_changed(session: Any):
    raise Exception('组合逻辑查询变式107----T91列ID与开发时不匹配')


def fill_107(session: Any, job_ids: List[str], key_date: str) -> None:
    """填充107"""
    pyperclip.copy('\r\n'.join(job_ids))  # 复制到剪切板
    grid_view_ctrl_id = 'wnd[0]/usr/subSUB_MAIN:SAPLAQ_ADHOC:0212/subSUB_SELECTION:SAPLAQ_ADHOC:0310/cntlSEL_DEF_CONTAINER/shellcont/shell'
    grid_view_ctrl = GridViewCtrl(session, grid_view_ctrl_id)
    grid_view_ctrl['字段名称'].find('对象标识').same_line('更多值 ').press_button()
    session.findById("wnd[1]/tbar[0]/btn[16]").press()
    session.findById("wnd[1]/tbar[0]/btn[24]").press()  # 粘贴
    session.findById("wnd[1]/tbar[0]/btn[8]").press()
    session.findById("wnd[0]/usr/subSUB_MAIN:SAPLAQ_ADHOC:0212/subSUB_APPLICATION:SAPLHR_QUERY_APPL_AREA:0122/subSUB:SAPLHR_QUERY_APPL_AREA:0121/btnDYNP121-EVALUATION_PERIOD_TEXT").press()
    session.findById("wnd[0]/usr/subSUB_MAIN:SAPLAQ_ADHOC:0212/subSUB_APPLICATION:SAPLHR_QUERY_APPL_AREA:0122/subSUB:SAPLHR_QUERY_APPL_AREA:0120/cmbDD_DATE").setFocus()
    session.findById("wnd[0]/usr/subSUB_MAIN:SAPLAQ_ADHOC:0212/subSUB_APPLICATION:SAPLHR_QUERY_APPL_AREA:0122/subSUB:SAPLHR_QUERY_APPL_AREA:0120/cmbDD_DATE").key = "8"
    session.findById("wnd[0]/usr/subSUB_MAIN:SAPLAQ_ADHOC:0212/subSUB_APPLICATION:SAPLHR_QUERY_APPL_AREA:0122/subSUB:SAPLHR_QUERY_APPL_AREA:0120/ctxtG_APPL_AREA-BEGDA").text = key_date
    session.findById("wnd[0]/usr/subSUB_MAIN:SAPLAQ_ADHOC:0212/subSUB_APPLICATION:SAPLHR_QUERY_APPL_AREA:0122/subSUB:SAPLHR_QUERY_APPL_AREA:0120/ctxtG_APPL_AREA-ENDDA").text = "99991231"
    session.findById("wnd[0]/usr/subSUB_MAIN:SAPLAQ_ADHOC:0212/subSUB_APPLICATION:SAPLHR_QUERY_APPL_AREA:0122/subSUB:SAPLHR_QUERY_APPL_AREA:0120/ctxtG_APPL_AREA-ENDDA").setFocus()
    session.findById("wnd[0]/usr/subSUB_MAIN:SAPLAQ_ADHOC:0212/subSUB_APPLICATION:SAPLHR_QUERY_APPL_AREA:0122/subSUB:SAPLHR_QUERY_APPL_AREA:0120/ctxtG_APPL_AREA-ENDDA").caretPosition = 8
    session.findById("wnd[0]/tbar[1]/btn[8]").press()


def export_107_t90(session: Any, job_ids: List[str], key_date: str) -> AdTable:
    """导出107_T90
       ------------------
       入参：
       session: SAP SESSION，如为None，则新打开SAP
       job_ids: 机构编码
       key_date: 关键日期
       ------------------
       返回值：
       AdTable，可通过.wb访问Workbook，或.ws访问Worksheet
       ------------------
       调用样例：
       _table: AdTable = export_107(None, ['04613370'], '20200301')
       _table.filename = '模板_107'
       _table.save_to('x:/') # 保存模板至x:/下
    """
    logging.info(f'导出组合逻辑查询107，机构编号：{job_ids}，关键日期：{key_date}')
    if all(map(lambda v: v == '', job_ids)) is True:
        raise Exception('机构编号全为空值，请检查模板机构编号是否填充')
    if session is None:
        session = attach_sap()
    elif isinstance(session, str):
        session = attach_sap(session)
    enter_107(session)  # 进入107信息集查询屏
    query_selection(session, '----T90', throw_exception_when_query_changed, HEADER_IDS)  # 勾选107选项
    fill_107(session, job_ids, key_date)  # 填入员工编号和关键日期，并查询
    _table: AdTable = export_query(session, query_name='----T83-4')
    _table['A'].apply(init_sap_id)
    # _table.filename = '107'
    return _table


# def _export_all():
#     """导出机构信息（只用导出顶层ID即可）"""
#     import traceback
#     from rpa.ssc.hr.orm.orm import TB_ODS_HR_JOB_INFOS, Session
#     org_ids = []  # 20200908统计结果：75449条记录
#     with Session() as s:
#         req = s.query(TB_ODS_HR_JOB_INFOS.obj_id).filter(TB_ODS_HR_JOB_INFOS.obj_type == 'O', TB_ODS_HR_JOB_INFOS.obj_level == '0')
#         org_ids = [r[0] for r in req]
#         for org_id in org_ids:
#             logging.info(f'正在导出{org_id}')
#             try:
#                 _lt: AdTable = export_107_t90(None, [org_id], '20200901')  # 最大的org_id是15570000，数据量为6573条
#                 _lt.filename = org_id  # 开始ID-结束ID-数据量
#                 _lt.save_to('x:/T90')
#                 logging.info('导出完成')
#             except Exception as e:
#                 logging.error(f'{e}, {org_id}')
#                 logging.error(f"异常原因: {traceback.format_exc()}")


# example
if __name__ == '__main__':
    from rpa.fastrpa.log import config
    config('107----T90')
    sap_ids = ['03186764', '10010004', '10010005', '10010008', '10010009', '10010013', '10010014', '10010018', '10010020', '10010021', ]
    _lt: AdTable = export_107_t90(None, sap_ids, '20200901')
    _lt.save_to('x:/')
    # with sap_close():
    #     _export_all()
