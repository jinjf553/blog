import logging
import re
from typing import Any, List

from rpa.fastrpa.adtable import AdTable, AdTableRow
from rpa.fastrpa.sap.session import attach_sap


def ks02(session: Any, row: AdTableRow) -> bool:
    if row['A'].value is None:
        row['A'].cmt('red', '主成本中心为空')
        return False
    match = re.match('[^a-zA-Z0-9]*([a-zA-Z0-9]{10})[^a-zA-Z0-9]*', str(row['A'].value))
    if match is None:
        row['A'].cmt('red', '主成本中心代码不合法')
        return False
    row['A'].value = match.groups()[0]
    if row['B'].value != '' and row['C'].value != '' or row['D'].value != '':
        row['A'].cmt('red', '公司代码、业务范围、功能范围已有值，跳过查询')
        return True
    session.findById("wnd[0]/usr/ctxtCSKSZ-KOSTL").text = match.groups()[0]  # 主成本中心
    session.findById("wnd[0]").sendVKey(0)  # 回车
    try:
        if '分析时间框架: 选择' in session.findById("wnd[1]").text:
            session.findById("wnd[1]/tbar[0]/btn[0]").press()  # 选择第一个
    except Exception:  # nosec
        pass
    if '改变成本中心：初始屏幕' in session.findById("wnd[0]").text:
        row['N'].value = str(session.findById("wnd[0]/sbar/pane[0]").text)  # 状态栏
        return False
    elif '改变成本中心：基本屏幕' in session.findById("wnd[0]").text:
        row['B'].value = session.findById("wnd[0]/usr/tabsTABSTRIP_EINZEL/tabpGRUN/ssubSUBSCREEN_EINZEL:SAPLKMA1:0300/txtCSKSZ-KTEXT").text  # 名称
        row['C'].value = session.findById("wnd[0]/usr/tabsTABSTRIP_EINZEL/tabpGRUN/ssubSUBSCREEN_EINZEL:SAPLKMA1:0300/txtCSKSZ-LTEXT").text  # 描述
        row['D'].value = session.findById("wnd[0]/usr/tabsTABSTRIP_EINZEL/tabpGRUN/ssubSUBSCREEN_EINZEL:SAPLKMA1:0300/ctxtCSKSZ-VERAK_USER").text  # 负责的用户
        row['E'].value = session.findById("wnd[0]/usr/tabsTABSTRIP_EINZEL/tabpGRUN/ssubSUBSCREEN_EINZEL:SAPLKMA1:0300/txtCSKSZ-VERAK").text  # 负责人
        row['F'].value = session.findById("wnd[0]/usr/tabsTABSTRIP_EINZEL/tabpGRUN/ssubSUBSCREEN_EINZEL:SAPLKMA1:0300/txtCSKSZ-ABTEI").text  # 部门
        row['G'].value = session.findById("wnd[0]/usr/tabsTABSTRIP_EINZEL/tabpGRUN/ssubSUBSCREEN_EINZEL:SAPLKMA1:0300/ctxtCSKSZ-KOSAR").text  # 成本中心类型[编码]
        row['G'].value += ' ' + session.findById("wnd[0]/usr/tabsTABSTRIP_EINZEL/tabpGRUN/ssubSUBSCREEN_EINZEL:SAPLKMA1:0300/txtCSKSZ-KOSAR_TEXT").text  # 成本中心类型[文本]
        row['H'].value = session.findById("wnd[0]/usr/tabsTABSTRIP_EINZEL/tabpGRUN/ssubSUBSCREEN_EINZEL:SAPLKMA1:0300/ctxtCSKSZ-KHINR").text  # 层次结构范围[编码]
        row['H'].value += ' ' + session.findById("wnd[0]/usr/tabsTABSTRIP_EINZEL/tabpGRUN/ssubSUBSCREEN_EINZEL:SAPLKMA1:0300/txtCSKSZ-KHINR_TEXT").text  # 层次结构范围[文本]
        row['I'].value = session.findById("wnd[0]/usr/tabsTABSTRIP_EINZEL/tabpGRUN/ssubSUBSCREEN_EINZEL:SAPLKMA1:0300/ctxtCSKSZ-BUKRS").text  # 公司代码[编码]
        row['I'].value += ' ' + session.findById("wnd[0]/usr/tabsTABSTRIP_EINZEL/tabpGRUN/ssubSUBSCREEN_EINZEL:SAPLKMA1:0300/txtCSKSZ-BUKRS_TEXT").text  # 公司代码[文本]
        row['J'].value = session.findById("wnd[0]/usr/tabsTABSTRIP_EINZEL/tabpGRUN/ssubSUBSCREEN_EINZEL:SAPLKMA1:0300/ctxtCSKSZ-GSBER").text  # 业务范围[编码]
        row['J'].value += ' ' + session.findById("wnd[0]/usr/tabsTABSTRIP_EINZEL/tabpGRUN/ssubSUBSCREEN_EINZEL:SAPLKMA1:0300/txtCSKSZ-GSBER_TEXT").text  # 业务范围[文本]
        row['K'].value = session.findById("wnd[0]/usr/tabsTABSTRIP_EINZEL/tabpGRUN/ssubSUBSCREEN_EINZEL:SAPLKMA1:0300/ctxtCSKSZ-FUNC_AREA").text  # 功能范围[编码]
        row['K'].value += ' ' + session.findById("wnd[0]/usr/tabsTABSTRIP_EINZEL/tabpGRUN/ssubSUBSCREEN_EINZEL:SAPLKMA1:0300/txtCSKSZ-FAREA_NAME").text  # 功能范围[文本]
        row['L'].value = session.findById("wnd[0]/usr/tabsTABSTRIP_EINZEL/tabpGRUN/ssubSUBSCREEN_EINZEL:SAPLKMA1:0300/ctxtCSKSZ-WAERS").text  # 货币
        row['M'].value = session.findById("wnd[0]/usr/tabsTABSTRIP_EINZEL/tabpGRUN/ssubSUBSCREEN_EINZEL:SAPLKMA1:0300/ctxtCSKSZ-PRCTR").text  # 利润中心[编码]
        row['M'].value += ' ' + session.findById("wnd[0]/usr/tabsTABSTRIP_EINZEL/tabpGRUN/ssubSUBSCREEN_EINZEL:SAPLKMA1:0300/txtCSKSZ-PRCTR_TEXT").text  # 利润中心[文本]
        row['N'].value = str(session.findById("wnd[0]/sbar/pane[0]").text)  # 错误提示
        session.findById("wnd[0]/tbar[0]/btn[12]").press()  # 取消（点击确认有可能需要连点两次确认，不如点击取消直接）
    else:
        session.findById("wnd[0]/tbar[0]/okcd").text = "/nex"  # 关闭SAP。代码跑飞了，既没有在初始屏幕，也没有进入基本屏幕
        session.findById("wnd[0]").sendVKey(0)
    return True


def _export_ks02(lt_ks02: AdTable) -> AdTable:
    session = attach_sap()
    session.findById("wnd[0]/tbar[0]/okcd").text = "/n ks02"  # SAP事务码：KS02
    session.findById("wnd[0]").sendVKey(0)  # 回车
    try:
        if '设置成本控制范围' in session.findById("wnd[1]").Text:
            session.findById("wnd[1]/usr/sub:SAPLSPO4:0300/ctxtSVALD-VALUE[0,21]").text = "sino"  # 控制范围
            session.findById("wnd[1]").sendVKey(0)  # 回车
    except Exception:  # nosec
        pass
    for row in lt_ks02.rows:
        is_action_passed = ks02(session, row)
        if isinstance(is_action_passed, bool) is False:  # 与SAP失去连接
            break
    session.findById("wnd[0]/tbar[0]/okcd").text = "/nex"  # 关闭SAP。代码跑飞了，既没有在初始屏幕，也没有进入基本屏幕
    session.findById("wnd[0]").sendVKey(0)
    return lt_ks02


def export_ks02(cost_center_ids: List[str]) -> AdTable:
    """cost_center_ids: 成本中心代码数组"""
    logging.info(f'导出KS02，成本中心ID：{cost_center_ids}')
    lt_ks02 = AdTable('KS02')
    lt_ks02['A'][1].value = '主成本中心'
    lt_ks02['B'][1].value = '名称'
    lt_ks02['C'][1].value = '描述'
    lt_ks02['D'][1].value = '负责的用户'
    lt_ks02['E'][1].value = '负责人'
    lt_ks02['F'][1].value = '部门'
    lt_ks02['G'][1].value = '成本中心类型'
    lt_ks02['H'][1].value = '层次结构范围'
    lt_ks02['I'][1].value = '公司代码'
    lt_ks02['J'][1].value = '业务范围'
    lt_ks02['K'][1].value = '功能范围'
    lt_ks02['L'][1].value = '货币'
    lt_ks02['M'][1].value = '利润中心'
    lt_ks02['N'][1].value = '错误提示'
    for sap_id in list(set(cost_center_ids)):
        new_row = lt_ks02.add_row()
        new_row['A'].value = sap_id
    return _export_ks02(lt_ks02)


if __name__ == '__main__':
    sap_ids = ['8248002103', '8280001023']
    lt_ks02 = export_ks02(sap_ids)
    lt_ks02.save_to('x:/')
