"""导出组合逻辑查询107_t83_4"""
import logging
from typing import Any, List

import pyperclip
from rpa.fastrpa.adtable import AdTable
from rpa.fastrpa.sap.grid_view_ctrl import GridViewCtrl
from rpa.fastrpa.sap.session import attach_sap
from rpa.ssc.sap.query import export_query, query_selection
from rpa.ssc.sap.utils import init_sap_id


def enter_107(session: Any) -> None:
    """进入107_t83_4"""
    session.findById("wnd[0]").maximize()
    session.findById("wnd[0]/tbar[0]/okcd").text = "/n S_PH0_48000513"
    session.findById("wnd[0]").sendVKey(0)
    session.findById("wnd[1]/usr/cmbDYNP4100-DD_WORKSPACE").setFocus()
    session.findById("wnd[1]/usr/cmbDYNP4100-DD_WORKSPACE").key = "2"
    session.findById("wnd[1]/usr/cmbDYNP4100-DD_USERGROUP").setFocus()
    session.findById("wnd[1]/usr/cmbDYNP4100-DD_USERGROUP").key = "107"
    session.findById("wnd[1]/usr/tblSAPLAQ_INT_FUNCTIONSTCH_FUNCAREAS").getAbsoluteRow(2).selected = -1
    session.findById("wnd[1]/usr/tblSAPLAQ_INT_FUNCTIONSTCH_FUNCAREAS/txtDYNP4100_TC_FUNCAREAS-NAME[0,2]").setFocus()
    session.findById("wnd[1]/usr/tblSAPLAQ_INT_FUNCTIONSTCH_FUNCAREAS/txtDYNP4100_TC_FUNCAREAS-NAME[0,2]").caretPosition = 0
    session.findById("wnd[1]/tbar[0]/btn[0]").press()


def fill_107_t83_4(session: Any, object_ids: List[str], key_date: str, begin_date='', end_date='') -> None:
    """填充107_t83_4"""
    session.findById("wnd[0]/usr/subSUB_MAIN:SAPLAQ_ADHOC:0212/subSUB_APPLICATION:SAPLHR_QUERY_APPL_AREA:0122/subSUB:SAPLHR_QUERY_APPL_AREA:0121/btnDYNP121-EVALUATION_PERIOD_TEXT").press()  # 点击报告时间
    if key_date != '':
        session.findById("wnd[0]/usr/subSUB_MAIN:SAPLAQ_ADHOC:0212/subSUB_APPLICATION:SAPLHR_QUERY_APPL_AREA:0122/subSUB:SAPLHR_QUERY_APPL_AREA:0120/cmbDD_DATE").key = "7"  # 选择关键日期
        session.findById("wnd[0]/usr/subSUB_MAIN:SAPLAQ_ADHOC:0212/subSUB_APPLICATION:SAPLHR_QUERY_APPL_AREA:0122/subSUB:SAPLHR_QUERY_APPL_AREA:0120/ctxtG_APPL_AREA-BEGDA").text = key_date  # 填充关键日期
    else:
        session.findById("wnd[0]/usr/subSUB_MAIN:SAPLAQ_ADHOC:0212/subSUB_APPLICATION:SAPLHR_QUERY_APPL_AREA:0122/subSUB:SAPLHR_QUERY_APPL_AREA:0120/cmbDD_DATE").key = "8"  # 其他期间
        session.findById("wnd[0]/usr/subSUB_MAIN:SAPLAQ_ADHOC:0212/subSUB_APPLICATION:SAPLHR_QUERY_APPL_AREA:0122/subSUB:SAPLHR_QUERY_APPL_AREA:0120/ctxtG_APPL_AREA-BEGDA").text = begin_date  # 开始日期
        session.findById("wnd[0]/usr/subSUB_MAIN:SAPLAQ_ADHOC:0212/subSUB_APPLICATION:SAPLHR_QUERY_APPL_AREA:0122/subSUB:SAPLHR_QUERY_APPL_AREA:0120/ctxtG_APPL_AREA-ENDDA").text = end_date  # 结束日期
    grid_view_ctrl_id = 'wnd[0]/usr/subSUB_MAIN:SAPLAQ_ADHOC:0212/subSUB_SELECTION:SAPLAQ_ADHOC:0310/cntlSEL_DEF_CONTAINER/shellcont/shell'
    grid_view_ctrl = GridViewCtrl(session, grid_view_ctrl_id)
    grid_view_ctrl['字段名称'].find('对象标识').same_line('更多值 ').press_button()
    session.findById("wnd[1]/tbar[0]/btn[16]").press()  # 清空
    pyperclip.copy('\r\n'.join(object_ids))  # 复制到剪切板
    session.findById("wnd[1]/tbar[0]/btn[24]").press()  # 粘贴
    session.findById("wnd[1]/tbar[0]/btn[8]").press()  # 确认
    session.findById("wnd[0]/tbar[1]/btn[8]").press()  # 输出


HEADER_IDS: List[str] = ['VALUE1', 'VALUE2', 'VALUE5', 'VALUE6', 'VALUE7', 'VALUE8', 'VALUE9', 'VALUE10', 'VALUE14',
                         'VALUE15', 'VALUE16', 'VALUE17', 'VALUE20', 'VALUE21', 'VALUE33', 'VALUE34', 'VALUE35',
                         'VALUE36', 'VALUE38', 'TEXT38', 'VALUE39', 'VALUE40', 'VALUE41', 'TEXT41', 'VALUE255',
                         'VALUE256', 'VALUE257', 'VALUE258', 'VALUE259', 'TEXT259', 'VALUE260', 'TEXT260', 'VALUE262',
                         'TEXT262', 'VALUE263', 'TEXT263', 'VALUE266', 'TEXT266', 'VALUE267', 'TEXT267', 'VALUE268',
                         'TEXT268', 'VALUE269', 'TEXT274', 'TEXT275', 'TEXT276']


def throw_exception_when_query_changed(session: Any):
    raise Exception('组合逻辑查询变式107----T83-4列ID与开发时不匹配')


def export_107_t83_4(session: Any, job_ids: List[str], key_date: str, begin_date='', end_date='') -> AdTable:
    """导出107_t83_4
       ------------------
       入参：
       session: SAP SESSION，如为None，则新打开SAP
       job_ids: 岗位编码
       key_date: 关键日期
       ------------------
       返回值：
       AdTable，可通过.wb访问Workbook，或.ws访问Worksheet
       ------------------
       调用样例：
       _table: AdTable = export_107_t83_4(None, ['04613370'], '20200301')
       _table.filename = '模板_107_t83_4'
       _table.save_to('x:/') # 保存模板至x:/下
    """
    logging.info(f'导出组合逻辑查询107_t83_4，岗位编号：{job_ids}，关键日期：{key_date}，开始日期：{begin_date}，结束日期：{end_date}')
    if all(map(lambda v: v == '', job_ids)) is True:
        raise Exception('岗位编号全为空值，请检查模板岗位编号是否填充')
    if session is None:
        session = attach_sap()
    elif isinstance(session, str):
        session = attach_sap(session)
    enter_107(session)  # 进入107信息集查询屏
    query_selection(session, '----T83-4', throw_exception_when_query_changed, HEADER_IDS)  # 勾选107_t83_4选项
    fill_107_t83_4(session, job_ids, key_date, begin_date=begin_date, end_date=end_date)  # 填入岗位编号和关键日期，并查询
    _lt: AdTable = export_query(session, query_name='----T83-4')
    _lt['A'].apply(init_sap_id)
    _lt.filename = 'T83-4'
    return _lt


# example
if __name__ == '__main__':
    from rpa.fastrpa.log import config
    config()
    sap_ids = ['00992832', '00994093', '00994109', '00994143', '00994569', '00994717', '00994786', '00994789', '01000662',
               '01001066', '01001085', '01001689', '01002187', '01003919', '01003931', '01003967', '01004089', '01004357',
               '01004401', '01004438', '01004752', '01004754', '01004755', '01004814', '01004822', '01004824', '01004827',
               '01004865', '03070862', '03070863', '03075576', '03087689', '03087692', '03087706', '03087708', '03088231',
               '03088339', '03101843', '03101844', '03102268', '03115335', '03160326', '03217238', '03221889', '03234809',
               '03265749', '03269578', '03312929', '03312930', '03312931', '03312932', '03315772', '03344583', '03443071',
               '03468233', '03477682', '03491045', '03507136', '03561186', '03855604', '04117893', '04117895', '04180301',
               '04442815', '04565926', '04565943', ]
    _lt: AdTable = export_107_t83_4(None, sap_ids, '', '20200601', '99991231')
    _lt.save_to('x:/')
