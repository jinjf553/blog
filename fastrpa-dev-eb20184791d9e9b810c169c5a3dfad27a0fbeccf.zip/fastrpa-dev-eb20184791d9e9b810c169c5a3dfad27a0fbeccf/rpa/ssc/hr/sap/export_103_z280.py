"""导出组合逻辑查询103(替代事务码zhrpy280，用于校验用户编码-姓名是否一致)"""
import logging
from typing import Any, List

import pyperclip
from rpa.fastrpa.adtable import AdTable
from rpa.fastrpa.named_lock import ClipboardLock
from rpa.fastrpa.sap.grid_view_ctrl import GridViewCtrl
from rpa.fastrpa.sap.session import SAP
from rpa.ssc.sap.query import export_query, query_selection
from rpa.ssc.sap.utils import init_sap_id


def enter_103(session: Any) -> None:
    """进入103"""
    session.findById("wnd[0]").maximize()
    session.findById("wnd[0]/tbar[0]/okcd").text = "/n S_PH0_48000513"
    session.findById("wnd[0]").sendVKey(0)
    session.findById("wnd[1]/usr/cmbDYNP4100-DD_WORKSPACE").setFocus()
    session.findById("wnd[1]/usr/cmbDYNP4100-DD_WORKSPACE").key = "2"  # 全局区域（跨集团）
    session.findById("wnd[1]/usr/cmbDYNP4100-DD_USERGROUP").setFocus()
    session.findById("wnd[1]/usr/cmbDYNP4100-DD_USERGROUP").key = "103"  # SAP_HR查询   （ZHR_ALL）
    session.findById("wnd[1]/usr/tblSAPLAQ_INT_FUNCTIONSTCH_FUNCAREAS").getAbsoluteRow(1).selected = -1
    session.findById("wnd[1]/usr/tblSAPLAQ_INT_FUNCTIONSTCH_FUNCAREAS/txtDYNP4100_TC_FUNCAREAS-NAME[0,1]").setFocus()
    session.findById("wnd[1]/usr/tblSAPLAQ_INT_FUNCTIONSTCH_FUNCAREAS/txtDYNP4100_TC_FUNCAREAS-NAME[0,1]").caretPosition = 0
    session.findById("wnd[1]/tbar[0]/btn[0]").press()  # 信息集查询（信息集：SAP_HR查询）


def select_103_z280(session: Any):
    enter_103(session)
    session.findById("wnd[0]/shellcont[1]/shell/shellcont[0]/shell/shellcont[1]/shell[1]").expandNode("          2")
    session.findById("wnd[0]/shellcont[1]/shell/shellcont[0]/shell/shellcont[1]/shell[1]").topNode = "          1"
    session.findById("wnd[0]/shellcont[1]/shell/shellcont[0]/shell/shellcont[1]/shell[1]").selectItem("          3", "C          3")
    session.findById("wnd[0]/shellcont[1]/shell/shellcont[0]/shell/shellcont[1]/shell[1]").ensureVisibleHorizontalItem("          3", "C          3")
    session.findById("wnd[0]/shellcont[1]/shell/shellcont[0]/shell/shellcont[1]/shell[1]").changeCheckbox("          3", "C          3", -1)
    session.findById("wnd[0]/shellcont[1]/shell/shellcont[0]/shell/shellcont[1]/shell[1]").selectItem("          3", "C          4")
    session.findById("wnd[0]/shellcont[1]/shell/shellcont[0]/shell/shellcont[1]/shell[1]").ensureVisibleHorizontalItem("          3", "C          4")
    session.findById("wnd[0]/shellcont[1]/shell/shellcont[0]/shell/shellcont[1]/shell[1]").changeCheckbox("          3", "C          4", -1)
    session.findById("wnd[0]/shellcont[1]/shell/shellcont[0]/shell/shellcont[1]/shell[1]").itemContextMenu("          3", "C          4")
    session.findById("wnd[0]/shellcont[1]/shell/shellcont[0]/shell/shellcont[1]/shell[1]").selectContextMenuItem("OUTPUT_BOTH")


def fill_103(session: Any, staff_ids: List[str]) -> None:
    """填充103"""
    # 点击今天按钮
    session.findById("wnd[0]/usr/subSUB_MAIN:SAPLAQ_ADHOC:0210/subSUB_APPLICATION:SAPLHR_QUERY_APPL_AREA:0122/subSUB:SAPLHR_QUERY_APPL_AREA:0121/btnDYNP121-EVALUATION_PERIOD_TEXT").press()
    # 报告期间选择全部
    session.findById("wnd[0]/usr/subSUB_MAIN:SAPLAQ_ADHOC:0210/subSUB_APPLICATION:SAPLHR_QUERY_APPL_AREA:0122/subSUB:SAPLHR_QUERY_APPL_AREA:0120/cmbDD_DATE").key = "4"
    grid_view_ctrl_id = 'wnd[0]/usr/subSUB_MAIN:SAPLAQ_ADHOC:0210/subSUB_SELECTION:SAPLAQ_ADHOC:0310/cntlSEL_DEF_CONTAINER/shellcont/shell'
    grid_view_ctrl = GridViewCtrl(session, grid_view_ctrl_id)
    grid_view_ctrl['字段名称'].find('人员编号').same_line('更多值 ').press_button()
    session.findById("wnd[1]/tbar[0]/btn[16]").press()
    with ClipboardLock():
        pyperclip.copy('\r\n'.join(staff_ids))  # 复制到剪切板
        session.findById("wnd[1]/tbar[0]/btn[24]").press()  # 粘贴
    try:
        session.findById("wnd[2]/tbar[0]/btn[0]").press()
    except Exception:  # nosec
        pass
    session.findById("wnd[1]/tbar[0]/btn[8]").press()
    session.findById("wnd[0]/tbar[1]/btn[8]").press()  # 输出按钮


HEADER_IDS: List[str] = ['VALUE1273', 'TEXT1273']


def export_103_z280(session: Any, staff_ids: List[str]) -> AdTable:
    """导出103
       ------------------
       入参：
       session: SAP SESSION，如为None，则新打开SAP
       staff_ids: 人员编号数组
       key_date: 关键日期
       ------------------
       返回值：
       AdTable，可通过.wb访问Workbook，或.ws访问Worksheet
       ------------------
       调用样例：
       _table: AdTable = export_103_Z280(None, ['01576547'], '20200301')
       _table.filename = '模板_103'
       _table.save_to('x:/') # 保存模板至x:/下
    """
    staff_ids = [staff_id.strip() for staff_id in staff_ids if staff_id.strip().isdigit()]
    _table: AdTable = AdTable('z280.xlsx')
    if len(staff_ids) == 0:
        _table['A'][1].value = '人员编号'
        _table['B'][1].value = '姓名'
        _table.filename = 'z280'
        return _table
    with SAP(session) as session:
        enter_103(session)  # 进入103信息集查询屏
        query_selection(session, 'RPA_Z280', select_103_z280, HEADER_IDS)  # 勾选103选项
        fill_103(session, staff_ids)  # 填入员工编号和关键日期，并查询
        try:
            _table = export_query(session, query_name='RPA_Z280')
        except Exception as e:
            logging.error(e)
        _table['A'][1].value = '人员编号'
        _table['B'][1].value = '姓名'
        _table['A'].apply(init_sap_id)
        _table.filename = 'z280'
        return _table


# example
if __name__ == '__main__':
    from rpa.fastrpa.log import config
    config()
    _table: AdTable = export_103_z280(None, ['01576547'])
    _table.save_to('x:/')
