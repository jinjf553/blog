r"""SAP `\N PA30`事务码(可重复执行)"""

import datetime
import logging
import pathlib
import re
import sys
from time import sleep

import pyperclip
import rpa.config
from rpa.fastrpa.adtable import AdTable, AdTableRow, load_from_xlsx_file
from rpa.fastrpa.date_funcs import valid_date
from rpa.fastrpa.log import config, logfn
from rpa.fastrpa.sap.gui_table_control import GuiTableControl
from rpa.fastrpa.sap.session import SapClose, attach_sap
from rpa.ssc.hr.orm.dims_utils import load_tb_dim_hr_diao_pei
from rpa.ssc.hr.sap.export_103 import export_103
from rpa.ssc.hr.sap.zhrpy280 import check_zhrpy280
from rpa.ssc.sap.utils import init_sap_id


def get_id(text):
    """返回单元格值的ID部分（一般为字母数字组成的ID+空格+中文，这里取ID部分）"""
    return re.match(r'([a-zA-Z0-9]+) .*', text).groups()[0]


PA30_TEMPLATE_HEADER = ['序号', '人员编号', '人员姓名', '人事范围', '人事子范围', '开始日期', '结束日期',
                        '原屏修改标识', '工资核算范围', '工资总额控制范围', '企业自定义分类1', '企业自定义分类2',
                        '企业自定义分类3', '工作合同', '业务范围', '功能范围', '企业统计标识', '总部统计唯一标识', '结果反馈']


# 识别表单
@logfn
def chk_1_01(_pa30: AdTable) -> bool:
    """读取表单【A1-S1】的值是否与表样相同。
    -------------------------------------
    1.为“不同”，在【R-结果反馈】单元格填充红色并插入批注“表样发生变化”；
    2.为“相同”，执行下一规则。
    """
    if _pa30.row(1).values != PA30_TEMPLATE_HEADER:
        _pa30.row(1)['R'].cmt('red', '表样发生变化')
        return False
    return True


# 人员姓名编号校验 & 校验校验人员姓名是否匹配
@logfn
def chk_1_02(pa30: AdTable):
    """提取【【B-人员编号】、【C-人员姓名】】，复制到【编号姓名核查-【B5-人员编号】、【C5-人员姓名】】。
    -------------------------------------
    1.检查zhrpy280导入【编号姓名模板】后是否有报错项，若有，在【S-结果反馈】单元格填充红色并插入批注“人员编号与人员姓名不对应”。
    """
    staffs = [{'staff_id': row['B'].value, 'staff_name': row['C'].value} for row in pa30.rows]
    err_staff_ids = check_zhrpy280(staffs)
    if len(err_staff_ids) > 0:
        for err_staff_id in err_staff_ids:
            pa30['B'].find(err_staff_id).same_line('S').cmt('red', 'Excel员工编号+姓名与系统中员工编号+姓名不一致，请检查')  # 此处口头通知修改为S列
        return False
    return True


# 码值性校验 & 校验人事范围、人事子范围及其对应关系
@logfn
def chk_1_03(_pa30: AdTableRow, dims: AdTable) -> bool:
    """检验【D-人事范围】是否在【码表库-【D-人事范围】】中，若不在，见1；
       若在，检验【E-人事子范围】是否在【码表库-【E-人事子范围】】中，若不在，见2；
       若在，检验【码表库-【D-人事范围】】是否与【D-人事范围】相同，若不同，见3。
    -------------------------------------
    1.为“不在”，在【D-人事范围】单元格填充红色并插入批注“人事范围非码值”，继续检验下一人员；
    2.为“不在”，在【E-人事子范围】单元格填充红色并插入批注“人事子范围非码值”，继续检验下一人员；
    3.为“不在”，在【D-人事范围】单元格填充红色并插入批注“人事范围与人事子范围不对应”，继续检验下一人员。
    """
    is_passed = True
    if _pa30['D'].value not in dims['D'].values:
        _pa30['D'].cmt('red', '人事范围非码值')
        is_passed = False
    if _pa30['E'].value not in dims['E'].values:
        _pa30['E'].cmt('red', '人事子范围非码值')
        is_passed = False
    staff_subgrp_id = _pa30['E'].value
    if staff_subgrp_id in dims['E'].values and _pa30['D'].value != dims['E'].find(staff_subgrp_id).same_line('D').value:
        _pa30['D'].cmt('red', '人事范围与人事子范围不对应')
        is_passed = False
    return is_passed


# 码值性校验 & 校验开始日期、结束日期
@logfn
def chk_1_04(_pa30: AdTableRow) -> bool:
    """检验【F-开始日期】、【G-结束日期】的值是否为符合常识的日期（8位数字）。
    -------------------------------------
    1.若值“不为正确日期”，在【F-开始日期】、【G-结束日期】单元格填充红色并插入批注“日期非正确值”，继续检验下一人员。
    """
    is_passed = True
    if valid_date(_pa30['F'].value) is False:
        _pa30['G'].cmt('日期非正确值')
        is_passed = False
    if valid_date(_pa30['F'].value) is False:
        is_passed = False
        _pa30['G'].cmt('日期非正确值')
    return is_passed


# 码值性校验 & 校验开始日期
@logfn
def chk_1_05(_pa30: AdTableRow) -> bool:
    """检验【F-开始日期】的值是否相同。
    -------------------------------------
    1.为“不同”，在【F-开始日期】单元格填充红色并插入批注“开始日期不同”，继续检验下一人员。
    """
    for value in _pa30.table['F'].values:
        if _pa30['F'].value != value:
            _pa30['F'].cmt('red', '“开始日期不同')
            return False
    return True

# 码值性校验 & 校验开始日期不早于当月1号


@logfn
def chk_1_05b(_pa30: AdTableRow) -> bool:
    """检验【F-开始日期】的值是否早于执行时间当月一号。
    -------------------------------------
    1.早于当月1号，在【F-开始日期】单元格填充红色并插入批注“开始日期不能早于当月一号”，继续检验下一人员。
    """
    yyyymm01 = datetime.datetime.now().strftime(r'%Y%m01')
    if _pa30['F'].value < yyyymm01:
        _pa30['F'].cmt('red', f'开始日期不能早于{yyyymm01}')
        return False
    return True

# 码值性校验 & 校验原屏修改标识


@logfn
def chk_1_06(_pa30: AdTableRow) -> bool:
    """检验【H-原屏修改标识】的值是否为“是”或者“否”之一。
    -------------------------------------
    1.为“不是”，在【H-原屏修改标识】单元格填充红色并插入批注“原屏修改标识非码值”，继续检验下一人员。
    """
    if _pa30['H'].value not in ('是', '否'):
        _pa30['H'].cmt('red', '原屏修改标识非码值')
        return False
    return True


# 码值性校验 & 校验00时的工资总额控制范围
@logfn
def chk_1_07(_pa30: AdTableRow) -> bool:
    """当【I-工资核算范围】的值为“不变”时，不执行规则1.07-1.09
       当【I-工资核算范围】的值为“00”时，检验【J-工资总额控制范围】的值是否为“清空”。
    -------------------------------------
    1.为“不是”，在【J-工资总额控制范围】单元格填充红色并插入批注“工资总额控制范围有误”，继续检验下一人员。
    """
    if _pa30['I'].value == '00' and _pa30['J'].value != '清空':
        _pa30['J'].cmt('red', '“工资总额控制范围有误[规则1.07]')
        return False
    return True


# 码值性校验 & 校验工资核算范围
@logfn
def chk_1_08(_pa30: AdTableRow, dims: AdTable) -> bool:
    """当【I-工资核算范围】的值不为“00”时，检验【D-人事范围】是否存在于【码表库-【AA-人事范围】】中，若不存在，见1；
       再检验【E-人事子范围】是否存在于锁定后的【码表库-【AB-人事子范围】】中，若不存在，见3；
       最后检验【I-工资核算范围】的值是否存在于两次锁定后的【码表库-【AE-工资范围】】中，若不在，见3。
       -------------------------------------
       1.为“不存在”，在【D-人事范围】单元格填充红色并插入批注“人事范围非码值！”，继续检验下一人员；
       2.为“不存在”，在【E-人事子范围】单元格填充红色并插入批注“人事子范围与人事范围没有对应关系！”，继续检验下一人员。
       3.为“不存在，在【I-工资核算范围】单元格填充红色并插入批注“工资核算范围与与人事范围、人事子范围没有对应关系！”，继续检验下一人员；
    """
    if _pa30['I'].value not in ('00', '0'):
        _d = _pa30['D'].value
        if _d not in dims['AA'].values:
            _pa30['D'].cmt('red', '人事范围非码值！')
            return False
        _e = _pa30['E'].value
        cells = dims['AA'].find_all(_d)
        if _e not in cells.same_line('AB').values:
            _pa30['E'].cmt('red', '人事子范围与人事范围没有对应关系！')
            return False
        _i = _pa30['I'].value
        if _i not in cells.same_line('AB').find_all(_e).same_line('AE').values:
            _pa30['I'].cmt('red', '工资核算范围与与人事范围、人事子范围没有对应关系！')
            return False
    return True


# 码值性校验 & 校验工资总额控制范围
@logfn
def chk_1_09(_pa30: AdTableRow, dims: AdTable) -> bool:
    """当【I-工资核算范围】的值为“不变”时，不执行规则1.07-1.09
       当“规则-1.07”完全正确时且【I-工资核算范围】的值不为“00”时，执行此条规则：
       锁定【码表库-【AA-人事范围】、【AB-人事子范围】、【AE-工资范围】】与【D-人事范围】【E-人事子范围】【I-工资核算范围】相同的值，
       检验【J-工资总额控制范围】是否与【码表库-【AF-工资总额控制范围】】相同，若不同，见1.
    -------------------------------------
    1.为“不是”，在【J-工资总额控制范围】单元格填充红色并插入批注“工资总额控制范围有误”，继续检验下一人员。
    """
    if chk_1_07(_pa30) is True and _pa30['I'].value != '00':
        _d = _pa30['D'].value
        _e = _pa30['E'].value
        _i = _pa30['I'].value
        _j = _pa30['J'].value
        try:
            if _j != dims['AA'].find_all(_d).same_line('AB').find_all(_e).same_line('AE').find(_i).same_line('AF').value:
                _pa30['J'].cmt('red', '工资总额控制范围有误[规则1.09-1]')
                return False
        except Exception:
            _pa30['J'].cmt('red', '工资总额控制范围有误[规则1.09-2]')
    return True


# 码值性校验 & 校验企业自定义分类1
@logfn
def chk_1_10(_pa30: AdTableRow, dims: AdTable) -> bool:
    """当【K-企业自定义分类1】的值为“不变”时，不执行规则1.10
       检验【K-企业自定义分类1】的值是否在【码表库-【F-企业自定义分类1】】中，若不在，见1。
    -------------------------------------
    1.为“不是”，在【K-企业自定义分类1】单元格填充红色并插入批注“企业自定义分类1非码值”，继续检验下一人员。
    """
    if _pa30['K'].value not in dims['F'].values:
        _pa30['K'].cmt('red', '企业自定义分类1非码值')
        return False
    return True


# 码值性校验 & 校验企业自定义分类2
@logfn
def chk_1_11(_pa30: AdTableRow, dims: AdTable) -> bool:
    """当【L-企业自定义分类2】的值为“不变”时，不执行规则1.11
       检验【L-企业自定义分类2】的值是否在【码表库-【G-企业自定义分类2】】中，若不在，见1。
    -------------------------------------
    1.为“不是”，在【L-企业自定义分类2】单元格填充红色并插入批注“企业自定义分类2非码值”，继续检验下一人员。
    """
    if _pa30['L'].value not in dims['G'].values:
        _pa30['L'].cmt('red', '企业自定义分类2非码值')
        return False
    return True


# 码值性校验 & 校验企业自定义分类3
@logfn
def chk_1_12(pa30: AdTableRow, dims: AdTable) -> bool:
    """当【M-企业自定义分类3】的值为“不变”时，不执行规则1.12
       检验【M-企业自定义分类3】的值是否在【码表库-【H-企业自定义分类3】】中，若不在，见1。
    -------------------------------------
    1.为“不是”，在【M-企业自定义分类3】单元格填充红色并插入批注“企业自定义分类3非码值”，继续检验下一人员。
    """
    if pa30['M'].value not in dims['H'].values:
        pa30['M'].cmt('red', '企业自定义分3非码值')
        return False
    return True


# 码值性校验 & 校验工作合同
@logfn
def chk_1_13(_pa30: AdTableRow, dims: AdTable) -> bool:
    """当【N-工作合同】的值为“不变”时，不执行规则1.13
       检验【N-工作合同】的值是否在【码表库-【Y-工组合同】】中，若不在，见1。
    -------------------------------------
    1.为“不是”，在【N-工作合同】单元格填充红色并插入批注“工作合同非码值”，继续检验下一人员。
    """
    if _pa30['N'].value not in dims['Y'].values:
        _pa30['N'].cmt('red', '工作合同非码值')
        return False
    return True


# 码值性校验 & 校验业务范围
@logfn
def chk_1_14(_pa30: AdTableRow, dims: AdTable) -> bool:
    """当【O-业务范围】的值为“不变”时，不执行规则1.14
       检验【O-业务范围】的值是否在【码表库-【BO-业务范围】】中，若不在，见1。
    -------------------------------------
    1.为“不是”，在【O-业务范围】单元格填充红色并插入批注“业务范围非码值”，继续检验下一人员。
    """
    if _pa30['O'].value not in dims['BO'].values:
        _pa30['O'].cmt('red', '业务范围非码值')
        return False
    return True


# 码值性校验 & 校验功能范围
@logfn
def chk_1_15(pa30: AdTableRow, dims: AdTable) -> bool:
    """当【P-功能范围】的值为“不变”时，不执行规则1.15
       检验【P-功能范围】的值是否在【码表库-【BP-功能范围】】中，若不在，见1。
    -------------------------------------
    1.为“不是”，在【P-功能范围】单元格填充红色并插入批注“功能范围非码值”，继续检验下一人员。
    """
    if pa30['P'].value not in dims['BP'].values:
        pa30['P'].cmt('red', '功能范围非码值')
        return False
    return True


# 码值性校验 & 校验企业统计标识
@logfn
def chk_1_16(_pa30: AdTableRow) -> bool:
    """当【Q-企业统计标识】的值为“不变”时，不执行规则1.16
       检验【Q-企业统计标识】的值是“是”或者“否”之一。
    -------------------------------------
    1.为“不是”，在【Q-企业统计标识】单元格填充红色并插入批注“企业统计标识非码值”，继续检验下一人员。
    """
    if _pa30['Q'].value not in ('是', '否'):
        _pa30['Q'].cmt('red', '企业统计标识非码值')
        return False
    return True


# 码值性校验 & 校验总部统计唯一标识
@logfn
def chk_1_17(_pa30: AdTableRow, dims: AdTable) -> bool:
    """当【R-总部统计唯一标识】的值为“不变”时，不执行规则1.17
       检验【R-总部统计唯一标识】的值是否在【码表库-【BQ-总部统计唯一标识】】中，若不在，见1。
    -------------------------------------
    1.为“不是”，在【R-总部统计唯一标识】单元格填充红色并插入批注“总部统计唯一标识非码值”，继续检验下一人员。
    """
    if _pa30['R'].value not in dims['BQ'].values:
        _pa30['R'].cmt('red', '总部统计唯一标识非码值')
        return False
    return True


# 反馈
@logfn
def chk_1_18(pa30: AdTable, dims: AdTable) -> bool:
    """当表单无任何批注时，执行下一规则；有任一批注，不予执行。
    -------------------------------------
    """
    logging.info('【模板字段校验】')
    logging.info('【模板字段校验】校验模板标样是否变更')
    is_check_passed = [chk_1_01(pa30)]
    logging.info('【模板字段校验】启动SAP，执行事务码zhrpy280，校验人员编号、姓名是否匹配')
    with SapClose():
        is_check_passed.append(chk_1_02(pa30))  # 人员姓名编号匹配校验
    total_cnt = len(pa30.rows.rows)
    for finished_cnt, _pa30 in enumerate(pa30.rows, start=1):
        logging.info(f'【模板字段校验】规则校验，共{total_cnt}行记录，正在校验第{finished_cnt}行')
        is_check_passed.append(chk_1_03(_pa30, dims))
        is_check_passed.append(chk_1_04(_pa30))
        is_check_passed.append(chk_1_05(_pa30))
        is_check_passed.append(chk_1_05b(_pa30))
        is_check_passed.append(chk_1_06(_pa30))
        if _pa30['I'].value != '不变':
            is_check_passed.append(chk_1_07(_pa30))  # 当【I-工资核算范围】的值为“不变”时，不执行规则1.07-1.09
            is_check_passed.append(chk_1_08(_pa30, dims))
            is_check_passed.append(chk_1_09(_pa30, dims))
        if _pa30['K'].value != '不变':
            is_check_passed.append(chk_1_10(_pa30, dims))  # 当【K-企业自定义分类1】的值为“不变”时，不执行规则1.10
        if _pa30['L'].value != '不变':
            is_check_passed.append(chk_1_11(_pa30, dims))  # 当【L-企业自定义分类2】的值为“不变”时，不执行规则1.11
        if _pa30['M'].value != '不变':
            is_check_passed.append(chk_1_12(_pa30, dims))  # 当【M-企业自定义分类3】的值为“不变”时，不执行规则1.12
        if _pa30['N'].value != '不变':
            is_check_passed.append(chk_1_13(_pa30, dims))  # 当【N-工作合同】的值为“不变”时，不执行规则1.13
        if _pa30['O'].value != '不变':
            is_check_passed.append(chk_1_14(_pa30, dims))  # 当【O-业务范围】的值为“不变”时，不执行规则1.14
        if _pa30['P'].value != '不变':
            is_check_passed.append(chk_1_15(_pa30, dims))  # 当【P-功能范围】的值为“不变”时，不执行规则1.15
        if _pa30['Q'].value != '不变':
            is_check_passed.append(chk_1_16(_pa30))  # 当【Q-企业统计标识】的值为“不变”时，不执行规则1.16
        if _pa30['R'].value != '不变':
            is_check_passed.append(chk_1_17(_pa30, dims))  # 当【R-总部统计唯一标识】的值为“不变”时，不执行规则1.17
    if all(is_check_passed) is True:
        logging.info('【模板字段校验】结束，所有检查项均通过')
        return True
    else:
        pathlib.Path(f'{rpa.config.D_RPA}/HR人事/组织分配屏修改').mkdir(parents=True, exist_ok=True)
        filename = pa30.save_to(f'{rpa.config.D_RPA}/HR人事/组织分配屏修改/')
        logging.info(f'【模板字段校验】结束，存在检查项未通过，请检查模板批注查看原因，模板保存路径：{filename}。')
        return False


# 执行（功能逻辑在函数chk_2_04中实现）
@logfn
def chk_2_01():
    """进入组织分配屏，若最上一条开始日期在【F-开始日期】之前，见1；
       若最上一条开始日期与【F-开始日期】相同，检验【H-原屏修改标识】的码值是否为“是”，若是，见1；
       若不是，见2；若最上一条开始日期在【F-开始日期】之后，见2。
    -------------------------------------
    1.复制最上一条组织分配屏，开始日期和结束日期分别填写为：【F-开始日期】、【G-结束日期】并在其中修改；
    2.不予执行，跳转下一人。
    """
    pass


# 执行 & 判断人事范围 （功能逻辑在函数chk_2_04中实现）
@logfn
def chk_2_02():
    """进入PA30，逐次进入人员界面，检验人事范围是否与【D-人事范围】相同，若不同，见1.
    -------------------------------------
    1.为“不同”，在【S-结果反馈】单元格填充红色并输入“人事范围不同，该人员不予修改”，继续检验下一人员。
    """
    pass


# 执行 & 修改人事子范围并予以记录 （功能逻辑在函数chk_2_04中实现）
@logfn
def chk_2_03():
    """检验人事子范围是否与【E-人事子范围】相同，若不同，见1.
    -------------------------------------
    1.为“不同”，将【E-人事子范围】的代码部分填入，并在【S-结果反馈】单元格输入“人事子范围已修改”，继续检验下一人员。
    """
    pass


# 执行 & 修改其他信息项并予以记录（功能逻辑2.0.1-2.0.4在函数chk_2_04中实现）
@logfn
def chk_2_04(pa30: AdTableRow, session) -> bool:
    """修改各个码值非“不变”的信息项：工资核算范围 、工资总额控制范围 、企业自定义分类1 、企业自定义分类2 、企业自定义分类3 、工作合同 、业务范围 、功能范围 、企业统计标识 、总部统计唯一标识。
       -------------------------------------
       1.将各信息项代码部分填入，并在【S-结果反馈】单元格输入“各信息项已修改”，继续检验下一人员。
    """
    is_noerror = True
    session.findById("wnd[0]/usr/ctxtP0001-BEGDA").text = pa30['F'].value  # 开始日期
    session.findById("wnd[0]/usr/ctxtP0001-ENDDA").text = pa30['G'].value  # 结束日期
    session.findById("wnd[0]/usr/ctxtP0001-BTRTL").text = get_id(pa30['E'].value)  # 人事子范围
    if pa30['I'].value != '不变':  # 输入框：工资(核算)范围
        try:
            text = '' if pa30['I'].value == '清空' else pa30['I'].value
            session.findById("wnd[0]/usr/ctxtP0001-ABKRS").text = text
        except Exception:
            pa30['I'].cmt('red', '工资(核算)范围修改失败')
            is_noerror = False
    if pa30['J'].value != '不变':  # 输入框：工资总额控制范围
        try:
            text = '' if pa30['J'].value == '清空' else pa30['J'].value
            session.findById("wnd[0]/usr/subSUBSCREEN_T582C:ZP000100:0200/ctxtP0001-ZZ_ZEFW").text = text
        except Exception:
            pa30['I'].cmt('red', '，工资总额控制范围修改失败')
            is_noerror = False
    if pa30['K'].value != '不变':  # 输入框：企业自定义分类1
        try:
            text = '' if pa30['K'].value == '清空' else get_id(pa30['K'].value)
            session.findById("wnd[0]/usr/subSUBSCREEN_T582C:ZP000100:0200/ctxtP0001-ZZ_QYZDYYGFL").text = text
        except Exception:
            pa30['K'].cmt('red', '，企业自定义分类1修改失败')
            is_noerror = False
    if pa30['L'].value != '不变':  # 输入框：企业自定义分类2
        try:
            text = '' if pa30['L'].value == '清空' else get_id(pa30['L'].value)
            session.findById("wnd[0]/usr/subSUBSCREEN_T582C:ZP000100:0200/ctxtP0001-ZZ_QYZDYYGFL1").text = text
        except Exception:
            pa30['L'].cmt('red', '企业自定义分类2修改失败')
            is_noerror = False
    if pa30['M'].value != '不变':  # 输入框：企业自定义分类3
        try:
            text = '' if pa30['M'].value == '清空' else get_id(pa30['M'].value)
            session.findById("wnd[0]/usr/subSUBSCREEN_T582C:ZP000100:0200/ctxtP0001-ZZ_QYZDYYGFL2").text = text
        except Exception:
            pa30['M'].cmt('red', '企业自定义分类3修改失败')
            is_noerror = False
    if pa30['N'].value != '不变':  # 下拉选择框：工作合同
        try:
            key = get_id(pa30['N'].value)
            session.findById("wnd[0]/usr/cmbP0001-ANSVH").key = key
        except Exception:
            pa30['N'].cmt('red', '工作合同修改失败')
            is_noerror = False
    if pa30['O'].value != '不变':  # 输入框：业务范围
        try:
            text = '' if pa30['O'].value == '清空' else get_id(pa30['O'].value)
            session.findById("wnd[0]/usr/ctxtP0001-GSBER").text = text
        except Exception:
            pa30['O'].cmt('red', '业务范围修改失败')
            is_noerror = False
    if pa30['P'].value != '不变':  # 下拉选择框：功能范围
        try:
            key = get_id(pa30['P'].value)
            session.findById("wnd[0]/usr/subSUBSCREEN_T582C:ZP000100:0200/cmbP0001-ZZ_GNFW").key = key
        except Exception:
            pa30['P'].cmt('red', '功能范围修改失败')
            is_noerror = False
    if pa30['Q'].value != '不变':  # 单选框：企业统计标识
        try:
            select_status = 1 if pa30['Q'].value == '是' else 0
            session.findById("wnd[0]/usr/subSUBSCREEN_T582C:ZP000100:0200/chkP0001-ZZ_QYTJBS1").selected = select_status
        except Exception:
            pa30['Q'].cmt('red', '企业统计标识修改失败')
            is_noerror = False
    if pa30['R'].value != '不变':  # 下拉选择框：总部统计唯一标识
        try:
            key = get_id(pa30['R'].value)
            session.findById("wnd[0]/usr/subSUBSCREEN_T582C:ZP000100:0200/cmbP0001-ZZ_ZBTJWYBZ").key = key
        except Exception:
            pa30['R'].cmt('red', '总部统计唯一标识修改失败')
            is_noerror = False
    return is_noerror


@logfn
def sap_pa30(pa30: AdTable, ignore_flag=False) -> bool:
    """使用人事范围批量勾选最高工种标识
    -------------------------------------
    20200708新增规则：（分两次打包为不同的程序）
    ignore_flag 默认为 False
    ignore_flag 为 False 时，原屏修改标识为是，模板开始日期等于SAP开始日期，会在原屏进行修改
    ignore_flag 为 True 时，即使原屏修改标识为否，只要模板开始日期等于SAP开始日期，仍然会在原屏进行修改
    """
    logging.info('【组织分配屏修改】（事务码：PA30）')
    logging.info('【组织分配屏修改】启动SAP')
    session = attach_sap('reopen')
    session.findById("wnd[0]").maximize()
    session.findById("wnd[0]/tbar[0]/okcd").text = "/n PA30"  # 进入组织分配屏
    session.findById("wnd[0]").sendVKey(0)
    session.findById("wnd[0]/shellcont/shell/shellcont[0]/shell/shellcont[1]/shell[1]").selectItem("          2", "&Hierarchy")
    session.findById("wnd[0]/shellcont/shell/shellcont[0]/shell/shellcont[1]/shell[1]").ensureVisibleHorizontalItem("          2", "&Hierarchy")
    session.findById("wnd[0]/shellcont/shell/shellcont[0]/shell/shellcont[1]/shell[1]").clickLink("          2", "&Hierarchy")  # 集合搜索帮助
    session.findById("wnd[1]/usr/tabsG_SELONETABSTRIP/tabpTAB002").select()  # IC号码
    session.findById("wnd[1]/usr/tabsG_SELONETABSTRIP/tabpTAB002/ssubSUBSCR_PRESEL:SAPLSDH4:0220/sub:SAPLSDH4:0220/txtG_SELFLD_TAB-LOW[4,24]").setFocus()  # 人员编号
    session.findById("wnd[1]/usr/tabsG_SELONETABSTRIP/tabpTAB002/ssubSUBSCR_PRESEL:SAPLSDH4:0220/sub:SAPLSDH4:0220/txtG_SELFLD_TAB-LOW[4,24]").caretPosition = 0
    session.findById("wnd[1]/usr/tabsG_SELONETABSTRIP/tabpTAB002/ssubSUBSCR_PRESEL:SAPLSDH4:0220/sub:SAPLSDH4:0220/btnG_SELFLD_TAB-MORE[4,56]").press()  # 多项选择
    session.findById("wnd[2]/tbar[0]/btn[16]").press()  # 删除
    staff_ids = pa30['B'].values
    pyperclip.copy('\r\n'.join(staff_ids))  # 复制人员编号到剪切板
    session.findById("wnd[2]/tbar[0]/btn[24]").press()  # 粘贴
    session.findById("wnd[2]/tbar[0]/btn[8]").press()  # 执行
    session.findById("wnd[1]/tbar[0]/btn[0]").press()  # 确认
    # 勾选一次即可
    session.findById("wnd[0]/usr/tabsMENU_TABSTRIP/tabpTAB03").select()  # 劳动关系
    session.findById("wnd[0]/usr/tabsMENU_TABSTRIP/tabpTAB03/ssubSUBSCR_MENU:SAPMP50A:0400/subSUBSCR_ITMENU:SAPMP50A:0310/tblSAPMP50ATC_MENU").getAbsoluteRow(0).selected = -1  # 组织分配及岗位聘任
    # 当人员编号在SAP中不存在时，excel里的人员编号会多于SAP的，直接用excel的量去遍历会超出索引报错(在事前校验zhrpy280里将缺失的员工编号标注为错误)
    is_noerror = True
    total_cnt = len(pa30['B'].values)
    finished_cnt = 0
    for rn in range(len(list(set(pa30['B'].values)))):  # 一个人员编号可能存在多条记录，这里要去重（因为SAP列表也去重了，这里是为了避免在SAP列表中定位时超出列表索引值）
        session.findById("wnd[0]/shellcont/shell/shellcont[1]/shell").currentCellRow = rn
        session.findById("wnd[0]/shellcont/shell/shellcont[1]/shell").selectedRows = str(rn)
        session.findById("wnd[0]/shellcont/shell/shellcont[1]/shell").doubleClickCurrentCell()  # SAP中选中人员编号
        try:
            staff_id = init_sap_id(session.findById("wnd[0]/usr/ctxtRP50G-PERNR").text)  # SAP人员编号
        except Exception:
            staff_id = init_sap_id(session.findById("wnd[0]/usr/subSUBSCREEN_HEADER:/1PAPAXX/HDR_80003A:0100/txt$_DG01_800A03_DAT_P0000_PERNR").text)  # SAP人员编号
        staff_pa30_rows = pa30['B'].find_all(staff_id).same_line('F').asc().rows  # 对于某一特定员工编号，用开始日期升序排序
        for _pa30 in staff_pa30_rows:  # 遍历当前员工编号所有行
            finished_cnt = finished_cnt + 1
            logging.info(f"【组织分配屏修改】共{total_cnt}行记录，正在修改第{finished_cnt}行，人员编号：{staff_id}，开始日期：{_pa30['F'].value}")
            session.findById("wnd[0]/tbar[1]/btn[20]").press()  # 点击【概览】
            gui_table_control = GuiTableControl(session, 'wnd[0]/usr/tblMP000100TC3000')
            most_recent_begin_time = gui_table_control['开始日期'].values[0]  # 获取最上一条开始日期
            most_recent_begin_time = ''.join([c for c in list(most_recent_begin_time) if c in '0123456789'])  # 将最上一条开始日期转为yyyymmdd格式
            yyyymm01 = datetime.datetime.now().strftime(r'%Y%m01')
            if ignore_flag is True and most_recent_begin_time == _pa30['F'].value:  # 如果ignore_flag为True，模板日期等于SAP第一条开始日期，原屏修改（即使原屏修改标识为否）
                logging.info('模板日期等于SAP第一条开始日期，原屏修改')
                session.findById("wnd[0]/usr/tblMP000100TC3000").getAbsoluteRow(0).selected = -1  # 选择第一条记录
                session.findById("wnd[0]/tbar[1]/btn[6]").press()  # 点击更改
            elif most_recent_begin_time > _pa30['F'].value and _pa30['F'].value >= yyyymm01:  # 模板日期早于SAP第一条开始日期，且大于执行日期当月1号，原屏修改
                logging.info('模板日期早于SAP第一条开始日期，且大于执行日期当月1号，原屏修改')
                _begin_date = _pa30['F'].value
                dotted_begin_date = _begin_date[:4] + '.' + _begin_date[4:6] + '.' + _begin_date[6:8]
                try:
                    gui_table_control['开始日期'].find(dotted_begin_date).select_row()  # 在表格开始日期列查找开始日期，并选中对应行
                except Exception:
                    _pa30['S'].value = f'模板日期早于SAP第一条开始日期，且大于执行日期当月1号，原屏修改，但SAP种未找到开始日期为{dotted_begin_date}的记录'
                    logging.error(f'找不到开始日期：{dotted_begin_date}，跳过修改')
                    continue
                session.findById("wnd[0]/tbar[1]/btn[6]").press()  # 点击更改
            else:
                session.findById("wnd[0]/tbar[0]/btn[3]").press()  # 返回
                if ignore_flag is False and _pa30['H'].value == '否' and most_recent_begin_time == _pa30['F'].value:  # chk_2_01
                    _pa30['S'].value = '原屏修改标识为否，且SAP开始日期等于模板开始日期，跳过修改'
                    continue
                elif most_recent_begin_time > _pa30['F'].value:
                    _pa30['S'].value = 'SAP开始日期大于模板开始日期，跳过修改'
                    continue
                session.findById("wnd[0]/tbar[1]/btn[21]").press()  # 复制一屏。已确认，当日期相同时，复制等于原屏修改。
                begin_date = session.findById("wnd[0]/usr/ctxtP0001-BEGDA").text.replace('.', '')
                begin_date = ''.join([c for c in list(begin_date) if c in '0123456789'])  # SAP-开始日期
                staff_group = session.findById("wnd[0]/usr/ctxtP0001-WERKS").text  # 人事范围(id)
                staff_subgroup = session.findById("wnd[0]/usr/ctxtP0001-BTRTL").text  # 人事子范围(id)
                staff_subgroup_nm = session.findById("wnd[0]/usr/txtT001P-BTEXT").text  # 人事子范围(name)
                if begin_date > _pa30['F'].value:  # 开始时间大于当前日期
                    session.findById("wnd[0]/tbar[0]/btn[3]").press()  # 返回
                    _pa30['F'].cmt('red', 'SAP开始日期大于表格日期，跳过修改')
                    _pa30['S'].value = 'SAP开始日期大于表格日期，跳过修改'
                    continue
                elif begin_date == _pa30['F'].value and _pa30['H'].value != '是':
                    _pa30['S'].value = 'SAP开始日期等于表格日期，且原屏修改为否，跳过修改'
                    continue
                if staff_group != _pa30['D'].value:
                    _pa30['S'].cmt('red', '人事范围不同，该人员不予修改')  # chk_2_02
                    _pa30['S'].value = '人事范围不同，该人员不予修改'
                    continue
                if staff_subgroup + ' ' + staff_subgroup_nm != _pa30['E'].value:
                    _pa30['S'].cmt('red', '人事子范围不同，该人员不予修改')  # chk_2_03
                    _pa30['S'].value = '人事子范围不同，该人员不予修改'
                    continue
            if chk_2_04(_pa30, session) is True:
                _pa30['S'].cmt('white', '各信息项已修改')
                _pa30['S'].value = '各信息项已修改'
            session.findById("wnd[0]").sendVKey(0)
            session.findById("wnd[0]").sendVKey(0)  # 2次回车
            session.findById("wnd[0]/tbar[0]/btn[11]").press()  # 保存
            sap_status = ''
            for i in range(10):
                sap_status = session.findById("wnd[0]/sbar/pane[0]").text
                if '记录已创建' in sap_status:
                    break
                else:
                    sleep(0.2)
                    session.findById("wnd[0]").sendVKey(0)  # 回车
            if '记录已创建' not in sap_status and sap_status.strip(' ') != '':  # 原屏修改保存时，SAP状态栏信息为空
                logging.error(sap_status)
                _pa30['S'].value = sap_status
                _pa30['S'].cmt('red', f'SAP错误信息：{sap_status}')
                session.findById("wnd[0]/tbar[0]/btn[12]").press()  # 取消 (20200316沟通，遇到错误情形时，点击取消按钮)
                try:
                    session.findById("wnd[1]/usr/btnSPOP-OPTION1").press()  # 是
                except Exception:  # nosec 还有可能直接取消，不需要确认
                    pass
                is_noerror = False
    session.findById("wnd[0]/tbar[0]/okcd").text = "/nex"
    session.findById("wnd[0]").sendVKey(0)  # 返回主屏
    if is_noerror is True:
        pathlib.Path(f'{rpa.config.D_RPA}/HR人事/组织分配屏修改').mkdir(parents=True, exist_ok=True)
        filename = pa30.save_to(f'{rpa.config.D_RPA}/HR人事/组织分配屏修改/')
        logging.info('【组织分配屏修改】结束，修改过程未遇到问题')
        return True
    else:
        pathlib.Path(f'{rpa.config.D_RPA}/HR人事/组织分配屏修改').mkdir(parents=True, exist_ok=True)
        filename = pa30.save_to(f'{rpa.config.D_RPA}/HR人事/组织分配屏修改/')
        logging.info(f'【组织分配屏修改】结束，修改过程存在问题，请检查模板批注查看原因，模板保存路径：{filename}。')
        return False


# 主函数


@logfn
def main(filename: str, is_before_check=True, is_sap_pa30=True, ignore_flag=False):
    """20200708新增规则：（分两次打包为不同的程序）
       ignore_flag 默认为 False
       ignore_flag 为 False 时，原屏修改标识为是，模板开始日期等于SAP开始日期，会在原屏进行修改
       ignore_flag 为 True 时，即使原屏修改标识为否，只要模板开始日期等于SAP开始日期，仍然会在原屏进行修改
    """
    lt_pa30 = load_from_xlsx_file(filename)
    lt_pa30.del_blank_rows_by_column('B')
    lt_pa30['B'].apply(init_sap_id)
    lt_pa30['I'].apply(lambda c: '00' if c == '0' else c)
    lt_dims = load_tb_dim_hr_diao_pei()
    staff_ids = lt_pa30['B'].values
    key_date = lt_pa30['F'].values[0]
    lt_103 = export_103(None, staff_ids, key_date)
    lt_103.filename = pathlib.Path(filename).name[:-4] + '_事前导出103'
    lt_103.save_to(f'{rpa.config.D_RPA}/HR人事/组织分配屏修改/')
    if is_before_check is True and chk_1_18(lt_pa30, lt_dims) is False:  # 事前校验
        return False
    if is_sap_pa30 is True and sap_pa30(lt_pa30, ignore_flag) is False:  # SAP修改
        lt_103 = export_103(None, staff_ids, key_date)
        lt_103.filename = pathlib.Path(filename).name[:-4] + '_事后导出103'
        lt_103.save_to(f'{rpa.config.D_RPA}/HR人事/组织分配屏修改/')
        return False
    lt_103 = export_103(None, staff_ids, key_date)
    lt_103.filename = pathlib.Path(filename).name[:-4] + '_事后导出103'
    lt_103.save_to(f'{rpa.config.D_RPA}/HR人事/组织分配屏修改/')
    return True


# 命令行执行
if __name__ == '__main__':
    config('pa30.log')
    with SapClose():
        if len(sys.argv) >= 2 and len(sys.argv[1]) > 5 and sys.argv[1][:5].lower() == r'.xlsx':
            pa30_template_filename = sys.argv[1]
            main(pa30_template_filename)
        else:
            main(r"x:\Users\rpa\Desktop\组织分配屏修改RPA模板V2.xlsx", True, False, False)
            logging.info('程序调用方式：pa30.py 组织分配屏修改模板.xlsx')
