"""批导调出模板"""
import logging

from rpa.fastrpa.adtable import AdTable, load_from_xlsx_file
from rpa.fastrpa.tempdir import gentempdir
from rpa.ssc.hr.sap.import_xlsx import import_multi


def import_checkout(_out: AdTable) -> bool:
    """上传调出模板/批导调入模板至SAP，成功返回True，失败返回False。"""
    # 导出调出模板为临时文件
    temp_dir = gentempdir()
    logging.info(f'生成调出模板批导文件')
    try:
        filename = _out.save_to(temp_dir)
    except PermissionError:
        _out.filename += '_副本'
        filename = _out.save_to(temp_dir)
    logging.info(f'调出模板生成成功，文件路径：{filename}')
    is_import_succ = import_multi('调出事件批导', filename)
    _out_imported = load_from_xlsx_file(filename, skip_header=6)
    _out.replace_content_by(_out_imported)  # 读取批导结果，并写入原文件
    return is_import_succ
