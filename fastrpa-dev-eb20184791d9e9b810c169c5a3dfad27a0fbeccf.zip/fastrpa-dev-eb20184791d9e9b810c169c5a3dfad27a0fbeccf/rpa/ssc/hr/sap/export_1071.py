"""导出组合逻辑查询1071"""
import logging
from typing import Any, List

import pyperclip
from rpa.config import TEMPLATE_DIR
from rpa.fastrpa.adtable import AdTable
from rpa.fastrpa.sap.grid_view_ctrl import GridViewCtrl
from rpa.fastrpa.sap.session import attach_sap
from rpa.ssc.sap.query import export_query, query_selection
from rpa.ssc.sap.utils import init_sap_id


def enter_1071(session: Any) -> None:
    """进入1071"""
    session.findById("wnd[0]").maximize()
    session.findById("wnd[0]/tbar[0]/okcd").text = "/n S_PH0_48000513"
    session.findById("wnd[0]").sendVKey(0)
    session.findById("wnd[1]/usr/cmbDYNP4100-DD_WORKSPACE").setFocus()
    session.findById("wnd[1]/usr/cmbDYNP4100-DD_WORKSPACE").key = "2"
    session.findById("wnd[1]/usr/cmbDYNP4100-DD_USERGROUP").setFocus()
    session.findById("wnd[1]/usr/cmbDYNP4100-DD_USERGROUP").key = "107"
    session.findById("wnd[1]/usr/tblSAPLAQ_INT_FUNCTIONSTCH_FUNCAREAS").getAbsoluteRow(2).selected = -1
    session.findById("wnd[1]/usr/tblSAPLAQ_INT_FUNCTIONSTCH_FUNCAREAS/txtDYNP4100_TC_FUNCAREAS-NAME[0,2]").setFocus()
    session.findById("wnd[1]/usr/tblSAPLAQ_INT_FUNCTIONSTCH_FUNCAREAS/txtDYNP4100_TC_FUNCAREAS-NAME[0,2]").caretPosition = 0
    session.findById("wnd[1]/tbar[0]/btn[0]").press()


def select_1071(session: Any) -> None:
    """勾选1071"""
    enter_1071(session)
    session.findById("wnd[0]/shellcont[1]/shell/shellcont[0]/shell/shellcont[1]/shell[1]").selectItem("          8", "C          3")
    session.findById("wnd[0]/shellcont[1]/shell/shellcont[0]/shell/shellcont[1]/shell[1]").ensureVisibleHorizontalItem("          8", "C          3")
    session.findById("wnd[0]/shellcont[1]/shell/shellcont[0]/shell/shellcont[1]/shell[1]").changeCheckbox("          8", "C          3", -1)
    session.findById("wnd[0]/shellcont[1]/shell/shellcont[0]/shell/shellcont[1]/shell[1]").selectItem("         10", "C          3")
    session.findById("wnd[0]/shellcont[1]/shell/shellcont[0]/shell/shellcont[1]/shell[1]").ensureVisibleHorizontalItem("         10", "C          3")
    session.findById("wnd[0]/shellcont[1]/shell/shellcont[0]/shell/shellcont[1]/shell[1]").changeCheckbox("         10", "C          3", -1)
    session.findById("wnd[0]/shellcont[1]/shell/shellcont[0]/shell/shellcont[1]/shell[1]").selectItem("         11", "C          3")
    session.findById("wnd[0]/shellcont[1]/shell/shellcont[0]/shell/shellcont[1]/shell[1]").ensureVisibleHorizontalItem("         11", "C          3")
    session.findById("wnd[0]/shellcont[1]/shell/shellcont[0]/shell/shellcont[1]/shell[1]").changeCheckbox("         11", "C          3", -1)
    session.findById("wnd[0]/shellcont[1]/shell/shellcont[0]/shell/shellcont[1]/shell[1]").selectItem("         12", "C          3")
    session.findById("wnd[0]/shellcont[1]/shell/shellcont[0]/shell/shellcont[1]/shell[1]").ensureVisibleHorizontalItem("         12", "C          3")
    session.findById("wnd[0]/shellcont[1]/shell/shellcont[0]/shell/shellcont[1]/shell[1]").changeCheckbox("         12", "C          3", -1)
    session.findById("wnd[0]/shellcont[1]/shell/shellcont[0]/shell/shellcont[1]/shell[1]").selectItem("         16", "C          3")
    session.findById("wnd[0]/shellcont[1]/shell/shellcont[0]/shell/shellcont[1]/shell[1]").ensureVisibleHorizontalItem("         16", "C          3")
    session.findById("wnd[0]/shellcont[1]/shell/shellcont[0]/shell/shellcont[1]/shell[1]").changeCheckbox("         16", "C          3", -1)
    session.findById("wnd[0]/shellcont[1]/shell/shellcont[0]/shell/shellcont[1]/shell[1]").expandNode("         24")
    session.findById("wnd[0]/shellcont[1]/shell/shellcont[0]/shell/shellcont[1]/shell[1]").topNode = "          1"
    session.findById("wnd[0]/shellcont[1]/shell/shellcont[0]/shell/shellcont[1]/shell[1]").selectItem("         25", "C          4")
    session.findById("wnd[0]/shellcont[1]/shell/shellcont[0]/shell/shellcont[1]/shell[1]").ensureVisibleHorizontalItem("         25", "C          4")
    session.findById("wnd[0]/shellcont[1]/shell/shellcont[0]/shell/shellcont[1]/shell[1]").changeCheckbox("         25", "C          4", -1)
    session.findById("wnd[0]/shellcont[1]/shell/shellcont[0]/shell/shellcont[1]/shell[1]").selectItem("         26", "C          4")
    session.findById("wnd[0]/shellcont[1]/shell/shellcont[0]/shell/shellcont[1]/shell[1]").ensureVisibleHorizontalItem("         26", "C          4")
    session.findById("wnd[0]/shellcont[1]/shell/shellcont[0]/shell/shellcont[1]/shell[1]").changeCheckbox("         26", "C          4", -1)
    session.findById("wnd[0]/shellcont[1]/shell/shellcont[0]/shell/shellcont[1]/shell[1]").itemContextMenu("         26", "C          4")
    session.findById("wnd[0]/shellcont[1]/shell/shellcont[0]/shell/shellcont[1]/shell[1]").selectContextMenuItem("OUTPUT_ONLYVALUE")
    session.findById("wnd[0]/shellcont[1]/shell/shellcont[0]/shell/shellcont[1]/shell[1]").selectItem("         27", "C          4")
    session.findById("wnd[0]/shellcont[1]/shell/shellcont[0]/shell/shellcont[1]/shell[1]").ensureVisibleHorizontalItem("         27", "C          4")
    session.findById("wnd[0]/shellcont[1]/shell/shellcont[0]/shell/shellcont[1]/shell[1]").topNode = "         13"
    session.findById("wnd[0]/shellcont[1]/shell/shellcont[0]/shell/shellcont[1]/shell[1]").changeCheckbox("         27", "C          4", -1)
    session.findById("wnd[0]/shellcont[1]/shell/shellcont[0]/shell/shellcont[1]/shell[1]").selectItem("         28", "C          4")
    session.findById("wnd[0]/shellcont[1]/shell/shellcont[0]/shell/shellcont[1]/shell[1]").ensureVisibleHorizontalItem("         28", "C          4")
    session.findById("wnd[0]/shellcont[1]/shell/shellcont[0]/shell/shellcont[1]/shell[1]").changeCheckbox("         28", "C          4", -1)
    session.findById("wnd[0]/shellcont[1]/shell/shellcont[0]/shell/shellcont[1]/shell[1]").selectItem("         29", "C          4")
    session.findById("wnd[0]/shellcont[1]/shell/shellcont[0]/shell/shellcont[1]/shell[1]").ensureVisibleHorizontalItem("         29", "C          4")
    session.findById("wnd[0]/shellcont[1]/shell/shellcont[0]/shell/shellcont[1]/shell[1]").changeCheckbox("         29", "C          4", -1)
    session.findById("wnd[0]/shellcont[1]/shell/shellcont[0]/shell/shellcont[1]/shell[1]").selectItem("         30", "C          4")
    session.findById("wnd[0]/shellcont[1]/shell/shellcont[0]/shell/shellcont[1]/shell[1]").ensureVisibleHorizontalItem("         30", "C          4")
    session.findById("wnd[0]/shellcont[1]/shell/shellcont[0]/shell/shellcont[1]/shell[1]").changeCheckbox("         30", "C          4", -1)
    session.findById("wnd[0]/shellcont[1]/shell/shellcont[0]/shell/shellcont[1]/shell[1]").selectItem("         31", "C          4")
    session.findById("wnd[0]/shellcont[1]/shell/shellcont[0]/shell/shellcont[1]/shell[1]").ensureVisibleHorizontalItem("         31", "C          4")
    session.findById("wnd[0]/shellcont[1]/shell/shellcont[0]/shell/shellcont[1]/shell[1]").changeCheckbox("         31", "C          4", -1)
    session.findById("wnd[0]/shellcont[1]/shell/shellcont[0]/shell/shellcont[1]/shell[1]").selectItem("         32", "C          4")
    session.findById("wnd[0]/shellcont[1]/shell/shellcont[0]/shell/shellcont[1]/shell[1]").ensureVisibleHorizontalItem("         32", "C          4")
    session.findById("wnd[0]/shellcont[1]/shell/shellcont[0]/shell/shellcont[1]/shell[1]").changeCheckbox("         32", "C          4", -1)
    session.findById("wnd[0]/shellcont[1]/shell/shellcont[0]/shell/shellcont[1]/shell[1]").expandNode("        156")
    session.findById("wnd[0]/shellcont[1]/shell/shellcont[0]/shell/shellcont[1]/shell[1]").topNode = "         12"
    session.findById("wnd[0]/shellcont[1]/shell/shellcont[0]/shell/shellcont[1]/shell[1]").selectItem("        160", "C          4")
    session.findById("wnd[0]/shellcont[1]/shell/shellcont[0]/shell/shellcont[1]/shell[1]").ensureVisibleHorizontalItem("        160", "C          4")
    session.findById("wnd[0]/shellcont[1]/shell/shellcont[0]/shell/shellcont[1]/shell[1]").topNode = "         18"
    session.findById("wnd[0]/shellcont[1]/shell/shellcont[0]/shell/shellcont[1]/shell[1]").changeCheckbox("        160", "C          4", -1)
    session.findById("wnd[0]/shellcont[1]/shell/shellcont[0]/shell/shellcont[1]/shell[1]").selectItem("        161", "C          4")
    session.findById("wnd[0]/shellcont[1]/shell/shellcont[0]/shell/shellcont[1]/shell[1]").ensureVisibleHorizontalItem("        161", "C          4")
    session.findById("wnd[0]/shellcont[1]/shell/shellcont[0]/shell/shellcont[1]/shell[1]").changeCheckbox("        161", "C          4", -1)
    session.findById("wnd[0]/shellcont[1]/shell/shellcont[0]/shell/shellcont[1]/shell[1]").selectItem("        162", "C          4")
    session.findById("wnd[0]/shellcont[1]/shell/shellcont[0]/shell/shellcont[1]/shell[1]").ensureVisibleHorizontalItem("        162", "C          4")
    session.findById("wnd[0]/shellcont[1]/shell/shellcont[0]/shell/shellcont[1]/shell[1]").changeCheckbox("        162", "C          4", -1)
    session.findById("wnd[0]/shellcont[1]/shell/shellcont[0]/shell/shellcont[1]/shell[1]").expandNode("         66")
    session.findById("wnd[0]/shellcont[1]/shell/shellcont[0]/shell/shellcont[1]/shell[1]").topNode = "         18"
    session.findById("wnd[0]/shellcont[1]/shell/shellcont[0]/shell/shellcont[1]/shell[1]").selectItem("         69", "C          4")
    session.findById("wnd[0]/shellcont[1]/shell/shellcont[0]/shell/shellcont[1]/shell[1]").ensureVisibleHorizontalItem("         69", "C          4")
    session.findById("wnd[0]/shellcont[1]/shell/shellcont[0]/shell/shellcont[1]/shell[1]").changeCheckbox("         69", "C          4", -1)
    session.findById("wnd[0]/shellcont[1]/shell/shellcont[0]/shell/shellcont[1]/shell[1]").selectItem("         70", "C          4")
    session.findById("wnd[0]/shellcont[1]/shell/shellcont[0]/shell/shellcont[1]/shell[1]").ensureVisibleHorizontalItem("         70", "C          4")
    session.findById("wnd[0]/shellcont[1]/shell/shellcont[0]/shell/shellcont[1]/shell[1]").changeCheckbox("         70", "C          4", -1)
    session.findById("wnd[0]/shellcont[1]/shell/shellcont[0]/shell/shellcont[1]/shell[1]").selectItem("         71", "C          4")
    session.findById("wnd[0]/shellcont[1]/shell/shellcont[0]/shell/shellcont[1]/shell[1]").ensureVisibleHorizontalItem("         71", "C          4")
    session.findById("wnd[0]/shellcont[1]/shell/shellcont[0]/shell/shellcont[1]/shell[1]").changeCheckbox("         71", "C          4", -1)
    session.findById("wnd[0]/shellcont[1]/shell/shellcont[0]/shell/shellcont[1]/shell[1]").selectItem("         72", "C          4")
    session.findById("wnd[0]/shellcont[1]/shell/shellcont[0]/shell/shellcont[1]/shell[1]").ensureVisibleHorizontalItem("         72", "C          4")
    session.findById("wnd[0]/shellcont[1]/shell/shellcont[0]/shell/shellcont[1]/shell[1]").changeCheckbox("         72", "C          4", -1)
    session.findById("wnd[0]/shellcont[1]/shell/shellcont[0]/shell/shellcont[1]/shell[1]").topNode = "         69"
    session.findById("wnd[0]").maximize()
    session.findById("wnd[0]/shellcont[1]/shell/shellcont[0]/shell/shellcont[1]/shell[1]").selectItem("         92", "C          4")
    session.findById("wnd[0]/shellcont[1]/shell/shellcont[0]/shell/shellcont[1]/shell[1]").ensureVisibleHorizontalItem("         92", "C          4")
    session.findById("wnd[0]/shellcont[1]/shell/shellcont[0]/shell/shellcont[1]/shell[1]").changeCheckbox("         92", "C          4", -1)
    session.findById("wnd[0]/shellcont[1]/shell/shellcont[0]/shell/shellcont[1]/shell[1]").itemContextMenu("         92", "C          4")
    session.findById("wnd[0]/shellcont[1]/shell/shellcont[0]/shell/shellcont[1]/shell[1]").selectContextMenuItem("OUTPUT_ONLYVALUE")
    session.findById("wnd[0]/shellcont[1]/shell/shellcont[0]/shell/shellcont[1]/shell[1]").selectItem("         73", "C          4")
    session.findById("wnd[0]/shellcont[1]/shell/shellcont[0]/shell/shellcont[1]/shell[1]").ensureVisibleHorizontalItem("         73", "C          4")
    session.findById("wnd[0]/shellcont[1]/shell/shellcont[0]/shell/shellcont[1]/shell[1]").changeCheckbox("         73", "C          4", -1)
    session.findById("wnd[0]/shellcont[1]/shell/shellcont[0]/shell/shellcont[1]/shell[1]").itemContextMenu("         73", "C          4")
    session.findById("wnd[0]/shellcont[1]/shell/shellcont[0]/shell/shellcont[1]/shell[1]").selectContextMenuItem("OUTPUT_BOTH")
    session.findById("wnd[0]/shellcont[1]/shell/shellcont[0]/shell/shellcont[1]/shell[1]").selectItem("         74", "C          4")
    session.findById("wnd[0]/shellcont[1]/shell/shellcont[0]/shell/shellcont[1]/shell[1]").ensureVisibleHorizontalItem("         74", "C          4")
    session.findById("wnd[0]/shellcont[1]/shell/shellcont[0]/shell/shellcont[1]/shell[1]").changeCheckbox("         74", "C          4", -1)
    session.findById("wnd[0]/shellcont[1]/shell/shellcont[0]/shell/shellcont[1]/shell[1]").itemContextMenu("         74", "C          4")
    session.findById("wnd[0]/shellcont[1]/shell/shellcont[0]/shell/shellcont[1]/shell[1]").selectContextMenuItem("OUTPUT_BOTH")
    session.findById("wnd[0]/shellcont[1]/shell/shellcont[0]/shell/shellcont[1]/shell[1]").selectItem("         81", "C          4")
    session.findById("wnd[0]/shellcont[1]/shell/shellcont[0]/shell/shellcont[1]/shell[1]").ensureVisibleHorizontalItem("         81", "C          4")
    session.findById("wnd[0]/shellcont[1]/shell/shellcont[0]/shell/shellcont[1]/shell[1]").changeCheckbox("         81", "C          4", -1)
    session.findById("wnd[0]/shellcont[1]/shell/shellcont[0]/shell/shellcont[1]/shell[1]").itemContextMenu("         81", "C          4")
    session.findById("wnd[0]/shellcont[1]/shell/shellcont[0]/shell/shellcont[1]/shell[1]").selectContextMenuItem("OUTPUT_BOTH")
    session.findById("wnd[0]/shellcont[1]/shell/shellcont[0]/shell/shellcont[1]/shell[1]").selectItem("         82", "C          4")
    session.findById("wnd[0]/shellcont[1]/shell/shellcont[0]/shell/shellcont[1]/shell[1]").ensureVisibleHorizontalItem("         82", "C          4")
    session.findById("wnd[0]/shellcont[1]/shell/shellcont[0]/shell/shellcont[1]/shell[1]").changeCheckbox("         82", "C          4", -1)
    session.findById("wnd[0]/shellcont[1]/shell/shellcont[0]/shell/shellcont[1]/shell[1]").itemContextMenu("         82", "C          4")
    session.findById("wnd[0]/shellcont[1]/shell/shellcont[0]/shell/shellcont[1]/shell[1]").selectContextMenuItem("OUTPUT_BOTH")
    session.findById("wnd[0]/shellcont[1]/shell/shellcont[0]/shell/shellcont[1]/shell[1]").selectItem("         83", "C          4")
    session.findById("wnd[0]/shellcont[1]/shell/shellcont[0]/shell/shellcont[1]/shell[1]").ensureVisibleHorizontalItem("         83", "C          4")
    session.findById("wnd[0]/shellcont[1]/shell/shellcont[0]/shell/shellcont[1]/shell[1]").changeCheckbox("         83", "C          4", -1)
    session.findById("wnd[0]/shellcont[1]/shell/shellcont[0]/shell/shellcont[1]/shell[1]").selectItem("         76", "C          4")
    session.findById("wnd[0]/shellcont[1]/shell/shellcont[0]/shell/shellcont[1]/shell[1]").ensureVisibleHorizontalItem("         76", "C          4")
    session.findById("wnd[0]/shellcont[1]/shell/shellcont[0]/shell/shellcont[1]/shell[1]").changeCheckbox("         76", "C          4", -1)
    session.findById("wnd[0]/shellcont[1]/shell/shellcont[0]/shell/shellcont[1]/shell[1]").itemContextMenu("         76", "C          4")
    session.findById("wnd[0]/shellcont[1]/shell/shellcont[0]/shell/shellcont[1]/shell[1]").selectContextMenuItem("OUTPUT_BOTH")
    session.findById("wnd[0]/shellcont[1]/shell/shellcont[0]/shell/shellcont[1]/shell[1]").selectItem("         77", "C          4")
    session.findById("wnd[0]/shellcont[1]/shell/shellcont[0]/shell/shellcont[1]/shell[1]").ensureVisibleHorizontalItem("         77", "C          4")
    session.findById("wnd[0]/shellcont[1]/shell/shellcont[0]/shell/shellcont[1]/shell[1]").changeCheckbox("         77", "C          4", -1)
    session.findById("wnd[0]/shellcont[1]/shell/shellcont[0]/shell/shellcont[1]/shell[1]").itemContextMenu("         77", "C          4")
    session.findById("wnd[0]/shellcont[1]/shell/shellcont[0]/shell/shellcont[1]/shell[1]").selectContextMenuItem("OUTPUT_ONLYVALUE")
    session.findById("wnd[0]/shellcont[1]/shell/shellcont[0]/shell/shellcont[1]/shell[1]").selectItem("         80", "C          4")
    session.findById("wnd[0]/shellcont[1]/shell/shellcont[0]/shell/shellcont[1]/shell[1]").ensureVisibleHorizontalItem("         80", "C          4")
    session.findById("wnd[0]/shellcont[1]/shell/shellcont[0]/shell/shellcont[1]/shell[1]").changeCheckbox("         80", "C          4", -1)
    session.findById("wnd[0]/shellcont[1]/shell/shellcont[0]/shell/shellcont[1]/shell[1]").itemContextMenu("         80", "C          4")
    session.findById("wnd[0]/shellcont[1]/shell/shellcont[0]/shell/shellcont[1]/shell[1]").selectItem("         88", "C          4")
    session.findById("wnd[0]/shellcont[1]/shell/shellcont[0]/shell/shellcont[1]/shell[1]").ensureVisibleHorizontalItem("         88", "C          4")
    session.findById("wnd[0]/shellcont[1]/shell/shellcont[0]/shell/shellcont[1]/shell[1]").changeCheckbox("         88", "C          4", -1)
    session.findById("wnd[0]/shellcont[1]/shell/shellcont[0]/shell/shellcont[1]/shell[1]").selectItem("         89", "C          4")
    session.findById("wnd[0]/shellcont[1]/shell/shellcont[0]/shell/shellcont[1]/shell[1]").ensureVisibleHorizontalItem("         89", "C          4")
    session.findById("wnd[0]/shellcont[1]/shell/shellcont[0]/shell/shellcont[1]/shell[1]").changeCheckbox("         89", "C          4", -1)
    session.findById("wnd[0]/shellcont[1]/shell/shellcont[0]/shell/shellcont[1]/shell[1]").selectItem("         90", "C          4")
    session.findById("wnd[0]/shellcont[1]/shell/shellcont[0]/shell/shellcont[1]/shell[1]").ensureVisibleHorizontalItem("         90", "C          4")
    session.findById("wnd[0]/shellcont[1]/shell/shellcont[0]/shell/shellcont[1]/shell[1]").changeCheckbox("         90", "C          4", -1)
    session.findById("wnd[0]/shellcont[1]/shell/shellcont[0]/shell/shellcont[1]/shell[1]").selectItem("         84", "C          4")
    session.findById("wnd[0]/shellcont[1]/shell/shellcont[0]/shell/shellcont[1]/shell[1]").ensureVisibleHorizontalItem("         84", "C          4")
    session.findById("wnd[0]/shellcont[1]/shell/shellcont[0]/shell/shellcont[1]/shell[1]").changeCheckbox("         84", "C          4", -1)
    session.findById("wnd[0]/shellcont[1]/shell/shellcont[0]/shell/shellcont[1]/shell[1]").selectItem("         85", "C          4")
    session.findById("wnd[0]/shellcont[1]/shell/shellcont[0]/shell/shellcont[1]/shell[1]").ensureVisibleHorizontalItem("         85", "C          4")
    session.findById("wnd[0]/shellcont[1]/shell/shellcont[0]/shell/shellcont[1]/shell[1]").changeCheckbox("         85", "C          4", -1)
    session.findById("wnd[0]/shellcont[1]/shell/shellcont[0]/shell/shellcont[1]/shell[1]").selectItem("         86", "C          4")
    session.findById("wnd[0]/shellcont[1]/shell/shellcont[0]/shell/shellcont[1]/shell[1]").ensureVisibleHorizontalItem("         86", "C          4")
    session.findById("wnd[0]/shellcont[1]/shell/shellcont[0]/shell/shellcont[1]/shell[1]").changeCheckbox("         86", "C          4", -1)
    session.findById("wnd[0]/shellcont[1]/shell/shellcont[0]/shell/shellcont[1]/shell[1]").selectItem("         87", "C          4")
    session.findById("wnd[0]/shellcont[1]/shell/shellcont[0]/shell/shellcont[1]/shell[1]").ensureVisibleHorizontalItem("         87", "C          4")
    session.findById("wnd[0]/shellcont[1]/shell/shellcont[0]/shell/shellcont[1]/shell[1]").changeCheckbox("         87", "C          4", -1)
    session.findById("wnd[0]/shellcont[1]/shell/shellcont[0]/shell/shellcont[1]/shell[1]").expandNode("        134")
    session.findById("wnd[0]/shellcont[1]/shell/shellcont[0]/shell/shellcont[1]/shell[1]").topNode = "         74"
    session.findById("wnd[0]/shellcont[1]/shell/shellcont[0]/shell/shellcont[1]/shell[1]").selectItem("        137", "C          4")
    session.findById("wnd[0]/shellcont[1]/shell/shellcont[0]/shell/shellcont[1]/shell[1]").ensureVisibleHorizontalItem("        137", "C          4")
    session.findById("wnd[0]/shellcont[1]/shell/shellcont[0]/shell/shellcont[1]/shell[1]").changeCheckbox("        137", "C          4", -1)
    session.findById("wnd[0]/shellcont[1]/shell/shellcont[0]/shell/shellcont[1]/shell[1]").selectItem("        138", "C          4")
    session.findById("wnd[0]/shellcont[1]/shell/shellcont[0]/shell/shellcont[1]/shell[1]").ensureVisibleHorizontalItem("        138", "C          4")
    session.findById("wnd[0]/shellcont[1]/shell/shellcont[0]/shell/shellcont[1]/shell[1]").changeCheckbox("        138", "C          4", -1)
    session.findById("wnd[0]/shellcont[1]/shell/shellcont[0]/shell/shellcont[1]/shell[1]").selectItem("        139", "C          4")
    session.findById("wnd[0]/shellcont[1]/shell/shellcont[0]/shell/shellcont[1]/shell[1]").ensureVisibleHorizontalItem("        139", "C          4")
    session.findById("wnd[0]/shellcont[1]/shell/shellcont[0]/shell/shellcont[1]/shell[1]").changeCheckbox("        139", "C          4", -1)
    session.findById("wnd[0]/shellcont[1]/shell/shellcont[0]/shell/shellcont[1]/shell[1]").selectItem("        140", "C          4")
    session.findById("wnd[0]/shellcont[1]/shell/shellcont[0]/shell/shellcont[1]/shell[1]").ensureVisibleHorizontalItem("        140", "C          4")
    session.findById("wnd[0]/shellcont[1]/shell/shellcont[0]/shell/shellcont[1]/shell[1]").topNode = "         83"
    session.findById("wnd[0]/shellcont[1]/shell/shellcont[0]/shell/shellcont[1]/shell[1]").changeCheckbox("        140", "C          4", -1)
    session.findById("wnd[0]/shellcont[1]/shell/shellcont[0]/shell/shellcont[1]/shell[1]").selectItem("        142", "C          4")
    session.findById("wnd[0]/shellcont[1]/shell/shellcont[0]/shell/shellcont[1]/shell[1]").ensureVisibleHorizontalItem("        142", "C          4")
    session.findById("wnd[0]/shellcont[1]/shell/shellcont[0]/shell/shellcont[1]/shell[1]").changeCheckbox("        142", "C          4", -1)
    session.findById("wnd[0]/shellcont[1]/shell/shellcont[0]/shell/shellcont[1]/shell[1]").itemContextMenu("        142", "C          4")
    session.findById("wnd[0]/shellcont[1]/shell/shellcont[0]/shell/shellcont[1]/shell[1]").selectContextMenuItem("OUTPUT_ONLYVALUE")
    session.findById("wnd[0]/shellcont[1]/shell/shellcont[0]/shell/shellcont[1]/shell[1]").selectItem("        143", "C          4")
    session.findById("wnd[0]/shellcont[1]/shell/shellcont[0]/shell/shellcont[1]/shell[1]").ensureVisibleHorizontalItem("        143", "C          4")
    session.findById("wnd[0]/shellcont[1]/shell/shellcont[0]/shell/shellcont[1]/shell[1]").changeCheckbox("        143", "C          4", -1)
    session.findById("wnd[0]/shellcont[1]/shell/shellcont[0]/shell/shellcont[1]/shell[1]").itemContextMenu("        143", "C          4")
    session.findById("wnd[0]/shellcont[1]/shell/shellcont[0]/shell/shellcont[1]/shell[1]").selectContextMenuItem("OUTPUT_ONLYVALUE")
    session.findById("wnd[0]/shellcont[1]/shell/shellcont[0]/shell/shellcont[1]/shell[1]").selectItem("        144", "C          4")
    session.findById("wnd[0]/shellcont[1]/shell/shellcont[0]/shell/shellcont[1]/shell[1]").ensureVisibleHorizontalItem("        144", "C          4")
    session.findById("wnd[0]/shellcont[1]/shell/shellcont[0]/shell/shellcont[1]/shell[1]").changeCheckbox("        144", "C          4", -1)
    session.findById("wnd[0]/shellcont[1]/shell/shellcont[0]/shell/shellcont[1]/shell[1]").itemContextMenu("        144", "C          4")
    session.findById("wnd[0]/shellcont[1]/shell/shellcont[0]/shell/shellcont[1]/shell[1]").selectContextMenuItem("OUTPUT_ONLYVALUE")
    session.findById("wnd[0]/shellcont[1]/shell/shellcont[0]/shell/shellcont[1]/shell[1]").expandNode("        124")
    session.findById("wnd[0]/shellcont[1]/shell/shellcont[0]/shell/shellcont[1]/shell[1]").topNode = "         83"
    session.findById("wnd[0]/shellcont[1]/shell/shellcont[0]/shell/shellcont[1]/shell[1]").selectItem("        127", "C          4")
    session.findById("wnd[0]/shellcont[1]/shell/shellcont[0]/shell/shellcont[1]/shell[1]").ensureVisibleHorizontalItem("        127", "C          4")
    session.findById("wnd[0]/shellcont[1]/shell/shellcont[0]/shell/shellcont[1]/shell[1]").changeCheckbox("        127", "C          4", -1)
    session.findById("wnd[0]/shellcont[1]/shell/shellcont[0]/shell/shellcont[1]/shell[1]").selectItem("        128", "C          4")
    session.findById("wnd[0]/shellcont[1]/shell/shellcont[0]/shell/shellcont[1]/shell[1]").ensureVisibleHorizontalItem("        128", "C          4")
    session.findById("wnd[0]/shellcont[1]/shell/shellcont[0]/shell/shellcont[1]/shell[1]").changeCheckbox("        128", "C          4", -1)
    session.findById("wnd[0]/shellcont[1]/shell/shellcont[0]/shell/shellcont[1]/shell[1]").selectItem("        129", "C          4")
    session.findById("wnd[0]/shellcont[1]/shell/shellcont[0]/shell/shellcont[1]/shell[1]").ensureVisibleHorizontalItem("        129", "C          4")
    session.findById("wnd[0]/shellcont[1]/shell/shellcont[0]/shell/shellcont[1]/shell[1]").changeCheckbox("        129", "C          4", -1)
    session.findById("wnd[0]/shellcont[1]/shell/shellcont[0]/shell/shellcont[1]/shell[1]").selectItem("        130", "C          4")
    session.findById("wnd[0]/shellcont[1]/shell/shellcont[0]/shell/shellcont[1]/shell[1]").ensureVisibleHorizontalItem("        130", "C          4")
    session.findById("wnd[0]/shellcont[1]/shell/shellcont[0]/shell/shellcont[1]/shell[1]").changeCheckbox("        130", "C          4", -1)
    session.findById("wnd[0]/shellcont[1]/shell/shellcont[0]/shell/shellcont[1]/shell[1]").selectItem("        131", "C          4")
    session.findById("wnd[0]/shellcont[1]/shell/shellcont[0]/shell/shellcont[1]/shell[1]").ensureVisibleHorizontalItem("        131", "C          4")
    session.findById("wnd[0]/shellcont[1]/shell/shellcont[0]/shell/shellcont[1]/shell[1]").changeCheckbox("        131", "C          4", -1)
    session.findById("wnd[0]/shellcont[1]/shell/shellcont[0]/shell/shellcont[1]/shell[1]").itemContextMenu("        131", "C          4")
    session.findById("wnd[0]/shellcont[1]/shell/shellcont[0]/shell/shellcont[1]/shell[1]").selectItem("        132", "C          4")
    session.findById("wnd[0]/shellcont[1]/shell/shellcont[0]/shell/shellcont[1]/shell[1]").ensureVisibleHorizontalItem("        132", "C          4")
    session.findById("wnd[0]/shellcont[1]/shell/shellcont[0]/shell/shellcont[1]/shell[1]").changeCheckbox("        132", "C          4", -1)
    session.findById("wnd[0]/shellcont[1]/shell/shellcont[0]/shell/shellcont[1]/shell[1]").selectItem("        133", "C          4")
    session.findById("wnd[0]/shellcont[1]/shell/shellcont[0]/shell/shellcont[1]/shell[1]").ensureVisibleHorizontalItem("        133", "C          4")
    session.findById("wnd[0]/shellcont[1]/shell/shellcont[0]/shell/shellcont[1]/shell[1]").changeCheckbox("        133", "C          4", -1)
    session.findById("wnd[0]/usr/subSUB_MAIN:SAPLAQ_ADHOC:0212/subSUB_SELECTION:SAPLAQ_ADHOC:0310/cntlSEL_DEF_CONTAINER/shellcont/shell").modifyCell(0, "LOW", "1")  # 默认值(后面再填充)
    session.findById("wnd[0]/usr/subSUB_MAIN:SAPLAQ_ADHOC:0212/subSUB_SELECTION:SAPLAQ_ADHOC:0310/cntlSEL_DEF_CONTAINER/shellcont/shell").modifyCell(1, "LOW", "1")
    session.findById("wnd[0]/usr/subSUB_MAIN:SAPLAQ_ADHOC:0212/subSUB_SELECTION:SAPLAQ_ADHOC:0310/cntlSEL_DEF_CONTAINER/shellcont/shell").modifyCell(2, "LOW", "S")
    session.findById("wnd[0]/usr/subSUB_MAIN:SAPLAQ_ADHOC:0212/subSUB_SELECTION:SAPLAQ_ADHOC:0310/cntlSEL_DEF_CONTAINER/shellcont/shell").modifyCell(3, "LOW", "01")
    session.findById("wnd[0]/usr/subSUB_MAIN:SAPLAQ_ADHOC:0212/subSUB_SELECTION:SAPLAQ_ADHOC:0310/cntlSEL_DEF_CONTAINER/shellcont/shell").modifyCell(4, "LOW", "O-S-P")
    session.findById("wnd[0]/usr/subSUB_MAIN:SAPLAQ_ADHOC:0212/subSUB_SELECTION:SAPLAQ_ADHOC:0310/cntlSEL_DEF_CONTAINER/shellcont/shell").setCurrentCell(4, "LOW")


def fill_1071(session: Any, job_ids: List[str], key_date: str) -> None:
    """填充1071"""
    pyperclip.copy('\r\n'.join(job_ids))  # 复制到剪切板
    grid_view_ctrl_id = 'wnd[0]/usr/subSUB_MAIN:SAPLAQ_ADHOC:0212/subSUB_SELECTION:SAPLAQ_ADHOC:0310/cntlSEL_DEF_CONTAINER/shellcont/shell'
    grid_view_ctrl = GridViewCtrl(session, grid_view_ctrl_id)
    grid_view_ctrl['字段名称'].find('对象标识').same_line('更多值 ').press_button()
    session.findById("wnd[1]/tbar[0]/btn[16]").press()
    session.findById("wnd[1]/tbar[0]/btn[24]").press()  # 粘贴
    session.findById("wnd[1]/tbar[0]/btn[8]").press()
    session.findById("wnd[0]/usr/subSUB_MAIN:SAPLAQ_ADHOC:0212/subSUB_APPLICATION:SAPLHR_QUERY_APPL_AREA:0122/subSUB:SAPLHR_QUERY_APPL_AREA:0121/btnDYNP121-EVALUATION_PERIOD_TEXT").press()
    session.findById("wnd[0]/usr/subSUB_MAIN:SAPLAQ_ADHOC:0212/subSUB_APPLICATION:SAPLHR_QUERY_APPL_AREA:0122/subSUB:SAPLHR_QUERY_APPL_AREA:0120/cmbDD_DATE").setFocus()
    session.findById("wnd[0]/usr/subSUB_MAIN:SAPLAQ_ADHOC:0212/subSUB_APPLICATION:SAPLHR_QUERY_APPL_AREA:0122/subSUB:SAPLHR_QUERY_APPL_AREA:0120/cmbDD_DATE").key = "8"
    session.findById("wnd[0]/usr/subSUB_MAIN:SAPLAQ_ADHOC:0212/subSUB_APPLICATION:SAPLHR_QUERY_APPL_AREA:0122/subSUB:SAPLHR_QUERY_APPL_AREA:0120/ctxtG_APPL_AREA-BEGDA").text = key_date
    session.findById("wnd[0]/usr/subSUB_MAIN:SAPLAQ_ADHOC:0212/subSUB_APPLICATION:SAPLHR_QUERY_APPL_AREA:0122/subSUB:SAPLHR_QUERY_APPL_AREA:0120/ctxtG_APPL_AREA-ENDDA").text = "99991231"
    session.findById("wnd[0]/usr/subSUB_MAIN:SAPLAQ_ADHOC:0212/subSUB_APPLICATION:SAPLHR_QUERY_APPL_AREA:0122/subSUB:SAPLHR_QUERY_APPL_AREA:0120/ctxtG_APPL_AREA-ENDDA").setFocus()
    session.findById("wnd[0]/usr/subSUB_MAIN:SAPLAQ_ADHOC:0212/subSUB_APPLICATION:SAPLHR_QUERY_APPL_AREA:0122/subSUB:SAPLHR_QUERY_APPL_AREA:0120/ctxtG_APPL_AREA-ENDDA").caretPosition = 8
    session.findById("wnd[0]/tbar[1]/btn[8]").press()


HEADER_IDS: List[str] = ['VALUE1', 'VALUE2', 'VALUE3', 'VALUE4', 'VALUE5', 'VALUE6', 'VALUE7', 'VALUE8', 'VALUE126', 'VALUE127', 'TEXT128', 'VALUE41', 'VALUE42',
                         'VALUE43', 'VALUE44', 'VALUE64', 'VALUE45', 'TEXT45', 'VALUE46', 'TEXT46', 'VALUE53', 'TEXT53', 'VALUE54', 'TEXT54', 'VALUE55', 'VALUE48',
                         'TEXT48', 'VALUE49', 'TEXT52', 'TEXT60', 'TEXT61', 'TEXT62', 'TEXT56', 'TEXT57', 'TEXT58', 'TEXT59', 'VALUE105', 'VALUE106', 'VALUE107',
                         'VALUE108', 'VALUE110', 'VALUE111', 'VALUE112', 'VALUE96', 'VALUE97', 'VALUE98', 'VALUE99', 'TEXT100', 'TEXT101', 'TEXT102']


def export_1071(session: Any, job_ids: List[str], key_date: str) -> AdTable:
    """导出1071
       ------------------
       入参：
       session: SAP SESSION，如为None，则新打开SAP
       job_ids: 岗位编码
       key_date: 关键日期
       ------------------
       返回值：
       AdTable，可通过.wb访问Workbook，或.ws访问Worksheet
       ------------------
       调用样例：
       _table: AdTable = export_1071(None, ['04613370'], '20200301')
       _table.filename = '模板_1071'
       _table.save_to('x:/') # 保存模板至x:/下
    """
    logging.info(f'导出组合逻辑查询1071，岗位编号：{job_ids}，关键日期：{key_date}')
    if all(map(lambda v: v == '', job_ids)) is True:
        raise Exception('岗位编号全为空值，请检查模板岗位编号是否填充')
    if session is None:
        session = attach_sap()
    elif isinstance(session, str):
        session = attach_sap(session)
    enter_1071(session)  # 进入1071信息集查询屏
    query_selection(session, 'RPA_HR_1071', select_1071, HEADER_IDS)  # 勾选1071选项
    fill_1071(session, job_ids, key_date)  # 填入员工编号和关键日期，并查询
    _table: AdTable = export_query(session, template_file=f'{TEMPLATE_DIR}/模板_1071.xlsx', query_name='RPA_HR_1071')
    _table['A'].apply(init_sap_id)
    # _table.filename = '1071'
    return _table


# example
if __name__ == '__main__':
    _table: AdTable = export_1071(None, ['04613370'], '20200301')
    _table.save_to('x:/')
