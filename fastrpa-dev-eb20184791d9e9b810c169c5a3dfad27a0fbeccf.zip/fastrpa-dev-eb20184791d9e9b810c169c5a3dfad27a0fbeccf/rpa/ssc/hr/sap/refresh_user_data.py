import datetime
import logging
import traceback
from pathlib import Path
from typing import List, Optional

import pyperclip
import rpa.config
from rpa.fastrpa.sap.session import attach_sap, SapSession
from rpa.ssc.hr.orm.session import DbSession
from rpa.ssc.hr.orm.tb_hr_sap_refresh_user_data import \
    TB_HR_SAP_REFRESH_USER_DATA
from rpa.ssc.hr.sap.export_107_c91 import export_107_c91
from rpa.ssc.sap.utils import init_sap_id


def _refresh_user_data(sap_session: Optional[SapSession] = None) -> bool:
    """结构化刷新(业务人员SAP账号)"""
    if sap_session is None:
        sap_session = attach_sap('login_tx')
    try:
        log_file = Path(rpa.config.LOG_FILENAME).relative_to('d:').as_posix()
    except Exception:
        log_file = ''
    record = TB_HR_SAP_REFRESH_USER_DATA(rpa_id=rpa.config.RPA_ID,
                                         staff_group=rpa.config.STAFF_GROUP,
                                         staff_id=rpa.config.STAFF_ID,
                                         staff_name=rpa.config.STAFF_NAME,
                                         sr_no=rpa.config.SR_NO,
                                         busi_type=rpa.config.SUBTICKET_TYPE,
                                         log_file=log_file)
    record_id = 0
    with DbSession() as db_session:
        db_session.add(record)
        db_session.commit()
        record_id = record.id
    is_succ = True
    remark = ''  # 记录错误原因（结构化刷新成功则为空）
    begintime = datetime.datetime.now()  # 登录SAP时间不计入结构化刷新耗时
    try:
        sap_session.findById("wnd[0]").maximize()
        sap_session.findById("wnd[0]/tbar[0]/okcd").text = "/n zhrau008"
        sap_session.findById("wnd[0]").sendVKey(0)
        wnd_0 = sap_session.findById("wnd[0]")
        sap_session.findById("wnd[0]/tbar[1]/btn[45]").press()  # 本地文件
        sap_session.findById("wnd[1]/usr/subSUBSCREEN_STEPLOOP:SAPLSPO5:0150/sub:SAPLSPO5:0150/radSPOPLI-SELFLAG[4,0]").select()  # 剪切板
        sap_session.findById("wnd[1]/tbar[0]/btn[0]").press()
        sap_html_control_text = pyperclip.paste()
        if '重新生成结构权限' in wnd_0.Text and '用户已更新' in sap_html_control_text:
            is_succ = True
        else:
            is_succ = False
    except Exception as e:
        is_succ = False
        remark = str(e)
    endtime = datetime.datetime.now()
    dur = endtime - begintime  # 执行时长（秒）
    with DbSession() as db_session:
        res = db_session.query(TB_HR_SAP_REFRESH_USER_DATA).filter(TB_HR_SAP_REFRESH_USER_DATA.id == record_id)
        res.update({'dur_seconds': dur.seconds, 'is_succ': is_succ, 'remark': remark})
    return is_succ


def refresh_user_data(session: Optional[SapSession] = None, job_ids: List[str] = [], key_date: str = '99991231', repeat_times: int = 3) -> bool:
    """结构化刷新(业务人员SAP账号)"""
    logging.info('登录业务人员账号执行结构化刷新')
    if repeat_times < 1:  # 重试次数为0
        return False
    job_ids = [init_sap_id(job_id) for job_id in job_ids]
    try:
        is_succ = _refresh_user_data(session)
        if is_succ is False:
            logging.error('结构化刷新失败')
            raise Exception('结构化刷新失败')
        elif job_ids:
            session = attach_sap('login_tx')  # 用个人账号导出
            try:
                lt = export_107_c91(session, job_ids, key_date)
                _job_ids: List[str] = lt['A'].values
            except Exception as e:
                logging.error(e)
                _job_ids = []
            _job_ids = [init_sap_id(_job_id) for _job_id in _job_ids]
            missing_job_ids = [job_id for job_id in job_ids if job_id not in _job_ids]
            if missing_job_ids:
                logging.error(f'结构化刷新以下岗位未能正常刷新出：{missing_job_ids}')
                raise Exception('结构化刷新未能刷新全部岗位')
        return True
    except Exception as e:
        logging.error(e)
        logging.error(f"异常原因: {traceback.format_exc()}")
        return refresh_user_data(session, job_ids, key_date=key_date, repeat_times=repeat_times - 1)


if __name__ == '__main__':
    from rpa.fastrpa.log import config
    config()
    rpa.config.FSO_USERNAME = 'changsh55'
    rpa.config.SAP_FUNJ = 'FUNJ0036'
    refresh_user_data(job_ids=['00000012', '00000015', '00000013'])
