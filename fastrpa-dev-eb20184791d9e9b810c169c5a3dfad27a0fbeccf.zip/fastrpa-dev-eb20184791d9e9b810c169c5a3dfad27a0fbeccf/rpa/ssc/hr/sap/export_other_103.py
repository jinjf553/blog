"""导出组合逻辑查询103"""
from typing import Any, List

from rpa.config import TEMPLATE_DIR
from rpa.fastrpa.adtable import AdTable
from rpa.fastrpa.log import config
from rpa.fastrpa.sap.session import attach_sap
from rpa.ssc.hr.sap.export_103 import enter_103, fill_103
from rpa.ssc.hr.sap.select_options import (LI_TUI_XIU_HEADER,
                                           LI_TUI_XIU_JIAN_CE_HEADER,
                                           LI_ZHI_HEADER, LI_ZHI_HEADER2,
                                           LI_ZHI_HEADER3, NEI_TUI_HEADER,
                                           select_103_li_tui_xiu,
                                           select_103_li_tui_xiu_jian_ce,
                                           select_103_li_zhi,
                                           select_103_nei_tui,
                                           select_li_zhi_1032,
                                           select_li_zhi_1033)
from rpa.ssc.sap.query import export_query, query_selection
from rpa.ssc.sap.utils import init_sap_id


def export_103_li_tui_xiu_jian_ce(session: Any, staff_ids: List[str], key_date: str) -> AdTable:
    """导出103
       ------------------
       入参：
       session: SAP SESSION，如为None，则新打开SAP
       staff_ids: 人员编号数组
       key_date: 关键日期
       ------------------
       返回值：
       AdTable，可通过.wb访问Workbook，或.ws访问Worksheet
       ------------------
       调用样例：
       _table: AdTable = export_103(None, ['01576547'], '20200301')
       _table.filename = '模板_103'
       _table.save_to('x:/') # 保存模板至x:/下
    """
    if session is None:
        session = attach_sap("reopen")
    elif isinstance(session, str):
        session = attach_sap(session)
    enter_103(session)  # 进入103信息集查询屏
    query_selection(session, 'RPA_HR_LTX_103', select_103_li_tui_xiu_jian_ce, LI_TUI_XIU_JIAN_CE_HEADER)  # 勾选103选项
    fill_103(session, staff_ids, key_date)  # 填入员工编号和关键日期，并查询
    _table: AdTable = export_query(session, template_file=f'{TEMPLATE_DIR}/C21_离退休减册.xlsx', query_name='RPA_HR_LTX_103')
    _table['A'].apply(init_sap_id)
    return _table


def export_103_li_tui_xiu(session: Any, staff_ids: List[str], key_date: str) -> AdTable:
    """导出103
       ------------------
       入参：
       session: SAP SESSION，如为None，则新打开SAP
       staff_ids: 人员编号数组
       key_date: 关键日期
       ------------------
       返回值：
       AdTable，可通过.wb访问Workbook，或.ws访问Worksheet
       ------------------
       调用样例：
       _table: AdTable = export_103(None, ['01576547'], '20200301')
       _table.filename = '模板_103'
       _table.save_to('x:/') # 保存模板至x:/下
    """
    if session is None:
        session = attach_sap("reopen")
    elif isinstance(session, str):
        session = attach_sap(session)
    enter_103(session)  # 进入103信息集查询屏
    query_selection(session, 'RPA_HR_LT_103', select_103_li_tui_xiu, LI_TUI_XIU_HEADER)  # 勾选103选项
    fill_103(session, staff_ids, key_date)  # 填入员工编号和关键日期，并查询
    _table: AdTable = export_query(session, template_file=f'{TEMPLATE_DIR}/C20_离退休.xlsx', query_name='RPA_HR_LT_103')
    _table['A'].apply(init_sap_id)
    return _table


def export_103_nei_tui(session: Any, staff_ids: List[str], key_date: str) -> AdTable:
    """导出103
       ------------------
       入参：
       session: SAP SESSION，如为None，则新打开SAP
       staff_ids: 人员编号数组
       key_date: 关键日期
       ------------------
       返回值：
       AdTable，可通过.wb访问Workbook，或.ws访问Worksheet
       ------------------
       调用样例：
       _table: AdTable = export_103(None, ['01576547'], '20200301')
       _table.filename = '模板_103'
       _table.save_to('x:/') # 保存模板至x:/下
    """
    if session is None:
        session = attach_sap("reopen")
    elif isinstance(session, str):
        session = attach_sap(session)
    enter_103(session)  # 进入103信息集查询屏
    query_selection(session, 'RPA_HR_NT_103', select_103_nei_tui, NEI_TUI_HEADER)  # 勾选103选项
    fill_103(session, staff_ids, key_date)  # 填入员工编号和关键日期，并查询
    _table: AdTable = export_query(session, template_file=f'{TEMPLATE_DIR}/C22_内退.xlsx', query_name='RPA_HR_NT_103')
    _table['A'].apply(init_sap_id)
    return _table


def export_103_li_zhi(session: Any, staff_ids: List[str], key_date: str) -> AdTable:
    """导出103
       ------------------
       入参：
       session: SAP SESSION，如为None，则新打开SAP
       staff_ids: 人员编号数组
       key_date: 关键日期
       ------------------
       返回值：
       AdTable，可通过.wb访问Workbook，或.ws访问Worksheet
       ------------------
       调用样例：
       _table: AdTable = export_103(None, ['01576547'], '20200301')
       _table.filename = '模板_103'
       _table.save_to('x:/') # 保存模板至x:/下
    """
    if session is None:
        session = attach_sap("reopen")
    elif isinstance(session, str):
        session = attach_sap(session)
    enter_103(session)  # 进入103信息集查询屏
    query_selection(session, 'RPA_HR_LZ_103', select_103_li_zhi, LI_ZHI_HEADER)  # 勾选103选项
    fill_103(session, staff_ids, key_date)  # 填入员工编号和关键日期，并查询
    _table: AdTable = export_query(session, template_file=f'{TEMPLATE_DIR}/C23_离职.xlsx', query_name='RPA_HR_LZ_103')
    _table['A'].apply(init_sap_id)
    return _table


def export_103_li_zhi2(session: Any, staff_ids: List[str], key_date: str, key: str = '8', end_date: str = '99991231') -> AdTable:
    """导出103
       ------------------
       入参：
       session: SAP SESSION，如为None，则新打开SAP
       staff_ids: 人员编号数组
       key_date: 关键日期
       ------------------
       返回值：
       AdTable，可通过.wb访问Workbook，或.ws访问Worksheet
       ------------------
       调用样例：
       _table: AdTable = export_103(None, ['01576547'], '20200301')
       _table.filename = '模板_103'
       _table.save_to('x:/') # 保存模板至x:/下
    """
    if session is None:
        session = attach_sap("reopen")
    elif isinstance(session, str):
        session = attach_sap(session)
    enter_103(session)  # 进入103信息集查询屏
    query_selection(session, 'RPA_HR_LZ_1032', select_li_zhi_1032, LI_ZHI_HEADER2)  # 勾选103选项
    fill_103(session, staff_ids, key_date, key, end_date)  # 填入员工编号和关键日期，并查询
    _table: AdTable = export_query(session, template_file=f'{TEMPLATE_DIR}/C23-2离职.xlsx', query_name='RPA_HR_LZ_1032')
    _table['A'].apply(init_sap_id)
    return _table


def export_103_li_zhi3(session: Any, staff_ids: List[str], key_date: str, key: str = '8', end_date: str = '99991231') -> AdTable:
    """导出103
       ------------------
       入参：
       session: SAP SESSION，如为None，则新打开SAP
       staff_ids: 人员编号数组
       key_date: 关键日期
       ------------------
       返回值：
       AdTable，可通过.wb访问Workbook，或.ws访问Worksheet
       ------------------
       调用样例：
       _table: AdTable = export_103(None, ['01576547'], '20200301')
       _table.filename = '模板_103'
       _table.save_to('x:/') # 保存模板至x:/下
    """
    if session is None:
        session = attach_sap("reopen")
    elif isinstance(session, str):
        session = attach_sap(session)
    enter_103(session)  # 进入103信息集查询屏
    query_selection(session, 'RPA_HR_LZ_1033', select_li_zhi_1033, LI_ZHI_HEADER3)  # 勾选103选项
    fill_103(session, staff_ids, key_date, key, end_date)  # 填入员工编号和关键日期，并查询
    _table: AdTable = export_query(session, template_file=f'{TEMPLATE_DIR}/C23-3劳动合同.xlsx', query_name='RPA_HR_LZ_1033')
    _table['A'].apply(init_sap_id)
    return _table


def export_103_lao_wu_gong(session: Any, staff_ids: List[str], key_date: str) -> AdTable:
    return export_103_li_zhi(session, staff_ids, key_date)


# example
if __name__ == '__main__':
    config()
    _table: AdTable = export_103_li_tui_xiu(None, ['01576547'], '20200301')
    _table.save_to('x:/')
