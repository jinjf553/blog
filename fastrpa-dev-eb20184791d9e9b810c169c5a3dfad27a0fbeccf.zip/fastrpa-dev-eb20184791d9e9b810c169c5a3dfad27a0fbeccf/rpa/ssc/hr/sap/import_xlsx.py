import logging
import re
import time
from pathlib import Path
from typing import Any, Dict

import win32con
import win32gui
from rpa.fastrpa.adtable import AdTable, load_from_xlsx_file
from rpa.fastrpa.sap.grid_view_ctrl import GridViewCtrl
from rpa.fastrpa.sap.session import SAP, clean_sap_gui_cache_dir
from rpa.fastrpa.tempdir import gentempdir
from rpa.fastrpa.utils.window import pass_upload_window
from rpa.fastrpa.xlsx import fix_excel, kill_excel

IMPORT_MULTI_DICT = {'入职事件批导': 'wnd[0]/usr/radRB_M_ZA',
                     '调入事件批导': 'wnd[0]/usr/radRB_M_ZG',
                     '调出事件批导': 'wnd[0]/usr/radRB_M_ZH',
                     '拟调出事件批导': 'wnd[0]/usr/radRB_M_ZX',
                     '岗位变动事件批导': 'wnd[0]/usr/radRB_M_ZI',
                     '因公司代码调整的岗位变化': 'wnd[0]/usr/radRB_M_YE',
                     '离退休事件批导': 'wnd[0]/usr/radRB_M_ZK',
                     '减册事件批导': 'wnd[0]/usr/radRB_M_ZL',
                     '内退事件批导': 'wnd[0]/usr/radRB_M_ZO',
                     'PB入职事件批导': 'wnd[0]/usr/radRB_M_Y1',
                     '劳务工退回ZM批导': 'wnd[0]/usr/radRB_M_MZ',
                     '入职工资处理批导': 'wnd[0]/usr/radRB_M_Z0',
                     '工资调整批导': 'wnd[0]/usr/radRB_M_Z1',
                     '暂停取消发薪': 'wnd[0]/usr/radRB_M_Z2',
                     '离职工资处理': 'wnd[0]/usr/radRB_M_Z3',
                     '离退休工资处理': 'wnd[0]/usr/radRB_M_Z4',
                     '离退休减册事件批导': 'wnd[0]/usr/radRB_M_YB',
                     '不在岗人员岗位变动事件批导': 'wnd[0]/usr/radRB_M_YD',
                     '转正人员岗位变动事件批导': 'wnd[0]/usr/radRB_M_ZB',
                     '重新录用/管理业务（服务）外包人员事件批导': 'wnd[0]/usr/radRB_M_ZQ',
                     '原其他长期合同工人员岗位变动批导': 'wnd[0]/usr/radRB_M_ZI3',
                     '离岗事件批导': 'wnd[0]/usr/radRB_M_ZN'}

IMPORT_SINGLE_MATRIX = [['在表格 INDX 中的用户-定义关键字', 'I类型', 'STy.', '消息文本', '人员类别'],
                        ['0000->HR_BI_YF', '0000', '', '国家再分配', ''],
                        ['0000->HR_BI_Y0X', '0000', '', '人事事件_系统上线_总额控制范围非默认', ''],
                        ['0000->HR_BI_Y0', '0000', '', '人事事件_系统上线', ''],
                        ['0000->HR_BI_ZIX', '0000', '', '人事事件_调整用工形式（由派遣制员工调整）', ''],
                        ['0002->HR_BI_0002', '0002', '', '人员基本信息', ''],
                        ['0002->HR_BI_0002HK', '0002', '', '人员信息-户口类别', ''],
                        ['0006->HR_BI_0006', '0006', '', '地址信息', ''],
                        ['0007->HR_BI_0007', '0007', '', '计划工作时间', ''],
                        ['0008->HR_BI_0008X', '0008', '', '基本工资_原等级标准', ''],
                        ['0008->HR_BI_0008', '0008', '', '基本工资', ''],
                        ['0009->HR_BI_0009', '0009', '', '银行信息', ''],
                        ['0014->HR_BI_0014', '0014', '', '经常性支付扣除', ''],
                        ['0014->HR_BI_0014X', '0014', '', '经常性支付扣除_成本分配', ''],
                        ['0014->HR_BI_0014CU', '0014', '', '经常性支付扣除_定界', ''],
                        ['0015->HR_BI_0015X', '0015', '', '偶然性支付扣款_成本分配', ''],
                        ['0015->HR_BI_0015', '0015', '', '偶然性支付扣款', ''],
                        ['0019->HR_BI_0019', '0019', '', '人事业务提醒', ''],
                        ['0021->HR_BI_0021', '0021', '', '家庭成员及社会关系', ''],
                        ['0022->HR_BI_0022', '0022', '', '学历学位', ''],
                        ['0023->HR_BI_0023', '0023', '', '工作经历', ''],
                        ['0027->HR_BI_0027X', '0027', '', '成本分配_定界', ''],
                        ['0027->HR_BI_0027', '0027', '', '成本分配', ''],
                        ['0041->HR_BI_0041JY', '0041', '', '特殊日期修改15', ''],
                        ['0041->HR_BI_0041', '0041', '', '特殊日期记录', ''],
                        ['0105->HR_BI_0105X', '0105', '', '通讯信息_家庭电话', ''],
                        ['0105->HR_BI_0105', '0105', '', '通讯信息(不含家庭电话）', ''],
                        ['0185->HR_BI_0185', '0185', '', '证件信息_居民身份证', ''],
                        ['0185->HR_BI_0185X', '0185', '', '证件信息(不含居民身份证）', ''],
                        ['0267->HR_BI_0267X', '0267', '', '单独发放_成本分配', ''],
                        ['0267->HR_BI_0267', '0267', '', '单独发放', ''],
                        ['0530->HR_BI_0530', '0530', '', '住房公积金', ''],
                        ['0531->HR_BI_0531', '0531', '', '所得税（中国）', ''],
                        ['0532->HR_BI_0532', '0532', '', '社会保险', ''],
                        ['0534->HR_BI_0534', '0534', '', '政治面貌信息', ''],
                        ['0537->HR_BI_0537', '0537', '', '出国（境）情况', ''],
                        ['1000->HR_BI_100002', '1000', '', '创建对象_02', ''],
                        ['1000->HR_BI_1000S', '1000', '', '创建（职务）岗位具体名称（S）', ''],
                        ['1000->HR_BI_PP0394', '1000', '', '系统上线新建项目部', ''],
                        ['1000->HR_BI_1000SC', '1000', '', '职务（岗位）具体名称（S)定界', ''],
                        ['1000->HR_BI_100003', '1000', '', '创建对象_03', ''],
                        ['1000->HR_BI_1000O', '1000', '', '创建组织机构', ''],
                        ['1000->HR_BI_1000C', '1000', '', '对象（C）', ''],
                        ['1001->HR_BI_AZ11SS', '1001', '', '考勤关系_S_S_AZ11', ''],
                        ['1001->HR_BI_A012SO', '1001', '', '关系_S_O_A012', ''],
                        ['1001->HR_BI_A011OK', '1001', '', '关系_O_K_A011', ''],
                        ['1001->HR_BI_A003SO', '1001', '', '指定岗位的隶属机构', ''],
                        ['1001->HR_BI_AZ0332', '1001', '', '创建关系_AZ03_03_02', ''],
                        ['1001->HR_BI_A002OO', '1001', '', '指定机构的直接上级机构', ''],
                        ['1001->HR_BI_PJ_PJ', '1001', '', '关系_PJ_PJ_A002', ''],
                        ['1001->HR_BI_B007SC', '1001', '', '关系_S_C_B007', ''],
                        ['1001->HR_BI_AZ03C2', '1001', '', '关系_C_02_AZ03', ''],
                        ['1001->HR_BI_B007S3', '1001', '', '创建关系_S_03_B007', ''],
                        ['1001->HR_A011_OKCU', '1001', '', '机构主成本中心_定界', ''],
                        ['1001->HR_BI_A008', '1001', '', '指定岗位与人员的对应关系', ''],
                        ['1001->HR_BI_A00222', '1001', '', '创建关系_02_02_A002', ''],
                        ['1001->HR_BI_A005SS', '1001', '', '关系_S_S_A005', ''],
                        ['1001->HR_BI_A108', '1001', '', '创建S与PJ的关系', ''],
                        ['1001->HR_A011_SKCU', '1001', '', '岗位主成本中心_定界', ''],
                        ['1001->HR_BI_A011SK', '1001', '', 'HR_BI_A011SK', ''],
                        ['1001->HR_BI_AZ12SS', '1001', 'AZ12', '考勤汇报关系_S_S_AZ12', ''],
                        ['1008->HR_BI_1008', '1008', '', '财务科目设置', ''],
                        ['1018->HR_BI_1018OC', '1018', '', '成本分配定界（O）', ''],
                        ['1018->HR_BI_1018O', '1018', '', '成本分配_O', ''],
                        ['1018->HR_BI_1018CU', '1018', '', '成本分配定界（S）', ''],
                        ['1018->HR_BI_1018S', '1018', '', '成本分配_S', ''],
                        ['1019->HR_BI_1019', '1019', '', '岗位定员', ''],
                        ['2001->HR_BI_2001X', '2001', '', '缺勤及休假（有定额）', ''],
                        ['2001->HR_BI_2001', '2001', '', '缺勤及休假（除有定额并且受控制的子类型）', ''],
                        ['2002->HR_BI_2002', '2002', '', '特殊出勤', ''],
                        ['2003->HR_BI_2003', '2003', '', '替班', ''],
                        ['2005->HR_BI_2005', '2005', '', '加班', ''],
                        ['2006->HR_BI_2006', '2006', '', '休假定额', ''],
                        ['2010->HR_BI_2010', '2010', '', '考勤结果_成本分配', ''],
                        ['2010->HR_BI_2010M', '2010', '', '考勤结果', ''],
                        ['9004->HR_BI_9004', '9004', '', '注册登记信息', ''],
                        ['9005->HR_BI_9005', '9005', '', '机构分类属性', ''],
                        ['9007->HR_BI_9007', '9007', '', '基层单位特有属性', ''],
                        ['9008->HR_BI_9008', '9008', '', '项目部信息', ''],
                        ['9010->HR_BI_9010', '9010', '', '通讯地址', ''],
                        ['9014->HR_BI_9014', '9014', '', '加油站信息', ''],
                        ['9015->HR_BI_9015', '9015', '', '博士后站信息', ''],
                        ['9018->HR_BI_9018', '9018', '', '工商登记信息', ''],
                        ['9019->HR_BI_9019', '9019', '', '岗位分类信息', ''],
                        ['9020->HR_BI_9020C', '9020', '', '任职条件_C', ''],
                        ['9020->HR_BI_9020S', '9020', '', '任职条件_S', ''],
                        ['9022->HR_BI_9022', '9022', '', '销售企业单位属性', ''],
                        ['9050->HR_BI_9050', '9050', '', '行政班子换届情况', ''],
                        ['9051->HR_BI_9051', '9051', '', '党组织换届情况', ''],
                        ['9052->HR_BI_9052', '9052', '', '董事会/监事会换届情况', ''],
                        ['9053->HR_BI_9053', '9053', '', '工会换届情况', ''],
                        ['9054->HR_BI_9054', '9054', '', '民主生活会情况', ''],
                        ['9055->HR_BI_9055', '9055', '', '中心组学习情况', ''],
                        ['9056->HR_BI_9056', '9056', '', '海外机构信息', ''],
                        ['9064->HR_BI_9064', '9064', '', '领导班子信息', ''],
                        ['9068->HR_BI_9068', '9068', '', '单位简化全称', ''],
                        ['9068->HR_BI_9068M', '9068', '', '单位简化全称修改', ''],
                        ['9072->HR_BI_9072', '9072', '', '海外岗位属性信息', ''],
                        ['9084->HR_BI_9084', '9084', '', '岗位类别', ''],
                        ['9099->HR_BI_9099', '9099', '', '岗位业务分类', ''],
                        ['9201->HR_BI_9201', '9201', '', '奖惩（行政及党内）信息', ''],
                        ['9203->HR_BI_9203', '9203', '', '员工协议', ''],
                        ['9204->HR_BI_9204', '9204', '', '工伤信息', ''],
                        ['9205->HR_BI_9205_1', '9205', '', '语言能力_0001', ''],
                        ['9205->HR_BI_9205_3', '9205', '', '语言能力_英语分级测试', ''],
                        ['9205->HR_BI_9205_2', '9205', '', '语言能力_0002', ''],
                        ['9206->HR_BI_9206', '9206', '', '职称考试成绩', ''],
                        ['9207->HR_BI_9207', '9207', '', '专长信息', ''],
                        ['9208->HR_BI_9208', '9208', '', '社会(学术)团体任职信息', ''],
                        ['9209->HR_BI_9209X', '9209', '', '岗位聘任补充信息修改', ''],
                        ['9209->HR_BI_9209', '9209', '', '岗位聘任补充信息', ''],
                        ['9211->HR_BI_9211', '9211', '', '借调人员信息', ''],
                        ['9212->HR_BI_9212', '9212', '', '离退休人员信息', ''],
                        ['9212->HR_BI_9212X', '9212', '', '离退休人员领取企业年金标识', ''],
                        ['9216->HR_BI_9216', '9216', '', '专业技术资格申报', ''],
                        ['9217->HR_BI_9217', '9217', '', '专业技术资格信息', ''],
                        ['9219->HR_BI_9219', '9219', '', '专业技术工作信息', ''],
                        ['9220->HR_BI_9220', '9220', '', '专业技术成果及获奖信息', ''],
                        ['9222->HR_BI_9222', '9222', '', '专利信息', ''],
                        ['9223->HR_BI_9223', '9223', '', '论文论著', ''],
                        ['9224->HR_BI_9224', '9224', '', '专家申报信息', ''],
                        ['9225->HR_BI_9225', '9225', '', '专家称号信息', ''],
                        ['9226->HR_BI_9226', '9226', '', '职业（上岗）资格证书', ''],
                        ['9228->HR_BI_9228', '9228', '', '职业技能鉴定信息', ''],
                        ['9229->HR_BI_9229', '9229', '', '职业技能资格聘任', ''],
                        ['9230->HR_BI_9230', '9230', '', '职业技能鉴定考评员资格信息', ''],
                        ['9231->HR_BI_9231', '9231', '', '职业技能鉴定考评员聘任', ''],
                        ['9232->HR_BI_9232', '9232', '', '技术能手评选申报', ''],
                        ['9233->HR_BI_9233', '9233', '', '技能荣誉信息', ''],
                        ['9234->HR_BI_9234', '9234', '', '职业技能竞赛申报', ''],
                        ['9235->HR_BI_9235', '9235', '', '职业技能竞赛信息', ''],
                        ['9237->HR_BI_9237', '9237', '', '师带徒信息', ''],
                        ['9238->HR_BI_9238', '9238', '', '军队复转人员', ''],
                        ['9239->HR_BI_9239', '9239', '', '博士后研究人员', ''],
                        ['9240->HR_BI_9240', '9240', '', '考察（疗养）情况', ''],
                        ['9241->HR_BI_9241', '9241', '', '其他用工信息', ''],
                        ['9242->HR_BI_9242', '9242', '', '兼任职务', ''],
                        ['9243->HR_BI_9243', '9243', '', '从事职业（工种）情况', ''],
                        ['9244->HR_BI_9244', '9244', '', '档案转递情况', ''],
                        ['9245->HR_BI_9245', '9245', '', '工程项目部信息', ''],
                        ['9248->HR_BI_9248', '9248', '', '海外机构（项目）人员', ''],
                        ['9251->HR_BI_9251', '9251', '', '行政党派职务', ''],
                        ['9256->HR_BI_9256', '9256', '', '内退人员信息', ''],
                        ['9257->HR_BI_9257', '9257', '', '职业技能鉴定成绩信息', ''],
                        ['9259->HR_BI_9259', '9259', '', '国际化人才标识', ''],
                        ['9261->HR_BI_9261_1', '9261', '', '员工考核信息(企业自定义考核结果等级)', ''],
                        ['9261->HR_BI_9261', '9261', '', '员工考核信息', ''],
                        ['9264->HR_BI_9264', '9264', '', '集团公司外派海外用工信息', ''],
                        ['9271->HR_BI_9271', '9271', '', '原其他长期合同工信息', ''],
                        ['9271->HR_BI_9271X', '9271', '', '原其他长期合同工信息_定界', ''],
                        ['9272->HR_BI_9272', '9272', '', '改制预留费支付费用人员信息', ''],
                        ['9273->HR_BI_9273', '9273', '', '调整用工形式人员信息', ''],
                        ['9280->HR_BI_9280', '9280', '', '基本薪酬运行区间', ''],
                        ['9281->HR_BI_9281', '9281', '', '基本薪酬特殊运行区间标识', ''],
                        ['9282->HR_BI_9282', '9282', '', '岗薪联动资质等级', ''],
                        ['9299->HR_BI_9299', '9299', '', '劳动合同', ''],
                        ['9408->HR_BI_9408', '9408', '', '员工培训信息', ''],
                        ['9409->HR_BI_9409', '9409', '', '内部讲师信息', ''],
                        ['9412->HR_BI_9412', '9412', '', '培训机构人员情况', ''],
                        ['9416->HR_BI_9416', '9416', '', '培训办班情况', ''],
                        ['9500->HR_BI_9500', '9500', '', '考勤信息备注', ''],
                        ['9601->HR_BI_9601', '9601', '', '企业年金', ''],
                        ['9602->HR_BI_9602', '9602', '', '原企业年金', ''],
                        ['9603->HR_BI_9603', '9603', '', '基本工资演变历史记录', ''],
                        ['9607->HR_BI_9607', '9607', '', '成本分配辅助信息', ''],
                        ['9631->HR_BI_9631', '9631', '', '总额控制范围分配', ''], ]


def pass_microsoft_excel_window():
    """关闭Microsoft Excel弹窗
       ------------------
       窗口标题：Microsoft Excel
       ------------------
       窗口内容：在当前位置发现已经存在名为“xxxx.XLS”的文件。您希望将该文件替换掉吗？"""
    for _ in range(240):
        time.sleep(1)
        dialog = win32gui.FindWindow('#32770', 'Microsoft Excel')  # 对话框
        if dialog:
            button = win32gui.FindWindowEx(dialog, 0, 'Button', None)  # 是按钮Button
            win32gui.PostMessage(button, win32con.WM_LBUTTONDOWN, win32con.MK_LBUTTON, 0)
            win32gui.PostMessage(button, win32con.WM_LBUTTONUP, win32con.MK_LBUTTON, 0)
            break
        time.sleep(0.5)


def import_multi(import_name: str, filename: str, repeat_times: int = 10, extra_args: Dict[str, Any] = {}, enter_mode='login_tx') -> bool:
    """多信息类型批导

    Args:
        import_name (str): 批导类型，如：入职事件批导、调入事件批导，可从SAP界面中查看支持的批导类型
        filename (str): 文件全路径
        repeat_times (int, optional): 失败后重试次数，默认10次

    Raises:
        Exception: [description]

    Returns:
        bool: 批导全部成功返回True，失败返回False
    """
    windows_filepath: str = str(Path(filename))
    logging.info(f'多信息模板批导，批导类型：{import_name}，文件名：{windows_filepath}')
    kill_excel()
    fix_excel(filename)
    kill_excel()
    clean_sap_gui_cache_dir()
    with SAP(enter_mode, 'close_sap') as session:
        session.findById("wnd[0]").maximize()
        # logging.info('执行事务码zhrbi0013')
        session.findById("wnd[0]/tbar[0]/okcd").text = "/n zhrbi0013"
        session.findById("wnd[0]").sendVKey(0)
        # logging.info('选择多信息类型批导')
        session.findById("wnd[0]/usr/radRB_M").select()  # 多信息类型批导
        # logging.info(f'勾选批导类型：{import_name}')
        if import_name in IMPORT_MULTI_DICT.keys():
            import_radio_id = IMPORT_MULTI_DICT[import_name]
        else:
            raise Exception(f'未知批导类型：{import_name}')
        session.findById(import_radio_id).select()
        # logging.info('点击执行按钮')
        session.findById("wnd[0]/tbar[1]/btn[8]").press()  # 执行
        # logging.info('选择上载数据')
        session.findById("wnd[0]/usr/radRB_UP").select()  # 上载数据
        pass_upload_window(windows_filepath)  # 查找【选择上传文件】弹出窗口，数据文件名，并关闭对话框
        # logging.info('点击执行按钮')
        session.findById("wnd[0]/tbar[1]/btn[8]").press()  # 执行
        # 可能出现的弹窗
        if len(session.children) >= 2:
            wnd1_text = session.findById("wnd[1]").text  # 弹出窗口的标题
        # 结果弹窗
        if len(session.children) >= 2:
            wnd1_text = session.findById("wnd[1]").text  # 弹出窗口的标题
            if '数据已完成导入' in wnd1_text:
                import_info = session.findById("wnd[1]/usr/txtSPOP-TEXTLINE2").Text  # 批导结果信息
                matches = re.match(r'其中：成功(\d+)\s*行，失败(\d+)\s*行', import_info)
                if matches is not None:
                    failed_cnt = int(matches.group(2))
                    if failed_cnt != 0:
                        logging.error(f'批导存在失败，{import_info}')
                        return False
                    else:
                        logging.info('批导成功，未遇到错误')
                        return True
                else:
                    logging.warning(f'SAP窗口【数据已完成导入】窗口信息无法解析：{import_info}')
                    return False
            elif 'SAP' in session.findById("wnd[1]").Text:
                grid_view_ctrl = GridViewCtrl(session, 'wnd[1]/usr/cntlG_GRID/shellcont/shell')
                lt_import_result = grid_view_ctrl.to_adtable()  # TODO 待优化：一行一行获取数据，错误行数较多时，性能差
                if repeat_times > 1 and '数据超长' in lt_import_result['C'].values:
                    logging.error('数据超长')
                    return import_multi(import_name, filename, repeat_times - 1, enter_mode=enter_mode)
                else:  # 回写错误信息
                    lt = load_from_xlsx_file(filename)
                    df = lt.to_dataframe()
                    is_import_passed = True
                    for row in lt_import_result.rows:
                        if row['C'].value != '':
                            is_import_passed = False
                            idx = row['A'].value  # 序号
                            column_name = row['B'].value  # 字段名
                            err_text = row['C'].value  # 错误信息
                            logging.error(f'序号：{idx}，字段名：{column_name}，错误信息：{err_text}')
                            df_tmp = df[df['A'] == idx]  # A 列找到序号
                            if df_tmp.empty is False:
                                rn = df_tmp.index[0]
                                lt['A'][rn].cmt('red', f'批导错误：{column_name}:{err_text}')  # 回写批导错误信息
                    lt.save(filename)
                    return is_import_passed
            else:
                logging.warning(wnd1_text)  # 非预期结果弹窗
        sap_status = session.findById("wnd[0]/sbar/pane[0]").text
        logging.info(f'批导后SAP状态栏信息:{sap_status}')
        if '记录已创建' in sap_status:
            return True
        elif sap_status in ('上载的模板中没有数据或数据错误', '没有需要处理的数据或数据错误', '文件不符合要求', '没有需要处理的数据或数据错误'):
            logging.error(sap_status)  # 重复批导也会触发[没有需要处理的数据或数据错误]，实际是批导成功了
            if repeat_times > 1:
                return import_multi(import_name, filename, repeat_times - 1, enter_mode=enter_mode)
            else:
                return False
        else:
            logging.warning('未知批导结果')
            return False  # 未知批导结果


def import_multi_adtable(import_name: str, lt: AdTable, repeat_times: int = 10, extra_args: Dict[str, Any] = {}, enter_mode='login_tx') -> bool:
    """多信息类型批导，同import_multi()，接收并更新AdTable对象"""
    temp_dir = gentempdir()
    temp_filename = lt.save_to(temp_dir)
    is_import_succ = import_multi(import_name, temp_filename, repeat_times, extra_args, enter_mode=enter_mode)
    _lt = load_from_xlsx_file(temp_filename, lt.ws.title, lt.skip_header)
    lt.wb = _lt.wb
    lt.ws = _lt.ws
    return is_import_succ


def import_single(import_name: str, filename: str, repeat_times: int = 10, *, extra_args: Dict[str, Any] = {}, enter_mode='login_tx') -> bool:
    """单信息类型批导

    Args:
        import_name (str): 导入模板名称，如："9243->HR_BI_9243"
        filename (str): 文件全路径
        repeat_times (int, optional): 失败后重试次数，默认10次

    Returns:
        bool: 批导全部成功返回True，失败返回False
    """
    windows_filepath: str = str(Path(filename))
    logging.info(f'单信息模板批导，批导类型：{import_name}，文件名：{windows_filepath}')
    kill_excel()
    fix_excel(filename)
    kill_excel()
    clean_sap_gui_cache_dir()
    with SAP(enter_mode, 'close_sap') as session:
        session.findById("wnd[0]").maximize()
        # logging.info('执行事务码zhrbi0013')
        session.findById("wnd[0]/tbar[0]/okcd").text = "/n zhrbi0013"
        # logging.info('回车')
        session.findById("wnd[0]").sendVKey(0)  # 回车
        # logging.info('勾选[人员导入]')
        session.findById("wnd[0]/usr/radRB_M_PA").select()  # 勾选[人员导入]
        # logging.info('点击执行按钮')
        session.findById("wnd[0]/tbar[1]/btn[8]").press()  # 执行
        # logging.info(f'填充导入模板名称：{import_name}')
        session.findById("wnd[0]/usr/ctxtP_SRTFD").text = import_name  # 导入模板名称，如："1001->HR_BI_A011SK"
        # logging.info('选择上载数据')
        session.findById("wnd[0]/usr/radRB_UP").select()
        pass_upload_window(windows_filepath)
        # logging.info('点击执行按钮')
        session.findById("wnd[0]/tbar[1]/btn[8]").press()  # 执行
        # 可能出现的弹窗
        if len(session.children) >= 2:
            if '附加选择' in session.findById("wnd[1]").text:  # 窗口[PH3(1)/800 附加选择]-[公司代码]
                if session.findById("wnd[1]/usr/txt%_P_BUKRS_%_APP_%-TEXT", False) is not None:  # 元素存在
                    if '公司代码' in session.findById("wnd[1]/usr/txt%_P_BUKRS_%_APP_%-TEXT").text:
                        session.findById("wnd[1]/usr/ctxtP_BUKRS").text = extra_args['公司代码']  # 1018->HR_BI_1018S需要额外输入公司代码
                        session.findById("wnd[1]/tbar[0]/btn[8]").press()
        if len(session.children) >= 2:
            if '下载文件' in session.findById("wnd[1]").text:  # 窗口[PH3(1)/800 下载文件]-[下载失败！]
                session.findById("wnd[1]/usr/btnSPOP-OPTION1").press()  # 点击[继续]
        if len(session.children) >= 2:
            if session.findById("wnd[1]/usr/ctxtP_ORGEH", False) is not None:  # 元素存在
                session.findById("wnd[1]/usr/ctxtP_ORGEH").text = "10010060"
                session.findById("wnd[1]/tbar[0]/btn[8]").press()
        # 结果弹窗
        if len(session.children) >= 2:
            wnd1_text = session.findById("wnd[1]").text  # 弹出窗口的标题
            if '数据已完成导入' in wnd1_text:
                import_info = session.findById("wnd[1]/usr/txtSPOP-TEXTLINE2").Text  # 批导结果信息
                matches = re.match(r'其中：成功(\d+)\s*行，失败(\d+)\s*行', import_info)
                if matches is not None:
                    failed_cnt = int(matches.group(2))
                    if failed_cnt != 0:
                        logging.error(f'批导存在失败，{import_info}')
                        return False
                    else:
                        logging.info('批导成功，未遇到错误')
                        return True
                else:
                    logging.warning(f'SAP窗口【数据已完成导入】窗口信息无法解析：{import_info}')
                    return False
            elif 'SAP' in wnd1_text:
                grid_view_ctrl = GridViewCtrl(session, 'wnd[1]/usr/cntlG_GRID/shellcont/shell')
                lt_import_result = grid_view_ctrl.to_adtable()  # TODO 待优化：一行一行获取数据，错误行数较多时，性能差
                if repeat_times > 1 and '数据超长' in lt_import_result['C'].values:
                    logging.error('数据超长')
                    return import_single(import_name, filename, repeat_times - 1, extra_args=extra_args, enter_mode=enter_mode)
                else:  # 回写错误信息
                    lt = load_from_xlsx_file(filename)
                    df = lt.to_dataframe()
                    is_import_passed = True
                    for row in lt_import_result.rows:
                        if row['C'].value != '':
                            is_import_passed = False
                            idx = row['A'].value  # 序号
                            column_name = row['B'].value  # 字段名
                            err_text = row['C'].value  # 错误信息
                            logging.error(f'序号：{idx}，字段名：{column_name}，错误信息：{err_text}')
                            df_tmp = df[df['A'] == idx]  # A 列找到序号
                            if df_tmp.empty is False:
                                rn = df_tmp.index[0]
                                lt['A'][rn].cmt('red', f'批导错误：{column_name}:{err_text}')  # 回写批导错误信息
                    lt.save(filename)
                    return is_import_passed
            else:
                logging.warning(wnd1_text)  # 非预期结果弹窗
        sap_status = session.findById("wnd[0]/sbar/pane[0]").text
        logging.info(f'批导后SAP状态栏信息:{sap_status}')
        if '记录已创建' in sap_status:
            return True
        elif sap_status in ('上载的模板中没有数据或数据错误', '没有需要处理的数据或数据错误', '文件不符合要求', '没有需要处理的数据或数据错误'):
            logging.error(sap_status)  # 重复批导也会触发[没有需要处理的数据或数据错误]，实际是批导成功了
            if repeat_times > 1:
                return import_single(import_name, filename, repeat_times - 1, extra_args=extra_args, enter_mode=enter_mode)
            else:
                return False
        else:
            logging.warning('未知批导结果')
            return False


def import_single_adtable(import_name: str, lt: AdTable, repeat_times: int = 10, *, extra_args: Dict[str, Any] = {}, enter_mode='login_tx') -> bool:
    """单信息类型批导，同import_single()，接收并更新AdTable对象"""
    temp_dir = gentempdir()
    temp_filename = lt.save_to(temp_dir)
    is_import_succ = import_single(import_name, temp_filename, repeat_times, extra_args=extra_args, enter_mode=enter_mode)
    _lt = load_from_xlsx_file(temp_filename, lt.ws.title, lt.skip_header)
    lt.wb = _lt.wb
    lt.ws = _lt.ws
    return is_import_succ


if __name__ == '__main__':
    # from rpa.ssc.hr.sap.import_xlsx import import_single, import_multi
    import rpa.config
    from rpa.fastrpa.log import config
    config('单信息批导')
    rpa.config.SAP_FUNJ = 'FUNJ0179'
    rpa.config.FSO_USERNAME = 'guoy926'  # 业务人员FSO账号写入全局配置里
    rpa.config.STAFF_GROUP = 'RPA团队'
    rpa.config.STAFF_ID = 49
    rpa.config.STAFF_TYPE = '组员'
    rpa.config.STAFF_NAME = '郭运'
    import_single('1000->HR_BI_1000S', r"x:/无单号-X420-销售建岗-郭运/01.1000_HR_BI_1000S--人员导入--创建（职务）岗位具体名称（S）.xlsx", 1, enter_mode='reopen')  # 单信息类型批导
    import_single('9019->HR_BI_9019', r"x:/无单号-X420-销售建岗-郭运/02.9019_HR_BI_9019--人员导入--岗位分类信息-33150000.xlsx", 1, enter_mode='reopen')  # 单信息类型批导
    import_single('1001->HR_BI_B007SC', r"x:/无单号-X420-销售建岗-郭运/03.1001_HR_BI_B007SC--人员导入--关系_S_C_B007.xlsx", 1, enter_mode='reopen')  # 单信息类型批导
    import_single('1001->HR_BI_A011SK', r"x:/无单号-X420-销售建岗-郭运/04.1001_HR_BI_A011SK--人员导入--HR_BI_A011SK.xlsx", 1, enter_mode='reopen')  # 单信息类型批导
    import_single('1018->HR_BI_1018S', r"x:/无单号-X420-销售建岗-郭运/05.1018_HR_BI_1018S--人员导入--成本分配_S--X240.xlsx", 1, extra_args={'公司代码': 'X420'}, enter_mode='reopen')  # 单信息类型批导
    import_single('1001->HR_BI_B007S3', r"x:/无单号-X420-销售建岗-郭运/07.1001_HR_BI_B007S3--人员导入--创建关系_S_03_B007.xlsx", 1, enter_mode='reopen')  # 单信息类型批导
    import_single('1001->HR_BI_A003SO', r"x:/无单号-X420-销售建岗-郭运/08.1001_HR_BI_A003SO--人员导入--指定岗位的隶属机构.xlsx", 1, enter_mode='reopen')  # 单信息类型批导
    import_single('1001->HR_BI_A012SO', r"x:/无单号-X420-销售建岗-郭运/06.1001_HR_BI_A012SO--人员导入--关系_S_O_A012.xlsx", 1, enter_mode='reopen')  # 单信息类型批导
    import_multi('重新录用/管理业务（服务）外包人员事件批导', 'x:/rpa_not_exist.xlsx')  # 多信息类型批导
