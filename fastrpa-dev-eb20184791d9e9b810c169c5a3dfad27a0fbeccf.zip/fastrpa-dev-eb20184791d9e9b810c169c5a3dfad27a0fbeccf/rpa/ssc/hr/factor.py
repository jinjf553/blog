#!/usr/bin/env python
# -*- coding: utf-8 -*-
# @File    : tmp.py
# @Author  : jinjianfeng
# @Contact : 553041800@qq.com
# @Link    : https://github.com/jinjf553
# @software: PyCharm
# @Date    : 2020/3/11 15:23
# @Version : ??
import logging
from functools import lru_cache

from pandas import DataFrame
from rpa.config import TEMPLATE_DIR
from rpa.fastrpa.adtable import load_from_xlsx_file
from rpa.fastrpa.log import config


@lru_cache()
def load_factor(filename: str) -> DataFrame:
    """读取系数页，并转化为DataFrame"""
    lt_factor = load_from_xlsx_file(filename, '系数')
    tmp = []
    for column in range(5, 1 + lt_factor.max_column):
        for row in range(4, 1 + lt_factor.max_row):
            cell = lt_factor[column][row]  # 单元格
            value = cell.value  # 系数
            busi_group = cell.same_line('A').value  # 工单对应业务组
            company_type = cell.same_line('B').value  # 企业类型
            company_code = cell.same_line('C').value  # 机构编码
            company_nm = cell.same_line('D').value  # 服务请求单位
            busi_type = cell.same_column('3').value  # 服务类型小类
            busi_parent_type = cell.same_column('1').find_to_left_until_no_empty().value  # 服务类型大类
            max_amount = int(lt_factor[column][2].value)  # 最大人次(超过最大人次则按最大人次计算人次)
            tmp.append(
                [busi_parent_type, busi_type, busi_group, company_type, company_code, company_nm, value, max_amount])
    df_sheet3 = DataFrame(tmp)
    df_sheet3.columns = ['服务类型大类', '服务类型小类', '工单对应业务组', '企业类型', '机构编码', '服务请求单位', '系数', '最大人次']
    df_sheet3['系数'] = df_sheet3['系数'].astype(float)
    df_sheet3 = df_sheet3[['服务类型大类', '服务类型小类', '企业类型', '机构编码', '服务请求单位', '工单对应业务组', '系数', '最大人次']]
    df_sheet3 = df_sheet3.copy(deep=True)
    return df_sheet3


@lru_cache()
def get_factor(company_code: str, busi_type: str) -> float:
    lt_factor = load_factor(f'{TEMPLATE_DIR}/工作量系数.xlsx')
    try:
        tmp = lt_factor[(lt_factor['机构编码'] == company_code) & (lt_factor['服务类型小类'] == busi_type)]
        return tmp['系数'].values[0]
    except Exception:
        return 1.0


# exmple
if __name__ == '__main__':
    config()
    logging.info(get_factor("10010009", "二级单位间调动"))
