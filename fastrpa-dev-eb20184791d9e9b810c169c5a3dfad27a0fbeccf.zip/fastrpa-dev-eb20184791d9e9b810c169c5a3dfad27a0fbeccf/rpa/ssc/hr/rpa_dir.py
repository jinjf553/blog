import datetime
from pathlib import Path

import rpa.config

RECENT_RPA_DIR: str = ''  # 最近一次生成的目录地址


def get_rpa_dir(subticket_type: str, subticket_title: str, is_succ: bool) -> str:
    """在本地生成文件夹，结果文件上传FTP前先保存至此文件夹，方便业务人员在本地查看
    :param subticket_type: 事件类型（如：岗位变动、员工入职、二级单位间调动、组织机构维护、内退）
    :param subticket_title: 事件标题（一般为事件模板名称，如：1000183882-X450-二级单位间调动-常盛）
    :param is_succ: 事件执行是否成功，True代表成功，False代表失败
    :return: 文件夹路径
    -----------------------------------------
    调用样例：
    from rpa.ssc.hr.rpa_dir import get_rpa_dir
    rpa_dir = get_rpa_dir('二级单位间调动', '1000183882-X450-二级单位间调动-常盛', True)
    # 返回值：x:/rpa/HR人事/二级单位间调动/202007/20200713/092142_成功_1000183882-X450-二级单位间调动-常盛
    """
    global RECENT_RPA_DIR
    yyyymm = datetime.datetime.now().strftime(r'%Y%m')
    yyyymmdd = datetime.datetime.now().strftime(r'%Y%m%d')
    hhmmss = datetime.datetime.now().strftime(r'%H%M%S')
    if is_succ is True:
        is_succ_str = '成功'
    else:
        is_succ_str = '失败'
    subticket_title = subticket_title.strip()
    rpa_dir = Path(f'{rpa.config.D_RPA}/HR人事').joinpath(subticket_type).joinpath(f'{yyyymm}/{yyyymmdd}').joinpath(f'{hhmmss}_{is_succ_str}_{subticket_title}')
    rpa_dir.mkdir(parents=True, exist_ok=True)
    RECENT_RPA_DIR = rpa_dir.as_posix()
    return RECENT_RPA_DIR


if __name__ == '__main__':
    print(get_rpa_dir('二级单位间调动', '1000183882-X450-二级单位间调动-常盛', True))
