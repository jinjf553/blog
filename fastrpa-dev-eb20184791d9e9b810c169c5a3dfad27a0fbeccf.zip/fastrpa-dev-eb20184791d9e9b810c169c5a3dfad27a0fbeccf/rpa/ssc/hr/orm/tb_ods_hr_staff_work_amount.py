# 工作量统计表
from rpa.ssc.hr.orm.base_model_hr import hr
from sqlalchemy import Boolean, Column, DateTime, Integer, String
from sqlalchemy.sql import func


class TB_ODS_HR_STAFF_WORK_AMOUNT(hr):
    """人事工作量汇总表（人事业务部手工统计，区别于RPA记录值）"""
    __tablename__ = 'tb_ods_hr_staff_work_amount'
    id = Column(Integer, nullable=False, primary_key=True, autoincrement=True)
    statis_year = Column(String(4), nullable=False, index=True, comment='年份')  # 2020
    day_begin = Column(String(8), nullable=False, index=True, comment='起始日')  # 20201224
    day_end = Column(String(8), nullable=False, index=True, comment='截止日')  # 20201230
    staff_id = Column(Integer, nullable=False, comment='STAFF_ID')  # 主键
    staff_group = Column(String(30), nullable=False, comment='业务组')  # 枚举值：人事一组、...、人事六组、服务支持岗
    staff_type = Column(String(30), nullable=False, comment='角色')  # 枚举值：组长、组员
    staff_name = Column(String(30), nullable=False, comment='维护人')  # 业务人员名称
    service_id = Column(String(20), nullable=False, comment='服务请求号')  # 一般为10位纯数字，也会有“无单号”的情况存在
    service_group = Column(String(30), nullable=False, comment='服务类型大类')  # 枚举值：事件类、信息类、专项类
    service_lgroup = Column(String(30), nullable=False, comment='服务类型小类')  # 枚举值：岗位变动、人员退休等
    amount = Column(Integer, nullable=False, comment='人次')
    service_corp = Column(String(30), nullable=False, comment='服务请求单位')  # 枚举值：河北石油、黑龙江石油等
    day_work = Column(String(8), nullable=False, comment='维护日期')  # 20201230
    coop_times = Column(Integer, default=0, comment='协同反馈次数')
    topic_name = Column(String(30), default='', comment='专项工作名称')
    is_p2p = Column(String(255), default='', comment='端到端相关')  # 枚举值：是、否，仅作存储和下载，不参与计算
    is_confirmed = Column(Boolean, default=False, comment='组长确认')  # 个人工作量经组长确认后才会计入业务部工作量
    create_time = Column(DateTime(timezone=True), server_default=func.now(), comment='创建时间')
    update_time = Column(DateTime(timezone=True), server_default=func.now(), onupdate=func.now(), comment='更新时间')
