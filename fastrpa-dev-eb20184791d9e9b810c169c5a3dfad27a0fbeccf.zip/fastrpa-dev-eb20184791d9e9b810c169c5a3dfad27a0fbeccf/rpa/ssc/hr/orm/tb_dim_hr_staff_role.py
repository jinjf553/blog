from rpa.ssc.hr.orm.base_model_hr import hr
from sqlalchemy import Column, DateTime, Integer, String
from sqlalchemy.sql import func


class TB_DIM_HR_STAFF_ROLE(hr):
    """人事人员-角色表"""
    __tablename__ = 'tb_dim_hr_staff_role'
    id = Column(Integer, nullable=False, primary_key=True, autoincrement=True)
    staff_id = Column(Integer, index=True, nullable=False)
    role_id = Column(Integer, index=True, nullable=False)
    editor_name = Column(String(30), comment='人员姓名')
    create_time = Column(DateTime(timezone=True), server_default=func.now(), comment='创建时间')
    update_time = Column(DateTime(timezone=True), server_default=func.now(), onupdate=func.now(), comment='更新时间')
