from rpa.ssc.hr.orm.base_model_hr import hr
from rpa.ssc.hr.orm.tb_hr_non_mid import TB_HR_NON_MID
from sqlalchemy import Column, DateTime, ForeignKey, Integer, String
from sqlalchemy.sql import func


class TB_HR_NON_MID_DETAIL(hr):
    __tablename__ = 'tb_hr_non_mid_detail'
    id = Column(Integer, primary_key=True)
    sr = Column(String(255), nullable=True)
    org_no = Column(String(255), nullable=True)
    personnel_area = Column(String(255), nullable=True)
    sr_id = Column(Integer, ForeignKey(TB_HR_NON_MID.id, name="tb_hr_non_mid_detail_ibfk_1", onupdate='RESTRICT', ondelete='RESTRICT'), comment='所属sr的ID')
    no = Column(String(255), nullable=False, comment="序号")
    org_class = Column(String(255), comment="机构维护类型")
    desc = Column(String(255), comment="描述")
    create_time = Column(DateTime(timezone=True), server_default=func.now(), comment='创建时间')
    update_time = Column(DateTime(timezone=True), server_default=func.now(), onupdate=func.now(), comment='更新时间')

    def __repr__(self) -> str:
        return str(self.id)
