#!/usr/bin/env python
# -*- coding: utf-8 -*-
# @File    : tb_user.py
# @Author  : jinjianfeng
from rpa.ssc.hr.orm.base_model_hr import hr
from sqlalchemy import Column, Integer, String


class User(hr):
    __tablename__ = 'tb_user'
    id = Column(Integer, nullable=False, primary_key=True, comment="序号")
    username = Column(String(255), nullable=False, comment="用户名")
    password = Column(String(255), comment="密码")
    parment = Column(String(255), comment="部门")
    business = Column(String(255), comment="业务")
    system = Column(String(255), comment="系统")
    address = Column(String(255), comment="地址")
    updatetime = Column(String(255), comment="更新时间")
    state = Column(String(255), comment="状态")
    remark = Column(String(255), comment="备注")

    def __repr__(self) -> str:
        return super().__repr__()

    def dict_(self) -> dict:
        return {'序号': self.id, "用户名": self.username, "密码": self.password, "部门": self.parment,
                "业务": self.business, "系统": self.system, "地址": self.address, "更新时间": self.updatetime,
                "状态": self.state, "备注": self.remark}
