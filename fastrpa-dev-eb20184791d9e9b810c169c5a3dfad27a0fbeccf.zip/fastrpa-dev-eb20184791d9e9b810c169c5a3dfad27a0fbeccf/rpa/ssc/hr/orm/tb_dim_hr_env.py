from rpa.ssc.hr.orm.base_model_hr import hr
from sqlalchemy import Column, DateTime, Integer, String
from sqlalchemy.sql import func


class TB_DIM_HR_ENV(hr):
    """人事环境变量表（存储Key-Value键对）"""
    __tablename__ = 'tb_dim_hr_env'
    id = Column(Integer, nullable=False, primary_key=True, autoincrement=True)
    key_name = Column(String(120), primary_key=True, unique=True, index=True, comment='键名')  # 枚举值：RPA、工具
    value = Column(String(255), primary_key=True, unique=True, comment='值')
    desc = Column(String(255), comment='字段描述')
    create_time = Column(DateTime(timezone=True), server_default=func.now(), comment='创建时间')
    update_time = Column(DateTime(timezone=True), server_default=func.now(), onupdate=func.now(), comment='更新时间')
