import datetime

from rpa.ssc.hr.orm.base_model_hr import hr
from sqlalchemy import Column, DateTime, Integer, String
from sqlalchemy.sql import func


class TB_HR_NON_MID(hr):
    __tablename__ = 'tb_hr_non_mid'
    id = Column(Integer, primary_key=True)
    sr = Column(String(255), nullable=False, comment="服务请求编号")
    name = Column(String(255), comment="名字")
    tab_name = Column(String(255), comment="excel名称")
    # break_point = Column(String(255), comment="断点描述") # 1000O | A002OO |空
    is_validate = Column(String(255), comment="规则库校验情况")
    start_time = Column(DateTime, default=datetime.datetime.now, comment='创建时间')
    end_time = Column(DateTime, comment='结束时间')
    use_time = Column(String(255), comment="耗时")
    desc = Column(String(255), comment="描述")
    remaker = Column(String(2550), comment="预留字段标注 成功/失败")
    create_time = Column(DateTime(timezone=True), server_default=func.now(), comment='创建时间')
    update_time = Column(DateTime(timezone=True), server_default=func.now(), onupdate=func.now(), comment='更新时间')

    def __repr__(self) -> str:
        return str(self.sr)
