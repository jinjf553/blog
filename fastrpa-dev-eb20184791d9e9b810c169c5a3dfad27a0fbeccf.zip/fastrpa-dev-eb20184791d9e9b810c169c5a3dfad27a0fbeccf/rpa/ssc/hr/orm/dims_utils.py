"""ORM库"""
import datetime
import re
from collections import defaultdict
from functools import lru_cache
from typing import Dict, Iterator, List

from pandas import DataFrame
from rpa.fastrpa.adtable import AdTable
from rpa.ssc.hr.orm.session import DbSession
from rpa.ssc.hr.orm.td_hr_gang_wei_diao_pei_rulebase import Event
from rpa.ssc.hr.orm.td_hr_li_tui_code_rulebase import LiTui


class DIMS_LINE():
    _df: DataFrame
    _rn: int

    def __init__(self, df: DataFrame, rn: int):
        self._df = df
        self._rn = rn

    def __getattr__(self, name):
        if name in self._df.columns:
            return self._df[name][self._rn]
        else:
            return ''


class DIMS_RULEBASE():
    df: DataFrame

    def __init__(self, df: DataFrame = DataFrame()):
        self.df = df

    def __iter__(self) -> Iterator[DIMS_LINE]:
        return iter([DIMS_LINE(self.df, rn) for rn in self.df.index])


@lru_cache()
def load_tb_dim_hr_diao_pei() -> AdTable:
    """加载调配码表库"""
    now = datetime.datetime.now().strftime(r'%Y%m%d%H%M%S')
    _dims = AdTable(f'调配码表库_{now}', skip_header=2)
    attrs: List[str] = []
    with DbSession() as session:
        for row, res in enumerate(session.query(Event).all(), start=3):
            attrs = [attr for attr in dir(res) if re.match('db_[A-Z]+', attr) is not None] if attrs == [] else attrs
            for attr in attrs:
                column = attr[3:]
                _dims[column][row].value = getattr(res, attr)  # 注意：码表库所有字段必须是str格式，前后空格由码表更新程序负责清理
    return _dims


@lru_cache()
def load_tb_dim_hr_li_tui() -> AdTable:
    """加载离退码表库"""
    now = datetime.datetime.now().strftime(r'%Y%m%d%H%M%S')
    _dims = AdTable(f'离退码表库_{now}', skip_header=2)
    attrs: List[str] = []
    with DbSession() as session:
        for row, res in enumerate(session.query(LiTui).all(), start=3):
            attrs = [attr for attr in dir(res) if re.match('rule_[A-Z]+', attr) is not None] if attrs == [] else attrs
            for attr in attrs:
                column = attr[5:]
                _dims[column][row].value = getattr(res, attr)  # 注意：码表库所有字段必须是str格式，前后空格由码表更新程序负责清理
    return _dims


_DIMS_DF_DICT: Dict[str, DIMS_RULEBASE] = defaultdict(DIMS_RULEBASE)  # 存放所有码表库的字典


@lru_cache()
def query_dims(dims_name: str):
    """加载码表库

    Args:
        dims_name (str): 码表库名称，枚举值：diao_pei、li_tui

    Returns:
        类sqlalchemy res对象

    Examples:
        rule_b = [res.B for res in query_dims('li_tui') if res.B]
    """
    if dims_name == 'diao_pei':
        return DIMS_RULEBASE(load_tb_dim_hr_diao_pei().to_dataframe())  # 加载码表库
    elif dims_name == 'li_tui':
        return DIMS_RULEBASE(load_tb_dim_hr_li_tui().to_dataframe())  # 加载码表库
    else:
        raise Exception('码表库名称必须为diao_pei或li_tui')


if __name__ == '__main__':
    rule_b = [res.B for res in query_dims('li_tui') if res.B]
