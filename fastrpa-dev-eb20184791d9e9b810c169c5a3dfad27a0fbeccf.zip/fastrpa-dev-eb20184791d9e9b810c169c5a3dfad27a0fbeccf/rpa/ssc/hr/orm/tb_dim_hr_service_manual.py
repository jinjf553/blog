# 工作量统计表


from rpa.ssc.hr.orm.base_model_hr import hr
from sqlalchemy import Column, DateTime, Integer, String
from sqlalchemy.sql import func


class TB_DIM_HR_SERVICE_MANUAL(hr):
    """工作量服务目录码表（提供服务目录-事件类型映射关系）"""
    __tablename__ = 'tb_dim_hr_service_manual'
    id = Column(Integer, nullable=False, primary_key=True, autoincrement=True)
    action_name = Column(String(16), nullable=False, index=True, comment='事件类型')  # 如：岗位变动
    service_id = Column(String(8), nullable=False, comment='服务目录')
    description = Column(String(128), comment='服务目录描述')
    create_time = Column(DateTime(timezone=True), server_default=func.now(), comment='创建时间')
    update_time = Column(DateTime(timezone=True), server_default=func.now(), onupdate=func.now(), comment='更新时间')
