from rpa.ssc.hr.orm.base_model_hr import hr
from sqlalchemy import CHAR, Column, DateTime, Integer, String
from sqlalchemy.orm import relationship
from sqlalchemy.sql import func


class TB_ODS_RPA_LOGIN(hr):
    """RPA运行状态记录明细表"""
    __tablename__ = 'tb_ods_rpa_login'
    id = Column(Integer, nullable=False, primary_key=True, autoincrement=True)
    rpa_id = Column(CHAR(120), primary_key=True, comment='RPA_ID', index=True)  # 主键 UUID1()
    mac_addr = Column(CHAR(17), comment='MAC地址')
    ip_addr = Column(String(18), comment='IP地址')
    hostname = Column(String(60), comment='主机名')
    username = Column(String(60), comment='用户名')
    busi_type = Column(String(60), comment='业务类型')  # 枚举值：扫单、拆单、各事件类型
    status = Column(Integer, comment='运行状态')  # 枚举值：0成功，1执行中，-1失败，注意：0成功仅代表RPA未抛出异常，不代表单子做成功了
    create_time = Column(DateTime(timezone=True), server_default=func.now(), comment='创建时间')
    update_time = Column(DateTime(timezone=True), server_default=func.now(), onupdate=func.now(), comment='更新时间')
    log_file = Column(String(255), default='', comment='日志文件')
    remark = Column(String(255), default='', comment='备注')
    subticket = relationship('TB_ODS_HR_SUBTICKET', uselist=False, backref='tb_ods_rpa_login')
