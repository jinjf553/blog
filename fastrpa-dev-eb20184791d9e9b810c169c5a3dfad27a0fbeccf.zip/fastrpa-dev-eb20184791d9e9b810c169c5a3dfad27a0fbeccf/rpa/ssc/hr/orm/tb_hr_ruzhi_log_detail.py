from rpa.ssc.hr.orm.base_model_hr import hr
from rpa.ssc.hr.orm.tb_hr_ruzhi_log import RZLog
from sqlalchemy import Column, DateTime, ForeignKey, Integer, String
from sqlalchemy.sql import func


class RZLog_detail(hr):
    __tablename__ = 'tb_hr_ruzhi_log_detail'
    id = Column(Integer, primary_key=True)
    create_time = Column(DateTime(timezone=True), server_default=func.now(), comment='创建时间')
    update_time = Column(DateTime(timezone=True), server_default=func.now(), onupdate=func.now(), comment='更新时间')
    sr = Column(String(255), ForeignKey(RZLog.sr, name="tb_hr_ruzhi_log_detail_ibfk_1", onupdate='RESTRICT', ondelete='RESTRICT'), comment="服务请求编号")
    name = Column(String(255), comment="人员姓名")
    code = Column(String(255), comment="人员编号")
    ywlx = Column(String(255), comment="业务类型（新入职，str(cell_columnletter)）")
    start_date = Column(String(255), comment="执行日期")
    sqjcjg = Column(String(255), comment="事前检查结果")
    picture = Column(String(255), comment="照片批导结果")
    shjcjg = Column(String(255), comment="事后检查结果")
    times = Column(Integer, comment="执行次数")
    remark = Column(String(255), comment="预留字段")

    def __repr__(self) -> str:
        return super().__repr__()
