from rpa.ssc.hr.orm.base_model_hr import hr
from rpa.ssc.hr.orm.tb_hr_sr import SR
from sqlalchemy import (Column, DateTime, ForeignKey, Integer, String,
                        UniqueConstraint)
from sqlalchemy.orm import relationship


class FlowTrack(hr):
    __tablename__ = 'tb_hr_whole_process_tracking'
    id = Column(Integer, primary_key=True, autoincrement=True)
    sr_id = Column(Integer, ForeignKey(SR.id, name="tb_hr_whole_process_tracking_ibfk_1", onupdate='RESTRICT', ondelete='RESTRICT'), comment="tb_hr_sr.id")
    worker = Column(String(20), comment="业务员")
    step = Column(String(255), nullable=False, comment="步骤")
    start_time = Column(DateTime, comment="开始时间")
    end_time = Column(DateTime, comment="结束时间")
    UniqueConstraint(sr_id, step, name='sr_step')

    to_sr = relationship("SR", backref="to_flow")

    def __repr__(self) -> str:
        return super().__repr__()
