from rpa.ssc.hr.orm.base_model_hr import hr
from sqlalchemy import CHAR, Column, DateTime, Integer, String
from sqlalchemy.sql import func


class TB_ODS_HR_TICKET(hr):
    """人事FSO工单记录明细表"""
    __tablename__ = 'tb_ods_hr_ticket'
    id = Column(Integer, nullable=False, primary_key=True, autoincrement=True)
    ticket_id = Column(String(120), primary_key=True, comment='TICKET_ID', index=True)  # 主键 sr_no
    rpa_id = Column(CHAR(120), comment='RPA_ID')  # 外键RPA_ID
    staff_id = Column(Integer, default=-1, comment='STAFF_ID')  # 外键STAFF_ID
    staff_name = Column(String(30), comment='人员姓名')
    ticket_from = Column(String(60), comment='工单发起方式')  # 枚举值：FSO、线下提报、数据质量检查
    ticket_name = Column(String(255), comment='工单标题')
    staff_area = Column(String(8), comment='人事范围')  # 人事范围与企业为多对一关系
    amount = Column(Integer, comment='工作量（人次）')
    create_time = Column(DateTime(timezone=True), server_default=func.now(), comment='创建时间')
    update_time = Column(DateTime(timezone=True), server_default=func.now(), onupdate=func.now(), comment='更新时间')
    remark = Column(String(255), default='', comment='备注')
