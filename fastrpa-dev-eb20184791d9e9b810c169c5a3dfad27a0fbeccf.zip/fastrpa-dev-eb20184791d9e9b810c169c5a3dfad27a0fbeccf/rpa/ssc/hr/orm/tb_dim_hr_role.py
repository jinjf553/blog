from rpa.ssc.hr.orm.base_model_hr import hr
from sqlalchemy import Boolean, Column, DateTime, Integer, String
from sqlalchemy.sql import func


class TB_DIM_HR_ROLE(hr):
    """人事角色表"""
    __tablename__ = 'tb_dim_hr_role'
    id = Column(Integer, nullable=False, primary_key=True, autoincrement=True)
    order_id = Column(Integer, comment='排序')
    role_name = Column(String(60), primary_key=True, unique=True, comment='角色名称')
    is_deleted = Column(Boolean, default=False, comment='是否删除')
    desc = Column(String(255), comment='角色描述')
    create_time = Column(DateTime(timezone=True), server_default=func.now(), comment='创建时间')
    update_time = Column(DateTime(timezone=True), server_default=func.now(), onupdate=func.now(), comment='更新时间')
