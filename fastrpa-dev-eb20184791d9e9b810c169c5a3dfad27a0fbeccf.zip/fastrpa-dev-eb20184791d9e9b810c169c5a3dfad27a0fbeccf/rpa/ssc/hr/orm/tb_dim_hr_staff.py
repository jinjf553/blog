
from rpa.ssc.hr.orm.base_model_hr import hr
from sqlalchemy import Boolean, Column, DateTime, Integer, String
from sqlalchemy.sql import func


class TB_DIM_HR_STAFF(hr):
    """人事业务人员信息码表"""
    __tablename__ = 'tb_dim_hr_staff'
    id = Column(Integer, nullable=False, primary_key=True, autoincrement=True)
    order_id = Column(Integer, comment='排序')
    staff_group = Column(String(30), comment='业务组')  # 枚举值：人事一组、...、人事六组、服务支持岗
    staff_type = Column(String(30), comment='角色')  # 枚举值：组长、组员
    staff_name = Column(String(30), comment='人员姓名')
    staff_pinyin = Column(String(30), comment='姓名拼音')
    phone_num = Column(String(13), comment='手机号码')
    tel_num = Column(String(13), comment='固化号码')
    email = Column(String(40), comment='邮箱')
    is_valid = Column(Integer, comment='用户状态')  # 枚举值：1有效、0无效（使用前必须判断用户状态）
    funj = Column(String(20), comment="员工FUNJ账号")
    fso_username = Column(String(255), comment="FSO账号")
    fso_password = Column(String(255), comment="FSO密码")
    fso_state = Column(Integer, comment="FSO账号状态")
    is_virtual_fso = Column(Boolean, default=False, comment='是否为虚拟FSO账号')  # 新人无FSO账号，为了能做业务，登记的是虚拟FSO账号
    win_username = Column(String(255), comment="Windows账号")
    ip_addr = Column(String(255), comment="IP地址")
    mac_addr = Column(String(255), comment="mac地址")
    hostname = Column(String(255), comment="计算机名")
    create_time = Column(DateTime(timezone=True), server_default=func.now(), comment='创建时间')
    update_time = Column(DateTime(timezone=True), server_default=func.now(), onupdate=func.now(), comment='更新时间')
