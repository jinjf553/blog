from rpa.ssc.hr.orm.base_model_hr import hr
from sqlalchemy import Column, DateTime, Integer, LargeBinary, String, Text
from sqlalchemy.sql import func


class kaoShiLog(hr):
    __tablename__ = 'tb_hr_kaoshi_log'
    id = Column(Integer, nullable=False, primary_key=True, autoincrement=True)
    create_time = Column(DateTime(timezone=True), server_default=func.now(), comment='创建时间')
    update_time = Column(DateTime(timezone=True), server_default=func.now(), onupdate=func.now(), comment='更新时间')
    name = Column(String(255), comment="员工姓名", nullable=False)
    mac = Column(String(255), comment="mac地址")
    sj_file = Column(Text, comment="试卷文件路径")
    lp_file = Column(Text, comment="录屏文件路径")
    shi_juan = Column(LargeBinary(length=(2**24) - 1), comment="试卷文件")
    lu_ping = Column(LargeBinary(length=(2**30) - 1), comment="录屏文件")
    grade = Column(Integer, comment="分数")
    remark1 = Column(Text, comment="预留字段")
    remark2 = Column(Text, comment="预留字段")
    remark3 = Column(Text, comment="预留字段")

    def __repr__(self) -> str:
        return super().__repr__()
