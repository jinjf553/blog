import datetime
import logging
import uuid
from contextlib import contextmanager
from pathlib import Path
from typing import List

import rpa.config
from rpa.fastrpa.net import get_hostname, get_ip, get_macaddr, get_username
from rpa.ssc.hr.orm.session import DbSession
from rpa.ssc.hr.orm.tb_dim_hr_service_manual import TB_DIM_HR_SERVICE_MANUAL
from rpa.ssc.hr.orm.tb_dim_hr_staff import TB_DIM_HR_STAFF
from rpa.ssc.hr.orm.tb_ods_hr_subticket import TB_ODS_HR_SUBTICKET
from rpa.ssc.hr.orm.tb_ods_hr_subticket_detail import \
    TB_ODS_HR_SUBTICKET_DETAIL
from rpa.ssc.hr.orm.tb_ods_hr_work_amount import TB_ODS_HR_WORK_AMOUNT
from rpa.ssc.hr.orm.tb_ods_rpa_login import TB_ODS_RPA_LOGIN
from rpa.ssc.hr.parse_template_info import parse_template_file
from rpa.ssc.hr.sap.export_103_t70 import export_103_t70
from sqlalchemy.sql import func


def find_staff_id_by_name(staff_name: str):
    """根据业务人员姓名获取业务人员ID"""
    with DbSession() as s:
        res = s.query(TB_DIM_HR_STAFF.id).filter(TB_DIM_HR_STAFF.staff_name == staff_name, TB_DIM_HR_STAFF.is_valid == 1).first()
        if res:
            staff_id = res[0]
        else:
            staff_id = -1
        return staff_id


def upload_rpa_log() -> str:
    """上传RPA运行日志文件至FTP，返回FTP路径文件名
       20200921变更：上传日志文件所在目录到ftp（因为360会随机终止RPA进程，存在日志未上传的问题，这里尽可能弥补日志缺失）
    """
    from rpa.public.myftp import MYFTP
    if Path(rpa.config.LOG_FILENAME).exists() is True and Path(rpa.config.LOG_FILENAME).is_file():
        with MYFTP() as my_ftp:
            remote_filename = Path(rpa.config.LOG_FILENAME).relative_to('d:').as_posix()  # 带时分秒前缀的，不用考虑文件名重复问题
            # my_ftp.upload_file_tree(Path(rpa.config.LOG_FILENAME).parent.as_posix(), Path(remote_filename).parent.as_posix(), False, False)
            logging.info('上传RPA日志到FTP')
            my_ftp.upload_file(Path(rpa.config.LOG_FILENAME).as_posix(), Path(remote_filename).as_posix())
            logging.info('【RPA】执行结束')
            my_ftp.upload_file(Path(rpa.config.LOG_FILENAME).as_posix(), Path(remote_filename).as_posix(), False, False)
        return remote_filename
    else:
        return ''


@contextmanager
def rpa_login(filename: str, staff_id: int = 0):
    """RPA启动时调用，在数据库中插入客户端信息"""
    rpa.config.FILENAME = filename
    rpa.config.SR_NO, rpa.config.STAFF_AREA, rpa.config.SUBTICKET_TYPE, rpa.config.STAFF_NAME, rpa.config.SAP_IDS, rpa.config.SAP_NAMES = parse_template_file(filename)
    rpa.config.RPA_ID = str(uuid.uuid1())  # RPA_ID
    mac_addr = get_macaddr()  # MAC地址
    ip_addr = get_ip()  # IP地址
    hostname = get_hostname()  # 主机名
    username = get_username()  # 用户名
    with DbSession() as s:
        # 插入登录记录
        s.add(TB_ODS_RPA_LOGIN(rpa_id=rpa.config.RPA_ID, mac_addr=mac_addr, ip_addr=ip_addr, hostname=hostname, username=username,
                               busi_type=rpa.config.SUBTICKET_TYPE, log_file=Path(rpa.config.LOG_FILENAME).relative_to('d:').as_posix(), status=1))
    try:
        logging.info('【RPA】开始执行')
        yield rpa.config.RPA_ID
        with DbSession() as s:
            s.query(TB_ODS_RPA_LOGIN).filter(TB_ODS_RPA_LOGIN.rpa_id == rpa.config.RPA_ID).update({'status': 0})
        # 更新登录记录状态为正常退出
    except Exception as e:
        with DbSession() as s:
            s.query(TB_ODS_RPA_LOGIN).filter(TB_ODS_RPA_LOGIN.rpa_id == rpa.config.RPA_ID).update(
                {'status': -1, 'remark': str(e)[:80]})
        raise e
    finally:
        upload_rpa_log()


@contextmanager
def rpa_step(step_name: str):
    """RPA中间步骤（暂不可用）"""
    if rpa.config.RPA_ID != '':
        pass


@contextmanager
def rpa_subticket(filename: str):
    """事件单执行时调用，记录事件信息、执行成功记录数（多次成功以第一次成功为准）"""
    rpa.config.KEY_ERROR = ''  # 关键性错误
    if rpa.config.RPA_ID != '':
        staff_id = find_staff_id_by_name(rpa.config.STAFF_NAME)
        if staff_id == -1:
            raise Exception(f'业务人员名称【{rpa.config.STAFF_NAME}】不在码表库中')
        rpa.config.SUBTICKET_ID = str(uuid.uuid1())
        amount = len(rpa.config.SAP_IDS)
        with DbSession() as s:
            s.add(TB_ODS_HR_SUBTICKET(ticket_id=rpa.config.SR_NO, subticket_id=rpa.config.SUBTICKET_ID, rpa_id=rpa.config.RPA_ID, staff_id=staff_id,
                                      staff_name=rpa.config.STAFF_NAME,
                                      sr_no=rpa.config.SR_NO, staff_area=rpa.config.STAFF_AREA, subticket_type=rpa.config.SUBTICKET_TYPE, amount=amount))
        yield rpa.config.SUBTICKET_ID
        with DbSession() as s:
            # 查询本次事件完成人数：查询相同SR号，相同事件类型，且成功次数为1的人员编号（大于1的说明以前已经做过了，这次是重复做，不计入本次成功）
            res = s.query(TB_ODS_HR_SUBTICKET_DETAIL.sap_id).filter(
                TB_ODS_HR_SUBTICKET_DETAIL.ticket_id == rpa.config.SR_NO,
                TB_ODS_HR_SUBTICKET_DETAIL.subticket_type == rpa.config.SUBTICKET_TYPE,
                TB_ODS_HR_SUBTICKET_DETAIL.status == 0).group_by(
                TB_ODS_HR_SUBTICKET_DETAIL.sap_id
            ).having(func.count('1') == 1).all()
            succ_sap_ids = [r[0] for r in res if r[0] in rpa.config.SAP_IDS]
            succ_amount = len(succ_sap_ids)
            s.query(TB_ODS_HR_SUBTICKET).filter(TB_ODS_HR_SUBTICKET.subticket_id == rpa.config.SUBTICKET_ID).update(
                {'succ_amount': succ_amount, 'key_error': rpa.config.KEY_ERROR})  # 更新人次，关键性错误信息


def rpa_work_amount(obj_ids: List[str] = []):
    """插入RPA执行明细结果，每一条记录的执行成功或失败，格式：[{'SR号': '','事件类型':'', '人事范围':'', '对象ID': '', '执行结果': True, '失败原因': ''}]，其中对象ID、执行结果是必填项，其他为选填"""
    if rpa.config.RPA_ID == '':  # 非启动器执行的事件
        logging.warning('非启动器执行的RPA不计入工作量')
        return
    if obj_ids == []:  # 如果事件RPA没有传参对象ID，则使用通用解析模板的结果
        obj_ids = rpa.config.SAP_IDS
    logging.info('正在写入工作量信息')
    logging.info(obj_ids)
    yyyymmdd = datetime.datetime.now().strftime(r'%Y%m%d')
    hhmmss = datetime.datetime.now().strftime(r'%H%M%S')
    service_ids = []  # 事件对应的服务目录编码（其中二级单位间调动、直属单位间调动对应多个服务目录编码）
    staff_group = ''
    staff_funj = ''  # 业务人员FUNJ账号
    with DbSession() as s:
        service_ids = [r[0] for r in s.query(TB_DIM_HR_SERVICE_MANUAL.service_id).filter(TB_DIM_HR_SERVICE_MANUAL.action_name == rpa.config.SUBTICKET_TYPE).all()]
        user_info: TB_DIM_HR_STAFF = s.query(TB_DIM_HR_STAFF).filter(TB_DIM_HR_STAFF.staff_name == rpa.config.STAFF_NAME).first()
        staff_funj = user_info.funj
        staff_group = user_info.staff_group
    if len(service_ids) == 0:
        # 出错时打印信息以便手工补偿数据
        # raise Exception(f'事件类型{rpa.config.SUBTICKET_TYPE}没有对应的服务目录')
        logging.error(f'事件类型：{rpa.config.SUBTICKET_TYPE}，没有对应的服务目录')
        logging.info(f'RPA_ID：{rpa.config.RPA_ID}')
        logging.info(f'SR_NO：{rpa.config.SR_NO}')
        logging.info(f'FILENAME：{rpa.config.FILENAME}')
    if rpa.config.SUBTICKET_TYPE in ('销售建岗', '炼化建岗'):
        obj_type = 'S'
    elif rpa.config.SUBTICKET_TYPE == '组织机构维护':
        obj_type = 'O'
    else:
        obj_type = 'P'
    if obj_type == 'P':  # 当人员时，需要导出103补充信息
        lt_103 = export_103_t70(None, obj_ids)
        lt_103['C'].apply(lambda v: v.replace('.', '').replace('/', '').replace('-', ''))  # 移除开始日期中间的点号
        df_103 = lt_103.to_dataframe()
        df_103.columns = ['人员编号', '姓名', '开始日期', '人事范围', '人事子范围', '人事子范围_文本', '人员组', '人员子组', '机构编码',
                          '组织机构', '岗位编码', '职务（岗位）具体名称', '工资范围', '工资总额控制范围', '成本中心']
        with DbSession() as s:
            for service_id in service_ids:  # 一个事件可能对应多个service_id
                for idx in df_103.index:
                    s.add(TB_ODS_HR_WORK_AMOUNT(statis_date=yyyymmdd,
                                                statis_time=hhmmss,
                                                staff_group=staff_group,
                                                staff_name=rpa.config.STAFF_NAME,
                                                staff_funj=staff_funj,
                                                rpa_funj='FUNJ0016',
                                                action_name=rpa.config.SUBTICKET_TYPE,
                                                action_type='I',
                                                service_id=service_id,
                                                obj_type=obj_type,
                                                obj_id=df_103['人员编号'][idx],
                                                begin_date=df_103['开始日期'][idx],
                                                staff_rng=df_103['人事范围'][idx],
                                                staff_srng=df_103['人事子范围'][idx],
                                                org_id=df_103['机构编码'][idx],
                                                job_id=df_103['岗位编码'][idx],
                                                pay_rng=df_103['工资范围'][idx],
                                                pay_mrng=df_103['工资总额控制范围'][idx],
                                                cost_center_id=df_103['成本中心'][idx],
                                                rpa_id=rpa.config.RPA_ID,
                                                sr_no=rpa.config.SR_NO,
                                                filename=rpa.config.FILENAME[:255]))
        # with DbSession('165') as s:
        #     for service_id in service_ids:  # 一个事件可能对应多个service_id
        #         for idx in df_103.index:
        #             s.add(TB_ODS_HR_WORK_AMOUNT(statis_date=yyyymmdd,
        #                                         statis_time=hhmmss,
        #                                         staff_group=staff_group,
        #                                         staff_name=rpa.config.STAFF_NAME,
        #                                         staff_funj=staff_funj,
        #                                         rpa_funj='FUNJ0016',
        #                                         action_name=rpa.config.SUBTICKET_TYPE,
        #                                         service_id=service_id,
        #                                         obj_type=obj_type,
        #                                         obj_id=df_103['人员编号'][idx],
        #                                         begin_date=df_103['开始日期'][idx],
        #                                         staff_rng=df_103['人事范围'][idx],
        #                                         staff_srng=df_103['人事子范围'][idx],
        #                                         org_id=df_103['机构编码'][idx],
        #                                         job_id=df_103['岗位编码'][idx],
        #                                         pay_rng=df_103['工资范围'][idx],
        #                                         pay_mrng=df_103['工资总额控制范围'][idx],
        #                                         cost_center_id=df_103['成本中心'][idx],
        #                                         rpa_id=rpa.config.RPA_ID,
        #                                         sr_no=rpa.config.SR_NO,
        #                                         filename=rpa.config.FILENAME[:255]))
    else:  # 当对象为机构、岗位时
        with DbSession() as s:
            for service_id in service_ids:  # 一个事件可能对应多个service_id
                for obj_id in obj_ids:
                    s.add(TB_ODS_HR_WORK_AMOUNT(statis_date=yyyymmdd,
                                                statis_time=hhmmss,
                                                staff_group=staff_group,
                                                staff_name=rpa.config.STAFF_NAME,
                                                staff_funj=staff_funj,
                                                rpa_funj='FUNJ0016',
                                                action_name=rpa.config.SUBTICKET_TYPE,
                                                service_id=service_id,
                                                obj_type=obj_type,
                                                obj_id=obj_id,
                                                begin_date='',
                                                staff_rng='',
                                                staff_srng='',
                                                org_id='',
                                                job_id='',
                                                pay_rng='',
                                                pay_mrng='',
                                                cost_center_id='',
                                                rpa_id=rpa.config.RPA_ID,
                                                sr_no=rpa.config.SR_NO,
                                                filename=rpa.config.FILENAME[:255]))
        # with DbSession('165') as s:
        #     for service_id in service_ids:  # 一个事件可能对应多个service_id
        #         for obj_id in obj_ids:
        #             s.add(TB_ODS_HR_WORK_AMOUNT(statis_date=yyyymmdd,
        #                                         statis_time=hhmmss,
        #                                         staff_group=staff_group,
        #                                         staff_name=rpa.config.STAFF_NAME,
        #                                         staff_funj=staff_funj,
        #                                         rpa_funj='FUNJ0016',
        #                                         action_name=rpa.config.SUBTICKET_TYPE,
        #                                         service_id=service_id,
        #                                         obj_type=obj_type,
        #                                         obj_id=obj_id,
        #                                         begin_date='',
        #                                         staff_rng='',
        #                                         staff_srng='',
        #                                         org_id='',
        #                                         job_id='',
        #                                         pay_rng='',
        #                                         pay_mrng='',
        #                                         cost_center_id='',
        #                                         rpa_id=rpa.config.RPA_ID,
        #                                         sr_no=rpa.config.SR_NO,
        #                                         filename=rpa.config.FILENAME[:255]))


# example
if __name__ == '__main__':
    pass
