#!/usr/bin/env python
# -*- coding: utf-8 -*-
# @Date    : 2019-03-17 14:44:03
import rpa
from rpa.ssc.hr.orm.session import DbSession
from rpa.ssc.hr.orm.tb_hr_gangweibiandong_log import Log
from sqlalchemy import and_
from sqlalchemy.ext.declarative import DeclarativeMeta


def get_session():
    with DbSession() as session:
        return session


def Query(table: DeclarativeMeta = Log, **kwargs):
    tup = ()
    for key, value in kwargs.items():
        eval_str = str(table)[8:-2] + "." + key
        tup = tup + (eval(eval_str) == value,)
    with DbSession() as session:
        for res in session.query(eval(str(table)[8:-2])).filter(and_(*tup)).all():
            yield res


def Insert(table: DeclarativeMeta = Log, **kwargs):
    with DbSession() as session:
        eval_str = str(table)[8:-2]
        obj = eval(eval_str)(**kwargs)
        session.add(obj)


def Update(table: DeclarativeMeta = Log, sr=None, **kwargs):
    if sr is None:
        raise Exception('id is required...')
    tup = ()
    for key, value in kwargs.items():
        eval_str = str(table)[8:-2] + '.' + key
        tup = tup + (eval(eval_str) == value,)
    with DbSession() as session:
        que = session.query(eval(str(table)[8:-2])).filter(eval(str(table)[8:-2] + '.' + 'sr') == sr)
        if que.all():
            que.update(kwargs)
        else:
            raise Exception('Not Found Any data!')
