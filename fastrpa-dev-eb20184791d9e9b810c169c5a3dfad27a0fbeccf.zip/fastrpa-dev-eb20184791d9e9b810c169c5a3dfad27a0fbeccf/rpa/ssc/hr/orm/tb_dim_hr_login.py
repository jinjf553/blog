from rpa.ssc.hr.orm.base_model_hr import hr
from sqlalchemy import CHAR, Column, DateTime, Integer, String
from sqlalchemy.sql import func


class TB_DIM_HR_LOGIN(hr):
    """Windows用户密码表"""
    __tablename__ = 'tb_dim_hr_login'
    id = Column(Integer, nullable=False, primary_key=True, autoincrement=True)
    mac_addr = Column(CHAR(17), index=True, comment='MAC地址')
    ip_addr = Column(String(18), comment='IP地址')
    hostname = Column(String(60), comment='主机名')
    win_username = Column(String(60), index=True, comment='用户名')
    win_password = Column(String(255), comment="Windows密码")
    create_time = Column(DateTime(timezone=True), index=True, server_default=func.now(), comment='创建时间')
    update_time = Column(DateTime(timezone=True), server_default=func.now(), onupdate=func.now(), comment='更新时间')
    remark = Column(String(255), default='', comment='备注')
