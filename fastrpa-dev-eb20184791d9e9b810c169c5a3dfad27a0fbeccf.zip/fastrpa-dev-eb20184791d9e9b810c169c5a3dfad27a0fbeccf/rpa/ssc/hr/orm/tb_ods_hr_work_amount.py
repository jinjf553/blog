# 工作量统计表


from rpa.ssc.hr.orm.base_model_hr import hr
from sqlalchemy import CHAR, Column, DateTime, Integer, String
from sqlalchemy.sql import func


class TB_ODS_HR_WORK_AMOUNT(hr):
    """人事工作量汇总表（回传总部平台用于展示）"""
    __tablename__ = 'tb_ods_hr_work_amount'
    id = Column(Integer, nullable=False, primary_key=True, autoincrement=True)
    statis_date = Column(String(8), index=True, comment='创建日期')  # yyyyMMdd
    statis_time = Column(String(6), comment='创建时间')  # HHmmss
    staff_group = Column(String(30), comment='用户组别')
    staff_name = Column(String(16), comment='用户姓名')
    staff_funj = Column(String(16), comment='用户FUNJ')
    rpa_funj = Column(String(16), comment='RPA_FUNJ')  # FUNJ0016
    action_name = Column(String(16), comment='事件类型名称')  # 如：岗位变动
    action_type = Column(CHAR(1), default="I", comment='操作类型')  # 枚举值：I、U、D（当前全为I，即新增）
    service_id = Column(String(16), comment='工作量服务目录编码')  # 关联码表 tb_dim_hr_service_manual
    obj_type = Column(String(2), comment='对象编码类型')  # 枚举值：O、P、S
    obj_id = Column(String(8), index=True, comment='对象编码')  # 机构编码、岗位编码、人员编码
    begin_date = Column(String(8), comment='开始日期')  # yyyyMMdd
    staff_rng = Column(String(8), comment='人事范围编码')  # 当obj_type=S时有值
    staff_srng = Column(String(8), comment='人事子范围编码')  # 当obj_type=S时有值
    org_id = Column(String(8), comment='机构编码')    # 当obj_type=S时有值
    job_id = Column(String(8), comment='岗位编码')    # 当obj_type=S时有值
    pay_rng = Column(String(8), comment='工资范围')  # 当obj_type=S时有值
    pay_mrng = Column(String(8), comment='工资总额控制范围')  # 当obj_type=S时有值
    cost_center_id = Column(String(20), comment='成本中心编码')  # 当obj_type=S时有值
    rpa_id = Column(CHAR(120), comment='RPA_ID', index=True)
    sr_no = Column(String(16), index=True, comment='SR号')
    filename = Column(String(256), comment='文件名')
    create_time = Column(DateTime(timezone=True), server_default=func.now(), comment='创建时间')
    update_time = Column(DateTime(timezone=True), server_default=func.now(), onupdate=func.now(), comment='更新时间')
