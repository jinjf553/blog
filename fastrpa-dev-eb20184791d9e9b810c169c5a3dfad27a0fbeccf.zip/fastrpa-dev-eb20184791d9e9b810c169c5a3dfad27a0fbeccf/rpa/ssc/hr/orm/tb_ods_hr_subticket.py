from rpa.ssc.hr.orm.base_model_hr import hr
from rpa.ssc.hr.orm.tb_ods_rpa_login import TB_ODS_RPA_LOGIN
from sqlalchemy import CHAR, Column, DateTime, ForeignKey, Integer, String
from sqlalchemy.sql import func


class TB_ODS_HR_SUBTICKET(hr):
    """人事事件工单记录明细表（由FSO派生的事件工单）"""
    __tablename__ = 'tb_ods_hr_subticket'
    id = Column(Integer, nullable=False, primary_key=True, autoincrement=True)
    ticket_id = Column(String(120), comment='TICKET_ID', index=True)  # sr_no
    subticket_id = Column(String(120), primary_key=True, index=True, comment='SUBTICKET_ID')
    rpa_id = Column(CHAR(120), ForeignKey(TB_ODS_RPA_LOGIN.rpa_id, name="tb_ods_hr_subticket_ibfk_1", onupdate='RESTRICT', ondelete='RESTRICT'), comment='RPA_ID')
    staff_id = Column(Integer, default=-1, comment='STAFF_ID')  # 外键STAFF_ID
    staff_name = Column(String(30), comment='人员姓名')
    sr_no = Column(String(120), comment='工单SR号')
    staff_area = Column(String(10), comment='人事范围')
    subticket_type = Column(String(30), comment='事件类型')
    succ_amount = Column(Integer, default=0, comment='成功工作量（人次）')
    amount = Column(Integer, comment='工作量（人次）')
    create_time = Column(DateTime(timezone=True), server_default=func.now(), comment='创建时间')
    update_time = Column(DateTime(timezone=True), server_default=func.now(), onupdate=func.now(), comment='更新时间')
    remark = Column(String(255), default='', comment='备注')
    key_error = Column(String(255), default='', comment='关键性错误')
