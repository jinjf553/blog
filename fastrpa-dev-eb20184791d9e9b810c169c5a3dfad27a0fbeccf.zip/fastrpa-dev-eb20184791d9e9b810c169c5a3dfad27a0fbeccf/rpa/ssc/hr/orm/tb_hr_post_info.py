from rpa.ssc.hr.orm.base_model_hr import hr
from sqlalchemy import Column, DateTime, Integer, String
from sqlalchemy.sql import func


class PostInfo(hr):
    __tablename__ = 'tb_hr_post_info'
    id = Column(Integer, primary_key=True, autoincrement=True)
    file_id = Column(String(255), comment="文件id")
    post = Column(String(20), nullable=False, unique=True, comment="RPA生成的岗位编码")
    C = Column(String(255), comment="岗位所在机构编码")
    D = Column(String(255), comment="参照岗位")
    E = Column(String(255), comment="对应企业岗位目录行编号")
    F = Column(String(255), comment="执行时间")
    G = Column(String(255), comment="岗位简称")
    H = Column(String(255), comment="岗位全称")
    F2 = Column(String(255), comment="职务（岗位）编码02码")
    F4 = Column(String(255), comment="岗位分类序列")
    G4 = Column(String(255), comment="所属专业类别")
    H4 = Column(String(255), comment="所属专业名称")
    J4 = Column(String(255), comment="所属工种类别")
    K4 = Column(String(255), comment="所属工种")
    L4 = Column(String(255), comment="工种名称")
    M4 = Column(String(255), comment="薪酬标杆岗位类别")
    N4 = Column(String(255), comment="企业岗位分类")
    Q4 = Column(String(255), comment="岗位工时制")
    F5 = Column(String(255), comment="控制范围")
    F6 = Column(String(255), comment="职务（岗位）编码03码")
    I = Column(String(255), comment="岗位类别")
    J = Column(String(255), comment="油品销售企业定员标准未覆盖标识")
    K = Column(String(255), comment="班组长标识")
    L = Column(String(255), comment="虚岗位标识")
    M = Column(String(255), comment="岗位财科成本中心")
    N = Column(String(255), comment="岗位财科公司代码")
    O = Column(String(255), comment="岗位财科业务范围")
    P = Column(String(255), comment="岗位财科人事范围")
    Q = Column(String(255), comment="岗位财科人事子范围")
    R = Column(String(255), comment="岗位成本分配成本中心")
    create_time = Column(DateTime(timezone=True), server_default=func.now(), comment='创建时间')
    update_time = Column(DateTime(timezone=True), server_default=func.now(), onupdate=func.now(), comment='更新时间')
    remark = Column(String(255), comment="备用字段")

    # update_time = Column(DateTime, comment="上次更新时间")
    # info = Column(Text, comment="历史更新信息")

    def __repr__(self) -> str:
        return super().__repr__()
