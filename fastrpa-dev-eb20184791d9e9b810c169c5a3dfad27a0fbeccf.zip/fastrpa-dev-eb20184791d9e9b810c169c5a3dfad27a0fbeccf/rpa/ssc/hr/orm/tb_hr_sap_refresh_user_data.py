from rpa.ssc.hr.orm.base_model_hr import hr
from sqlalchemy import CHAR, Boolean, Column, DateTime, Integer, String
from sqlalchemy.sql import func


class TB_HR_SAP_REFRESH_USER_DATA(hr):
    """结构化刷新日志表（记录业务人员SAP账号结构化刷新成功、失败、耗时日志）"""
    __tablename__ = 'tb_hr_sap_refresh_user_data'
    id = Column(Integer, nullable=False, primary_key=True, autoincrement=True)
    rpa_id = Column(CHAR(120), comment='RPA_ID', index=True)  # 主键 UUID1()
    staff_group = Column(String(30), comment='业务组')  # 枚举值：人事一组、...、人事六组、服务支持岗
    staff_id = Column(Integer, default=-1, comment='STAFF_ID')  # 外键STAFF_ID
    staff_name = Column(String(30), comment='人员姓名')
    sr_no = Column(String(120), comment='工单SR号')
    busi_type = Column(String(60), comment='业务类型')  # 枚举值：扫单、拆单、各事件类型
    dur_seconds = Column(Integer, default=0, comment='结构化刷新耗时（秒）')
    is_succ = Column(Boolean, default=False, comment='运行状态')
    log_file = Column(String(255), default='', comment='日志文件')
    remark = Column(String(255), default='', comment='备注')
    create_time = Column(DateTime(timezone=True), server_default=func.now(), comment='创建时间')
    update_time = Column(DateTime(timezone=True), server_default=func.now(), onupdate=func.now(), comment='更新时间')
