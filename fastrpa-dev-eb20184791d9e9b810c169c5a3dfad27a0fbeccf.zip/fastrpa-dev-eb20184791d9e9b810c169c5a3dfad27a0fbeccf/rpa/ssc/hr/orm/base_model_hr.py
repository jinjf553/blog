from rpa.config import SRC_PASD, SRC_PORT, SRC_URL, SRC_USER
from sqlalchemy import Column, DateTime, Integer
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.sql import func

hr = declarative_base()
hr.__name__ = 'hr'
hr.id = Column(Integer, nullable=False, primary_key=True, autoincrement=True)
hr.create_time = Column(DateTime(timezone=True), server_default=func.now(), comment='创建时间')
hr.update_time = Column(DateTime(timezone=True), server_default=func.now(), onupdate=func.now(), comment='更新时间')

database_config = {
    '155': {
        'url': SRC_URL,
        'port': SRC_PORT,
        'user': SRC_USER,
        'password': SRC_PASD,
        'dbname': 'hr',
        'base': hr
    },

    '165': {
        'url': '10.133.8.165',
        'port': '13306',
        'user': 'HR_RPA',
        'password': 'HRrpa2020',
        'dbname': 'hr',
        'base': hr
    }
}
