#!/usr/bin/env python
# -*- coding: utf-8 -*-
# @File    : td_hr_li_tui_code_rulebase.py
# @Author  : jinjianfeng
from rpa.ssc.hr.orm.base_model_hr import hr
from sqlalchemy import Column, Integer, String


# 离退码表库
class LiTui(hr):
    __tablename__ = 'td_hr_li_tui_code_rulebase'
    id = Column(Integer, nullable=False, primary_key=True)
    db_A = Column(String(24))  # 事件类型
    db_B = Column(String(4))  # B
    db_C = Column(String(72))  # 编码
    db_D = Column(String(188))  # 码值
    db_E = Column(String(20))  # 人事范围
    db_F = Column(String(92))  # 人事子范围
    db_G = Column(String(36))  # 岗位编号
    db_H = Column(String(108))  # 岗位名称
    db_I = Column(String(116))  # 工资核算范围
    db_J = Column(String(116))  # 工资总额控制范围
    db_K = Column(String(24))  # 原因
    db_L = Column(String(4))  # 备注
    db_M = Column(String(4))  # 功能范围
    db_N = Column(String(4))  # 业务范围
    db_O = Column(String(4))  # O
    db_P = Column(String(52))  # 内退事件原因
    db_Q = Column(String(44))  # 离退休事件原因
    db_R = Column(String(68))  # 离退休减册事件原因
    db_S = Column(String(136))  # 离职事件原因
    db_T = Column(String(28))  # 解除终止类型
    db_U = Column(String(136))  # 匹配人员增减变动信息
    db_V = Column(String(132))  # 匹配人员增减变动信息
    db_W = Column(String(32))  # 离退休类别
    db_X = Column(String(24))  # 待遇级别
    db_Y = Column(String(32))  # 离退休人员来源
    db_Z = Column(String(32))  # 离退休原因对应人员子组

    def __repr__(self) -> str:
        return super().__repr__()
