from rpa.ssc.hr.orm.base_model_hr import hr
from sqlalchemy import Column, DateTime, Integer, String
from sqlalchemy.sql import func


class SR(hr):
    __tablename__ = 'tb_hr_sr'
    id = Column(Integer, primary_key=True, autoincrement=True)
    sr = Column(String(20), nullable=False, primary_key=True, unique=True, comment="服务请求编号")
    create_time = Column(DateTime(timezone=True), server_default=func.now(), comment='创建时间')
    update_time = Column(DateTime(timezone=True), server_default=func.now(), onupdate=func.now(), comment='更新时间')
    state = Column(String(255), comment="状态")

    # update_time = Column(DateTime, comment="上次更新时间")
    # info = Column(Text, comment="历史更新信息")

    def __repr__(self) -> str:
        return super().__repr__()
