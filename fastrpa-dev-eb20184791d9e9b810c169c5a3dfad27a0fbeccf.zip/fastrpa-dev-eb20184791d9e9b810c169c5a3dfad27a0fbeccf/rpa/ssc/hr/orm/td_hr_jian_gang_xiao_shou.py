from rpa.ssc.hr.orm.base_model_hr import hr
from sqlalchemy import Column, Integer, String


# 建岗（销售企业）码表库
class TD_HR_JIAN_GANG_XIAO_SHOU(hr):
    __tablename__ = 'td_hr_jian_gang_xiao_shou'
    id = Column(Integer, nullable=False, primary_key=True)
    db_A = Column(String(48))  # 编号
    db_B = Column(String(88))  # 机构
    db_C = Column(String(36))  # 职务岗位码
    db_D = Column(String(120))  # 职务（岗位）
    db_E = Column(String(64))  # 岗位简称
    db_F = Column(String(164))  # 薪酬标杆
    db_G = Column(String(40))  # 所属专业大类
    db_H = Column(String(60))  # 所属专业小类
    db_I = Column(String(48))  # 所属工种大类
    db_J = Column(String(64))  # 所属工种小类
    db_K = Column(String(40))  # 岗位工时制
    db_L = Column(String(120))  # 岗位类别-A-关键岗位
    db_M = Column(String(80))  # 岗位类别-B1-非辅助性主体岗位
    db_N = Column(String(80))  # 岗位类别-B2-辅助性主体岗位
    db_O = Column(String(88))  # 岗位类别-C0-销售企业特定普通岗位
    db_P = Column(String(88))  # 岗位类别-C1-非辅助性普通岗位
    db_Q = Column(String(80))  # 岗位类别-C2-辅助性普通岗位
    db_R = Column(String(36))  # 职位序列
    db_S = Column(String(148))  # 职位级别
    db_T = Column(String(380))  # 行政党派职务信息
    db_U = Column(String(144))  # 报表提取位置
    db_V = Column(String(24))  # 油品销售企业定员标准未覆盖标识（计划删除）
    db_W = Column(String(60))  # 销售企业特有属性
    db_X = Column(String(4))   # 备注

    def __repr__(self) -> str:
        return super().__repr__()
