#!/usr/bin/env python
# -*- coding: utf-8 -*-
# @File    : tb_hr_gangweibiandong_log.py
# @Author  : jinjianfeng
from rpa.ssc.hr.orm.base_model_hr import hr
from sqlalchemy import DECIMAL, Column, DateTime, Integer, String
from sqlalchemy.sql import func


class Log(hr):
    __tablename__ = 'tb_hr_gangweibiandong_log'
    id = Column(Integer, primary_key=True)
    sr = Column(String(255), nullable=False, comment="服务请求编号")
    code = Column(String(255), comment="人事范围编码")
    content = Column(String(255), comment="服务对象")
    comment = Column(String(255), comment="业务摘要")
    date = Column(String(255), comment="创建日期")
    people_num = Column(String(255), comment="人数")
    worker = Column(String(255), comment="业务人员")
    step = Column(String(255), comment="服务请求状态")
    result = Column(String(255), comment="拆单结果")
    mjml = Column(String(255), comment="末级目录")
    zubie = Column(String(255), comment="组别")
    start_time = Column(String(255), comment="拆单开始时间")
    end_time = Column(String(255), comment="拆单结束时间")
    type = Column(String(255), comment="拆单方式（自动or手动）")
    grade = Column(DECIMAL(10, 2), comment="分数")
    remark = Column(String(255), comment="预留字段")
    create_time = Column(DateTime(timezone=True), server_default=func.now(), comment='创建时间')
    update_time = Column(DateTime(timezone=True), server_default=func.now(), onupdate=func.now(), comment='更新时间')

    def __repr__(self) -> str:
        return super().__repr__()
