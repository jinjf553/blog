from rpa.ssc.hr.orm.base_model_hr import hr
from sqlalchemy import Column, DateTime, Integer, String
from sqlalchemy.sql import func


class RZLog(hr):
    __tablename__ = 'tb_hr_ruzhi_log'
    id = Column(Integer, primary_key=True, autoincrement=True)
    sr = Column(String(255), nullable=False, primary_key=True, unique=True, index=True, comment="服务请求编号")
    code = Column(String(255), comment="人事范围编码")
    content = Column(String(255), comment="服务对象")
    comment = Column(String(255), comment="业务摘要")
    date = Column(String(255), comment="创建日期")
    people_num = Column(String(255), comment="人数")
    worker = Column(String(255), comment="业务人员")
    step = Column(String(255), comment="执行状态")
    result = Column(String(255), comment="结果")
    remark = Column(String(255), comment="预留字段")
    create_time = Column(DateTime(timezone=True), server_default=func.now(), comment='创建时间')
    update_time = Column(DateTime(timezone=True), server_default=func.now(), onupdate=func.now(), comment='更新时间')

    def __repr__(self) -> str:
        return super().__repr__()
