from rpa.ssc.hr.orm.base_model_hr import hr
from sqlalchemy import Column, DateTime, Integer, String
from sqlalchemy.sql import func


class TB_ODS_HR_SUBTICKET_DETAIL(hr):
    """人事事件工单工作量明细表（由FSO派生的事件工单）"""
    __tablename__ = 'tb_ods_hr_subticket_detail'
    id = Column(Integer, nullable=False, primary_key=True, autoincrement=True)
    ticket_id = Column(String(120), comment='TICKET_ID', index=True)
    subticket_id = Column(String(120), primary_key=True, comment='SUBTICKET_ID', index=True)
    subticket_type = Column(String(30), comment='事件类型')
    sap_id = Column(String(10), primary_key=True, comment='SAP对象编号')
    # sap_staff_nm = Column(String(30), comment='人员姓名')
    status = Column(Integer, comment='状态')  # 枚举值：0成功，-1失败
    create_time = Column(DateTime(timezone=True), server_default=func.now(), comment='创建时间')
    update_time = Column(DateTime(timezone=True), server_default=func.now(), onupdate=func.now(), comment='更新时间')
    remark = Column(String(255), default='', comment='备注')
