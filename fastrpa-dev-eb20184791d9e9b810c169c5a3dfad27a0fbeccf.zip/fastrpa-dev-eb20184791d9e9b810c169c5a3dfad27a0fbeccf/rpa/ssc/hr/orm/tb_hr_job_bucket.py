from enum import Enum

from rpa.ssc.hr.orm.base_model_hr import hr
from sqlalchemy import CHAR, Column, DateTime, Integer, String
from sqlalchemy.sql import func


class JOB_STATUS(Enum):
    """岗位状态枚举类
       ------------------
       各状态间转换关系:
           新创建岗位，状态置为READY
           分配给指定模板，状态由READY置为INUSE
           如模板校验未通过，清空inuse_date、template_name、template_uuid、template_rn，状态由INUSE重新置为READY
           如模板校验通过，超过inuse_date 48小时，岗位不在机构parent_org_id下，状态由INUSE重新置为SUCC
           如模板校验通过，超过inuse_date 48小时，岗位仍在机构parent_org_id下，定界岗位，状态由INUSE重新置为TIMEOUT
           状态转换时预期外的状态，置为ERROR
        ------------------
    """
    READY = 1  # 新创建岗位，可用
    INUSE = 20  # 已分配给指定模板
    SUCC = 30  # 已分配岗位（此时岗位已不在该机构下）
    TIMEOUT = 40  # 超时未使用，已定界（此时岗位已不在该机构下）
    ERROR = 50  # 状态异常（通常是岗位在数据库中是READY状态，机构下不存在）


class TB_HR_JOB_BUCKET(hr):
    """岗位池"""
    __tablename__ = 'tb_hr_job_bucket'
    id = Column(Integer, primary_key=True, autoincrement=True)
    parent_org_id = Column(CHAR(8), nullable=False, index=True, comment="父节点机构编码")
    begin_date = Column(CHAR(8), default='', index=True, comment="岗位创建日期")  # yyyymmdd格式，一般为执行时3月前1号
    job_id = Column(CHAR(8), nullable=False, primary_key=True, unique=True, index=True, comment="岗位编码")
    job_short_name = Column(String(36), nullable=False, comment="岗位简称")
    job_full_name = Column(String(120), nullable=False, comment="岗位全称")
    inuse_date = Column(CHAR(8), default='', index=True, comment="岗位使用日期")  # yyyymmdd
    template_name = Column(String(255), default='', comment="模板名称")
    template_uuid = Column(String(40), default='', index=True, comment="模板UUID")  # 如果分配到模板，此为模板UUID
    template_rn = Column(Integer, default=0, comment='模板行号')  # 如果分配到模板，此为对应模板行号
    job_status = Column(Integer, default=JOB_STATUS.READY.value, index=True, comment='运行状态')  # 枚举值，见枚举类JOB_STATUS
    remark = Column(String(255), default='', comment="备用字段")
    create_time = Column(DateTime(timezone=True), server_default=func.now(), comment='创建时间')
    update_time = Column(DateTime(timezone=True), server_default=func.now(), onupdate=func.now(), comment='更新时间')

    def __repr__(self) -> str:
        return super().__repr__()
