from rpa.ssc.hr.orm.base_model_hr import hr
from sqlalchemy import Column, DateTime, Integer, String
from sqlalchemy.sql import func


class Friends(hr):
    __tablename__ = 'dingding_friends'
    id = Column(Integer, primary_key=True, autoincrement=True, comment='id')
    create_time = Column(DateTime(timezone=True), server_default=func.now(), comment='创建时间')
    update_time = Column(DateTime(timezone=True), server_default=func.now(), onupdate=func.now(), comment='更新时间')
    nick = Column(String(255), comment="昵称")
    uid = Column(String(255), comment="uid")
    alias = Column(String(255), comment="备注")
    ding_id = Column(String(255), comment="钉钉ID")
    space_id = Column(String(255), comment="SpaceId")
    state = Column(String(255), comment="状态")

    def __repr__(self) -> str:
        return super().__repr__()
