"""mysql数据库访问模块.

   重要设置: 通过mysql_insert_ignore修改Sqlalchemy ORM，insert时，相同ID的对象将被忽略.
"""
import logging
from contextlib import contextmanager
from functools import lru_cache
from typing import Iterator

from rpa.config import TIMEOUT
from rpa.ssc.hr.orm.all_tables import *  # noqa: F401, F403
from rpa.ssc.hr.orm.base_model_hr import database_config
from sqlalchemy import create_engine
from sqlalchemy.ext.compiler import compiles
from sqlalchemy.ext.declarative import DeclarativeMeta
from sqlalchemy.orm import scoped_session, sessionmaker
from sqlalchemy.sql import Insert
from sqlalchemy_utils import create_database, database_exists


@compiles(Insert, "mysql")
def mysql_insert_ignore(insert, compiler, **kw):
    """相同主键插入数据库时，忽略不报错"""
    return compiler.visit_insert(insert.prefix_with("IGNORE"), **kw)


@lru_cache()
def _create_engine(database: DeclarativeMeta, user: str, password: str, url: str, port: str, db_name: str, timeout: int, echo: bool):
    engine = create_engine(f"mysql+mysqlconnector://{user}:{password}@{url}:{port}/{db_name}", max_overflow=timeout, echo=echo, pool_recycle=3600, pool_size=5, pool_pre_ping=True)
    if not database_exists(engine.url):
        create_database(engine.url)
    database.metadata.create_all(engine)  # 创建表
    return engine


@contextmanager
def Engine(database: str = '155', echo=False) -> Iterator[scoped_session]:  # noqa: N802
    """参数:
            database='155' HR服务器MySQL数据库配置
                     ,'165' IT服务器MySQL数据库配置
            如调用成功，scoped_session 对象
    """
    database_, db_name = database_config[database]['base'], database_config[database]['dbname']
    src_url, src_port = database_config[database]['url'], database_config[database]['port']
    src_user, src_pasd = database_config[database]['user'], database_config[database]['password']
    try:
        yield _create_engine(database_, src_user, src_pasd, src_url, src_port, db_name, TIMEOUT, echo)
    except Exception as e:
        if database != "165":
            raise e
        yield None


@contextmanager
def DbSession(database: str = '155') -> Iterator[scoped_session]:  # noqa: N802
    """参数:
            database='155' HR服务器MySQL数据库配置
                     ,'165' IT服务器MySQL数据库配置
            如调用成功，scoped_session 对象
    """
    with Engine(database) as engine:
        session = scoped_session(sessionmaker(bind=engine))()
        try:
            yield session
            session.commit()
        except Exception as e:
            session.rollback()
            # logging.error(e)
            if database != "165":  # 165异常时继续保证业务正常结束
                # logging.info("工作量上传165服务器异常，跳过异常继续执行后续步骤。")
                raise e
        finally:
            session.close()


if __name__ == '__main__':
    # with DbSession('165') as s:
    #     s.add(TB_ODS_HR_WORK_AMOUNT(staff_name='常盛'))
    #     res = s.query(TB_ODS_HR_WORK_AMOUNT)
    #     print(res.first().staff_name)
    pass
