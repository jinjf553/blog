from rpa.ssc.hr.orm.base_model_hr import hr
from sqlalchemy import Column, DateTime, Integer, String
from sqlalchemy.sql import func


class TB_DIM_HR_ROLE_PERMISSION(hr):
    """人事角色-权限表"""
    __tablename__ = 'tb_dim_hr_role_permission'
    id = Column(Integer, nullable=False, primary_key=True, autoincrement=True)
    role_id = Column(Integer, index=True, nullable=False)
    permission_id = Column(Integer, index=True, nullable=False)
    editor_name = Column(String(30), comment='人员姓名')
    create_time = Column(DateTime(timezone=True), server_default=func.now(), comment='创建时间')
    update_time = Column(DateTime(timezone=True), server_default=func.now(), onupdate=func.now(), comment='更新时间')
