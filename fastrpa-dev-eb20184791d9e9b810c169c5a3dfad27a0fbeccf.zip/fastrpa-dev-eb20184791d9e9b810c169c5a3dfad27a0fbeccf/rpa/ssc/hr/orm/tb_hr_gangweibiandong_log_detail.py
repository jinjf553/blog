from rpa.ssc.hr.orm.base_model_hr import hr
from rpa.ssc.hr.orm.tb_hr_gangweibiandong_log import Log
from sqlalchemy import (DECIMAL, Column, DateTime, ForeignKey, Integer, String,
                        Text)
from sqlalchemy.orm import relationship
from sqlalchemy.sql import func


class LogDetail(hr):
    __tablename__ = 'tb_hr_gangweibiandong_log_detail'
    id = Column(Integer, primary_key=True)
    log_id = Column(Integer, ForeignKey(Log.id, name="tb_hr_gangweibiandong_log_detail_ibfk_1", onupdate='RESTRICT', ondelete='RESTRICT'), comment="Log.id")
    sr = Column(String(10), nullable=False, comment="服务请求编号")
    business_type = Column(String(20), comment="事件类型")
    people_num = Column(Integer, comment="人数")
    grade = Column(DECIMAL(10, 2), comment="分数")
    code = Column(String(20), comment="人事范围")
    ins_code = Column(String(20), comment="机构编码")
    remark = Column(Text, comment="预留字段")
    to_log = relationship("Log", backref="to_detail")
    create_time = Column(DateTime(timezone=True), server_default=func.now(), comment='创建时间')
    update_time = Column(DateTime(timezone=True), server_default=func.now(), onupdate=func.now(), comment='更新时间')

    def __repr__(self) -> str:
        return super().__repr__()
