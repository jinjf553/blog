from pathlib import Path

import rpa.config
from rpa.fastrpa.adtable import load_from_xlsx_file
from rpa.ssc.hr.orm.session import DbSession
from rpa.ssc.hr.orm.td_hr_gang_wei_diao_pei_rulebase import Event
from rpa.ssc.sap.utils import init_sap_id


def parse_template_file(filename: str):
    """解析人事模板信息
    返回值：
    sr_no: SR号
    staff_area: 人事范围
    subticket_type: 事件类型(如：员工入职、大学生入职、岗位变动、组织机构维护、二级单位间调动、离职等)
    staff_name: 业务人员名称
    sap_ids: SAP对象编号数组（人员编号、机构编号）
    sap_names: SAP对象名称数组（人员姓名、机构名称）
    """
    if filename[-5:].lower() != '.xlsx':
        raise Exception(f'文件扩展名必须为.xlsx，选定文件名：{filename}')
    argslist = Path(filename).name[:-5].split('-')
    if len(argslist) < 4:
        raise Exception(f'事件模板名格式应为：（sr-人事范围-事件类型-业务人员.xlsx），选定文件名：{filename}')
    sr_no, staff_area, subticket_type, staff_name = argslist[:4]
    if subticket_type not in ('销售建岗', '重新录用', '员工入职', '大学生入职', '岗位变动', '组织机构维护', '二级单位间调动', '直属单位间调动', '离职', '内退', '劳务工退回', '离退休减册', '离岗', '不在岗变动'):
        raise Exception(f'暂时只支持解析销售建岗、重新录用、员工入职、大学生入职、岗位变动、组织机构维护、二级单位间调动、直属单位间调动、离职、内退、劳务工退回、离退休减册、离岗、不在岗变动事件模板，选定文件名：{filename}')
    if subticket_type in ('销售建岗'):
        lt = load_from_xlsx_file(filename, skip_header=5)
        lt.del_blank_rows_by_column('B')
        sap_ids = lt['A'].values  # RPA生成的岗位编码（都为空值，做完才有值）
        sap_names = lt['G'].values  # 岗位简称
    if subticket_type in ('岗位变动', '重新录用', '离职', '内退', '劳务工退回', '离退休减册', '离岗', '不在岗变动'):
        lt = load_from_xlsx_file(filename, skip_header=6)
        lt.del_blank_rows_by_column('B')
        sap_ids = lt['B'].values
        sap_names = lt['C'].values
    elif subticket_type in ('员工入职', '大学生入职'):
        lt = load_from_xlsx_file(filename, skip_header=6)
        lt.del_blank_rows_by_column('B')
        sap_ids = lt['CA'].values
        sap_names = lt['B'].values
    elif subticket_type == '组织机构维护':
        lt = load_from_xlsx_file(filename, skip_header=7)
        lt.del_blank_rows_by_column('C')
        sap_ids = lt['C'].values
        sap_names = lt['E'].values
    elif subticket_type in ('二级单位间调动', '直属单位间调动'):
        lt = load_from_xlsx_file(filename, skip_header=6)
        lt.del_blank_rows_by_column('B')
        sap_ids = lt['B'].values
        sap_names = lt['C'].values
    else:
        sap_ids = []
        sap_names = []
    sap_ids = [init_sap_id(sap_staff_id) for sap_staff_id in sap_ids]
    if rpa.config.STAFF_GROUP in ['人事一组', '人事二组', '人事三组', '人事四组', '人事五组', '人事六组', 'RPA团队']:
        staff_areas = []
        with DbSession() as db_session:
            res = db_session.query(Event.db_BJ).filter(Event.db_BL == rpa.config.STAFF_GROUP)
            staff_areas = list(set([r[0] for r in res]))
        if len(staff_areas) > 0 and staff_area not in staff_areas:
            raise Exception(f'只能处理本组人事范围的模板，{rpa.config.STAFF_GROUP}人事范围码值：{staff_areas}')
    return sr_no, staff_area, subticket_type, staff_name, sap_ids, sap_names
