"""存放RPA枚举值"""
from enum import Enum


class STAFF_GROUP(Enum):
    """组别"""
    HR_GROUP_RPA = 'RPA团队'
    HR_GROUP1 = '人事一组'
    HR_GROUP2 = '人事二组'
    HR_GROUP3 = '人事三组'
    HR_GROUP4 = '人事四组'
    HR_GROUP5 = '人事五组'
    HR_GROUP6 = '人事六组'
    PAY_GROUP1 = '薪酬一组'
    PAY_GROUP2 = '薪酬二组'
    PAY_GROUP3 = '薪酬三组'
    PAY_GROUP4 = '薪酬四组'
    PAY_GROUP5 = '薪酬五组'
    PAY_GROUP6 = '薪酬六组'


if __name__ == '__main__':
    print(STAFF_GROUP.HR_GROUP_RPA.name)  # HR_GROUP_RPA
    print(STAFF_GROUP.HR_GROUP_RPA.value)  # RPA团队
    staff_names = [staff_group.name for staff_group in STAFF_GROUP]
    staff_values = [staff_group.value for staff_group in STAFF_GROUP]
