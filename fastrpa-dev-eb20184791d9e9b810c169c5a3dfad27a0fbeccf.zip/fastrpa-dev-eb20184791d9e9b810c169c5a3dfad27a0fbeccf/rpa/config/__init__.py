# mypy: ignore-errors
import datetime
import os
import sys
from pathlib import Path
from threading import Thread
from typing import List, Optional

import win32file
from rpa.config.RPAConfig_dev import PASD, PORT, SALT, URL, USER
from rpa.fastrpa.third_party.isa import decrypt
from rpa.fastrpa.utils.system_dir import get_desktop_dir
from websockets.server import WebSocketServerProtocol
from webview.window import Window

# ===========================================
if True:
    D_RPA = 'd:/rpa'
    for i in range(100, 123):  # d-z
        if win32file.GetDriveType(f'{chr(i)}:') == 3:  # 本地磁盘或闪存
            D_RPA = f'{chr(i)}:/rpa'
            break
    else:
        D_RPA = 'c:/rpa'
    WORKING_DIR = getattr(sys, '_MEIPASS') if hasattr(sys, '_MEIPASS') is True else Path(__file__).parent.parent.parent.as_posix()  # 代码根目录
    os.chdir(WORKING_DIR)  # 将当前目录设置为根目录
    FASTRPA_DIR = WORKING_DIR
    IS_PROD_MODE = not Path(WORKING_DIR).joinpath('.dev').exists()
    RESOURCE_DIR = Path(WORKING_DIR).joinpath('resources').as_posix()  # 模板文件夹路径
    TEMPLATE_DIR = Path(WORKING_DIR).joinpath('resources/templates').as_posix()  # 模板文件夹路径
    IS_PYINSTALLER_EXE = hasattr(sys, '_MEIPASS')  # 是否是EXE打包后程序，如果是，则禁用某些功能（如Git代码更新检测）
    if IS_PYINSTALLER_EXE is True:
        EXE_DIR = Path(sys.executable).parent.as_posix()
    else:
        EXE_DIR = WORKING_DIR  # EXE程序所在路径或工作目录
    SRC_URL, SRC_PORT, SRC_USER, SRC_PASD = decrypt([URL, PORT, USER, PASD])  # TODO 优化性能
    SRC_PASD = SRC_PASD + SALT
    RPA_TEMP_DIR = f'{D_RPA}/temp'  # 临时文件路径
    Path(RPA_TEMP_DIR).mkdir(parents=True, exist_ok=True)
    RPA_SCREENSHOTS_DIR = f'{D_RPA}/screenshots'  # 屏幕截图路径
    Path(RPA_SCREENSHOTS_DIR).mkdir(parents=True, exist_ok=True)
# ===========================================
APPDATA_DIR = Path(str(os.environ.get("APPDATA"))).as_posix()
CHROME_DRIVER_EXE_PATH = Path(f'{D_RPA}/安装包/谷歌浏览器').joinpath('chromedriver.exe').as_posix()
DESKTOP_DIR = get_desktop_dir()
IS_DEBUGGING_MODE = hasattr(sys, 'gettrace') and sys.gettrace() is not None  # 是否处于调试状态
TIMEOUT = 5000  # MySQL连接超时时间
# ===========================================
LASTEST_GIT_COMMIT_HEAD = ''  # 程序commit版本，发布时由build.py填充
# ===========================================运行时全局变量，由rpa_launcher登录过程写入
WEBAPI_PORT: int = 19527
if 'ONLY_RPA_SERVER' in os.environ.keys():
    WEBAPI_PORT = 29527
# 业务人员FUNJ(人员注册时写入数据库，登录时从数据库读取，登录个人SAP账号时验证SAP FUNJ与注册时提交的是否一致)
SAP_FUNJ: str = ''
FSO_USERNAME: str = ''  # 业务人员FSO用户名
STAFF_GROUP: str = ''  # 人员组别：如人事一组
STAFF_ID: int = 0  # 人员编码，TB_DIM_HR_STAFF自增ID
STAFF_NAME: str = ''  # 人员姓名
STAFF_TYPE: str = ''  # 人员类型：组长、组员
APP_HWND: int = 0  # APP 窗口句柄
MAIN_WINDOW: Window = None  # 主窗口标识
LAUNCH_BEGIN_TIME = datetime.datetime.now().strftime(r'%Y-%m-%d %H:%M:%S')  # 启动日期
LAUNCH_END_TIME = (datetime.datetime.now() + datetime.timedelta(days=1)).strftime('%Y-%m-%d 07:00:00')  # 次日7点强制重启更新，否则不能做单子
RPC_LOG_TEXT: WebSocketServerProtocol = None  # websocket日志接口
RPC_FRONT_END: WebSocketServerProtocol = None  # websocket功能接口
WORKER_THREAD: Optional[Thread] = None  # 后台工作进程
WORKERPROCESS_LAUNCH_SAP_GUI: Optional[Thread] = None  # 后台工作进程
LOG_TEXT: List[str] = []
LOG_FILENAME = ''  # 日志文件名
RPA_USERNAME = 'fastrpa'
RPA_PASSWORD = ''  # nosec
WIN_USERNAME = ''
WIN_PASSWORD = ''  # nosec
# ===========================================运行时全局变量，由事件RPA执行期写入
RPA_ID = ''  # RPA_ID(uuid)
SR_NO = ''  # SR号(一般为10位)
STAFF_AREA = ''  # 人事范围
SUBTICKET_ID = ''  # 事件单ID
SUBTICKET_TYPE = ''  # 事件类型（员工入职、岗位变动、组织机构维护、二级单位间调动）
SAP_IDS: List[str] = []  # 对象ID（一般为人员编码、机构编码）
SAP_NAMES: List[str] = []  # 对象名称（一般为人员名称、机构名称）
FILENAME = ''  # 事件模板名称（全路径）
KEY_ERROR = ''  # RPA运行时关键性错误，需要通知用户及时处理，并由专人跟踪结果
# ===========================================
