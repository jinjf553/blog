#!/usr/bin/env python
# mypy: ignore-errors


URL = 'uMTAuMTU1KiMIyoxMC4xMzM='
PORT = 'MwNiojIyoxMz'
USER = 'GEqIwIypyc=='
PASD = 'JwYSojIypyc3'
DBNAME = 'ciojIypo'
SALT = ''
TIMEOUT = 5000  # 超时时间
