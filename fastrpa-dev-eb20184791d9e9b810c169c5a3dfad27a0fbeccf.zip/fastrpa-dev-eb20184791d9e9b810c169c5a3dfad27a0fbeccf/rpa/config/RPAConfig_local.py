#!/usr/bin/env python
# mypy: ignore-errors


URL = 'Ghvc3QqIwIypsb2Nhb=='
PORT = 'MwNiojIyoxMz'
USER = 'GEqIwIypyc=='
PASD = 'dGVzdCojIypycGEu'
DBNAME = 'ciojIypo'
SALT = ''
TIMEOUT = 5000  # 超时时间
