#!/usr/bin/env python
# mypy: ignore-errors


import datetime

URL = 'uOC4xNjUqIwIyoxMC4xMzM=='
PORT = 'MwNiojIyoxMz'
USER = 'GEqIwIypyc=='
PASD = 'LklUQCojIypneG5m'
DBNAME = 'YmFzZSojIypydWxl'
SALT = str(datetime.datetime.now().year) + str((int(datetime.datetime.now().month) - 1) // 3 + 1)
TIMEOUT = 5000  # 超时时间
