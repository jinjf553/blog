
import functools
import logging
import os
import traceback
import webbrowser
from pathlib import Path
from threading import Thread
from time import sleep
from typing import Callable, Dict, List

import rpa.config
import rpa.ssc_rpa.hr.rpa_jian_gang.main as jian_gang
import webview
from rpa.fastrpa.named_lock import NamedLock
from rpa.fastrpa.net import get_username
from rpa.fastrpa.sap.session import SapClose, close_sap
from rpa.fastrpa.third_party.isa import decrypt
from rpa.fastrpa.utils.git import get_lastest_git_commit_head
from rpa.fastrpa.utils.win_user import (check_win_login,
                                        check_win_login_locked,
                                        get_server_port,
                                        launch_server_from_rpa_user,
                                        logoff_user, open_user_accounts)
from rpa.fastrpa.utils.window import (activate_window, find_window,
                                      get_open_file_name,
                                      get_save_as_file_name,
                                      get_window_class_name, get_windws_list,
                                      maximum_window, message_box_ok,
                                      message_box_okcancel, open_dir,
                                      pass_sapgui_err_window, restore_window,
                                      set_topmost, set_window_icon)
from webview.platforms.edgechromium import EdgeChrome
from webview.window import Window


def update_rpa_shell():
    import winreg
    from pathlib import Path
    from time import sleep

    import requests
    sleep(10)  # 等待10秒钟，rpa_shell退出
    rpa_shell_path = ''
    rpa_shell_version = ''
    winreg.CreateKey(winreg.HKEY_LOCAL_MACHINE, r'SOFTWARE\FASTRPA\RPA_SHELL')  # 为避免key不存在打开时报错，要先创建
    with winreg.OpenKey(winreg.HKEY_LOCAL_MACHINE, r'SOFTWARE\FASTRPA\RPA_SHELL', 0, winreg.KEY_QUERY_VALUE) as key:
        rpa_shell_path: str = winreg.QueryValueEx(key, 'RPA_SHELL_PATH')[0]
        rpa_shell_version: str = winreg.QueryValueEx(key, 'RPA_SHELL_VERSION')[0]
    server_rpa_shell_version = requests.get('http://10.133.10.155:19530/fastrpa/rpa_shell.exe.version').content.decode('utf-8')
    if rpa_shell_version not in ['', server_rpa_shell_version]:  # 更新rpa_sehll
        Path(rpa_shell_path).parent.mkdir(parents=True, exist_ok=True)
        Path(rpa_shell_path).write_bytes(requests.get('http://10.133.10.155:19530/fastrpa/rpa_shell.exe').content)  # 下载新版本


def start_init_funcs():
    from rpa.fastrpa.date_funcs import sync_sys_time
    from rpa.fastrpa.obs.obs import init_obs
    from rpa.fastrpa.quit_360 import _init as quit_360
    from rpa.fastrpa.sap.session import init_chromium
    from rpa.fastrpa.third_party.dont_sleep import dont_sleep
    from rpa.fastrpa.utils.clean_pyinstaller_cache_file import \
        clean_pyinstaller_cache
    from rpa.fastrpa.utils.fix_tkinter_path import fix_tkinter_path
    for _f in [sync_sys_time, quit_360, init_obs, init_chromium, dont_sleep, fix_tkinter_path, clean_pyinstaller_cache, update_rpa_shell, pass_sapgui_err_window]:
        _t = Thread(target=_f, args=())
        _t.setDaemon(True)
        _t.start()


LOCALIZATION = {
    'global.quitConfirmation': u'是否要退出程序？',
    'global.saveFile': u'是否保存文件？',
    'windows.fileFilter.allFiles': u'所有文件',
    'windows.fileFilter.otherFiles': u'其他文件',
}


def fix_edge_chromium_console():
    """pywebview在debug=True时，会将console.log重定向至python的标准输出，调试js输出不方便
       此函数在在debug=False时，rpa.config.IS_PROD_MODE=True时打开devtools，方便调试
    """
    old_on_webview_ready = EdgeChrome.on_webview_ready

    def new_on_webview_ready(self, sender, args):
        old_on_webview_ready(self, sender, args)
        settings = sender.CoreWebView2.Settings
        settings.AreDefaultContextMenusEnabled = not rpa.config.IS_PROD_MODE
        settings.AreDevToolsEnabled = not rpa.config.IS_PROD_MODE
        settings.IsStatusBarEnabled = not rpa.config.IS_PROD_MODE
    EdgeChrome.on_webview_ready = new_on_webview_ready


fix_edge_chromium_console()


def js_api_better_err_info(func: Callable) -> Callable:
    @functools.wraps(func)
    def foo(*args):
        try:
            return func(*args)
        except Exception as e:
            logging.error(e)
            logging.error(traceback.format_exc())
            raise Exception(f'错误信息: {e}\n\n{traceback.format_exc(20)}')
    return foo


class Api(object):
    win_username: str = ''
    win_password: str = ''
    rpa_username: str = 'fastrpa'
    rpa_password: str = str(decrypt('VUR3FIViojIypSMzNUdH'))
    fso_username: str = ''
    fso_password: str = ''

    def __init__(self):
        from rpa_launcher.backend.ws.user import get_login_info
        if get_login_info() is True:  # 获取当前[MAC地址-用户]的Windows用户名和密码
            self.win_username = rpa.config.WIN_USERNAME
            self.win_password = rpa.config.WIN_PASSWORD
        else:
            self.win_username = get_username()

    def get_bucket_dst_job_count(self) -> int:
        return jian_gang.get_bucket_dst_job_count()

    @js_api_better_err_info
    def chk_win_login_locked(self, win_username: str, win_password: str):
        check_win_login_locked(win_username, win_password)

    @js_api_better_err_info
    def open_control_user_accounts(self):
        open_user_accounts()

    @js_api_better_err_info
    def is_win_login_info_right(self) -> bool:
        from rpa_launcher.backend.ws.user import get_login_info
        return get_login_info()

    @js_api_better_err_info
    def get_win_username(self) -> str:
        return get_username()

    @js_api_better_err_info
    def update_win(self, win_username: str, win_password: str) -> None:
        from rpa_launcher.backend.ws.user import update_login_info
        if check_win_login(win_username, win_password):
            self.win_username = win_username
            self.win_password = win_password
            update_login_info(win_username, win_password)

    @js_api_better_err_info
    def update_fso(self, fso_username: str, fso_password: str) -> None:
        self.fso_username = fso_username
        self.fso_password = fso_password

    @js_api_better_err_info
    def get_win(self) -> List[str]:
        return [self.win_username, self.win_password]

    @js_api_better_err_info
    def get_fso(self) -> List[str]:
        return [self.fso_username, self.fso_password]

    @js_api_better_err_info
    def win32_app_hwnd(self) -> int:
        """刷新窗口句柄"""
        app_hwnd = find_window(None, '人事RPA平台')
        if app_hwnd and rpa.config.APP_HWND == 0:
            rpa.config.APP_HWND = app_hwnd
        return rpa.config.APP_HWND

    @js_api_better_err_info
    def win32_topmost(self) -> bool:
        """窗口置顶"""
        return set_topmost(rpa.config.APP_HWND)

    @js_api_better_err_info
    def win32_activate_window(self):
        """激活窗口"""
        return activate_window(rpa.config.APP_HWND)

    @js_api_better_err_info
    def win32_message_box_ok(self, message: str, title: str) -> None:
        """弹出消息确认框"""
        restore_window(rpa.config.APP_HWND)
        message_box_ok(rpa.config.APP_HWND, str(message), title)

    @js_api_better_err_info
    def message_box_okcancel(self, message: str, title: str):
        """弹出消息确认框"""
        restore_window(rpa.config.APP_HWND)
        return message_box_okcancel(rpa.config.APP_HWND, message, title)

    @js_api_better_err_info
    def win32_open_file(self) -> str:
        """打开Excel 文件对话框"""
        restore_window(rpa.config.APP_HWND)
        file_types = ('xlsx 文件 (*.xlsx)',)
        filename = ''
        if rpa.config.APP_HWND:
            filename = get_open_file_name(rpa.config.APP_HWND)
        elif rpa.config.MAIN_WINDOW is not None:
            filename = rpa.config.MAIN_WINDOW.create_file_dialog(webview.OPEN_DIALOG, allow_multiple=False, file_types=file_types)
            filename = filename[0] if isinstance(filename, tuple) else ''
        return filename

    @js_api_better_err_info
    def win32_save_as(self, default_filename: str = '') -> str:
        """打开Excel 文件对话框"""
        restore_window(rpa.config.APP_HWND)
        file_types = ('xlsx 文件 (*.xlsx)',)
        filename = ''
        if rpa.config.APP_HWND:
            filename = get_save_as_file_name(rpa.config.APP_HWND, default_filename=default_filename)
        elif rpa.config.MAIN_WINDOW is not None:
            filename = rpa.config.MAIN_WINDOW.create_file_dialog(webview.SAVE_DIALOG, allow_multiple=False, file_types=file_types, save_filename=default_filename)
        return filename

    @js_api_better_err_info
    def win32_open_dir(self) -> str:
        """打开文件夹对话框"""
        restore_window(rpa.config.APP_HWND)
        dirname = ''
        try:
            dirname = open_dir(rpa.config.APP_HWND)
        except Exception:  # nosec
            pass
        return dirname

    @js_api_better_err_info
    def win32_open_url(self, url: str):
        """用系统默认浏览器打开url（默认是用webview打开的，部分网页不兼容）"""
        webbrowser.open(url)

    @js_api_better_err_info
    def launch_sap_gui(self):
        """快捷登录SAP"""
        from rpa_launcher.backend.ws.sap import run_launch_sap_gui
        run_launch_sap_gui()

    @js_api_better_err_info
    def launch_ftp(self):
        """快捷登录FTP"""
        from rpa_launcher.backend.ws.ftp import open_ftp_by_explorer
        open_ftp_by_explorer()

    @js_api_better_err_info
    def win32_check_win_login(self, win_username: str, win_password: str):
        return check_win_login(win_username, win_password)

    @js_api_better_err_info
    def get_webapi_port(self):
        """获取当前用户连接的端口"""
        return rpa.config.WEBAPI_PORT

    @js_api_better_err_info
    def get_rpa_webapi_port(self):
        """获取rpa用户的webapi端口"""
        return get_server_port(self.rpa_username)

    @js_api_better_err_info
    def launch_ws_on_other_user(self):
        """启动后台应用"""
        launch_server_from_rpa_user(self.win_username, self.win_password, self.rpa_username, self.rpa_password)


def on_loaded():  # 网页加载或刷新DOM就绪时执行（先于网页js执行）
    # 修复 TypeError: console.warn is not a function 在 debug=True 时报错的问题
    # 提供动态websocket server端口给前端
    if rpa.config.MAIN_WINDOW is not None:
        rpa.config.MAIN_WINDOW.evaluate_js(f'''
            console.error = console.log;
            console.warn = console.log;
            console.info = console.log;
            pywebview.webapi_port = {rpa.config.WEBAPI_PORT};
            ''')


def on_init(_: Window):
    # 程序首次加载时执行
    icon_path = Path(rpa.config.WORKING_DIR).joinpath('resources/images/icons/256.ico').as_posix()
    for _ in range(2000):
        sleep(0.1)
        hwnd_dict: Dict[int, str] = get_windws_list()
        for _hwnd, _title in hwnd_dict.items():
            if _title == '人事RPA平台':
                window_class_name = get_window_class_name(_hwnd)
                if window_class_name.startswith('WindowsForms'):
                    rpa.config.APP_HWND = _hwnd
                    set_window_icon(rpa.config.APP_HWND, icon_path)  # 设置窗口图标
                    maximum_window(rpa.config.APP_HWND)
                    activate_window(rpa.config.APP_HWND)
                    return


def on_closed():
    """窗口关闭前执行"""
    logoff_user(rpa.config.RPA_USERNAME)
    close_sap()
    os._exit(0)


def main():
    from rpa_launcher.backend.main import main as websocket_server
    _t0 = Thread(target=logoff_user, args=(rpa.config.RPA_USERNAME,))
    _t0.setDaemon(True)
    _t0.start()
    _t1 = Thread(target=websocket_server, args=())
    _t1.setDaemon(True)
    _t1.start()
    _t1 = Thread(target=start_init_funcs, args=())
    _t1.setDaemon(True)
    _t1.start()
    with SapClose():
        if rpa.config.IS_PROD_MODE is True:
            rpadash_url = 'http://10.133.10.155:19526'
        else:
            rpadash_url = 'http://localhost:19526'
        try:
            with NamedLock('rpa_launcher', 0):
                api = Api()
                rpa.config.MAIN_WINDOW = webview.create_window('人事RPA平台', rpadash_url, js_api=api, background_color='#2b6cb0', width=1850, height=1000, min_size=(1850, 1000), confirm_close=True, text_select=True)
                rpa.config.MAIN_WINDOW.loaded += on_loaded
                rpa.config.MAIN_WINDOW.closed += on_closed
                webview.start(on_init, rpa.config.MAIN_WINDOW, gui='chromium', localization=LOCALIZATION, debug=False)
                logoff_user(rpa.config.RPA_USERNAME)
        except TimeoutError:
            message_box_ok(0, '程序重复运行，请先关闭上一次打开的窗口。', '人事RPA平台')


if __name__ == '__main__':
    from rpa.fastrpa.log import config
    config()
    if rpa.config.LASTEST_GIT_COMMIT_HEAD == '':
        rpa.config.LASTEST_GIT_COMMIT_HEAD = get_lastest_git_commit_head()  # 开发模式下
    main()
