import asyncio
import logging
import os
from threading import Thread

import rpa.config
import websockets
from rpa.fastrpa.log import logfn2
from rpa.fastrpa.net import get_unused_port
from rpa.fastrpa.sharedstate import SharedState
from rpa.fastrpa.third_party.sap import init_sap_config
from rpa.fastrpa.utils.git import get_lastest_git_commit_head
from rpa.fastrpa.utils.window import pass_sapgui_err_window
from rpa_launcher.backend.ws.rpc import websocket_endpoint


def _websocket_server(webapi_port=19527):
    with SharedState('WEBAPI_PORT', str(webapi_port)) as _:
        try:
            asyncio.get_event_loop()
        except RuntimeError:
            asyncio.set_event_loop(asyncio.new_event_loop())
        asyncio.get_event_loop().run_until_complete(
            websockets.serve(websocket_endpoint, '0.0.0.0', webapi_port))  # nosec
        asyncio.get_event_loop().run_forever()


@logfn2
def main(webapi_port=19527):
    for _f in [pass_sapgui_err_window]:
        _t = Thread(target=_f, args=())
        _t.setDaemon(True)
        _t.start()
    if 'ONLY_RPA_SERVER' in os.environ.keys():
        webapi_port = 29527
        init_sap_config()
    webapi_port = get_unused_port(webapi_port)  # 如果端口被占用则选用下一个端口
    rpa.config.WEBAPI_PORT = webapi_port
    logging.info(webapi_port)
    _websocket_server(webapi_port)


if __name__ == '__main__':
    if rpa.config.LASTEST_GIT_COMMIT_HEAD == '':
        rpa.config.LASTEST_GIT_COMMIT_HEAD = get_lastest_git_commit_head()  # 开发模式下
    main()
