import logging
import traceback
from typing import Optional

import rpa.config
from passlib import pwd
from passlib.context import CryptContext
from rpa.fastrpa.net import get_hostname, get_ip, get_macaddr, get_username
from rpa.fastrpa.third_party.isa import decrypt, encrypt
from rpa.ssc.fso.check_fso_login import check_fso_login
from rpa.ssc.hr.orm.session import DbSession
from rpa.ssc.hr.orm.tb_dim_hr_staff import TB_DIM_HR_STAFF
from rpa_launcher.backend.ws.dispatcher import add_rpc_method

pwd_context = CryptContext(schemes=["bcrypt"], deprecated="auto")


def hash_password(password: str) -> str:
    """hash密码"""
    # return pwd_context.hash(password)
    return str(encrypt(password))


def generate_password(length: int = 8) -> str:
    """生成随机密码"""
    return pwd.genword(length=length)


@add_rpc_method(name="/auth/login")
def login(fso_username: str, fso_password: str) -> bool:
    with DbSession() as s:
        user: Optional[TB_DIM_HR_STAFF] = s.query(TB_DIM_HR_STAFF).filter(TB_DIM_HR_STAFF.fso_username == fso_username).first()
        if user is None:
            raise Exception("用户不存在")
        if user.is_valid != 1:
            raise Exception("当前用户被锁定")
        funj = user.funj
        try:
            if user.is_virtual_fso is True:  # 20210117调整：FSO系统认证接口变化，暂时使用数据库中账号信息做验证
                if fso_password != decrypt(user.fso_password):
                    raise Exception('FSO账号或者密码错误')
            else:
                check_fso_login(fso_username, fso_password)  # 每次都用FSO系统的登录系统验证用户密码
        except Exception as e:
            logging.error(f"异常原因: {traceback.format_exc()}")
            raise Exception('校验FSO账号登录信息失败，错误信息：' + str(e))
        user.fso_password = encrypt(fso_password)  # 验证通过，则用更新数据库旧密码
        user.win_username = get_username()
        user.ip_addr = get_ip()
        user.mac_addr = get_macaddr()
        user.hostname = get_hostname()
        if user.is_virtual_fso is False:
            user.fso_state = 1
        rpa.config.SAP_FUNJ = funj
        rpa.config.FSO_USERNAME = fso_username  # 业务人员FSO账号写入全局配置里
        rpa.config.STAFF_GROUP = user.staff_group
        rpa.config.STAFF_ID = user.id
        rpa.config.STAFF_TYPE = user.staff_type
        rpa.config.STAFF_NAME = user.staff_name
    return True


@add_rpc_method(name="/auth/logout")
def logout():
    """登出账号（暂不可用）"""
    rpa.config.STAFF_ID = None
