import logging
from typing import Any, Dict, List, Optional

import rpa.config
from rpa.fastrpa.sap.session import is_session_alive
from rpa.ssc.hr.orm.dims_utils import load_tb_dim_hr_diao_pei
from rpa.ssc.hr.orm.session import DbSession
from rpa.ssc.hr.orm.tb_dim_hr_staff import TB_DIM_HR_STAFF
from rpa.ssc.hr.sap.ppose import PPOSE
from rpa_launcher.backend.ws.dispatcher import add_rpc_method

ppose: Optional[PPOSE] = None


@add_rpc_method(name="/ppose/open_ppose")
def open_ppose() -> List[str]:
    global ppose
    lt_diao_pei = load_tb_dim_hr_diao_pei()
    df_diao_pei = lt_diao_pei.to_dataframe()
    org_ids: List[str] = []
    with DbSession() as s:
        user: Optional[TB_DIM_HR_STAFF] = s.query(TB_DIM_HR_STAFF).filter(TB_DIM_HR_STAFF.id == rpa.config.STAFF_ID).first()
        if user:
            org_ids = df_diao_pei[df_diao_pei['BL'] == '人事五组']['BC'].drop_duplicates().values.tolist()
    logging.info(org_ids)
    ppose = PPOSE(org_ids)
    return org_ids


@add_rpc_method(name="/ppose/gui_nav_select")
def gui_nav_select(org_id: str):
    """点选GuiNav标签"""
    ppose.gui_nav_select(org_id)


@add_rpc_method(name="/ppose/gui_nav_locate")
def gui_nav_locate(org_id: str) -> bool:
    """搜索机构编码"""
    return ppose.gui_nav_locate(org_id)


@add_rpc_method(name="/ppose/gui_view_select")
def gui_view_select(obj_id: str):
    """点选GuiView标签"""
    ppose.gui_view_select(obj_id)


@add_rpc_method(name="/ppose/gui_view_locate")
def gui_view_locate(search_obj_type: str, search_obj_id: str) -> bool:
    """搜索机构、岗位、人员编码"""
    return ppose.gui_view_locate(search_obj_type, search_obj_id)


@add_rpc_method(name="/ppose/gui_tab_select")
def gui_tab_select(tab_name: str) -> Dict[str, Any]:
    """点选GuiTab标签"""
    return ppose.gui_tab_select(tab_name)


@add_rpc_method(name="/ppose/get_gui_nav")
def get_gui_nav(parent_id: str):
    """返回机构目录数据"""
    return ppose.get_gui_nav(parent_id)


@add_rpc_method(name="/ppose/get_gui_view")
def get_gui_view(parent_id: str):
    """返回机构岗位人员详情表数据"""
    return ppose.get_gui_view(parent_id)


@add_rpc_method(name="/ppose/is_ppose_ready")
def is_ppose_ready() -> bool:
    """判断PPOSE是否就绪"""
    return ppose is not None and is_session_alive(ppose.session)


@add_rpc_method(name="/ppose/get_gui_tab_status")
def get_gui_tab_status() -> List[Dict[str, str]]:
    """得到PPOSE标签组件GuiTab的状态"""
    return ppose.get_gui_tab_status()


@add_rpc_method(name="/ppose/is_leaf_org")
def is_leaf_org(org_id: str) -> bool:
    """判断节点是否是末级机构"""
    df_nav = ppose.gui_nav.df_nav
    df_tmp = df_nav[df_nav['org_id'] == org_id]
    return df_tmp['has_children'].values[0]


@add_rpc_method(name="/ppose/get_begin_date")
def get_begin_date() -> str:
    """获取开始日期"""
    return ppose.begin_date


@add_rpc_method(name="/ppose/get_end_date")
def get_end_date() -> str:
    """获取结束日期"""
    return ppose.end_date


@add_rpc_method(name="/ppose/get_org_parent_id")
def get_org_parent_id(org_id: str) -> str:
    """向上翻页"""
    return ppose.get_org_parent_id(org_id)


@add_rpc_method(name="/ppose/get_current_org_id")
def get_current_org_id() -> str:
    """向上翻页"""
    return ppose.get_current_org_id()


# @ADD_RPC_METHOD(name="/ppose/gui_view_upper")
# def gui_view_upper() -> str:
#     """向上翻页"""
#     return ppose.gui_view_upper()
