import functools
import logging
import traceback
from typing import Callable

from jsonrpc.dispatcher import Dispatcher
from jsonrpc.exceptions import JSONRPCDispatchException

DISPATHCHER = Dispatcher()


def add_rpc_method(name=None) -> Callable:
    def decorator(func: Callable) -> Callable:
        @functools.wraps(func)
        def foo(*args):
            try:
                return func(*args)
            except Exception as e:
                logging.error(e)
                logging.error(traceback.format_exc())
                raise JSONRPCDispatchException(code=5000, message=f'错误信息: {e}\n\n{traceback.format_exc()}')
        return DISPATHCHER.add_method(foo, name=name or func.__name__)
    return decorator
