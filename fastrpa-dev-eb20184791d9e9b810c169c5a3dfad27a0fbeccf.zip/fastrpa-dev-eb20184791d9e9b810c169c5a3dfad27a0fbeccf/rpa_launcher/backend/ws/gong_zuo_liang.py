"""工作量汇总相关接口
   ----------------------
   1、组员：下载模板、上传个人工作量、下载个人工作量
   2、组长：下载模板、上传个人工作量、下载个人工作量、下载组内工作量、统计组内工作量、确认组内工作量
   3、经理：下载模板、上传模板、下载业务部工作量，统计业务部工作量
   4、组长、经理 Dashboard 显示工作量信息（组内工作量上传情况、业务部工作量上传情况）
"""

import asyncio
import datetime
import json
import logging
import shutil
from pathlib import Path
from threading import Thread
from typing import List, Optional

import rpa.config
from rpa.fastrpa.adtable import load_from_xlsx_file
from rpa.fastrpa.date_funcs import valid_date
from rpa.fastrpa.log import config
from rpa.fastrpa.myredis import MyRedis
from rpa.fastrpa.tempdir import gentempdir
from rpa.fastrpa.utils.taskkill import taskkill
from rpa.fastrpa.xlsx import clean_gen_py_dir
from rpa.public.myftp import MYFTP
from rpa.ssc.date_funcs import (before_day, get_today, get_week_range,
                                get_week_str)
from rpa.ssc.hr.orm.session import DbSession
from rpa.ssc.hr.orm.tb_dim_hr_env import TB_DIM_HR_ENV
from rpa.ssc.hr.orm.tb_ods_hr_staff_work_amount import \
    TB_ODS_HR_STAFF_WORK_AMOUNT
from rpa.ssc_kit.hr.kit_gong_zuo_liang.work_amount import before_check
from rpa.ssc_kit.hr.kit_gong_zuo_liang.work_amount import \
    main as run_kit_calc_work_amount
from rpa.ssc_kit.hr.kit_gong_zuo_liang.work_amount import valid_week_range
from rpa_launcher.backend.ws.dispatcher import add_rpc_method
from rpa_launcher.backend.ws.permission import get_staff_role_names
from rpa_launcher.backend.ws.ws import BACKGROUND_TASK_RUNNING

IS_CHECK_PASSED: bool = False


add_rpc_method('/work_amount/before_check')(before_check)


def worker_func(filename: str, day_begin: str, day_end: str, is_before_check=True, is_calc=True, is_master_version: bool = False):
    lt = load_from_xlsx_file(filename, '工作量统计', skip_header=2)
    staff_name = '业务部'
    if is_master_version is False:
        staff_name = lt['F'][3].value
    asyncio.run(rpa.config.RPC_FRONT_END.send(json.dumps({'jsonrpc': '2.0',
                                                          'method': 'update_file_info',
                                                          'params': [{'filename': filename,
                                                                      'sr_no': '',
                                                                      'staff_area': '',
                                                                      'subticket_type': '工作量汇总',
                                                                      'staff_name': staff_name,
                                                                      'row_count': lt.max_row - 2}]})))
    with BACKGROUND_TASK_RUNNING():
        taskkill('excel.exe')
        config(Path(filename).name, websocket=rpa.config.RPC_LOG_TEXT)
        if rpa.config.LASTEST_GIT_COMMIT_HEAD:
            logging.info('代码版本: ' + rpa.config.LASTEST_GIT_COMMIT_HEAD)
        run_kit_calc_work_amount(filename, day_begin, day_end, is_before_check, is_calc, is_master_version)
        taskkill('excel.exe')


def get_template_update_time() -> str:
    with DbSession() as db_session:
        query: Optional[TB_DIM_HR_ENV] = db_session.query(TB_DIM_HR_ENV).filter(TB_DIM_HR_ENV.key_name == '工作量汇总模板更新时间').first()
        if query:
            return query.value
        else:
            raise Exception('当前FTP无工作量汇总模板，请联系领导上传')


@add_rpc_method(name="/work_amount/get_week_range")
def work_amount_get_week_range() -> List[str]:
    """本周日期范围"""
    week_begin_day, week_end_day = get_week_range(get_today())
    return [week_begin_day, week_end_day]


@add_rpc_method(name="/work_amount/get_before_week_range")
def work_amount_get_before_week_range() -> List[str]:
    """上周日期范围"""
    week_begin_day, _ = get_week_range(get_today())
    before_week_begin_day, before_week_end_day = get_week_range(before_day(week_begin_day))
    return [before_week_begin_day, before_week_end_day]


@add_rpc_method(name="/work_amount/current_week")
def current_week() -> str:
    """获取当前周次"""
    return get_week_str(get_today())


@add_rpc_method(name="/work_amount/upload_template")
def upload_template(filename: str):
    """更新模板（领导权限）"""
    clean_gen_py_dir()
    staff_roles = get_staff_role_names(rpa.config.STAFF_ID)
    if set(staff_roles).intersection(['管理员', '正经理', '副经理', '书记']):
        # 更新模板datetime
        current_time = datetime.datetime.now().strftime(r'%Y-%m-%d %H:%M:%S')
        lt = load_from_xlsx_file(filename, '工作量统计', skip_header=2, data_only=False)
        lt.wb.properties.description = current_time  # 模板日期
        try:
            lt.delete_all_contents()  # 清空模板上工作量
            filename = lt.save_to(gentempdir())
        except Exception:
            raise Exception('模板文件被占用，请关闭Excel再上传')
        with DbSession() as db_session:
            req: Optional[TB_DIM_HR_ENV] = db_session.query(TB_DIM_HR_ENV).filter(TB_DIM_HR_ENV.key_name == '工作量汇总模板更新时间').first()
            if req:
                req.value = current_time
            else:
                db_session.add(TB_DIM_HR_ENV(key_name='工作量汇总模板更新时间',
                                             value=current_time))
        with MYFTP() as ftp:
            yyyymmdd = datetime.datetime.now().strftime(r'%Y%m%d')
            hhmmss = datetime.datetime.now().strftime(r'%H%M%S')
            ftp.upload_file(Path(filename).as_posix(), f'/HR工作量汇总/模板/工作量汇总_{yyyymmdd}_{hhmmss}.xlsx')
            ftp.upload_file(Path(filename).as_posix(), '/HR工作量汇总/模板/工作量汇总.xlsx')
    else:
        raise Exception('当前用户无工作量汇总模板更新权限')


@add_rpc_method(name="/work_amount/download_template")
def download_template(filename: str):
    """下载模板到本地"""
    clean_gen_py_dir()
    with MYFTP() as ftp:
        temp_dir = gentempdir()
        temp_file = Path(temp_dir).joinpath('工作量汇总.xlsx').as_posix()
        ftp.download_file(temp_file, '/HR工作量汇总/模板/工作量汇总.xlsx')
    if Path(temp_file).exists() is True:
        lt = load_from_xlsx_file(temp_file, '工作量统计', skip_header=2, data_only=False)
        lt.delete_all_contents()
        # 根据用户角色不同，删除不同的sheet页
        staff_roles = get_staff_role_names(rpa.config.STAFF_ID)
        if '正经理' in staff_roles:
            pass
        elif set(staff_roles).intersection(['管理员', '副经理', '书记']):
            for sheetname in lt.wb.sheetnames:
                if sheetname not in ['工作量统计', '按人员统计', '按机构统计', '码表', '按人员统计_中间结果', '按机构统计_中间结果', '绩效考核_中间结果0', '绩效考核_中间结果1']:
                    del lt.wb[sheetname]
        elif '组长' in staff_roles:
            for sheetname in lt.wb.sheetnames:
                if sheetname not in ['工作量统计', '按人员统计', '按机构统计']:
                    lt.wb[sheetname].sheet_state = 'hidden'
                if sheetname not in ['工作量统计', '按人员统计', '按机构统计', '码表', '按人员统计_中间结果', '按机构统计_中间结果', '绩效考核_中间结果0', '绩效考核_中间结果1']:
                    del lt.wb[sheetname]
        else:
            for sheetname in lt.wb.sheetnames:
                if sheetname not in ['工作量统计', '码表']:
                    del lt.wb[sheetname]
        lt.save(temp_file)
        shutil.copyfile(temp_file, Path(filename).as_posix())  # 将文件复制到目标路径
    else:
        raise Exception('工作量汇总模板下载失败')


add_rpc_method(name="/work_amount/download_template")(download_template)


@add_rpc_method(name="/work_amount/upload_data")
def upload_data(filename: str, day_begin: str, day_end: str):
    """上传工作量
    """
    clean_gen_py_dir()
    valid_week_range(day_begin, day_end)
    lt = load_from_xlsx_file(filename, '工作量统计', skip_header=2)
    lt.del_blank_rows_by_column('B')
    df = lt.to_dataframe()
    staff_names = list(set(lt['I'].values))
    current_time = lt.wb.properties.description   # 模板日期
    with DbSession() as db_session:
        req: Optional[TB_DIM_HR_ENV] = db_session.query(TB_DIM_HR_ENV).filter(TB_DIM_HR_ENV.key_name == '工作量汇总模板更新时间').first()
        if req and req.value != current_time:
            raise Exception(f'模板非最新，请在工作量汇总窗口下载最新模板。本地文件日期：{req.value}，最新模板日期：{current_time}')
    if len(staff_names) > 1:
        raise Exception(f'当前只支持上传本人工作量，请检查维护人是否全为{rpa.config.STAFF_NAME}')
    if staff_names[0] != rpa.config.STAFF_NAME:
        raise Exception('模板中维护人姓名与RPA登录账号用户姓名不一致，请修改一致后再上传工作量')
    with DbSession() as db_session:
        db_session.query(TB_ODS_HR_STAFF_WORK_AMOUNT).filter(TB_ODS_HR_STAFF_WORK_AMOUNT.day_begin == day_begin,
                                                             TB_ODS_HR_STAFF_WORK_AMOUNT.day_end == day_end,
                                                             TB_ODS_HR_STAFF_WORK_AMOUNT.staff_id == rpa.config.STAFF_ID,
                                                             TB_ODS_HR_STAFF_WORK_AMOUNT.staff_name == rpa.config.STAFF_NAME
                                                             ).delete()  # 删除旧数据
        for rn in df.index:
            coop_times = int(df['J'][rn]) if df['J'][rn] else df['J'][rn].isdigit()
            db_session.add(TB_ODS_HR_STAFF_WORK_AMOUNT(statis_year=day_begin[:4],  # 周次开始日期所在年份
                                                       day_begin=day_begin,  # 周次结束日期
                                                       day_end=day_end,  # 周次开始日期
                                                       staff_id=rpa.config.STAFF_ID,  # 员工ID
                                                       staff_group=rpa.config.STAFF_GROUP,  # 员工组别
                                                       staff_type=rpa.config.STAFF_TYPE,  # 员工类型：组长、组员
                                                       staff_name=rpa.config.STAFF_NAME,  # 员工姓名
                                                       service_id=df['B'][rn],  # 服务请求号
                                                       service_group=df['C'][rn],  # 服务类型大类
                                                       service_lgroup=df['D'][rn],  # 服务类型小类
                                                       amount=df['E'][rn],  # 人次
                                                       service_corp=df['G'][rn],  # 服务请求单位
                                                       day_work=df['H'][rn].replace('/', ''),  # 维护日期
                                                       coop_times=coop_times,  # 协同反馈次数
                                                       topic_name=df['K'][rn],  # 专项工作名称
                                                       is_p2p=str(df['L'][rn]),  # 端到端相关
                                                       is_confirmed=False,  # 组长确认
                                                       ))
        with MYFTP() as ftp:
            ftp.upload_file(Path(filename).as_posix(), f'/HR工作量汇总/{rpa.config.STAFF_GROUP}/{day_begin}-{day_end}-{rpa.config.STAFF_GROUP}-{rpa.config.STAFF_NAME}.xlsx')  # 上传工作量到FTP
        with MyRedis() as r:
            daytime = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
            r.lpush(f'工作量-历史记录:上传:{rpa.config.STAFF_GROUP}', f'{daytime} {rpa.config.STAFF_GROUP}-{rpa.config.STAFF_NAME} 上传了工作量')
            r.ltrim(f'工作量-历史记录:上传:{rpa.config.STAFF_GROUP}', 0, 300)  # 只保留近300次更新记录


@add_rpc_method(name="/work_amount/download_data")
def download_data(filename: str, data_type: str, day_begin: str, day_end: str):
    """下载工作量（领导权限）
    """
    clean_gen_py_dir()
    if valid_date(day_begin) is False or valid_date(day_end) is False:
        raise Exception(f'日期范围{day_begin}-{day_end}必须是合法的日期，如20210318-20210324')
    # _day_begin, _ = get_week_range(day_begin)
    # _, _day_end = get_week_range(day_end)
    # if day_begin != _day_begin or day_end != _day_end:
    #     raise Exception(f'工作量下载日期范围，开始日期必须是周四，结束日期必须是周三，当前值：{day_begin}-{day_end}')
    temp_dir = gentempdir()
    temp_file = Path(temp_dir).joinpath('工作量汇总.xlsx').as_posix()
    download_template(temp_file)
    if Path(temp_file).exists() is False:
        raise Exception('工作量汇总模板下载失败')
    lt = load_from_xlsx_file(temp_file, '工作量统计', skip_header=2, data_only=False)
    lt.delete_all_contents()  # 创建空白模板
    lt.save(temp_file)
    with DbSession() as db_session:
        query = db_session.query(TB_ODS_HR_STAFF_WORK_AMOUNT).filter(TB_ODS_HR_STAFF_WORK_AMOUNT.statis_year == day_begin[:4],
                                                                     TB_ODS_HR_STAFF_WORK_AMOUNT.day_begin >= day_begin,
                                                                     TB_ODS_HR_STAFF_WORK_AMOUNT.day_end <= day_end)
        if data_type == '业务部工作量':
            query = query.filter(TB_ODS_HR_STAFF_WORK_AMOUNT.is_confirmed == True)  # noqa: E712
        elif data_type == '组内工作量':  # 组长只能下载本组工作量
            query = query.filter(TB_ODS_HR_STAFF_WORK_AMOUNT.staff_group == rpa.config.STAFF_GROUP)
        elif data_type == '个人工作量':
            query = query.filter(TB_ODS_HR_STAFF_WORK_AMOUNT.staff_id == rpa.config.STAFF_ID)
        else:
            raise Exception('工作量类型非预定义值')
        result = query.all()
        if result:
            for rn, _work in enumerate(result, start=3):
                day_work = _work.day_work
                if len(day_work) == 8:
                    day_work = day_work[:4] + '/' + day_work[4:6] + '/' + day_work[6:8]
                lt['A'][rn].value = str(rn - 2)
                lt['B'][rn].value = _work.service_id  # 服务请求号
                lt['C'][rn].value = _work.service_group  # 服务类型大类
                lt['D'][rn].value = _work.service_lgroup  # 服务类型小类
                lt['E'][rn].value = _work.amount  # 人次
                lt['F'][rn].value = _work.staff_group  # 业务组
                lt['G'][rn].value = _work.service_corp  # 服务请求单位
                lt['H'][rn].value = _work.day_work  # 维护日期
                lt['I'][rn].value = _work.staff_name  # 维护人
                lt['J'][rn].value = _work.coop_times  # 协同反馈次数
                lt['K'][rn].value = _work.topic_name  # 专项工作名称
                lt['L'][rn].value = _work.is_p2p or ''  # 端到端相关
    lt.save(temp_file)
    shutil.copyfile(temp_file, Path(filename).as_posix())  # 将文件复制到目标路径


@add_rpc_method(name="/work_amount/comfirm_data")
def comfirm_data():
    """确认工作量（组长权限）
    """
    with DbSession() as db_session:
        query = db_session.query(TB_ODS_HR_STAFF_WORK_AMOUNT).filter(TB_ODS_HR_STAFF_WORK_AMOUNT.staff_group == rpa.config.STAFF_GROUP)
        query.update({TB_ODS_HR_STAFF_WORK_AMOUNT.is_confirmed: True})
        with MyRedis() as r:
            daytime = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
            r.lpush('工作量-历史记录:确认', f'{daytime} 【{rpa.config.STAFF_GROUP}】工作量由组长【{rpa.config.STAFF_NAME}】确认通过')
            r.ltrim('工作量-历史记录:确认', 0, 300)  # 只保留近300次更新记录


@add_rpc_method(name="/work_amount/calc_data")
def calc_data(filename: str, day_begin: str, day_end: str, is_master_version: bool = False):
    """统计工作量（领导、组长权限）
    """
    clean_gen_py_dir()
    staff_roles = get_staff_role_names(rpa.config.STAFF_ID)
    is_master_version = is_master_version and True if '正经理' in staff_roles else False
    rpa.config.WORKER_THREAD = Thread(target=worker_func, args=(filename, day_begin, day_end, False, True, is_master_version))
    rpa.config.WORKER_THREAD.setDaemon(True)
    rpa.config.WORKER_THREAD.start()


@add_rpc_method(name="/work_amount/get_history")
def work_amount_get_history() -> List[str]:
    history: List[str] = []
    staff_roles = get_staff_role_names(rpa.config.STAFF_ID)
    try:
        with MyRedis() as r:
            if set(staff_roles).intersection(['管理员', '正经理', '副经理', '书记']):
                history = r.lrange('工作量-历史记录:确认', 0, 300)
            else:
                history = r.lrange(f'工作量-历史记录:上传:{rpa.config.STAFF_GROUP}', 0, 300)
    except Exception:  # nosec
        pass
    return history


if __name__ == '__main__':
    config()
