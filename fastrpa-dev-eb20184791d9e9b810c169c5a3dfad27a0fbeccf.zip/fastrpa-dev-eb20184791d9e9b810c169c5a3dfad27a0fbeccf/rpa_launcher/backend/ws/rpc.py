import rpa.config
import rpa_launcher.backend.ws.auth
import rpa_launcher.backend.ws.dashboard
import rpa_launcher.backend.ws.dims
import rpa_launcher.backend.ws.ftp
import rpa_launcher.backend.ws.gong_zuo_liang
import rpa_launcher.backend.ws.log
import rpa_launcher.backend.ws.nian_jin
import rpa_launcher.backend.ws.permission
import rpa_launcher.backend.ws.ppose
import rpa_launcher.backend.ws.rpa_info
import rpa_launcher.backend.ws.sap
import rpa_launcher.backend.ws.user  # noqa: F401
from jsonrpc.manager import JSONRPCResponseManager
from rpa_launcher.backend.ws.dispatcher import DISPATHCHER
from websockets.server import WebSocketServerProtocol


async def websocket_endpoint(websocket: WebSocketServerProtocol, uri: str):
    if uri == '/ws/rpc_log_text':
        rpa.config.RPC_LOG_TEXT = websocket  # websocket日志接口
    elif uri == '/ws/rpc':  # websocket功能接口
        rpa.config.RPC_FRONT_END = websocket
    async for data in websocket:
        response = JSONRPCResponseManager.handle(data, DISPATHCHER)
        await websocket.send(response.json)
