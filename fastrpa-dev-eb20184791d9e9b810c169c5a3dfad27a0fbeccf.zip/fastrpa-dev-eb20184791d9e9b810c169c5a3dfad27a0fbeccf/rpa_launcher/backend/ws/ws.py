import asyncio
import json
from typing import Optional

import rpa.config
from websockets.server import WebSocketServerProtocol


class BACKGROUND_TASK_RUNNING(object):
    ws: WebSocketServerProtocol

    def __init__(self, ws: Optional[WebSocketServerProtocol] = None):
        self.ws = ws if ws else rpa.config.RPC_FRONT_END

    def __enter__(self):
        asyncio.run(self.ws.send(json.dumps({'jsonrpc': '2.0',
                                             'method': '/sap/is_background_task_running',
                                             'params': [True]})))

    def __exit__(self, exc_type, exc_val, exc_tb):
        asyncio.run(self.ws.send(json.dumps({'jsonrpc': '2.0',
                                             'method': '/sap/is_background_task_running',
                                             'params': [False]})))
