"""建岗码表更新"""
import asyncio
import json
import logging
from pathlib import Path
from threading import Thread
from typing import List

import rpa.config
from rpa.fastrpa.log import config
from rpa.fastrpa.utils.taskkill import taskkill
from rpa.ssc_kit.hr.kit_update_dims.main import (dims_update_history,
                                                 download_dims, update_dims)
from rpa_launcher.backend.ws.dispatcher import add_rpc_method
from rpa_launcher.backend.ws.permission import get_staff_role_names
from rpa_launcher.backend.ws.ws import BACKGROUND_TASK_RUNNING


def worker_func(dims_name: str, group_name: str, filename: str):
    asyncio.run(rpa.config.RPC_FRONT_END.send(json.dumps({'jsonrpc': '2.0',
                                                          'method': 'update_file_info',
                                                          'params': [{'filename': filename,
                                                                      'sr_no': '',
                                                                      'staff_area': '',
                                                                      'subticket_type': '码表库更新',
                                                                      'staff_name': rpa.config.STAFF_NAME,
                                                                      'row_count': 0}]})))
    with BACKGROUND_TASK_RUNNING():
        config(Path(f'码表库更新_{dims_name}_{rpa.config.STAFF_NAME}_' + filename).name, websocket=rpa.config.RPC_LOG_TEXT)
        if rpa.config.LASTEST_GIT_COMMIT_HEAD:
            logging.info('代码版本: ' + rpa.config.LASTEST_GIT_COMMIT_HEAD)
        taskkill('excel.exe')
        update_dims(dims_name, group_name, filename, rpa.config.STAFF_GROUP, rpa.config.STAFF_NAME)
        taskkill('excel.exe')


@add_rpc_method('/dims/download_dims')
def download_group_dims(dims_name: str, group_name: str, filename: str):
    download_dims(dims_name, group_name, filename)


@add_rpc_method('/dims/update_group_dims')
def update_group_dims(dims_name: str, group_name: str, filename: str):
    rpa.config.WORKER_THREAD = Thread(target=worker_func, args=(dims_name, group_name, filename))
    rpa.config.WORKER_THREAD.setDaemon(True)
    rpa.config.WORKER_THREAD.start()


@add_rpc_method('/dims/get_dims_update_history')
def get_dims_update_history() -> List[str]:
    """获取码表库更新历史"""
    if '管理员' in get_staff_role_names(rpa.config.STAFF_ID):
        return dims_update_history()  # 管理员查看所有更新记录
    else:
        return dims_update_history(rpa.config.STAFF_GROUP)  # 其他组查看本组更新记录
