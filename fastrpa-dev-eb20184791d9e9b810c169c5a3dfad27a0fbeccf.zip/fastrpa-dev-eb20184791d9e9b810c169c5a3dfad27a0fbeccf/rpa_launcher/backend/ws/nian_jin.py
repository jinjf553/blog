"""企业年金相关接口
"""
import asyncio
import json
import logging
import traceback
from pathlib import Path
from threading import Thread

import rpa.config
from rpa.fastrpa.date_funcs import valid_date
from rpa.fastrpa.log import config
from rpa.fastrpa.obs import OBS_REC
from rpa.fastrpa.sap.session import SapClose
from rpa.fastrpa.tempdir import reset_tempdir
from rpa.fastrpa.third_party.dont_sleep import DONT_SLEEP
from rpa.fastrpa.utils.taskkill import taskkill
from rpa.ssc_kit.hr.kit_nian_jin import (  # 账管系统核查
    account_management_verification, first_participate, intra_group_transfer,
    retirement_payment, transfer_group_out)
from rpa_launcher.backend.ws.dispatcher import add_rpc_method
from rpa_launcher.backend.ws.permission import has_permission
from rpa_launcher.backend.ws.sap import is_background_task_running
from rpa_launcher.backend.ws.ws import BACKGROUND_TASK_RUNNING

# 下拉菜单选项
ORG_ITEMS = [['35450003', '勘探分公司'], ['36400000', '项目管理公司'], ['10010023', '扬子石化'], ['13350042', '上海赛诺佩克'], ['10010067', '湖南石油'], ['33450000', '云南石油'], ['33300000', '广西石油'], ['30250052', '四川石油'], ['35100000', '海南炼化'], ['30250090', '重庆石油'], ['33400000', '贵州石油']]


def worker_func(event_type: str, path_or_orgid: str, day_begin: str, day_end: str):
    asyncio.run(rpa.config.RPC_FRONT_END.send(json.dumps({'jsonrpc': '2.0',
                                                          'method': 'update_file_info',
                                                          'params': [{'filename': path_or_orgid,
                                                                      'sr_no': '',
                                                                      'staff_area': '',
                                                                      'subticket_type': '年金-账管系统核查',
                                                                      'staff_name': rpa.config.STAFF_NAME,
                                                                      'row_count': 0}]})))
    with DONT_SLEEP():  # 禁用休眠
        with OBS_REC(f'年金-{event_type}'):  # 录屏
            with SapClose():
                with BACKGROUND_TASK_RUNNING():
                    config('年金_' + event_type, websocket=rpa.config.RPC_LOG_TEXT)
                    taskkill('excel.exe')
                    reset_tempdir()
                    if event_type == '账管系统核查':
                        p = Path(path_or_orgid)
                        if p.exists() is False or p.is_dir() is False:
                            raise Exception(f'【账管系统核查】{path_or_orgid}不存在或不是文件夹')
                        logging.info(f'执行【年金-账管系统核查】，目录名：{path_or_orgid}')
                        try:
                            account_management_verification.account_verif(path_or_orgid)  # arg2对应目录
                        except Exception as e:
                            logging.error(f'执行出错，异常原因：{e}')
                            logging.error(f"调用栈: {traceback.format_exc()}")
                    else:
                        p = Path(path_or_orgid)
                        if p.exists() and p.is_absolute() and p.is_file():
                            pass
                        else:
                            for item in ORG_ITEMS:
                                if path_or_orgid.startswith(item[0]):  # 转换为对应的机构编码
                                    path_or_orgid = item[0]
                                    break
                            else:
                                raise Exception(f'{path_or_orgid}不是有效的文件路径或机构ID')
                        if valid_date(day_begin) is False or valid_date(day_end) is False:
                            raise Exception(f'{day_begin}-{day_end}不是有效的日期区间')
                        logging.info(f'执行【年金-{event_type}】，机构ID或文件路径：{path_or_orgid}，时间区间：{day_begin}-{day_end}')
                        try:
                            if event_type == '退休支付确认':
                                retirement_payment.main(path_or_orgid, day_begin, day_end)
                            elif event_type == '集团内转移个人信息':
                                intra_group_transfer.main(path_or_orgid, day_begin, day_end)
                            elif event_type == '集团外变动信息':
                                transfer_group_out.main(path_or_orgid, day_begin, day_end)
                            elif event_type == '首次参加年金计划':
                                first_participate.main(path_or_orgid, day_begin, day_end)  # arg2对应机构编码或者文件路径
                            else:
                                raise Exception(f'不支持的事件类型{event_type}')
                        except Exception as e:
                            logging.error(f'执行出错，异常原因：{e}')
                            logging.error(f"调用栈: {traceback.format_exc()}")
                    taskkill('excel.exe')


@add_rpc_method(name='/annuity/execute')
def execute(event_type: str, path_or_orgid: str, day_begin: str, day_end: str):
    if has_permission(rpa.config.STAFF_ID, '年金') is False:
        raise Exception('当前用户无【年金】执行权限')
    if is_background_task_running() is False:
        rpa.config.WORKER_THREAD = Thread(target=worker_func, args=(event_type, path_or_orgid, day_begin, day_end))
        rpa.config.WORKER_THREAD.setDaemon(True)
        rpa.config.WORKER_THREAD.start()
        return True
    else:
        return False
