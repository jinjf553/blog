from time import sleep

import rpa.config
import win32api
from rpa.fastrpa.utils.window import activate_window, find_window
from rpa.public.config import ftp_user, ftp_user_readonly
from rpa_launcher.backend.ws.dispatcher import add_rpc_method
from rpa_launcher.backend.ws.permission import get_staff_role_names


@add_rpc_method(name='/ftp/open_ftp_by_explorer')
def open_ftp_by_explorer():
    """使用explorer.exe打开FTP"""
    staff_roles = get_staff_role_names(rpa.config.STAFF_ID)
    ftp_address, ftp_password, ftp_port, ftp_username = ftp_user_readonly()  # 其他人只读
    if '管理员' in staff_roles:
        ftp_address, ftp_password, ftp_port, ftp_username = ftp_user()  # 管理员读写
    win32api.ShellExecute(0, 'open', 'explorer', f'"ftp://{ftp_username}:{ftp_password}@{ftp_address}:{ftp_port}/"', '', 1)
    for _ in range(20):
        sleep(.2)
        hwnd = find_window(None, ftp_address)
        if hwnd:
            activate_window(hwnd)
            break
