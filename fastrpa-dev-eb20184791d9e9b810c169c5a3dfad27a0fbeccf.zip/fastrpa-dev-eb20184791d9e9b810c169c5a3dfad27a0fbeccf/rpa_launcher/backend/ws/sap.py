import datetime
import logging
from pathlib import Path
from threading import Thread
from typing import List

import rpa.config
from rpa.fastrpa.log import config
from rpa.fastrpa.sap.session import login_tx
from rpa.fastrpa.utils.taskkill import taskkill
from rpa.run_rpa import run_rpa
from rpa.ssc.hr.parse_template_info import parse_template_file
from rpa.ssc_kit.hr.kit_organization_code_application.main import \
    main as mdm_main
from rpa_launcher.backend.ws.dispatcher import add_rpc_method
from rpa_launcher.backend.ws.permission import has_permission
from rpa_launcher.backend.ws.ws import BACKGROUND_TASK_RUNNING


def worker_func(filename: str, subticket_type: str = ''):
    with BACKGROUND_TASK_RUNNING():
        config(Path(filename).name, websocket=rpa.config.RPC_LOG_TEXT)
        if rpa.config.LASTEST_GIT_COMMIT_HEAD:
            logging.info('代码版本: ' + rpa.config.LASTEST_GIT_COMMIT_HEAD)
        taskkill('excel.exe')
        run_rpa(filename, subticket_type)
        taskkill('excel.exe')


@add_rpc_method(name='/sap/parse_file_info')
def parse_file_info(filename: str, file_subticket_type: str):
    """解析文件信息"""
    sap_ids: List[str] = []
    if file_subticket_type in ['自动拆单', '手动拆单', '成本中心定位', '组合逻辑查询导出', '机构岗位查询分析', '员工信息表导出', '工作量汇总', '成本中心信息导出', '组织分配屏修改', '单位简化全称修改', '码表库更新', '机构编码申请']:
        sr_no, staff_area, subticket_type, staff_name, sap_ids, sap_names = ['', '', file_subticket_type, '', [], []]
        row_count = len(sap_ids)
    else:
        try:
            sr_no, staff_area, subticket_type, staff_name, sap_ids, sap_names = parse_template_file(filename)
            row_count = len(sap_ids)
            if subticket_type != file_subticket_type:
                raise Exception(f'RPA类型为【{file_subticket_type}】模板事件类型为【{subticket_type}】，二者不一致')
        except Exception as e:
            raise Exception(str(e))
    return {'filename': filename,
            'sr_no': sr_no,
            'staff_area': staff_area,
            'subticket_type': subticket_type,
            'staff_name': staff_name,
            'row_count': row_count}


@add_rpc_method(name='/sap/is_background_task_running')
def is_background_task_running() -> bool:
    """是否存在后台任务"""
    return rpa.config.WORKER_THREAD is not None and rpa.config.WORKER_THREAD.is_alive() is True


@add_rpc_method(name='/sap/execute')
def execute(subticket_type: str, filename: str):
    if datetime.datetime.now().strftime(r'%Y-%m-%d %H:%M:%S') >= rpa.config.LAUNCH_END_TIME:  # 次日7点强制重启更新，否则不能做单子
        raise Exception('请关闭RPA获取最新')
    if has_permission(rpa.config.STAFF_ID, subticket_type) is False:
        logging.info(subticket_type)
        raise Exception(f'当前用户无【{subticket_type}】执行权限')
    if is_background_task_running() is False:
        rpa.config.WORKER_THREAD = Thread(target=worker_func, args=(filename, subticket_type))
        rpa.config.WORKER_THREAD.setDaemon(True)
        rpa.config.WORKER_THREAD.start()
        return True
    else:
        return False


def run_launch_sap_gui():
    if has_permission(rpa.config.STAFF_ID, '快捷登录SAP') is False:
        raise Exception('当前用户无【快捷登录SAP】执行权限')
    login_tx()


@add_rpc_method(name='/sap/mdm')
def run_mdm():
    mdm_main()
