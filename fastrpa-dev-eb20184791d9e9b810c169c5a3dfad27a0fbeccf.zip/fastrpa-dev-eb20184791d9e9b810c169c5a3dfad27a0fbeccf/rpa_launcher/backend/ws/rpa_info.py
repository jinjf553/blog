import rpa.config
from rpa_launcher.backend.ws.dispatcher import add_rpc_method


@add_rpc_method(name="/rpa_config/get_rpa_server_version")
def get_rpa_version() -> str:
    return rpa.config.LASTEST_GIT_COMMIT_HEAD
