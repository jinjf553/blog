
from collections import defaultdict
from typing import Dict, List, Union

import rpa.config
from rpa.ssc.hr.orm.session import DbSession
from rpa.ssc.hr.orm.tb_dim_hr_permission import TB_DIM_HR_PERMISSION
from rpa.ssc.hr.orm.tb_dim_hr_role import TB_DIM_HR_ROLE
from rpa.ssc.hr.orm.tb_dim_hr_role_permission import TB_DIM_HR_ROLE_PERMISSION
from rpa.ssc.hr.orm.tb_dim_hr_staff import TB_DIM_HR_STAFF
from rpa.ssc.hr.orm.tb_dim_hr_staff_role import TB_DIM_HR_STAFF_ROLE
from rpa_launcher.backend.ws.dispatcher import add_rpc_method

STAFF_GROUPS = defaultdict(int)
STAFF_GROUPS['人事一组'] = 1
STAFF_GROUPS['人事二组'] = 2
STAFF_GROUPS['人事三组'] = 3
STAFF_GROUPS['人事四组'] = 4
STAFF_GROUPS['人事五组'] = 5
STAFF_GROUPS['人事六组'] = 6


def get_staff_role_names(staff_id: int) -> List[str]:
    """获取业务人员权限列表

    Args:
        staff_id (int): 业务人员id(TB_DIM_HR_STAFF.id)

    Returns:
        List[str]: 角色名称列表（TB_DIM_HR_ROLE.role_name）
    """
    with DbSession() as s:
        res = s.query(TB_DIM_HR_ROLE.role_name
                      ).select_from(TB_DIM_HR_STAFF_ROLE  # 用户-角色
                                    ).filter(TB_DIM_HR_STAFF_ROLE.staff_id == staff_id
                                             ).join(TB_DIM_HR_ROLE,  # 角色-名称
                                                    TB_DIM_HR_STAFF_ROLE.role_id == TB_DIM_HR_ROLE.id
                                                    ).distinct().all()  # 去重
        if res is not None:
            return [r[0] for r in res if isinstance(r[0], str)]  # 过滤非str的结果
        else:
            return []


def get_staff_permission_names(staff_id: int) -> List[str]:
    """获取业务人员权限列表

    Args:
        staff_id (int): 业务人员id(TB_DIM_HR_STAFF.id)

    Returns:
        List[str]: 权限名称列表（TB_DIM_HR_PERMISSION.permission_name）
    """
    staff_roles = get_staff_role_names(staff_id)
    with DbSession() as s:
        if '管理员' in staff_roles:
            res = s.query(TB_DIM_HR_PERMISSION.permission_name).distinct().all()  # 管理员拥有所有权限
        else:
            res = s.query(TB_DIM_HR_PERMISSION.permission_name
                          ).select_from(TB_DIM_HR_STAFF_ROLE  # 用户-角色
                                        ).filter(TB_DIM_HR_STAFF_ROLE.staff_id == staff_id
                                                 ).join(TB_DIM_HR_ROLE_PERMISSION,  # 角色-权限
                                                        TB_DIM_HR_STAFF_ROLE.role_id == TB_DIM_HR_ROLE_PERMISSION.role_id
                                                        ).join(TB_DIM_HR_PERMISSION,  # 权限-名称
                                                               TB_DIM_HR_ROLE_PERMISSION.permission_id == TB_DIM_HR_PERMISSION.id).distinct().all()  # 去重
        if res is not None:
            return [r[0] for r in res if isinstance(r[0], str)]  # 过滤非str的结果
        else:
            return []


def has_permission(staff_id: int, permission_name: str) -> bool:
    """判断业务人员是否有某项权限

    Args:
        staff_id (int): 业务人员id(TB_DIM_HR_STAFF.id)
        permission_name (str): 权限名称，如：岗位变动、二级单位间调动（TB_DIM_HR_PERMISSION.permission_name）

    Returns:
        bool: True代表有权限，False代表无权限
    """
    staff_permissions = get_staff_permission_names(staff_id)
    return permission_name in staff_permissions


@add_rpc_method('/permission/get_staffs')
def get_staffs() -> List[Dict[str, Union[int, str]]]:
    staff_roles: List[str] = get_staff_role_names(rpa.config.STAFF_ID)

    def compare(s):
        number = STAFF_GROUPS[s['staff_group']]
        if number == 0:
            if s['staff_name'] == '张蕾':
                number = -99
            elif s['staff_name'] == '高韧':
                number = -98
        return number
    with DbSession() as s:
        res = s.query(TB_DIM_HR_STAFF.staff_group, TB_DIM_HR_STAFF.id, TB_DIM_HR_STAFF.staff_name)
        res = res.filter(TB_DIM_HR_STAFF.id != rpa.config.STAFF_ID)
        if not set(staff_roles).intersection(['管理员', '正经理']):  # 管理员&正经理能查看所有人员信息
            res = res.filter(TB_DIM_HR_STAFF.staff_group == rpa.config.STAFF_GROUP)
        res = res.order_by(TB_DIM_HR_STAFF.order_id).all()
        if res is not None:
            result = [{'staff_group': r[0] or '', 'staff_id': r[1], 'staff_name':r[2], } for r in res]
            result = sorted(result, key=compare)
            return result
        else:
            return []


@add_rpc_method('/permission/get_roles')
def get_roles() -> List[Dict[str, Union[int, str]]]:
    if '管理员' in get_staff_role_names(rpa.config.STAFF_ID):  # 管理员能查看所有角色
        with DbSession() as s:
            res = s.query(TB_DIM_HR_ROLE.id, TB_DIM_HR_ROLE.role_name).order_by(TB_DIM_HR_ROLE.order_id)
            res = res.all()
            if res is not None:
                return [{'role_id': r[0], 'role_name': r[1]} for r in res if isinstance(r[1], str)]  # 过滤非str的结果
            else:
                return []
    else:
        with DbSession() as s:  # 其他人只能查看自己拥有的角色
            res = s.query(TB_DIM_HR_ROLE.id,
                          TB_DIM_HR_ROLE.role_name
                          ).select_from(TB_DIM_HR_STAFF_ROLE  # 用户-角色
                                        ).filter(TB_DIM_HR_STAFF_ROLE.staff_id == rpa.config.STAFF_ID
                                                 ).join(TB_DIM_HR_ROLE,  # 角色-名称
                                                        TB_DIM_HR_STAFF_ROLE.role_id == TB_DIM_HR_ROLE.id
                                                        ).distinct().order_by(TB_DIM_HR_ROLE.order_id).all()  # 去重
            if res is not None:
                return [{'role_id': r[0], 'role_name': r[1]} for r in res if isinstance(r[0], str)]  # 过滤非str的结果
            else:
                return []


@add_rpc_method('/permission/get_permissions')
def get_permissions() -> List[Dict[str, Union[int, str]]]:
    staff_permission_names: List[str] = get_staff_permission_names(rpa.config.STAFF_ID)
    if '管理员' in staff_permission_names:  # 管理员能查看所有权限
        with DbSession() as s:
            res = s.query(TB_DIM_HR_PERMISSION.id, TB_DIM_HR_PERMISSION.permission_name).order_by(TB_DIM_HR_PERMISSION.order_id).all()
            if res is not None:
                return [{'permission_id': r[0], 'permission_name': r[1]} for r in res]
            else:
                return []
    else:
        with DbSession() as s:
            res = s.query(TB_DIM_HR_PERMISSION.id,
                          TB_DIM_HR_PERMISSION.permission_name
                          ).select_from(TB_DIM_HR_STAFF_ROLE  # 用户-角色
                                        ).filter(TB_DIM_HR_STAFF_ROLE.staff_id == rpa.config.STAFF_ID
                                                 ).join(TB_DIM_HR_ROLE_PERMISSION,  # 角色-权限
                                                        TB_DIM_HR_STAFF_ROLE.role_id == TB_DIM_HR_ROLE_PERMISSION.role_id
                                                        ).join(TB_DIM_HR_PERMISSION,  # 权限-名称
                                                               TB_DIM_HR_ROLE_PERMISSION.permission_id == TB_DIM_HR_PERMISSION.id
                                                               ).distinct().order_by(TB_DIM_HR_PERMISSION.order_id).all()  # 去重
            if res is not None:
                return [{'permission_id': r[0], 'permission_name': r[1]} for r in res if r[1] not in ['管理员', '正经理', '副经理', '书记', '组长']]
            else:
                return []


@add_rpc_method('/permission/get_all_staff_roles')
def get_all_staff_roles() -> List[Dict[str, Union[int, str]]]:  # {staff_id: xxx, role_id: xxx}
    """获取所有人的权限信息"""
    staff_roles: List[str] = get_staff_role_names(rpa.config.STAFF_ID)
    with DbSession() as s:
        res = s.query(TB_DIM_HR_STAFF_ROLE).select_from(TB_DIM_HR_STAFF).join(TB_DIM_HR_STAFF_ROLE, TB_DIM_HR_STAFF.id == TB_DIM_HR_STAFF_ROLE.staff_id)
        res = res.filter(TB_DIM_HR_STAFF.id != rpa.config.STAFF_ID)
        if not set(staff_roles).intersection(['管理员', '正经理']):  # 管理员&正经理能查看所有人员信息
            if '组长' in staff_roles:
                res = res.filter(TB_DIM_HR_STAFF.staff_group == rpa.config.STAFF_GROUP)
            else:
                raise Exception('当前用户无查看权限')
        res = res.all()
        if res is not None:
            return [{'staff_id': r.staff_id, 'role_id': r.role_id} for r in res]
        else:
            return []


@add_rpc_method('/permission/get_all_role_permissions')
def get_all_role_permissions() -> List[Dict[str, Union[int, str]]]:   # {role_id: xxx, permission_id: xxx}
    """获取角色的权限"""
    with DbSession() as s:
        res = s.query(TB_DIM_HR_ROLE_PERMISSION)
        res = res.all()
        if res is not None:
            return [{'role_id': r.role_id, 'permission_id': r.permission_id} for r in res]
        else:
            return []


@add_rpc_method('/permission/toggle_staff_role')
def toggle_staff_role(staff_id: int, role_id: int, state: bool):
    with DbSession() as s:
        s.query(TB_DIM_HR_STAFF_ROLE).filter(TB_DIM_HR_STAFF_ROLE.staff_id == staff_id,
                                             TB_DIM_HR_STAFF_ROLE.role_id == role_id).delete()
        if state is True:
            s.add(TB_DIM_HR_STAFF_ROLE(staff_id=staff_id, role_id=role_id))


@add_rpc_method('/permission/toggle_role_permission')
def toggle_role_permission(role_id: int, permission_id: str, state: bool):
    with DbSession() as s:
        s.query(TB_DIM_HR_ROLE_PERMISSION).filter(TB_DIM_HR_ROLE_PERMISSION.role_id == role_id,
                                                  TB_DIM_HR_ROLE_PERMISSION.permission_id == permission_id).delete()
        if state is True:
            s.add(TB_DIM_HR_ROLE_PERMISSION(role_id=role_id, permission_id=permission_id))
