from typing import Dict, Optional

import rpa.config
from rpa.fastrpa.net import get_hostname, get_ip, get_macaddr, get_username
from rpa.fastrpa.third_party.isa import decrypt, encrypt
from rpa.fastrpa.utils.win_user import check_win_login
from rpa.ssc.fso.check_fso_login import check_fso_login
from rpa.ssc.hr.orm.session import DbSession
from rpa.ssc.hr.orm.tb_dim_hr_login import TB_DIM_HR_LOGIN
from rpa.ssc.hr.orm.tb_dim_hr_staff import TB_DIM_HR_STAFF
from rpa_launcher.backend.ws.dispatcher import add_rpc_method
from rpa_launcher.backend.ws.permission import (get_staff_permission_names,
                                                get_staff_role_names)
from sqlalchemy import desc
from xpinyin import Pinyin

PINYIN = Pinyin()


@add_rpc_method(name="/user/me")
def me() -> Dict[str, str]:
    staff_roles = get_staff_role_names(rpa.config.STAFF_ID)
    staff_permissions = get_staff_permission_names(rpa.config.STAFF_ID)
    if rpa.config.STAFF_ID is None:
        raise Exception("未登录")
    with DbSession() as s:
        user: Optional[TB_DIM_HR_STAFF] = s.query(TB_DIM_HR_STAFF).filter(TB_DIM_HR_STAFF.id == rpa.config.STAFF_ID).first()
        if user is None:
            raise Exception("用户不存在")
        else:
            user_profile = {attr: getattr(user, attr) if isinstance(getattr(user, attr), bool) else str(getattr(user, attr) or '') for attr in dir(user) if not attr.startswith('_') and 'password' not in attr}
            user_profile['staff_roles'] = staff_roles
            user_profile['permissions'] = staff_permissions
            return user_profile


@add_rpc_method(name="/user/register")
def register(username: str, phone_num: str, email: str, tel_num: str, fso_username: str, fso_password: str, funj: str):
    fso_username = fso_username.strip()
    fso_password = fso_password.strip()
    funj = funj.upper().strip()
    with DbSession() as db_session:
        if db_session.query(TB_DIM_HR_STAFF).filter(TB_DIM_HR_STAFF.fso_username == fso_username).first() is not None:
            raise Exception(f'用户{fso_username}已存在，请勿重复注册')
        if db_session.query(TB_DIM_HR_STAFF).filter(TB_DIM_HR_STAFF.funj == funj).first() is not None:
            raise Exception(f'{funj}已存在，请勿重复注册')
        try:
            check_fso_login(fso_username, fso_password)
        except Exception as e:
            raise Exception('校验FSO账号登录信息失败，错误信息：' + str(e))
        # 20210129 更新，由于快捷登录SAP刷新tx文件机制变化，现在不需要收集登录账号创建计划任务
        # try:
        #     check_win_login(get_username(), win_password)
        # except Exception as e:
        #     raise Exception('校验windows账号登录信息失败，错误信息：' + str(e))
        if len(tel_num) != 8:
            raise Exception("固话号码必须为8位")
        if len(phone_num) != 11 or phone_num[0] != '1':
            raise Exception("手机号码不合法")
        staff = TB_DIM_HR_STAFF(staff_name=username,
                                fso_username=fso_username,
                                fso_password=encrypt(fso_password),
                                win_username=get_username(),
                                phone_num=phone_num,
                                tel_num=tel_num,
                                email=email,
                                funj=funj,
                                staff_pinyin=PINYIN.get_pinyin(username, ''),
                                is_valid=True,
                                is_virtual_fso=False,
                                )
        db_session.add(staff)
        db_session.flush()
        staff.staff_id = staff.id


@add_rpc_method(name='/user/check_win_login')
def user_check_win_login(win_username: str, win_password: str):
    """检查windows用户名密码是否正确"""
    if win_username != get_username():
        raise Exception('Windows登录信息验证不通过，请确认用户名是否正确')
    if check_win_login(win_username, decrypt(win_password)) is False:
        raise Exception('Windows登录信息验证不通过，请确认密码是否正确')


@add_rpc_method(name='/user/get_login_info')
def get_login_info() -> bool:
    """检查数据库中是否有最新的登录信息"""
    mac_addr = get_macaddr()
    win_username = get_username()
    rpa.config.WIN_USERNAME = win_username
    with DbSession() as s:
        login_info: Optional[TB_DIM_HR_LOGIN] = s.query(TB_DIM_HR_LOGIN).filter(TB_DIM_HR_LOGIN.mac_addr == mac_addr,
                                                                                TB_DIM_HR_LOGIN.win_username == win_username
                                                                                ).order_by(desc(TB_DIM_HR_LOGIN.create_time)).first()
        if login_info is None:
            return False
        win_password = decrypt(login_info.win_password)
        if check_win_login(win_username, win_password) is False:
            return False
        rpa.config.WIN_PASSWORD = win_password
        return True


@add_rpc_method(name='/user/update_login_info')
def update_login_info(win_username: str, win_password: str):
    """更新windows登录信息"""
    mac_addr = get_macaddr()
    ip_addr = get_ip()
    hostname = get_hostname()
    win_username = get_username()
    with DbSession() as s:
        s.add(TB_DIM_HR_LOGIN(mac_addr=mac_addr,
                              ip_addr=ip_addr,
                              hostname=hostname,
                              win_username=win_username,
                              win_password=encrypt(win_password)))
