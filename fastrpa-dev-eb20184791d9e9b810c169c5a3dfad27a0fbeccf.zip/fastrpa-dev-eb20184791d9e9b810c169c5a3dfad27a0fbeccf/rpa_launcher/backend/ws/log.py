import rpa.config
from rpa_launcher.backend.ws.dispatcher import add_rpc_method


@add_rpc_method(name="/log/log_text/get")
def get_log_text(begin_idx: int = 0):
    return rpa.config.LOG_TEXT[begin_idx:]
